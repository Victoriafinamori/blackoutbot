# FF BLACKOUT — Bot Discord

Bot modular de Discord para administração, moderação, atendimento, registro, movimentação, entretenimento, campeonatos e sistemas sociais.

## Comece por aqui

### Para agentes / Codex

**Leia primeiro `AGENTS.md`.** Ele contém o mapa de contexto do repositório e diz exatamente quais arquivos devem ser lidos para cada tipo de tarefa. O objetivo é evitar varrer o projeto inteiro a cada alteração. As pastas `src/`, `app/` e `prisma/` também possuem `AGENTS.md` locais com regras específicas da camada.

### Para entender o estado técnico atual

Consulte `docs/TECHNICAL.md`.

### Para ver o que mudou ao longo do tempo

Consulte `docs/CHANGELOG.md`.

## Estado de execução atual

| Camada | Função |
|---|---|
| `src/` | Fonte TypeScript disponível para desenvolvimento |
| `dist/` | Saída do TypeScript; não é o alvo atual da Square Cloud |
| `app/` | **Código JavaScript executado atualmente na Square Cloud** |
| `prisma/` | Schema e migrations do banco |
| `assets/` | Recursos estáticos do bot |

> **Atenção:** `squarecloud.app` inicia `app/index.js`. Há funcionalidades presentes em `app/` que ainda não possuem equivalente em `src/`. Leia `AGENTS.md` antes de modificar qualquer módulo.

## Stack

- Node.js >= 22.12 (necessário pela camada de voz da Rádio 24h)
- TypeScript 5.6
- discord.js 14
- Prisma 5.20
- Banco configurado por `DATABASE_URL`
- Hospedagem preparada para Square Cloud

## Fluxo de inicialização na Square Cloud

O START atual executa, em ordem:

1. `prisma generate`
2. verificação do Prisma Client
3. `prisma migrate deploy`
4. registro dos slash commands
5. `app/index.js`

Essa sequência está definida em `squarecloud.app`.

## Documentos específicos existentes

- `README_FIX_CURTIDAS.txt` — correção histórica do Social


## Submundo

O módulo **Submundo** fica em `/adm → Social e entretenimento → Submundo` e reúne:

- fotos e vídeos anônimos com painel configurável, horários, limpeza e logs privados;
- mensagens anônimas em formato de confissão/Tellonym, também com horários, limpeza e logs;
- destaque automático da mídia mais curtida ao fechar a sessão.

A implementação de produção está em `app/submundo/` e nos componentes `anonymousPhoto*`, `anonymousMessage*` e `admSubmundo*`.

## Rádio 24h

O módulo **Rádio 24h** fica em `/adm → Social e entretenimento → Rádio 24h` e permite manter o bot conectado continuamente a uma call com uma playlist de links do YouTube.

Recursos atuais:

- call de voz ou palco configurável;
- playlist persistida, com adição em lote, remoção, paginação e reorganização;
- modos sequencial e aleatório;
- repetição contínua, volume e controles de reprodução;
- reconexão automática e restauração das rádios ativas após reinício do bot;
- faixas indisponíveis são puladas sem encerrar toda a rádio.

A implementação de produção está em `app/radio/service.js` e `app/components/buttons/admRadioMenu.js`. Os dados ficam nos models Prisma `RadioConfig` e `RadioTrack`.



## Central de Embeds V2

Em `/adm → Personalização do bot → Mensagens Personalizadas / Embeds`, o bot possui um construtor de embeds salvas com edição por etapas, prévia, publicação/atualização da mensagem original e clonagem. Cada embed pode ter título, descrição, autor, rodapé, cor, imagem, thumbnail, timestamp, canal de destino e até 25 botões. Os botões podem abrir um **canal do próprio Discord** ou um **link externo** (site, Instagram, TikTok etc.).

A configuração antiga de aparência global das embeds continua acessível em **Padrão do Bot** e segue sendo usada por `baseEmbed()` nos módulos que dependem do estilo padrão.

## Central de Denúncias

Em `/adm → Atendimento → Central de Denúncias`, o bot possui um atendimento privado especializado para denúncias: painel configurável no padrão moderno de Tickets (embed + botão com texto, emoji e cor + prévia), cargos responsáveis, categoria própria, logs/transcripts, ação de **Assumir** e fechamento com motivo. Cada membro pode ter uma denúncia aberta por vez. Ao encerrar, o bot salva o transcript nos logs e remove o canal.

O antigo VOTEBAN não faz mais parte da navegação ativa.

## Regra de manutenção da documentação

Toda implementação nova deve atualizar a documentação na mesma entrega:

- mudança estrutural, módulo, fluxo, comando, banco ou integração → `docs/TECHNICAL.md`;
- qualquer entrega relevante → `docs/CHANGELOG.md`;
- mudança no mapa de leitura dos agentes → `AGENTS.md`.

Assim, uma próxima tarefa pode começar pelo contexto certo sem reler todo o projeto.

> **Banco de produção:** enquanto a aplicação usar SQLite (`prisma/dev.db`) na própria árvore da Square Cloud, não substitua esse arquivo por banco local/vazio em atualizações. Leia `AGENTS.md` e `docs/TECHNICAL.md` antes de qualquer deploy que envolva banco.

### Parcerias
O BLACKOUT possui Central de Parcerias em `/adm → Atendimento → Parcerias`, com painel configurável no padrão moderno de Tickets (embed + botão com texto, emoji e cor + prévia), atendimento privado, staff responsável, aprovação/recusa, cargo automático, divulgação, logs e transcript.

## Interface administrativa BLACKOUT

A Central do servidor foi organizada na sequência de configuração da comunidade: **Personalização do bot**, **Equipe e proteção**, **Entrada e evolução**, **Atendimento**, **Comunidade e atividade**, **Jogos e eventos** e **Social e entretenimento**.

O visual usa preto, branco e vermelho, com banner e sete PNGs próprios. O bot prepara os PNGs como emojis da aplicação para usá-los nos selects; os emojis e espaços do servidor são preservados. As configurações e mensagens públicas existentes não são redefinidas.

Para verificar a navegação localmente: `node --test tests/admin-ui.test.cjs tests/personalization.test.cjs tests/security.test.cjs tests/log-center.test.cjs`. Consulte `docs/TECHNICAL.md` para os limites da validação e as divergências preexistentes do build.

### Personalização por comprador

Nome, avatar e banner são personalizados apenas no servidor do cliente, com autorização administrativa local. O painel não altera a identidade global da conta do bot. As alterações salvas aparecem na própria embed; modelos salvos só atualizam a mensagem pública ao usar Publicar/Atualizar publicação.

Esta entrega inclui uma migração aditiva de três colunas, aplicada pelo START existente da Square Cloud. Consulte `ATUALIZAR-SQUARE-CLOUD.md` antes de aplicar o pacote. Nunca envie banco local, `.env` ou backups junto da atualização.


Equipe e proteção separa Equipe e permissões, Proteção automática, Moderação de membros e Logs e auditoria. A moderação parte do membro, mostra histórico e exige revisão e confirmação antes das ações. Seleções atualizam a própria embed; logs usam um canal geral com destinos opcionais por categoria. Validação atual: 47 testes simulados. Não houve deploy ou punição real durante o desenvolvimento.


A central de logs oferece 24 tipos de eventos, envio local/externo/em ambos, destinos por categoria, filtros e teste externo antes da ativação. Os novos eventos começam desligados. Texto apagado fora do cache é identificado como indisponível; calls não têm gravação de áudio. A entrega cumulativa inclui uma migration aditiva para a configuração por servidor. Validação atual: 75 testes offline, sem acesso ao bot ou banco em produção.


A navegação de logs foi simplificada para O que registrar, Onde enviar, O que ignorar e Testar envio. Os destinos aparecem por nome; Reintegração fica em Sistemas do bot, com configurações independentes. Atalhos levam aos painéis próprios de Tickets e Registro. A demonstração de antes/depois e o ZIP cumulativo acompanham a entrega; o bot online não foi alterado.
