# BLACKOUT — Mensagens V2 e Cargos por reação

## Criar uma mensagem

Abra `/adm → Personalização do bot → Mensagens Personalizadas / Embeds → Criar mensagem`.

1. Escolha um bloco para editar ou use Adicionar bloco: título, texto, texto com miniatura, galeria, separador ou botões de links/canais.
2. Salve o formulário. A alteração aparece na mesma mensagem do editor. Reorganizar / remover também permite mover ou duplicar os blocos. Desfazer recupera a alteração anterior.
3. Use Nome e cor para o nome interno e o acento do cartão. Imagens usam URLs HTTP(S) acessíveis pelo Discord. Ver prévia oculta os controles de edição e permite voltar.
4. Salvar modelo guarda uma versão reutilizável. Publicar abre a escolha de canal e a conferência; somente Confirmar envia a mensagem.

Novas mensagens usam Components V2 do Discord. A prévia pode ter páginas para acomodar os controles; a publicação inteira precisa caber em uma mensagem nativa. Os limites são conferidos antes do envio. Modelos antigos são preservados e aparecem como importados, com prévia de conversão.

## Gerenciar mensagens enviadas

Entre em Mensagens enviadas e escolha a publicação. O painel mostra o conteúdo registrado, canal e estado.

- Ir para mensagem abre o envio no Discord.
- Editar este envio abre um rascunho exclusivo daquela publicação. Confirmar atualiza somente aquela mensagem; o modelo e outros envios permanecem iguais.
- Publicar uma cópia abre outro rascunho e permite escolher outro canal.
- Verificar acesso confere a mensagem. Excluir publicação pede confirmação e apaga somente esse envio.

Excluir um modelo salvo não apaga publicações. O editor importa somente a última publicação antiga que já possuía ID registrado, sem inventar um histórico de todos os envios. O conteúdo antigo convertido pode diferir da mensagem original; confira-a antes de atualizar. A data de registro de um envio importado não é a data histórica original.

Se aparecer entrega não confirmada, confira o canal antes de tentar outro envio. Registrar mensagem existente permite informar o ID da mensagem já enviada; o bot valida autoria, destino e conteúdo. Mensagem apagada ou inacessível não é recriada automaticamente.

## Criar um painel de cargos por reação

Abra `/adm → Entrada e evolução → Cargos e automações → Cargos por reação → Criar painel`.

1. Em Mensagem e prévia, personalize o cartão com o mesmo editor V2. A legenda das associações é automática.
2. Em Reações e cargos, escolha um cargo e informe um emoji Unicode ou personalizado disponível para o bot. Cada painel aceita até 20 associações; os membros podem escolher mais de um cargo.
3. Escolha o Canal do painel e a regra Ao retirar a reação: remover a concessão do painel ou preservar o cargo.
4. Use Publicar / atualizar, confira e confirme. O bot envia o cartão, adiciona as próprias reações e ativa o painel quando terminar.
5. O membro reage à mensagem para receber o cargo. A retirada segue a regra publicada. Cargos que já eram do membro ou ainda são concedidos por outro painel são preservados.

Cargos administrativos, cargos gerenciados por integrações e cargos acima do bot não podem ser oferecidos. O bot precisa de acesso ao canal/histórico, envio, adição de reações e Gerenciar Cargos. O cargo do bot deve estar acima dos cargos oferecidos; emojis externos podem exigir permissão adicional.

O atalho Usar em painel de cargos, no editor de mensagens, cria um painel independente com o conteúdo copiado. Cargos por reação continua tendo seu próprio acesso.

## Manutenção dos painéis

Pausar painel interrompe o processamento de reações e preserva os cargos. Ao retomar, use Conferir funcionamento para diagnosticar permissões, mensagem e reações. Eventos ocorridos durante pausa ou com o bot desligado não são reproduzidos automaticamente.

Sincronizar participações lê as reações atuais e mostra uma revisão; somente a confirmação aplica mudanças. O trabalho avança em etapas de até 25 operações, com progresso e opção de continuar. A revisão aceita até 2.000 participações e expira após 20 minutos; para um painel maior, divida-o antes de usar essa sincronização.

Para trocar uma associação publicada, desative a antiga e crie outra. A revisão permite preservar os cargos ou revisar suas retiradas em etapas. Salvar texto, cargo ou regra não dispara uma retirada em massa. Reações antigas podem continuar na mensagem, mas associações desativadas não concedem cargos. Se o Discord bloquear novas reações porque a mensagem já atingiu seu limite, confira as reações existentes antes de publicar novamente.

Mensagem apagada, reações limpas ou cargo removido suspendem o painel afetado. Corrija o motivo indicado e atualize a publicação existente; não se cria outra mensagem silenciosamente. Para mudar o canal de um painel já publicado, duplique-o e configure o novo destino.

## O que foi validado

240 testes offline aprovados, incluindo 55 testes novos dos três fluxos. Telas geradas pelo código foram conferidas em desktop e celular. As cinco migrations foram verificadas numa cópia isolada do banco enviado, preservando as 123 tabelas anteriores. A atualização ainda precisa ser aplicada e conferida no Discord/Square Cloud; nenhum envio real ou deploy foi feito nesta entrega.
