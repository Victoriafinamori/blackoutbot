## Atualização vigente — Central de segurança (24/10/2026)

O pacote atual é **BLACKOUT-seguranca-atualizada.zip**, cumulativo desde o SNAPSHOT. Inclui as entregas anteriores e a nova Central de segurança. É um patch sobre a aplicação existente; não inclui um banco novo. As seções abaixo deste complemento são o histórico das etapas anteriores.

1. Faça backup do banco vivo e preserve `.env`, `prisma/dev.db` e as migrations anteriores. Aplique os arquivos do ZIP sobre o código existente. Não apague a aplicação, substitua o banco ou copie dist/ inteiro por cima de app/. MAIN e START continuam iguais; a Square Cloud executa **app/index.js**.
2. Confira no START Prisma generate, verificação dos delegates e migrate deploy. A sexta migration é `20261024180000_security_center`: oito tabelas independentes, sem alterações nas tabelas anteriores. As cinco anteriores permanecem no ZIP cumulativo. Não use reset ou db push. Nenhum slash command ou pacote npm foi acrescentado nesta etapa.
3. Abra um novo `/adm → Equipe e proteção → Central de segurança`. As 19 regras novas começam desligadas. O provedor de PNGs prepara sete emojis da aplicação sob demanda; os slots de emoji do servidor permanecem disponíveis. Falha de provisionamento preserva os rótulos e a imagem local. Confira `[blackout-security]` nos logs se necessário.
4. Cadastre contas/bots e cargos confiáveis, pessoas/cargos protegidos e canais ignorados. Administradores do bot podem consultar, mas alterações exigem Administrador do Discord ou proprietário. Modos, respostas, limites e exceções têm revisão na mesma mensagem e confirmação explícita.
5. Use primeiro Observar e registrar e confira as ocorrências. Em Conferir funcionamento, revise auditoria, permissões/hierarquia e acesso aos canais. GuildModeration já é solicitado no código; Ver Registro de Auditoria é necessário. Server Members e Message Content precisam estar habilitados/aprovados quando exigidos. A resposta escolhida também precisa de Gerenciar Cargos/Mensagens/Webhooks, Expulsar, Banir ou Moderar Membros conforme a ação.
6. Configure Logs e auditoria para a categoria Servidor e segurança, mantendo o modo local/externo/ambos que a equipe escolheu. Autorização externa é a mesma da central anterior e continua sendo revalidada. Incidentes ficam no banco mesmo se o destino estiver indisponível; reenvio de log não repete punições.
7. Teste intencionalmente em um servidor/canal/membro/cargo de teste: salvar um limite e conferir o painel; observar uma ocorrência sem punição; escolher uma resposta e testar a execução/hierarquia; revisar e cancelar; testar restauração de uma contenção temporária. Para Anti Ban e permissões, use somente contas e alvos de teste autorizados, com a equipe ciente da ação real. Esta validação ao vivo não foi feita nesta entrega.
8. Filtros antigos permanecem independentes em Chat e conteúdo → Palavras, links e filtros existentes. Observar uma regra nova não desliga as punições do automod antigo. A blacklist de reintegração não foi transformada em blacklist de entrada automaticamente.

Guia completo: **SEGURANCA-BLACKOUT.md**. Contenção automática de entrada não expulsa membros anteriores. Anti Ban reage à auditoria depois da ação e depende de hierarquia; não impede a primeira ação nem restaura tudo que foi apagado. URL personalizada é monitorada, sem promessa de recuperação. Calls sem executor identificado só geram registro. Restrição de chats tem prazo, snapshot e retomada; conflitos de alterações posteriores exigem conferência manual e podem ser encerrados preservando as regras atuais.

Validação: **319 testes offline** em nove suítes, incluindo 79 novos; 32 telas em desktop/celular; SQL das seis migrations numa cópia isolada do banco enviado, preservando todas as colunas/valores das 123 tabelas anteriores. Prisma validate/generate passaram. O migrate deploy nativo, concessões/punições reais e renderização no cliente Discord não foram executados neste ambiente. Permanece um erro TypeScript preexistente em denunciaSelects.ts:61, sem erros novos. Sem login, envio real, alteração do banco vivo ou deploy. A versão em uso só muda quando o pacote for aplicado.

---

## Atualização vigente — Mensagens V2 e Cargos por reação (23/10/2026)

O pacote atual é **BLACKOUT-mensagens-e-cargos-atualizados.zip**, cumulativo desde o SNAPSHOT e substituto dos ZIPs anteriores. Inclui o refinamento administrativo, logs, Social e Jogos e eventos, além dos três recursos desta etapa. É um patch sobre a aplicação existente, não uma instalação com banco vazio.

1. Faça backup do banco vivo e preserve `.env`, `prisma/dev.db` e todas as migrations anteriores. Aplique o conteúdo do ZIP sobre o código existente; não apague a aplicação nem substitua o banco por um arquivo local. O ZIP exclui credenciais, bancos, backups, node_modules e dist.
2. Mantenha `MAIN=app/index.js` e o START atual. Não copie um build global de dist/ por cima de app/: há funcionalidades exclusivas em produção. package.json, package-lock.json e squarecloud.app foram preservados. Use uma instância por banco SQLite.
3. O START continua gerando o Prisma Client, conferindo seus delegates e aplicando `prisma migrate deploy`. A quinta migration é `20261023180000_message_maker_reaction_roles`, com oito tabelas novas e sem alterações nas anteriores. Não use reset ou db push. Confira o sucesso das migrations antes de usar os novos painéis. Nenhum slash command foi acrescentado nesta etapa.
4. GuildMessageReactions e partials Reaction/User foram acrescentados no código. Confira no Developer Portal o Server Members já utilizado pelo bot e as aprovações de intents que se aplicarem ao aplicativo. Reações precisam das permissões de canal/histórico/Adicionar Reações; cargos exigem Gerenciar Cargos e hierarquia adequada. Se usar emojis de fora do servidor, confira Usar Emojis Externos.
5. Abra um novo `/adm`. Em Personalização do bot → Mensagens Personalizadas / Embeds, teste criar, salvar um formulário e ver a mudança na mesma mensagem. Publique intencionalmente num canal de teste, envie uma cópia a outro canal e atualize só o primeiro envio. Confira que modelo e segundo envio permanecem iguais. Confira também o retorno às sete categorias, presentes nos seletores com os PNGs aprovados.
6. Em Entrada e evolução → Cargos e automações → Cargos por reação, crie um painel com cargo de teste, configure a reação e confirme a publicação. Com um membro autorizado de teste, confira receber/retirar, preservar um cargo já existente, pausa, retomada e revisão da sincronização. Edite a mensagem do painel e confirme que ele atualiza a mesma mensagem.
7. Modelos e IDs antigos são importados ao abrir a central, sem sobrescrever as linhas anteriores. Um envio legado mostra aviso: a prévia veio do modelo salvo e precisa ser comparada ao original. Falha incerta pede conferência do canal e oferece registrar a mensagem existente, sem reenviar automaticamente.

Guia do administrador: `MENSAGENS-E-CARGOS.md`. Limites: até 20 associações por painel, escolhas múltiplas, sincronização manual de até 2.000 participações com etapas de 25. Mídias usam URLs HTTP(S) e dependem de disponibilidade/formato aceito pelo Discord. Pausar não retira cargos e eventos offline não são recuperados automaticamente.

Validação da entrega: 240 testes offline; 25 telas em duas larguras; SQL das cinco migrations numa cópia isolada do banco com todas as colunas/valores das 123 tabelas anteriores preservados. Prisma validate e generate passaram. O migrate deploy nativo, envio real, concessão real de cargos e renderização no cliente Discord não foram executados neste ambiente. O typecheck global conserva um erro anterior em denunciaSelects.ts:61. A versão em produção só muda quando o pacote for aplicado na Square Cloud.

Os complementos abaixo são o histórico das etapas anteriores. Para o ZIP e a contagem de migrations/testes vigentes, use esta seção.

---

# Refinamento administrativo BLACKOUT — atualização na Square Cloud

Este ZIP contém as mudanças acumuladas desde o SNAPSHOT enviado. Aplique à aplicação existente; a produção continua iniciando `app/index.js`.

## Aplicar

1. Faça backup dos arquivos e do banco atual pela Square Cloud. Guarde as credenciais em local privado.
2. Extraia o ZIP na raiz da aplicação existente, substituindo somente os arquivos de mesmo caminho incluídos. Preserve os demais arquivos. Use uma atualização de arquivos que não apague a aplicação inteira.
3. **Preserve o `.env` e o `prisma/dev.db` atuais.** O pacote não inclui credenciais, banco, backups ou dependências. Ele inclui o schema atualizado e migrations aditivas. Não envie um banco vazio/local para produção.
4. Reinicie a aplicação existente usando o START já configurado. Ele executa a geração do Prisma e `prisma migrate deploy` antes de iniciar o bot. A migration `20261021180000_personalization_module_notifications` acrescenta três campos opcionais. A migration `20261021220000_server_log_center` cria a tabela de configuração dos logs. Elas não removem tabelas nem registros. Não use `prisma migrate reset` ou `db push`.
5. Confira os logs de inicialização. Se a migration ou a geração do Prisma falhar, guarde a mensagem de erro para diagnóstico; não apague o banco ou o histórico de migrations para contornar a falha.
6. Abra `/adm` novamente. Confira Personalização do bot, os retornos, os sete PNGs e as prévias que mudam na própria mensagem. Teste o perfil em um servidor de teste e confirme que outros servidores mantêm seus próprios perfis.

As dependências, os comandos registrados e a configuração de inicialização permanecem os mesmos. O JavaScript de produção já está em `app/`: não é necessário rodar build para aplicar este pacote. **Não copie `dist/` por cima de `app/`.** Não inicie uma segunda instância do mesmo bot.

## O que mudou

- Personalização do bot com Perfil neste servidor, Padrão das mensagens e Mensagens Personalizadas / Embeds.
- Nome, avatar e banner editados somente no servidor atual, sem alteração global da conta.
- Prévia real na própria embed após salvar; publicação de mensagens continua sendo uma ação explícita. O editor indica alterações ainda não publicadas.
- Cargos automáticos em Entrada e evolução; logs em Equipe e proteção → Logs e auditoria.
- Avisos de moderação e DMs de reintegração nos respectivos módulos, com preferências independentes.
- Identidade administrativa BLACKOUT e PNGs próprios, cadastrados como emojis da aplicação sem consumir espaços do servidor.

A migration acrescenta `moderationNotifyDm` e `reintegrationNotifyDm` em `GuildConfig`, e `publishedPayloadHash` em `CustomEmbed`. Os novos campos começam sem valor. As preferências anteriores de DM continuam sendo usadas até a configuração individual. Publicações antigas aparecem com estado desconhecido até uma publicação pelo novo editor.

## Validação e limites

- `node --test tests/admin-ui.test.cjs tests/personalization.test.cjs tests/security.test.cjs tests/log-center.test.cjs`: 75 testes aprovados com banco e API simulados, incluindo isolamento por servidor, atualização da mesma mensagem, permissões e publicação.
- SQL da migration aplicado em cópia isolada do banco enviado: todos os registros e valores anteriores preservados. O banco da aplicação em produção não foi acessado.
- Prévia produzida pelos builders de produção, conferida em desktop e celular. O HTML usa dados ilustrativos; o Discord controla a renderização nativa.
- Checagem TypeScript mantém os 38 erros preexistentes do SNAPSHOT, sem erros novos. Não substitua a aplicação por um build parcial.

Não foram executados login no Discord, deploy na Square Cloud ou a migration pelo CLI nativo do Prisma neste ambiente: o download do engine foi bloqueado. A execução real do START e a renderização no Discord precisam ser conferidas na aplicação atualizada. Se os PNGs não aparecerem, consulte `[blackout-ui]` nos logs; a preparação permite nova tentativa após cinco minutos, sem excluir emojis existentes.


## Conferir Equipe e proteção após atualizar

A área agora contém quatro entradas. Teste com um servidor de teste: salvar cargos e reabrir o mesmo seletor; alterar um filtro e conferir o estado; escolher resposta automática; configurar o canal geral e um destino separado de logs; escolher um membro e cancelar uma revisão de moderação. Para validar execução real, use somente uma ação intencional sobre uma conta de teste autorizada. Revisões expiram após dez minutos e são invalidadas ao reiniciar o bot; abra uma nova após o deploy. Esta etapa não acrescenta migrations além da migration de personalização já descrita acima.


## Configurar a central de logs

1. Abra `/adm → Equipe e proteção → Logs e auditoria → O que registrar`. Novos eventos de alto volume começam desligados; escolha os que sua equipe precisa.
2. Em Onde enviar, escolha local, somente externo ou ambos. Configure primeiro o servidor/canal externo; o bot precisa estar nos dois servidores. O responsável precisa administrar o bot na origem e ter Administrador ou Gerenciar Servidor no destino. Esse acesso é revalidado em cada envio; perda de acesso exige reautorização por outro administrador.
3. Use Testar destino externo para enviar um exemplo antes de ativar o envio externo. Ele não muda o modo nem ativa eventos. Configure canais por categoria somente se necessário; todos podem usar o mesmo canal geral.
4. Ajuste os filtros de canais/categorias, cargos e outros bots. Eventos do próprio bot são ignorados para evitar repetição. Dados de cargo ausentes podem fazer um evento ser omitido quando há filtro de cargos.
5. Abra Testar envio → Verificar permissões, inclusive permissão Ver Registro de Auditoria para banimentos fora do bot. Server Members e Message Content precisam estar habilitados/aprovados no Developer Portal para os eventos/conteúdos correspondentes. Os intents já são solicitados pelo código.

Tickets e Registro mantêm seus destinos externos próprios. Edição/exclusão de mensagens depende do conteúdo disponível no cache; exclusão em massa mostra uma amostra de até dez mensagens, não um transcript completo. URLs de anexos podem expirar. A fila de envio é limitada e fica em memória: reinícios, excesso de volume ou falhas podem causar perda de logs; o diagnóstico mostra contadores do processo. Não se trata de arquivo durável de todas as mensagens do servidor.

As duas migrations foram aplicadas juntas em uma cópia isolada do banco do SNAPSHOT, preservando os valores das 123 tabelas anteriores. O CLI nativo de migrations e a entrega real no Discord continuam sem validação neste ambiente. Preserve `.env`, banco e migrations anteriores; confira o START na Square Cloud antes de ativar os novos eventos.


## Conferir a navegação refinada

A central agora apresenta quatro entradas principais. Onde enviar inclui o destino e os canais por categoria; IDs e autorização aparecem em Detalhes e ajuda. Reintegração está agrupada em Sistemas do bot, com flags e destinos anteriores preservados. Os atalhos de Tickets/Registro abrem os painéis próprios desses módulos e oferecem retorno à central. Esta etapa altera somente código/documentação; as duas migrations acima continuam sendo as únicas migrations incluídas no pacote cumulativo.


## Refinamento das áreas restantes — 21/10/2026

O pacote `BLACKOUT-refinamento-completo.zip` é cumulativo: inclui as entregas anteriores de personalização, equipe e central de logs e acrescenta a revisão dos módulos restantes. A produção continua em `app/index.js`. Esta etapa não cria migration; as duas migrations anteriores continuam incluídas.

- Entrada e evolução: Cargos e automações reúne a entrada automática e o acesso à transferência programada. A transferência sai da Reintegração; seus IDs antigos e o serviço de transferência permanecem.
- Registro: cinco entradas principais; gerenciamento da pergunta, descrição, obrigatoriedade e ordem das páginas; categoria e responsáveis no atendimento; logs locais/externos próprios; mensagens e prévias na mensagem de origem; publicação explícita. Configuração externa exige acesso administrativo ao destino no momento de configurar. Os logs da central possuem a autorização contínua documentada acima; os logs próprios do Registro continuam sendo um fluxo independente.
- Oficialização: resumo compacto, seleção de tarefas, cargos em tela própria e prévia após editar mensagens.
- Atendimento: Canais, responsáveis e mensagens são tarefas identificadas. Parcerias e Denúncias atualizam os editores e os seletores na mensagem de origem. Salvar aparência não publica o painel. Tickets tem Ver prévia e publicação explícita no editor.
- Comunidade: nomes de atividade e rankings, retorno da área e organização por tarefas. Análise de inatividade continua sendo uma análise; a atualização não executa limpeza ou remove membros.
- Jogos e eventos: jogos existentes, sorteios, Bingo e Free Fire continuam acessíveis. Aparência de sorteios passa a atualizar o painel aberto após salvar. Operações de partidas e publicação continuam com os handlers originais.
- Social: retornos, PNGs e tarefas consistentes. Rádio oferece escolha explícita de reprodução sequencial ou aleatória. Submundo preserva horários, privacidade, logs e histórico; editar aparência abre a prévia na mensagem de origem.

Após atualizar, abra um novo `/adm` para carregar os novos componentes. Confira Registro, Cargos e automações, atendimento e uma prévia de mensagem antes de usar a versão com a comunidade. Publicar é uma ação real sobre o canal escolhido. O HTML de demonstração usa dados fictícios e não se conecta ao Discord.

Validação desta entrega: 107 testes offline, 50 telas em duas larguras, sintaxe dos arquivos JavaScript e atualização sobre uma cópia sanitizada do SNAPSHOT. A checagem global de TypeScript ainda apresenta os 38 erros anteriores de tipagem (principalmente Bingo); nenhum erro foi acrescentado por esta etapa. Não houve login no Discord, alteração do banco vivo ou deploy na Square Cloud. Os JavaScripts alterados foram preparados diretamente para a camada de produção, preservando os módulos exclusivos de `app/`.

## Complemento — Social e entretenimento (22/10/2026)

O pacote `BLACKOUT-social-atualizado.zip` é cumulativo desde o SNAPSHOT e inclui as melhorias administrativas anteriores. Aplique somente os arquivos de código sobre a aplicação existente, preservando `.env` e `prisma/dev.db`. Faça backup do banco vivo antes da atualização. Não suba um banco de teste nem substitua a aplicação por um projeto vazio.

Há uma terceira migration aditiva: `20261022010000_social_experience`. O START existente executa Prisma generate e migrate deploy; nenhuma mudança de slash command foi necessária. Os novos módulos estão em app/, que é a camada de produção. Não executar npm build e copiar dist/ inteiro para app/.

Depois do START:
1. Abra `/adm → Social e entretenimento`: INSTA, Dinâmicas sociais, Submundo e Rádio 24h.
2. Configure dinâmicas e só depois ative a rotina. Ela pode publicar o tema de hoje se o horário local já passou. Publicar agora pede confirmação.
3. Em INSTA, abra Painel de participação e perfis para escolher canal, ver prévia e publicar/atualizar o hub. Perfis começam desativados e ocultos por membro.
4. Na Rádio, abra Pedidos e painel público para limites, aprovação e publicação. A configuração antiga de call/playlist continua sendo usada.
5. No Submundo, Privacidade e aprovação controla a fila opcional. Canal de revisão deve ser privado e +18. Destinos e logs existentes continuam necessários.
6. Teste PNG, GIF e MP4 pelo hub: prévia → confirmar → curtir/comentar. Confira mídia dentro do cartão no desktop e celular, sem anexos duplicados. O envio direto no canal do INSTA também continua disponível.

Vídeos usam o player da galeria nativa do Discord dentro de um cartão V2. Não há player de vídeo em EmbedBuilder clássico. Tamanho aceito e codec dependem do Discord. Em falhas, o original é preservado. Mídias históricas apagadas/fora do histórico recente podem precisar ser reenviadas.

Validação entregue é offline; não foi feito login no Discord ou deploy na Square Cloud. `.env`, banco, backups e node_modules ficam fora do ZIP. A fixture de testes SQLite requer Node >=22.13 (validada com Node24); não altera dependências de produção.

## Complemento atual — Jogos e eventos (22/10/2026)

`BLACKOUT-jogos-atualizados.zip` substitui os pacotes anteriores como entrega cumulativa desde o SNAPSHOT. Contém apenas arquivos novos/alterados; aplique sobre a aplicação existente. Preserve .env, prisma/dev.db e migrations anteriores; faça backup do banco vivo antes de atualizar. Não apague a aplicação nem copie dist/ sobre app/. MAIN continua app/index.js.

A quarta migration é `20261022140000_games_experience`: quatro tabelas novas e colunas de rodada/pontos/compartilhamento do TERMO. O START já gera o cliente, aplica migrate deploy e registra comandos; agora também registra `/jogar`. BingoOrder e configurações antigas foram alinhados no schema sem recriação de tabelas. Não use reset ou db push.

Após iniciar e conferir os logs de migration/registro:
1. Abra um novo `/adm → Jogos e eventos → Games de Chat → Painel de participação e resultados`. Defina canal, veja a prévia e publique quando desejar. O mesmo painel é atualizado, e editar aparência não publica automaticamente.
2. Em Bingo → Bingo comunitário e dinâmica, escolha canal, objetivo, limites e ritmo; confira a prévia e confirme Abrir inscrições. O novo modo é gratuito, com uma cartela por membro. Inicie depois do mínimo. Teste acesso com DMs fechadas, Atualizar, pausa e conferência de vencedores. O fluxo clássico continua em Bingo geral, sem consumir cartelas pendentes no novo modo.
3. Em TERMO, confira o fuso, regras, palavras e mensagem. Regras novas valem para a próxima palavra. Teste continuar, tentativa inválida, compartilhar uma vez e rankings.
4. Na Caixa, escolha se deseja anúncios por abertura ou resultado concentrado no painel. Teste Mais caixas, Meu resultado e estado de entrega. Prêmios externos permanecem pendentes até integração/confirmação real.
5. Em Eventos de interação, confira o acesso ao Quiz em equipes existente. Teste `/jogar` com um membro comum: os controles administrativos continuam restritos à equipe.

Validação: 185 testes offline; 24 telas em desktop/celular; SQL das quatro migrations testado em cópia isolada do banco fornecido, com todos os valores/colunas anteriores preservados. O Prisma migrate deploy nativo e a entrega real no Discord não foram executados aqui. A checagem TypeScript tem um erro anterior em denunciaSelects.ts; os arquivos JavaScript entregues têm validação de sintaxe. Nenhum login, envio real ou deploy foi feito. A versão em uso só muda quando este pacote for aplicado na Square Cloud.
