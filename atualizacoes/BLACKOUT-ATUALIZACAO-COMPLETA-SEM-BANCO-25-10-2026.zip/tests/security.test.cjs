const {test}=require('node:test');const assert=require('node:assert/strict');const {Collection,ChannelType}=require('discord.js');
const configs=new Map(),data={botAdmin:[],permissionRole:[],systemRole:[]},ops=[],effects=[];let active=2;
const clone=v=>structuredClone(v);
const prisma={serverLogSettings:{findUnique:async()=>null},guildConfig:{findUnique:async({where})=>configs.get(where.guildId),update:async({where,data:d})=>{ops.push(['config',where.guildId,d]);return Object.assign(configs.get(where.guildId),d)}},warn:{count:async()=>active},filterRule:{count:async()=>0,findMany:async()=>[]},adminLog:{findMany:async()=>[]},$transaction:async p=>Promise.all(p)};
for(const model of Object.keys(data))prisma[model]={findMany:async({where={}}={})=>data[model].filter(r=>Object.entries(where).every(([k,v])=>r[k]===v)),findUnique:async({where})=>data[model].find(r=>Object.entries(where.guildId_type).every(([k,v])=>r[k]===v))||null,
 create:async({data:d})=>{ops.push([model,'create',clone(d)]);data[model].push(clone(d));return d},deleteMany:async({where})=>{ops.push([model,'delete',where]);data[model]=data[model].filter(r=>!Object.entries(where).every(([k,v])=>r[k]===v))},upsert:async({where,create,update})=>{const r=data[model].find(r=>r.guildId===where.guildId_type.guildId&&r.type===where.guildId_type.type);if(r)Object.assign(r,update);else data[model].push(create);ops.push([model,'upsert',create]);},delete:async()=>{}};
function stub(path,exports){const id=require.resolve(path);require.cache[id]={id,filename:id,loaded:true,exports}}
stub('../app/database/prisma',{prisma});stub('../app/utils/adminLog',{logAdminAction:async()=>{}});
const service={getModerationHistory:async()=>({warns:[{active:true,reason:'Exemplo'}],mutes:[],actions:[],wordWatchHits:[]})};
for(const name of ['warnMember','muteMember','kickMember','banMember','unbanMember','unmuteMember','clearWarns'])service[name]=async(...args)=>{effects.push([name,args[0].id,...args.slice(1)])};
stub('../app/utils/moderation',service);
const flow=require('../app/utils/moderationPanel');const modals=require('../app/components/modals/modModals').default;const button=require('../app/components/buttons/teamModeration').default;
function fixture(id='100000000000000101'){
 configs.set(id,{guildId:id,notifyDm:true,moderationNotifyDm:null,notifyPublicWarns:false,autoMuteDurationMinutes:10,maxWarnsBeforeMute:3,maxWarnsBeforeBan:5,filterWordsEnabled:true,filterLinksEnabled:true,filterFloodEnabled:false,filterCapsEnabled:false,filterSpamEnabled:false,filterToxicityEnabled:false,autoModAction:'DELETE_ONLY',filterLinksMode:'BLOCK_ALL',wordWatchEnabled:false,capsThreshold:70,capsMinLength:10,floodMaxMessages:5,floodIntervalSeconds:5,spamMaxDuplicates:3,toxicityThreshold:70});
 const guild={id,ownerId:'100000000000000199',client:{user:{id:'100000000000000198',displayAvatarURL:()=> 'https://example.com/avatar.png'},application:{emojis:{cache:new Collection()}}},roles:{cache:new Collection()},channels:{cache:new Collection()},members:{}};
 const actor={id:'100000000000000102',guild,permissions:{has:()=>guild.authorized},roles:{highest:{comparePositionTo:()=>guild.actorAbove?1:-1},cache:new Collection()}};
 guild.actorAbove=true;guild.authorized=true;const target={id:'100000000000000103',roles:{highest:{}},moderatable:true,kickable:true,bannable:true,communicationDisabledUntilTimestamp:0};guild.target=target;
 guild.members.me={permissions:{has:()=>true}};guild.members.fetch=async arg=>{const uid=typeof arg==='string'?arg:arg.user;if(uid===actor.id)return actor;if(uid===target.id)return target;throw Error('Unknown member')};guild.members.fetchMe=async()=>guild.members.me;
 guild.channels.fetch=async id=>guild.channels.cache.get(id)||null;guild.bans={fetch:async()=>({})};return guild;
}
function interaction(guild,id,{values=[],fields={},user='100000000000000102',messageId='message-1'}={}){const calls=[];const i={guild,user:{id:user},message:{id:messageId},customId:id,values,fields:{getTextInputValue:k=>fields[k]??''},deferred:false,replied:false,isFromMessage:()=>true,isUserSelectMenu:()=>true,isStringSelectMenu:()=>true,isChannelSelectMenu:()=>true,async reply(p){calls.push(['reply',p]);i.replied=true},async followUp(p){calls.push(['followUp',p])},async update(p){calls.push(['update',p]);i.replied=true},async deferUpdate(){calls.push(['deferUpdate']);i.deferred=true},async editReply(p){calls.push(['editReply',p])},async showModal(p){calls.push(['modal',p])},calls};return i}
function panel(i){return i.calls.filter(([m,p])=>p?.embeds&&['update','editReply'].includes(m)).at(-1)?.[1]}
function validate(p){assert.ok(p);assert.ok(p.components.length<=5);for(const e of p.embeds){e.toJSON();assert.ok(e.length<=6000)}for(const r of p.components){const j=r.toJSON();assert.ok(j.components.length<=5);for(const c of j.components)assert.ok(c.custom_id.length<=100)}return p}
function ids(p){return p.components.flatMap(r=>r.toJSON().components).map(c=>c.custom_id)}
async function review(g,action='ban',fields={reason:'Motivo claro'}){const i=interaction(g,`adm-modal:mod:${action}:${g.target.id}`,{fields});await modals.execute(i);const p=validate(panel(i));return {i,p,id:ids(p).find(s=>s.startsWith('team-mod:confirm:'))}}

test('team settings show current roles, distinguish access from associations and retain selectors after saving',async()=>{
 const g=fixture();g.roles.cache.set('100000000000000110',{id:'100000000000000110',name:'Equipe',editable:true});
 const h=require('../app/components/selects/roleSelects').default;const i=interaction(g,'adm-role-select:botadmin',{values:['100000000000000110']});await h.execute(i);const p=validate(panel(i));assert.match(p.embeds[0].toJSON().fields[0].value,/100000000000000110/);assert.ok(ids(p).includes('adm-role-select:botadmin'));
 assert.ok(data.botAdmin.some(r=>r.guildId===g.id));assert.ok(!data.botAdmin.some(r=>r.guildId==='other'));
});
test('missing, everyone and unassignable system roles cannot be saved; current deleted roles remain visible for correction',async()=>{
 const g=fixture();const h=require('../app/components/selects/roleSelects').default;const before=ops.length;
 for(const id of ['missing',g.id,'high']){g.roles.cache.set('high',{id:'high',name:'Acima',editable:false});if(id===g.id)g.roles.cache.set(id,{id,name:'everyone'});const i=interaction(g,'adm-role-select:sysrole:MUTED',{values:[id]});await h.execute(i);assert.ok(i.calls.some(([m])=>m==='reply'))}
 assert.equal(ops.length,before);data.systemRole.push({guildId:g.id,type:'MUTED',roleId:'deleted'});const i=interaction(g,'');await require('../app/components/buttons/admAdminMenu').renderSysRoleType(i,'MUTED');assert.match(panel(i).embeds[0].toJSON().fields[0].value,/Cargo excluído/);assert.equal(panel(i).components[0].toJSON().components[0].default_values,undefined);
});
test('member-first screen opens history and paired actions without applying anything',async()=>{
 const g=fixture(),before=effects.length;const i=interaction(g,'adm-mod-user-select:member',{values:[g.target.id]});await require('../app/components/selects/modUserSelects').default.execute(i);const p=validate(panel(i));assert.match(p.embeds[0].toJSON().description,new RegExp(g.target.id));assert.ok(ids(p).some(s=>s.includes('action:unmute')));assert.ok(ids(p).some(s=>s.includes('action:clearwarns')));assert.equal(effects.length,before);
});
test('submitting a punishment only reviews it; confirming executes exactly once and refreshes the same panel',async()=>{
 const g=fixture(),before=effects.length;const {p,id}=await review(g);assert.equal(effects.length,before);assert.match(p.embeds[0].toJSON().fields.find(f=>f.name==='Motivo').value,/Motivo claro/);
 const i=interaction(g,id);await button.execute(i);assert.equal(effects.length,before+1);assert.equal(effects.at(-1)[0],'banMember');assert.equal(effects.at(-1)[1],g.id);validate(panel(i));
 const again=interaction(g,id);await button.execute(again);assert.equal(effects.length,before+1);assert.match(again.calls.at(-1)[1].content,/expirou/);
});
test('confirmation is scoped to guild, actor and originating message',async()=>{
 const g=fixture(),{id}=await review(g),before=effects.length;
 const other=fixture('100000000000000901');const wrongGuild=interaction(other,id);await button.execute(wrongGuild);assert.match(wrongGuild.calls.at(-1)[1].content,/outro painel/);
 const wrongMessage=interaction(g,id,{messageId:'other-message'});await button.execute(wrongMessage);assert.match(wrongMessage.calls.at(-1)[1].content,/outro painel/);
 g.members.fetch=async()=>({guild:g,permissions:{has:()=>true},roles:{highest:{comparePositionTo:()=>1}}});const wrongActor=interaction(g,id,{user:'100000000000000104'});await button.execute(wrongActor);assert.match(wrongActor.calls.at(-1)[1].content,/outro painel/);assert.equal(effects.length,before);
});
test('cancelling or an expired confirmation never executes a moderation action',async()=>{
 const g=fixture();let {id}=await review(g),before=effects.length;await button.execute(interaction(g,id.replace(':confirm:',':cancel:')));assert.equal(effects.length,before);
 ({id}=await review(g));const original=Date.now;try{Date.now=()=>original()+11*60*1000;const i=interaction(g,id);await button.execute(i);assert.match(i.calls.at(-1)[1].content,/expirou/)}finally{Date.now=original}assert.equal(effects.length,before);
});
test('lost access, changed hierarchy or lost bot permission blocks confirmation',async()=>{
 for(const change of [g=>g.authorized=false,g=>g.actorAbove=false,g=>g.target.bannable=false]){const g=fixture(),{id}=await review(g),before=effects.length;change(g);const i=interaction(g,id);await button.execute(i);assert.equal(effects.length,before);assert.ok(i.calls.some(([m])=>m==='reply'||m==='followUp'||m==='editReply'))}
});
test('changing warning thresholds or active warning count invalidates an earlier review',async()=>{
 const g=fixture();let {id}=await review(g,'warn'),before=effects.length;configs.get(g.id).maxWarnsBeforeBan=2;let i=interaction(g,id);await button.execute(i);assert.match(panel(i).embeds[0].toJSON().fields.at(-1).value,/mudaram/);assert.equal(effects.length,before);
 ({id}=await review(g,'warn'));active++;i=interaction(g,id);await button.execute(i);active--;assert.match(panel(i).embeds[0].toJSON().fields.at(-1).value,/mudaram/);assert.equal(effects.length,before);
});
test('review includes duration and automatic warning escalation; invalid durations cannot be confirmed',async()=>{
 const g=fixture();const r=await review(g,'mute',{reason:'Spam',duration:'25'});assert.equal(r.p.embeds[0].toJSON().fields.find(f=>f.name==='Duração').value,'25 minutos');
 const w=await review(g,'warn');assert.match(w.p.embeds[0].toJSON().fields.find(f=>f.name==='Escalonamento automático').value,/após esta, 3/);
 for(const duration of ['0','-1','25abc','1.5','40321','']){const i=interaction(g,'adm-modal:mod:mute:'+g.target.id,{fields:{reason:'Spam',duration}});await modals.execute(i);assert.ok(!panel(i));assert.match(i.calls.at(-1)[1].content,/duração/)}
});
test('reversals and unban require review and preserve reasons and target IDs',async()=>{
 const g=fixture();for(const action of ['unmute','clearwarns','unban']){const i=interaction(g,`adm-modal:mod:${action}:${g.target.id}`,{fields:{reason:'Revisão da equipe',userId:g.target.id}});const before=effects.length;await modals.execute(i);const p=validate(panel(i));assert.equal(effects.length,before);await button.execute(interaction(g,ids(p).find(s=>s.startsWith('team-mod:confirm:'))));assert.equal(effects.length,before+1)}
});
test('protection changes refresh the originating embed and response selection is explicit',async()=>{
 const g=fixture();let i=interaction(g,'adm-mod:filtros:toggle:flood');await require('../app/components/buttons/admModerationMenu').default.execute(i);assert.equal(configs.get(g.id).filterFloodEnabled,true);assert.match(panel(i).embeds[0].toJSON().description,/Flood:\*\* Ativado/);
 i=interaction(g,'adm-mod:filtros:automod');await require('../app/components/buttons/admModerationMenu').default.execute(i);assert.ok(ids(panel(i)).includes('adm-automod-select'));assert.equal(configs.get(g.id).autoModAction,'DELETE_ONLY');
 i=interaction(g,'adm-automod-select',{values:['MUTE']});await require('../app/components/selects/autoModActionSelect').default.execute(i);assert.equal(configs.get(g.id).autoModAction,'MUTE');assert.match(panel(i).embeds[0].toJSON().description,/Apagar e silenciar/);
});
test('logs start with general destination, retain category fallback and show inaccessible channels',async()=>{
 const g=fixture();configs.get(g.id).logChannelId='100000000000000555';const i=interaction(g,'');await require('../app/components/buttons/admLogsMenu').renderLogsMenu(i);const p=validate(panel(i));assert.ok(ids(p).includes('logs-center:destination'));assert.match(p.embeds[0].toJSON().fields.find(f=>f.name==='Pendências').value,/excluído|inacessível/);const org=interaction(g,'');await require('../app/logging/panel').renderLogOrganization(org,'local');assert.match(panel(org).embeds[0].toJSON().fields[0].value,/excluído|inacessível/);
});
test('read-only team and protection destinations serialize within Discord limits',async()=>{
 const g=fixture();for(const [file,names]of [['admAdminMenu',['renderAdminMenu','renderPermRolesMenu','renderSysRolesMenu']],['admModerationMenu',['renderModerationMenu','renderFiltersMenu','renderFiltersToggles','renderFiltersContent','renderFiltersLimits','renderFiltersWordWatch']]])for(const name of names){const i=interaction(g,'');await require('../app/components/buttons/'+file)[name](i);validate(panel(i))}
});
