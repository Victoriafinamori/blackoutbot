const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { Collection, ComponentType } = require('discord.js');
const root = path.resolve(__dirname, '..');
const { ADM_SECTIONS, ADM_SECTION_ORDER, resolveAdmSection, buildAdmRootPanel, buildAdmSectionPanel } = require('../app/utils/admPanel');
const { ADM_EMOJI_NAMES, admEmoji, ensureAdmEmojis, adminIconFile } = require('../app/utils/admEmojis');
const { adminEmbed, BLACKOUT_RED } = require('../app/utils/adminUi');

// UI tests never authenticate with Discord or read a live database.
const config = { guildId: '100000000000000001', embedColor: '000000', language: 'pt-BR', prefix: '!', timezone: 'America/Sao_Paulo', notifyDm: true, notifyPingStaff: false, notifyPublicWarns: false, autoRoleEnabled: false, autoRoleIds: null };
let writes = 0;
const prisma = new Proxy({}, { get(_, model) {
  return {
    findMany: async () => [], count: async () => 0,
    findUnique: async () => model === 'guildConfig' ? config : null,
    create: async () => { writes++; throw new Error('UI navigation attempted a database write'); },
    update: async () => { writes++; throw new Error('UI navigation attempted a database write'); },
    delete: async () => { writes++; throw new Error('UI navigation attempted a database write'); },
  };
}});
const dbPath = require.resolve('../app/database/prisma');
require.cache[dbPath] = { id: dbPath, filename: dbPath, loaded: true, exports: { prisma } };

function guildFixture({ populated = true, fail = false } = {}) {
  const cache = new Collection(); let creations = 0, fetches = 0;
  if (populated) Object.values(ADM_EMOJI_NAMES).forEach((name, i) => cache.set(String(100000000000000010n + BigInt(i)), { id: String(100000000000000010n + BigInt(i)), name }));
  const application = { emojis: {
    cache,
    async fetch() { fetches++; if (fail) throw new Error('simulated API outage'); return cache; },
    async create({ name, attachment }) { assert.ok(fs.existsSync(attachment)); creations++; const e = { id: String(200000000000000010n + BigInt(creations)), name }; cache.set(e.id, e); return e; },
  }};
  const guild = { id: config.guildId, name: 'Servidor de teste', client: { application, user: { username: 'BLACKOUT', displayAvatarURL: () => 'https://cdn.discordapp.com/embed/avatars/0.png' } }, members: { me: { displayName: 'BLACKOUT' }, fetch: async () => ({ guild, permissions: { has: () => true } }) }, roles: { cache: new Collection() } };
  guild.members.fetchMe = async () => guild.members.me;
  guild.members.me.permissions = { has: () => true };
  guild.channels = { cache: new Collection(), fetch: async () => null };
  return { guild, application, stats: () => ({ creations, fetches }) };
}
function interaction(guild, customId, values = [], allowed = true) {
  const calls = [];
  const i = { guild, customId, values, message: { id: '100000000000000050' }, user: { id: '100000000000000002', username: 'Admin' }, deferred: false, replied: false,
    inGuild: () => true, isStringSelectMenu: () => true,
    async reply(p) { calls.push(['reply', p]); i.replied = true; },
    async update(p) { calls.push(['update', p]); i.replied = true; },
    async deferReply(p) { calls.push(['deferReply', p]); i.deferred = true; },
    async deferUpdate() { calls.push(['deferUpdate']); i.deferred = true; },
    async editReply(p) { calls.push(['editReply', p]); },
    async followUp(p) { calls.push(['followUp', p]); }, calls,
  };
  guild.members.fetch = async () => ({ guild, permissions: { has: () => allowed }, roles: { cache: new Collection() } });
  return i;
}
function validatePayload(payload) {
  if (Number(payload.flags) & require('discord.js').MessageFlags.IsComponentsV2) {
    const {countComponents,textLength}=require('../app/message-maker/document');
    assert.equal((payload.embeds||[]).length,0);assert.ok(countComponents(payload.components)<=40);assert.ok(textLength(payload.components)<=4000);
    return [];
  }
  assert.ok(Array.isArray(payload.embeds) && payload.embeds.length > 0);
  const embeds = payload.embeds.map(e => e.toJSON());
  for (const embed of embeds) {
    assert.ok(embed.title?.length <= 256);
    assert.ok((embed.description?.length ?? 0) <= 4096);
    assert.ok((embed.fields?.length ?? 0) <= 25);
    assert.ok(payload.embeds[0].length <= 6000);
  }
  assert.ok(payload.components.length <= 5);
  for (const row of payload.components) {
    const data = row.toJSON();
    assert.ok(data.components.length <= 5);
    for (const c of data.components) {
      assert.ok(c.custom_id.length <= 100);
      if (c.type === ComponentType.StringSelect) {
        assert.ok(c.options.length > 0 && c.options.length <= 25);
        for (const o of c.options) { assert.ok(o.label.length <= 100); assert.ok(o.value.length <= 100); assert.ok((o.description?.length ?? 0) <= 100); }
      }
    }
  }
  const attachments = new Map((payload.files ?? []).map(file => [file.name, file]));
  for (const embed of embeds) for (const url of [embed.image?.url, embed.thumbnail?.url]) {
    if (url?.startsWith('attachment://')) { const file = attachments.get(url.slice(13)); assert.ok(file, `Missing attachment for ${url}`); assert.ok(fs.existsSync(file.attachment)); }
  }
  return embeds;
}

test('root uses the approved seven areas in order, with seven custom PNG emoji IDs', async () => {
  const { guild } = guildFixture(); const p = await buildAdmRootPanel(guild);
  const [embed] = validatePayload(p); const options = p.components[0].toJSON().components[0].options;
  assert.equal(embed.title, 'Central do servidor'); assert.equal(embed.color, BLACKOUT_RED);
  assert.deepEqual(options.map(o => o.value), ['sistema', 'seguranca', 'membros', 'atendimento', 'servidor', 'staff', 'entretenimento']);
  assert.equal(new Set(options.map(o => o.emoji.id)).size, 7);
  assert.ok(!JSON.stringify(embed).includes('expira')); assert.deepEqual(p.attachments, []);
});

test('all category payloads serialize within Discord limits with a real PNG and working back button', async () => {
  const { guild } = guildFixture();
  for (const area of ADM_SECTION_ORDER) {
    const p = await buildAdmSectionPanel(guild, area); validatePayload(p);
    assert.equal(p.components[1].toJSON().components[0].custom_id, 'adm-nav:root');
    assert.equal(p.components[0].toJSON().components[0].options.length, ADM_SECTIONS[area].modules.length);
    assert.deepEqual(p.attachments, []);
  }
});

test('all seven PNGs are valid 128px RGBA assets under Discord custom emoji size limits', () => {
  for (const area of ADM_SECTION_ORDER) {
    const file = fs.readFileSync(adminIconFile(area));
    assert.equal(file.subarray(0,8).toString('hex'), '89504e470d0a1a0a');
    assert.equal(file.readUInt32BE(16), 128); assert.equal(file.readUInt32BE(20), 128);
    assert.equal(file[25], 6); assert.ok(file.length < 256 * 1024);
  }
});

test('existing modules are preserved exactly once after regrouping', () => {
  const values = Object.values(ADM_SECTIONS).flatMap(s => s.modules.map(m => m.value));
  const old = ['administracao','moderacao','reintegracao','logs','tickets','registro','denuncias','parcerias','eventos','gameschat','estatisticas','movchat','movcall','subidamembros','limpa','familias','feedbackservidor','freefire','bingo','social','submundo','radio24h','sorteios'];
  for (const value of old) assert.equal(values.filter(v => v === value).length, 1, value);
  for (const action of ['autocargo','aparencia','padrao','embeds']) assert.ok(values.includes(`cfg:${action}`));
  assert.equal(resolveAdmSection('campeonatos'), 'staff'); assert.equal(resolveAdmSection('__proto__'), undefined);
});

test('application PNG provisioning is concurrency-safe across guilds and repeatable', async () => {
  const f = guildFixture({ populated: false }); const other = { ...f.guild, id: '100000000000000099' };
  await Promise.all([ensureAdmEmojis(f.guild), ensureAdmEmojis(other), ensureAdmEmojis(f.guild)]);
  assert.deepEqual(f.stats(), { creations: 7, fetches: 1 });
  await ensureAdmEmojis(f.guild); assert.deepEqual(f.stats(), { creations: 7, fetches: 1 });
  assert.equal(new Set([...f.application.emojis.cache.values()].map(e => e.name)).size, 7);
});

test('API failure has bounded retries and does not substitute default Unicode emojis', async () => {
  const f = guildFixture({ populated: false, fail: true }); const warn = console.warn; console.warn = () => {};
  try { await ensureAdmEmojis(f.guild); await ensureAdmEmojis(f.guild); } finally { console.warn = warn; }
  assert.deepEqual(f.stats(), { creations: 0, fetches: 1 }); assert.equal(admEmoji(f.guild,'sistema'), undefined);
  const p = await buildAdmRootPanel(f.guild); validatePayload(p);
  assert.ok(p.components[0].toJSON().components[0].options.every(o => !o.emoji));
});

test('slash command acknowledges before provisioning and sends all embed attachments', async () => {
  const { guild } = guildFixture({ populated: false }); const i = interaction(guild);
  await require('../app/commands/adm').default.execute(i);
  assert.equal(i.calls[0][0], 'deferReply'); assert.equal(i.calls[0][1].ephemeral, true);
  assert.equal(i.calls[1][0], 'editReply'); validatePayload(i.calls[1][1]);
  assert.equal(i.calls[1][1].files.length, 1);
});

test('unauthorized members cannot open the root, sections, or new back navigation', async () => {
  for (const [file, id, values] of [['commands/adm',null,[]], ['components/selects/admPanelSelect','adm-panel-select',['seguranca']], ['components/buttons/admNavigation','adm-nav:root',[]]]) {
    const { guild } = guildFixture(); const i = interaction(guild,id,values,false);
    await require('../app/'+file).default.execute(i);
    assert.ok(i.calls.some(([method,p]) => ['reply','editReply'].includes(method) && p.content.includes('permissão')));
    assert.ok(!i.calls.some(([,p]) => p?.embeds));
  }
});

test('new back navigation returns a complete root/section payload including the PNG file', async () => {
  const { guild } = guildFixture(); const i = interaction(guild,'adm-nav:membros');
  await require('../app/components/buttons/admNavigation').default.execute(i);
  assert.equal(i.calls[0][0], 'deferUpdate'); assert.equal(i.calls[1][0], 'editReply');
  validatePayload(i.calls[1][1]); assert.equal(i.calls[1][1].embeds[0].toJSON().title, 'Entrada e evolução');
});

test('each of the 29 section destinations dispatches to its intended existing renderer', async () => {
  const mappings = {
    protecao:['../../security/interactions','open'], administracao:['admAdminMenu','renderAdminMenu'], moderacao:['admModerationMenu','renderModerationMenu'], reintegracao:['admReintegrationMenu','renderReintegrationMenu'], logs:['admLogsMenu','renderLogsMenu'], tickets:['admTicketsMenu','renderTicketsMenu'], registro:['admRegistrationMenu','renderRegistrationMenu'], eventos:['admEventsMenu','renderEventsMenu'], gameschat:['admGamesChatMenu','renderGamesChatMenu'], estatisticas:['admStatsMenu','renderStatsMenu'], movchat:['admMovMenu','renderMovMenu'], movcall:['admMovCallMenu','renderMovCallRoot'], limpa:['admCleanupMenu','renderCleanupMenu'], familias:['admFamiliasMenu','renderFamiliasMenu'], feedbackservidor:['admServerFeedbackMenu','renderServerFeedbackMenu'], freefire:['admFreeFireMenu','renderFreeFireMenu'], bingo:['admBingoMenu','renderBingoMenu'], denuncias:['admDenunciasMenu','renderDenunciasMenu'], parcerias:['admPartnershipsMenu','renderPartnershipsMenu'], social:['socialAdminButtons','renderSocialAdmin'], submundo:['admSubmundoMenu','renderSubmundoMenu'], radio24h:['admRadioMenu','renderRadioMenu'], sorteios:['giveawayAdminButtons','renderGiveawayAdmin'], subidamembros:['../../memberRise/panel','renderMemberRise'],
  };
  const saved = new Map(); let reached;
  function stub(file, exports) { const id = require.resolve(file); if(!saved.has(id))saved.set(id,require.cache[id]); require.cache[id]={id,filename:id,loaded:true,exports:{...(require.cache[id]?.exports??{}),...exports}}; }
  for (const [value,[file,fn]] of Object.entries(mappings)) {
    const target=file.startsWith('../../') ? '../app/'+file.slice(6) : '../app/components/buttons/'+file;
    stub(target,{[fn]:async()=>{reached=value;}});
  }
  stub('../app/social-experience/interactions',{showAdmin:async()=>{reached='dinamicassociais';}});
  stub('../app/components/buttons/admConfigMenu',{renderConfigMenu:async()=>{reached='configuracoes';},renderConfigDestination:async(i,action)=>{reached='cfg:'+action;}});
  const id=require.resolve('../app/components/selects/admSectionSelect'); const prior=require.cache[id]; delete require.cache[id];
  try {
    const handler=require(id).default; const {guild}=guildFixture(); let destinations=0;
    for(const [area,section] of Object.entries(ADM_SECTIONS)) for(const module of section.modules) {
      reached=undefined; await handler.execute(interaction(guild,'adm-section-select:'+area,[module.value]));
      assert.equal(reached,module.value); destinations++;
    }
    assert.equal(destinations,29);
    reached=undefined; await handler.execute(interaction(guild,'adm-section-select:sistema',['cfg:not-real'])); assert.equal(reached,undefined);
    reached=undefined; await handler.execute(interaction(guild,'adm-section-select:membros',['registro'],false)); assert.equal(reached,undefined);
  } finally { for(const [id,cache] of saved) { if(cache) require.cache[id]=cache; else delete require.cache[id]; } if(prior)require.cache[id]=prior;else delete require.cache[id]; }
});

test('current and legacy configuration selections open real read-only views without writing persistent settings', async () => {
  const {guild}=guildFixture(); const {renderConfigDestination}=require('../app/components/buttons/admConfigMenu'); const before=writes;
  for(const action of ['canais','autocargo','aparencia','padrao','embeds','notificacoes']) {
    const i=interaction(guild,'adm-section-select:sistema',['cfg:'+action]);
    await renderConfigDestination(i,action); const last=i.calls.at(-1); assert.ok(['update','editReply'].includes(last[0])); validatePayload(last[1]); assert.deepEqual(last[1].attachments,[]);
  }
  assert.equal(writes,before);
});

test('shared admin styling removes decorative title emojis while public baseEmbed is untouched', async () => {
  const {guild}=guildFixture(); const a=adminEmbed(guild,'seguranca').setTitle('🛡️ Proteção').toJSON();
  assert.equal(a.title,'Proteção'); assert.equal(a.color,BLACKOUT_RED); assert.ok(a.author.name.startsWith('BLACKOUT'));
  const p=await require('../app/utils/embeds').baseEmbed(guild); assert.equal(p.toJSON().color,0);
});

test('moved modules return to their new parent without creating or resetting configuration', async () => {
  const cases = [
    ['components/selects/registrationAdminNavSelect','registration-admin-nav',['back'],'Entrada e evolução'],
    ['components/buttons/memberRiseButtons','member-rise:back',[],'Entrada e evolução'],
    ['components/selects/bingoAdminSelect','bingo-admin-nav',['back'],'Jogos e eventos'],
    ['components/selects/ffAdminNavSelect','ff-admin-nav',['back'],'Jogos e eventos'],
    ['components/buttons/giveawayAdminButtons','giveaway-admin:back',[],'Jogos e eventos'],
  ];
  const before=writes;
  for (const [file,id,values,title] of cases) {
    const {guild}=guildFixture();const i=interaction(guild,id,values);
    await require('../app/'+file).default.execute(i);
    assert.equal(i.calls[0][0],'update',file);validatePayload(i.calls[0][1]);
    assert.equal(i.calls[0][1].embeds[0].toJSON().title,title,file);
  }
  assert.equal(writes,before);
});
