const {test,beforeEach}=require('node:test');const assert=require('node:assert/strict');const {Collection,EmbedBuilder,ChannelType,PermissionFlagsBits,AuditLogEvent}=require('discord.js');
const rows=new Map(),configs=new Map(),guilds=new Map(),sent=[],audits=[],writes=[];let seq=1000;
const clone=v=>structuredClone(v);
const prisma={serverLogSettings:{findUnique:async({where})=>clone(rows.get(where.guildId)??null),upsert:async({where,create,update})=>{writes.push([where.guildId,clone(update)]);rows.set(where.guildId,{...(rows.get(where.guildId)??create),...update});return clone(rows.get(where.guildId))}},guildConfig:{findUnique:async({where})=>configs.get(where.guildId)},adminLog:{create:async({data})=>{audits.push(data);return data},findMany:async()=>[]},familyConfig:{findUnique:async({where})=>({logChannelId:configs.get(where.guildId)?.familyChannelId})},botAdmin:{findMany:async()=>[]}};
const db=require.resolve('../app/database/prisma');require.cache[db]={id:db,filename:db,loaded:true,exports:{prisma}};
const config=require('../app/logging/config'),delivery=require('../app/logging/delivery'),events=require('../app/logging/events');
const button=require('../app/components/buttons/logCenter').default,select=require('../app/components/selects/logCenterSelect').default,modal=require('../app/components/modals/logCenterModal').default;
const panel=require('../app/logging/panel');
beforeEach(async()=>{await delivery.flushLogs();config.clearLogSettingsCache()});
function fixture(){
 const id=String(100000000000000000n+BigInt(++seq)),actorId=String(BigInt(id)+100000n),botId='900000000000000001';
 const client={user:{id:botId,displayAvatarURL:()=> 'https://example.com/avatar.png'},guilds:{fetch:async id=>guilds.get(id)||Promise.reject(Error('Unknown guild'))},application:{emojis:{cache:new Collection()}}};
 const g={id,name:'Comunidade '+seq,client,channels:{cache:new Collection(),fetch:async id=>g.channels.cache.get(id)||Promise.reject(Error('Unknown channel'))},roles:{cache:new Collection()},members:{cache:new Collection()},admin:true,botAllowed:true};
 const member={id:actorId,guild:g,user:{bot:false},roles:{cache:new Collection()},permissions:{has:()=>g.admin}};g.actorId=actorId;
 g.members.me={permissions:{has:()=>g.botAllowed}};g.members.fetchMe=async()=>g.members.me;g.members.fetch=async arg=>{const uid=typeof arg==='string'?arg:arg.user;if(uid!==actorId&&!g.allowAuthorizer)throw Error('Unknown member');return member};
 guilds.set(id,g);configs.set(id,{guildId:id,embedColor:'000000',embedAuthor:null,embedFooter:null,embedThumbnail:null});
 function channel(offset=1,type=ChannelType.GuildText){const cid=String(BigInt(id)+BigInt(offset));const c={id:cid,guildId:id,guild:g,name:'logs-'+offset,type,permissionsFor:()=>({has:()=>g.botAllowed}),send:async p=>{sent.push({guildId:id,channelId:cid,payload:p});return{id:'sent'}}};g.channels.cache.set(cid,c);return c}
 g.makeChannel=channel;g.general=channel();configs.get(id).logChannelId=g.general.id;return g;
}
const embed=()=>new EmbedBuilder().setTitle('Registro de teste').setDescription('Conteúdo de exemplo');
async function settings(g,patch){return config.saveLogSettings(g.id,patch)}
async function enable(g,...keys){const s=await config.readLogSettings(g.id);return settings(g,{eventsJson:JSON.stringify({...s.events,...Object.fromEntries(keys.map(k=>[k,true]))})})}
async function external(source,target){target.allowAuthorizer=true;await settings(source,{externalGuildId:target.id,externalChannelId:target.general.id,externalAuthorizedBy:source.actorId})}
function interaction(g,id,{values=[],fields={}}={}){const calls=[];const i={guild:g,customId:id,user:{id:g.actorId},values,fields:{getTextInputValue:k=>fields[k]??''},deferred:false,replied:false,isFromMessage:()=>true,isStringSelectMenu:()=>true,isChannelSelectMenu:()=>true,isRoleSelectMenu:()=>true,async reply(p){calls.push(['reply',p]);i.replied=true},async followUp(p){calls.push(['followUp',p])},async update(p){calls.push(['update',p]);i.replied=true},async deferUpdate(){calls.push(['deferUpdate']);i.deferred=true},async editReply(p){calls.push(['editReply',p])},async showModal(p){calls.push(['modal',p])},calls};return i}
function result(i){return i.calls.filter(([m,p])=>p?.embeds&&['editReply','update'].includes(m)).at(-1)?.[1]}
function valid(p){assert.ok(p);assert.ok(p.components.length<=5);for(const e of p.embeds){e.toJSON();assert.ok(e.length<=6000)}for(const r of p.components){const row=r.toJSON();assert.ok(row.components.length<=5);for(const c of row.components){assert.ok(c.custom_id.length<=100);if(c.options)assert.ok(c.options.length<=25)}}return p}
function last(){return sent.at(-1).payload.embeds[0].toJSON()}
function message(g,extra={}){return {id:String(BigInt(g.id)+500n),guild:g,channelId:g.general.id,channel:g.general,author:{id:g.actorId,bot:false},member:g.members.cache.get(g.actorId),partial:false,content:'Conteúdo anterior',attachments:new Collection(),...extra}}

test('legacy defaults keep existing categories and entry/exit, while all new high-volume events start disabled',async()=>{
 const g=fixture(),s=await config.readLogSettings(g.id);assert.equal(rows.has(g.id),false);assert.equal(s.deliveryMode,'LOCAL');assert.equal(s.events['member.join'],true);assert.equal(s.events['system.actions'],true);for(const key of ['voice.join','message.edit','message.delete','message.bulk','channel.create'])assert.equal(s.events[key],false);
 const before=sent.length;await delivery.deliverLog(g,'message.delete',embed());assert.equal(sent.length,before);await delivery.deliverLog(g,'system.actions',embed());assert.equal(sent.length,before+1);
});
test('routing supports local, external-only and both without sending external-only logs locally',async()=>{
 const g=fixture(),target=fixture();await external(g,target);for(const [mode,count,expected]of [['LOCAL',1,[g.id]],['EXTERNAL',1,[target.id]],['BOTH',2,[g.id,target.id]]]){await settings(g,{deliveryMode:mode});const start=sent.length;const r=await delivery.deliverLog(g,'system.actions',embed());assert.equal(r.sent,count);assert.deepEqual(sent.slice(start).map(s=>s.guildId),expected);for(const m of sent.slice(start)){assert.deepEqual(m.payload.allowedMentions,{parse:[]});assert.match(m.payload.embeds[0].toJSON().author.name,new RegExp(g.id))}}
});
test('external destination requires the bot, authorized destination administrator and writable channel',async()=>{
 const g=fixture(),target=fixture();const original=rows.get(g.id);target.admin=false;let i=interaction(g,'logs-center-modal:external',{fields:{guild:target.id,channel:target.general.id}});await modal.execute(i);assert.equal(rows.get(g.id),original);assert.match(i.calls.at(-1)[1].content,/responsável/);
 target.admin=true;target.allowAuthorizer=true;target.botAllowed=false;i=interaction(g,'logs-center-modal:external',{fields:{guild:target.id,channel:target.general.id}});await modal.execute(i);assert.equal(rows.get(g.id),original);assert.match(i.calls.at(-1)[1].content,/bot precisa/);
 target.botAllowed=true;i=interaction(g,'logs-center-modal:external',{fields:{guild:target.id,channel:target.general.id}});await modal.execute(i);valid(result(i));assert.equal(rows.get(g.id).externalAuthorizedBy,g.actorId);assert.equal((await config.readLogSettings(g.id)).deliveryMode,'LOCAL');
});
test('external authorization is rechecked at delivery and revoked access never falls back to the source',async()=>{
 const g=fixture(),target=fixture();await external(g,target);await settings(g,{deliveryMode:'EXTERNAL'});target.admin=false;const start=sent.length;const r=await delivery.deliverLog(g,'system.actions',embed());assert.equal(r.sent,0);assert.ok(r.errors.length);assert.equal(sent.length,start);assert.ok(delivery.logHealth(g.id).failed>0);
});
test('one failed destination in both mode does not prevent delivery to the other destination',async()=>{
 const g=fixture(),target=fixture();await external(g,target);await settings(g,{deliveryMode:'BOTH'});g.botAllowed=false;const r=await delivery.deliverLog(g,'system.actions',embed());assert.equal(r.sent,1);assert.equal(sent.at(-1).guildId,target.id);assert.ok(r.errors.length);
});
test('legacy category fallback is preserved and clearing a new override explicitly uses the general channel',async()=>{
 const g=fixture(),old=g.makeChannel(2),specific=g.makeChannel(3);configs.get(g.id).moderationLogChannelId=old.id;let s=await config.readLogSettings(g.id);assert.equal((await delivery.resolveLocalLogChannel(g,'moderation',s)).id,old.id);
 await settings(g,{localChannelsJson:JSON.stringify({moderation:specific.id})});s=await config.readLogSettings(g.id);assert.equal((await delivery.resolveLocalLogChannel(g,'moderation',s)).id,specific.id);await settings(g,{localChannelsJson:'{"moderation":null}'});s=await config.readLogSettings(g.id);assert.equal((await delivery.resolveLocalLogChannel(g,'moderation',s)).id,g.general.id);
});
test('per-category external override is validated against the selected external guild',async()=>{
 const g=fixture(),target=fixture(),third=fixture();await external(g,target);let i=interaction(g,'logs-center-modal:channel:messages',{fields:{channel:third.general.id}});await modal.execute(i);assert.match(i.calls.at(-1)[1].content,/excluído|inacessível/);assert.equal(config.objectJson(rows.get(g.id).externalChannelsJson).messages,undefined);
 const specific=target.makeChannel(3);i=interaction(g,'logs-center-modal:channel:messages',{fields:{channel:specific.id}});await modal.execute(i);assert.equal(config.objectJson(rows.get(g.id).externalChannelsJson).messages,specific.id);await settings(g,{deliveryMode:'EXTERNAL'});await enable(g,'message.delete');await delivery.deliverLog(g,'message.delete',embed());assert.equal(sent.at(-1).channelId,specific.id);
});
test('event selections and mode changes refresh the same originating panel and remain guild scoped',async()=>{
 const g=fixture(),other=fixture();const i=interaction(g,'logs-center-select:events:voice',{values:['voice.join','voice.move']});await select.execute(i);valid(result(i));assert.equal(i.calls[0][0],'deferUpdate');assert.equal((await config.readLogSettings(g.id)).events['voice.join'],true);assert.equal((await config.readLogSettings(other.id)).events['voice.join'],false);
 const invalid=interaction(g,'logs-center-select:events:voice',{values:['message.delete']});const before=writes.length;await select.execute(invalid);assert.equal(writes.length,before);
 const mode=interaction(g,'logs-center-select:mode',{values:['EXTERNAL']});await select.execute(mode);assert.equal((await config.readLogSettings(g.id)).deliveryMode,'LOCAL');assert.ok(mode.calls.some(([m])=>m==='followUp'));
});
test('ignored bots, this application, roles, channels and nested categories suppress forwarding',async()=>{
 const g=fixture(),category=g.makeChannel(5,ChannelType.GuildCategory),child=g.makeChannel(6);child.parentId=category.id;
 await settings(g,{ignoredChannelIds:JSON.stringify([category.id]),ignoredRoleIds:JSON.stringify(['100000000000000777'])});const before=sent.length;
 for(const context of [{bot:true},{userId:g.client.user.id},{roleIds:['100000000000000777']},{channelIds:[child.id]}])await delivery.deliverLog(g,'system.actions',embed(),context);
 assert.equal(sent.length,before);await settings(g,{ignoreBots:false});await delivery.deliverLog(g,'system.actions',embed(),{bot:true,userId:'100000000000000888'});assert.equal(sent.length,before+1);await delivery.deliverLog(g,'system.actions',embed(),{bot:true,userId:g.client.user.id});assert.equal(sent.length,before+1);
});
test('filter selections reject foreign guild channels and roles without changing current settings',async()=>{
 const g=fixture(),other=fixture();for(const [id,values]of [['ignored-channels',[other.general.id]],['ignored-roles',['unknown-role']]]){const i=interaction(g,'logs-center-select:'+id,{values});const before=writes.length;await select.execute(i);assert.equal(writes.length,before);assert.ok(i.calls.some(([m])=>m==='followUp'))}
});
test('voice logging is independent from MOV CALL and distinguishes join, move, leave and audio states',async()=>{
 const g=fixture();await enable(g,'voice.join','voice.move','voice.leave','voice.state');const member={id:g.actorId,user:{bot:false},roles:{cache:new Collection()}};const old={id:g.actorId,guild:g,member,channelId:null},joined={...old,channelId:g.general.id,selfMute:false,selfDeaf:false,serverMute:false,serverDeaf:false};
 const start=sent.length;await events.voiceLog(old,joined);await events.voiceLog(joined,{...joined,channelId:g.makeChannel(5,ChannelType.GuildVoice).id});await events.voiceLog(joined,{...joined,channelId:null});await events.voiceLog(joined,{...joined,selfMute:true});await delivery.flushLogs();assert.equal(sent.length,start+4);assert.deepEqual(sent.slice(start).map(s=>s.payload.embeds[0].toJSON().title),['Entrada em call','Troca de call','Saída de call','Silêncio e áudio em call']);assert.match(last().fields.find(f=>f.name==='Responsável').value,/não identificado/);
});
test('message edit records before and after, ignores embed-only updates and never invents uncached old content',async()=>{
 const g=fixture();await enable(g,'message.edit');let old=message(g),next={...old,content:'Conteúdo novo'};await events.messageEdited(old,next);await delivery.flushLogs();assert.equal(last().fields.find(f=>f.name==='Antes').value,'Conteúdo anterior');assert.equal(last().fields.find(f=>f.name==='Depois').value,'Conteúdo novo');
 const before=sent.length;await events.messageEdited(next,{...next});await delivery.flushLogs();assert.equal(sent.length,before);await events.messageEdited({...old,partial:true,content:null},next);await delivery.flushLogs();assert.match(last().fields.find(f=>f.name==='Antes').value,/indisponível/);
});
test('deleted uncached messages report missing content and never attribute deletion to their author',async()=>{
 const g=fixture();await enable(g,'message.delete');await events.messageDeleted(message(g,{partial:true,content:null}));await delivery.flushLogs();assert.match(last().fields.find(f=>f.name==='Conteúdo disponível').value,/Indisponível/);assert.match(last().fields.find(f=>f.name==='Responsável pela exclusão').value,/Não identificado/);
});
test('bulk deletion produces one bounded summary and respects ignored bots and channels',async()=>{
 const g=fixture();await enable(g,'message.bulk');const messages=new Collection();for(let n=0;n<100;n++)messages.set(String(n),message(g,{id:String(n),content:'x'.repeat(300)}));let before=sent.length;await events.messagesDeleted(messages,g.general);await delivery.flushLogs();assert.equal(sent.length,before+1);assert.ok(sent.at(-1).payload.embeds[0].length<=6000);assert.match(last().fields.find(f=>f.name==='Mensagens excluídas').value,/100/);
 await settings(g,{ignoredChannelIds:JSON.stringify([g.general.id])});before=sent.length;await events.messagesDeleted(messages,g.general);await delivery.flushLogs();assert.equal(sent.length,before);
});
test('member changes and channel/role permission changes log actual differences only',async()=>{
 const g=fixture();await enable(g,'member.nickname','member.roles','channel.update','role.update');const original={id:g.actorId,guild:g,nickname:'Antes',roles:{cache:new Collection()},user:{bot:false}},next={...original,nickname:'Depois',roles:{cache:new Collection([['100000000000000123',{id:'100000000000000123'}]])}};
 await events.memberChanged(original,next);const ch={id:g.general.id,guild:g,name:'antes',permissions:{},permissionOverwrites:{cache:new Collection()}};await events.channelChanged('update',ch,{...ch,name:'depois'});const role={id:'100000000000000555',guild:g,name:'Equipe',permissions:{bitfield:0n}};await events.roleChanged('update',role,{...role,permissions:{bitfield:8n}});await delivery.flushLogs();assert.equal(last().title,'Cargo ou permissões alterados');assert.match(last().fields.find(f=>f.name==='Alterações').value,/Administrador/);const before=sent.length;await events.channelChanged('update',ch,{...ch});await delivery.flushLogs();assert.equal(sent.length,before);
});
test('native ban audit identifies a confirmed executor and skips this bot to avoid duplicate sanctions',async()=>{
 const g=fixture();await enable(g,'moderation.ban');const entry={id:'100000000000000444',action:AuditLogEvent.MemberBanAdd,executorId:g.actorId,targetId:'100000000000000888',reason:'Motivo'};const before=sent.length;await events.auditEntry(entry,g);await events.auditEntry({...entry,executorId:g.client.user.id},g);await delivery.flushLogs();assert.equal(sent.length,before+1);assert.match(last().fields.find(f=>f.name==='Responsável confirmado pela auditoria').value,new RegExp(g.actorId));
});
test('AdminLog history remains saved when channel forwarding is disabled, and family custom channels are preserved locally',async()=>{
 const g=fixture();await settings(g,{eventsJson:'{"system.actions":false}'});const admin=require('../app/utils/adminLog');const before=sent.length,count=audits.length;await admin.logAdminAction({guild:g,actorId:g.actorId,action:'CONFIG_CHANGED',details:'Alteração'});await delivery.flushLogs();assert.equal(audits.length,count+1);assert.equal(sent.length,before);
 const family=g.makeChannel(5);configs.get(g.id).familyChannelId=family.id;await settings(g,{eventsJson:'{"system.actions":true}'});await admin.logAdminAction({guild:g,actorId:g.actorId,action:'FAMILY_CREATED',details:'Família'});await delivery.flushLogs();assert.equal(sent.at(-1).channelId,family.id);assert.equal(last().title,'LOG DE FAMÍLIAS');
});
test('external-only family logs do not bypass the selected delivery mode',async()=>{
 const g=fixture(),target=fixture();await external(g,target);await settings(g,{deliveryMode:'EXTERNAL'});configs.get(g.id).familyChannelId=g.makeChannel(5).id;const before=sent.length;await require('../app/utils/adminLog').logAdminAction({guild:g,actorId:g.actorId,action:'FAMILY_CREATED'});await delivery.flushLogs();assert.equal(sent.length,before+1);assert.equal(sent.at(-1).guildId,target.id);
});
test('test delivery works even with all events disabled and reports failures in the originating panel',async()=>{
 const g=fixture();await settings(g,{eventsJson:JSON.stringify(Object.fromEntries(Object.keys(config.LOG_EVENTS).map(k=>[k,false])))});let i=interaction(g,'logs-center:test'),before=sent.length;await button.execute(i);valid(result(i));assert.equal(sent.length,before+1);assert.match(result(i).embeds[0].toJSON().fields.at(-1).value,/1 destinos/);
 const target=fixture();await external(g,target);const externalTest=interaction(g,'logs-center:test-external');before=sent.length;await button.execute(externalTest);assert.equal(sent.length,before+1);assert.equal(sent.at(-1).guildId,target.id);assert.equal((await config.readLogSettings(g.id)).deliveryMode,'LOCAL');
 g.botAllowed=false;i=interaction(g,'logs-center:test');await button.execute(i);assert.match(result(i).embeds[0].toJSON().fields.at(-1).value,/0 destinos/);
});
test('all central views remain within native Discord limits and require administration for mutations',async()=>{
 const g=fixture();for(const fn of [i=>panel.renderLogHome(i),i=>panel.renderLogEvents(i),...Object.keys(config.LOG_GROUPS).map(group=>i=>panel.renderLogEvents(i,group)),i=>panel.renderLogDestination(i),i=>panel.renderLogOrganization(i),i=>panel.renderLogOrganization(i,'local'),i=>panel.renderLogOrganization(i,'external'),i=>panel.renderLocalGroup(i,'messages'),i=>panel.renderLogFilters(i),i=>panel.renderLogDiagnostic(i)]){const i=interaction(g,'');await fn(i);valid(result(i))}
 g.admin=false;let before=writes.length;const i=interaction(g,'logs-center:toggle-bots');await button.execute(i);assert.equal(writes.length,before);assert.match(i.calls.at(-1)[1].content,/permissão/);
});
test('the bounded delivery queue records overflow instead of growing without limit',async()=>{
 const g=fixture();let unlock;g.general.send=async()=>new Promise(resolve=>{unlock=resolve});for(let n=0;n<120;n++)await delivery.emitLog(g,'system.actions',embed());assert.ok(delivery.logHealth(g.id).dropped>0);
 g.general.send=async()=>({});if(unlock)unlock({});await delivery.flushLogs();
});

test('revoked source access or source membership stops external forwarding until a new administrator configures it',async()=>{
 for(const revoke of [g=>g.admin=false,g=>g.members.fetch=async()=>{throw Error('Left source')}]){
 const g=fixture(),target=fixture();await external(g,target);await settings(g,{deliveryMode:'EXTERNAL'});revoke(g);const start=sent.length;const result=await delivery.deliverLog(g,'system.actions',embed());assert.equal(result.sent,0);assert.equal(sent.length,start);assert.match(result.errors.join(' '),/origem/);
 }
});
test('bulk deletion with ignored roles retains one summary for allowed known authors and omits ignored or unknown roles',async()=>{
 const g=fixture();await enable(g,'message.bulk');const ignoredRole='100000000000000777';await settings(g,{ignoredRoleIds:JSON.stringify([ignoredRole])});
 const allowed={id:g.actorId,user:{bot:false},roles:{cache:new Collection()}},ignored={id:'100000000000000888',user:{bot:false},roles:{cache:new Collection([[ignoredRole,{id:ignoredRole}]])}};
 const messages=new Collection([['allowed',message(g,{id:'allowed',member:allowed,content:'Permitida'})],['ignored',message(g,{id:'ignored',member:ignored,author:{id:ignored.id,bot:false},content:'Conteúdo ignorado'})],['unknown',message(g,{id:'unknown',member:null,author:{id:'100000000000000999',bot:false},content:'Autor sem cargos disponíveis'})]]);
 const before=sent.length;await events.messagesDeleted(messages,g.general);await delivery.flushLogs();assert.equal(sent.length,before+1);assert.match(last().fields.find(f=>f.name==='Mensagens excluídas').value,/1 após os filtros/);const summary=last().fields.find(f=>f.name==='Amostra do conteúdo disponível').value;assert.match(summary,/Permitida/);assert.ok(!summary.includes('Conteúdo ignorado'));assert.ok(!summary.includes('Autor sem cargos'));
});

test('refined central exposes four primary tasks, hides inactive external setup and resolves active destination names',async()=>{
 const g=fixture();let i=interaction(g,'');await panel.renderLogHome(i);let p=valid(result(i));const primary=p.components.slice(0,2).flatMap(r=>r.toJSON().components).map(c=>c.label);assert.deepEqual(primary,['O que registrar','Onde enviar','O que ignorar','Testar envio']);assert.equal(p.embeds[0].toJSON().fields.length,2);assert.match(p.embeds[0].toJSON().fields[0].value,new RegExp(g.name));assert.ok(!JSON.stringify(p.embeds[0].toJSON()).includes('Não configurado'));
 const target=fixture();await external(g,target);await settings(g,{deliveryMode:'EXTERNAL'});i=interaction(g,'');await panel.renderLogDestination(i);p=valid(result(i));const display=p.embeds[0].toJSON().fields.map(f=>f.value).join(' ');assert.ok(display.includes(target.name));assert.ok(display.includes('#'+target.general.name));assert.ok(!display.includes(target.id));i=interaction(g,'');await panel.renderLogHelp(i,'destination');assert.ok(JSON.stringify(result(i).embeds[0].toJSON()).includes(target.id));
});
test('Sistemas do bot groups reintegration without merging stored event flags or category destinations',async()=>{
 const g=fixture();let i=interaction(g,'');await panel.renderLogEvents(i);const choices=result(i).components[0].toJSON().components[0].options;assert.equal(choices.length,6);assert.ok(choices.some(o=>o.value==='bot'));assert.ok(!choices.some(o=>o.value==='reintegration'));
 i=interaction(g,'logs-center-select:events:bot',{values:['reintegration.actions']});await select.execute(i);valid(result(i));let s=await config.readLogSettings(g.id);assert.equal(s.events['system.actions'],false);assert.equal(s.events['reintegration.actions'],true);
 i=interaction(g,'logs-center-select:events:system',{values:['system.actions']});await select.execute(i);s=await config.readLogSettings(g.id);assert.equal(s.events['system.actions'],true);assert.equal(s.events['reintegration.actions'],true);
 i=interaction(g,'logs-center-select:channel-group:local',{values:['bot']});await select.execute(i);valid(result(i));assert.deepEqual(result(i).components[0].toJSON().components[0].options.map(o=>o.value),['system','reintegration']);
 const own=g.makeChannel(5);i=interaction(g,'logs-center-select:local-channel:reintegration',{values:[own.id]});await select.execute(i);s=await config.readLogSettings(g.id);assert.equal(s.localChannels.reintegration,own.id);assert.equal(s.localChannels.system,undefined);
});
test('category selectors and thumbnails use the existing approved application PNGs',async()=>{
 const g=fixture();const {ADM_EMOJI_NAMES}=require('../app/utils/admEmojis');for(const [area,name]of Object.entries(ADM_EMOJI_NAMES)){const id=String(100000000000000010n+BigInt(g.client.application.emojis.cache.size));g.client.application.emojis.cache.set(id,{id,name})}
 let i=interaction(g,'');await panel.renderLogEvents(i);const options=result(i).components[0].toJSON().components[0].options;assert.ok(options.every(o=>o.emoji?.id));
 for(const [group,area]of [['voice','atendimento'],['messages','entretenimento'],['members','membros']]){i=interaction(g,'');await panel.renderLogEvents(i,group);const expected=g.client.application.emojis.cache.find(e=>e.name===ADM_EMOJI_NAMES[area]).id;assert.ok(result(i).embeds[0].toJSON().thumbnail.url.includes(expected))}
});
test('module shortcuts open real production panels with a return to logs and do not rewrite module settings',async()=>{
 const g=fixture(),moduleReads=[];prisma.ticketConfig={upsert:async({where,update})=>{assert.deepEqual(update,{});moduleReads.push(['tickets',where.guildId]);return{guildId:where.guildId}}};prisma.registrationConfig={upsert:async({where,update})=>{assert.deepEqual(update,{});moduleReads.push(['registration',where.guildId]);return{guildId:where.guildId}}};
 const before=writes.length;for(const [key,title]of [['tickets','Canais dos Tickets'],['ticket-external','Relatórios Externos'],['registration','Logs do Registro']]){const i=interaction(g,'logs-center:module:'+key);await button.execute(i);const p=valid(result(i));assert.equal(p.embeds[0].toJSON().title,title);assert.ok(p.components.flatMap(r=>r.toJSON().components).some(c=>c.custom_id==='logs-center:modules'));assert.equal(i.calls[0][0],'deferUpdate')}
 assert.equal(writes.length,before);assert.ok(moduleReads.every(([,id])=>id===g.id));
});
test('help and permission details stay reachable without cluttering basic testing and ignoring screens',async()=>{
 const g=fixture();let i=interaction(g,'logs-center:diagnostic');await button.execute(i);assert.equal(result(i).embeds[0].toJSON().title,'Testar envio');assert.ok(!JSON.stringify(result(i).embeds[0].toJSON()).includes('Message Content Intent'));
 i=interaction(g,'logs-center:diagnostic-details');await button.execute(i);assert.match(JSON.stringify(result(i).embeds[0].toJSON()),/Message Content Intent/);
 i=interaction(g,'logs-center:help:filters');await button.execute(i);valid(result(i));assert.equal(result(i).components[0].toJSON().components[0].custom_id,'logs-center:filters');
});
