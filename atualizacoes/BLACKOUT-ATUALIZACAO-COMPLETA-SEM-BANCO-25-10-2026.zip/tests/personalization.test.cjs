const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const {Collection,ChannelType,GuildMemberManager}=require('discord.js');
const configs=new Map(),records=new Map(),profiles=new Map(),channels=new Map();
const mutations=[];let globalChanges=0,sends=0,edits=0,fetchError=null;
function record(id,guildId,extra={}){return {id,guildId,name:'Boas-vindas',title:'Bem-vindo!',description:'Este é o texto da comunidade.',author:null,footer:null,color:'D71935',imageUrl:null,thumbnailUrl:null,showTimestamp:false,destinationChannelId:null,publishedMessageId:null,publishedChannelId:null,publishedPayloadHash:null,buttons:[],...extra};}
const clone=value=>structuredClone(value);
const prisma={serverLogSettings:{findUnique:async()=>null,upsert:async()=>({})},
 botAdmin:{findMany:async()=>[]},
 guildConfig:{findUnique:async({where})=>clone(configs.get(where.guildId)),create:async({data})=>{throw new Error('Unexpected missing guild configuration')},update:async({where,data})=>{mutations.push(['config',where.guildId,clone(data)]);Object.assign(configs.get(where.guildId),data);return clone(configs.get(where.guildId));}},
 customEmbed:{findFirst:async({where})=>{const r=records.get(where.id);return r?.guildId===where.guildId?clone(r):null;},findMany:async({where,skip=0,take=25})=>[...records.values()].filter(r=>r.guildId===where.guildId).slice(skip,skip+take).map(clone),count:async({where})=>[...records.values()].filter(r=>r.guildId===where.guildId).length,
 update:async({where,data})=>{mutations.push(['embed',where.id,clone(data)]);Object.assign(records.get(where.id),data);return clone(records.get(where.id));},create:async({data})=>{const r=record('new-'+records.size,data.guildId,{...data,buttons:[]});records.set(r.id,r);return clone(r);},delete:async({where})=>{records.delete(where.id);}},
 customEmbedButton:{count:async({where})=>records.get(where.embedId).buttons.length,create:async({data})=>{const b={id:'button-'+Math.random(),...data};records.get(data.embedId).buttons.push(b);return clone(b);},update:async({where,data})=>{for(const r of records.values()){const b=r.buttons.find(b=>b.id===where.id);if(b){Object.assign(b,data);return clone(b);}}}},
 adminLog:{create:async()=>({})},
};
const db=require.resolve('../app/database/prisma');require.cache[db]={id:db,filename:db,loaded:true,exports:{prisma}};
const {buildAppearancePayload,buildDefaultPatternPayload}=require('../app/components/buttons/admConfigMenu');
const {publicationHash,publicationState}=require('../app/utils/embedPublication');
const {buildEmbedEditorPayload}=require('../app/components/buttons/admEmbedV2Menu');
const {ADM_SECTIONS}=require('../app/utils/admPanel');
function fixture(id='100000000000000101'){
 configs.set(id,{guildId:id,embedColor:'000000',embedAuthor:null,embedFooter:null,embedThumbnail:null,notifyDm:true,moderationNotifyDm:null,reintegrationNotifyDm:null,notifyPublicWarns:false,reportsChannelId:null,logChannelId:null,autoRoleEnabled:false,autoRoleIds:null});
 profiles.set(id,{name:'BLACKOUT',avatar:null,banner:null});
 const global={username:'BASE',setAvatar:async()=>{globalChanges++;throw new Error('Global avatar forbidden')},setBanner:async()=>{globalChanges++;throw new Error('Global banner forbidden')},displayAvatarURL:()=> 'https://images.example/default.png'};
 const member=(p)=>({displayName:p.name,avatarURL:()=>p.avatar,bannerURL:()=>p.banner,displayAvatarURL:()=>p.avatar||'https://images.example/default.png',displayBannerURL:()=>p.banner,permissions:{has:()=>true}});
 const guild={id,name:'Comunidade '+id,client:{user:global,application:{emojis:{cache:new Collection()}}},roles:{cache:new Collection()},channels:{cache:new Collection(),fetch:async id=>channels.get(id)||null},members:{me:member({...profiles.get(id)}),fetchMe:async()=>member({...profiles.get(id)}),fetch:async()=>({permissions:{has:()=>true},roles:{cache:new Collection()}})}};
 guild.members.editMe=async data=>{mutations.push(['profile',id,clone(data)]);const p=profiles.get(id);if(data.nick)p.name=data.nick;if(data.avatar)p.avatar=data.avatar;if(data.banner)p.banner=data.banner;return member({...p});};
 return guild;
}
function channel(guild,id='200000000000000001',allowed=true){
 const ch={id,guildId:guild.id,name:'comunicados',type:ChannelType.GuildText,permissionsFor:()=>({has:()=>allowed}),messages:{fetch:async()=>{if(fetchError)throw fetchError;return{id:'public-message',edit:async payload=>{edits++;return payload}}}},send:async payload=>{sends++;return{id:'new-public-message',payload}}};channels.set(id,ch);guild.channels.cache.set(id,ch);return ch;
}
function interaction(guild,customId,{fields={},values=[],kind='modal',authorized=true}={}){
 const calls=[];const i={guild,client:guild.client,user:{id:'300000000000000001',tag:'Cliente'},customId,values,fields:{getTextInputValue:k=>fields[k]??''},deferred:false,replied:false,isFromMessage:()=>true,isRoleSelectMenu:()=>kind==='role',isChannelSelectMenu:()=>kind==='channel',isStringSelectMenu:()=>kind==='select',
 async deferUpdate(){calls.push(['deferUpdate']);i.deferred=true},async update(p){calls.push(['update',p]);i.replied=true},async editReply(p){calls.push(['editReply',p]);},async reply(p){calls.push(['reply',p]);i.replied=true},async followUp(p){calls.push(['followUp',p]);},async showModal(p){calls.push(['modal',p]);},calls};
 guild.members.fetch=async()=>({guild,permissions:{has:()=>authorized},roles:{cache:new Collection()}});
 return i;
}
function lastPanel(i){const call=i.calls.filter(([m,p])=>['update','editReply'].includes(m)&&p?.embeds).at(-1);assert.ok(call,'Expected same-message panel refresh');return call[1];}
function validate(p){assert.ok(p.components.length<=5);for(const r of p.components){const j=r.toJSON();assert.ok(j.components.length<=5);for(const c of j.components)if(c.options)assert.ok(c.options.length<=25);}for(const e of p.embeds){const j=e.toJSON();assert.ok(e.length<=6000);assert.ok((j.title?.length??0)<=256);}return p;}

test('personalization has only local profile, message defaults and saved messages; entrance owns automatic roles',()=>{
 assert.deepEqual(ADM_SECTIONS.sistema.modules.map(m=>m.value),['cfg:aparencia','cfg:padrao','cfg:embeds']);
 assert.ok(ADM_SECTIONS.membros.modules.some(m=>m.value==='cfg:autocargo'));
 assert.ok(ADM_SECTIONS.seguranca.modules.some(m=>m.value==='logs'));
});
test('SDK guild-profile editing targets the selected guild member endpoint, never the global account',async()=>{
 const routes=[];const manager={guild:{id:'100000000000000101'},client:{rest:{patch:async(route,body)=>{routes.push([route,body]);return{nick:'Cliente'}}}},me:null,_add:data=>data};
 await GuildMemberManager.prototype.editMe.call(manager,{nick:'Cliente'});
 assert.equal(decodeURIComponent(routes[0][0]),'/guilds/100000000000000101/members/@me');assert.equal(routes[0][1].body.nick,'Cliente');
 const png=fs.readFileSync(require('../app/utils/admEmojis').adminIconFile('sistema'));
 await GuildMemberManager.prototype.editMe.call(manager,{avatar:png});
 manager.guild.id='100000000000000102';
 await GuildMemberManager.prototype.editMe.call(manager,{banner:png});
 assert.ok(routes[1][1].body.avatar.startsWith('data:'));assert.ok(routes[2][1].body.banner.startsWith('data:'));
 assert.equal(decodeURIComponent(routes[2][0]),'/guilds/100000000000000102/members/@me');
 assert.ok(routes.every(([route])=>route.startsWith('/guilds/')));
});
test('name, avatar and banner update immediately in the originating embed and never affect another guild',async()=>{
 const a=fixture(),b=fixture('100000000000000102');const originalB=clone(profiles.get(b.id));
 const handler=require('../app/components/modals/appearanceModal').default;
 for(const [action,value]of [['nickname','Bot da comunidade'],['avatar','https://images.example/avatar-a.png'],['banner','https://images.example/banner-a.png']]){
  const i=interaction(a,'appearance-modal:'+action,{fields:{value}});await handler.execute(i);const p=lastPanel(i),e=p.embeds[0].toJSON();
  assert.equal(i.calls[0][0],'deferUpdate');assert.equal(e.title,profiles.get(a.id).name);assert.equal(e.thumbnail.url,profiles.get(a.id).avatar||'https://images.example/default.png');if(profiles.get(a.id).banner)assert.equal(e.image.url,profiles.get(a.id).banner);
  assert.ok(!i.calls.some(([method])=>method==='reply'));validate(p);
 }
 assert.deepEqual(profiles.get(b.id),originalB);assert.equal(globalChanges,0);assert.equal(a.members.me.displayName,'BLACKOUT','Test intentionally keeps the gateway cache stale');
});
test('a failed local avatar update has no account-edit fallback',async()=>{
 const a=fixture();a.members.editMe=async()=>{throw new Error('Discord denied guild profile')};const i=interaction(a,'appearance-modal:avatar',{fields:{value:'https://images.example/fail.png'}});
 await require('../app/components/modals/appearanceModal').default.execute(i);assert.equal(globalChanges,0);assert.equal(profiles.get(a.id).avatar,null);assert.equal(i.calls.at(-1)[0],'followUp');
});
test('unauthorized users cannot change local identity or saved messages',async()=>{
 const a=fixture();const before=mutations.length;const i=interaction(a,'appearance-modal:nickname',{fields:{value:'Unauthorized'},authorized:false});await require('../app/components/modals/appearanceModal').default.execute(i);assert.equal(mutations.length,before);assert.equal(profiles.get(a.id).name,'BLACKOUT');
});
test('message default color, author, footer and thumbnail appear in the same embed after modal save',async()=>{
 const a=fixture(),b=fixture('100000000000000102');const i=interaction(a,'adm-modal:embed',{fields:{embedColor:'#AB1234',embedAuthor:'Nossa comunidade',embedFooter:'Rodapé local',embedThumbnail:'https://images.example/miniatura.png'}});
 await require('../app/components/modals/embedModal').default.execute(i);const e=lastPanel(i).embeds[0].toJSON();assert.equal(e.color,0xab1234);assert.equal(e.author.name,'Nossa comunidade');assert.equal(e.footer.text,'Rodapé local');assert.equal(e.thumbnail.url,'https://images.example/miniatura.png');assert.equal(configs.get(b.id).embedColor,'000000');assert.ok(!i.calls.some(([m])=>m==='reply'));
});
test('default visual removal clears author, footer and thumbnail in the refreshed preview',async()=>{
 const a=fixture();Object.assign(configs.get(a.id),{embedAuthor:'Old',embedFooter:'Old',embedThumbnail:'https://images.example/old.png'});
 const i=interaction(a,'adm-modal:embed',{fields:{embedColor:'000000'}});await require('../app/components/modals/embedModal').default.execute(i);const e=lastPanel(i).embeds[0].toJSON();assert.equal(e.color,0);assert.equal(e.author,undefined);assert.equal(e.footer,undefined);assert.equal(e.thumbnail,undefined);
});
test('automatic role selection refreshes the same panel and rejects unassignable roles without persisting them',async()=>{
 const a=fixture();a.roles.cache.set('400000000000000001',{id:'400000000000000001',name:'Membro',managed:false,editable:true});a.roles.cache.set('400000000000000002',{id:'400000000000000002',name:'Equipe',managed:false,editable:false});
 const h=require('../app/components/selects/autoRoleSelect').default;
 const valid=interaction(a,'auto-role-select:roles',{values:['400000000000000001'],kind:'role'});await h.execute(valid);assert.equal(configs.get(a.id).autoRoleIds,'400000000000000001');assert.ok(JSON.stringify(lastPanel(valid).embeds[0].toJSON()).includes('<@&400000000000000001>'));
 const before=mutations.length;const invalid=interaction(a,'auto-role-select:roles',{values:['400000000000000002'],kind:'role'});await h.execute(invalid);assert.equal(mutations.length,before);assert.equal(configs.get(a.id).autoRoleIds,'400000000000000001');assert.ok(JSON.stringify(lastPanel(invalid).embeds[0].toJSON()).includes('não foi salva'));
});
test('general logs are configured under audit and remain visible in the same selector after saving',async()=>{
 const a=fixture();const ch=channel(a);const i=interaction(a,'adm-logchannel-select:geral',{values:[ch.id],kind:'channel'});await require('../app/components/selects/logChannelSelects').default.execute(i);const p=lastPanel(i);assert.equal(configs.get(a.id).logChannelId,ch.id);assert.ok(JSON.stringify(p.embeds[0].toJSON()).includes('<#'+ch.id+'>'));assert.equal(p.components[0].toJSON().components[0].default_values[0].id,ch.id);
});
test('channel changes reject foreign guild channels and insufficient write permissions',async()=>{
 const a=fixture(),b=fixture('100000000000000102');const foreign=channel(b),blocked=channel(a,'200000000000000002',false);const before=mutations.length;
 for(const ch of [foreign,blocked]){const i=interaction(a,'adm-logchannel-select:geral',{values:[ch.id],kind:'channel'});await require('../app/components/selects/logChannelSelects').default.execute(i);assert.equal(i.calls.at(-1)[0],'reply');}
 assert.equal(mutations.length,before);assert.equal(configs.get(a.id).logChannelId,null);
});
test('module DM controls are independent per module and guild and inherit legacy preferences before first edit',async()=>{
 const a=fixture(),b=fixture('100000000000000102');const {moduleDm}=require('../app/components/buttons/admNotifications');assert.equal(moduleDm(configs.get(a.id),'moderacao'),true);assert.equal(moduleDm({...configs.get(a.id),notifyDm:false},'reintegracao'),false);
 const i=interaction(a,'adm-notify:moderacao:dm',{kind:'button'});await require('../app/components/buttons/admNotifications').default.execute(i);
 assert.equal(configs.get(a.id).moderationNotifyDm,false);assert.equal(moduleDm(configs.get(a.id),'reintegracao'),true);assert.equal(moduleDm(configs.get(b.id),'moderacao'),true);assert.ok(JSON.stringify(lastPanel(i).embeds[0].toJSON()).includes('Desativadas'));
});
test('public moderation notices cannot activate without a valid destination and clearing it disables notices',async()=>{
 const a=fixture();let i=interaction(a,'adm-notify:moderacao:public',{kind:'button'});await require('../app/components/buttons/admNotifications').default.execute(i);assert.equal(configs.get(a.id).notifyPublicWarns,false);
 const ch=channel(a);i=interaction(a,'notice-channel-select:moderacao',{values:[ch.id],kind:'channel'});await require('../app/components/selects/noticeChannelSelect').default.execute(i);assert.equal(configs.get(a.id).reportsChannelId,ch.id);
 i=interaction(a,'adm-notify:moderacao:public',{kind:'button'});await require('../app/components/buttons/admNotifications').default.execute(i);assert.equal(configs.get(a.id).notifyPublicWarns,true);
 i=interaction(a,'notice-channel-select:moderacao',{values:[],kind:'channel'});await require('../app/components/selects/noticeChannelSelect').default.execute(i);assert.equal(configs.get(a.id).notifyPublicWarns,false);assert.equal(configs.get(a.id).reportsChannelId,null);
});
test('saved message text and visual edits are visible directly and remain drafts until published',async()=>{
 const a=fixture();records.set('embed-a',record('embed-a',a.id));const h=require('../app/components/modals/admEmbedV2Modal').default;
 let i=interaction(a,'embedv2-modal:text:embed-a',{fields:{title:'Novo título',description:'Novo texto',author:'Comunidade',footer:'Novo rodapé'}});await h.execute(i);let p=lastPanel(i),e=p.embeds[0].toJSON();assert.equal(e.title,'Novo título');assert.equal(e.description,'Novo texto');assert.equal(e.author.name,'Comunidade');assert.equal(e.footer.text,'Novo rodapé');assert.ok(p.content.includes('Rascunho salvo'));
 i=interaction(a,'embedv2-modal:visual:embed-a',{fields:{color:'123ABC',image:'https://images.example/banner.png',thumbnail:'https://images.example/thumb.png',timestamp:'não'}});await h.execute(i);p=lastPanel(i);e=p.embeds[0].toJSON();assert.equal(e.color,0x123abc);assert.equal(e.image.url,'https://images.example/banner.png');assert.equal(e.thumbnail.url,'https://images.example/thumb.png');assert.equal(e.timestamp,undefined);validate(p);
});
test('destination selection verifies record ownership before writing across tenant boundaries',async()=>{
 const a=fixture(),b=fixture('100000000000000102');records.set('private-a',record('private-a',a.id));const ch=channel(b);const before=mutations.length;
 const i=interaction(b,'embedv2-channel:destination:private-a',{values:[ch.id],kind:'channel'});await require('../app/components/selects/admEmbedV2ChannelSelect').default.execute(i);assert.equal(mutations.length,before);assert.equal(records.get('private-a').destinationChannelId,null);assert.equal(i.calls.at(-1)[0],'reply');
});
test('up to 25 real link buttons have an in-place preview within the five-row Discord limit',async()=>{
 const a=fixture();const r=record('many-buttons',a.id,{buttons:Array.from({length:25},(_,n)=>({id:'btn-'+n,type:'LINK',label:'Abrir '+n,url:'https://example.com/'+n,position:n}))});
 for(const [page,count]of [[0,10],[1,10],[2,5]]){const p=validate(await buildEmbedEditorPayload(a,r,page));const links=p.components.flatMap(row=>row.toJSON().components).filter(c=>c.style===5);assert.equal(links.length,count);assert.ok(p.content.includes('25'));}
});
test('publishing changes the in-place state; later edits remain pending until the existing publication is updated',async()=>{
 sends=0;edits=0;fetchError=null;const a=fixture();const ch=channel(a);const r=record('publish-a',a.id,{destinationChannelId:ch.id});records.set(r.id,r);
 const h=require('../app/components/buttons/admEmbedV2Menu').default;let i=interaction(a,'embedv2:publish:'+r.id,{kind:'button'});await h.execute(i);assert.equal(sends,1);assert.equal(publicationState(records.get(r.id)),'Publicado · sem alterações pendentes');assert.ok(lastPanel(i).content.includes('sem alterações pendentes'));
 records.get(r.id).description='Texto editado depois';assert.equal(publicationState(records.get(r.id)),'Alterações salvas · ainda não publicadas');i=interaction(a,'embedv2:publish:'+r.id,{kind:'button'});await h.execute(i);assert.equal(sends,1);assert.equal(edits,1);assert.equal(publicationState(records.get(r.id)),'Publicado · sem alterações pendentes');
});
test('a publication fetch permission failure does not silently create a duplicate',async()=>{
 sends=0;edits=0;const a=fixture();const ch=channel(a);const r=record('publish-fail',a.id,{destinationChannelId:ch.id,publishedChannelId:ch.id,publishedMessageId:'old'});records.set(r.id,r);fetchError={code:50013};
 const i=interaction(a,'embedv2:publish:'+r.id,{kind:'button'});await require('../app/components/buttons/admEmbedV2Menu').default.execute(i);assert.equal(sends,0);assert.equal(edits,0);assert.equal(i.calls.at(-1)[0],'followUp');fetchError=null;
});
test('publication fingerprints ignore editor-only names and clock time, while detecting content and button changes',()=>{
 const r=record('hash','guild');const h=publicationHash(r);assert.equal(h,publicationHash({...r,name:'Renamed',updatedAt:new Date(),showTimestamp:false}));assert.notEqual(h,publicationHash({...r,description:'Changed'}));assert.notEqual(h,publicationHash({...r,buttons:[{type:'LINK',label:'Site',url:'https://example.com'}]}));assert.ok(publicationState({...r,publishedMessageId:'legacy'}).includes('conferir'));
});
test('image-only messages retain the real preview without adding editor instructions to published content',async()=>{
 const a=fixture();const r=record('image-only',a.id,{title:null,description:null,imageUrl:'https://images.example/image.png'});const p=await buildEmbedEditorPayload(a,r);assert.equal(p.embeds[0].toJSON().description,undefined);assert.equal(p.embeds[0].toJSON().image.url,r.imageUrl);
});


test('editing a saved link button refreshes its real label and URL in place without updating the public message',async()=>{
 const a=fixture();const r=record('button-edit',a.id,{publishedMessageId:'existing',buttons:[{id:'btn-edit',type:'LINK',label:'Antigo',url:'https://example.com/old',emoji:null,position:0}]});r.publishedPayloadHash=publicationHash(r);records.set(r.id,r);
 const beforeSends=sends,beforeEdits=edits;
 const i=interaction(a,'embedv2-modal:edit-button:button-edit:btn-edit',{fields:{label:'Novo destino',url:'https://example.com/new',emoji:''}});
 await require('../app/components/modals/admEmbedV2Modal').default.execute(i);
 const p=lastPanel(i);const link=p.components.flatMap(row=>row.toJSON().components).find(b=>b.style===5);
 assert.equal(link.label,'Novo destino');assert.equal(link.url,'https://example.com/new');assert.ok(p.content.includes('ainda não publicadas'));
 assert.equal(sends,beforeSends);assert.equal(edits,beforeEdits);validate(p);
});

test('Ver prévia shows only the saved message and paginated links, returns to editing and never publishes',async()=>{
 const a=fixture();const h=require('../app/components/buttons/admEmbedV2Menu').default;
 const r=record('focused-preview',a.id,{buttons:Array.from({length:25},(_,n)=>({id:'preview-'+n,type:'LINK',label:'Link '+n,url:'https://example.com/'+n,position:n}))});records.set(r.id,r);
 assert.equal(ADM_SECTIONS.sistema.modules.find(m=>m.value==='cfg:embeds').label,'Mensagens Personalizadas / Embeds');
 const editor=validate(await buildEmbedEditorPayload(a,r));
 assert.ok(editor.components.flatMap(row=>row.toJSON().components).some(c=>c.label==='Ver prévia'&&c.custom_id==='embedv2:preview:'+r.id));
 const before={sends,edits,mutations:mutations.length,record:clone(records.get(r.id))};
 for(const [page,count]of [[0,10],[1,10],[2,5]]){
  const i=interaction(a,`embedv2:preview:${r.id}:${page}`);await h.execute(i);const p=validate(lastPanel(i));
  assert.deepEqual(p.embeds[0].toJSON(),editor.embeds[0].toJSON());
  const controls=p.components.flatMap(row=>row.toJSON().components);
  assert.equal(controls.filter(c=>c.style===5).length,count);
  assert.ok(controls.some(c=>c.label==='Voltar ao editor'&&c.custom_id==='embedv2:editor:'+r.id));
  assert.ok(!controls.some(c=>c.type===3||c.custom_id?.startsWith('embedv2:publish:')));
 }
 const back=interaction(a,'embedv2:editor:'+r.id);await h.execute(back);
 assert.ok(lastPanel(back).content.startsWith('**Editar'));
 assert.deepEqual({sends,edits,mutations:mutations.length,record:clone(records.get(r.id))},before);
 const foreign=fixture('100000000000000999');const i=interaction(foreign,'embedv2:preview:'+r.id);await h.execute(i);
 assert.equal(i.calls.at(-1)[0],'reply');assert.equal(sends,before.sends);assert.equal(edits,before.edits);
});
