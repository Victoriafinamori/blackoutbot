"use strict";
const {test}=require("node:test"),assert=require("node:assert/strict"),D=require("discord.js"),fs=require("node:fs");
const {setup,interaction,valid,last,rolePanel,draft,prisma,Doc,S,R,V,C,I,Compat,json}=require("./fixtures/maker-runtime.cjs");
test("new document renders native V2 with black supported and no classic embeds", () => {
  const d = Doc.blank();
  d.color = "000000";
  const p = valid(Doc.render(d));
  assert.equal(p.components[0].accent_color, 0);
});
test("all native block types, galleries and channel links render without placeholder substitutions", () => {
  const d = Doc.blank();
  d.blocks.push(
    {
      id: Doc.uid(),
      type: "section",
      text: "Texto",
      thumbnail: "https://example.com/thumb.png",
    },
    {
      id: Doc.uid(),
      type: "gallery",
      images: ["https://example.com/1.png", "https://example.com/2.png"],
    },
    { id: Doc.uid(), type: "separator" },
    {
      id: Doc.uid(),
      type: "buttons",
      buttons: [
        {
          id: Doc.uid(),
          label: "Canal",
          url: "https://discord.com/channels/1/2",
        },
      ],
    },
  );
  const p = valid(Doc.render(d));
  assert.ok(JSON.stringify(p).includes('"type":12'));
  assert.equal(p.allowedMentions.parse.length, 0);
});
test("invalid URLs, repeated block IDs and excessive component content are rejected", () => {
  const d = Doc.blank();
  d.blocks.push({
    id: Doc.uid(),
    type: "gallery",
    images: ["javascript:alert(1)"],
  });
  assert.throws(() => Doc.render(d), Doc.MakerError);
  const e = Doc.blank();
  e.blocks[1].id = e.blocks[0].id;
  assert.throws(() => Doc.parse(e), Doc.MakerError);
  const a = Doc.blank();
  a.blocks = Array.from({ length: 25 }, () => ({
    id: Doc.uid(),
    type: "text",
    text: "x".repeat(200),
  }));
  assert.throws(() => Doc.render(a), /4.000/);
});
test("25 legacy link buttons are retained for publication and paginated for editing", async () => {
  const f = setup(),
    old = {
      name: "Links",
      title: "Links",
      buttons: Array.from({ length: 25 }, (_, n) => ({
        label: "Link " + n,
        type: "LINK",
        url: "https://example.com/" + n,
      })),
    };
  const d = Doc.legacy(old, f.g.id);
  assert.equal(
    d.blocks
      .filter((b) => b.type === "buttons")
      .reduce((n, b) => n + b.buttons.length, 0),
    25,
  );
  valid(Doc.render(d));
  const { s } = await draft(f, { document: d });
  const p = valid(await V.editor(f.g, s));
  assert.ok(Doc.pages(d).length > 1);
  assert.ok(JSON.stringify(p).includes("todos os blocos"));
});
test("legacy import is idempotent, guild scoped and preserves original rows", async () => {
  const f = setup();
  const old = await prisma.customEmbed.create({
    data: {
      guildId: f.g.id,
      name: "Antigo",
      title: "Título",
      description: "Descrição",
      publishedMessageId: "100000000000009001",
      publishedChannelId: f.ch.id,
    },
  });
  await prisma.customEmbedButton.create({
    data: {
      embedId: old.id,
      type: "LINK",
      label: "Site",
      url: "https://example.com",
    },
  });
  await Promise.all([S.importLegacy(f.g.id), S.importLegacy(f.g.id)]);
  assert.equal(await prisma.makerTemplate.count(), 1);
  assert.equal(await prisma.makerPublication.count(), 1);
  assert.equal(
    (await prisma.customEmbed.findUnique({ where: { id: old.id } }))
      .description,
    "Descrição",
  );
  const pub = await prisma.makerPublication.findFirst();
  assert.equal(pub.legacy, true);
  assert.match(
    JSON.stringify(valid(await V.publicationView(f.g, pub.id))),
    /pode ter conteúdo diferente/,
  );
});
test("deleted imported model does not reappear when legacy models are imported again", async () => {
  const f = setup();
  await prisma.customEmbed.create({
    data: { guildId: f.g.id, name: "Antigo", title: "Título" },
  });
  await S.importLegacy(f.g.id);
  const t = await prisma.makerTemplate.findFirst();
  await prisma.makerTemplate.update({
    where: { id: t.id },
    data: { deletedAt: new Date() },
  });
  await S.importLegacy(f.g.id);
  assert.equal(await prisma.makerTemplate.count(), 1);
  assert.equal(
    await prisma.makerTemplate.count({ where: { deletedAt: null } }),
    0,
  );
});
test("saved text is refreshed on the original message without publication", async () => {
  const f = setup(),
    { s } = await draft(f),
    id = Doc.parse(s.documentJson).blocks[1].id;
  const i = interaction(f.g, "maker-form:block:" + s.id + ":0:" + id, {
    text: "**Novo texto**",
  });
  await I.execute(i);
  const p = valid(last(i));
  assert.match(JSON.stringify(p), /Novo texto/);
  assert.equal(f.sent.length, 0);
  assert.equal(
    i.calls.some(([m]) => m === "reply"),
    false,
  );
});
test("session rejects another actor, message, guild, stale revision and expiry", async () => {
  const f = setup(),
    { i, s } = await draft(f);
  await assert.rejects(
    () =>
      C.session(interaction(f.g, "x", {}, [], { user: f.g.other.user }), s.id),
    Doc.MakerError,
  );
  await assert.rejects(
    () =>
      C.session(
        interaction(f.g, "x", {}, [], { messageId: "different" }),
        s.id,
      ),
    Doc.MakerError,
  );
  await assert.rejects(
    () => C.session({ ...i, guild: { ...f.g, id: "other" } }, s.id),
    Doc.MakerError,
  );
  await assert.rejects(() => C.session(i, s.id, 4), Doc.MakerError);
  await prisma.makerSession.update({
    where: { id: s.id },
    data: { expiresAt: new Date(0) },
  });
  await assert.rejects(() => C.session(i, s.id), Doc.MakerError);
});
test("concurrent stale edits preserve the first accepted document", async () => {
  const f = setup(),
    { i, s } = await draft(f);
  const results = await Promise.allSettled([
    S.change(i, s.id, 0, (d) => (d.blocks[0].text = "Primeiro")),
    S.change(i, s.id, 0, (d) => (d.blocks[0].text = "Segundo")),
  ]);
  assert.equal(results.filter((r) => r.status === "fulfilled").length, 1);
  assert.equal(
    Doc.parse((await C.session(i, s.id)).documentJson).blocks[0].text,
    "Primeiro",
  );
});
test("reordering, duplicate, removal and undo preserve stable block identity", async () => {
  const f = setup(),
    { s } = await draft(f),
    id = Doc.parse(s.documentJson).blocks[1].id;
  let i = interaction(f.g, "maker:up:" + s.id + ":0:" + id);
  await I.execute(i);
  let current = await C.session(i, s.id);
  assert.equal(Doc.parse(current.documentJson).blocks[0].id, id);
  i = interaction(
    f.g,
    "maker:duplicate:" + s.id + ":" + current.revision + ":" + id,
  );
  await I.execute(i);
  current = await C.session(i, s.id);
  assert.equal(Doc.parse(current.documentJson).blocks.length, 3);
  i = interaction(f.g, "maker:undo:" + s.id + ":" + current.revision);
  await I.execute(i);
  assert.equal(
    Doc.parse((await C.session(i, s.id)).documentJson).blocks.length,
    2,
  );
  valid(last(i));
});
test("gallery and appearance modal update real preview while invalid edits preserve draft", async () => {
  const f = setup(),
    { s } = await draft(f);
  let i = interaction(f.g, "maker-form:addblock:" + s.id + ":0:gallery", {
    images: "https://example.com/a.png\nhttps://example.com/b.png",
  });
  await I.execute(i);
  let current = await C.session(i, s.id);
  assert.equal(Doc.parse(current.documentJson).blocks.at(-1).images.length, 2);
  i = interaction(
    f.g,
    "maker-form:appearance:" + s.id + ":" + current.revision,
    { name: "Bem-vindo", color: "#000000" },
  );
  await I.execute(i);
  assert.equal(valid(last(i)).components[1].accent_color, 0);
  current = await C.session(i, s.id);
  i = interaction(
    f.g,
    "maker-form:appearance:" + s.id + ":" + current.revision,
    { name: "Erro", color: "bad" },
  );
  await I.execute(i);
  assert.equal((await C.session(i, s.id)).revision, current.revision);
  assert.equal(i.calls.at(-1)[0], "followUp");
});
test("same model creates two publication records and editing one preserves the other", async () => {
  const f = setup(),
    { i, s } = await draft(f);
  await S.save(i, s.id, 0);
  const t = await prisma.makerTemplate.findFirst();
  const a = await S.start(i, { templateId: t.id, fresh: true }),
    b = await S.start(i, { templateId: t.id, fresh: true });
  for (const d of [a, b])
    await prisma.makerSession.update({
      where: { id: d.id },
      data: { destinationChannelId: f.ch.id },
    });
  const p1 = await S.publishSession(i, await C.session(i, a.id)),
    p2 = await S.publishSession(i, await C.session(i, b.id));
  assert.notEqual(p1.messageId, p2.messageId);
  const old = p2.snapshotJson,
    edit = await S.start(i, { publicationId: p1.id });
  const changed = await S.change(
    i,
    edit.id,
    0,
    (d) => (d.blocks[1].text = "Só este envio"),
  );
  await S.publishSession(i, changed);
  assert.equal((await S.publication(f.g.id, p2.id)).snapshotJson, old);
  assert.notEqual((await S.publication(f.g.id, p1.id)).snapshotJson, old);
  assert.equal(
    (await prisma.makerTemplate.findUnique({ where: { id: t.id } }))
      .documentJson,
    t.documentJson,
  );
  assert.equal(f.sent.length, 2);
});
test("saving a publication as model does not replace the original source template", async () => {
  const f = setup(),
    { i, s } = await draft(f);
  await S.save(i, s.id, 0);
  await prisma.makerSession.update({
    where: { id: s.id },
    data: { destinationChannelId: f.ch.id },
  });
  const p = await S.publishSession(i, await C.session(i, s.id)),
    edit = await S.start(i, { publicationId: p.id });
  await S.change(i, edit.id, 0, (d) => (d.blocks[0].text = "Novo modelo"));
  await S.save(i, edit.id, 1);
  assert.equal(await prisma.makerTemplate.count(), 2);
  assert.equal(
    (await S.publication(f.g.id, p.id)).snapshotJson,
    p.snapshotJson,
  );
});
test("model optimistic revision prevents overwriting another administrator's saved change", async () => {
  const f = setup(),
    { i, s } = await draft(f);
  await S.save(i, s.id, 0);
  const t = await prisma.makerTemplate.findFirst(),
    a = await S.start(i, { templateId: t.id, fresh: true }),
    b = await S.start(i, { templateId: t.id, fresh: true });
  await S.save(i, a.id, 0);
  await assert.rejects(() => S.save(i, b.id, 0), /outra edição/);
});
test("confirmation tokens are restricted, consumed once and do not create duplicate sends", async () => {
  const f = setup(),
    { i, s } = await draft(f);
  await prisma.makerSession.update({
    where: { id: s.id },
    data: { destinationChannelId: f.ch.id },
  });
  const current = await C.session(i, s.id),
    op = await C.action(i, "PUBLISH", null, {
      sessionId: s.id,
      revision: 0,
      documentJson: current.documentJson,
      channelId: f.ch.id,
      publicationId: null,
    });
  const click = interaction(f.g, "maker:confirm:" + op.id);
  await I.execute(click);
  assert.equal(f.sent.length, 1);
  await I.execute(interaction(f.g, "maker:confirm:" + op.id));
  assert.equal(f.sent.length, 1);
  assert.equal(await prisma.makerPublication.count(), 1);
});
test("permission failure fetching an existing publication does not create another message", async () => {
  const f = setup(),
    { i, s } = await draft(f);
  await prisma.makerSession.update({
    where: { id: s.id },
    data: { destinationChannelId: f.ch.id },
  });
  const p = await S.publishSession(i, await C.session(i, s.id)),
    edit = await S.start(i, { publicationId: p.id });
  f.ch.messages.fetch = async () => {
    throw Object.assign(Error(), { code: 50013 });
  };
  await assert.rejects(() => S.publishSession(i, edit), /permissões/);
  assert.equal(f.sent.length, 1);
  assert.equal((await S.publication(f.g.id, p.id)).status, "UNAVAILABLE");
});
test("uncertain initial send remains registered and cannot be retried as a fresh send", async () => {
  const f = setup(),
    { i, s } = await draft(f);
  await prisma.makerSession.update({
    where: { id: s.id },
    data: { destinationChannelId: f.ch.id },
  });
  f.ch.send = async () => {
    throw Error("timeout");
  };
  await assert.rejects(
    async () => S.publishSession(i, await C.session(i, s.id)),
    /confirmar/,
  );
  const current = await C.session(i, s.id);
  assert.ok(current.publicationId);
  assert.equal(
    (await S.publication(f.g.id, current.publicationId)).status,
    "UNCERTAIN",
  );
  await assert.rejects(
    () => S.publishSession(i, current),
    /não possui|não foi confirmada/,
  );
  assert.equal(await prisma.makerPublication.count(), 1);
});
test("missing publication is reported and never silently recreated", async () => {
  const f = setup(),
    { i, s } = await draft(f);
  await prisma.makerSession.update({
    where: { id: s.id },
    data: { destinationChannelId: f.ch.id },
  });
  const p = await S.publishSession(i, await C.session(i, s.id)),
    m = await f.ch.messages.fetch(p.messageId);
  await m.delete();
  await assert.rejects(() => S.verifyPublication(f.g, p.id), /apagada/);
  assert.equal((await S.publication(f.g.id, p.id)).status, "MISSING");
  assert.equal(f.sent.length, 1);
});
test("deleting a template preserves every publication and deleting a publication preserves the model", async () => {
  const f = setup(),
    { i, s } = await draft(f);
  await S.save(i, s.id, 0);
  const t = await prisma.makerTemplate.findFirst();
  await prisma.makerSession.update({
    where: { id: s.id },
    data: { destinationChannelId: f.ch.id },
  });
  const p = await S.publishSession(i, await C.session(i, s.id));
  const op = await C.action(i, "TEMPLATE_DELETE", t.id, {
    revision: t.revision,
    name: t.name,
  });
  await I.execute(interaction(f.g, "maker:confirm:" + op.id));
  assert.ok(
    (await prisma.makerTemplate.findUnique({ where: { id: t.id } })).deletedAt,
  );
  assert.equal((await S.publication(f.g.id, p.id)).messageId, p.messageId);
  const del = await C.action(i, "PUB_DELETE", p.id, {
    revision: p.revision,
    name: p.name,
    channelId: p.channelId,
  });
  await I.execute(interaction(f.g, "maker:confirm:" + del.id));
  assert.equal((await S.publication(f.g.id, p.id)).status, "DELETED");
  assert.equal(await prisma.makerTemplate.count(), 1);
});
test("role panel starts draft, rejects privileged roles, and seeds actual reactions on publication", async () => {
  const f = setup();
  const p = await R.create(f.g.id, f.g.actor.id);
  assert.equal(p.status, "DRAFT");
  f.role.permissions.has = (bit) => bit === D.PermissionFlagsBits.Administrator;
  await assert.rejects(
    () => R.addBinding(f.g, p.id, f.role.id, "🎮"),
    /administr/,
  );
  f.role.permissions.has = () => false;
  const e = await rolePanel(f);
  assert.equal(e.p.status, "ACTIVE");
  assert.ok(e.message.reactions.cache.has("u:🎮"));
  assert.equal((await R.bindings(f.g.id, e.p.id, true)).length, 1);
});
test("Unicode emoji validation normalizes variation selectors and checks custom availability", async () => {
  const f = setup();
  assert.equal(R.emoji("⚽").emojiKey, R.emoji("⚽️").emojiKey);
  assert.throws(() => R.emoji("abc"), Doc.MakerError);
  assert.throws(() => R.emoji("🎮⚽"), Doc.MakerError);
  const p = await R.create(f.g.id, f.g.actor.id);
  await assert.rejects(
    () => R.addBinding(f.g, p.id, f.role.id, "<:teste:100000000000000555>"),
    /acesso/,
  );
  f.g.emojis.cache.set("100000000000000555", {
    id: "100000000000000555",
    available: true,
  });
  await R.addBinding(f.g, p.id, f.role.id, "<:teste:100000000000000555>");
});
test("same emoji cannot map to two active roles in a panel", async () => {
  const f = setup(),
    p = await R.create(f.g.id, f.g.actor.id);
  await R.addBinding(f.g, p.id, f.role.id, "🎮");
  await assert.rejects(
    () => R.addBinding(f.g, p.id, [...f.g.roles.cache.keys()][1], "🎮"),
    /já está/,
  );
});
test("concurrent repeated add events grant one role with one tracked participation", async () => {
  const f = setup(),
    e = await rolePanel(f);
  await Promise.all([
    R.grant(f.g, e.b.id, f.g.other.id),
    R.grant(f.g, e.b.id, f.g.other.id),
  ]);
  assert.equal(f.roleCalls.filter((v) => v[0] === "add").length, 1);
  assert.equal(await prisma.reactionRoleGrant.count(), 1);
  assert.equal(await prisma.reactionRoleOwnership.count(), 1);
});
test("removing a tracked reaction removes only a bot-owned role", async () => {
  const f = setup(),
    e = await rolePanel(f);
  await R.grant(f.g, e.b.id, f.g.other.id);
  await R.release(f.g, e.b.id, f.g.other.id);
  assert.equal(f.g.other.roles.cache.has(f.role.id), false);
  assert.equal(f.roleCalls.filter((v) => v[0] === "remove").length, 1);
});
test("preexisting member role remains after add and remove reactions", async () => {
  const f = setup(),
    e = await rolePanel(f);
  f.g.other.roles.cache.set(f.role.id, f.role);
  await R.grant(f.g, e.b.id, f.g.other.id);
  await R.release(f.g, e.b.id, f.g.other.id);
  assert.equal(f.g.other.roles.cache.has(f.role.id), true);
  assert.equal(f.roleCalls.length, 0);
});
test("same role granted by another panel remains until its last active grant is removed", async () => {
  const f = setup(),
    a = await rolePanel(f),
    b = await rolePanel(f);
  await R.grant(f.g, a.b.id, f.g.other.id);
  await R.grant(f.g, b.b.id, f.g.other.id);
  await R.release(f.g, a.b.id, f.g.other.id);
  assert.equal(f.g.other.roles.cache.has(f.role.id), true);
  await R.release(f.g, b.b.id, f.g.other.id);
  assert.equal(f.g.other.roles.cache.has(f.role.id), false);
});
test("keep-on-unreact preserves the role and explicitly releases ownership", async () => {
  const f = setup(),
    e = await rolePanel(f, { removeOnUnreact: false });
  await R.onReaction(e.reaction, f.g.other.user);
  await R.onReaction(e.reaction, f.g.other.user, true);
  assert.equal(f.g.other.roles.cache.has(f.role.id), true);
  assert.equal((await prisma.reactionRoleGrant.findFirst()).status, "RETAINED");
});
test("paused panel ignores add and remove events and preserves assigned roles", async () => {
  const f = setup(),
    e = await rolePanel(f);
  await R.onReaction(e.reaction, f.g.other.user);
  await R.pause(f.g.id, e.p.id, true);
  await R.onReaction(e.reaction, f.g.other.user, true);
  await R.onReaction(e.reaction, f.g.third.user);
  assert.equal(f.g.other.roles.cache.has(f.role.id), true);
  assert.equal(f.g.third.roles.cache.has(f.role.id), false);
});
test("reaction events work with uncached partial messages and reject foreign guilds or channels", async () => {
  const f = setup(),
    e = await rolePanel(f);
  const partial = {
    ...e.reaction,
    message: {
      id: e.message.id,
      channelId: f.ch.id,
      guild: f.g,
      partial: true,
    },
  };
  await R.onReaction(partial, f.g.other.user);
  assert.equal(f.g.other.roles.cache.has(f.role.id), true);
  await R.onReaction(
    {
      ...partial,
      message: { ...partial.message, guild: { ...f.g, id: "foreign" } },
    },
    f.g.third.user,
  );
  await R.onReaction(
    { ...partial, message: { ...partial.message, channelId: "foreign" } },
    f.g.third.user,
  );
  assert.equal(f.g.third.roles.cache.has(f.role.id), false);
});
test("ownership uncertain after an interrupted API operation is retained conservatively", async () => {
  const f = setup(),
    e = await rolePanel(f);
  await R.grant(f.g, e.b.id, f.g.other.id);
  const owner = await prisma.reactionRoleOwnership.findFirst();
  await prisma.reactionRoleOwnership.update({
    where: { id: owner.id },
    data: { state: "PENDING" },
  });
  await R.grant(f.g, e.b.id, f.g.other.id);
  assert.equal(
    (await prisma.reactionRoleOwnership.findFirst()).state,
    "UNCERTAIN",
  );
  await R.release(f.g, e.b.id, f.g.other.id);
  assert.equal(f.g.other.roles.cache.has(f.role.id), true);
});
test("role API failure is recorded without claiming a completed grant", async () => {
  const f = setup(),
    e = await rolePanel(f);
  f.g.other.roles.add = async () => {
    throw Error("API");
  };
  await R.onReaction(e.reaction, f.g.other.user);
  assert.equal((await prisma.reactionRoleGrant.findFirst()).status, "FAILED");
  assert.match((await R.panel(f.g.id, e.p.id)).lastError, /concessão/);
  assert.equal(f.g.other.roles.cache.has(f.role.id), false);
});
test("failed activation keeps its original message for retry and suspends grants", async () => {
  const f = setup(),
    p = await R.create(f.g.id, f.g.actor.id);
  await prisma.reactionRolePanel.update({
    where: { id: p.id },
    data: { channelId: f.ch.id },
  });
  const b = await R.addBinding(f.g, p.id, f.role.id, "🎮"),
    send = f.ch.send;
  f.ch.send = async (payload) => {
    const m = await send(payload);
    m.react = async () => {
      throw Error("reaction denied");
    };
    return m;
  };
  await assert.rejects(
    async () => R.publish(f.g, p.id, (await R.panel(f.g.id, p.id)).revision),
    /ativação/,
  );
  const failed = await R.panel(f.g.id, p.id);
  assert.equal(failed.status, "ERROR");
  await R.grant(f.g, b.id, f.g.other.id);
  assert.equal(f.g.other.roles.cache.has(f.role.id), false);
  assert.equal(f.sent.length, 1);
});
test("role draft edits do not alter published content or overwrite another editor", async () => {
  const f = setup(),
    e = await rolePanel(f),
    i = interaction(f.g, "x"),
    a = await S.start(i, { panelId: e.p.id, fresh: true }),
    b = await S.start(i, { panelId: e.p.id, fresh: true });
  await S.change(i, a.id, 0, (d) => (d.blocks[0].text = "Novo rascunho"));
  await S.save(i, a.id, 1);
  assert.equal(
    (await S.publication(f.g.id, e.pub.id)).snapshotJson,
    e.pub.snapshotJson,
  );
  await assert.rejects(() => S.save(i, b.id, 0), /outra edição/);
});
test("retiring association with keep does not remove roles or affect published siblings", async () => {
  const f = setup(),
    e = await rolePanel(f);
  await R.grant(f.g, e.b.id, f.g.other.id);
  await R.disable(f.g, e.b.id, true);
  assert.equal(f.g.other.roles.cache.has(f.role.id), true);
  assert.equal((await prisma.reactionRoleGrant.findFirst()).status, "RETAINED");
  assert.equal((await R.bindings(f.g.id, e.p.id)).length, 0);
});
test("retiring with removal is processed in bounded batches and respects preexisting roles", async () => {
  const f = setup(),
    e = await rolePanel(f);
  f.g.third.roles.cache.set(f.role.id, f.role);
  await R.grant(f.g, e.b.id, f.g.other.id);
  await R.grant(f.g, e.b.id, f.g.third.id);
  await R.disable(f.g, e.b.id, false);
  const result = await R.revokeBatch(f.g, e.b.id);
  assert.equal(result.processed, 2);
  assert.equal(result.remaining, 0);
  assert.equal(f.g.other.roles.cache.has(f.role.id), false);
  assert.equal(f.g.third.roles.cache.has(f.role.id), true);
});
test("sync review is read-only and application rechecks current reaction presence", async () => {
  const f = setup(),
    e = await rolePanel(f);
  e.reaction.users.cache.set(f.g.other.id, f.g.other.user);
  const plan = await R.planSync(f.g, e.p.id);
  assert.equal(plan.items.length, 1);
  assert.equal(f.roleCalls.length, 0);
  e.reaction.users.cache.delete(f.g.other.id);
  await R.syncItem(f.g, e.p.id, plan.items[0]);
  assert.equal(f.g.other.roles.cache.has(f.role.id), false);
});
test("sync recovers missed offline add and remove events", async () => {
  const f = setup(),
    e = await rolePanel(f);
  e.reaction.users.cache.set(f.g.other.id, f.g.other.user);
  let plan = await R.planSync(f.g, e.p.id);
  await R.syncItem(f.g, e.p.id, plan.items[0]);
  assert.equal(f.g.other.roles.cache.has(f.role.id), true);
  e.reaction.users.cache.delete(f.g.other.id);
  plan = await R.planSync(f.g, e.p.id);
  assert.equal(plan.items[0].type, "REMOVE");
  await R.syncItem(f.g, e.p.id, plan.items[0]);
  assert.equal(f.g.other.roles.cache.has(f.role.id), false);
});
test("sync confirmation is consumed once and reports bounded progress", async () => {
  const f = setup(),
    e = await rolePanel(f),
    i = interaction(f.g, "x");
  e.reaction.users.cache.set(f.g.other.id, f.g.other.user);
  const data = await R.planSync(f.g, e.p.id),
    op = await C.action(i, "SYNC", e.p.id, data);
  await I.execute(interaction(f.g, "maker:confirm:" + op.id));
  const current = await prisma.makerAction.findUnique({ where: { id: op.id } });
  assert.equal(current.status, "DONE");
  assert.equal(current.cursor, 1);
  await I.execute(interaction(f.g, "maker:confirm:" + op.id));
  assert.equal(f.roleCalls.filter((v) => v[0] === "add").length, 1);
});
test("deleted message, removed reactions and deleted role suspend the affected panel", async () => {
  const f = setup(),
    e = await rolePanel(f);
  await R.messageDeleted(e.message);
  assert.equal((await R.panel(f.g.id, e.p.id)).status, "PAUSED");
  assert.equal((await S.publication(f.g.id, e.pub.id)).status, "MISSING");
  await prisma.reactionRolePanel.update({
    where: { id: e.p.id },
    data: { status: "ACTIVE" },
  });
  await R.reactionsCleared(e.message);
  assert.equal((await R.panel(f.g.id, e.p.id)).status, "PAUSED");
  await require("../app/events/makerRoleDelete").default.execute({
    ...f.role,
    guild: f.g,
  });
  assert.match((await R.panel(f.g.id, e.p.id)).lastError, /apagado/);
});
test("guild departure clears active grants and ownership without mutating Discord roles", async () => {
  const f = setup(),
    e = await rolePanel(f);
  await R.grant(f.g, e.b.id, f.g.other.id);
  const before = f.roleCalls.length;
  await require("../app/events/makerMemberRemove").default.execute(f.g.other);
  assert.equal((await prisma.reactionRoleGrant.findFirst()).active, false);
  assert.equal(await prisma.reactionRoleOwnership.count(), 0);
  assert.equal(f.roleCalls.length, before);
});
test("role panel copy and editor shortcut preserve model and existing panels", async () => {
  const f = setup(),
    e = await rolePanel(f),
    { s } = await draft(f);
  await I.execute(interaction(f.g, "maker:copy-role:" + s.id + ":0"));
  assert.equal(await prisma.reactionRolePanel.count(), 2);
  assert.equal((await R.panel(f.g.id, e.p.id)).documentJson, e.p.documentJson);
  assert.equal(await prisma.makerTemplate.count(), 0);
  assert.equal(f.sent.length, 1);
});
test("all maker administrative views fit native limits and isolate the optional role shortcut", async () => {
  const f = setup(),
    e = await rolePanel(f),
    { i, s } = await draft(f);
  for (const p of [
    await V.home(f.g),
    await V.templates(f.g),
    await V.editor(f.g, s),
    await V.organize(f.g, s),
    await V.publications(f.g),
    await V.roleHome(f.g),
    await V.roleDetail(f.g, e.p.id),
    await V.roleBindings(f.g, e.p.id),
    await V.roleInspect(f.g, e.p.id),
  ])
    valid(p);
  const roleSession = await S.start(i, { panelId: e.p.id, fresh: true });
  assert.ok(
    JSON.stringify(valid(await V.editor(f.g, s))).includes(
      "Usar em painel de cargos",
    ),
  );
  assert.ok(
    !JSON.stringify(valid(await V.editor(f.g, roleSession))).includes(
      "Usar em painel de cargos",
    ),
  );
});
test("unauthorized users cannot mutate sessions, publish or configure role bindings", async () => {
  const f = setup(),
    i = interaction(f.g, "maker:create", {}, [], { user: f.g.other.user });
  await I.execute(i);
  assert.equal(await prisma.makerSession.count(), 0);
  assert.equal(i.calls.at(-1)[0], "reply");
});
test("back navigation on a V2 message remains compatible with classic administrative builders", async () => {
  const f = setup(),
    i = interaction(f.g, "adm-nav:root");
  f.g.client.buttons = new D.Collection([
    ["adm-nav:", require("../app/components/buttons/admNavigation").default],
  ]);
  await require("../app/events/interactionCreate").default.execute(
    i,
    f.g.client,
  );
  valid(last(i));
  assert.ok(JSON.stringify(json(last(i))).includes("adm-panel-select"));
});
test("V2 compatibility preserves a new ephemeral error reply as a separate classic message", async () => {
  const f = setup(),
    i = interaction(f.g, "x"),
    proxy = Compat.compatibleInteraction(i);
  await proxy.deferReply({ flags: D.MessageFlags.Ephemeral });
  await proxy.editReply({ content: "Erro de exemplo" });
  assert.equal(i.calls.at(-1)[1].components, undefined);
});
test("stale classic embed controls are intercepted before legacy mutations", async () => {
  const f = setup();
  const old = await prisma.customEmbed.create({
    data: { guildId: f.g.id, name: "Antigo", title: "Título" },
  });
  const i = interaction(f.g, "embedv2:publish:" + old.id);
  f.g.client.buttons = new D.Collection([
    [
      "embedv2:",
      {
        customId: "embedv2:",
        execute() {
          throw Error("Legacy runtime must not run");
        },
      },
    ],
  ]);
  await require("../app/events/interactionCreate").default.execute(
    i,
    f.g.client,
  );
  valid(last(i));
  assert.equal(f.sent.length, 0);
  assert.equal(await prisma.makerSession.count(), 1);
  assert.equal(
    (await prisma.customEmbed.findUnique({ where: { id: old.id } }))
      .publishedMessageId,
    null,
  );
});
test("canonical navigation retains seven areas, 29 destinations and no duplicated module list in embeds", async () => {
  const f = setup(),
    { ADM_SECTIONS, buildAdmSectionPanel } = require("../app/utils/admPanel");
  assert.equal(
    Object.values(ADM_SECTIONS).reduce((n, a) => n + a.modules.length, 0),
    29,
  );
  for (const area of Object.keys(ADM_SECTIONS)) {
    const p = await buildAdmSectionPanel(f.g, area);
    assert.equal((p.embeds[0].toJSON().fields || []).length, 0);
    assert.ok(p.components[0].toJSON().components[0].options.length);
  }
});


test("reopening the same model resumes the actor's unsaved draft", async () => {
  const f = setup(),
    { i, s } = await draft(f);
  await S.save(i, s.id, 0);
  const t = await prisma.makerTemplate.findFirst();
  const next = await S.change(
    i,
    s.id,
    0,
    (d) => (d.blocks[0].text = "Rascunho que continua"),
  );
  const reopened = await S.start(i, { templateId: t.id });
  assert.equal(reopened.id, next.id);
  assert.equal(
    Doc.parse(reopened.documentJson).blocks[0].text,
    "Rascunho que continua",
  );
  assert.notEqual(reopened.documentJson, t.documentJson);
});
test("newer saved model revision opens a fresh editor without overwriting the old draft", async () => {
  const f = setup(),
    { i, s } = await draft(f);
  await S.save(i, s.id, 0);
  const t = await prisma.makerTemplate.findFirst();
  await S.change(i, s.id, 0, (d) => (d.blocks[0].text = "Rascunho antigo"));
  await prisma.makerTemplate.update({
    where: { id: t.id },
    data: { revision: { increment: 1 } },
  });
  const fresh = await S.start(i, { templateId: t.id });
  assert.notEqual(fresh.id, s.id);
  assert.equal(
    Doc.parse(fresh.documentJson).blocks[0].text,
    "Sua próxima mensagem",
  );
});
test("role editor preview includes generated emoji, role legend and withdrawal rule", async () => {
  const f = setup(),
    e = await rolePanel(f),
    i = interaction(f.g, "x"),
    s = await S.start(i, { panelId: e.p.id });
  const p = valid(await V.editor(f.g, s));
  const text = JSON.stringify(p);
  assert.match(text, /🎮/);
  assert.ok(text.includes(f.role.id));
  assert.match(text, /Retirar a reação/);
});
test("member lookup failure leaves a retryable withdrawal without removing unrelated roles", async () => {
  const f = setup(),
    e = await rolePanel(f);
  await R.grant(f.g, e.b.id, f.g.other.id);
  const fetch = f.g.members.fetch;
  f.g.members.fetch = async () => {
    throw Object.assign(Error(), { code: 50013 });
  };
  await assert.rejects(() => R.release(f.g, e.b.id, f.g.other.id), /consultar/);
  assert.equal(
    (await prisma.reactionRoleGrant.findFirst()).status,
    "REVOKE_PENDING",
  );
  assert.equal(f.g.other.roles.cache.has(f.role.id), true);
  f.g.members.fetch = fetch;
  await R.release(f.g, e.b.id, f.g.other.id);
  assert.equal(f.g.other.roles.cache.has(f.role.id), false);
});
test("uncertain send can register only a matching message from the same bot and channel", async () => {
  const f = setup(),
    { i, s } = await draft(f),
    send = f.ch.send;
  await prisma.makerSession.update({
    where: { id: s.id },
    data: { destinationChannelId: f.ch.id },
  });
  f.ch.send = async (payload) => {
    await send(payload);
    throw Error("ack lost");
  };
  await assert.rejects(
    async () => S.publishSession(i, await C.session(i, s.id)),
    /confirmar/,
  );
  const pub = await prisma.makerPublication.findFirst(),
    actual = f.sent.at(-1).m,
    op = await C.action(i, "REGISTER", pub.id, {});
  const modal = interaction(f.g, "maker-form:register:" + op.id, {
    message: actual.id,
  });
  await I.execute(modal);
  assert.equal((await S.publication(f.g.id, pub.id)).messageId, actual.id);
  assert.equal(f.sent.length, 1);
  valid(last(modal));
});
test("message recovery rejects an unrelated operational bot message", async () => {
  const f = setup(),
    { i, s } = await draft(f),
    other = await f.ch.send(
      Doc.render({
        ...Doc.blank(),
        blocks: [
          { id: Doc.uid(), type: "text", text: "Mensagem de outro sistema" },
        ],
      }),
    );
  const pub = await prisma.makerPublication.create({
    data: {
      id: Doc.uid(),
      guildId: f.g.id,
      channelId: f.ch.id,
      name: s.name,
      snapshotJson: s.documentJson,
      status: "UNCERTAIN",
    },
  });
  const op = await C.action(i, "REGISTER", pub.id, {}),
    modal = interaction(f.g, "maker-form:register:" + op.id, {
      message: other.id,
    });
  await I.execute(modal);
  assert.equal((await S.publication(f.g.id, pub.id)).messageId, null);
  assert.match(modal.calls.at(-1)[1].content, /não corresponde/);
});
test("role association and publication work through real select/modal/confirmation handlers", async () => {
  const f = setup(),
    p = await R.create(f.g.id, f.g.actor.id);
  await prisma.reactionRolePanel.update({
    where: { id: p.id },
    data: { channelId: f.ch.id },
  });
  const pick = interaction(f.g, "maker-select:r-role:" + p.id + ":0", {}, [
    f.role.id,
  ]);
  await I.execute(pick);
  const modal = pick.calls.at(-1)[1].toJSON(),
    save = interaction(f.g, modal.custom_id, { emoji: "🎮" });
  await I.execute(save);
  valid(last(save));
  const updated = await R.panel(f.g.id, p.id),
    publish = interaction(
      f.g,
      "maker:r-publish:" + p.id + ":" + updated.revision,
    );
  await I.execute(publish);
  const op = await prisma.makerAction.findFirst({
    where: { kind: "ROLE_PUBLISH" },
  });
  await I.execute(interaction(f.g, "maker:confirm:" + op.id));
  assert.equal((await R.panel(f.g.id, p.id)).status, "ACTIVE");
  assert.equal(f.sent.length, 1);
});
test("cleared reaction seeds are diagnosed and republishing reuses the original message", async () => {
  const f = setup(),
    e = await rolePanel(f);
  e.message.reactions.cache.clear();
  await R.reactionsCleared(e.message);
  const report = await R.inspect(f.g, e.p.id);
  assert.match(report.problems.join(" "), /Faltam reações/);
  await R.publish(f.g, e.p.id, (await R.panel(f.g.id, e.p.id)).revision);
  assert.equal(f.sent.length, 1);
  assert.equal((await R.panel(f.g.id, e.p.id)).status, "ACTIVE");
  assert.equal(e.message.reactions.cache.size, 1);
});
