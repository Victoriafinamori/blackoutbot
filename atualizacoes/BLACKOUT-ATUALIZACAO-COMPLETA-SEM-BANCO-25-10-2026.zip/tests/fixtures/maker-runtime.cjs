"use strict";
const assert = require("node:assert/strict"),
  D = require("discord.js"),
  fs = require("node:fs");
const { fixture, prisma, db } = require("./social-runtime.cjs");
const Doc = require("../../app/message-maker/document"),
  S = require("../../app/message-maker/service"),
  R = require("../../app/message-maker/roles"),
  V = require("../../app/message-maker/views"),
  C = require("../../app/message-maker/common"),
  I = require("../../app/message-maker/interactions"),
  Compat = require("../../app/utils/componentMessages");
function json(p) {
  return JSON.parse(JSON.stringify(p));
}
function valid(p) {
  const q = json(p);
  assert.ok(Number(q.flags) & D.MessageFlags.IsComponentsV2);
  assert.equal((q.embeds || []).length, 0);
  assert.ok(Doc.countComponents(q.components) <= 40);
  assert.ok(Doc.textLength(q.components) <= 4000);
  const walk = (cs) => {
    for (const c of cs) {
      if (c.custom_id) assert.ok(c.custom_id.length <= 100, c.custom_id);
      if (c.options) {
        assert.ok(c.options.length >= 1 && c.options.length <= 25);
        for (const o of c.options) {
          assert.ok(o.label.length <= 100);
          assert.ok(o.value.length <= 100);
        }
      }
      if (c.components) walk(c.components);
      if (c.accessory) walk([c.accessory]);
    }
  };
  walk(q.components);
  return q;
}
function setup() {
  const f = fixture(),
    g = f.g;
  g.roles.cache = new D.Collection();
  g.emojis = { cache: new D.Collection() };
  g.client.emojis = { cache: new D.Collection() };
  for (let n = 11; n <= 13; n++) {
    const r = {
      id: String(BigInt(g.id) + BigInt(n)),
      name: ["Gamer", "Futebol", "Equipe"][n - 11],
      managed: false,
      editable: true,
      permissions: { has: () => false },
    };
    g.roles.cache.set(r.id, r);
  }
  g.roles.fetch = async (id) => g.roles.cache.get(id) || null;
  const fetch = g.members.fetch.bind(g.members);
  g.members.fetch = async (arg) =>
    fetch(typeof arg === "string" ? arg : arg.user);
  const roleCalls = [];
  for (const m of g.members.cache.values()) {
    m.roles.add = async (id) => {
      roleCalls.push(["add", m.id, id]);
      m.roles.cache.set(id, g.roles.cache.get(id));
      return m;
    };
    m.roles.remove = async (id) => {
      roleCalls.push(["remove", m.id, id]);
      m.roles.cache.delete(id);
      return m;
    };
  }
  for (const ch of g.channels.cache.values()) {
    const send = ch.send.bind(ch),
      fetchMessage = ch.messages.fetch;
    ch.messages.fetch = async (id) => {
      const m = await fetchMessage(id);
      if (!m) throw Object.assign(Error("Unknown message"), { code: 10008 });
      return m;
    };
    ch.send = async (p) => {
      const m = await send(p);
      m.author = g.client.user;
      m.guildId = g.id;
      m.reactions = { cache: new D.Collection() };
      m.raw = p;
      const edit = m.edit;
      m.edit = async (next) => {
        await edit(next);
        m.raw = next;
        return m;
      };
      m.react = async (value) => {
        const custom = /^[0-9]+$/.test(value),
          key = custom ? "c:" + value : "u:" + value.replace(/\uFE0F/g, "");
        if (!m.reactions.cache.has(key)) {
          const users = new D.Collection([
            [g.client.user.id, { ...g.client.user, bot: true }],
          ]);
          const r = {
            emoji: {
              id: custom ? value : null,
              name: custom ? "custom" : value,
            },
            message: m,
            users: {
              cache: users,
              fetch: async ({ limit = 100, after } = {}) =>
                new D.Collection(
                  [...users]
                    .filter(([id]) => !after || BigInt(id) > BigInt(after))
                    .sort(([a], [b]) => (BigInt(a) < BigInt(b) ? -1 : 1))
                    .slice(0, limit),
                ),
            },
          };
          m.reactions.cache.set(key, r);
        }
        return m.reactions.cache.get(key);
      };
      return m;
    };
  }
  const ch = [...g.channels.cache.values()][0],
    role = [...g.roles.cache.values()][0];
  return { ...f, ch, role, roleCalls };
}
function interaction(g, customId, fields = {}, values = [], options = {}) {
  const calls = [],
    i = {
      guild: g,
      client: g.client,
      user: options.user || g.actor.user,
      customId,
      values,
      channelId: [...g.channels.cache.keys()][0],
      message: {
        id: options.messageId || "100000000000000050",
        flags: { has: () => options.v2 !== false },
      },
      deferred: false,
      replied: false,
      fields: { getTextInputValue: (k) => fields[k] ?? "" },
      isFromMessage: () => true,
      isButton: () =>
        customId.startsWith("maker:") ||
        customId.startsWith("adm-nav:") ||
        customId.startsWith("embedv2:"),
      isAnySelectMenu: () =>
        customId.startsWith("maker-select:") ||
        customId.startsWith("embedv2-select:"),
      isStringSelectMenu: () => customId.startsWith("maker-select:"),
      isChatInputCommand: () => false,
      isModalSubmit: () => customId.startsWith("maker-form:"),
      isRepliable: () => true,
      async deferUpdate() {
        i.deferred = true;
        calls.push(["deferUpdate"]);
      },
      async deferReply() {
        i.deferred = true;
        calls.push(["deferReply"]);
      },
      async update(p) {
        i.replied = true;
        calls.push(["update", p]);
      },
      async editReply(p) {
        calls.push(["editReply", p]);
      },
      async reply(p) {
        i.replied = true;
        calls.push(["reply", p]);
      },
      async followUp(p) {
        calls.push(["followUp", p]);
      },
      async showModal(p) {
        calls.push(["modal", p]);
      },
      calls,
    };
  return i;
}
const last = (i) =>
  i.calls
    .filter(([m, p]) => ["update", "editReply"].includes(m) && p?.components)
    .at(-1)?.[1];
async function rolePanel(f, extra = {}) {
  const p = await R.create(f.g.id, f.g.actor.id, Doc.blank(), "Jogos");
  await prisma.reactionRolePanel.update({
    where: { id: p.id },
    data: { channelId: f.ch.id, ...extra },
  });
  const b = await R.addBinding(f.g, p.id, f.role.id, "🎮");
  await R.publish(f.g, p.id, (await R.panel(f.g.id, p.id)).revision);
  const current = await R.panel(f.g.id, p.id),
    pub = await S.publication(f.g.id, current.publicationId),
    message = await f.ch.messages.fetch(pub.messageId);
  return {
    p: current,
    b,
    pub,
    message,
    reaction: message.reactions.cache.get("u:🎮"),
  };
}
async function draft(f, extra = {}) {
  const i = interaction(f.g, "maker:create");
  const s = await S.start(i, extra);
  return { i, s };
}

module.exports={setup,interaction,valid,last,rolePanel,draft,prisma,Doc,S,R,V,C,I,Compat,json};
