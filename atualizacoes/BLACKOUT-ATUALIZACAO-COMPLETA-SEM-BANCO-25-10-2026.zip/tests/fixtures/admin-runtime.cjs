const {Collection,ChannelType,PermissionFlagsBits}=require('discord.js');
const {Prisma}=require('@prisma/client');
const models=new Map(Prisma.dmmf.datamodel.models.map(m=>[m.name[0].toLowerCase()+m.name.slice(1),m]));
const store=new Map(),lists=new Map(),writes=[],sends=[];
let currentGuild='100000000000000001';
function defaults(name,guildId=currentGuild){const out={};for(const f of models.get(name)?.fields||[]){if(f.kind==='object')continue;const d=f.default;out[f.name]=d&&typeof d==='object'?(d.name==='now'?new Date():f.type==='Int'?1:'example-'+name):d!==undefined?d:f.isList?[]:!f.isRequired?null:f.type==='DateTime'?new Date():['Int','Float','BigInt'].includes(f.type)?0:f.type==='Boolean'?false:''}return {...out,id:out.id||'example-'+name,guildId}}
function get(name,guildId=currentGuild){const key=name+':'+guildId;if(!store.has(key))store.set(key,defaults(name,guildId));return store.get(key)}
function gid(where){return where?.guildId||where?.guildId_step?.guildId||currentGuild}
const prisma=new Proxy({}, {get(_,name){if(name==='$transaction')return async fn=>typeof fn==='function'?fn(prisma):Promise.all(fn);return {
  findUnique:async({where}={})=>/config$/i.test(name)||name==='memberRiseStage'?get(name,gid(where)):null,
  findFirst:async({where}={})=>name==='registrationPage'?(lists.get(name)||[]).find(p=>(!where.id||p.id===where.id)&&(!where.guildId||p.guildId===where.guildId))||null:null,
  findMany:async({where,orderBy,skip=0,take=100}={})=>{let v=(lists.get(name)||[]).filter(p=>(!where?.guildId||p.guildId===where.guildId)&&(!where?.id||p.id===where.id));if(orderBy?.order)v=v.slice().sort((a,b)=>a.order-b.order);return v.slice(skip,skip+take)},
  count:async({where}={})=>(lists.get(name)||[]).filter(p=>!where?.guildId||p.guildId===where.guildId).length,
  upsert:async({where,create,update})=>{const r=get(name,gid(where));if(Object.keys(update||{}).length){writes.push([name,gid(where),update]);Object.assign(r,update)}return r},
  update:async({where,data})=>{const r=name==='registrationPage'?(lists.get(name)||[]).find(p=>p.id===where.id):get(name,gid(where));if(!r)throw Error('Missing record');writes.push([name,gid(where),data]);Object.assign(r,data);return r},
  create:async({data})=>{writes.push([name,data.guildId,data]);const r={...defaults(name,data.guildId),...data,id:'created-'+writes.length};lists.set(name,[...(lists.get(name)||[]),r]);return r},
  delete:async({where})=>{writes.push([name,'delete',where]);lists.set(name,(lists.get(name)||[]).filter(p=>p.id!==where.id))},
  aggregate:async()=>({_sum:{seconds:0,count:0},_count:0}),
};}});
const db=require.resolve('../../app/database/prisma');require.cache[db]={id:db,filename:db,loaded:true,exports:{prisma}};
function fixture(){
 store.clear();lists.clear();writes.length=0;sends.length=0;
 const g={id:currentGuild,name:'Comunidade de exemplo',iconURL:()=>null,memberCount:120,roles:{cache:new Collection()},channels:{cache:new Collection()},members:{cache:new Collection()},client:{application:{emojis:{cache:new Collection()}},user:{id:'100000000000000099',username:'BLACKOUT',displayAvatarURL:()=> 'https://example.com/bot.png'}}};
 g.members.me={id:g.client.user.id,guild:g,displayName:'BLACKOUT',permissions:{has:()=>true},roles:{highest:{position:100}}};
 g.members.fetchMe=async()=>g.members.me;
 g.actor={id:'100000000000000002',guild:g,user:{id:'100000000000000002',username:'Admin',bot:false},roles:{cache:new Collection()},permissions:{has:()=>g.allowed!==false},displayAvatarURL:()=> 'https://example.com/member.png',displayName:'Admin'};
 g.members.fetch=async()=>g.actor;
 for(let n=11;n<18;n++){const r={id:String(BigInt(currentGuild)+BigInt(n)),guild:g,name:['Membro','Não registrado','Registradores','Coordenação','Eventos','Novidades','Jogos'][n-11],position:10,managed:false,editable:true};g.roles.cache.set(r.id,r)}
 g.roles.fetch=async id=>g.roles.cache.get(id)||null;
 for(let n=21;n<26;n++){const ch={id:String(BigInt(currentGuild)+BigInt(n)),guild:g,guildId:g.id,type:n===25?ChannelType.GuildCategory:ChannelType.GuildText,name:['registro','boas-vindas','logs-registro','geral','Registros privados'][n-21],isTextBased:()=>n!==25,isDMBased:()=>false,isSendable:()=>n!==25,permissionsFor:()=>({has:()=>true}),send:async p=>{sends.push(p);return{id:'100000000000000090'}},messages:{fetch:async()=>null}};g.channels.cache.set(ch.id,ch)}
 g.channels.fetch=async id=>g.channels.cache.get(id)||null;
 g.client.guilds={fetch:async()=>g};g.client.buttons=new Collection();
 const {ADM_EMOJI_NAMES}=require('../../app/utils/admEmojis');Object.values(ADM_EMOJI_NAMES).forEach((name,n)=>{const id=String(BigInt(currentGuild)+100n+BigInt(n));g.client.application.emojis.cache.set(id,{id,name})});
 const rc=get('registrationConfig');Object.assign(rc,{registeredRoleIds:[...g.roles.cache.keys()][0],unregisteredRoleIds:[...g.roles.cache.keys()][1],registrarRoleIds:[...g.roles.cache.keys()][2],leaderRoleIds:[...g.roles.cache.keys()][3],panelChannelId:[...g.channels.cache.keys()][0],registrationCategoryId:[...g.channels.cache.keys()][4],logChannelId:[...g.channels.cache.keys()][2],panelButtonLabel:'Iniciar registro',panelButtonStyle:'PRIMARY'});
 lists.set('registrationPage',[{id:'page-a',guildId:g.id,name:'Interesses',question:'Quais assuntos você mais gosta?',description:'Escolha até duas opções.',required:true,maxChoices:2,roleIds:[...g.roles.cache.keys()].slice(4,7).join(','),order:1},{id:'page-b',guildId:g.id,name:'Notificações',question:'Quais avisos deseja receber?',description:'Esta etapa é opcional.',required:false,maxChoices:1,roleIds:[...g.roles.cache.keys()].slice(4,6).join(','),order:2}]);
 return g;
}
function interaction(g,customId,values=[],fields={}){const calls=[];const i={guild:g,client:g.client,customId,values,user:g.actor.user,message:{id:'100000000000000050'},deferred:false,replied:false,isFromMessage:()=>true,isStringSelectMenu:()=>true,isButton:()=>true,
 fields:{getTextInputValue:key=>fields[key]??'',getUploadedFiles:()=>new Collection()},
 async update(p){calls.push(['update',p]);i.replied=true},async reply(p){calls.push(['reply',p]);i.replied=true},async editReply(p){calls.push(['editReply',p])},async followUp(p){calls.push(['followUp',p])},async deferUpdate(){calls.push(['deferUpdate']);i.deferred=true},async deferReply(){calls.push(['deferReply']);i.deferred=true},async showModal(p){calls.push(['modal',p])},calls};return i}
function validate(p){if(!p?.embeds?.length)throw Error('Missing embeds');let total=0;for(const b of p.embeds){const e=b.toJSON?b.toJSON():b;if((e.title?.length||0)>256||(e.description?.length||0)>4096||(e.fields?.length||0)>25)throw Error('Embed limit');for(const f of e.fields||[])if(f.name.length>256||f.value.length>1024||!f.value)throw Error('Field limit');total+=(e.title?.length||0)+(e.description?.length||0)+(e.footer?.text?.length||0)+(e.author?.name?.length||0)+(e.fields||[]).reduce((n,f)=>n+f.name.length+f.value.length,0)}if(total>6000)throw Error('Total embed limit');if((p.components?.length||0)>5)throw Error('Row limit');for(const r of p.components||[]){const row=r.toJSON?r.toJSON():r;if(row.components.length>5)throw Error('Component limit');for(const c of row.components){if(c.custom_id?.length>100)throw Error('ID limit');if(c.options){if(c.options.length<1||c.options.length>25)throw Error('Option limit');for(const o of c.options)if(!o.label||o.label.length>100||o.value.length>100||(o.description?.length||0)>100)throw Error('Option text limit')}}}return p}
module.exports={fixture,interaction,validate,prisma,get,lists,writes,sends};
