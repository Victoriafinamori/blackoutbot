'use strict';
const D=require('discord.js');
const base=require('./maker-runtime.cjs');
const C=require('../../app/security/config'),E=require('../../app/security/entry'),M=require('../../app/security/messages'),A=require('../../app/security/audit'),L=require('../../app/security/locks'),I=require('../../app/security/interactions'),V=require('../../app/security/views'),R=require('../../app/security/reviews'),N=require('../../app/security/incidents'),Assets=require('../../app/security/assets');
const {prisma}=base;
function setup(){
 const f=base.setup(),g=f.g,acts=[],bans=new Map(),auditEntries=new D.Collection();let serial=500n;
 C.clearConfig();M.resetWindows();require('../../app/logging/config').clearLogSettingsCache();
 g.ownerId='100000000000000088';
 for(const m of g.members.cache.values()){
  m.user.createdTimestamp=Date.now()-30*86400000;m.joinedTimestamp=Date.now();m.manageable=true;m.moderatable=!m.user.bot;m.kickable=true;m.communicationDisabledUntilTimestamp=null;
  m.roles.remove=async(value)=>{for(const id of Array.isArray(value)?value:[value]){f.roleCalls.push(['remove',m.id,id]);m.roles.cache.delete(id);}return m;};
  m.roles.add=async(value)=>{for(const id of Array.isArray(value)?value:[value]){f.roleCalls.push(['add',m.id,id]);m.roles.cache.set(id,g.roles.cache.get(id));}return m;};
  m.timeout=async(ms)=>{acts.push(['timeout',m.id,ms]);m.communicationDisabledUntilTimestamp=ms==null?null:Date.now()+ms;return m;};
  m.kick=async()=>{acts.push(['kick',m.id]);g.members.cache.delete(m.id);};
 }
 const fetch=g.members.fetch;
 g.members.fetch=async(arg)=>{try{return await fetch(arg);}catch{throw Object.assign(Error('Unknown member'),{code:10007});}};
 g.members.unban=async(id)=>{acts.push(['unban',id]);bans.delete(id);};
 g.bans={fetch:async(id)=>{if(!bans.has(id))throw Object.assign(Error('Unknown ban'),{code:10026});return bans.get(id);}};
 g.fetchAuditLogs=async({type})=>({entries:new D.Collection([...auditEntries].filter(([,e])=>type===undefined||e.action===type).reverse())});
 for(const role of g.roles.cache.values()){
  role.permissions=new D.PermissionsBitField();
  role.setPermissions=async(bits)=>{acts.push(['permissions',role.id,String(bits)]);role.permissions=new D.PermissionsBitField(bits);return role;};
 }
 for(const ch of g.channels.cache.values()){
  const cache=new D.Collection([[g.id,{id:g.id,type:0,allow:new D.PermissionsBitField([D.PermissionFlagsBits.ViewChannel,D.PermissionFlagsBits.SendMessages]),deny:new D.PermissionsBitField()}]]);
  ch.permissionOverwrites={cache,delete:async(id)=>{acts.push(["overwriteDelete",ch.id,id]);cache.delete(id);},set:async(values)=>{acts.push(['overwrites',ch.id,structuredClone(values)]);cache.clear();for(const p of values)cache.set(p.id,{...p,allow:new D.PermissionsBitField(BigInt(p.allow)),deny:new D.PermissionsBitField(BigInt(p.deny))});return ch;}};
 }
 Object.entries(Assets.ICONS).forEach(([key,name],n)=>g.client.application.emojis.cache.set(String(200000000000000101n+BigInt(n)),{id:String(200000000000000101n+BigInt(n)),name}));
 function audit(action,targetId,changes=[],actorId=g.actor.id){const e={id:String(100000000000000000n+serial++),action,targetId,executorId:actorId,createdTimestamp:Date.now(),changes};auditEntries.set(e.id,e);return e;}
 function message(text,extra={}){const m=extra.member||g.other,ch=extra.channel||f.ch;return {id:String(100000000000000000n+serial++),guild:g,channelId:ch.id,channel:ch,member:m,author:m.user,content:text,delete:async()=>acts.push(['delete',m.id]),...extra};}
 return {...f,acts,bans,auditEntries,audit,message};
}
async function configure(f,key,patch){const {config,revision}=await C.settings(f.g.id,true);return C.save(f.g.id,revision,C.editRule(config,key,patch));}
function interaction(g,id,fields={},values=[],options={}){const i=base.interaction(g,id,fields,values,options);i.isButton=()=>id.startsWith('security:')||id.startsWith('adm-nav:');i.isAnySelectMenu=()=>id.startsWith('security-select:');i.isStringSelectMenu=()=>id.startsWith('security-select:');i.isModalSubmit=()=>id.startsWith('security-form:');return i;}
function ids(p){return JSON.stringify(p).match(/security:confirm:[a-f0-9-]+/g)||[];}
module.exports={setup,configure,interaction,ids,valid:base.valid,last:base.last,prisma,D,C,E,M,A,L,I,V,R,N,Assets};
