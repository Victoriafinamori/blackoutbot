"use strict";
// Real SQLite constraints, deterministic Discord stubs; no network or bot login.
const { DatabaseSync } = require("node:sqlite"),
  { Prisma } = require("@prisma/client"),
  { randomUUID } = require("node:crypto"),
  fs = require("node:fs"),
  path = require("node:path");
const { Collection, ChannelType } = require("discord.js");
const db = new DatabaseSync(":memory:"),
  models = new Map(
    Prisma.dmmf.datamodel.models.map((m) => [
      m.name[0].toLowerCase() + m.name.slice(1),
      m,
    ]),
  );
const modelsUsed = [
  "GuildConfig",
  "CustomEmbed",
  "CustomEmbedButton",
  "GamesChatConfig",
  "MysteryBoxConfig",
  "MysteryReward",
  "MysteryEvent",
  "MysteryBox",
  "MysteryOpening",
  "MysteryDelivery",
  "TermoConfig",
  "TermoWord",
  "TermoRound",
  "TermoGame",
  "TermoGuess",
  "TermoStat",
  "BingoMatch",
  "BingoDraw",
  "BingoCard",
  "BingoWinner",
  "BingoConfig",
  "BingoOrder",
  "WarSettings",
  "WarGame",
  "WarQuestion",
  "WarSelection",
  "WarPlayer",
  "WarRound",
  "WarAnswer",
  "SocialConfig",
  "SocialPublication",
  "SocialLike",
  "SocialComment",
  "SocialHighlight",
  "SocialHighlightGrant",
  "SocialHighlightPeriod",
  "SocialUserPreference",
  "SocialBlock",
  "SocialDm",
  "BotAdmin",
  "ServerLogSettings",
  "FilterRule",
  "RadioConfig",
  "RadioTrack",
  "AnonymousPhotoConfig",
  "AnonymousMessageConfig",
  "AnonymousPhotoSubmission",
  "AnonymousMessageSubmission",
];
const fieldMap = (m) =>
  new Map(m.fields.filter((f) => f.kind !== "object").map((f) => [f.name, f]));
for (const name of modelsUsed) {
  const m = models.get(name[0].toLowerCase() + name.slice(1));
  db.exec(
    'CREATE TABLE "' +
      name +
      '"(' +
      [...fieldMap(m)]
        .filter(
          ([k]) =>
            !(
              name === "TermoRound" &&
              ["maxAttemptsSnapshot", "wordLengthSnapshot"].includes(k)
            ) &&
            !(
              name === "TermoGame" &&
              ["pointsEarned", "sharedMessageId"].includes(k)
            ),
        )
        .map(
          ([k, f]) =>
            '"' +
            k +
            '" ' +
            (["Int", "Float", "Boolean", "BigInt"].includes(f.type)
              ? "NUMERIC"
              : "TEXT") +
            (f.isId ? " PRIMARY KEY" : ""),
        )
        .join(",") +
      ")",
  );
}
db.exec(
  fs.readFileSync(
    path.join(
      __dirname,
      "../../prisma/migrations/20261022010000_social_experience/migration.sql",
    ),
    "utf8",
  ),
);
db.exec(
  fs.readFileSync(
    path.join(
      __dirname,
      "../../prisma/migrations/20261022140000_games_experience/migration.sql",
    ),
    "utf8",
  ),
);
db.exec(fs.readFileSync(path.join(__dirname, "../../prisma/migrations/20261023180000_message_maker_reaction_roles/migration.sql"), "utf8"));
db.exec(fs.readFileSync(path.join(__dirname, "../../prisma/migrations/20261024180000_security_center/migration.sql"), "utf8"));
for (const name of modelsUsed) {
  const m = models.get(name[0].toLowerCase() + name.slice(1));
  for (const keys of [
    ...m.uniqueFields,
    ...m.fields.filter((f) => f.isUnique && !f.isId).map((f) => [f.name]),
  ])
    db.exec(
      'CREATE UNIQUE INDEX IF NOT EXISTS "test_' +
        name +
        "_" +
        keys.join("_") +
        '" ON "' +
        name +
        '"(' +
        keys.map((k) => '"' + k + '"').join(",") +
        ")",
    );
}
let writes = [];
const wire = (v) =>
  v instanceof Date ? v.toISOString() : typeof v === "boolean" ? Number(v) : v;
function defaults(m) {
  const out = {};
  for (const [k, f] of fieldMap(m)) {
    const d = f.default;
    out[k] =
      d && typeof d === "object"
        ? d.name === "now"
          ? new Date()
          : randomUUID()
        : d !== undefined
          ? d
          : !f.isRequired
            ? null
            : f.type === "DateTime"
              ? new Date()
              : undefined;
  }
  return out;
}
function decode(m, row) {
  if (!row) return null;
  const r = { ...row };
  for (const [k, f] of fieldMap(m))
    if (r[k] != null) {
      if (f.type === "DateTime") r[k] = new Date(r[k]);
      if (f.type === "Boolean") r[k] = Boolean(r[k]);
    }
  return r;
}
function match(m, where = {}, params = []) {
  const fields = fieldMap(m),
    parts = [];
  for (const [k, v] of Object.entries(where)) {
    if (v === undefined) continue;
    if (k === "OR" || k === "AND") {
      parts.push(
        "(" +
          v
            .map((x) => match(m, x, params))
            .join(k === "OR" ? " OR " : " AND ") +
          ")",
      );
      continue;
    }
    if (!fields.has(k)) {
      if (
        v &&
        typeof v === "object" &&
        Object.keys(v).every((f) => fields.has(f))
      ) {
        parts.push(match(m, v, params));
        continue;
      }
      const rel = m.fields.find((f) => f.name === k && f.kind === "object");
      if (rel && rel.relationFromFields.length) {
        const target = models.get(
            rel.type[0].toLowerCase() + rel.type.slice(1),
          ),
          join = rel.relationFromFields
            .map(
              (f, n) =>
                '"' +
                target.name +
                '"."' +
                rel.relationToFields[n] +
                '"="' +
                m.name +
                '"."' +
                f +
                '"',
            )
            .join(" AND ");
        parts.push(
          'EXISTS (SELECT 1 FROM "' +
            target.name +
            '" WHERE ' +
            join +
            " AND " +
            match(target, v, params) +
            ")",
        );
        continue;
      }
      throw Error("Unsupported test where " + m.name + "." + k);
    }
    const col = '"' + m.name + '"."' + k + '"';
    if (v === null) {
      parts.push(col + " IS NULL");
      continue;
    }
    if (v && typeof v === "object" && !(v instanceof Date)) {
      for (const [op, value] of Object.entries(v)) {
        if (op === "in" || op === "notIn") {
          parts.push(
            col +
              (op === "in" ? " IN (" : " NOT IN (") +
              value.map(() => "?").join(",") +
              ")",
          );
          params.push(...value.map(wire));
        } else if (op === "not" && value === null) {
          parts.push(col + " IS NOT NULL");
        } else if (op === "contains") {
          parts.push(col + " LIKE ?");
          params.push("%" + value + "%");
        } else {
          const operators = {
            gte: ">=",
            gt: ">",
            lte: "<=",
            lt: "<",
            equals: "=",
            not: "!=",
          };
          if (!operators[op]) throw Error("Unknown operator " + op);
          parts.push(col + " " + operators[op] + " ?");
          params.push(wire(value));
        }
      }
    } else {
      parts.push(col + " = ?");
      params.push(wire(v));
    }
  }
  return parts.join(" AND ") || "1";
}
async function enriched(m, r, include) {
  if (!r || !include) return r;
  const out = { ...r };
  for (const [key, options] of Object.entries(include)) {
    if (!options) continue;
    const rel = m.fields.find((f) => f.name === key && f.kind === "object");
    if (!rel) throw Error("Unknown include " + m.name + "." + key);
    const target = models.get(rel.type[0].toLowerCase() + rel.type.slice(1)),
      args = options === true ? {} : options;
    let where, reverse;
    if (rel.relationFromFields.length)
      where = Object.fromEntries(
        rel.relationToFields.map((f, n) => [f, r[rel.relationFromFields[n]]]),
      );
    else {
      reverse = target.fields.find(
        (f) =>
          f.kind === "object" &&
          f.type === m.name &&
          f.relationName === rel.relationName &&
          f.relationFromFields.length,
      );
      if (!reverse) throw Error("Unknown reverse " + key);
      where = Object.fromEntries(
        reverse.relationFromFields.map((f, n) => [
          f,
          r[reverse.relationToFields[n]],
        ]),
      );
    }
    const method = rel.isList ? "findMany" : "findFirst";
    out[key] = await prisma[
      target.name[0].toLowerCase() + target.name.slice(1)
    ][method]({ ...args, where: { ...where, ...(args.where || {}) } });
  }
  return out;
}
function delegate(m) {
  const name = '"' + m.name + '"';
  const where = (w) => {
    const p = [];
    return [match(m, w, p), p];
  };
  const select = (args = {}) => {
    const [sql, params] = where(args.where);
    const order = (
      Array.isArray(args.orderBy)
        ? args.orderBy
        : args.orderBy
          ? [args.orderBy]
          : []
    )
      .flatMap((o) => Object.entries(o))
      .map(([k, v]) => '"' + k + '" ' + (v === "desc" ? "DESC" : "ASC"))
      .join(",");
    let q =
      "SELECT * FROM " +
      name +
      " WHERE " +
      sql +
      (order ? " ORDER BY " + order : "");
    if (args.take !== undefined) {
      q += " LIMIT ? OFFSET ?";
      params.push(args.take, args.skip || 0);
    }
    return db
      .prepare(q)
      .all(...params)
      .map((r) => decode(m, r));
  };
  const d = {
    findUnique: async (a) => enriched(m, select(a)[0] || null, a?.include),
    findUniqueOrThrow: async (a) => {
      const r = await d.findUnique(a);
      if (!r) throw Error("Missing " + m.name);
      return r;
    },
    findFirst: async (a) =>
      enriched(m, select({ ...a, take: 1 })[0] || null, a?.include),
    findMany: async (a) =>
      Promise.all(select(a).map((r) => enriched(m, r, a?.include))),
    count: async (a = {}) => {
      const [sql, p] = where(a.where);
      return db
        .prepare("SELECT COUNT(*) AS n FROM " + name + " WHERE " + sql)
        .get(...p).n;
    },
    create: async ({ data, include }) => {
      const r = { ...defaults(m), ...data };
      for (const [k, f] of fieldMap(m)) if (f.isUpdatedAt) r[k] = new Date();
      const entries = Object.entries(r).filter(([, v]) => v !== undefined);
      writes.push([m.name, "create", data]);
      db.prepare(
        "INSERT INTO " +
          name +
          "(" +
          entries.map(([k]) => '"' + k + '"').join(",") +
          ") VALUES(" +
          entries.map(() => "?").join(",") +
          ")",
      ).run(...entries.map(([, v]) => wire(v)));
      return enriched(m, decode(m, r), include);
    },
    updateMany: async ({ where: w, data }) => {
      const params = [],
        set = [];
      for (const [k, v] of Object.entries(data)) {
        if (v === undefined) continue;
        if (v && typeof v === "object" && !(v instanceof Date)) {
          if (v.increment !== undefined) {
            set.push('"' + k + '" = "' + k + '" + ?');
            params.push(v.increment);
            continue;
          }
          if (v.decrement !== undefined) {
            set.push('"' + k + '" = "' + k + '" - ?');
            params.push(v.decrement);
            continue;
          }
          throw Error("Unknown update");
        }
        set.push('"' + k + '" = ?');
        params.push(wire(v));
      }
      for (const [k, f] of fieldMap(m))
        if (f.isUpdatedAt) {
          set.push('"' + k + '" = ?');
          params.push(new Date().toISOString());
        }
      const p = [];
      const sql = match(m, w, p);
      writes.push([m.name, "updateMany", data]);
      return {
        count: db
          .prepare("UPDATE " + name + " SET " + set.join(",") + " WHERE " + sql)
          .run(...params, ...p).changes,
      };
    },
    update: async (a) => {
      const prior = select({ where: a.where })[0];
      if (!prior) throw Error("Missing " + m.name);
      await d.updateMany(a);
      const idField = m.fields.find((f) => f.isId).name;
      return enriched(
        m,
        select({ where: { [idField]: prior[idField] } })[0],
        a.include,
      );
    },
    createMany: async ({ data }) => {
      for (const item of data) await d.create({ data: item });
      return { count: data.length };
    },
    groupBy: async (a) => {
      const [sql, p] = where(a.where),
        sums = Object.keys(a._sum || {}),
        columns = [
          ...a.by.map((k) => '"' + k + '"'),
          'COUNT(*) AS "count_all"',
          ...sums.map((k) => 'SUM("' + k + '") AS "sum_' + k + '"'),
        ];
      const order = (a.orderBy || [])
        .flatMap((o) => Object.entries(o))
        .map(([k, v]) =>
          k === "_sum"
            ? Object.entries(v)
                .map(
                  ([f, dir]) =>
                    '"sum_' + f + '" ' + (dir === "desc" ? "DESC" : "ASC"),
                )
                .join(",")
            : '"' + k + '" ' + (v === "desc" ? "DESC" : "ASC"),
        )
        .join(",");
      const q =
        "SELECT " +
        columns.join(",") +
        " FROM " +
        name +
        " WHERE " +
        sql +
        " GROUP BY " +
        a.by.map((k) => '"' + k + '"').join(",") +
        (order ? " ORDER BY " + order : "") +
        (a.take ? " LIMIT " + Number(a.take) : "");
      return db
        .prepare(q)
        .all(...p)
        .map((r) => ({
          ...Object.fromEntries(a.by.map((k) => [k, r[k]])),
          _count: a._count === true ? r.count_all : { _all: r.count_all },
          _sum: Object.fromEntries(sums.map((k) => [k, r["sum_" + k]])),
        }));
    },
    upsert: async (a) => {
      const r = select({ where: a.where })[0];
      if (r)
        return Object.keys(a.update).length
          ? d.update({ where: a.where, data: a.update, include: a.include })
          : enriched(m, r, a.include);
      return d.create({ data: a.create, include: a.include });
    },
    deleteMany: async (a = {}) => {
      const [sql, p] = where(a.where);
      return {
        count: db.prepare("DELETE FROM " + name + " WHERE " + sql).run(...p)
          .changes,
      };
    },
    delete: async (a) => {
      const r = select(a)[0];
      await d.deleteMany(a);
      return r;
    },
  };
  return d;
}
const delegates = new Map();
let transactionTail = Promise.resolve();
const prisma = new Proxy(
  {},
  {
    get(_, key) {
      if (key === "$transaction")
        return async (fn) => {
          if (typeof fn !== "function") return Promise.all(fn);
          const work = transactionTail.then(async () => {
            db.exec("BEGIN");
            try {
              const v = await fn(prisma);
              db.exec("COMMIT");
              return v;
            } catch (e) {
              db.exec("ROLLBACK");
              throw e;
            }
          });
          transactionTail = work.catch(() => null);
          return work;
        };
      if (!delegates.has(key)) delegates.set(key, delegate(models.get(key)));
      return delegates.get(key);
    },
  },
);
const moduleId = require.resolve("../../app/database/prisma");
require.cache[moduleId] = {
  id: moduleId,
  filename: moduleId,
  loaded: true,
  exports: { prisma },
};
function fixture() {
  for (const m of [...models.values()]) {
    try {
      db.exec('DELETE FROM "' + m.name + '"');
    } catch {}
  }
  writes.length = 0;
  const sent = [],
    edits = [],
    members = new Collection(),
    channels = new Collection();
  const g = {
    id: "100000000000000001",
    name: "BLACKOUT Comunidade",
    roles: { everyone: { id: "100000000000000001" } },
    channels: {
      cache: channels,
      fetch: async (id) => channels.get(id) || null,
    },
    members: { cache: members },
    client: {
      application: { emojis: { cache: new Collection() } },
      user: {
        id: "100000000000000099",
        displayAvatarURL: () => "https://example.com/bot.png",
      },
    },
  };
  g.client.guilds = {
    cache: new Collection([[g.id, g]]),
    fetch: async (id) => (id === g.id ? g : null),
  };
  g.client.users = {
    fetch: async (id) => {
      const m = members.get(id);
      if (!m) throw Error("Unknown user");
      return m.user;
    },
  };
  function addMember(id, admin = false) {
    const m = {
      id,
      guild: g,
      displayName: admin ? "Admin" : "Membro",
      permissions: { has: () => admin },
      roles: { cache: new Collection() },
      voice: {},
      user: {
        id,
        bot: false,
        username: admin ? "Admin" : "Membro",
        send: async (p) => {
          sent.push({ dm: true, p });
          return { id: randomUUID() };
        },
      },
    };
    members.set(id, m);
    return m;
  }
  g.actor = addMember("100000000000000002", true);
  g.other = addMember("100000000000000003");
  g.third = addMember("100000000000000004");
  g.members.me = addMember(g.client.user.id, true);
  g.members.me.user.bot = true;
  g.members.fetch = async (id) => {
    if (!members.has(id)) throw Error("Unknown member");
    return members.get(id);
  };
  g.members.fetchMe = async () => g.members.me;
  for (let n = 21; n < 26; n++) {
    const id = String(BigInt(g.id) + BigInt(n)),
      messages = new Collection();
    const ch = {
      id,
      guild: g,
      guildId: g.id,
      name: "canal-" + n,
      type: ChannelType.GuildText,
      nsfw: n >= 23,
      private: n >= 23,
      members: new Collection(),
      isTextBased: () => true,
      isDMBased: () => false,
      permissionsFor: (who) => ({
        has: () => (who?.id === g.id ? !ch.private : true),
      }),
      messages: { fetch: async (mid) => messages.get(mid) || null },
      send: async (p) => {
        const mid = String(100000000000000100n + BigInt(sent.length)),
          att = new Collection(
            (p.files || []).map((f, i) => [
              String(i),
              {
                id: String(i),
                name: f.name,
                url: `https://cdn.discordapp.com/attachments/${id}/${mid}/${f.name}`,
              },
            ]),
          ),
          m = {
            id: mid,
            channelId: id,
            guild: g,
            url: `https://discord.com/channels/${g.id}/${id}/${mid}`,
            attachments: att,
            embeds: p.embeds || [],
            components: p.components || [],
            flags: { has: () => Boolean(Number(p.flags) & 32768) },
            edit: async (value) => {
              edits.push(value);
              m.components = value.components || m.components;
              m.embeds = value.embeds || m.embeds;
              return m;
            },
            delete: async () => {
              messages.delete(mid);
            },
            react: async () => null,
          };
        sent.push({ channel: id, p, m });
        messages.set(mid, m);
        return m;
      },
    };
    channels.set(id, ch);
  }
  return { g, sent, edits, prisma, db, writes, addMember };
}
module.exports = { fixture, prisma, db, writes };
