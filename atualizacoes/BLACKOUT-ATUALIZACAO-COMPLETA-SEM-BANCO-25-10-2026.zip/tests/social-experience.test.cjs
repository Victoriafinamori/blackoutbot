"use strict";
const { test } = require("node:test"),
  assert = require("node:assert/strict"),
  { Collection, MessageFlags } = require("discord.js");
const { fixture, prisma } = require("./fixtures/social-runtime.cjs");
const C = require("../app/social-experience/common"),
  A = require("../app/social-experience/activities"),
  V = require("../app/social-experience/views"),
  R = require("../app/social-experience/radio"),
  N = require("../app/social-experience/anonymous"),
  P = require("../app/social-experience/posts"),
  S = require("../app/social/service"),
  M = require("../app/social/media");
const { validate } = require("./fixtures/admin-runtime.cjs");
// admin-runtime installs its own Prisma stub; restore the real SQLite harness.
const dbId = require.resolve("../app/database/prisma");
require.cache[dbId].exports.prisma = prisma;
function native(p) {
  if (p.flags & MessageFlags.IsComponentsV2) {
    assert.ok(!p.embeds?.length);
    assert.equal(p.content ?? null, null);
    const cards = p.components.map((c) => c.toJSON());
    assert.ok(cards.length);
    assert.ok(JSON.stringify(cards).length < 20000);
    return cards;
  }
  validate(p);
  return p;
}
async function setupSocial(g) {
  const channel = [...g.channels.cache.values()][0];
  const c = await S.socialConfig(g.id);
  await prisma.socialConfig.update({
    where: { guildId: g.id },
    data: {
      enabled: true,
      instaChannelId: channel.id,
      highlightsEnabled: false,
      postCooldownSeconds: 0,
    },
  });
  return { c, channel };
}
async function fetchStub(fn) {
  const prior = global.fetch;
  global.fetch = async () =>
    new Response(Buffer.from([0, 1, 2, 3]), {
      status: 200,
      headers: { "content-type": "video/mp4" },
    });
  try {
    return await fn();
  } finally {
    global.fetch = prior;
  }
}
function message(g, ch, name = "video.mp4", id = "100000000000000070") {
  let deleted = 0;
  const replies = [],
    m = {
      id,
      guild: g,
      channel: ch,
      channelId: ch.id,
      author: g.other.user,
      member: g.other,
      content: "Meu momento no servidor",
      attachments: new Collection([
        [
          "one",
          {
            id: "one",
            name,
            url: "https://cdn.discordapp.com/attachments/1/2/" + name,
            size: 4,
          },
        ],
      ]),
      reply: async (s) => {
        replies.push(s);
      },
      delete: async () => {
        deleted++;
      },
    };
  return { m, replies, deleted: () => deleted };
}
function interaction(g, id, fields = {}) {
  const calls = [],
    i = {
      id: "100000000000000080",
      guild: g,
      client: g.client,
      user: g.actor.user,
      customId: id,
      values: [],
      message: { id: "msg" },
      isFromMessage: () => true,
      fields: {
        getTextInputValue: (k) => fields[k] || "",
        getUploadedFiles: () => new Collection(),
      },
      deferred: false,
      replied: false,
      async deferReply() {
        i.deferred = true;
        calls.push(["deferReply"]);
      },
      async deferUpdate() {
        i.deferred = true;
        calls.push(["deferUpdate"]);
      },
      async editReply(p) {
        calls.push(["editReply", p]);
      },
      async update(p) {
        i.replied = true;
        calls.push(["update", p]);
      },
      async reply(p) {
        i.replied = true;
        calls.push(["reply", p]);
      },
      async followUp(p) {
        calls.push(["followUp", p]);
      },
      async showModal(p) {
        calls.push(["modal", p]);
      },
      calls,
    };
  return i;
}
test("new Social features default to off and do not publish while configuring", async () => {
  const { g, sent } = fixture(),
    c = await C.config(g.id);
  assert.equal(c.dynamicsEnabled, false);
  assert.equal(c.requestsEnabled, false);
  assert.equal(c.profilesEnabled, false);
  assert.equal(c.anonymousModerated, false);
  for (const page of [
    "dynamics",
    "templates",
    "participation",
    "radio",
    "anonymous",
  ])
    native(await V.adminView(g, page));
  native(await V.hub(g));
  assert.equal(sent.length, 0);
});
for (const name of ["imagem.png", "animacao.gif", "video.mp4"])
  test(
    "INSTA owns " + name + " once and preserves the file across repeated edits",
    async () => {
      const { g, sent, edits } = fixture(),
        { channel } = await setupSocial(g),
        source = message(g, channel, name);
      await fetchStub(() => S.createSocialPublication(source.m));
      const post = await prisma.socialPublication.findFirst({
        where: { guildId: g.id },
      });
      assert.equal(post.status, "ACTIVE");
      assert.equal(source.deleted(), 1);
      assert.equal(sent.length, 1);
      const card = native(sent[0].p);
      assert.match(JSON.stringify(card), /attachment:\/\/social-/);
      assert.equal(sent[0].p.files.length, 1);
      assert.equal(sent[0].m.attachments.size, 1);
      for (let n = 0; n < 3; n++) {
        await prisma.socialPublication.update({
          where: { id: post.id },
          data: { likesCount: n + 1 },
        });
        await S.refreshPublication(g, post.id);
      }
      for (const p of edits) {
        native(p);
        assert.deepEqual(p.embeds, []);
        assert.deepEqual(p.attachments, [{ id: "0" }]);
        assert.equal(p.files, undefined);
        assert.match(JSON.stringify(p.components), /attachment:\/\/social-/);
      }
      assert.match(JSON.stringify(edits.at(-1).components), /3 curtidas/);
    },
  );
test("failed public upload preserves original and records failed status", async () => {
  const { g, sent } = fixture(),
    { channel } = await setupSocial(g),
    source = message(g, channel);
  channel.send = async () => {
    throw Error("upload rejected");
  };
  await fetchStub(() =>
    assert.rejects(
      () => S.createSocialPublication(source.m),
      /upload rejected/,
    ),
  );
  assert.equal(source.deleted(), 0);
  assert.equal(sent.length, 0);
  assert.equal(
    (await prisma.socialPublication.findFirst({ where: { guildId: g.id } }))
      .status,
    "FAILED",
  );
});
test("oversize, multiple media and external fetch origins do not lose source files", async () => {
  const { g, sent } = fixture(),
    { channel } = await setupSocial(g),
    source = message(g, channel);
  source.m.attachments.first().size = 26 * 1024 * 1024;
  await S.createSocialPublication(source.m);
  assert.match(source.replies[0], /preservado/);
  source.m.attachments.first().size = 4;
  source.m.attachments.set("two", { name: "second.png" });
  await S.createSocialPublication(source.m);
  assert.match(source.replies[1], /uma mídia/);
  assert.equal(sent.length, 0);
  assert.equal(source.deleted(), 0);
  await assert.rejects(
    () => M.downloadMedia("https://example.com/movie.mp4"),
    /upload do Discord/,
  );
});
test("cross guild publication cannot be refreshed or rendered", async () => {
  const { g, edits } = fixture();
  await assert.rejects(
    () => S.publicationView(g, { guildId: "different" }),
    /outro servidor/,
  );
  const c = await S.socialConfig(g.id),
    p = await prisma.socialPublication.create({
      data: {
        guildId: "different",
        publicId: "foreign",
        configId: c.id,
        channelId: "other",
        authorId: g.other.id,
        origin: "INSTA",
        messageId: "msg",
        mediaUrl: "https://example.com/a.png",
      },
    });
  await S.refreshPublication(g, p.id);
  assert.equal(edits.length, 0);
});
test("native video previews publish only after a single use confirmation", async () => {
  const { g, sent } = fixture();
  await setupSocial(g);
  const i = interaction(g, "sx-form:post");
  i.user = g.other.user;
  const file = {
    name: "video.mp4",
    size: 4,
    url: "https://cdn.discordapp.com/attachments/1/2/video.mp4",
  };
  native(await P.draft(i, file, "Minha legenda"));
  assert.equal(sent.length, 0);
  const d = await prisma.socialSubmission.findFirst({
    where: { guildId: g.id },
  });
  const confirm = interaction(g, "sx:post-confirm:" + d.id);
  confirm.user = g.other.user;
  await fetchStub(() => P.confirm(confirm, d.id));
  assert.equal(sent.length, 1);
  assert.equal(
    (await prisma.socialSubmission.findUnique({ where: { id: d.id } })).status,
    "PUBLISHED",
  );
  await assert.rejects(() => P.confirm(confirm, d.id), /expirou|confirmada/);
  assert.equal(sent.length, 1);
});
test("draft confirmation rejects wrong actor, expired draft and current disabled INSTA", async () => {
  const { g, sent } = fixture();
  await setupSocial(g);
  const i = interaction(g, "sx-form:post"),
    file = {
      name: "imagem.png",
      size: 4,
      url: "https://cdn.discordapp.com/a.png",
    };
  await P.draft(i, file, "");
  let d = await prisma.socialSubmission.findFirst({ where: { guildId: g.id } });
  const bad = interaction(g, "sx:post-confirm:" + d.id);
  bad.user = g.other.user;
  await assert.rejects(() => P.confirm(bad, d.id), /expirou|confirmada/);
  await prisma.socialSubmission.update({
    where: { id: d.id },
    data: { expiresAt: new Date(0) },
  });
  await assert.rejects(() => P.confirm(i, d.id), /expirou/);
  assert.equal(sent.length, 0);
});
test("highlight card supports playable video and empty V2 state", async () => {
  const { g, sent, edits } = fixture(),
    { channel } = await setupSocial(g);
  const highlight = [...g.channels.cache.values()][1];
  await prisma.socialConfig.update({
    where: { guildId: g.id },
    data: { highlightsEnabled: true, highlightsChannelId: highlight.id },
  });
  await fetchStub(() => S.createSocialPublication(message(g, channel).m));
  const h = sent.find((x) => x.channel === highlight.id);
  assert.ok(h);
  native(h.p);
  assert.match(JSON.stringify(h.p), /Media|Vídeo|video/i);
  const post = await prisma.socialPublication.findFirst({
    where: { guildId: g.id },
  });
  await prisma.socialPublication.update({
    where: { id: post.id },
    data: { status: "DELETED" },
  });
  await S.refreshHighlights(g);
  const last = edits.at(-1);
  native(last);
  assert.match(JSON.stringify(last.components), /Nenhuma publicação/);
  assert.deepEqual(last.embeds, []);
});
test("automatic activities follow server timezone, interval and one publication per day", async () => {
  const { g, sent } = fixture(),
    ch = [...g.channels.cache.values()][0];
  await prisma.guildConfig.create({
    data: { guildId: g.id, timezone: "America/Sao_Paulo" },
  });
  await C.config(g.id);
  const c = await prisma.socialExperienceConfig.update({
    where: { guildId: g.id },
    data: {
      dynamicsEnabled: true,
      dynamicsChannelId: ch.id,
      dynamicsHour: 18,
      dynamicsIntervalDays: 2,
    },
  });
  await A.schedule(g, c, new Date("2026-10-21T20:59:00Z"));
  assert.equal(sent.length, 0);
  await A.schedule(g, c, new Date("2026-10-21T21:00:00Z"));
  await A.schedule(g, c, new Date("2026-10-21T22:00:00Z"));
  assert.equal(sent.length, 1);
  const current = await C.config(g.id);
  await A.schedule(g, current, new Date("2026-10-22T22:00:00Z"));
  assert.equal(sent.length, 1);
  await A.schedule(g, current, new Date("2026-10-23T22:00:00Z"));
  assert.equal(sent.length, 2);
});
test("activity answers overwrite same member response and refresh original result", async () => {
  const { g, sent, edits } = fixture(),
    ch = [...g.channels.cache.values()][0];
  await C.config(g.id);
  await prisma.socialExperienceConfig.update({
    where: { guildId: g.id },
    data: { dynamicsEnabled: true, dynamicsChannelId: ch.id },
  });
  const a = await A.publish(g, "test", "POLL");
  await A.respond(g, a.id, g.other.id, "0");
  await A.respond(g, a.id, g.other.id, "1");
  assert.equal(
    await prisma.socialActivityResponse.count({ where: { activityId: a.id } }),
    1,
  );
  assert.equal(sent.length, 1);
  assert.equal(edits.length, 2);
  native(edits.at(-1));
  await assert.rejects(() => A.respond(g, a.id, g.other.id, "99"), /inválida/);
});
test("invalid activity proposals and cross server response fail before writes", async () => {
  const { g } = fixture();
  assert.throws(
    () => A.templateData("POLL", "Escolha", ["a", "a"]),
    /diferentes/,
  );
  assert.throws(() => A.templateData("BROKEN", "Escolha", []), /inválido/);
  const a = await prisma.socialActivity.create({
    data: {
      guildId: "foreign",
      scheduleKey: "test",
      kind: "QUESTION",
      prompt: "?",
      channelId: "ch",
      status: "ACTIVE",
    },
  });
  await assert.rejects(
    () => A.respond(g, a.id, g.actor.id, "sim"),
    /disponível/,
  );
});
test("music requests persist, enforce per member limits and are claimed exactly once", async () => {
  const { g } = fixture();
  await C.config(g.id);
  await prisma.socialExperienceConfig.update({
    where: { guildId: g.id },
    data: { requestsEnabled: true, requestsLimit: 1, requestsCooldown: 30 },
  });
  const r = await R.request(g, g.other.id, "https://youtu.be/dQw4w9WgXcQ");
  assert.equal(r.status, "PENDING");
  await assert.rejects(
    () => R.request(g, g.other.id, "https://youtu.be/abcdefghijk"),
    /já tem/,
  );
  assert.equal(await R.claimNext(g.id), null);
  await R.review(g, r.id, g.actor.id, true);
  const track = await R.claimNext(g.id);
  assert.equal(track.requestId, r.id);
  assert.equal(await R.claimNext(g.id), null);
  await R.finish(track);
  assert.equal(
    (await prisma.socialRadioRequest.findUnique({ where: { id: r.id } }))
      .status,
    "PLAYED",
  );
  assert.equal(await prisma.radioTrack.count({ where: { guildId: g.id } }), 0);
});
test("radio voting counts current human listeners once and skips only with a majority", async () => {
  const { g } = fixture(),
    radio = require("../app/radio/service"),
    oldStatus = radio.getRadioRuntimeStatus,
    oldSkip = radio.skipRadioTrack;
  let skipped = 0;
  const ch = [...g.channels.cache.values()][0];
  ch.members = new Collection([
    [g.actor.id, g.actor],
    [g.other.id, g.other],
    [g.third.id, g.third],
    [g.members.me.id, g.members.me],
  ]);
  await C.config(g.id);
  await prisma.socialExperienceConfig.update({
    where: { guildId: g.id },
    data: { requestsEnabled: true },
  });
  await radio.getRadioConfig(g.id);
  await prisma.radioConfig.update({
    where: { guildId: g.id },
    data: { voiceChannelId: ch.id },
  });
  radio.getRadioRuntimeStatus = async () => ({
    playToken: "token-a",
    playerStatus: "playing",
  });
  radio.skipRadioTrack = async () => {
    skipped++;
    return true;
  };
  try {
    let v = await R.vote(g, g.actor.id, "token-a");
    assert.equal(v.votes, 1);
    assert.equal(v.needed, 2);
    v = await R.vote(g, g.actor.id, "token-a");
    assert.equal(v.votes, 1);
    assert.equal(skipped, 0);
    v = await R.vote(g, g.other.id, "token-a");
    assert.equal(v.skipped, true);
    assert.equal(skipped, 1);
    await assert.rejects(
      () => R.vote(g, g.third.id, "old-token"),
      /faixa mudou/,
    );
  } finally {
    radio.getRadioRuntimeStatus = oldStatus;
    radio.skipRadioTrack = oldSkip;
  }
});
test("optional profiles are server scoped, initially hidden and can be erased", async () => {
  const { g } = fixture(),
    F = require("../app/social-experience/profiles");
  await C.config(g.id);
  await prisma.socialExperienceConfig.update({
    where: { guildId: g.id },
    data: { profilesEnabled: true },
  });
  const p = await F.own(g, g.other.id);
  assert.equal(p.visible, false);
  await F.save(g, g.other.id, {
    bio: "Oi!",
    interests: "Música",
    games: "TERMO",
    visible: true,
  });
  native(await F.discover(g, 0, "Música"));
  const foreign = await prisma.socialProfile.create({
    data: {
      guildId: "foreign",
      userId: g.actor.id,
      bio: "Outro servidor",
      visible: true,
    },
  });
  assert.ok(!JSON.stringify(await F.discover(g)).includes(foreign.bio));
  await prisma.socialProfile.deleteMany({
    where: { guildId: g.id, userId: g.other.id },
  });
  assert.equal(
    await prisma.socialProfile.count({ where: { guildId: g.id } }),
    0,
  );
});
test("anonymous opt out and opaque block prevent future deliveries", async () => {
  const { g, sent } = fixture();
  const c = await prisma.anonymousPhotoConfig.create({
    data: { guildId: g.id, logChannelId: [...g.channels.cache.values()][2].id },
  });
  await prisma.anonymousPhotoSubmission.create({
    data: {
      guildId: g.id,
      configId: c.id,
      publicId: "ANON1",
      authorId: g.other.id,
      sessionKey: "test",
      status: "PUBLISHED",
    },
  });
  const delivery = await N.sendDm(g, g.actor.id, "ANON1", "Uma mensagem");
  assert.equal(sent.filter((x) => x.dm).length, 1);
  const p = sent.find((x) => x.dm).p;
  assert.ok(!JSON.stringify(p).includes(g.actor.id));
  const i = { user: g.other.user, client: g.client };
  await N.inbox(i, "block", delivery.id);
  await assert.rejects(
    () => N.allowed(g, g.actor.id, g.other.id),
    /disponível/,
  );
  await N.inbox(i, "optout", delivery.id);
  await assert.rejects(
    () => N.allowed(g, g.third.id, g.other.id),
    /disponível/,
  );
  await assert.rejects(
    () =>
      N.inbox({ user: g.third.user, client: g.client }, "block", delivery.id),
    /outra pessoa/,
  );
});
test("anonymous reports deliver only to the private source guild log", async () => {
  const { g, sent } = fixture(),
    ch = [...g.channels.cache.values()][2];
  const c = await prisma.anonymousPhotoConfig.create({
    data: { guildId: g.id, logChannelId: ch.id },
  });
  await prisma.anonymousPhotoSubmission.create({
    data: {
      guildId: g.id,
      configId: c.id,
      publicId: "ANON1",
      authorId: g.other.id,
      sessionKey: "test",
      status: "PUBLISHED",
    },
  });
  const d = await N.sendDm(g, g.actor.id, "ANON1", "Mensagem");
  await N.inbox({ user: g.other.user, client: g.client }, "report", d.id);
  assert.ok(
    sent.some(
      (x) => x.channel === ch.id && JSON.stringify(x.p).includes("Denúncia"),
    ),
  );
  await assert.rejects(
    () => N.inbox({ user: g.other.user, client: g.client }, "report", d.id),
    /já foi/,
  );
});
test("anonymous moderation queues text privately then approves once with audit and author notification", async () => {
  const { g, sent } = fixture(),
    chs = [...g.channels.cache.values()],
    review = chs[2],
    dest = chs[3],
    log = chs[4];
  await C.config(g.id);
  await prisma.socialExperienceConfig.update({
    where: { guildId: g.id },
    data: { anonymousModerated: true, reviewChannelId: review.id },
  });
  await prisma.anonymousMessageConfig.create({
    data: {
      guildId: g.id,
      enabled: true,
      destinationChannelId: dest.id,
      logChannelId: log.id,
    },
  });
  const d = await N.enqueue(g, g.other.id, "ANON_TEXT", {
    content: "Oi, comunidade!",
  });
  assert.equal(sent.length, 1);
  assert.equal(sent[0].channel, review.id);
  const i = { guild: g, user: g.actor.user, client: g.client };
  await N.review(i, true, d.id);
  assert.equal(
    (await prisma.socialSubmission.findUnique({ where: { id: d.id } })).status,
    "PUBLISHED",
  );
  assert.equal(sent.filter((x) => x.channel === dest.id).length, 1);
  assert.ok(
    !JSON.stringify(sent.find((x) => x.channel === dest.id).p).includes(
      g.other.id,
    ),
  );
  await assert.rejects(() => N.review(i, true, d.id), /analisado/);
  assert.equal(sent.filter((x) => x.channel === dest.id).length, 1);
});
test("unsafe review channel and unauthorized approval cannot publish", async () => {
  const { g, sent } = fixture(),
    ch = [...g.channels.cache.values()][0];
  await C.config(g.id);
  await prisma.socialExperienceConfig.update({
    where: { guildId: g.id },
    data: { anonymousModerated: true, reviewChannelId: ch.id },
  });
  await assert.rejects(
    () => N.enqueue(g, g.other.id, "ANON_TEXT", { content: "Teste" }),
    /privado/,
  );
  assert.equal(sent.length, 0);
});
test("new admin saves stay on original message and cannot be forged by ordinary members", async () => {
  const { g, sent } = fixture(),
    run = require("../app/social-experience/interactions");
  await C.config(g.id);
  let i = interaction(g, "sx-form:schedule", { time: "19:30", interval: "3" });
  await run.modal(i);
  assert.equal((await C.config(g.id)).dynamicsHour, 19);
  assert.equal(i.calls.at(-1)[0], "editReply");
  native(i.calls.at(-1)[1]);
  i = interaction(g, "sx-admin:toggle:requestsEnabled");
  i.user = g.other.user;
  await run.adminButton(i);
  assert.equal((await C.config(g.id)).requestsEnabled, false);
  assert.match(i.calls.at(-1)[1].content, /permissão/);
  assert.equal(sent.length, 0);
});
test("public panel publication is explicit and subsequent updates reuse one message", async () => {
  const { g, sent, edits } = fixture(),
    ch = [...g.channels.cache.values()][0];
  await C.config(g.id);
  await prisma.socialExperienceConfig.update({
    where: { guildId: g.id },
    data: { panelChannelId: ch.id },
  });
  await V.adminView(g, "participation");
  assert.equal(sent.length, 0);
  await V.publishPanel(g, "hub");
  await V.publishPanel(g, "hub");
  assert.equal(sent.length, 1);
  assert.equal(edits.length, 1);
});
test("real likes and comments leave native image and video gallery attached", async () => {
  const { g, sent, edits } = fixture(),
    { channel } = await setupSocial(g);
  await fetchStub(() => S.createSocialPublication(message(g, channel).m));
  const p = await prisma.socialPublication.findFirst({
    where: { guildId: g.id },
  });
  await S.toggleLike(g, p.id, g.actor.id);
  await S.addComment(g, p.id, g.actor.id, "Ficou incrível!");
  assert.equal(sent.length, 1);
  const post = await prisma.socialPublication.findUnique({
    where: { id: p.id },
  });
  assert.equal(post.likesCount, 1);
  assert.equal(post.commentsCount, 1);
  native(edits.at(-1));
  assert.match(
    JSON.stringify(edits.at(-1).components),
    /1 curtidas · 1 comentários/,
  );
  assert.deepEqual(edits.at(-1).attachments, [{ id: "0" }]);
});
test("failed database persistence rolls back public copy and keeps original", async () => {
  const { g } = fixture(),
    { channel } = await setupSocial(g),
    source = message(g, channel),
    model = prisma.socialPublication,
    prior = model.update;
  model.update = async (a) => {
    if (a.data.status === "ACTIVE") throw Error("database unavailable");
    return prior(a);
  };
  try {
    await fetchStub(() =>
      assert.rejects(
        () => S.createSocialPublication(source.m),
        /database unavailable/,
      ),
    );
    assert.equal(source.deleted(), 0);
    const p = await prisma.socialPublication.findFirst({
      where: { guildId: g.id },
    });
    assert.equal(p.status, "FAILED");
    assert.equal(await channel.messages.fetch("100000000000000100"), null);
  } finally {
    model.update = prior;
  }
});
test("bounded downloader rejects declared and streaming oversize responses", async () => {
  const prior = global.fetch;
  try {
    global.fetch = async () =>
      new Response("abc", { headers: { "content-length": "100" } });
    await assert.rejects(
      () => M.downloadMedia("https://cdn.discordapp.com/a.png", 2),
      /limite/,
    );
    global.fetch = async () => new Response("abcd");
    await assert.rejects(
      () => M.downloadMedia("https://cdn.discordapp.com/a.png", 2),
      /limite/,
    );
  } finally {
    global.fetch = prior;
  }
});
test("legacy classic card upgrades to V2 clearing old embed without detaching files", async () => {
  const { g, edits } = fixture(),
    { channel, c } = await setupSocial(g),
    m = await channel.send({
      embeds: [{ title: "Legacy" }],
      files: [{ name: "social-legacy.mp4", attachment: Buffer.from("a") }],
    });
  const p = await prisma.socialPublication.create({
    data: {
      guildId: g.id,
      configId: c.id,
      publicId: "legacy",
      channelId: channel.id,
      messageId: m.id,
      authorId: g.other.id,
      origin: "INSTA",
      mediaType: "VIDEO",
      mediaUrl: m.attachments.first().url,
    },
  });
  await S.refreshPublication(g, p.id);
  native(edits.at(-1));
  assert.deepEqual(edits.at(-1).embeds, []);
  assert.deepEqual(edits.at(-1).attachments, [{ id: "0" }]);
  assert.match(
    JSON.stringify(edits.at(-1).components),
    /attachment:\/\/social-legacy.mp4/,
  );
});
test("maximum new admin layouts respect all Discord embed and component limits", async () => {
  const { g } = fixture();
  await C.config(g.id);
  for (let n = 0; n < 20; n++)
    await prisma.socialActivityTemplate.create({
      data: {
        guildId: g.id,
        kind: "QUESTION",
        prompt: "Título longo ".repeat(50).slice(0, 700),
      },
    });
  native(await V.adminView(g, "templates"));
  for (const page of ["dynamics", "participation", "radio", "anonymous"])
    native(await V.adminView(g, page));
});
test("anonymous media moderation retains hosted upload and rejects ordinary reviewer", async () => {
  const { g, sent } = fixture(),
    chs = [...g.channels.cache.values()],
    review = chs[2],
    dest = chs[3],
    log = chs[4];
  await C.config(g.id);
  await prisma.socialExperienceConfig.update({
    where: { guildId: g.id },
    data: { anonymousModerated: true, reviewChannelId: review.id },
  });
  await prisma.anonymousPhotoConfig.create({
    data: {
      guildId: g.id,
      enabled: true,
      destinationChannelId: dest.id,
      logChannelId: log.id,
    },
  });
  const d = await fetchStub(() =>
    N.enqueue(g, g.other.id, "ANON_MEDIA", {
      url: "https://cdn.discordapp.com/attachments/1/2/video.mp4",
      name: "video.mp4",
      kind: "VIDEO",
    }),
  );
  await assert.rejects(
    () =>
      N.review({ guild: g, user: g.third.user, client: g.client }, true, d.id),
    /revisar/,
  );
  assert.equal(sent.filter((x) => x.channel === dest.id).length, 0);
  await fetchStub(() =>
    N.review({ guild: g, user: g.actor.user, client: g.client }, true, d.id),
  );
  assert.equal(sent.filter((x) => x.channel === dest.id).length, 1);
  native(sent.find((x) => x.channel === dest.id).p);
  assert.equal(sent.find((x) => x.channel === dest.id).p.files.length, 1);
});
test("anonymous refusal is final and never creates public submission", async () => {
  const { g, sent } = fixture(),
    ch = [...g.channels.cache.values()][2];
  await C.config(g.id);
  await prisma.socialExperienceConfig.update({
    where: { guildId: g.id },
    data: { anonymousModerated: true, reviewChannelId: ch.id },
  });
  const d = await N.enqueue(g, g.other.id, "ANON_TEXT", { content: "Teste" });
  await N.review(
    { guild: g, user: g.actor.user, client: g.client },
    false,
    d.id,
  );
  assert.equal(
    await prisma.anonymousMessageSubmission.count({ where: { guildId: g.id } }),
    0,
  );
  assert.equal(sent.filter((x) => !x.dm).length, 1);
  assert.equal(
    (await prisma.socialSubmission.findUnique({ where: { id: d.id } })).status,
    "REJECTED",
  );
});
test("legacy CDN reference renews from exact attachment in the same guild only", async () => {
  const { g } = fixture(),
    ch = [...g.channels.cache.values()][2],
    originalFetch = ch.messages.fetch;
  const attachment = {
    id: "555555555555555555",
    url:
      "https://cdn.discordapp.com/attachments/" +
      ch.id +
      "/555555555555555555/image.png?ex=fresh",
  };
  ch.messages.fetch = async (a) =>
    typeof a === "object"
      ? new Collection([
          [
            "message",
            { attachments: new Collection([[attachment.id, attachment]]) },
          ],
        ])
      : originalFetch(a);
  const p = {
    mediaUrl:
      "https://cdn.discordapp.com/attachments/" +
      ch.id +
      "/555555555555555555/image.png?ex=expired",
  };
  assert.equal(await M.legacyMediaUrl(g, p), attachment.url);
  const foreign = {
    mediaUrl:
      "https://cdn.discordapp.com/attachments/888888888888888888/555555555555555555/image.png?ex=expired",
  };
  assert.equal(await M.legacyMediaUrl(g, foreign), foreign.mediaUrl);
});
test("disabled INSTA after preview blocks confirmation and keeps the draft audit", async () => {
  const { g, sent } = fixture();
  await setupSocial(g);
  const i = interaction(g, "sx-form:post");
  await P.draft(
    i,
    { name: "a.png", size: 1, url: "https://cdn.discordapp.com/a.png" },
    "Legenda",
  );
  const d = await prisma.socialSubmission.findFirst({
    where: { guildId: g.id },
  });
  await prisma.socialConfig.update({
    where: { guildId: g.id },
    data: { enabled: false },
  });
  await assert.rejects(() => P.confirm(i, d.id), /desativado/);
  assert.equal(sent.length, 0);
  assert.equal(
    (await prisma.socialSubmission.findUnique({ where: { id: d.id } })).status,
    "FAILED",
  );
});
test("matching search keeps filter across profile pagination", async () => {
  const { g } = fixture(),
    F = require("../app/social-experience/profiles");
  await C.config(g.id);
  await prisma.socialExperienceConfig.update({
    where: { guildId: g.id },
    data: { profilesEnabled: true },
  });
  for (let n = 0; n < 7; n++)
    await prisma.socialProfile.create({
      data: {
        guildId: g.id,
        userId: "search-" + n,
        interests: "jazz",
        visible: true,
      },
    });
  await prisma.socialProfile.create({
    data: {
      guildId: g.id,
      userId: "unrelated",
      interests: "metal",
      visible: true,
    },
  });
  const first = await F.discover(g, 0, "jazz"),
    nextId = first.components[0].components[1].data.custom_id,
    token = nextId.split(":")[3],
    second = await F.discover(g, 1, "", token);
  assert.match(JSON.stringify(second), /7 perfis/);
  assert.ok(!JSON.stringify(second).includes("metal"));
});
test("private member navigation refreshes its existing message instead of opening repeated replies", async () => {
  const { g } = fixture(),
    i = interaction(g, "sx:radio-refresh");
  i.message.flags = { has: (flag) => flag === MessageFlags.Ephemeral };
  await C.config(g.id);
  await require("../app/social-experience/interactions").memberButton(i);
  assert.equal(i.calls[0][0], "deferUpdate");
  assert.equal(i.calls.at(-1)[0], "editReply");
  native(i.calls.at(-1)[1]);
});
