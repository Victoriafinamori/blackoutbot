"use strict";
const { test } = require("node:test"),
  assert = require("node:assert/strict"),
  { MessageFlags, Collection } = require("discord.js");
const { fixture, prisma } = require("./fixtures/social-runtime.cjs");
const B = require("../app/bingo/community"),
  V = require("../app/bingo/communityViews"),
  C = require("../app/games-chat/experience/common"),
  H = require("../app/games-chat/experience/hub"),
  T = require("../app/games-chat/termo/manager"),
  W = require("../app/games-chat/termo/words");
function valid(p) {
  assert.ok(p.embeds?.length);
  let total = 0;
  for (const item of p.embeds) {
    const e = item.toJSON ? item.toJSON() : item;
    assert.ok((e.title?.length || 0) <= 256);
    assert.ok((e.description?.length || 0) <= 4096);
    assert.ok((e.fields?.length || 0) <= 25);
    for (const f of e.fields || []) {
      assert.ok(f.value.length > 0 && f.value.length <= 1024);
      assert.ok(f.name.length <= 256);
    }
    total +=
      (e.title?.length || 0) +
      (e.description?.length || 0) +
      (e.fields || []).reduce((n, f) => n + f.name.length + f.value.length, 0);
  }
  assert.ok(total <= 6000);
  assert.ok((p.components?.length || 0) <= 5);
  for (const r of p.components || []) {
    const row = r.toJSON ? r.toJSON() : r;
    assert.ok(row.components.length <= 5);
    for (const c of row.components) {
      assert.ok((c.custom_id?.length || 0) <= 100);
      if (c.options) {
        assert.ok(c.options.length <= 25);
        for (const o of c.options) assert.ok(o.label.length <= 100);
      }
    }
  }
  return p;
}
function interaction(g, id, fields = {}, values = []) {
  const calls = [],
    i = {
      id: "100000000000000080",
      guild: g,
      channelId: [...g.channels.cache.keys()][0],
      client: g.client,
      user: g.actor.user,
      customId: id,
      values,
      message: { id: "100000000000000050", flags: { has: () => false } },
      fields: { getTextInputValue: (k) => fields[k] ?? "" },
      isFromMessage: () => true,
      isStringSelectMenu: () => true,
      isChannelSelectMenu: () => true,
      isButton: () => true,
      isModalSubmit: () => false,
      deferred: false,
      replied: false,
      ephemeral: null,
      async deferReply() {
        i.deferred = true;
        i.ephemeral = true;
        calls.push(["deferReply"]);
      },
      async deferUpdate() {
        i.deferred = true;
        calls.push(["deferUpdate"]);
      },
      async reply(p) {
        i.replied = true;
        calls.push(["reply", p]);
      },
      async update(p) {
        i.replied = true;
        calls.push(["update", p]);
      },
      async editReply(p) {
        i.replied = true;
        calls.push(["editReply", p]);
      },
      async followUp(p) {
        calls.push(["followUp", p]);
      },
      async showModal(p) {
        calls.push(["modal", p]);
      },
      calls,
    };
  return i;
}
async function bingo(options = {}) {
  const f = fixture(),
    ch = [...f.g.channels.cache.values()][0];
  await B.config(f.g.id);
  await prisma.bingoExperienceConfig.update({
    where: { guildId: f.g.id },
    data: { channelId: ch.id, ...options },
  });
  const event = await B.create(f.g, f.g.actor.id);
  return { ...f, ch, ...event };
}
async function readyBingo(options = {}) {
  const f = await bingo(options);
  await B.join(f.g, f.match.id, f.g.other.id);
  await B.join(f.g, f.match.id, f.g.third.id);
  await B.start(f.g.id, f.match.id);
  return f;
}
async function termo(options = {}) {
  const f = fixture();
  await prisma.guildConfig.create({
    data: { guildId: f.g.id, timezone: "America/Sao_Paulo" },
  });
  await prisma.gamesChatConfig.create({ data: { guildId: f.g.id } });
  const ch = [...f.g.channels.cache.values()][0];
  await prisma.termoConfig.create({
    data: { guildId: f.g.id, enabled: true, channelId: ch.id, ...options },
  });
  await W.ensureDefaultWords();
  const word = await prisma.termoWord.findFirst({
    where: { guildId: null, normalized: "amigo" },
  });
  const round = await prisma.termoRound.create({
    data: {
      guildId: f.g.id,
      date: T.dateInTZ(new Date(), "America/Sao_Paulo"),
      wordId: word.id,
      endsAt: T.nextMidnight("America/Sao_Paulo"),
      maxAttemptsSnapshot: options.maxAttempts || 6,
      wordLengthSnapshot: 5,
    },
  });
  return { ...f, ch, round, word };
}
test("community bingo is opt in, manual by default and does not consume old unassigned cards", async () => {
  const f = fixture(),
    old = await prisma.bingoCard.create({
      data: {
        guildId: f.g.id,
        cardNumber: 1,
        playerId: f.g.other.id,
        numbers: JSON.stringify(
          require("../app/bingo/service").generateCardNumbers(),
        ),
      },
    });
  await B.config(f.g.id);
  await prisma.bingoExperienceConfig.update({
    where: { guildId: f.g.id },
    data: { channelId: [...f.g.channels.cache.keys()][0] },
  });
  const e = await B.create(f.g, f.g.actor.id);
  assert.equal(e.state.phase, "LOBBY");
  assert.equal(e.state.automatic, false);
  assert.equal(
    (await prisma.bingoCard.findUnique({ where: { id: old.id } })).matchId,
    null,
  );
  assert.equal(f.sent.length, 1);
  valid(await V.publicView(f.g, e.match.id));
});
test("bingo event creation rejects unavailable and foreign channels", async () => {
  const { g, sent } = fixture();
  await B.config(g.id);
  await prisma.bingoExperienceConfig.update({
    where: { guildId: g.id },
    data: { channelId: "foreign" },
  });
  await assert.rejects(() => B.create(g, g.actor.id), /canal de texto/);
  assert.equal(sent.length, 0);
  assert.equal(await prisma.bingoMatch.count(), 0);
});
test("failed bingo publication closes the draft event without starting draws", async () => {
  const { g } = fixture(),
    ch = [...g.channels.cache.values()][0];
  await B.config(g.id);
  await prisma.bingoExperienceConfig.update({
    where: { guildId: g.id },
    data: { channelId: ch.id },
  });
  ch.send = async () => {
    throw Error("send failed");
  };
  await assert.rejects(() => B.create(g, g.actor.id), /send failed/);
  const state = await prisma.bingoExperienceState.findFirst();
  assert.equal(state.phase, "ENDED");
  assert.equal((await prisma.bingoMatch.findFirst()).status, "ENCERRADA");
  assert.equal(state.nextDrawAt, null);
});
test("one free card per member, with current membership and capacity checks", async () => {
  const { g, match } = await bingo({ maxPlayers: 2 });
  const card = await B.join(g, match.id, g.other.id);
  assert.equal((await B.join(g, match.id, g.other.id)).id, card.id);
  await B.join(g, match.id, g.third.id);
  await assert.rejects(() => B.join(g, match.id, g.actor.id), /vagas/);
  await assert.rejects(() => B.join(g, match.id, g.members.me.id), /Participe/);
  assert.equal(
    await prisma.bingoCard.count({ where: { matchId: match.id } }),
    2,
  );
});
test("simultaneous joins do not duplicate a participant or consume two card numbers", async () => {
  const { g, match } = await bingo();
  const values = await Promise.allSettled([
    B.join(g, match.id, g.other.id),
    B.join(g, match.id, g.other.id),
  ]);
  assert.ok(values.some((v) => v.status === "fulfilled"));
  assert.equal(
    await prisma.bingoCard.count({
      where: { matchId: match.id, playerId: g.other.id },
    }),
    1,
  );
});
test("minimum players, closed registration and leaving before play have explicit guards", async () => {
  const { g, match } = await bingo();
  await B.join(g, match.id, g.other.id);
  await assert.rejects(() => B.start(g.id, match.id), /ao menos 2/);
  await B.leave(g, match.id, g.other.id);
  assert.equal(
    await prisma.bingoCard.count({ where: { matchId: match.id } }),
    0,
  );
  await B.join(g, match.id, g.other.id);
  await B.join(g, match.id, g.third.id);
  await B.start(g.id, match.id);
  await assert.rejects(() => B.join(g, match.id, g.actor.id), /inscrições/);
  await assert.rejects(() => B.leave(g, match.id, g.other.id), /já começou/);
});
test("bingo rules are frozen per event and later configuration affects the next event", async () => {
  const { g, match, state } = await bingo();
  await prisma.bingoExperienceConfig.update({
    where: { guildId: g.id },
    data: { objective: "FULL_CARD", automatic: true, intervalSeconds: 30 },
  });
  const current = (await B.load(g.id, match.id)).state;
  assert.equal(current.objective, state.objective);
  assert.equal(current.automatic, false);
  assert.equal(current.intervalSeconds, 15);
});
test("all 75 draws are unique and exhaustion cannot create a 76th number", async () => {
  const { g, match } = await readyBingo();
  for (let n = 0; n < 75; n++) await B.draw(g.id, match.id);
  const draws = await prisma.bingoDraw.findMany({
    where: { matchId: match.id },
    orderBy: { order: "asc" },
  });
  assert.equal(draws.length, 75);
  assert.equal(new Set(draws.map((d) => d.number)).size, 75);
  assert.deepEqual(
    draws.map((d) => d.order),
    Array.from({ length: 75 }, (_, n) => n + 1),
  );
  await assert.rejects(() => B.draw(g.id, match.id), /75 números/);
});
test("automatic mode draws once after downtime and preserves the next deadline", async () => {
  const { g, match } = await readyBingo({ automatic: true });
  await prisma.bingoExperienceState.update({
    where: { matchId: match.id },
    data: { nextDrawAt: new Date(Date.now() - 3600000) },
  });
  await B.tick(g.client);
  assert.equal(
    await prisma.bingoDraw.count({ where: { matchId: match.id } }),
    1,
  );
  assert.ok((await B.load(g.id, match.id)).state.nextDrawAt > new Date());
  await B.tick(g.client);
  assert.equal(
    await prisma.bingoDraw.count({ where: { matchId: match.id } }),
    1,
  );
});
test("scheduler encountering an in flight action does not pause the game", async () => {
  const { g, match } = await readyBingo({ automatic: true });
  await prisma.bingoExperienceState.update({
    where: { matchId: match.id },
    data: { nextDrawAt: new Date(0) },
  });
  await C.lock("bingo:" + g.id, () => B.tick(g.client));
  assert.equal((await B.load(g.id, match.id)).state.phase, "RUNNING");
  assert.equal(
    await prisma.bingoDraw.count({ where: { matchId: match.id } }),
    0,
  );
});
test("pause, resume, end and old admin service methods preserve community state", async () => {
  const { g, match } = await readyBingo({ automatic: true }),
    legacy = require("../app/bingo/service");
  await legacy.pauseMatch(match.id);
  assert.equal((await B.load(g.id, match.id)).state.phase, "PAUSED");
  await assert.rejects(() => B.draw(g.id, match.id), /andamento/);
  await legacy.resumeMatch(match.id);
  assert.equal((await B.load(g.id, match.id)).state.phase, "RUNNING");
  await legacy.endMatch(match.id);
  assert.equal((await B.load(g.id, match.id)).state.phase, "ENDED");
  assert.equal((await B.load(g.id, match.id)).state.nextDrawAt, null);
});
test("bingo objectives validate lines, whole card and four corners against saved numbers", () => {
  const card = require("../app/bingo/service").generateCardNumbers();
  const row = new Set(card.slice(0, 5));
  assert.equal(B.progress(card, row, "ANY_LINE").won, true);
  assert.equal(B.progress(card, row, "FULL_CARD").won, false);
  assert.equal(
    B.progress(
      card,
      new Set([card[0], card[4], card[20], card[24]]),
      "FOUR_CORNERS",
    ).won,
    true,
  );
  assert.equal(
    B.progress(card, new Set(card.filter((n) => n !== null)), "FULL_CARD").won,
    true,
  );
  assert.throws(
    () => B.progress([1, 2], new Set(), "ANY_LINE"),
    /inconsistente/,
  );
});
test("same draw winners are registered together, pause the game and cannot duplicate claims", async () => {
  const { g, match } = await readyBingo();
  const cards = await prisma.bingoCard.findMany({
    where: { matchId: match.id },
    orderBy: { cardNumber: "asc" },
  });
  await prisma.bingoCard.update({
    where: { id: cards[1].id },
    data: { numbers: cards[0].numbers },
  });
  const nums = JSON.parse(cards[0].numbers).slice(0, 5);
  for (let n = 0; n < nums.length; n++)
    await prisma.bingoDraw.create({
      data: {
        matchId: match.id,
        number: nums[n],
        letter: require("../app/bingo/types").letterFor(nums[n]),
        order: n + 1,
      },
    });
  await prisma.bingoExperienceState.update({
    where: { matchId: match.id },
    data: { drawVersion: 5 },
  });
  const result = await B.check(g, match.id, g.other.id);
  assert.equal(result.won, true);
  assert.equal(result.winners.length, 2);
  assert.equal((await B.load(g.id, match.id)).state.phase, "REVIEW");
  await B.check(g, match.id, g.other.id);
  assert.equal(
    await prisma.bingoExperienceClaim.count({ where: { matchId: match.id } }),
    2,
  );
  assert.equal(
    await prisma.bingoWinner.count({ where: { matchId: match.id } }),
    2,
  );
  await assert.rejects(() => B.draw(g.id, match.id), /andamento/);
});
test("cross guild bingo controls and cards cannot be read or mutated", async () => {
  const { g, match } = await readyBingo();
  await assert.rejects(() => B.load("foreign", match.id), /servidor/);
  await assert.rejects(
    () => V.cardsView({ ...g, id: "foreign" }, match.id, g.other.id),
    /servidor/,
  );
  assert.equal(
    await prisma.bingoDraw.count({ where: { matchId: match.id } }),
    0,
  );
});
test("player and staff layouts fit Discord limits and show distinct controls", async () => {
  const { g, match } = await readyBingo();
  const publicPanel = valid(await V.publicView(g, match.id)),
    admin = valid(await V.adminView(g));
  valid(await V.cardsView(g, match.id, g.other.id));
  assert.ok(!JSON.stringify(publicPanel).includes("bg-admin:"));
  assert.ok(JSON.stringify(admin).includes("bg-admin:pause:"));
  assert.ok(admin.components.length <= 5);
  valid(await V.appearanceView(g));
});
test("unauthorized bingo admin action cannot start, publish or update a game", async () => {
  const { g, sent } = fixture(),
    i = interaction(g, "bg-admin:create");
  i.user = g.other.user;
  await require("../app/bingo/communityInteractions").admin(i);
  assert.equal(sent.length, 0);
  assert.equal(await prisma.bingoMatch.count(), 0);
  assert.match(i.calls.at(-1)[1].content, /permissão/);
});
test("bingo rule selection updates the same admin embed using readable labels", async () => {
  const { g } = fixture();
  await B.config(g.id);
  const i = interaction(g, "bg-select:objective", {}, ["FOUR_CORNERS"]);
  await require("../app/bingo/communityInteractions").select(i);
  assert.equal((await B.config(g.id)).objective, "FOUR_CORNERS");
  assert.equal(i.calls[0][0], "deferUpdate");
  valid(i.calls.at(-1)[1]);
  assert.match(JSON.stringify(i.calls.at(-1)[1].embeds), /Os quatro cantos/);
});
test("dictionary expands existing installations without duplicates or reactivating paused words", async () => {
  const { g } = fixture();
  await W.ensureDefaultWords();
  const count = await prisma.termoWord.count({ where: { guildId: null } });
  assert.ok(count > 350);
  const w = await prisma.termoWord.findFirst({
    where: { guildId: null, normalized: "amigo" },
  });
  await prisma.termoWord.update({
    where: { id: w.id },
    data: { active: false },
  });
  await W.ensureDefaultWords();
  assert.equal(
    await prisma.termoWord.count({ where: { guildId: null } }),
    count,
  );
  assert.equal(
    (await prisma.termoWord.findUnique({ where: { id: w.id } })).active,
    false,
  );
  assert.equal(await W.isAllowedGuess(g.id, "amigo", 5), false);
});
for (const hour of ["04:30", "15:00", "23:15"])
  test("next local midnight is correct when consulted at UTC " + hour, () => {
    const now = Date.parse("2026-10-22T" + hour + ":00Z"),
      deadline = T.nextMidnight("America/Sao_Paulo", now);
    assert.ok(
      Math.abs(deadline.getTime() - Date.parse("2026-10-23T03:00:00Z")) < 2000,
    );
  });
test("termo freezes length and attempts for today after admin changes settings", async () => {
  const { g, round } = await termo();
  await prisma.termoConfig.update({
    where: { guildId: g.id },
    data: { wordLength: 6, maxAttempts: 9 },
  });
  const current = await T.ensureDailyRound(g.id);
  assert.equal(current.id, round.id);
  assert.equal(current.wordLengthSnapshot, 5);
  assert.equal(current.maxAttemptsSnapshot, 6);
  await T.submitGuess(g.id, g.other.id, "amigo", round.id);
  const game = await T.getOrCreateGame(g.id, g.other.id);
  assert.equal(game.status, "WON");
  assert.equal(game.attemptsUsed, 1);
});
test("invalid termo word or stale modal consumes no attempts", async () => {
  const { g, round } = await termo();
  await assert.rejects(
    () => T.submitGuess(g.id, g.other.id, "zzzzz", round.id),
    /nenhuma tentativa/,
  );
  await assert.rejects(
    () => T.submitGuess(g.id, g.other.id, "amigo", "yesterday"),
    /mudou/,
  );
  assert.equal((await T.getOrCreateGame(g.id, g.other.id)).attemptsUsed, 0);
  assert.equal(await prisma.termoGuess.count(), 0);
});
test("termo wins award points and streak once; replay cannot inflate results", async () => {
  const { g, round } = await termo();
  await T.submitGuess(g.id, g.other.id, "amigo", round.id);
  await assert.rejects(
    () => T.submitGuess(g.id, g.other.id, "amigo", round.id),
    /já acertou/,
  );
  const stat = await prisma.termoStat.findUnique({
    where: { guildId_userId: { guildId: g.id, userId: g.other.id } },
  });
  assert.equal(stat.wins, 1);
  assert.equal(stat.points, 90);
  assert.equal((await T.getOrCreateGame(g.id, g.other.id)).pointsEarned, 90);
  assert.equal(await prisma.termoGuess.count(), 1);
});
test("losing respects reveal preference and does not disclose answer by default", async () => {
  const { g, round } = await termo({ maxAttempts: 1 }),
    ui = require("../app/games-chat/termo/ui");
  await T.submitGuess(g.id, g.other.id, "areia", round.id);
  let view = valid(await ui.termoPlayerView(g, g.other.id));
  assert.ok(!view.embeds[0].data.description.includes("AMIGO"));
  await prisma.termoConfig.update({
    where: { guildId: g.id },
    data: { revealOnLoss: true },
  });
  view = valid(await ui.termoPlayerView(g, g.other.id));
  assert.match(view.embeds[0].data.description, /AMIGO/);
});
test("result sharing is explicit, spoiler free and single use", async () => {
  const { g, round, sent } = await termo();
  await T.submitGuess(g.id, g.other.id, "amigo", round.id);
  await T.shareResult(g, g.other.id);
  assert.equal(sent.length, 1);
  assert.ok(!sent[0].p.content.toLowerCase().includes("amigo"));
  assert.ok(sent[0].p.content.includes("🟩"));
  await assert.rejects(() => T.shareResult(g, g.other.id), /compartilhado/);
  assert.equal(sent.length, 1);
});
test("failed share can be retried without changing win or points", async () => {
  const { g, round, ch } = await termo();
  await T.submitGuess(g.id, g.other.id, "amigo", round.id);
  ch.send = async () => {
    throw Error("failed share");
  };
  await assert.rejects(() => T.shareResult(g, g.other.id), /failed share/);
  const game = await T.getOrCreateGame(g.id, g.other.id);
  assert.equal(game.sharedMessageId, null);
  assert.equal(game.status, "WON");
  assert.equal(game.pointsEarned, 90);
});
test("disabled termo rejects old play buttons and incoming guesses", async () => {
  const { g, round } = await termo();
  await prisma.termoConfig.update({
    where: { guildId: g.id },
    data: { enabled: false },
  });
  await assert.rejects(
    () => T.submitGuess(g.id, g.other.id, "amigo", round.id),
    /desativado/,
  );
  assert.equal(await prisma.termoGuess.count(), 0);
});
test("weekly termo ranking uses per round earned points in the current guild only", async () => {
  const { g, round } = await termo();
  await T.submitGuess(g.id, g.other.id, "amigo", round.id);
  await prisma.termoGame.create({
    data: {
      guildId: "foreign",
      roundId: round.id,
      userId: "not-this-guild",
      status: "WON",
      pointsEarned: 900,
    },
  });
  const ranking = await T.weeklyRanking(g.id);
  assert.equal(ranking.length, 1);
  assert.equal(ranking[0].userId, g.other.id);
  assert.equal(ranking[0]._sum.pointsEarned, 90);
  valid(await require("../app/games-chat/termo/ui").termoRankingView(g));
});
test("termo public and private screens show frozen rule, progress and saved result", async () => {
  const { g, round } = await termo(),
    ui = require("../app/games-chat/termo/ui");
  valid(await ui.termoPublicView(g));
  valid(await ui.termoPlayerView(g, g.other.id));
  await T.submitGuess(g.id, g.other.id, "amigo", round.id);
  const privatePanel = valid(await ui.termoPlayerView(g, g.other.id));
  assert.match(JSON.stringify(privatePanel), /Compartilhar no TERMO/);
  assert.ok(!JSON.stringify(await ui.termoPublicView(g)).includes("AMIGO"));
});
test("25 mystery boxes fit five native rows including useful result navigation", () => {
  const event = {
      id: "example",
      status: "ACTIVE",
      endsAt: new Date(Date.now() + 60000),
      openings: [],
      boxes: Array.from({ length: 25 }, (_, n) => ({
        number: n + 1,
        status: "AVAILABLE",
      })),
    },
    c = {
      color: "D71935",
      title: "Caixa Misteriosa",
      description: "Escolha uma caixa.",
      buttonLabel: "Caixa",
    };
  const ui = require("../app/games-chat/mystery-box/ui"),
    first = valid(ui.mysteryView(event, c)),
    second = valid(ui.mysteryView(event, c, 20));
  assert.equal(first.components.length, 5);
  assert.equal(
    first.components.slice(0, 4).flatMap((r) => r.components).length,
    20,
  );
  assert.match(JSON.stringify(second), /Caixa 25/);
  assert.match(JSON.stringify(first), /Meu resultado/);
});
test("new game hub is not automatically published and individual announcement preference preserves old behavior", async () => {
  const { g, sent } = fixture();
  assert.equal((await H.config(g.id)).mysteryIndividualAnnouncements, true);
  valid(await H.publicView(g));
  valid(await H.adminView(g));
  valid(await H.adminView(g, true));
  assert.equal(sent.length, 0);
});
test("public hub publication updates one message and automatic status refresh keeps published appearance", async () => {
  const { g, sent, edits } = fixture(),
    ch = [...g.channels.cache.values()][0];
  await H.config(g.id);
  await prisma.gamesHubConfig.update({
    where: { guildId: g.id },
    data: { channelId: ch.id, title: "Título publicado" },
  });
  await H.publish(g);
  await H.publish(g);
  assert.equal(sent.length, 1);
  assert.equal(edits.length, 1);
  await prisma.gamesHubConfig.update({
    where: { guildId: g.id },
    data: { title: "Rascunho novo" },
  });
  await H.refreshPublished(g.client);
  assert.equal(edits.length, 1);
  await B.config(g.id);
  await prisma.bingoExperienceConfig.update({
    where: { guildId: g.id },
    data: { channelId: ch.id },
  });
  await B.create(g, g.actor.id);
  await H.refreshPublished(g.client);
  assert.match(JSON.stringify(edits.at(-1).embeds), /Título publicado/);
  assert.ok(!JSON.stringify(edits.at(-1).embeds).includes("Rascunho novo"));
  assert.match(JSON.stringify(edits.at(-1).embeds), /inscrições abertas/);
});
test("game hub settings refresh the originating preview without publishing", async () => {
  const { g, sent } = fixture(),
    i = interaction(g, "games-form:appearance", {
      title: "Vamos jogar",
      description: "Entre na diversão.",
      color: "D71935",
      footer: "",
    });
  await H.modal(i);
  assert.equal(sent.length, 0);
  assert.equal(i.calls[0][0], "deferUpdate");
  valid(i.calls.at(-1)[1]);
  assert.equal(i.calls.at(-1)[1].embeds[0].data.title, "Vamos jogar");
  assert.equal(i.calls.at(-1)[1].embeds[0].data.footer, undefined);
});
test("jogar command declares valid choices and discovers existing games", () => {
  const data = require("../app/commands/jogar").default.data.toJSON();
  assert.equal(data.name, "jogar");
  assert.deepEqual(
    data.options[0].choices.map((c) => c.value),
    ["termo", "bingo", "mystery", "quiz", "ranking"],
  );
});
test("old cards remain accessible privately inside the server without a DM", async () => {
  const { g } = fixture(),
    legacy = require("../app/bingo/service"),
    access = require("../app/bingo/cardAccess");
  await legacy.registerCard(
    g.id,
    null,
    1,
    g.other.id,
    legacy.generateCardNumbers(),
  );
  const own = valid(await access.view(g, g.other.id));
  assert.match(own.embeds[0].data.title, /0001/);
  const another = valid(await access.view(g, g.third.id));
  assert.ok(!JSON.stringify(another).includes("Cartela #0001"));
  const panel = valid(require("../app/bingo/views").buildCardPanelMessage());
  assert.match(JSON.stringify(panel), /Ver minhas cartelas aqui/);
});
test("old draw service serializes concurrent clicks and refuses paused games", async () => {
  const { g } = fixture(),
    legacy = require("../app/bingo/service"),
    m = await legacy.createMatch(
      g.id,
      [...g.channels.cache.keys()][0],
      g.actor.id,
    );
  const results = await Promise.allSettled([
    legacy.drawNumber(m.id),
    legacy.drawNumber(m.id),
  ]);
  assert.equal(results.filter((r) => r.status === "fulfilled").length, 1);
  assert.equal(await prisma.bingoDraw.count({ where: { matchId: m.id } }), 1);
  await legacy.pauseMatch(m.id);
  await assert.rejects(() => legacy.drawNumber(m.id), /andamento/);
});
test("simultaneous classic and community creation leaves one active match", async () => {
  const { g } = fixture(),
    legacy = require("../app/bingo/service"),
    channel = [...g.channels.cache.keys()][0];
  await B.config(g.id);
  await prisma.bingoExperienceConfig.update({
    where: { guildId: g.id },
    data: { channelId: channel },
  });
  const r = await Promise.allSettled([
    B.create(g, g.actor.id),
    legacy.createMatch(g.id, channel, g.actor.id),
  ]);
  assert.equal(r.filter((v) => v.status === "fulfilled").length, 1);
  assert.equal(
    await prisma.bingoMatch.count({
      where: { guildId: g.id, status: { in: ["PAUSADA", "EM_ANDAMENTO"] } },
    }),
    1,
  );
});
test("termo submissions cannot duplicate a winning attempt under concurrent clicks", async () => {
  const { g, round } = await termo();
  const r = await Promise.allSettled([
    T.submitGuess(g.id, g.other.id, "amigo", round.id),
    T.submitGuess(g.id, g.other.id, "amigo", round.id),
  ]);
  assert.equal(r.filter((v) => v.status === "fulfilled").length, 1);
  assert.equal(await prisma.termoGuess.count(), 1);
  assert.equal(
    (
      await prisma.termoStat.findUnique({
        where: { guildId_userId: { guildId: g.id, userId: g.other.id } },
      })
    ).wins,
    1,
  );
});
test("termo appearance saves an actual preview without opening a round or publishing", async () => {
  const { g, sent } = fixture();
  await prisma.guildConfig.create({ data: { guildId: g.id } });
  await prisma.termoConfig.create({ data: { guildId: g.id } });
  const i = interaction(g, "adm-games-modal:termo-appearance", {
    title: "Palavra da comunidade",
    description: "Seu desafio diário.",
    color: "000000",
    image: "",
    footer: "",
  });
  await require("../app/components/modals/admGamesChatModal").default.execute(
    i,
  );
  valid(i.calls.at(-1)[1]);
  assert.equal(i.calls.at(-1)[1].embeds[0].data.title, "Palavra da comunidade");
  assert.equal(i.calls.at(-1)[1].embeds[0].data.color, 0);
  assert.equal(await prisma.termoRound.count(), 0);
  assert.equal(sent.length, 0);
});
test("termo settings reject a future length without answers while custom words can be prepared first", async () => {
  const { g } = fixture();
  await prisma.guildConfig.create({ data: { guildId: g.id } });
  await prisma.termoConfig.create({ data: { guildId: g.id } });
  const run = require("../app/components/modals/admGamesChatModal").default;
  let i = interaction(g, "adm-games-modal:termo", {
    length: "6",
    attempts: "6",
    repeat: "30",
    title: "TERMO",
    color: "D71935",
  });
  await run.execute(i);
  assert.equal(
    (await prisma.termoConfig.findUnique({ where: { guildId: g.id } }))
      .wordLength,
    5,
  );
  assert.match(i.calls.at(-1)[1].content, /Cadastre primeiro/);
  i = interaction(g, "adm-games-modal:word", { word: "banana", answer: "SIM" });
  await run.execute(i);
  assert.equal(
    await prisma.termoWord.count({ where: { guildId: g.id, length: 6 } }),
    1,
  );
  i = interaction(g, "adm-games-modal:termo", {
    length: "6",
    attempts: "6",
    repeat: "30",
    title: "TERMO",
    color: "D71935",
  });
  await run.execute(i);
  assert.equal(
    (await prisma.termoConfig.findUnique({ where: { guildId: g.id } }))
      .wordLength,
    6,
  );
});
test("old modal opened before a setting change uses the current saved round snapshot", async () => {
  const { g, round } = await termo(),
    i = interaction(g, "termo-guess:" + round.id, { word: "amigo" });
  i.user = g.other.user;
  i.message.flags = { has: () => true };
  await require("../app/components/modals/termoGuessModal").default.execute(i);
  assert.equal(i.calls[0][0], "deferUpdate");
  valid(i.calls.find((c) => c[0] === "editReply")[1]);
  assert.equal((await T.getOrCreateGame(g.id, g.other.id)).status, "WON");
});
test("game hub discovers an existing classic card instead of hiding it behind the new community mode", async () => {
  const { g } = fixture(),
    legacy = require("../app/bingo/service");
  await legacy.registerCard(
    g.id,
    null,
    7,
    g.other.id,
    legacy.generateCardNumbers(),
  );
  valid(await H.playView(g, g.other.id, "bingo"));
  assert.match(
    JSON.stringify(await H.playView(g, g.other.id, "bingo")),
    /Cartela #0007/,
  );
});
test("old admin end confirmation refreshes the exact ended community panel", async () => {
  const { g, match, edits } = await readyBingo(),
    i = interaction(g, "adm-bingo:end-confirm");
  await require("../app/components/buttons/admBingoMenu").default.execute(i);
  assert.equal((await B.load(g.id, match.id)).state.phase, "ENDED");
  assert.ok(edits.some((p) => JSON.stringify(p.embeds).includes("Encerrada")));
});
test("DM failure offers an immediate private card fallback without exposing the card publicly", async () => {
  const { g } = fixture(),
    legacy = require("../app/bingo/service");
  await legacy.registerCard(
    g.id,
    null,
    1,
    g.other.id,
    legacy.generateCardNumbers(),
  );
  const i = interaction(g, "bingo:reenviar-cartelas");
  i.user = g.other.user;
  i.user.send = async () => {
    throw Error("DM closed");
  };
  await require("../app/components/buttons/bingoActions").default.execute(i);
  const response = i.calls.at(-1)[1];
  assert.equal(response.ephemeral, true);
  assert.match(JSON.stringify(response.components), /bingo-card-view:0/);
  assert.ok(!response.embeds);
});
