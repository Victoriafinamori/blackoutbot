"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ADMIN_TASKS = void 0;
exports.cleanAdminLabel = cleanAdminLabel;
exports.prepareAdminPanel = prepareAdminPanel;
exports.dispatchAdminTask = dispatchAdminTask;
const discord_js_1 = require("discord.js");
const admPanel_1 = require("./admPanel");
const admEmojis_1 = require("./admEmojis");
/** Only explicitly listed administrative navigation actions may be adapted from a select. */
exports.ADMIN_TASKS = {
    reintegracao: { area: 'membros', tasks: [['adm-reint:etapas', 'Etapas e progressão', 'Configure fases, cargos e regras de avanço'], ['adm-reint:chatcanais', 'Canais das etapas', 'Escolha onde as regras de chat se aplicam'], ['adm-reint:membros', 'Acompanhar membros', 'Inscrição, avaliação e progressão'], ['adm-notify:reintegracao', 'Mensagens aos membros', 'Preferências de comunicação deste módulo']] },
    movchat: { area: 'servidor', tasks: [] },
    movcall: { area: 'servidor', tasks: [['adm-movcall:categories', 'Categorias monitoradas', 'Onde o tempo em call será contado'], ['adm-movcall:permroles', 'Cargos com acesso aos comandos', 'Defina quem pode usar os comandos de call'], ['adm-movcall:interval', 'Ciclo do ranking', 'Intervalo entre os resets automáticos'], ['adm-movcall:topcall', 'Ranking e recompensas', 'Canais, cargos e recompensas'], ['adm-movcall:stats', 'Estatísticas', 'Consulte a atividade registrada'], ['adm-movcall:requestreset', 'Zerar tempo acumulado', 'Abre a confirmação; não executa imediatamente'], ['adm-movcall:resetconfigrequest', 'Restaurar configurações', 'Abre a confirmação das configurações']] },
    tickets: { area: 'atendimento', tasks: [] }, denuncias: { area: 'atendimento', back: 'adm-denuncia:back', tasks: [['adm-denuncia:channels', 'Canais e logs', 'Painel, atendimento e registros'], ['adm-denuncia:roles', 'Equipe responsável', 'Cargos autorizados a atender'], ['adm-denuncia:appearance', 'Mensagens e publicação', 'Editar o painel de denúncias']] },
    parcerias: { area: 'atendimento', back: 'parceria-admin:back', tasks: [['parceria-admin:channels', 'Canais e logs', 'Solicitações, divulgação e registros'], ['parceria-admin:roles', 'Equipe e cargos', 'Responsáveis e cargos de parceria'], ['parceria-admin:requirements', 'Requisitos da parceria', 'Critérios para receber solicitações'], ['parceria-admin:appearance', 'Mensagens e publicação', 'Prévia e edição do painel público']] },
    familias: { area: 'servidor', tasks: [['adm-familias:criar', 'Cadastrar família', 'Nome, dono, cargo e representantes'], ['adm-familias:listar', 'Gerenciar famílias', 'Membros, liderança e configurações'], ['adm-familias:membrosglobais', 'Membros das famílias', 'Consulte os participantes de todas as famílias'], ['adm-familias:ausencias', 'Ausências', 'Revise a atividade dos participantes'], ['adm-familias:configuracoes', 'Configurações das famílias', 'Critérios de atividade e preferências']] },
    feedback: { area: 'servidor', back: 'adm-feedback:back', tasks: [['adm-feedback:appearance', 'Mensagem do painel', 'Edite o convite para enviar feedback'], ['adm-feedback:history', 'Histórico privado', 'Consulte o feedback recebido']] },
    estatisticas: { area: 'servidor', tasks: [] },
    inatividade: { area: 'servidor', tasks: [['adm-cleanup:goals', 'Metas da análise', 'Mensagens, tempo em call e período de entrada'], ['adm-cleanup:mode:PROPORTIONAL', 'Recém-chegados: meta proporcional', 'Ajuste as metas ao tempo de participação'], ['adm-cleanup:mode:IGNORE', 'Recém-chegados: ignorar', 'Retire membros recentes da análise'], ['adm-cleanup:mode:NORMAL', 'Recém-chegados: metas normais', 'Aplique as mesmas metas a todos']] },
    eventos: { area: 'staff', back: 'adm-event-info:back', tasks: [['adm-event-info:truth', 'Verdade ou Desafio', 'Veja os comandos e como jogar'], ['music-admin:menu', 'Jogo musical', 'Configure e acompanhe as partidas']] },
    gameschat: { area: 'staff', tasks: [] }, bingo: { area: 'staff', tasks: [] }, freefire: { area: 'staff', tasks: [] },
    sorteios: { area: 'staff', back: 'giveaway-admin:back', tasks: [['giveaway-admin:new', 'Criar sorteio', 'Informações, publicação e requisitos'], ['giveaway-admin:appearance', 'Mensagens dos sorteios', 'Textos, imagens e mensagens de resultado'], ['giveaway-admin:permissions', 'Equipe e logs', 'Responsáveis e canal de registros'], ['giveaway-admin:history', 'Histórico', 'Ações realizadas nos sorteios'], ['giveaway-admin:stats', 'Estatísticas', 'Participações, resultados e prêmios']] },
    social: { area: 'entretenimento', back: 'social-admin:back', tasks: [['social-admin:personalize', 'Aparência do INSTA', 'Texto, cor e imagens'], ['social-admin:ranking', 'Ranking e destaques', 'Consulte o resultado do período']] },
    submundo: { area: 'entretenimento', back: 'adm-submundo:back', tasks: [['adm-submundo:photos', 'Fotos e vídeos anônimos', 'Painel, destino, horários e privacidade'], ['adm-submundo:messages', 'Mensagens anônimas', 'Painel, destino, horários e privacidade'], ['adm-submundo:highlight', 'Destaques', 'Critério e canal das publicações em destaque'], ['adm-submundo:reset', 'Restaurar configurações', 'Abre a confirmação; preserva o histórico']] },
    radio: { area: 'entretenimento', back: 'adm-radio:back', tasks: [['adm-radio:voice', 'Call da rádio', 'Escolha o canal de voz'], ['adm-radio:playlist:1', 'Playlist', 'Adicionar, remover e ordenar as faixas'], ['adm-radio:mode', 'Ordem de reprodução', 'Sequencial ou aleatória'], ['adm-radio:control', 'Controles da reprodução', 'Acompanhe e controle a faixa atual'], ['adm-radio:volume', 'Volume', 'Ajuste o volume da rádio'], ['adm-radio:reset', 'Restaurar rádio', 'Abre a confirmação das configurações']] },
    oficializacao: { area: 'membros', back: 'member-rise:back', tasks: [['member-rise:roles', 'Cargos inicial e oficial', 'Defina os cargos antes e depois da oficialização'], ['member-rise:requirements', 'Requisitos para oficializar', 'Mensagens, call e modo de cumprimento'], ['member-rise:voice', 'Regras de call', 'Participantes mínimos e tempo considerado'], ['member-rise:messages', 'Mensagens de oficialização', 'Anúncio público e mensagem privada'], ['member-rise:progress:0', 'Progresso dos membros', 'Consulte e revise cada participante'], ['member-rise:history:0', 'Histórico', 'Oficializações automáticas e manuais'], ['member-rise:preview', 'Prévia e variáveis', 'Confira o resultado das mensagens']] },
};
function cleanAdminLabel(value) {
    return value?.replace(/^[\p{Extended_Pictographic}\uFE0F\u200D\s]+/u, '').trim();
}
/** Preserve native controls, disabled states and IDs; only group visible navigation actions. */
function prepareAdminPanel(guild, key, payload) {
    const spec = exports.ADMIN_TASKS[key];
    if (!spec)
        return payload;
    const rows = (payload.components || []).map((r) => typeof r.toJSON === 'function' ? r.toJSON() : structuredClone(r));
    const visible = new Map();
    const kept = [];
    const icon = (0, admEmojis_1.admEmoji)(guild, spec.area);
    for (const r of rows) {
        const components = [];
        for (const c of r.components || []) {
            if (c.type === 2 && (c.custom_id?.startsWith('adm-nav:') || c.custom_id === spec.back))
                continue;
            if (c.type === 2 && spec.tasks.some(t => t[0] === c.custom_id)) {
                visible.set(c.custom_id, c);
                continue;
            }
            if (c.label)
                c.label = cleanAdminLabel(c.label);
            if (c.emoji && !c.emoji.id)
                delete c.emoji;
            if (c.options)
                c.options = c.options.filter((o) => o.value !== 'back' && o.value !== 'home').map((o) => ({ ...o, label: cleanAdminLabel(o.label), ...(icon ? { emoji: { id: icon } } : { emoji: undefined }) }));
            if (c.options && !c.options.length)
                continue;
            components.push(c);
        }
        if (components.length)
            kept.push({ ...r, components });
    }
    const tasks = spec.tasks.filter(([id]) => visible.has(id));
    const nav = tasks.length ? new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.StringSelectMenuBuilder().setCustomId(`admin-task:${key}`).setPlaceholder('Escolha a tarefa que deseja realizar').addOptions(tasks.map(([id, label, description]) => ({ value: id, label, description, ...(icon ? { emoji: icon } : {}), ...(visible.get(id).disabled ? { description: 'Indisponível no estado atual' } : {}) })))) : null;
    // A disabled button must never become an enabled select option.
    if (nav) {
        const active = tasks.filter(([id]) => !visible.get(id).disabled);
        if (active.length)
            nav.components[0].setOptions(active.map(([id, label, description]) => ({ value: id, label, description, ...(icon ? { emoji: icon } : {}) })));
        else
            nav.components[0].setDisabled(true);
    }
    const components = [...(nav ? [nav] : []), ...kept.map((r) => discord_js_1.ActionRowBuilder.from(r)), (0, admPanel_1.adminBackRow)(spec.area)];
    if (components.length > 5)
        return payload;
    return { ...payload, content: payload.content ?? null, attachments: payload.attachments ?? [], components };
}
async function dispatchAdminTask(i, key, value) {
    if (!i.guild || !exports.ADMIN_TASKS[key]?.tasks.some(([id]) => id === value))
        return;
    const { isBotAdmin } = require('./permissions');
    if (!await isBotAdmin(await i.guild.members.fetch(i.user.id)))
        return i.reply({ content: 'Você não possui permissão para configurar este servidor.', ephemeral: true });
    const handlers = i.client.buttons;
    const handler = handlers?.get(value) || [...(handlers?.values() || [])].filter((h) => value.startsWith(h.customId)).sort((a, b) => b.customId.length - a.customId.length)[0];
    if (!handler)
        return i.reply({ content: 'Esta tarefa não está disponível. Reabra o painel com /adm.', ephemeral: true });
    const adapted = new Proxy(i, { get(target, prop) { if (prop === 'customId')
            return value; if (prop === 'isButton')
            return () => true; if (['isStringSelectMenu', 'isAnySelectMenu', 'isRoleSelectMenu', 'isChannelSelectMenu', 'isUserSelectMenu'].includes(String(prop)))
            return () => false; const v = Reflect.get(target, prop, target); return typeof v === 'function' ? v.bind(target) : v; } });
    return handler.execute(adapted);
}
