"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.adminMessagePreviewPayload = adminMessagePreviewPayload;
exports.showAdminMessagePreview = showAdminMessagePreview;
const discord_js_1 = require("discord.js");
const panelInteraction_1 = require("./panelInteraction");
async function adminMessagePreviewPayload(guild, key, focused = false) {
    let preview, prefix, title, home = '';
    if (key === 'parcerias') {
        const m = require('./partnerships');
        preview = m.openingPanel(await m.partnershipConfig(guild.id), true);
        prefix = 'parceria-admin';
        title = 'Parcerias';
    }
    else if (key === 'denuncias') {
        const m = require('./reports');
        preview = m.reportOpeningPanel(await m.reportConfig(guild.id), true);
        prefix = 'adm-denuncia';
        title = 'Central de denúncias';
    }
    else if (key === 'feedback') {
        const m = require('./serverFeedback');
        preview = m.serverFeedbackPanelView(await m.getServerFeedbackConfig(guild.id));
        prefix = 'adm-feedback';
        title = 'Feedback da comunidade';
        home = 'adm-feedback:menu';
    }
    else if (key === 'anonymous-photo' || key === 'anonymous-message') {
        const m = require('../../app/submundo/service'), photo = key === 'anonymous-photo';
        const c = await (photo ? m.getAnonymousPhotoConfig : m.getAnonymousMessageConfig)(guild.id);
        preview = (photo ? m.buildAnonymousMediaPanelView : m.buildAnonymousMessagePanelView)(c, await m.getGuildTimezone(guild.id));
        prefix = 'adm-' + key;
        title = photo ? 'Fotos e vídeos anônimos' : 'Mensagens anônimas';
        home = prefix + ':home';
    }
    else
        throw Error('Prévia administrativa inválida.');
    const button = (id, label, style = discord_js_1.ButtonStyle.Secondary) => new discord_js_1.ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style);
    const rows = (preview.components || []).map((row) => { const data = typeof row.toJSON === 'function' ? row.toJSON() : structuredClone(row); for (const c of data.components)
        if (c.type === 2 && c.custom_id)
            c.disabled = true; return discord_js_1.ActionRowBuilder.from(data); });
    const simple = ['feedback', 'anonymous-photo', 'anonymous-message'].includes(key);
    const controls = focused ? [button(`admin-preview:edit-${key}`, 'Voltar ao editor')] : [button(`${prefix}:${simple ? 'appearance' : 'edit-embed'}`, 'Editar mensagem'), ...(!simple ? [button(`${prefix}:edit-button`, 'Editar botão')] : []), button(`admin-preview:${key}`, 'Ver prévia'), button(`${prefix}:publish`, 'Publicar / atualizar', discord_js_1.ButtonStyle.Primary)];
    return { content: `**${title} · ${focused ? 'Prévia' : 'Mensagens e publicação'}**\n${focused ? 'Esta visualização não publica a mensagem.' : 'Salvar atualiza esta mesma embed. Use Publicar / atualizar para alterar o painel público.'}`, attachments: [], embeds: preview.embeds, components: [...rows, new discord_js_1.ActionRowBuilder().addComponents(...controls), ...(!focused ? [new discord_js_1.ActionRowBuilder().addComponents(button(home || (key === 'parcerias' ? 'admin-task-home:parcerias' : `${prefix}:menu`), 'Voltar'))] : [])], allowedMentions: { parse: [] } };
}
async function showAdminMessagePreview(i, key, focused = false) { return (0, panelInteraction_1.refreshPanel)(i, await adminMessagePreviewPayload(i.guild, key, focused)); }
