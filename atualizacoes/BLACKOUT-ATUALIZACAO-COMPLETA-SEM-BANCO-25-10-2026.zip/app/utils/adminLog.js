"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveLogChannel = resolveLogChannel;
exports.sendCategoryLog = sendCategoryLog;
exports.logAdminAction = logAdminAction;
const enums_1 = require("../structures/enums");
const prisma_1 = require("../database/prisma");
const embeds_1 = require("./embeds");
const config_1 = require("../logging/config");
const delivery_1 = require("../logging/delivery");
const groups = { MODERATION: "moderation", SECURITY: "security", REINTEGRATION: "reintegration", SYSTEM: "system" };
async function resolveLogChannel(guild, category) { return (0, delivery_1.resolveLocalLogChannel)(guild, groups[category], await (0, config_1.readLogSettings)(guild.id)).catch(() => null); }
async function sendCategoryLog(guild, category, embed) { return (0, delivery_1.emitLog)(guild, `${groups[category]}.actions`, embed); }
async function logAdminAction({ guild, actorId, action, targetId, details, context }) {
    await prisma_1.prisma.adminLog.create({ data: { guildId: guild.id, actorId, action, targetId, details } });
    const category = enums_1.ACTION_LOG_CATEGORY[action] ?? enums_1.LogCategory.SYSTEM;
    const key = action === enums_1.AdminLogAction.MEMBER_JOINED ? "member.join" : action === enums_1.AdminLogAction.MEMBER_LEFT ? "member.leave" : `${groups[category]}.actions`;
    const familyActions = new Set([enums_1.AdminLogAction.FAMILY_CREATED, enums_1.AdminLogAction.FAMILY_UPDATED, enums_1.AdminLogAction.FAMILY_DELETED, enums_1.AdminLogAction.FAMILY_LEADER_SET, enums_1.AdminLogAction.FAMILY_CALL_LOCKED, enums_1.AdminLogAction.FAMILY_CALL_UNLOCKED, enums_1.AdminLogAction.FAMILY_CALL_LIMIT_SET, enums_1.AdminLogAction.FAMILY_NOTICE_SENT]);
    const isFamilyAction = familyActions.has(action);
    const embed = (await (0, embeds_1.baseEmbed)(guild)).setTitle(isFamilyAction ? "LOG DE FAMÍLIAS" : enums_1.LOG_CATEGORY_LABELS[category].label).addFields({ name: "Ação", value: action, inline: true }, { name: key.startsWith("member.") ? "Membro" : "Responsável", value: `<@${actorId}>`, inline: true }, ...(targetId ? [{ name: "Alvo", value: `<@${targetId}>`, inline: true }] : []), ...(details ? [{ name: "Detalhes", value: details.slice(0, 1024) }] : [])).setTimestamp();
    const member = guild.members.cache?.get(actorId);
    let localOverrideId;
    if (isFamilyAction) {
        const config = await prisma_1.prisma.familyConfig.findUnique({ where: { guildId: guild.id } }).catch(() => null);
        localOverrideId = config?.logChannelId ?? undefined;
    }
    return (0, delivery_1.emitLog)(guild, key, embed, { userId: key.startsWith("member.") ? actorId : undefined, bot: key.startsWith("member.") ? member?.user.bot : undefined, roleIds: member?.roles.cache.map(r => r.id), localOverrideId, ...context });
}
