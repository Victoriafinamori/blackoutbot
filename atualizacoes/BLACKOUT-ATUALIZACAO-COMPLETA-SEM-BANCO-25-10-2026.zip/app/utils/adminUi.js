"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ADMIN_AREA_LABELS = exports.BLACKOUT_RED = void 0;
exports.adminEmbed = adminEmbed;
const discord_js_1 = require("discord.js");
const admEmojis_1 = require("./admEmojis");
exports.BLACKOUT_RED = 0xd71935;
exports.ADMIN_AREA_LABELS = {
    sistema: "Personalização do bot", seguranca: "Equipe e proteção", membros: "Entrada e evolução",
    atendimento: "Atendimento", servidor: "Comunidade e atividade", staff: "Jogos e eventos",
    entretenimento: "Social e entretenimento",
};
/** Only administrative views use this theme. Saved/public embeds keep their design. */
class AdminEmbed extends discord_js_1.EmbedBuilder {
    setTitle(title) {
        return super.setTitle(title?.replace(/^[\p{Extended_Pictographic}\uFE0F\u200D\s]+/u, "") ?? null);
    }
    addFields(...fields) {
        return super.addFields(...fields.flat().map(field => ({ ...field, name: field.name?.replace(/^[\p{Extended_Pictographic}\uFE0F\u200D\s]+/u, '') })));
    }
    setFields(...fields) {
        return super.setFields(...fields.flat().map(field => ({ ...field, name: field.name?.replace(/^[\p{Extended_Pictographic}\uFE0F\u200D\s]+/u, '') })));
    }
}
function adminEmbed(guild, area) {
    const bot = guild.client.user;
    const embed = new AdminEmbed().setColor(exports.BLACKOUT_RED)
        .setAuthor({ name: `BLACKOUT · ${exports.ADMIN_AREA_LABELS[area]}`, ...(bot ? { iconURL: bot.displayAvatarURL() } : {}) })
        .setFooter({ text: "BLACKOUT · Administração" });
    const image = (0, admEmojis_1.adminEmojiImage)(guild, area);
    if (image)
        embed.setThumbnail(image);
    return embed;
}
