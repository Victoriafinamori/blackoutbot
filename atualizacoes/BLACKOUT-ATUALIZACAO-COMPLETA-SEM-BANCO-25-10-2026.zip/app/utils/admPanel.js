"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ADM_SECTION_ORDER = exports.ADM_SECTIONS = void 0;
exports.resolveAdmSection = resolveAdmSection;
exports.adminBackRow = adminBackRow;
exports.buildAdmRootPanel = buildAdmRootPanel;
exports.buildAdmSectionPanel = buildAdmSectionPanel;
const discord_js_1 = require("discord.js");
const admEmojis_1 = require("./admEmojis");
const adminUi_1 = require("./adminUi");
exports.ADM_SECTIONS = {
    sistema: { label: "Personalização do bot", description: "Perfil neste servidor, padrão visual e mensagens", intro: "Personalize o perfil do bot e as mensagens da sua comunidade. As alterações valem somente para este servidor.", modules: [
            { value: "cfg:aparencia", label: "Perfil neste servidor", description: "Nome, avatar e banner do bot na sua comunidade" },
            { value: "cfg:padrao", label: "Padrão das mensagens", description: "Cor, autor, rodapé e miniatura padrão" },
            { value: "cfg:embeds", label: "Mensagens Personalizadas / Embeds", description: "Criar, editar e publicar mensagens próprias" },
        ] },
    seguranca: { label: "Equipe e proteção", description: "Administradores, permissões, moderação e logs", intro: "Defina quem cuida do servidor e prepare as ferramentas de proteção.", modules: [
            { value: "administracao", label: "Equipe e permissões", description: "Administradores do bot, cargos e acessos" },
            { value: "protecao", label: "Central de segurança", description: "Anti-Raid, entrada, Anti Ban e proteção do servidor" },
            { value: "moderacao", label: "Moderação de membros", description: "Membro, histórico, ações e reversões" },
            { value: "logs", label: "Logs e auditoria", description: "Canais e histórico de eventos do servidor" },
        ] },
    membros: { label: "Entrada e evolução", description: "Cargos de entrada, registro e progressão", intro: "Organize a jornada de quem chega e de quem já faz parte da comunidade.", modules: [
            { value: "cfg:autocargo", label: "Cargos e automações", description: "Cargos de entrada, transferências e cargos por reação" },
            { value: "registro", label: "Registro de membros", description: "Painel de entrada, formulário e cargos" },
            { value: "subidamembros", label: "Oficialização de membros", description: "Requisitos e acompanhamento da progressão" },
            { value: "reintegracao", label: "Reintegração", description: "Etapas, membros e retorno à comunidade" },
        ] },
    atendimento: { label: "Atendimento", description: "Tickets, denúncias e parcerias", intro: "Prepare os canais de contato entre a comunidade e a equipe.", modules: [
            { value: "tickets", label: "Central de tickets", description: "Painel, responsáveis, avaliações e relatórios" },
            { value: "denuncias", label: "Central de denúncias", description: "Atendimento privado, responsáveis e transcripts" },
            { value: "parcerias", label: "Parcerias", description: "Solicitações, aprovação, cargos e divulgação" },
        ] },
    servidor: { label: "Comunidade e atividade", description: "Famílias, rankings, feedback e estatísticas", intro: "Conecte os membros e acompanhe a atividade da comunidade.", modules: [
            { value: "familias", label: "Famílias e irmandades", description: "Grupos, cargos e espaços da comunidade" },
            { value: "movchat", label: "Atividade no chat", description: "Mensagens, níveis, canais e ranking" },
            { value: "movcall", label: "Atividade em call", description: "Tempo em voz, ranking e recompensas" },
            { value: "feedbackservidor", label: "Feedback da comunidade", description: "Sugestões anônimas e votação" },
            { value: "estatisticas", label: "Estatísticas do servidor", description: "Indicadores gerais da comunidade" },
            { value: "limpa", label: "Análise de inatividade", description: "Revise a atividade antes de qualquer limpeza" },
        ] },
    staff: { label: "Jogos e eventos", description: "Jogos de chat, sorteios, Bingo e Free Fire", intro: "Com a base pronta, prepare os momentos de interação do servidor.", modules: [
            { value: "eventos", label: "Eventos de interação", description: "Verdade ou Desafio, Game Musical e Quiz em equipes" },
            { value: "gameschat", label: "Jogos de chat", description: "Caixa Misteriosa e TERMO" },
            { value: "sorteios", label: "Sorteios", description: "Criar, agendar, acompanhar e sortear" },
            { value: "bingo", label: "Bingo", description: "Cartelas, painéis e partidas" },
            { value: "freefire", label: "Campeonatos de Free Fire", description: "Duplas, vagas, inscrições e aprovação" },
        ] },
    entretenimento: { label: "Social e entretenimento", description: "INSTA, dinâmicas, Submundo e Rádio 24h", intro: "Crie espaços para a comunidade compartilhar, conversar e ouvir música.", modules: [
            { value: "social", label: "INSTA", description: "Publicações, curtidas, comentários e destaques" },
            { value: "dinamicassociais", label: "Dinâmicas sociais", description: "Perguntas, preferências, enquetes e desafios" },
    { value: "submundo", label: "Submundo", description: "Fotos, vídeos e mensagens anônimas" },
            { value: "radio24h", label: "Rádio 24h", description: "Playlist contínua em call com links do YouTube" },
        ] },
};
exports.ADM_SECTION_ORDER = Object.keys(exports.ADM_SECTIONS);
/** Old messages can still return from the former championship category. */
function resolveAdmSection(value) {
    if (value === "campeonatos")
        return "staff";
    return Object.prototype.hasOwnProperty.call(exports.ADM_SECTIONS, value) ? value : undefined;
}
function adminBackRow(area) {
    return new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder()
        .setCustomId(`adm-nav:${area ?? "root"}`)
        .setLabel(area ? `Voltar · ${exports.ADM_SECTIONS[area].label}` : "Central do servidor")
        .setStyle(discord_js_1.ButtonStyle.Secondary));
}
async function buildAdmRootPanel(guild, _requester) {
    const embed = (0, adminUi_1.adminEmbed)(guild, "sistema").setAuthor({ name: "BLACKOUT · Administração" })
        .setThumbnail(null).setTitle("Central do servidor")
        .setDescription("Da primeira configuração à rotina da comunidade.\nEscolha a área que você quer organizar.")
            .setImage("attachment://blackout-header.png").setFooter({ text: "Organize · Proteja · Conecte" });
    const select = new discord_js_1.StringSelectMenuBuilder().setCustomId("adm-panel-select")
        .setPlaceholder("Escolha uma área do servidor")
        .addOptions(exports.ADM_SECTION_ORDER.map((area, index) => {
        const data = exports.ADM_SECTIONS[area], emoji = (0, admEmojis_1.admEmoji)(guild, area);
        return { value: area, label: `${index + 1}. ${data.label}`, description: data.description, ...(emoji ? { emoji } : {}) };
    }));
    return { content: null, embeds: [embed], components: [new discord_js_1.ActionRowBuilder().addComponents(select)], attachments: [],
        files: [new discord_js_1.AttachmentBuilder((0, admEmojis_1.adminAsset)("header.png"), { name: "blackout-header.png" })] };
}
async function buildAdmSectionPanel(guild, requested) {
    const area = resolveAdmSection(requested);
    if (!area)
        throw new Error("Área administrativa inválida.");
    const data = exports.ADM_SECTIONS[area];
    const embed = (0, adminUi_1.adminEmbed)(guild, area).setAuthor({ name: "BLACKOUT · Central do servidor" })
        .setTitle(data.label).setDescription(data.intro)
        .setThumbnail("attachment://blackout-area.png")
        .setFooter({ text: `${data.modules.length} módulos · Escolha o que deseja configurar` });
      const emoji = (0, admEmojis_1.admEmoji)(guild, area);
    const select = new discord_js_1.StringSelectMenuBuilder().setCustomId(`adm-section-select:${area}`)
        .setPlaceholder(area === "membros" ? "Escolha uma etapa da jornada" : "Escolha o que deseja configurar")
        .addOptions(data.modules.map(module => ({ value: module.value, label: module.label, description: module.description, ...(emoji ? { emoji } : {}) })));
    return { content: null, embeds: [embed], components: [new discord_js_1.ActionRowBuilder().addComponents(select), adminBackRow()], attachments: [],
        files: [new discord_js_1.AttachmentBuilder((0, admEmojis_1.adminIconFile)(area), { name: "blackout-area.png" })] };
}
