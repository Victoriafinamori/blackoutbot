"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildCustomEmbedMessage = buildCustomEmbedMessage;
exports.buildCustomEmbedRows = buildCustomEmbedRows;
exports.fetchCustomEmbed = fetchCustomEmbed;
exports.normalizeHex = normalizeHex;
const discord_js_1 = require("discord.js");
const prisma_1 = require("../database/prisma");
function normalizeHex(value, fallback = "2B6CB0") {
    const clean = String(value || "").trim().replace(/^#/, "").toUpperCase();
    return /^[0-9A-F]{6}$/.test(clean) ? clean : fallback;
}
async function fetchCustomEmbed(id, guildId) {
    return prisma_1.prisma.customEmbed.findFirst({
        where: { id, guildId },
        include: { buttons: { orderBy: { position: "asc" } } },
    });
}
function makeLinkButton(item, guildId) {
    const target = item.type === "CHANNEL"
        ? (item.channelId ? `https://discord.com/channels/${guildId}/${item.channelId}` : null)
        : item.url;
    if (!target || !/^https?:\/\//i.test(target))
        return null;
    const button = new discord_js_1.ButtonBuilder()
        .setStyle(discord_js_1.ButtonStyle.Link)
        .setLabel((item.label || "Abrir").slice(0, 80))
        .setURL(target);
    if (item.emoji) {
        try {
            button.setEmoji(item.emoji);
        }
        catch { }
    }
    return button;
}
function buildCustomEmbedRows(record, guildId) {
    const rows = [];
    const buttons = (record.buttons || []).slice(0, 25).map((item) => makeLinkButton(item, guildId)).filter(Boolean);
    for (let i = 0; i < buttons.length; i += 5) {
        rows.push(new discord_js_1.ActionRowBuilder().addComponents(...buttons.slice(i, i + 5)));
    }
    return rows;
}
function buildCustomEmbedMessage(record, guildId) {
    const embed = new discord_js_1.EmbedBuilder().setColor(`#${normalizeHex(record.color)}`);
    if (record.title)
        embed.setTitle(record.title.slice(0, 256));
    if (record.description)
        embed.setDescription(record.description.slice(0, 4096));
    if (record.author)
        embed.setAuthor({ name: record.author.slice(0, 256) });
    if (record.footer)
        embed.setFooter({ text: record.footer.slice(0, 2048) });
    if (record.thumbnailUrl)
        embed.setThumbnail(record.thumbnailUrl);
    if (record.imageUrl)
        embed.setImage(record.imageUrl);
    if (record.showTimestamp)
        embed.setTimestamp();
    if (!record.title && !record.description && !record.imageUrl && !record.thumbnailUrl)
        embed.setDescription("*Configure o título e/ou a descrição desta embed.*");
    return { embeds: [embed], components: buildCustomEmbedRows(record, guildId) };
}
