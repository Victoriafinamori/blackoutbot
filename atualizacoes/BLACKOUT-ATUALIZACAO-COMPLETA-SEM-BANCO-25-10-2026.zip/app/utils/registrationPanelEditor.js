"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.registrationPanelDrafts = void 0;
exports.registrationPanelEmbed = registrationPanelEmbed;
exports.registrationPanelPayload = registrationPanelPayload;
exports.registrationPanelEditor = registrationPanelEditor;
const discord_js_1 = require("discord.js");
const registration_1 = require("./registration");
exports.registrationPanelDrafts = new Map();
function panelButtonStyle(style) {
    return { PRIMARY: discord_js_1.ButtonStyle.Primary, SECONDARY: discord_js_1.ButtonStyle.Secondary, SUCCESS: discord_js_1.ButtonStyle.Success, DANGER: discord_js_1.ButtonStyle.Danger }[style] || discord_js_1.ButtonStyle.Secondary;
}
function registrationPanelEmbed(c) {
    const embed = new discord_js_1.EmbedBuilder().setColor(Number.parseInt(c.panelColor, 16) || 0xd20b20)
        .setTitle(c.panelTitle || "Sistema de Registro")
        .setDescription(c.panelDescription || "Clique no botão abaixo para iniciar seu registro.");
    if (c.panelImage)
        embed.setImage(c.panelImage);
    if (c.panelThumbnail)
        embed.setThumbnail(c.panelThumbnail);
    if (c.panelFooter)
        embed.setFooter({ text: c.panelFooter });
    if (c.panelAuthor)
        embed.setAuthor({ name: c.panelAuthor });
    return embed;
}
function registrationPanelPayload(c) {
    const button = new discord_js_1.ButtonBuilder().setCustomId("registration-panel:open").setLabel(c.panelButtonLabel || "INICIAR STAND").setStyle(panelButtonStyle(c.panelButtonStyle));
    if (c.panelButtonEmoji)
        button.setEmoji(c.panelButtonEmoji);
    return { embeds: [registrationPanelEmbed(c)], components: [new discord_js_1.ActionRowBuilder().addComponents(button)] };
}
async function registrationPanelEditor(guild) {
    const c = await (0, registration_1.regConfig)(guild.id);
    const items = ["Texto principal", "Botão", c.panelThumbnail && "Thumbnail", c.panelImage && "Imagem", c.panelAuthor && "Autor", c.panelFooter && "Rodapé"].filter(Boolean).join(" • ");
    const preview = registrationPanelEmbed(c);
    const add = new discord_js_1.StringSelectMenuBuilder().setCustomId("registration-panel-editor:add").setPlaceholder("Adicionar item").addOptions({ label: "Texto / Seção", value: "text", description: "Título e texto principal do painel" }, { label: "Thumbnail", value: "thumbnail", description: "Upload de imagem pequena ao lado do texto" }, { label: "Imagem / Banner", value: "image", description: "Banner recomendado: 1200 × 400 pixels" }, { label: "Autor", value: "author", description: "Texto exibido acima do título" }, { label: "Rodapé", value: "footer", description: "Texto exibido no final da embed" }, { label: "Botão principal", value: "button", description: "Nome, emoji e cor do botão" }, { label: "Resetar tudo", value: "reset", description: "Restaura a aparência padrão" });
    const edit = new discord_js_1.StringSelectMenuBuilder().setCustomId("registration-panel-editor:edit").setPlaceholder("Editar ou remover item").addOptions({ label: "Texto / Seção", value: "text", description: "Editar título e descrição" }, { label: "Thumbnail", value: "thumbnail", description: c.panelThumbnail ? "Enviar uma nova imagem" : "Ainda não configurada" }, { label: "Remover thumbnail", value: "remove-thumbnail", description: c.panelThumbnail ? "Excluir a imagem pequena atual" : "Nada para remover" }, { label: "Imagem / Banner", value: "image", description: c.panelImage ? "Enviar uma nova imagem" : "Ainda não configurada" }, { label: "Remover imagem / banner", value: "remove-image", description: c.panelImage ? "Excluir o banner atual" : "Nada para remover" }, { label: "Autor", value: "author", description: c.panelAuthor ? "Editar ou remover" : "Ainda não configurado" }, { label: "Rodapé", value: "footer", description: c.panelFooter ? "Editar ou remover" : "Ainda não configurado" }, { label: "Botão principal", value: "button", description: `${c.panelButtonLabel} • ${c.panelButtonStyle}` });
    return { content: "**Registro · Painel público**\nAs alterações salvas aparecem nesta mesma embed. Publicar / atualizar altera o painel público.", attachments: [], allowedMentions: { parse: [] }, embeds: [preview], components: [
            ...registrationPanelPayload(c).components.map(row => { row.components.forEach(button => button.setDisabled(true)); return row; }),
            new discord_js_1.ActionRowBuilder().addComponents(add),
            new discord_js_1.ActionRowBuilder().addComponents(edit),
            new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("registration-panel-editor:color").setLabel("Cor").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId("registration-panel-editor:save").setLabel("Salvar modelo").setStyle(discord_js_1.ButtonStyle.Success), new discord_js_1.ButtonBuilder().setCustomId("registration-panel-editor:preview").setLabel("Ver prévia").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId("adm-reg-embed:publish").setLabel("Publicar / atualizar").setStyle(discord_js_1.ButtonStyle.Primary), new discord_js_1.ButtonBuilder().setCustomId("registration-ui:messages").setLabel("Voltar").setStyle(discord_js_1.ButtonStyle.Secondary)),
        ] };
}
//# sourceMappingURL=registrationPanelEditor.js.map