"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.partnershipRoleIds = partnershipRoleIds;
exports.partnershipSettingsPayload = partnershipSettingsPayload;
const discord_js_1 = require("discord.js");
const adminUi_1 = require("./adminUi");
function partnershipRoleIds(raw) { try {
    return JSON.parse(raw || '[]');
}
catch {
    return String(raw || '').split(',').filter(Boolean);
} }
async function partnershipSettingsPayload(guild, view) {
    const c = await require('./partnerships').partnershipConfig(guild.id), e = (0, adminUi_1.adminEmbed)(guild, 'atendimento');
    const components = [];
    if (view === 'channels') {
        e.setTitle('Canais e logs · Parcerias').setDescription('Escolha os destinos deste módulo. Uma seleção vazia remove o destino.');
        for (const [name, label, key, category] of [['panel', 'Canal do painel', 'panelChannelId', false], ['category', 'Categoria do atendimento', 'categoryId', true], ['logs', 'Canal de logs', 'logChannelId', false], ['publish', 'Canal de divulgação', 'publishChannelId', false]]) {
            e.addFields({ name: label, value: c[key] ? `<#${c[key]}>` : 'Não configurado' });
            const s = new discord_js_1.ChannelSelectMenuBuilder().setCustomId(`parceria-admin-select:${name}`).setPlaceholder(label).addChannelTypes(category ? discord_js_1.ChannelType.GuildCategory : discord_js_1.ChannelType.GuildText).setMinValues(0).setMaxValues(1);
            if (c[key])
                s.setDefaultChannels(c[key]);
            components.push(new discord_js_1.ActionRowBuilder().addComponents(s));
        }
    }
    else {
        e.setTitle('Equipe e cargos · Parcerias').setDescription('Os responsáveis atendem as solicitações. O cargo de parceiro é atribuído ao concluir a parceria.');
        for (const [name, label, values] of [['staff', 'Responsáveis pelo atendimento', partnershipRoleIds(c.staffRoleIds)], ['partner', 'Cargo de parceiro', c.partnerRoleId ? [c.partnerRoleId] : []]]) {
            e.addFields({ name: label, value: values.map((id) => `<@&${id}>`).join(', ') || 'Nenhum' });
            const s = new discord_js_1.RoleSelectMenuBuilder().setCustomId(`parceria-admin-select:${name}`).setPlaceholder(label).setMinValues(0).setMaxValues(name === 'staff' ? 10 : 1);
            if (values.length)
                s.setDefaultRoles(values);
            components.push(new discord_js_1.ActionRowBuilder().addComponents(s));
        }
    }
    components.push(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId('admin-task-home:parcerias').setLabel('Voltar · Parcerias').setStyle(discord_js_1.ButtonStyle.Secondary)));
    return { content: null, attachments: [], embeds: [e], components, allowedMentions: { parse: [] } };
}
