"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ModerationError = void 0;
exports.getActiveWarns = getActiveWarns;
exports.warnMember = warnMember;
exports.removeWarn = removeWarn;
exports.clearWarns = clearWarns;
exports.muteMember = muteMember;
exports.unmuteMember = unmuteMember;
exports.kickMember = kickMember;
exports.banMember = banMember;
exports.unbanMember = unbanMember;
exports.getModerationHistory = getModerationHistory;
const prisma_1 = require("../database/prisma");
const guildConfig_1 = require("../database/guildConfig");
const adminLog_1 = require("./adminLog");
const enums_1 = require("../structures/enums");
const wordWatch_1 = require("./wordWatch");
class ModerationError extends Error {
}
exports.ModerationError = ModerationError;
// Limite do timeout nativo do Discord (28 dias)
const MAX_TIMEOUT_MS = 28 * 24 * 60 * 60 * 1000;
async function notifyMember(guild, userId, message) {
    const config = await (0, guildConfig_1.getOrCreateGuildConfig)(guild.id);
    if (!(config.moderationNotifyDm ?? config.notifyDm))
        return;
    const user = await guild.client.users.fetch(userId).catch(() => null);
    if (!user)
        return;
    await user.send(message).catch(() => null);
}
async function publicNotice(guild, message) {
    const config = await (0, guildConfig_1.getOrCreateGuildConfig)(guild.id);
    if (!config.notifyPublicWarns || !config.reportsChannelId)
        return;
    const channel = guild.channels.cache.get(config.reportsChannelId);
    if (channel && channel.isTextBased())
        await channel.send(message).catch(() => null);
}
// -----------------------------
// Advertências (warns)
// -----------------------------
function getActiveWarns(guildId, userId) {
    return prisma_1.prisma.warn.findMany({
        where: { guildId, userId, active: true },
        orderBy: { createdAt: "desc" },
    });
}
/**
 * Aplica uma advertência e, se o total de advertências ativas atingir os
 * limites configurados, escala automaticamente para mute ou ban.
 */
async function warnMember(guild, actorId, userId, reason) {
    const config = await (0, guildConfig_1.getOrCreateGuildConfig)(guild.id);
    const warn = await prisma_1.prisma.warn.create({
        data: { guildId: guild.id, userId, moderatorId: actorId, reason },
    });
    await (0, adminLog_1.logAdminAction)({
        guild,
        actorId,
        action: enums_1.AdminLogAction.WARN_ADDED,
        targetId: userId,
        details: reason,
    });
    await notifyMember(guild, userId, `⚠️ Você recebeu uma advertência em **${guild.name}**.\n**Motivo:** ${reason}`);
    await publicNotice(guild, `⚠️ <@${userId}> recebeu uma advertência. **Motivo:** ${reason}`);
    const activeWarns = await getActiveWarns(guild.id, userId);
    const count = activeWarns.length;
    const botId = guild.client.user?.id ?? actorId;
    if (config.maxWarnsBeforeBan > 0 && count >= config.maxWarnsBeforeBan) {
        await banMember(guild, botId, userId, `Automático: atingiu ${count} advertência(s) ativa(s).`, true).catch(() => null);
    }
    else if (config.maxWarnsBeforeMute > 0 && count >= config.maxWarnsBeforeMute) {
        await muteMember(guild, botId, userId, `Automático: atingiu ${count} advertência(s) ativa(s).`, config.autoMuteDurationMinutes, true).catch(() => null);
    }
    return { warn, count };
}
async function removeWarn(guild, actorId, warnId) {
    const warn = await prisma_1.prisma.warn.update({ where: { id: warnId }, data: { active: false } });
    await (0, adminLog_1.logAdminAction)({
        guild,
        actorId,
        action: enums_1.AdminLogAction.WARN_REMOVED,
        targetId: warn.userId,
    });
    return warn;
}
async function clearWarns(guild, actorId, userId, reason) {
    await prisma_1.prisma.warn.updateMany({
        where: { guildId: guild.id, userId, active: true },
        data: { active: false },
    });
    await (0, adminLog_1.logAdminAction)({
        guild,
        actorId,
        action: enums_1.AdminLogAction.WARNS_CLEARED,
        targetId: userId,
    details: reason,
    });
}
// -----------------------------
// Mute (timeout nativo do Discord)
// -----------------------------
async function muteMember(guild, actorId, userId, reason, durationMinutes, automatic = false) {
    const member = await guild.members.fetch(userId).catch(() => null);
    if (!member)
        throw new ModerationError("Membro não encontrado no servidor.");
    if (!member.moderatable) {
        throw new ModerationError("Não tenho permissão para silenciar este membro (cargo mais alto ou dono do servidor).");
    }
    const ms = Math.min(Math.max(durationMinutes, 1) * 60 * 1000, MAX_TIMEOUT_MS);
    await member.timeout(ms, reason);
    const expiresAt = new Date(Date.now() + ms);
    await prisma_1.prisma.mute.create({
        data: { guildId: guild.id, userId, moderatorId: actorId, reason, expiresAt },
    });
    await (0, adminLog_1.logAdminAction)({
        guild,
        actorId,
        action: enums_1.AdminLogAction.MEMBER_MUTED,
        targetId: userId,
        details: `${reason}${automatic ? " (automático)" : ""} — ${durationMinutes} min`,
    });
    await notifyMember(guild, userId, `🔇 Você foi silenciado em **${guild.name}** por ${durationMinutes} minuto(s).\n**Motivo:** ${reason}`);
    return expiresAt;
}
async function unmuteMember(guild, actorId, userId, reason) {
    const member = await guild.members.fetch(userId).catch(() => null);
    if (member?.moderatable)
        await member.timeout(null).catch(() => null);
    await prisma_1.prisma.mute.updateMany({
        where: { guildId: guild.id, userId, active: true },
        data: { active: false },
    });
    await (0, adminLog_1.logAdminAction)({
        guild,
        actorId,
        action: enums_1.AdminLogAction.MEMBER_UNMUTED,
        targetId: userId,
    details: reason,
    });
}
// -----------------------------
// Kick / Ban / Unban
// -----------------------------
async function kickMember(guild, actorId, userId, reason) {
    const member = await guild.members.fetch(userId).catch(() => null);
    if (!member)
        throw new ModerationError("Membro não encontrado no servidor.");
    if (!member.kickable) {
        throw new ModerationError("Não tenho permissão para expulsar este membro.");
    }
    await notifyMember(guild, userId, `👢 Você foi expulso de **${guild.name}**.\n**Motivo:** ${reason}`);
    await member.kick(reason);
    await prisma_1.prisma.moderationAction.create({
        data: {
            guildId: guild.id,
            userId,
            moderatorId: actorId,
            type: enums_1.ModerationActionType.KICK,
            reason,
        },
    });
    await (0, adminLog_1.logAdminAction)({
        guild,
        actorId,
        action: enums_1.AdminLogAction.MEMBER_KICKED,
        targetId: userId,
        details: reason,
    });
}
async function banMember(guild, actorId, userId, reason, automatic = false) {
    const member = await guild.members.fetch(userId).catch(() => null);
    if (member && !member.bannable) {
        throw new ModerationError("Não tenho permissão para banir este membro.");
    }
    await notifyMember(guild, userId, `🔨 Você foi banido de **${guild.name}**.\n**Motivo:** ${reason}`);
    await guild.members.ban(userId, { reason });
    await prisma_1.prisma.moderationAction.create({
        data: {
            guildId: guild.id,
            userId,
            moderatorId: actorId,
            type: enums_1.ModerationActionType.BAN,
            reason: `${reason}${automatic ? " (automático)" : ""}`,
        },
    });
    await (0, adminLog_1.logAdminAction)({
        guild,
        actorId,
        action: enums_1.AdminLogAction.MEMBER_BANNED,
        targetId: userId,
        details: reason,
    });
}
async function unbanMember(guild, actorId, userId, reason) {
    try {
        await guild.members.unban(userId, reason);
    }
    catch {
        throw new ModerationError("Este usuário não está banido (ou já foi desbanido).");
    }
    await prisma_1.prisma.moderationAction.create({
        data: {
            guildId: guild.id,
            userId,
            moderatorId: actorId,
            type: enums_1.ModerationActionType.UNBAN,
            reason,
        },
    });
    await (0, adminLog_1.logAdminAction)({
        guild,
        actorId,
        action: enums_1.AdminLogAction.MEMBER_UNBANNED,
        targetId: userId,
        details: reason,
    });
}
// -----------------------------
// Histórico consolidado
// -----------------------------
async function getModerationHistory(guildId, userId) {
    const [warns, mutes, actions, wordWatchHits] = await Promise.all([
        prisma_1.prisma.warn.findMany({
            where: { guildId, userId },
            orderBy: { createdAt: "desc" },
            take: 10,
        }),
        prisma_1.prisma.mute.findMany({
            where: { guildId, userId },
            orderBy: { createdAt: "desc" },
            take: 5,
        }),
        prisma_1.prisma.moderationAction.findMany({
            where: { guildId, userId },
            orderBy: { createdAt: "desc" },
            take: 5,
        }),
        (0, wordWatch_1.getWordWatchHistory)(guildId, userId, 10),
    ]);
    return { warns, mutes, actions, wordWatchHits };
}
//# sourceMappingURL=moderation.js.map