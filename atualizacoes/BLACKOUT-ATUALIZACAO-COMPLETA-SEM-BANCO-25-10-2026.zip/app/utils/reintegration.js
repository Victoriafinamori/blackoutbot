"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReintegrationError = void 0;
exports.getStages = getStages;
exports.getStage = getStage;
exports.createStage = createStage;
exports.updateStage = updateStage;
exports.setStageRole = setStageRole;
exports.toggleStageAutoProgress = toggleStageAutoProgress;
exports.chatModeLabel = chatModeLabel;
exports.cycleStageChatMode = cycleStageChatMode;
exports.setStageChatLimits = setStageChatLimits;
exports.deleteStage = deleteStage;
exports.moveStage = moveStage;
exports.getActiveMember = getActiveMember;
exports.isBlacklisted = isBlacklisted;
exports.insertMember = insertMember;
exports.removeMember = removeMember;
exports.blacklistMember = blacklistMember;
exports.unblacklistMember = unblacklistMember;
exports.progressMember = progressMember;
exports.addEvaluation = addEvaluation;
exports.runAutoProgression = runAutoProgression;
const prisma_1 = require("../database/prisma");
const adminLog_1 = require("./adminLog");
const guildConfig_1 = require("../database/guildConfig");
const enums_1 = require("../structures/enums");
class ReintegrationError extends Error {
}
exports.ReintegrationError = ReintegrationError;
async function setMemberRole(guild, userId, roleId, add) {
    if (!roleId)
        return;
    const member = await guild.members.fetch(userId).catch(() => null);
    if (!member)
        return;
    if (add)
        await member.roles.add(roleId).catch(() => null);
    else
        await member.roles.remove(roleId).catch(() => null);
}
async function notifyMember(guild, userId, message) {
    const config = await (0, guildConfig_1.getOrCreateGuildConfig)(guild.id);
    if (!(config.reintegrationNotifyDm ?? config.notifyDm))
        return;
    const user = await guild.client.users.fetch(userId).catch(() => null);
    if (!user)
        return;
    await user.send(message).catch(() => null);
}
// -----------------------------
// Etapas
// -----------------------------
function getStages(guildId) {
    return prisma_1.prisma.stage.findMany({ where: { guildId }, orderBy: { order: "asc" } });
}
function getStage(stageId) {
    return prisma_1.prisma.stage.findUnique({ where: { id: stageId } });
}
async function createStage(guild, actorId, data) {
    const stages = await getStages(guild.id);
    const nextOrder = stages.length ? Math.max(...stages.map((s) => s.order)) + 1 : 1;
    const stage = await prisma_1.prisma.stage.create({
        data: {
            guildId: guild.id,
            name: data.name,
            minDays: data.minDays,
            restrictions: data.restrictions ?? null,
            order: nextOrder,
        },
    });
    await (0, adminLog_1.logAdminAction)({
        guild,
        actorId,
        action: enums_1.AdminLogAction.STAGE_CREATED,
        details: `${stage.name} (ordem ${stage.order})`,
    });
    return stage;
}
async function updateStage(guild, actorId, stageId, data) {
    const stage = await prisma_1.prisma.stage.update({ where: { id: stageId }, data });
    await (0, adminLog_1.logAdminAction)({
        guild,
        actorId,
        action: enums_1.AdminLogAction.STAGE_UPDATED,
        details: stage.name,
    });
    return stage;
}
async function setStageRole(guild, actorId, stageId, roleId) {
    const stage = await prisma_1.prisma.stage.update({ where: { id: stageId }, data: { roleId } });
    await (0, adminLog_1.logAdminAction)({
        guild,
        actorId,
        action: enums_1.AdminLogAction.STAGE_UPDATED,
        details: `${stage.name}: cargo ${roleId ? `<@&${roleId}>` : "removido"}`,
    });
    return stage;
}
async function toggleStageAutoProgress(guild, actorId, stageId) {
    const current = await prisma_1.prisma.stage.findUniqueOrThrow({ where: { id: stageId } });
    const stage = await prisma_1.prisma.stage.update({
        where: { id: stageId },
        data: { autoProgress: !current.autoProgress },
    });
    await (0, adminLog_1.logAdminAction)({
        guild,
        actorId,
        action: enums_1.AdminLogAction.STAGE_UPDATED,
        details: `${stage.name}: progressão automática ${stage.autoProgress ? "ativada" : "desativada"}`,
    });
    return stage;
}
const CHAT_MODE_CYCLE = [
    enums_1.StageChatMode.UNRESTRICTED,
    enums_1.StageChatMode.LOCKED,
    enums_1.StageChatMode.LIMITED,
];
function chatModeLabel(mode) {
    switch (mode) {
        case enums_1.StageChatMode.LOCKED:
            return "🔒 Bloqueado (apenas visualização)";
        case enums_1.StageChatMode.LIMITED:
            return "✉️ Limitado (mensagens controladas)";
        default:
            return "🟢 Sem restrição";
    }
}
/**
 * Avança o modo de chat da etapa no ciclo: Sem restrição -> Bloqueado ->
 * Limitado -> Sem restrição.
 */
async function cycleStageChatMode(guild, actorId, stageId) {
    const current = await prisma_1.prisma.stage.findUniqueOrThrow({ where: { id: stageId } });
    const index = CHAT_MODE_CYCLE.indexOf(current.chatMode);
    const next = CHAT_MODE_CYCLE[(index + 1) % CHAT_MODE_CYCLE.length];
    const stage = await prisma_1.prisma.stage.update({ where: { id: stageId }, data: { chatMode: next } });
    await (0, adminLog_1.logAdminAction)({
        guild,
        actorId,
        action: enums_1.AdminLogAction.STAGE_CHAT_CONFIG_CHANGED,
        details: `${stage.name}: chat -> ${chatModeLabel(next)}`,
    });
    return stage;
}
/**
 * Define o limite diário de mensagens e/ou o cooldown (em segundos) usados
 * quando a etapa está em modo "Limitado". Passar null limpa o respectivo
 * limite (sem limite de quantidade / sem cooldown).
 */
async function setStageChatLimits(guild, actorId, stageId, data) {
    const stage = await prisma_1.prisma.stage.update({
        where: { id: stageId },
        data: {
            chatMaxMessagesPerDay: data.chatMaxMessagesPerDay,
            chatCooldownSeconds: data.chatCooldownSeconds,
        },
    });
    await (0, adminLog_1.logAdminAction)({
        guild,
        actorId,
        action: enums_1.AdminLogAction.STAGE_CHAT_CONFIG_CHANGED,
        details: `${stage.name}: limite ${stage.chatMaxMessagesPerDay ?? "sem limite"} msg/dia, ` +
            `cooldown ${stage.chatCooldownSeconds ?? "sem"}s`,
    });
    return stage;
}
async function deleteStage(guild, actorId, stageId) {
    const stage = await prisma_1.prisma.stage.delete({ where: { id: stageId } });
    // Renumera as etapas restantes para manter a ordem contígua (1..N)
    const remaining = await getStages(guild.id);
    await prisma_1.prisma.$transaction(remaining.map((s, index) => prisma_1.prisma.stage.update({ where: { id: s.id }, data: { order: index + 1 } })));
    await (0, adminLog_1.logAdminAction)({
        guild,
        actorId,
        action: enums_1.AdminLogAction.STAGE_DELETED,
        details: stage.name,
    });
    return stage;
}
async function moveStage(guild, actorId, stageId, direction) {
    const stages = await getStages(guild.id);
    const index = stages.findIndex((s) => s.id === stageId);
    if (index === -1)
        throw new ReintegrationError("Etapa não encontrada.");
    const targetIndex = direction === "up" ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= stages.length) {
        throw new ReintegrationError("Não é possível mover a etapa nessa direção.");
    }
    const current = stages[index];
    const target = stages[targetIndex];
    await prisma_1.prisma.$transaction([
        prisma_1.prisma.stage.update({ where: { id: current.id }, data: { order: target.order } }),
        prisma_1.prisma.stage.update({ where: { id: target.id }, data: { order: current.order } }),
    ]);
    await (0, adminLog_1.logAdminAction)({
        guild,
        actorId,
        action: enums_1.AdminLogAction.STAGE_REORDERED,
        details: `${current.name} <-> ${target.name}`,
    });
}
// -----------------------------
// Membros
// -----------------------------
function getActiveMember(guildId, userId) {
    return prisma_1.prisma.reintegrationMember.findFirst({
        where: { guildId, userId, status: enums_1.MemberStatus.ACTIVE },
        include: { currentStage: true },
    });
}
async function isBlacklisted(guildId, userId) {
    const entry = await prisma_1.prisma.blacklist.findUnique({ where: { guildId_userId: { guildId, userId } } });
    return !!entry;
}
async function insertMember(guild, actorId, userId) {
    if (await isBlacklisted(guild.id, userId)) {
        throw new ReintegrationError("Este usuário está na blacklist e não pode ser inserido.");
    }
    if (await getActiveMember(guild.id, userId)) {
        throw new ReintegrationError("Este usuário já está em reintegração.");
    }
    const stages = await getStages(guild.id);
    if (!stages.length) {
        throw new ReintegrationError("Cadastre ao menos uma etapa antes de inserir membros.");
    }
    const firstStage = stages[0];
    const existingRecord = await prisma_1.prisma.reintegrationMember.findUnique({
        where: { guildId_userId: { guildId: guild.id, userId } },
    });
    const member = existingRecord
        ? await prisma_1.prisma.reintegrationMember.update({
            where: { id: existingRecord.id },
            data: {
                status: enums_1.MemberStatus.ACTIVE,
                currentStageId: firstStage.id,
                stageEnteredAt: new Date(),
                notes: null,
            },
        })
        : await prisma_1.prisma.reintegrationMember.create({
            data: {
                guildId: guild.id,
                userId,
                status: enums_1.MemberStatus.ACTIVE,
                currentStageId: firstStage.id,
            },
        });
    await setMemberRole(guild, userId, firstStage.roleId, true);
    await (0, adminLog_1.logAdminAction)({
        guild,
        actorId,
        action: enums_1.AdminLogAction.MEMBER_INSERTED,
        targetId: userId,
        details: `Etapa inicial: ${firstStage.name}`,
    });
    await notifyMember(guild, userId, `Você foi inserido no processo de reintegração de **${guild.name}**, na etapa **${firstStage.name}**.`);
    return member;
}
async function removeMember(guild, actorId, userId, reason) {
    const member = await getActiveMember(guild.id, userId);
    if (!member)
        throw new ReintegrationError("Este usuário não está em reintegração.");
    await setMemberRole(guild, userId, member.currentStage?.roleId, false);
    await prisma_1.prisma.reintegrationMember.update({
        where: { id: member.id },
        data: { status: enums_1.MemberStatus.REMOVED, notes: reason ?? null },
    });
    await (0, adminLog_1.logAdminAction)({
        guild,
        actorId,
        action: enums_1.AdminLogAction.MEMBER_REMOVED,
        targetId: userId,
        details: reason,
    });
    await notifyMember(guild, userId, `Você foi removido do processo de reintegração de **${guild.name}**.`);
}
async function blacklistMember(guild, actorId, userId, reason) {
    const activeMember = await getActiveMember(guild.id, userId);
    if (activeMember) {
        await setMemberRole(guild, userId, activeMember.currentStage?.roleId, false);
        await prisma_1.prisma.reintegrationMember.update({
            where: { id: activeMember.id },
            data: { status: enums_1.MemberStatus.REMOVED },
        });
    }
    await prisma_1.prisma.blacklist.upsert({
        where: { guildId_userId: { guildId: guild.id, userId } },
        update: { reason, addedBy: actorId },
        create: { guildId: guild.id, userId, reason, addedBy: actorId },
    });
    const blacklistRole = await prisma_1.prisma.systemRole.findUnique({
        where: { guildId_type: { guildId: guild.id, type: "BLACKLIST" } },
    });
    await setMemberRole(guild, userId, blacklistRole?.roleId, true);
    await (0, adminLog_1.logAdminAction)({
        guild,
        actorId,
        action: enums_1.AdminLogAction.MEMBER_BLACKLISTED,
        targetId: userId,
        details: reason,
    });
}
async function unblacklistMember(guild, actorId, userId) {
    const entry = await prisma_1.prisma.blacklist.findUnique({ where: { guildId_userId: { guildId: guild.id, userId } } });
    if (!entry)
        throw new ReintegrationError("Este usuário não está na blacklist.");
    await prisma_1.prisma.blacklist.delete({ where: { id: entry.id } });
    const blacklistRole = await prisma_1.prisma.systemRole.findUnique({
        where: { guildId_type: { guildId: guild.id, type: "BLACKLIST" } },
    });
    await setMemberRole(guild, userId, blacklistRole?.roleId, false);
    await (0, adminLog_1.logAdminAction)({
        guild,
        actorId,
        action: enums_1.AdminLogAction.MEMBER_UNBLACKLISTED,
        targetId: userId,
    });
}
async function progressMember(guild, actorId, userId, direction) {
    const member = await getActiveMember(guild.id, userId);
    if (!member || !member.currentStage) {
        throw new ReintegrationError("Este usuário não está em reintegração.");
    }
    const stages = await getStages(guild.id);
    const index = stages.findIndex((s) => s.id === member.currentStageId);
    const targetIndex = direction === "advance" ? index + 1 : index - 1;
    if (direction === "regress" && targetIndex < 0) {
        throw new ReintegrationError("Este membro já está na primeira etapa.");
    }
    await setMemberRole(guild, userId, member.currentStage.roleId, false);
    if (direction === "advance" && targetIndex >= stages.length) {
        // Concluiu a última etapa
        await prisma_1.prisma.reintegrationMember.update({
            where: { id: member.id },
            data: { status: enums_1.MemberStatus.COMPLETED, currentStageId: null },
        });
        await (0, adminLog_1.logAdminAction)({
            guild,
            actorId,
            action: enums_1.AdminLogAction.MEMBER_COMPLETED,
            targetId: userId,
        });
        await notifyMember(guild, userId, `🎉 Você concluiu o processo de reintegração em **${guild.name}**!`);
        return { completed: true };
    }
    const target = stages[targetIndex];
    await prisma_1.prisma.reintegrationMember.update({
        where: { id: member.id },
        data: { currentStageId: target.id, stageEnteredAt: new Date() },
    });
    await setMemberRole(guild, userId, target.roleId, true);
    await (0, adminLog_1.logAdminAction)({
        guild,
        actorId,
        action: direction === "advance" ? enums_1.AdminLogAction.MEMBER_PROGRESSED : enums_1.AdminLogAction.MEMBER_REGRESSED,
        targetId: userId,
        details: `${member.currentStage.name} -> ${target.name}`,
    });
    await notifyMember(guild, userId, `Sua etapa de reintegração em **${guild.name}** foi atualizada para **${target.name}**.`);
    return { completed: false, stage: target };
}
async function addEvaluation(guild, actorId, userId, approved, notes) {
    const member = await getActiveMember(guild.id, userId);
    if (!member || !member.currentStageId) {
        throw new ReintegrationError("Este usuário não está em reintegração.");
    }
    const evaluation = await prisma_1.prisma.evaluation.create({
        data: {
            guildId: guild.id,
            memberId: member.id,
            stageId: member.currentStageId,
            evaluatorId: actorId,
            approved,
            notes,
        },
    });
    await (0, adminLog_1.logAdminAction)({
        guild,
        actorId,
        action: enums_1.AdminLogAction.EVALUATION_ADDED,
        targetId: userId,
        details: `${approved ? "Aprovado" : "Reprovado"}${notes ? ` — ${notes}` : ""}`,
    });
    return evaluation;
}
// -----------------------------
// Progressão automática
// -----------------------------
/**
 * Verifica todos os membros ativos com progressão automática habilitada
 * na etapa atual e avança quem já cumpriu os dias mínimos. Deve ser
 * chamado periodicamente (ver index.ts).
 */
async function runAutoProgression(client) {
    const candidates = await prisma_1.prisma.reintegrationMember.findMany({
        where: { status: enums_1.MemberStatus.ACTIVE },
        include: { currentStage: true },
    });
    for (const member of candidates) {
        const stage = member.currentStage;
        if (!stage || !stage.autoProgress)
            continue;
        const daysInStage = (Date.now() - new Date(member.stageEnteredAt).getTime()) / 86400000;
        if (daysInStage < stage.minDays)
            continue;
        const guild = client.guilds.cache.get(member.guildId);
        if (!guild)
            continue;
        await progressMember(guild, client.user?.id ?? "SYSTEM", member.userId, "advance").catch((err) => console.error(`[auto-progression] Falha ao avançar ${member.userId}:`, err));
    }
}
//# sourceMappingURL=reintegration.js.map