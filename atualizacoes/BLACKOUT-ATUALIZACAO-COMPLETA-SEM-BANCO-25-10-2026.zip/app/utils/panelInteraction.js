"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.refreshPanel = refreshPanel;
exports.deferPanel = deferPanel;
/** Refresh the originating ephemeral panel, including after a modal submission. */
async function refreshPanel(interaction, payload) {
    if (interaction.deferred || interaction.replied)
        return interaction.editReply(payload);
    if (typeof interaction.isFromMessage === "function" && !interaction.isFromMessage()) {
        const { attachments, ...reply } = payload;
        return interaction.reply({ ...reply, ephemeral: true });
    }
    return interaction.update(payload);
}
async function deferPanel(interaction) {
    if (interaction.deferred || interaction.replied)
        return;
    if (typeof interaction.isFromMessage === "function" && !interaction.isFromMessage()) {
        await interaction.deferReply({ ephemeral: true });
    }
    else
        await interaction.deferUpdate();
}
