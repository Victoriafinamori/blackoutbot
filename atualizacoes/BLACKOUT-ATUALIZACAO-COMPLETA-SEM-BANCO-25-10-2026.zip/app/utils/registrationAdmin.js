"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.registrationIssues = registrationIssues;
exports.registrationInternalEmbed = registrationInternalEmbed;
exports.registrationPublicPreview = registrationPublicPreview;
exports.registrationAdminPayload = registrationAdminPayload;
exports.renderRegistrationAdmin = renderRegistrationAdmin;
const discord_js_1 = require("discord.js");
const prisma_1 = require("../database/prisma");
const registration_1 = require("./registration");
const adminUi_1 = require("./adminUi");
const admEmojis_1 = require("./admEmojis");
const admPanel_1 = require("./admPanel");
const panelInteraction_1 = require("./panelInteraction");
const tickets_1 = require("./tickets");
const button = (id, label, style = discord_js_1.ButtonStyle.Secondary) => new discord_js_1.ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style);
const row = (...buttons) => new discord_js_1.ActionRowBuilder().addComponents(...buttons);
const back = () => row(button('registration-ui:home', 'Voltar · Registro'));
const mentionRoles = (value) => (0, tickets_1.ids)(value).map((id) => `<@&${id}>`).join(', ') || 'Nenhum';
function channel(id, label, type, value) { const s = new discord_js_1.ChannelSelectMenuBuilder().setCustomId(`registration-channel:${id}`).setPlaceholder(label).addChannelTypes(type).setMinValues(0).setMaxValues(1); if (value)
    s.setDefaultChannels(value); return row(s); }
function roles(id, label, value) { const s = new discord_js_1.RoleSelectMenuBuilder().setCustomId(`registration-role:${id}`).setPlaceholder(label).setMinValues(0).setMaxValues(10); if ((0, tickets_1.ids)(value).length)
    s.setDefaultRoles((0, tickets_1.ids)(value)); return row(s); }
function registrationIssues(c, pages) {
    const result = [];
    if (!pages.length)
        result.push({ label: 'Crie a primeira página do formulário.', target: 'pages' });
    for (const p of pages)
        if (!(0, tickets_1.ids)(p.roleIds).length)
            result.push({ label: `Adicione cargos à página “${p.name}”.`, target: 'pages' });
    if (!c.panelChannelId)
        result.push({ label: 'Escolha o canal do painel público.', target: 'publication' });
    if (!c.registrationCategoryId)
        result.push({ label: 'Escolha a categoria dos chats privados.', target: 'team' });
    if (c.welcomeEnabled && (!c.welcomeChannelId || !c.welcomeMessage))
        result.push({ label: 'Complete as boas-vindas após registro.', target: 'welcome' });
    if (c.externalEnabled && (!c.externalGuildId || !c.externalChannelId))
        result.push({ label: 'Complete o destino externo dos logs.', target: 'logs' });
    return result;
}
function registrationInternalEmbed(c) {
    const embed = new discord_js_1.EmbedBuilder().setColor(Number.parseInt(c.internalColor || 'D71935', 16)).setTitle(c.internalTitle || 'Seu registro').setDescription(c.internalDescription || 'Seu atendimento foi iniciado.');
    if (c.internalThumbnail)
        embed.setThumbnail(c.internalThumbnail);
    if (c.internalImage)
        embed.setImage(c.internalImage);
    if (c.internalFooter)
        embed.setFooter({ text: c.internalFooter });
    return embed;
}
async function registrationPublicPreview(guild) {
    // The complete production editor remains authoritative; src's simpler editor is not substituted.
    const editor = require('../../app/utils/registrationPanelEditor');
    const c = await (0, registration_1.regConfig)(guild.id);
    const controls = editor.registrationPanelPayload(c).components;
    for (const row of controls)
        for (const button of row.components)
            button.setDisabled(true);
    return { content: '**Prévia · Painel público do Registro**\nEsta visualização não publica nem inicia um atendimento.', attachments: [], embeds: [editor.registrationPanelEmbed(c)], components: [...controls, row(button('adm-reg-embed:panel', 'Voltar ao editor'))], allowedMentions: { parse: [] } };
}
async function registrationAdminPayload(guild, view = 'home') {
    const c = await (0, registration_1.regConfig)(guild.id);
    const e = (0, adminUi_1.adminEmbed)(guild, 'membros');
    let components = [];
    if (view === 'pages')
        return require('./registrationPageAdmin').registrationPagesPayload(guild);
    if (view === 'welcome')
        return require('../../app/utils/registrationWelcome').registrationWelcomePayload(guild);
    if (view === 'preview-panel')
        return registrationPublicPreview(guild);
    if (view === 'internal' || view === 'preview-internal')
        return { content: '**Mensagem do chat de registro · Prévia**\nSalvar atualiza esta embed. As novas configurações serão usadas nos próximos atendimentos.', attachments: [], embeds: [registrationInternalEmbed(c)], components: [row(button('adm-reg-embed:internal', 'Editar mensagem', discord_js_1.ButtonStyle.Primary), button('registration-ui:messages', 'Voltar · Mensagens'))], allowedMentions: { parse: [] } };
    if (view === 'home' || view === 'pending') {
        const pages = await prisma_1.prisma.registrationPage.findMany({ where: { guildId: guild.id }, orderBy: { order: 'asc' } });
        const issues = registrationIssues(c, pages);
        e.setTitle(view === 'pending' ? 'Pendências do Registro' : 'Registro de membros').setDescription(view === 'pending' ? 'Abra o item que deseja corrigir.' : 'Prepare o formulário, os cargos e as mensagens antes de abrir o atendimento.');
        if (view === 'pending') {
            e.addFields({ name: 'O que falta', value: issues.map(x => x.label).join('\n').slice(0, 1024) || 'Nenhuma pendência de configuração encontrada.' });
            const tasks = [...new Map(issues.map(x => [x.target, x])).values()];
            if (tasks.length)
                components.push(row(new discord_js_1.StringSelectMenuBuilder().setCustomId('registration-admin-nav').setPlaceholder('Escolha o ajuste').addOptions(tasks.map(x => ({ value: x.target, label: x.label.slice(0, 100) })))));
            components.push(back());
        }
        else {
            e.addFields({ name: 'Estado', value: c.enabled ? 'Ativado' : 'Desativado', inline: true }, { name: 'Configuração', value: issues.length ? `${issues.length} pendência(s) para revisar` : 'Configuração básica pronta', inline: true }, { name: 'Formulário', value: `${pages.length}/5 páginas`, inline: true }, { name: 'Painel público', value: c.panelChannelId ? `<#${c.panelChannelId}> · ${c.panelMessageId ? 'Publicação cadastrada' : 'Ainda não publicado'}` : 'Canal não configurado' });
            const icon = (0, admEmojis_1.admEmoji)(guild, 'membros');
            components = [row(new discord_js_1.StringSelectMenuBuilder().setCustomId('registration-admin-nav').setPlaceholder('Escolha o que deseja configurar').addOptions([
                    ['pages', 'Formulário', 'Perguntas, ordem e opções de cargos'], ['auto', 'Cargos após registro', 'Cargos fixos adicionados e removidos'], ['embed', 'Mensagens e publicação', 'Painel, chat privado e boas-vindas'], ['team', 'Atendimento e equipe', 'Categoria dos chats e responsáveis'], ['logs', 'Logs do Registro', 'Envio local e externo deste módulo']
                ].map(([value, label, description]) => ({ value, label, description, ...(icon ? { emoji: icon } : {}) })))), row(button('adm-reg:test', 'Testar registro', discord_js_1.ButtonStyle.Primary), button('registration-ui:tools', 'Comandos e estatísticas')),
                row(...(issues.length ? [button('registration-ui:pending', 'Resolver pendências')] : []), button('registration-ui:toggle', c.enabled ? 'Desativar registro' : 'Ativar registro')), (0, admPanel_1.adminBackRow)('membros')];
        }
    }
    else if (view === 'embed' || view === 'messages') {
        e.setTitle('Mensagens e publicação').setDescription('Escolha a mensagem pelo momento em que ela aparece.').addFields({ name: 'Painel público', value: 'Convite para iniciar o registro.' }, { name: 'Mensagem do chat de registro', value: 'Orientações exibidas no atendimento privado.' }, { name: 'Boas-vindas após registro', value: 'Enviadas depois que o registro é concluído.' });
        components = [row(button('adm-reg-embed:panel', 'Painel público', discord_js_1.ButtonStyle.Primary), button('registration-ui:internal', 'Mensagem do chat'), button('registration-ui:welcome', 'Boas-vindas após registro')), row(button('registration-ui:publication', 'Publicar / atualizar painel')), back()];
    }
    else if (view === 'team') {
        e.setTitle('Atendimento e equipe').setDescription('Escolha onde os chats privados serão criados e quem atende os registros.').addFields({ name: 'Categoria dos chats', value: c.registrationCategoryId ? `<#${c.registrationCategoryId}>` : 'Não configurada' }, { name: 'Registradores', value: mentionRoles(c.registrarRoleIds) + '\nPodem assumir o atendimento. Administradores do Discord também podem atender.' }, { name: 'Liderança', value: mentionRoles(c.leaderRoleIds) + '\nPode consultar o ranking com /registros.' });
        components = [channel('registrationCategoryId', 'Categoria dos chats privados', discord_js_1.ChannelType.GuildCategory, c.registrationCategoryId), roles('registrarRoleIds', 'Cargos registradores', c.registrarRoleIds), roles('leaderRoleIds', 'Cargos de liderança', c.leaderRoleIds), back()];
    }
    else if (view === 'logs' || view === 'general') {
        const mode = c.logChannelId ? (c.externalEnabled ? 'Local e externo' : 'Somente local') : (c.externalEnabled ? 'Somente externo' : 'Sem destino de envio');
        e.setTitle('Logs do Registro').setDescription('Destinos próprios deste módulo. A central de logs do servidor tem configuração independente.').addFields({ name: 'Envio dos registros', value: mode }, { name: 'Neste servidor', value: c.logChannelId ? `<#${c.logChannelId}>` : 'Sem canal local' }, { name: 'Destino externo', value: c.externalEnabled ? `Servidor: ${c.externalGuildId || 'Não configurado'}\nCanal: ${c.externalChannelId ? `<#${c.externalChannelId}>` : 'Não configurado'}` : 'Desativado' });
        components = [channel('logChannelId', 'Canal local · vazio desativa o envio local', discord_js_1.ChannelType.GuildText, c.logChannelId), row(button('registration-ui:external', c.externalEnabled ? 'Desativar envio externo' : 'Ativar envio externo'), button('adm-reg:externalconfig', 'Configurar destino externo')), row(button('adm-logs:menu', 'Central de logs do servidor')), back()];
    }
    else if (view === 'auto' || view === 'roles') {
        e.setTitle('Cargos após registro').setDescription('Cargos fixos aplicados ao concluir. As escolhas do formulário também são adicionadas.').addFields({ name: 'Adicionar ao concluir', value: mentionRoles(c.registeredRoleIds) }, { name: 'Remover ao concluir', value: mentionRoles(c.unregisteredRoleIds) });
        components = [roles('registeredRoleIds', 'Cargos adicionados', c.registeredRoleIds), roles('unregisteredRoleIds', 'Cargos removidos', c.unregisteredRoleIds), back()];
    }
    else if (view === 'publication') {
        e.setTitle('Publicar painel').setDescription('Escolha o canal público. Salvar no editor atualiza a prévia; publicar ou atualizar exige esta ação explícita.').addFields({ name: 'Canal do painel', value: c.panelChannelId ? `<#${c.panelChannelId}>` : 'Não configurado' }, { name: 'Atendimento privado', value: c.registrationCategoryId ? `Categoria: <#${c.registrationCategoryId}>` : 'Defina a categoria em Atendimento e equipe.' });
        components = [channel('panelChannelId', 'Canal do painel público', discord_js_1.ChannelType.GuildText, c.panelChannelId), row(button('adm-reg-embed:send', 'Publicar / atualizar', discord_js_1.ButtonStyle.Primary).setDisabled(!c.panelChannelId || !c.registrationCategoryId), button('registration-ui:team', 'Atendimento e equipe')), back()];
    }
    else if (view === 'tools') {
        const top = await prisma_1.prisma.registrarStat.findMany({ where: { guildId: guild.id }, orderBy: { cycle: 'desc' }, take: 10 });
        e.setTitle('Comandos e estatísticas').setDescription('Consulte os comandos e o desempenho dos registradores.').addFields({ name: 'Comandos', value: '`/registrar @membro` e `/r @membro`: iniciar o formulário no atendimento.\n`/registros`: ranking disponível para a liderança.' }, { name: 'Ranking do ciclo', value: top.map((x, n) => `${n + 1}. <@${x.userId}> — ${x.cycle}`).join('\n') || 'Nenhum registro neste ciclo.' });
        components = [back()];
    }
    else
        throw new Error('Tela do Registro inválida.');
    return { content: null, attachments: [], embeds: [e], components, allowedMentions: { parse: [] } };
}
async function renderRegistrationAdmin(i, view = 'home') { return (0, panelInteraction_1.refreshPanel)(i, await registrationAdminPayload(i.guild, view)); }
