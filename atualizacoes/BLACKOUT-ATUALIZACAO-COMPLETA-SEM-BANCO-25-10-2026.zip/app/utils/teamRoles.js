"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.roleSummary = roleSummary;
exports.selectedRoleIssue = selectedRoleIssue;
function roleSummary(guild, ids, assignable = false) {
    return ids.length ? ids.map(id => {
        const role = guild.roles.cache.get(id);
        if (!role)
            return `Cargo excluído (${id}) · remova ou substitua a associação.`;
        const issue = assignable && (role.managed || !role.editable) ? " · bot sem permissão ou cargo acima do bot; revise Gerenciar Cargos e a hierarquia." : "";
        return `<@&${id}>${issue}`;
    }).join("\n").slice(0, 1024) : "Nenhum cargo definido.";
}
function selectedRoleIssue(guild, ids, assignable = false) {
    for (const id of ids) {
        const role = guild.roles.cache.get(id);
        if (!role)
            return "Um cargo selecionado não existe neste servidor. Escolha novamente.";
        if (id === guild.id)
            return "O cargo @everyone não pode ser usado aqui. Escolha um cargo específico.";
        if (assignable && (role.managed || !role.editable))
            return "O bot não pode atribuir esse cargo. Escolha um cargo comum abaixo do bot e confira Gerenciar Cargos.";
    }
    return null;
}
