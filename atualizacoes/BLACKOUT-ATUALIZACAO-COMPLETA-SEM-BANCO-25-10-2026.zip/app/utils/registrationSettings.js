"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.registrationRoleError = registrationRoleError;
exports.updateRegistrationSelection = updateRegistrationSelection;
const discord_js_1 = require("discord.js");
const prisma_1 = require("../database/prisma");
const registration_1 = require("./registration");
const tickets_1 = require("./tickets");
async function registrationRoleError(guild, values, assignable) {
    if (values.length > 20)
        return 'Selecione até vinte cargos.';
    const me = guild.members.me ?? await guild.members.fetchMe();
    for (const id of values) {
        const r = await guild.roles.fetch(id).catch(() => null);
        if (!r || r.guild.id !== guild.id || id === guild.id)
            return 'Escolha cargos válidos deste servidor.';
        if (assignable && (r.managed || !me.permissions.has(discord_js_1.PermissionFlagsBits.ManageRoles) || r.position >= me.roles.highest.position))
            return `O bot não pode atribuir o cargo ${r.name}. Revise a posição e a permissão Gerenciar cargos.`;
    }
    return null;
}
async function updateRegistrationSelection(i) {
    const [kind, key] = i.customId.split(':');
    const roleKeys = ['registeredRoleIds', 'unregisteredRoleIds', 'registrarRoleIds', 'leaderRoleIds'];
    const channelKeys = ['logChannelId', 'panelChannelId', 'registrationCategoryId', 'welcomeChannelId'];
    if (kind === 'registration-role' && !roleKeys.includes(key) || kind === 'registration-channel' && !channelKeys.includes(key))
        return;
    const c = await (0, registration_1.regConfig)(i.guild.id);
    if (kind === 'registration-role') {
        const assigning = ['registeredRoleIds', 'unregisteredRoleIds'].includes(key), error = await registrationRoleError(i.guild, i.values, assigning);
        if (error)
            return i.reply({ content: error, ephemeral: true });
        if (assigning) {
            const pages = await prisma_1.prisma.registrationPage.findMany({ where: { guildId: i.guild.id } });
            const added = key === 'registeredRoleIds' ? i.values : (0, tickets_1.ids)(c.registeredRoleIds), removed = key === 'unregisteredRoleIds' ? i.values : (0, tickets_1.ids)(c.unregisteredRoleIds);
            if (removed.some((id) => added.includes(id) || pages.some(p => (0, tickets_1.ids)(p.roleIds).includes(id))))
                return i.reply({ content: 'Um cargo não pode ser adicionado pelo formulário e removido na conclusão. Revise as duas configurações.', ephemeral: true });
        }
    }
    else {
        if (i.values.length > 1)
            return;
        if (i.values[0]) {
            const ch = await i.guild.channels.fetch(i.values[0]).catch(() => null), category = key === 'registrationCategoryId';
            if (!ch || ch.guild.id !== i.guild.id || ch.type !== (category ? discord_js_1.ChannelType.GuildCategory : discord_js_1.ChannelType.GuildText))
                return i.reply({ content: 'Escolha um canal válido deste servidor.', ephemeral: true });
            if (!category && !ch.permissionsFor(i.guild.members.me)?.has([discord_js_1.PermissionFlagsBits.ViewChannel, discord_js_1.PermissionFlagsBits.SendMessages, discord_js_1.PermissionFlagsBits.EmbedLinks]))
                return i.reply({ content: 'O bot precisa ver o canal, enviar mensagens e inserir links/embeds nesse destino.', ephemeral: true });
        }
    }
    const data = { [key]: i.values.join(',') || null };
    if (key === 'welcomeChannelId' && !i.values.length)
        data.welcomeEnabled = false;
    await prisma_1.prisma.registrationConfig.update({ where: { guildId: i.guild.id }, data });
    const view = key === 'welcomeChannelId' ? 'welcome' : key === 'logChannelId' ? 'logs' : key === 'panelChannelId' ? 'publication' : ['registeredRoleIds', 'unregisteredRoleIds'].includes(key) ? 'roles' : 'team';
    return require('./registrationAdmin').renderRegistrationAdmin(i, view);
}
