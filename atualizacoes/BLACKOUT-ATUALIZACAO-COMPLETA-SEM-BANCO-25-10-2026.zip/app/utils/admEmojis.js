"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.adminIconFile = exports.adminAsset = exports.ADM_EMOJI_NAMES = void 0;
exports.admEmoji = admEmoji;
exports.adminEmojiImage = adminEmojiImage;
exports.ensureAdmEmojis = ensureAdmEmojis;
const path_1 = __importDefault(require("path"));
/** Application emojis leave the server's existing emoji slots untouched. */
exports.ADM_EMOJI_NAMES = {
    sistema: "blackout_v2_structure", seguranca: "blackout_v2_security",
    membros: "blackout_v2_members", atendimento: "blackout_v2_support",
    servidor: "blackout_v2_community", staff: "blackout_v2_games", entretenimento: "blackout_v2_social",
};
const FILES = {
    sistema: "estrutura", seguranca: "seguranca", membros: "membros", atendimento: "atendimento",
    servidor: "comunidade", staff: "jogos", entretenimento: "social",
};
const adminAsset = (...parts) => path_1.default.resolve(__dirname, "../../assets/blackout-ui", ...parts);
exports.adminAsset = adminAsset;
const adminIconFile = (area) => (0, exports.adminAsset)("icons", `${FILES[area]}.png`);
exports.adminIconFile = adminIconFile;
const legacy = { campeonatos: "staff", tickets: "atendimento", registro: "membros" };
function areaFor(value) {
    return Object.prototype.hasOwnProperty.call(exports.ADM_EMOJI_NAMES, value) ? value : legacy[value];
}
function admEmoji(guild, value) {
    const area = areaFor(value);
    if (!area)
        return undefined;
    const emoji = guild.client.application?.emojis.cache.find(e => e.name === exports.ADM_EMOJI_NAMES[area]);
    return emoji?.id;
}
function adminEmojiImage(guild, area) {
    const emoji = admEmoji(guild, area);
    return emoji ? `https://cdn.discordapp.com/emojis/${emoji}.png?size=128&quality=lossless` : undefined;
}
// One application-wide queue avoids duplicate creations across guilds and /adm requests.
const pending = new WeakMap();
const retryAfter = new WeakMap();
async function ensureAdmEmojis(guild) {
    const application = guild.client.application;
    if (!application?.emojis)
        return;
    const manager = application.emojis;
    if (Object.values(exports.ADM_EMOJI_NAMES).every(name => manager.cache.some(e => e.name === name)))
        return;
    const running = pending.get(application);
    if (running)
        return running;
    if (Date.now() < (retryAfter.get(application) ?? 0))
        return;
    const task = (async () => {
        try {
            await manager.fetch();
            for (const area of Object.keys(exports.ADM_EMOJI_NAMES)) {
                const name = exports.ADM_EMOJI_NAMES[area];
                if (!manager.cache.some(e => e.name === name))
                    await manager.create({ attachment: (0, exports.adminIconFile)(area), name });
            }
        }
        catch {
            console.warn("[blackout-ui] Não foi possível preparar os PNGs dos menus. Nova tentativa em 5 minutos.");
            retryAfter.set(application, Date.now() + 5 * 60 * 1000);
        }
    })();
    pending.set(application, task);
    try {
        await task;
    }
    finally {
        pending.delete(application);
    }
}
