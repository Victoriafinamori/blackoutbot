"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MOD_ACTIONS = void 0;
exports.renderMemberModeration = renderMemberModeration;
exports.renderModerationMember = renderModerationMember;
exports.openModerationReason = openModerationReason;
exports.reviewModeration = reviewModeration;
exports.executeModerationPanel = executeModerationPanel;
const node_crypto_1 = require("node:crypto");
const discord_js_1 = require("discord.js");
const adminUi_1 = require("./adminUi");
const panelInteraction_1 = require("./panelInteraction");
const permissions_1 = require("./permissions");
const guildConfig_1 = require("../database/guildConfig");
const prisma_1 = require("../database/prisma");
const moderation_1 = require("./moderation");
exports.MOD_ACTIONS = { warn: "Advertir", clearwarns: "Limpar advertências", mute: "Silenciar", unmute: "Remover silêncio", kick: "Expulsar", ban: "Banir", unban: "Desbanir" };
const button = (id, label, style = discord_js_1.ButtonStyle.Secondary) => new discord_js_1.ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style);
const row = (...buttons) => new discord_js_1.ActionRowBuilder().addComponents(buttons);
const payload = (embed, components) => ({ content: null, attachments: [], embeds: [embed], components, allowedMentions: { parse: [] } });
async function renderMemberModeration(i) {
    const e = (0, adminUi_1.adminEmbed)(i.guild, "seguranca").setTitle("Moderação de membros").setDescription("Escolha o membro para consultar o histórico e as ações disponíveis. Usuários banidos podem ser localizados pelo ID.");
    const picker = new discord_js_1.UserSelectMenuBuilder().setCustomId("adm-mod-user-select:member").setPlaceholder("Escolha o membro que deseja acompanhar").setMinValues(1).setMaxValues(1);
    return (0, panelInteraction_1.refreshPanel)(i, payload(e, [new discord_js_1.ActionRowBuilder().addComponents(picker), row(button("adm-mod:unban", "Desbanir por ID"), button("adm-notify:moderacao", "Avisos e mensagens")), row(button("adm-nav:seguranca", "Voltar"))]));
}
function historyLines(rows, format) { return rows.length ? rows.map(format).join("\n").slice(0, 1024) : "Nenhum registro."; }
async function renderModerationMember(i, userId, notice) {
    await (0, panelInteraction_1.deferPanel)(i);
    const [member, history, active] = await Promise.all([i.guild.members.fetch({ user: userId, force: true }).catch(() => null), (0, moderation_1.getModerationHistory)(i.guild.id, userId), prisma_1.prisma.warn.count({ where: { guildId: i.guild.id, userId, active: true } })]);
    const e = (0, adminUi_1.adminEmbed)(i.guild, "seguranca").setTitle("Membro · Moderação").setDescription(`<@${userId}> · ID ${userId}${member ? "" : "\nEste usuário não está no servidor ou não pôde ser consultado."}`)
        .addFields({ name: "Situação atual", value: `${active} advertências ativas · ${member?.communicationDisabledUntilTimestamp > Date.now() ? "Silenciado" : "Sem silêncio ativo"}` }, { name: "Advertências recentes", value: historyLines(history.warns, w => `${w.active ? "Ativa" : "Removida"} · ${w.reason}`) }, { name: "Silenciamentos recentes", value: historyLines(history.mutes, m => m.reason || "Sem motivo") }, { name: "Expulsões e banimentos recentes", value: historyLines(history.actions, a => `${a.type} · ${a.reason || "Sem motivo"}`) }, { name: "Palavras monitoradas", value: historyLines(history.wordWatchHits, h => `${h.word} · <#${h.channelId}>`) });
    if (notice)
        e.addFields({ name: "Resultado", value: notice.slice(0, 1024) });
    const actor = await i.guild.members.fetch(i.user.id);
    const above = i.user.id === i.guild.ownerId || !member || actor.roles.highest.comparePositionTo(member.roles.highest) > 0;
    if (member && !above)
        e.addFields({ name: "Ações indisponíveis", value: "O cargo deste membro é igual ou superior ao seu. Peça a um responsável com cargo superior." });
    else if (member && (!member.moderatable || !member.kickable || !member.bannable))
        e.addFields({ name: "Permissões do bot", value: "Algumas ações estão indisponíveis. Confira a hierarquia do bot e as permissões Moderar, Expulsar e Banir Membros." });
    const self = userId === i.user.id || userId === i.guild.client.user?.id || userId === i.guild.ownerId;
    const can = (kind) => !!member && !self && above && (kind === "mute" || kind === "unmute" ? member.moderatable : kind === "kick" ? member.kickable : kind === "ban" ? member.bannable : true);
    return (0, panelInteraction_1.refreshPanel)(i, payload(e, [row(button(`team-mod:action:warn:${userId}`, "Advertir").setDisabled(!can("warn")), button(`team-mod:action:clearwarns:${userId}`, "Limpar advertências").setDisabled(active === 0)),
        row(button(`team-mod:action:mute:${userId}`, "Silenciar").setDisabled(!can("mute")), button(`team-mod:action:unmute:${userId}`, "Remover silêncio").setDisabled(!can("unmute") || !(member?.communicationDisabledUntilTimestamp > Date.now()))),
        row(button(`team-mod:action:kick:${userId}`, "Expulsar", discord_js_1.ButtonStyle.Danger).setDisabled(!can("kick")), button(`team-mod:action:ban:${userId}`, "Banir", discord_js_1.ButtonStyle.Danger).setDisabled(!can("ban"))),
        row(button(`team-mod:member:${userId}`, "Atualizar histórico"), button("adm-mod:menu", "Escolher outro membro"))]));
}
async function openModerationReason(i, action, userId) {
    if (!exports.MOD_ACTIONS[action] || action === "unban")
        return;
    const modal = new discord_js_1.ModalBuilder().setCustomId(`adm-modal:mod:${action}:${userId}`).setTitle(exports.MOD_ACTIONS[action]);
    const input = new discord_js_1.TextInputBuilder().setCustomId("reason").setLabel("Motivo").setStyle(discord_js_1.TextInputStyle.Paragraph).setRequired(true).setMaxLength(300);
    modal.addComponents(new discord_js_1.ActionRowBuilder().addComponents(input));
    if (action === "mute") {
        const c = await (0, guildConfig_1.getOrCreateGuildConfig)(i.guild.id);
        modal.addComponents(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("duration").setLabel("Duração em minutos (1 a 40320)").setStyle(discord_js_1.TextInputStyle.Short).setRequired(true).setValue(String(c.autoMuteDurationMinutes)).setMaxLength(5)));
    }
    return i.showModal(modal);
}
const pending = new Map();
const signature = (c) => JSON.stringify([c.moderationNotifyDm ?? c.notifyDm, c.notifyPublicWarns, c.reportsChannelId, c.maxWarnsBeforeMute, c.maxWarnsBeforeBan, c.autoMuteDurationMinutes]);
async function checkTarget(i, action, userId) {
    if (!/^\d{15,25}$/.test(userId))
        return "ID de usuário inválido.";
    if (action === "unban") {
        const me = i.guild.members.me ?? await i.guild.members.fetchMe();
        if (!me.permissions.has(discord_js_1.PermissionFlagsBits.BanMembers))
            return "O bot precisa da permissão Banir Membros.";
        return await i.guild.bans.fetch(userId).then(() => null, () => "Não foi possível consultar esse banimento. Confira o ID e as permissões do bot.");
    }
    if (action === "clearwarns")
        return null;
    if ([i.user.id, i.guild.ownerId, i.guild.client.user?.id].includes(userId))
        return "Não é possível aplicar essa ação ao responsável pelo servidor, ao próprio bot ou a si mesmo.";
    const member = await i.guild.members.fetch({ user: userId, force: true }).catch(() => null);
    if (!member)
        return "Membro não encontrado neste servidor.";
    const actor = await i.guild.members.fetch(i.user.id);
    if (i.user.id !== i.guild.ownerId && actor.roles.highest.comparePositionTo(member.roles.highest) <= 0)
        return "O cargo desse membro é igual ou superior ao seu. Peça a um responsável com cargo superior.";
    if ((action === "mute" || action === "unmute") && !member.moderatable)
        return "O bot não pode silenciar esse membro. Confira a hierarquia e a permissão Moderar Membros.";
    if (action === "kick" && !member.kickable)
        return "O bot não pode expulsar esse membro. Confira a hierarquia e a permissão Expulsar Membros.";
    if (action === "ban" && !member.bannable)
        return "O bot não pode banir esse membro. Confira a hierarquia e a permissão Banir Membros.";
    return null;
}
async function reviewModeration(i, action, userId, reason, duration) {
    if (!exports.MOD_ACTIONS[action])
        return;
    reason = reason.trim();
    if (!reason && action !== "unban")
        return i.reply({ content: "Informe o motivo da ação.", ephemeral: true });
    if (reason.length > 300)
        return i.reply({ content: "O motivo deve ter até 300 caracteres.", ephemeral: true });
    if (action === "mute" && (!Number.isInteger(duration) || duration < 1 || duration > 40320))
        return i.reply({ content: "Informe uma duração inteira entre 1 e 40320 minutos.", ephemeral: true });
    await (0, panelInteraction_1.deferPanel)(i);
    const issue = await checkTarget(i, action, userId);
    if (issue)
        return i.followUp({ content: issue, ephemeral: true });
    const c = await (0, guildConfig_1.getOrCreateGuildConfig)(i.guild.id), warnCount = await prisma_1.prisma.warn.count({ where: { guildId: i.guild.id, userId, active: true } });
    const e = (0, adminUi_1.adminEmbed)(i.guild, "seguranca").setTitle("Revisar ação de moderação").setDescription("Confira os dados. A ação só será executada ao confirmar.")
        .addFields({ name: "Membro", value: `<@${userId}> · ${userId}` }, { name: "Ação", value: exports.MOD_ACTIONS[action] }, { name: "Motivo", value: reason || "Não informado" });
    if (action === "mute")
        e.addFields({ name: "Duração", value: `${duration} minutos` });
    e.addFields({ name: "Avisos do módulo", value: `DMs: ${(c.moderationNotifyDm ?? c.notifyDm) ? "ativadas (o envio depende do membro)" : "desativadas"}\nAvisos públicos de advertência: ${c.notifyPublicWarns && c.reportsChannelId ? `<#${c.reportsChannelId}>` : "desativados ou sem destino"}` });
    if (action === "warn")
        e.addFields({ name: "Escalonamento automático", value: `${warnCount} advertências ativas; após esta, ${warnCount + 1}.\nSilêncio: ${c.maxWarnsBeforeMute > 0 ? `${c.maxWarnsBeforeMute} advertências · ${c.autoMuteDurationMinutes} min` : "desativado"}. Banimento: ${c.maxWarnsBeforeBan > 0 ? `${c.maxWarnsBeforeBan} advertências` : "desativado"}.` });
    for (const [key, value] of pending)
        if (value.expires < Date.now())
            pending.delete(key);
    if (pending.size >= 1000)
        return i.followUp({ content: "Há muitas revisões abertas. Aguarde alguns minutos e tente novamente.", ephemeral: true });
    const token = (0, node_crypto_1.randomBytes)(16).toString("hex");
    pending.set(token, { guildId: i.guild.id, actorId: i.user.id, messageId: i.message?.id ?? null, action, userId, reason, duration, expires: Date.now() + 10 * 60 * 1000, policy: signature(c), warnCount });
    return (0, panelInteraction_1.refreshPanel)(i, payload(e, [row(button(`team-mod:confirm:${token}`, `Confirmar ${exports.MOD_ACTIONS[action].toLowerCase()}`, discord_js_1.ButtonStyle.Danger), button(`team-mod:cancel:${token}`, "Cancelar"))]));
}
async function executeModerationPanel(i) {
    if (!i.guild || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
        return i.reply({ content: "Você não possui permissão neste servidor.", ephemeral: true });
    const [, action, arg, userId] = i.customId.split(":");
    if (action === "member")
        return renderModerationMember(i, arg);
    if (action === "action")
        return openModerationReason(i, arg, userId);
    if (action !== "confirm" && action !== "cancel")
        return;
    const p = pending.get(arg);
    if (!p || p.expires < Date.now() || p.guildId !== i.guild.id || p.actorId !== i.user.id || (p.messageId && p.messageId !== i.message?.id))
        return i.reply({ content: "Esta revisão expirou, já foi usada ou pertence a outro painel. Abra uma nova revisão.", ephemeral: true });
    pending.delete(arg);
    await (0, panelInteraction_1.deferPanel)(i);
    if (action === "cancel")
        return renderMemberModeration(i);
    const c = await (0, guildConfig_1.getOrCreateGuildConfig)(i.guild.id);
    if (signature(c) !== p.policy || (p.action === "warn" && await prisma_1.prisma.warn.count({ where: { guildId: i.guild.id, userId: p.userId, active: true } }) !== p.warnCount))
        return renderModerationMember(i, p.userId, "As configurações ou advertências mudaram. Revise a ação novamente antes de confirmar.");
    const issue = await checkTarget(i, p.action, p.userId);
    if (issue)
        return renderModerationMember(i, p.userId, issue);
    try {
        if (p.action === "warn")
            await (0, moderation_1.warnMember)(i.guild, i.user.id, p.userId, p.reason);
        if (p.action === "mute")
            await (0, moderation_1.muteMember)(i.guild, i.user.id, p.userId, p.reason, p.duration);
        if (p.action === "kick")
            await (0, moderation_1.kickMember)(i.guild, i.user.id, p.userId, p.reason);
        if (p.action === "ban")
            await (0, moderation_1.banMember)(i.guild, i.user.id, p.userId, p.reason);
        if (p.action === "unban")
            await (0, moderation_1.unbanMember)(i.guild, i.user.id, p.userId, p.reason);
        if (p.action === "unmute")
            await (0, moderation_1.unmuteMember)(i.guild, i.user.id, p.userId, p.reason);
        if (p.action === "clearwarns")
            await (0, moderation_1.clearWarns)(i.guild, i.user.id, p.userId, p.reason);
    }
    catch {
        return renderModerationMember(i, p.userId, "Não foi possível concluir a ação. Confira as permissões e o histórico antes de tentar novamente.");
    }
    return renderModerationMember(i, p.userId, `${exports.MOD_ACTIONS[p.action]}: ação concluída.`);
}
