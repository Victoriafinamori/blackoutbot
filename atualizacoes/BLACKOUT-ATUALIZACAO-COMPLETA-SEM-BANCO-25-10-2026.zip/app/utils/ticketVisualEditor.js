"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ticketVisualDrafts = void 0;
exports.ticketInternalPreview = ticketInternalPreview;
exports.ticketVisualEditor = ticketVisualEditor;
const discord_js_1 = require("discord.js");
const tickets_1 = require("./tickets");
exports.ticketVisualDrafts = new Map();
const style = (value) => ({ PRIMARY: discord_js_1.ButtonStyle.Primary, SECONDARY: discord_js_1.ButtonStyle.Secondary, SUCCESS: discord_js_1.ButtonStyle.Success, DANGER: discord_js_1.ButtonStyle.Danger }[value] || discord_js_1.ButtonStyle.Primary);
function ticketInternalPreview(c) {
    const embed = new discord_js_1.EmbedBuilder().setColor(Number.parseInt(c.internalColor, 16) || 0xd20b20).setTitle("Ticket - usuário")
        .addFields({ name: "Assumido por", value: "Ninguém" }, { name: c.internalTitle || "TICKET ABERTO", value: c.internalDescription || "Seu atendimento foi iniciado." });
    if (c.internalThumbnail)
        embed.setThumbnail(c.internalThumbnail);
    if (c.internalImage)
        embed.setImage(c.internalImage);
    if (c.internalFooter)
        embed.setFooter({ text: c.internalFooter });
    return embed;
}
async function ticketVisualEditor(guild, prefix) {
    const c = await (0, tickets_1.ticketConfig)(guild.id);
    const preview = prefix === "panel" ? (0, tickets_1.ticketPanel)(c).embeds[0] : ticketInternalPreview(c);
    const addOptions = [
        { label: "Texto / Seção", value: "text", description: "Título e conteúdo principal" },
        { label: "Thumbnail", value: "thumbnail", description: "Upload de imagem pequena" },
        { label: "Imagem / Banner", value: "image", description: "Banner recomendado: 1200 × 400" },
        { label: "Rodapé", value: "footer", description: "Texto no final da embed" },
    ];
    if (prefix === "panel")
        addOptions.push({ label: "Botão principal", value: "button", description: "Nome, emoji e cor do botão" });
    addOptions.push({ label: "Resetar aparência", value: "reset", description: "Restaurar esta embed" });
    const editOptions = [
        { label: "Texto / Seção", value: "text", description: "Editar título e conteúdo" },
        { label: "Thumbnail", value: "thumbnail", description: c[`${prefix}Thumbnail`] ? "Substituir imagem" : "Ainda não configurada" },
        { label: "Remover thumbnail", value: "remove-thumbnail", description: "Excluir a thumbnail atual" },
        { label: "Imagem / Banner", value: "image", description: c[`${prefix}Image`] ? "Substituir imagem" : "Ainda não configurada" },
        { label: "Remover imagem", value: "remove-image", description: "Excluir o banner atual" },
        { label: "Rodapé", value: "footer", description: c[`${prefix}Footer`] ? "Editar ou remover" : "Ainda não configurado" },
    ];
    if (prefix === "panel")
        editOptions.push({ label: "Botão principal", value: "button", description: `${c.panelButtonLabel} • ${c.panelButtonStyle}` });
    return { content: "**Tickets · Mensagens e publicação**\nSalvar atualiza a prévia. Publique o painel quando terminar a edição.", attachments: [], allowedMentions: { parse: [] }, embeds: [preview], components: [
            new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.StringSelectMenuBuilder().setCustomId(`ticket-visual-editor:add:${prefix}`).setPlaceholder("Adicionar item").addOptions(addOptions)),
            new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.StringSelectMenuBuilder().setCustomId(`ticket-visual-editor:edit:${prefix}`).setPlaceholder("Editar ou remover item").addOptions(editOptions)),
            new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId(`ticket-visual-editor:color:${prefix}`).setLabel("Cor").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId(`ticket-visual-editor:save:${prefix}`).setLabel("Salvar modelo").setStyle(discord_js_1.ButtonStyle.Success), new discord_js_1.ButtonBuilder().setCustomId(`ticket-visual-editor:preview:${prefix}`).setLabel("Ver prévia").setStyle(discord_js_1.ButtonStyle.Secondary), ...(prefix === "panel" ? [new discord_js_1.ButtonBuilder().setCustomId("adm-ticket:publish").setLabel("Publicar / atualizar").setStyle(discord_js_1.ButtonStyle.Primary)] : []), new discord_js_1.ButtonBuilder().setCustomId("adm-ticket:manager").setLabel("Voltar").setStyle(discord_js_1.ButtonStyle.Secondary)),
        ] };
}
//# sourceMappingURL=ticketVisualEditor.js.map