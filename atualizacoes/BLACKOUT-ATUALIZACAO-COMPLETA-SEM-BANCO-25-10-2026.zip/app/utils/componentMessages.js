"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.asComponentsV2 = asComponentsV2;
exports.compatibleInteraction = compatibleInteraction;
const D = __importStar(require("discord.js"));
/** Components V2 flags cannot be removed. Convert legacy navigation only on that message. */
function asComponentsV2(payload) {
    if (!payload || typeof payload !== "object")
        return payload;
    if (Number(payload.flags) & D.MessageFlags.IsComponentsV2)
        return payload;
    const components = [];
    if (payload.content)
        components.push({ type: 10, content: String(payload.content) });
    for (const item of payload.embeds || []) {
        const e = item.toJSON ? item.toJSON() : item, blocks = [];
        const lines = [
            e.author?.name ? "-# " + e.author.name : null,
            e.title ? "## " + e.title : null,
            e.description,
        ]
            .filter(Boolean)
            .join("\n");
        if (e.thumbnail?.url && lines)
            blocks.push({
                type: 9,
                components: [{ type: 10, content: lines }],
                accessory: { type: 11, media: { url: e.thumbnail.url } },
            });
        else if (lines)
            blocks.push({ type: 10, content: lines });
        for (const f of e.fields || [])
            blocks.push({ type: 10, content: "**" + f.name + "**\n" + f.value });
        if (e.image?.url)
            blocks.push({ type: 12, items: [{ media: { url: e.image.url } }] });
        if (e.footer?.text)
            blocks.push({ type: 10, content: "-# " + e.footer.text });
        if (blocks.length)
            components.push({
                type: 17,
                accent_color: e.color ?? 0xd71935,
                components: blocks,
            });
    }
    components.push(...(payload.components || []).map((c) => (c.toJSON ? c.toJSON() : c)));
    return {
        ...payload,
        content: null,
        embeds: [],
        flags: (Number(payload.flags) || 0) | D.MessageFlags.IsComponentsV2,
        components,
        allowedMentions: payload.allowedMentions || { parse: [] },
    };
}
function compatibleInteraction(interaction) {
    if (!interaction.message?.flags?.has(D.MessageFlags.IsComponentsV2))
        return interaction;
    let source = true;
    return new Proxy(interaction, {
        get(target, prop) {
            if (["reply", "deferReply"].includes(String(prop)))
                return (...args) => {
                    source = false;
                    return target[prop](...args);
                };
            if (prop === "deferUpdate")
                return (...args) => {
                    source = true;
                    return target.deferUpdate(...args);
                };
            if (prop === "update")
                return (p) => {
                    source = true;
                    return target.update(asComponentsV2(p));
                };
            if (prop === "editReply")
                return (p) => target.editReply(source ? asComponentsV2(p) : p);
            const value = Reflect.get(target, prop, target);
            return typeof value === "function" ? value.bind(target) : value;
        },
    });
}
