"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.registrationPagesPayload = registrationPagesPayload;
exports.registrationPageManagerPayload = registrationPageManagerPayload;
exports.deleteRegistrationPage = deleteRegistrationPage;
const discord_js_1 = require("discord.js");
const prisma_1 = require("../database/prisma");
const adminUi_1 = require("./adminUi");
const button = (id, label, style = discord_js_1.ButtonStyle.Secondary) => new discord_js_1.ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style);
async function registrationPagesPayload(guild) {
    const pages = await prisma_1.prisma.registrationPage.findMany({
        where: { guildId: guild.id },
        orderBy: { order: "asc" },
    });
    const embed = ((0, adminUi_1.adminEmbed)(guild, "membros"))
        .setTitle("Formulário do Registro")
        .setDescription(pages
        .map((p) => `**${p.order}. ${p.name}**\n${p.question}\n${p.roleIds
        .split(",")
        .filter(Boolean)
        .map((id) => `<@&${id}>`)
        .join(" • ") || "Sem cargos"}`)
        .join("\n\n") || "Nenhuma página configurada.");
    const components = [];
    if (pages.length) {
        const select = new discord_js_1.StringSelectMenuBuilder()
            .setCustomId("registration-manage-page")
            .setPlaceholder("Selecione uma página para gerenciar")
            .addOptions(pages.map((p) => ({
            label: `${p.order}. ${p.name}`.slice(0, 100),
            description: `Pergunta, ordem, obrigatoriedade e cargos`.slice(0, 100),
            value: p.id,
        })));
        components.push(new discord_js_1.ActionRowBuilder().addComponents(select));
    }
    components.push(new discord_js_1.ActionRowBuilder().addComponents(button("adm-reg:createpage", "Nova página", discord_js_1.ButtonStyle.Primary).setDisabled(pages.length >= 5), button("adm-reg:menu", "Voltar")));
    return { content: null, attachments: [], embeds: [embed], components, allowedMentions: { parse: [] } };
}
async function registrationPageManagerPayload(guild, pageId) {
    const page = await prisma_1.prisma.registrationPage.findFirst({
        where: { id: pageId, guildId: guild.id },
    });
    if (!page)
        return registrationPagesPayload(guild);
    const roleIds = page.roleIds.split(",").filter(Boolean);
    const roleLines = roleIds.length
        ? roleIds.map((id) => `<@&${id}>`).join(" • ")
        : "Nenhum cargo configurado.";
    const embed = ((0, adminUi_1.adminEmbed)(guild, "membros"))
        .setTitle(`Gerenciar Página ${page.order} — ${page.name}`)
        .setDescription(`**Pergunta**\n${page.question}\n\n` +
        `**Descrição**\n${page.description || "Sem descrição"}\n\n` +
        `**Resposta:** ${page.required ? "Obrigatória" : "Opcional"}\n\n` +
        `**Cargos desta página**\n${roleLines}\n\n` +
        `**Máximo de escolhas:** ${page.maxChoices}\n\n` +
        `Use os controles abaixo para adicionar/remover cargos ou excluir somente esta página.`);
    const addRoles = new discord_js_1.RoleSelectMenuBuilder()
        .setCustomId(`registration-page-addroles:${page.id}`)
        .setPlaceholder("Adicionar cargo(s) nesta página")
        .setMinValues(1)
        .setMaxValues(20);
    const components = [
        new discord_js_1.ActionRowBuilder().addComponents(addRoles),
    ];
    if (roleIds.length) {
        const removeRoles = new discord_js_1.StringSelectMenuBuilder()
            .setCustomId(`registration-page-removeroles:${page.id}`)
            .setPlaceholder("Remover cargo(s) desta página")
            .setMinValues(1)
            .setMaxValues(Math.min(20, roleIds.length))
            .addOptions(roleIds.slice(0, 20).map((id) => ({
            label: (guild.roles.cache.get(id)?.name || id).slice(0, 100),
            value: id,
            description: "Remover desta página",
        })));
        components.push(new discord_js_1.ActionRowBuilder().addComponents(removeRoles));
    }
    components.push(new discord_js_1.ActionRowBuilder().addComponents(button(`registration-ui:page-edit:${page.id}`, "Editar pergunta", discord_js_1.ButtonStyle.Primary), button(`registration-ui:page-up:${page.id}`, "Mover para cima").setDisabled(page.order <= 1), button(`registration-ui:page-down:${page.id}`, "Mover para baixo").setDisabled(page.order >= await prisma_1.prisma.registrationPage.count({ where: { guildId: guild.id } })), button(`adm-reg:pagedelete:${page.id}`, "Excluir página", discord_js_1.ButtonStyle.Danger), button("adm-reg:pages", "Voltar", discord_js_1.ButtonStyle.Secondary)));
    return { content: null, attachments: [], embeds: [embed], components, allowedMentions: { parse: [] } };
}
async function deleteRegistrationPage(guildId, pageId) {
    const page = await prisma_1.prisma.registrationPage.findFirst({ where: { id: pageId, guildId } });
    if (!page)
        return false;
    await prisma_1.prisma.$transaction(async (tx) => {
        await tx.registrationPage.delete({ where: { id: page.id } });
        const following = await tx.registrationPage.findMany({
            where: { guildId, order: { gt: page.order } },
            orderBy: { order: "asc" },
        });
        for (const current of following) {
            await tx.registrationPage.update({
                where: { id: current.id },
                data: { order: current.order - 1 },
            });
        }
    });
    return true;
}
