"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.publicationHash = publicationHash;
exports.publicationState = publicationState;
exports.hasMessageContent = hasMessageContent;
const crypto_1 = require("crypto");
function publicationHash(record) {
    const content = { guildId: record.guildId, destination: record.destinationChannelId ?? null,
        title: record.title ?? null, description: record.description ?? null, author: record.author ?? null,
        footer: record.footer ?? null, color: String(record.color || "2B6CB0").replace(/^#/, "").toUpperCase(),
        image: record.imageUrl ?? null, thumbnail: record.thumbnailUrl ?? null, timestamp: !!record.showTimestamp,
        buttons: (record.buttons ?? []).map((b) => ({ type: b.type, label: b.label, emoji: b.emoji ?? null, url: b.url ?? null, channelId: b.channelId ?? null })),
    };
    return (0, crypto_1.createHash)("sha256").update(JSON.stringify(content)).digest("hex");
}
function publicationState(record) {
    if (!record.publishedMessageId)
        return "Rascunho salvo";
    if (!record.publishedPayloadHash)
        return "Publicação anterior · conteúdo a conferir";
    return record.publishedPayloadHash === publicationHash(record) ? "Publicado · sem alterações pendentes" : "Alterações salvas · ainda não publicadas";
}
function hasMessageContent(record) {
    return !!(record.title?.trim() || record.description?.trim() || record.imageUrl || record.thumbnailUrl);
}
