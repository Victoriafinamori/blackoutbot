"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.writableChannel = writableChannel;
exports.autoRoleIssues = autoRoleIssues;
const discord_js_1 = require("discord.js");
async function writableChannel(guild, id, embed = true) {
    const channel = await guild.channels.fetch(id).catch(() => null);
    if (!channel || channel.guildId !== guild.id || !(channel.type === discord_js_1.ChannelType.GuildText || channel.type === discord_js_1.ChannelType.GuildAnnouncement)) {
        return { channel: null, issue: "Escolha um canal de texto deste servidor." };
    }
    const me = guild.members.me ?? await guild.members.fetchMe();
    const permissions = channel.permissionsFor(me);
    const required = [discord_js_1.PermissionFlagsBits.ViewChannel, discord_js_1.PermissionFlagsBits.SendMessages, ...(embed ? [discord_js_1.PermissionFlagsBits.EmbedLinks] : [])];
    if (!permissions?.has(required))
        return { channel: null, issue: "O bot precisa ver o canal e ter permissão para enviar mensagens" + (embed ? " e embeds." : ".") };
    return { channel, issue: null };
}
function autoRoleIssues(guild, ids) {
    return ids.flatMap(id => {
        const role = guild.roles.cache.get(id);
        if (!role)
            return ["Um cargo selecionado não existe mais."];
        if (role.id === guild.id || role.managed)
            return [`${role.name}: esse cargo não pode ser atribuído automaticamente.`];
        if (!role.editable)
            return [`${role.name}: verifique a hierarquia e a permissão Gerenciar Cargos do bot.`];
        return [];
    });
}
