"use strict";
const {
  ContainerBuilder,
  TextDisplayBuilder,
  MediaGalleryBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags,
} = require("discord.js");
function safe(value) {
  return String(value || "")
    .replace(/[\r\n]+/g, " ")
    .replace(/[*_~`>#]/g, "")
    .slice(0, 100);
}
function publicationControls(c, p) {
  const button = (id, emoji, label, disabled) => {
    const b = new ButtonBuilder()
      .setCustomId(id)
      .setLabel(label)
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(Boolean(disabled));
    if (emoji) b.setEmoji(emoji);
    return b;
  };
  return new ActionRowBuilder().addComponents(
    button(
      `social-like:${p.id}`,
      c.likeEmoji,
      String(p.likesCount || 0),
      !c.likesEnabled,
    ),
    button(
      `social-comments:${p.id}:0`,
      c.commentEmoji,
      String(p.commentsCount || 0),
      !c.commentsEnabled || !p.commentsEnabled,
    ),
    button(
      `social-dm:${p.id}`,
      c.dmEmoji,
      "DM",
      !c.dmsEnabled || !p.dmsEnabled,
    ),
    button(`social-more:${p.id}`, null, "Opções", false),
  );
}
/** Images, GIFs and playable videos share one native card; no detached video link. */
function publicationPayload(c, p, author, { mediaUrl, rank = 0 } = {}) {
  const url = mediaUrl || p.mediaUrl;
  if (!url && ["IMAGE", "GIF", "VIDEO"].includes(p.mediaType))
    throw new Error("A publicação não possui mídia disponível.");
  const name = safe(author?.displayName || author?.user?.username || "Membro");
  const header = `### ${name}${rank ? ` · #${rank} nos destaques` : ""}`;
  const caption = String(p.content || "").slice(0, 2000);
  const card = new ContainerBuilder()
    .setAccentColor(
      Number.parseInt(String(c.color || "D71935").replace("#", ""), 16) ||
        0xd71935,
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        [header, caption].filter(Boolean).join("\n\n"),
      ),
    );
  if (url)
    card.addMediaGalleryComponents(
      new MediaGalleryBuilder().addItems({
        media: { url },
        description:
          p.mediaType === "VIDEO"
            ? "Vídeo da publicação"
            : p.mediaType === "GIF"
              ? "GIF da publicação"
              : "Imagem da publicação",
      }),
    );
  card
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `**${p.likesCount || 0} curtidas · ${p.commentsCount || 0} comentários**\n-# ${safe(c.footer) || "Comunidade"} · ${safe(p.publicId)}`,
      ),
    )
    .addActionRowComponents(publicationControls(c, p));
  return {
    flags: MessageFlags.IsComponentsV2,
    components: [card],
    allowedMentions: { parse: [] },
  };
}
function retainedAttachments(message) {
  return [...(message.attachments?.values() || [])].map((a) => ({ id: a.id }));
}
function ownedMedia(message, p) {
  const attachment = [...(message.attachments?.values() || [])].find((a) =>
    /\.(png|jpe?g|webp|gif|avif|mp4|mov|webm|m4v)$/i.test(a.name || ""),
  );
  return attachment ? `attachment://${attachment.name}` : p.mediaUrl;
}
async function downloadMedia(url, limit = 25 * 1024 * 1024) {
  const parsed = new URL(url);
  if (
    parsed.protocol !== "https:" ||
    !["cdn.discordapp.com", "media.discordapp.net"].includes(parsed.hostname)
  )
    throw new Error("Envie um arquivo pelo upload do Discord.");
  const response = await fetch(url, {
    signal: AbortSignal.timeout(20000),
    redirect: "error",
  });
  if (!response.ok)
    throw new Error(
      `Não foi possível baixar a mídia (HTTP ${response.status}).`,
    );
  if (Number(response.headers?.get("content-length") || 0) > limit)
    throw new Error("A mídia excede o limite de envio.");
  if (!response.body?.getReader) {
    const buffer = Buffer.from(await response.arrayBuffer());
    if (buffer.length > limit)
      throw new Error("A mídia excede o limite de envio.");
    return buffer;
  }
  const reader = response.body.getReader(),
    chunks = [];
  let size = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > limit) {
        await reader.cancel();
        throw new Error("A mídia excede o limite de envio.");
      }
      chunks.push(Buffer.from(value));
    }
  } finally {
    reader.releaseLock();
  }
  return Buffer.concat(chunks);
}
const legacyCache = new Map();
/** Refresh expiring CDN URLs only from a matching attachment in this guild's recent history. */
async function legacyMediaUrl(guild, p) {
  if (!p.mediaUrl) return p.mediaUrl;
  let parsed;
  try {
    parsed = new URL(p.mediaUrl);
  } catch {
    return p.mediaUrl;
  }
  if (!["cdn.discordapp.com", "media.discordapp.net"].includes(parsed.hostname))
    return p.mediaUrl;
  const parts = parsed.pathname.split("/").filter(Boolean);
  if (
    parts[0] !== "attachments" ||
    !/^\d+$/.test(parts[1] || "") ||
    !/^\d+$/.test(parts[2] || "")
  )
    return p.mediaUrl;
  const key = guild.id + ":" + parts[1] + ":" + parts[2],
    cached = legacyCache.get(key);
  if (cached && cached.expires > Date.now()) return cached.url;
  const ch = await guild.channels.fetch(parts[1]).catch(() => null);
  if (!ch || ch.guildId !== guild.id || !ch.isTextBased() || ch.isDMBased())
    return p.mediaUrl;
  const recent = await ch.messages.fetch({ limit: 100 }).catch(() => null);
  let url = p.mediaUrl;
  if (recent?.values)
    for (const m of recent.values()) {
      const file = m.attachments?.get(parts[2]);
      if (file) {
        url = file.url;
        break;
      }
    }
  for (const [k, v] of legacyCache)
    if (v.expires < Date.now()) legacyCache.delete(k);
  if (legacyCache.size < 1000)
    legacyCache.set(key, { url, expires: Date.now() + 120000 });
  return url;
}
module.exports = {
  legacyMediaUrl,
  publicationPayload,
  publicationControls,
  retainedAttachments,
  ownedMedia,
  downloadMedia,
};
