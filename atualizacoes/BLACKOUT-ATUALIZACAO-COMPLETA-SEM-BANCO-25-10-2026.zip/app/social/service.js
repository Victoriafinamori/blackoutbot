"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.socialConfig = socialConfig;
exports.activeRanking = activeRanking;
exports.publicationView = publicationView;
exports.refreshPublication = refreshPublication;
exports.createSocialPublication = createSocialPublication;
exports.toggleLike = toggleLike;
exports.addComment = addComment;
exports.commentsView = commentsView;
exports.likesView = likesView;
exports.sendSocialDm = sendSocialDm;
exports.syncHighlightRole = syncHighlightRole;
exports.refreshHighlights = refreshHighlights;
exports.runSocialScheduler = runSocialScheduler;
const discord_js_1 = require("discord.js");
const prisma_1 = require("../database/prisma");
const filters_1 = require("../utils/filters");
async function socialConfig(guildId) {
  return prisma_1.prisma.socialConfig.upsert({
    where: { guildId },
    update: {},
    create: { guildId },
  });
}
const color = (v) => Number.parseInt(v.replace("#", ""), 16) || 0xd20b20;
const ids = (value) => {
  try {
    return JSON.parse(value || "[]");
  } catch {
    return [];
  }
};
const link = (g) =>
  g.messageId
    ? `https://discord.com/channels/${g.guildId}/${g.channelId}/${g.messageId}`
    : null;
const mediaKind = (attachment) => {
  const type = (attachment.contentType || "").toLowerCase(),
    name = (attachment.name || attachment.url).split("?")[0].toLowerCase();
  if (type.startsWith("video/") || /\.(mp4|mov|webm|m4v)$/.test(name))
    return "VIDEO";
  if (type.includes("gif") || name.endsWith(".gif")) return "GIF";
  if (type.startsWith("image/") || /\.(png|jpe?g|webp|avif)$/.test(name))
    return "IMAGE";
  return "UNSUPPORTED";
};
const mediaFileName = (attachment, publicId) => {
  const extension = (attachment.name || attachment.url)
    .split("?")[0]
    .match(/\.([a-zA-Z0-9]{2,5})$/)?.[1]
    ?.toLowerCase();
  return `social-${publicId}.${extension || "bin"}`;
};
async function activeRanking(guildId, c) {
  const config = c || (await socialConfig(guildId));
  return prisma_1.prisma.socialPublication.findMany({
    where: {
      guildId,
      status: "ACTIVE",
      highlightSuppressed: false,
      createdAt: { gte: config.periodStartedAt },
    },
    orderBy: [{ likesCount: "desc" }, { createdAt: "asc" }],
    take: config.highlightLimit,
  });
}
async function publicationView(guild, p, displayMediaUrl) {
  if (p.guildId !== guild.id) throw Error("Publicação de outro servidor.");
  const c = await socialConfig(guild.id),
    ranking = await activeRanking(guild.id, c),
    author = await guild.members.fetch(p.authorId).catch(() => null);
  return require("./media").publicationPayload(c, p, author, {
    mediaUrl: displayMediaUrl || p.mediaUrl,
    rank: ranking.findIndex((x) => x.id === p.id) + 1,
  });
}
async function refreshPublication(guild, id) {
  const p = await prisma_1.prisma.socialPublication.findUnique({
    where: { id },
  });
  if (!p || p.guildId !== guild.id || !p.messageId || p.status !== "ACTIVE")
    return;
  const ch = await guild.channels.fetch(p.channelId).catch(() => null);
  if (!ch?.isTextBased() || ch.isDMBased()) return;
  const m = await ch.messages.fetch(p.messageId).catch(() => null);
  if (!m) return;
  const media = require("./media");
  let mediaUrl = m.attachments?.size
    ? media.ownedMedia(m, p)
    : await media.legacyMediaUrl(guild, p);
  if (!mediaUrl) return;
  const payload = await publicationView(guild, p, mediaUrl);
  // Legacy embeds must be explicitly cleared when upgrading to Components V2.
  // Existing attachments are retained; a reaction never uploads the media again.
  await m.edit({
    ...payload,
    content: null,
    embeds: [],
    attachments: media.retainedAttachments(m),
  });
}

async function createSocialPublication(message) {
  if (!message.guild) return false;
  return require("../social-experience/common").locked(
    "insta:" + message.guild.id + ":" + message.author.id,
    () => createSocialPublicationInternal(message),
  );
}
async function createSocialPublicationInternal(message) {
  if (!message.guild || message.author.bot || message.channel.isDMBased())
    return false;
  const c = await socialConfig(message.guild.id);
  if (!c.enabled) return false;
  const origin = c.instaChannelId
    ? message.channelId === c.instaChannelId
      ? "INSTA"
      : null
    : message.channelId === c.photosChannelId
      ? "FOTOS"
      : message.channelId === c.feedChannelId
        ? "FEED"
        : null;
  if (!origin) return false;
  if (
    await prisma_1.prisma.socialPublication.findFirst({
      where: { guildId: message.guild.id, sourceMessageId: message.id },
    })
  )
    return true;
  if (ids(c.ignoredRoleIds).some((id) => message.member?.roles.cache.has(id)))
    return false;
  const allowed = ids(c.allowedRoleIds);
  if (
    allowed.length &&
    !allowed.some((id) => message.member?.roles.cache.has(id))
  )
    return false;
  if ((await (0, filters_1.checkMessage)(message)).violated) return false;
  if (message.attachments.size > 1) {
    await message
      .reply("Envie uma mídia por publicação. Nenhum arquivo foi removido.")
      .catch(() => null);
    return true;
  }
  const attachment = message.attachments.first();
  if (origin === "FOTOS" && !attachment) return false;
  if (!message.content.trim() && !attachment) return false;
  if (attachment?.size > 25 * 1024 * 1024) {
    await message
      .reply("Envie uma mídia de até 25 MB. O arquivo original foi preservado.")
      .catch(() => null);
    return true;
  }
  const kind = attachment ? mediaKind(attachment) : null;
  if (!attachment) return false;
  if (message.content.length > c.maxCaptionLength) {
    await message
      .reply(`A legenda pode ter no máximo ${c.maxCaptionLength} caracteres.`)
      .catch(() => null);
    return true;
  }
  if (
    (kind === "IMAGE" && !c.allowImages) ||
    (kind === "GIF" && !c.allowGifs) ||
    (kind === "VIDEO" && !c.allowVideos)
  ) {
    await message
      .reply("Este tipo de mídia está desativado no INSTA.")
      .catch(() => null);
    return true;
  }
  if (kind === "UNSUPPORTED") {
    await message
      .reply(
        "Envie uma imagem, GIF ou vídeo nos formatos PNG, JPG, WEBP, GIF, MP4, MOV ou WEBM.",
      )
      .catch(() => null);
    return true;
  }
  const last = await prisma_1.prisma.socialPublication.findFirst({
    where: {
      guildId: message.guild.id,
      authorId: message.author.id,
      status: "ACTIVE",
    },
    orderBy: { createdAt: "desc" },
    select: { createdAt: true },
  });
  if (
    last &&
    Date.now() - last.createdAt.getTime() < c.postCooldownSeconds * 1000
  ) {
    await message
      .reply("Aguarde antes de criar outra publicação.")
      .catch(() => null);
    return true;
  }
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  if (
    (await prisma_1.prisma.socialPublication.count({
      where: {
        guildId: message.guild.id,
        authorId: message.author.id,
        status: "ACTIVE",
        createdAt: { gte: today },
      },
    })) >= c.maxPostsPerDay
  ) {
    await message
      .reply("Você atingiu o limite diário de publicações.")
      .catch(() => null);
    return true;
  }
  const me = message.guild.members.me,
    permissions = message.channel.permissionsFor(me);
  const required = [
    discord_js_1.PermissionFlagsBits.ViewChannel,
    discord_js_1.PermissionFlagsBits.SendMessages,
    discord_js_1.PermissionFlagsBits.EmbedLinks,
    discord_js_1.PermissionFlagsBits.ReadMessageHistory,
    discord_js_1.PermissionFlagsBits.AttachFiles,
  ];
  if (!permissions?.has(required)) {
    await message
      .reply(
        "Não consigo criar publicações neste canal. Verifique minhas permissões de Ver Canal, Enviar Mensagens, Histórico e Inserir Links.",
      )
      .catch(() => null);
    return true;
  }
  const p = await prisma_1.prisma.socialPublication.create({
    data: {
      publicId: `P${message.id.slice(-10)}`,
      guildId: message.guild.id,
      configId: c.id,
      channelId: message.channelId,
      sourceMessageId: message.id,
      authorId: message.author.id,
      origin,
      content: message.content.trim() || null,
      mediaUrl: attachment?.url || null,
      mediaType: kind,
      status: "PROCESSING",
      commentsEnabled: c.commentsEnabled,
      dmsEnabled: c.dmsEnabled,
    },
  });
  let posted;
  try {
    const fileName = mediaFileName(attachment, p.publicId);
    const fileBuffer = await require("./media").downloadMedia(
      attachment.url,
      25 * 1024 * 1024,
    );
    const view = await publicationView(
      message.guild,
      p,
      "attachment://" + fileName,
    );
    posted = await message.channel.send({
      ...view,
      files: [{ attachment: fileBuffer, name: fileName }],
    });
    const hosted = posted.attachments.first()?.url;
    if (!hosted)
      throw new Error(
        "O Discord não confirmou o arquivo anexado à publicação.",
      );
    await prisma_1.prisma.socialPublication.update({
      where: { id: p.id },
      data: { messageId: posted.id, mediaUrl: hosted, status: "ACTIVE" },
    });
    // The source is removed only after Discord and the record confirm the copied media.
    if (c.deleteOriginal) await message.delete().catch(() => null);
    await refreshHighlights(message.guild).catch((error) =>
      console.warn("[social-highlights]", error.message),
    );
    return true;
  } catch (error) {
    if (posted) await posted.delete().catch(() => null);
    await prisma_1.prisma.socialPublication.update({
      where: { id: p.id },
      data: { status: "FAILED" },
    });
    await message
      .reply(
        "Não consegui anexar a mídia ao cartão. O arquivo original foi preservado. Confira o tamanho, o formato e as permissões de anexar arquivos.",
      )
      .catch(() => null);
    throw error;
  }
}
async function toggleLike(guild, id, userId) {
  const c = await socialConfig(guild.id);
  if (!c.enabled || !c.likesEnabled) throw new Error("Curtidas desativadas.");
  let added;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      added = await prisma_1.prisma.$transaction(async (tx) => {
        const p = await tx.socialPublication.findUnique({ where: { id } });
        if (!p || p.guildId !== guild.id || p.status !== "ACTIVE")
          throw new Error("Publicação indisponível.");
        if (!c.allowSelfLike && p.authorId === userId)
          throw new Error("Você não pode curtir sua própria publicação.");
        const found = await tx.socialLike.findUnique({
          where: { publicationId_userId: { publicationId: id, userId } },
        });
        if (found) await tx.socialLike.delete({ where: { id: found.id } });
        else
          await tx.socialLike.create({ data: { publicationId: id, userId } });
        const total = await tx.socialLike.count({
          where: { publicationId: id },
        });
        await tx.socialPublication.update({
          where: { id },
          data: { likesCount: total },
        });
        return !found;
      });
      break;
    } catch (error) {
      if (attempt === 2 || !["P2034", "P2002"].includes(error?.code))
        throw error;
    }
  }
  await refreshPublication(guild, id);
  await processHighlight(guild, id);
  await refreshHighlights(guild);
  return added;
}
async function addComment(guild, id, userId, content) {
  const p = await prisma_1.prisma.socialPublication.findUnique({
      where: { id },
    }),
    c = await socialConfig(guild.id);
  if (
    !c.enabled ||
    !p ||
    p.guildId !== guild.id ||
    p.status !== "ACTIVE" ||
    !c.commentsEnabled ||
    !p.commentsEnabled
  )
    throw new Error("Os comentários estão desativados.");
  if (!content?.trim() || content.length > 1000)
    throw new Error("Comentário inválido (máximo 1000 caracteres).");
  await prisma_1.prisma.$transaction([
    prisma_1.prisma.socialComment.create({
      data: { publicationId: id, authorId: userId, content: content.trim() },
    }),
    prisma_1.prisma.socialPublication.update({
      where: { id },
      data: { commentsCount: { increment: 1 } },
    }),
  ]);
  await refreshPublication(guild, id);
  await refreshHighlights(guild);
}
async function commentsView(guild, id, page = 0) {
  const p = await prisma_1.prisma.socialPublication.findUnique({
    where: { id },
  });
  if (!p || p.guildId !== guild.id)
    throw new Error("Publicação não encontrada.");
  const count = await prisma_1.prisma.socialComment.count({
      where: { publicationId: id, status: "ACTIVE" },
    }),
    pages = Math.max(1, Math.ceil(count / 5)),
    current = Math.max(0, Math.min(page, pages - 1)),
    rows = await prisma_1.prisma.socialComment.findMany({
      where: { publicationId: id, status: "ACTIVE" },
      orderBy: { createdAt: "asc" },
      skip: current * 5,
      take: 5,
    });
  const embed = new discord_js_1.EmbedBuilder()
    .setColor(0xd20b20)
    .setTitle("COMENTÁRIOS")
    .setDescription(
      rows.length
        ? rows.map((x) => `<@${x.authorId}>\n“${x.content}”`).join("\n\n")
        : "Ainda não há comentários.",
    )
    .setFooter({ text: `Página ${current + 1}/${pages}` });
  return {
    embeds: [embed],
    components: [
      new discord_js_1.ActionRowBuilder().addComponents(
        new discord_js_1.ButtonBuilder()
          .setCustomId(`social-comment-page:${id}:${current - 1}`)
          .setLabel("Anterior")
          .setStyle(discord_js_1.ButtonStyle.Secondary)
          .setDisabled(current === 0),
        new discord_js_1.ButtonBuilder()
          .setCustomId(`social-comment-add:${id}`)
          .setLabel("Adicionar comentário")
          .setStyle(discord_js_1.ButtonStyle.Primary),
        new discord_js_1.ButtonBuilder()
          .setCustomId(`social-comment-page:${id}:${current + 1}`)
          .setLabel("Próximo")
          .setStyle(discord_js_1.ButtonStyle.Secondary)
          .setDisabled(current === pages - 1),
      ),
    ],
  };
}
async function likesView(guild, id, requesterId, page = 0) {
  const p = await prisma_1.prisma.socialPublication.findUnique({
    where: { id },
  });
  if (!p || p.guildId !== guild.id)
    throw new Error("Publicação não encontrada.");
  const requester = await guild.members.fetch(requesterId),
    moderator = requester.permissions.has(
      discord_js_1.PermissionFlagsBits.ManageMessages,
    );
  if (p.authorId !== requesterId && !moderator)
    throw new Error("Somente o autor da publicação pode ver quem curtiu.");
  const count = await prisma_1.prisma.socialLike.count({
      where: { publicationId: id },
    }),
    pages = Math.max(1, Math.ceil(count / 10)),
    current = Math.max(0, Math.min(page, pages - 1)),
    rows = await prisma_1.prisma.socialLike.findMany({
      where: { publicationId: id },
      orderBy: { createdAt: "asc" },
      skip: current * 10,
      take: 10,
    });
  const embed = new discord_js_1.EmbedBuilder()
    .setColor(color((await socialConfig(guild.id)).color))
    .setTitle("QUEM CURTIU")
    .setDescription(
      rows.length
        ? rows
            .map((x, n) => `**${current * 10 + n + 1}.** <@${x.userId}>`)
            .join("\n")
        : "Ninguém curtiu esta publicação ainda.",
    )
    .setFooter({
      text: `${count} curtida${count === 1 ? "" : "s"} • Página ${current + 1}/${pages}`,
    });
  return {
    embeds: [embed],
    components: [
      new discord_js_1.ActionRowBuilder().addComponents(
        new discord_js_1.ButtonBuilder()
          .setCustomId(`social-likes:${id}:${current - 1}`)
          .setLabel("Anterior")
          .setStyle(discord_js_1.ButtonStyle.Secondary)
          .setDisabled(current === 0),
        new discord_js_1.ButtonBuilder()
          .setCustomId(`social-likes:${id}:${current + 1}`)
          .setLabel("Próximo")
          .setStyle(discord_js_1.ButtonStyle.Secondary)
          .setDisabled(current === pages - 1),
      ),
    ],
  };
}
async function sendSocialDm(guild, id, senderId, content, referenceText) {
  const p = await prisma_1.prisma.socialPublication.findUnique({
      where: { id },
    }),
    c = await socialConfig(guild.id);
  if (
    !c.enabled ||
    !p ||
    p.guildId !== guild.id ||
    p.status !== "ACTIVE" ||
    !c.dmsEnabled ||
    !p.dmsEnabled
  )
    throw new Error("O autor não aceita mensagens nesta publicação.");
  if (!content?.trim() || content.length > 1000)
    throw new Error("Mensagem inválida (máximo 1000 caracteres).");
  if (p.authorId === senderId)
    throw new Error("Você não pode enviar uma DM para si mesmo.");
  const preference = await prisma_1.prisma.socialUserPreference.findUnique({
    where: { guildId_userId: { guildId: guild.id, userId: p.authorId } },
  });
  if (preference?.allowDms === false)
    throw new Error("O autor não aceita mensagens privadas.");
  const blocked = await prisma_1.prisma.socialBlock.findUnique({
    where: {
      guildId_blockerId_blockedId: {
        guildId: guild.id,
        blockerId: p.authorId,
        blockedId: senderId,
      },
    },
  });
  if (blocked)
    throw new Error("Não foi possível enviar esta interação privada.");
  const last = await prisma_1.prisma.socialDm.findFirst({
    where: { publication: { guildId: guild.id }, senderId },
    orderBy: { createdAt: "desc" },
  });
  if (
    last &&
    Date.now() - last.createdAt.getTime() < c.dmCooldownSeconds * 1000
  )
    throw new Error(
      "Você está enviando interações rápido demais. Tente novamente em alguns instantes.",
    );
  const row = await prisma_1.prisma.socialDm.create({
      data: {
        publicationId: id,
        senderId,
        recipientId: p.authorId,
        content,
        referenceText: referenceText || null,
        expiresAt: new Date(Date.now() + 7 * 86400000),
      },
    }),
    recipient = await guild.members.fetch(p.authorId).catch(() => null);
  if (!recipient) throw new Error("O usuário não está mais disponível.");
  const url = link(p),
    embed = new discord_js_1.EmbedBuilder()
      .setColor(color(c.color))
      .setTitle("NOVA RESPOSTA À SUA PUBLICAÇÃO")
      .setDescription(
        `<@${senderId}> respondeu à sua publicação.\n\n“${content}”`,
      )
      .addFields({
        name: "Sua publicação",
        value: `${p.content || "Publicação com mídia"}\n<#${p.channelId}> · <t:${Math.floor(p.createdAt.getTime() / 1000)}:R>`,
      });
  if (p.mediaUrl && (p.mediaType === "IMAGE" || p.mediaType === "GIF"))
    embed.setThumbnail(p.mediaUrl);
  const buttons = new discord_js_1.ActionRowBuilder().addComponents(
    new discord_js_1.ButtonBuilder()
      .setCustomId(`social-dm-reply:${row.id}`)
      .setLabel("Responder")
      .setStyle(discord_js_1.ButtonStyle.Primary),
    new discord_js_1.ButtonBuilder()
      .setLabel("Ver Publicação")
      .setStyle(discord_js_1.ButtonStyle.Link)
      .setURL(url || "https://discord.com"),
    new discord_js_1.ButtonBuilder()
      .setCustomId(`social-dm-block:${row.id}`)
      .setLabel("•••")
      .setStyle(discord_js_1.ButtonStyle.Secondary),
  );
  try {
    await recipient.send({ embeds: [embed], components: [buttons] });
  } catch {
    await prisma_1.prisma.socialDm.delete({ where: { id: row.id } });
    throw new Error(
      "Não foi possível enviar sua mensagem. O usuário não está disponível para receber interações privadas no momento.",
    );
  }
  return p;
}
async function currentMediaUrl(guild, p) {
  if (!p.messageId) return p.mediaUrl;
  const channel = await guild.channels.fetch(p.channelId).catch(() => null);
  if (!channel?.isTextBased() || channel.isDMBased()) return p.mediaUrl;
  const message = await channel.messages.fetch(p.messageId).catch(() => null);
  return (
    message?.attachments.first()?.url ||
    (await require("./media").legacyMediaUrl(guild, p))
  );
}
async function processHighlight(guild, publicationId) {
  const c = await socialConfig(guild.id);
  if (!c.enabled || !c.highlightsEnabled) return;
  const p = await prisma_1.prisma.socialPublication.findUnique({
    where: { id: publicationId },
  });
  if (
    !p ||
    p.guildId !== guild.id ||
    p.status !== "ACTIVE" ||
    p.highlightSuppressed ||
    p.likesCount < c.minHighlightLikes
  )
    return;
  const h = await prisma_1.prisma.socialHighlight.upsert({
    where: { publicationId },
    create: {
      publicationId,
      guildId: guild.id,
      authorId: p.authorId,
      likesAtMoment: p.likesCount,
    },
    update: {},
  });
  if (h.roleStatus === "PENDING") {
    const claim = await prisma_1.prisma.socialHighlight.updateMany({
      where: { id: h.id, roleStatus: "PENDING" },
      data: { roleStatus: "PROCESSING" },
    });
    if (claim.count) {
      let status = "SKIPPED";
      if (c.highlightRoleId) {
        const role = await guild.roles
            .fetch(c.highlightRoleId)
            .catch(() => null),
          member = await guild.members.fetch(p.authorId).catch(() => null);
        status =
          role?.editable && member
            ? await member.roles.add(role, "Destaque do INSTA").then(
                () => "SENT",
                () => "FAILED",
              )
            : "FAILED";
      }
      await prisma_1.prisma.socialHighlight.update({
        where: { id: h.id },
        data: { roleStatus: status, roleId: c.highlightRoleId },
      });
    }
  }
  if (h.announcementStatus === "PENDING") {
    const claim = await prisma_1.prisma.socialHighlight.updateMany({
      where: { id: h.id, announcementStatus: "PENDING" },
      data: { announcementStatus: "PROCESSING" },
    });
    if (claim.count) {
      let status = "SKIPPED";
      if (c.announceHighlights && c.highlightsChannelId) {
        const channel = await guild.channels
          .fetch(c.highlightsChannelId)
          .catch(() => null);
        if (channel?.isTextBased() && !channel.isDMBased()) {
          const view = await publicationView(
            guild,
            p,
            await currentMediaUrl(guild, p),
          );
          view.components[0].addTextDisplayComponents(
            new discord_js_1.TextDisplayBuilder().setContent(
              "### Novo destaque da comunidade",
            ),
          );
          status = await channel
            .send({ ...view, allowedMentions: { parse: [] } })
            .then(
              () => "SENT",
              () => "FAILED",
            );
        } else status = "FAILED";
      }
      await prisma_1.prisma.socialHighlight.update({
        where: { id: h.id },
        data: { announcementStatus: status },
      });
    }
  }
}
async function syncHighlightRole(guild, c, ranking) {
  if (c.highlightRoleMode === "PERMANENT") return;
  const desired = new Set(
      c.enabled && c.highlightRoleId ? ranking.map((p) => p.authorId) : [],
    ),
    grants = await prisma_1.prisma.socialHighlightGrant.findMany({
      where: { guildId: guild.id },
    });
  for (const grant of grants) {
    const keep =
        grant.roleId === c.highlightRoleId && desired.has(grant.userId),
      role = await guild.roles.fetch(grant.roleId).catch(() => null),
      member = await guild.members.fetch(grant.userId).catch(() => null);
    if (keep) {
      if (role && member && !member.roles.cache.has(role.id))
        await member.roles
          .add(role, "Destaque do Social AUDAZ")
          .catch((error) => console.warn("[social-highlight-role-add]", error));
      continue;
    }
    let removed = !role || !member;
    if (role && member)
      removed = await member.roles
        .remove(role, "Saiu dos Destaques do Social AUDAZ")
        .then(() => true)
        .catch((error) => {
          console.warn("[social-highlight-role-remove]", error);
          return false;
        });
    if (removed)
      await prisma_1.prisma.socialHighlightGrant
        .delete({ where: { id: grant.id } })
        .catch(() => null);
  }
  if (!c.enabled || !c.highlightRoleId) return;
  const role = await guild.roles.fetch(c.highlightRoleId).catch(() => null);
  if (!role || role.managed || !role.editable) {
    console.warn(
      "[social-highlight-role] Cargo inexistente, gerenciado ou acima do bot.",
    );
    return;
  }
  for (const userId of desired) {
    const member = await guild.members.fetch(userId).catch(() => null);
    if (!member) continue;
    const existing = await prisma_1.prisma.socialHighlightGrant.findUnique({
      where: {
        guildId_userId_roleId: { guildId: guild.id, userId, roleId: role.id },
      },
    });
    if (member.roles.cache.has(role.id)) {
      continue;
    }
    const added = await member.roles
      .add(role, "Entrou nos Destaques do Social AUDAZ")
      .then(() => true)
      .catch((error) => {
        console.warn("[social-highlight-role-add]", error);
        return false;
      });
    if (added && !existing)
      await prisma_1.prisma.socialHighlightGrant
        .create({ data: { guildId: guild.id, userId, roleId: role.id } })
        .catch(() => null);
  }
}
async function refreshHighlights(guild) {
  const c = await socialConfig(guild.id),
    ranking =
      c.enabled && c.highlightsEnabled ? await activeRanking(guild.id, c) : [],
    top = ranking[0];
  await syncHighlightRole(guild, c, ranking);
  if (!c.highlightsChannelId) return;
  const ch = await guild.channels
    .fetch(c.highlightsChannelId)
    .catch(() => null);
  if (!ch?.isTextBased() || ch.isDMBased()) return;
  let payload;
  if (top) {
    payload = await publicationView(
      guild,
      top,
      await currentMediaUrl(guild, top),
    );
    payload.components[0].addTextDisplayComponents(
      new discord_js_1.TextDisplayBuilder().setContent(
        "**Publicação mais curtida**" +
          (link(top) ? " · [Abrir original](" + link(top) + ")" : ""),
      ),
    );
  } else
    payload = {
      flags: discord_js_1.MessageFlags.IsComponentsV2,
      components: [
        new discord_js_1.ContainerBuilder()
          .setAccentColor(color(c.color))
          .addTextDisplayComponents(
            new discord_js_1.TextDisplayBuilder().setContent(
              "### Destaques da comunidade\nNenhuma publicação no período atual.",
            ),
          ),
      ],
      allowedMentions: { parse: [] },
    };
  let m = c.highlightsMessageId
    ? await ch.messages.fetch(c.highlightsMessageId).catch(() => null)
    : null;
  if (m)
    await m.edit({
      ...payload,
      content: null,
      embeds: [],
      attachments: require("./media").retainedAttachments(m),
    });
  else {
    m = await ch.send(payload);
    await prisma_1.prisma.socialConfig.update({
      where: { guildId: guild.id },
      data: { highlightsMessageId: m.id },
    });
  }
  for (const publication of ranking)
    await refreshPublication(guild, publication.id).catch(() => null);
}
const periodMs = (period) =>
  period === "DAILY"
    ? 86400000
    : period === "MONTHLY"
      ? 30 * 86400000
      : 7 * 86400000;
async function runSocialScheduler(client) {
  await prisma_1.prisma.socialDm.deleteMany({
    where: { expiresAt: { lte: new Date() } },
  });
  const configs = await prisma_1.prisma.socialConfig.findMany({
    where: { enabled: true },
  });
  for (const c of configs) {
    const guild = client.guilds.cache.get(c.guildId);
    if (!guild) continue;
    if (c.highlightsEnabled) {
      const candidates = await prisma_1.prisma.socialPublication.findMany({
        where: {
          guildId: c.guildId,
          status: "ACTIVE",
          highlightSuppressed: false,
          likesCount: { gte: c.minHighlightLikes },
          highlight: null,
        },
        select: { id: true },
        take: 25,
      });
      for (const candidate of candidates)
        await processHighlight(guild, candidate.id).catch((error) =>
          console.error("[insta-highlight]", error),
        );
    }
    if (
      Date.now() - c.periodStartedAt.getTime() >=
      periodMs(c.highlightPeriod)
    ) {
      const ranking = await activeRanking(c.guildId, c);
      await prisma_1.prisma.socialHighlightPeriod.create({
        data: {
          guildId: c.guildId,
          periodType: c.highlightPeriod,
          startedAt: c.periodStartedAt,
          endedAt: new Date(),
          rankingJson: JSON.stringify(
            ranking.map((p) => ({
              id: p.id,
              authorId: p.authorId,
              likes: p.likesCount,
              origin: p.origin,
              content: p.content,
              mediaUrl: p.mediaUrl,
            })),
          ),
        },
      });
      await prisma_1.prisma.socialConfig.update({
        where: { guildId: c.guildId },
        data: { periodStartedAt: new Date(), highlightsMessageId: null },
      });
    }
    await refreshHighlights(guild).catch(() => null);
  }
}
//# sourceMappingURL=service.js.map
