"use strict";
const { prepareAdminPanel } = require("../utils/adminTasks");
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderMemberRise = renderMemberRise;
const discord_js_1 = require("discord.js");
const adminUi_1 = require("../utils/adminUi");
const prisma_1 = require("../database/prisma");
const service_1 = require("./service");
const button = (id, label, style = discord_js_1.ButtonStyle.Secondary) => new discord_js_1.ButtonBuilder().setCustomId(`member-rise:${id}`).setLabel(label).setStyle(style);
async function renderMemberRise(i, page = "home", offset = 0, userId) {
    const guild = i.guild, s = await (0, service_1.stage)(guild.id);
    const embed = (await (0, adminUi_1.adminEmbed)(guild, "membros")).setTitle("Oficialização de membros").setDescription("Requisitos para tornar seus membros oficiais");
    const rows = [];
    if (page === "home") {
        const issue = (0, service_1.roleProblem)(guild, s);
        embed.addFields(
 {name:'Estado',value:s.enabled?'Ativado':'Desativado',inline:true},
 {name:'Cargos da oficialização',value:('Inicial: '+(s.initialRoleId?'<@&'+s.initialRoleId+'>':'Não configurado')+'\nOficial: '+(s.officialRoleId?'<@&'+s.officialRoleId+'>':'Não configurado')+(issue?'\n'+issue:'')).slice(0,1024)},
 {name:'Requisitos',value:(s.requirementMode==='ALL'?'Cumprir todos':'Cumprir qualquer um')+'\nMensagens: '+(s.messageEnabled?s.minMessages:'Desligado')+' · Call: '+(s.voiceEnabled?Math.floor(s.minVoiceSeconds/3600)+'h '+Math.floor(s.minVoiceSeconds%3600/60)+'min':'Desligada')},
 {name:'Onde contar atividade',value:require('./service').ids(s.textChannelIds).length+' canais de texto · '+require('./service').ids(s.voiceCategoryIds).length+' categorias de voz'}
 );
        rows.push(new discord_js_1.ActionRowBuilder().addComponents(button("toggle", s.enabled ? "Desativar" : "Ativar", s.enabled ? discord_js_1.ButtonStyle.Danger : discord_js_1.ButtonStyle.Success), button("roles", "Cargos inicial e oficial"), button("requirements", "Requisitos"), button("voice", "Regras de call"), button("messages", "Mensagens")));
        rows.push(new discord_js_1.ActionRowBuilder().addComponents(button("progress:0", "Progresso"), button("history:0", "Histórico"), button("preview", "Prévia e variáveis"), button("back", "Voltar")));
        rows.push(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.StringSelectMenuBuilder().setCustomId("member-rise-select:configure").setPlaceholder("Configurar canais e cargos ignorados").addOptions({ label: "Canais de texto", value: "textChannelIds" }, { label: "Categorias de voz", value: "voiceCategoryIds" }, { label: "Canal de anúncio", value: "announcementChannelId" }, { label: "Cargos ignorados", value: "ignoredRoleIds" })));
    }
    else if (page === "roles") {
        embed.setDescription("Defina os cargos antes e depois da oficialização. As alterações aparecem nesta mesma mensagem.");
        rows.push(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.RoleSelectMenuBuilder().setCustomId("member-rise-select:initialRoleId").setPlaceholder("Cargo inicial").setMinValues(1).setMaxValues(1)));
        rows.push(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.RoleSelectMenuBuilder().setCustomId("member-rise-select:officialRoleId").setPlaceholder("Cargo após a subida").setMinValues(1).setMaxValues(1)));
        rows.push(new discord_js_1.ActionRowBuilder().addComponents(button("home", "Voltar")));
    }
    else if (page === "preview") {
        const preview = (value) => (value.replace(/\{membro\}/g, "@Exemplo").replace(/\{usuario\}/g, "Exemplo").replace(/\{servidor\}/g, guild.name).replace(/\{cargo\}/g, s.officialRoleId ? `<@&${s.officialRoleId}>` : "@Membro").replace(/\{mensagens\}/g, String(s.minMessages)).replace(/\{tempo_call\}/g, `${Math.floor(s.minVoiceSeconds / 3600)}h`) || "—").slice(0, 1024);
        embed.setDescription("PRÉ-VISUALIZAÇÃO DAS MENSAGENS\nVariáveis: `{membro}` `{usuario}` `{servidor}` `{cargo}` `{mensagens}` `{tempo_call}`\nEdite os modelos em **Mensagens**.").addFields({ name: "Mensagem pública", value: preview(s.publicMessage) }, { name: "DM", value: preview(s.dmMessage) });
        rows.push(new discord_js_1.ActionRowBuilder().addComponents(button("home", "Voltar")));
    }
    else if (page === "choose") {
        embed.setDescription(`Selecione ${userId === "textChannelIds" ? "os canais de texto" : userId === "voiceCategoryIds" ? "as categorias de voz (todos os canais dentro delas contarão)" : userId === "ignoredRoleIds" ? "os cargos ignorados" : "o canal de anúncio"}. Uma seleção vazia limpa a configuração.`);
        if (userId === "ignoredRoleIds")
            rows.push(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.RoleSelectMenuBuilder().setCustomId(`member-rise-select:${userId}`).setPlaceholder("Cargos ignorados").setMinValues(0).setMaxValues(25)));
        else
            rows.push(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ChannelSelectMenuBuilder().setCustomId(`member-rise-select:${userId}`).setPlaceholder(userId === "voiceCategoryIds" ? "Selecione as categorias" : "Selecione os canais").setMinValues(userId === "announcementChannelId" ? 1 : 0).setMaxValues(userId === "announcementChannelId" ? 1 : 25).addChannelTypes(userId === "voiceCategoryIds" ? discord_js_1.ChannelType.GuildCategory : discord_js_1.ChannelType.GuildText)));
        rows.push(new discord_js_1.ActionRowBuilder().addComponents(button("home", "Voltar")));
    }
    else if (page === "progress") {
        const list = await prisma_1.prisma.memberRiseProgress.findMany({ where: { guildId: guild.id, stageId: s.id, ...(userId ? { userId } : {}) }, orderBy: { updatedAt: "desc" }, skip: offset, take: 10 });
        embed.setDescription(`PROGRESSO DOS MEMBROS • ${offset + 1}–${offset + list.length}`).addFields(list.map(p => ({ name: `${p.status === "DONE" ? "✅" : "⏳"} ${guild.members.cache.get(p.userId)?.displayName || p.userId}`, value: `💬 ${p.messages}/${s.minMessages} • 🎙️ ${Math.floor(p.voiceSeconds / 3600)}h ${Math.floor(p.voiceSeconds % 3600 / 60)}min/${Math.floor(s.minVoiceSeconds / 3600)}h • ${(0, service_1.percent)(s, p)}%`, inline: false })));
        if (!list.length)
            embed.addFields({ name: "Sem registros", value: "Nenhum membro nesta página." });
        rows.push(new discord_js_1.ActionRowBuilder().addComponents(button(`progress:${Math.max(0, offset - 10)}`, "Anterior"), button(`progress:${offset + 10}`, "Próxima"), button("search", "Buscar membro"), button("home", "Voltar")));
        if (list.length)
            rows.push(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.StringSelectMenuBuilder().setCustomId("member-rise-select:member").setPlaceholder("Ver detalhes").addOptions(list.map(p => ({ label: guild.members.cache.get(p.userId)?.displayName?.slice(0, 80) || p.userId, value: p.userId })))));
    }
    else if (page === "detail" && userId) {
        const p = await prisma_1.prisma.memberRiseProgress.findUnique({ where: { stageId_userId: { stageId: s.id, userId } } });
        const member = await guild.members.fetch(userId).catch(() => null);
        embed.setThumbnail(member?.displayAvatarURL() || null).setDescription(`**${member?.displayName || userId}**\nMensagens: ${p?.messages || 0}/${s.minMessages}\nCall: ${Math.floor((p?.voiceSeconds || 0) / 3600)}h ${Math.floor(((p?.voiceSeconds || 0) % 3600) / 60)}min / ${Math.floor(s.minVoiceSeconds / 3600)}h\nProgresso: ${(0, service_1.percent)(s, p || { messages: 0, voiceSeconds: 0 })}%\nStatus: ${p?.status === "DONE" ? "Oficial" : "Em progresso"}`);
        rows.push(new discord_js_1.ActionRowBuilder().addComponents(button(`confirm-promote:${userId}`, "Promover manualmente", discord_js_1.ButtonStyle.Success), button(`confirm-reset:${userId}`, "Resetar progresso", discord_js_1.ButtonStyle.Danger), button("progress:0", "Voltar")));
    }
    else if (page === "confirm" && userId) {
        const [action, target] = userId.split(":");
        embed.setDescription(action === "promote" ? "Tem certeza que deseja promover este membro manualmente? Os requisitos ainda não cumpridos serão ignorados." : "Tem certeza que deseja zerar o progresso deste membro? Os cargos atuais serão mantidos.");
        rows.push(new discord_js_1.ActionRowBuilder().addComponents(button(`${action}:${target}`, action === "promote" ? "Confirmar promoção" : "Confirmar reset", discord_js_1.ButtonStyle.Danger), button(`detail:${target}`, "Cancelar")));
    }
    else if (page === "history") {
        const list = await prisma_1.prisma.memberRiseHistory.findMany({ where: { guildId: guild.id, stageId: s.id }, orderBy: { createdAt: "desc" }, skip: offset, take: 10 });
        embed.setDescription("HISTÓRICO DE SUBIDAS").addFields(list.map(h => ({ name: `<@${h.userId}> • ${h.kind === "AUTO" ? "Automática" : "Manual"}`, value: `<@&${h.oldRoleId}> → <@&${h.newRoleId}> • <t:${Math.floor(h.createdAt.getTime() / 1000)}:f>\n💬 ${h.messages} • 🎙️ ${Math.floor(h.voiceSeconds / 3600)}h • Admin: ${h.adminId ? `<@${h.adminId}>` : "—"}\nAnúncio: ${h.announcementStatus} • DM: ${h.dmStatus}` })));
        if (!list.length)
            embed.addFields({ name: "Sem registros", value: "Nenhuma subida registrada." });
        rows.push(new discord_js_1.ActionRowBuilder().addComponents(button(`history:${Math.max(0, offset - 10)}`, "Anterior"), button(`history:${offset + 10}`, "Próxima"), button("home", "Voltar")));
    }
    if (i.deferred)
        await i.editReply((page === 'home' ? prepareAdminPanel(guild, 'oficializacao', { attachments: [], embeds: [embed], components: rows }) : { attachments: [], embeds: [embed], components: rows }));
    else
        await i.update((page === 'home' ? prepareAdminPanel(guild, 'oficializacao', { attachments: [], embeds: [embed], components: rows }) : { attachments: [], embeds: [embed], components: rows }));
}
//# sourceMappingURL=panel.js.map