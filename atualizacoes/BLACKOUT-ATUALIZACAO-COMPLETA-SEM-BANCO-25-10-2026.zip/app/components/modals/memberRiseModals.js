"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const permissions_1 = require("../../utils/permissions");
const prisma_1 = require("../../database/prisma");
const panel_1 = require("../../memberRise/panel");
const service_1 = require("../../memberRise/service");
const component = { customId: "member-rise-modal:", async execute(i) {
        if (!i.guild || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return void await i.reply({ content: "Sem permissão.", ephemeral: true });
        const action = i.customId.split(":")[1], s = await (0, service_1.stage)(i.guild.id);
        const value = (id) => i.fields.getTextInputValue(id).trim();
        const integer = (id, max) => { const n = Number(value(id)); if (!Number.isInteger(n) || n < 0 || n > max)
            throw new Error(`${id}: valor inválido (0–${max}).`); return n; };
        const bool = (id) => { const x = value(id).toUpperCase(); if (!["SIM", "NÃO", "NAO"].includes(x))
            throw new Error(`${id}: use SIM ou NÃO.`); return x === "SIM"; };
        try {
            if (action === "search") {
                const userId = value("member").replace(/\D/g, "");
                if (!userId)
                    throw new Error("Informe um ID ou menção válida.");
                return (0, panel_1.renderMemberRise)(i, "progress", 0, userId);
            }
            let data = {};
            if (action === "requirements") {
                const messages = integer("messages", 10000000), hours = integer("hours", 100000), minutes = integer("minutes", 59), mode = value("mode").toUpperCase();
                if (!["TODOS", "QUALQUER UM"].includes(mode))
                    throw new Error("Modo inválido.");
                if (!messages && !hours && !minutes)
                    throw new Error("Ative ao menos um requisito.");
                data = { minMessages: messages, messageEnabled: messages > 0, minVoiceSeconds: hours * 3600 + minutes * 60, voiceEnabled: hours + minutes > 0, requirementMode: mode === "TODOS" ? "ALL" : "ANY", messageIntervalSeconds: integer("interval", 3600) };
            }
            if (action === "voice")
                data = { minVoicePeople: Math.max(1, integer("people", 99)), ignoreAfk: bool("afk"), countMuted: bool("muted"), countDeafened: bool("deaf") };
            if (action === "messages") {
                if (value("public").length > 2000 || value("dm").length > 2000)
                    throw new Error("Mensagem limitada a 2000 caracteres.");
                data = { publicMessage: value("public"), dmMessage: value("dm") };
            }
            await prisma_1.prisma.memberRiseStage.update({ where: { id: s.id }, data });
            return (0, panel_1.renderMemberRise)(i, action === 'messages' ? 'preview' : 'home');
        }
        catch (error) {
            return void await i.reply({ content: error instanceof Error ? error.message : "Erro ao salvar.", ephemeral: true });
        }
    } };
exports.default = component;
//# sourceMappingURL=memberRiseModals.js.map