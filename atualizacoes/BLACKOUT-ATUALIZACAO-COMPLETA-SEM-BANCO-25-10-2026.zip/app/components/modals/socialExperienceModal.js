"use strict";
exports.default = {
  customId: "sx-form:",
  execute: (i) => require("../../social-experience/interactions").modal(i),
};
