"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const moderationPanel_1 = require("../../utils/moderationPanel");
const panelInteraction_1 = require("../../utils/panelInteraction");
const discord_js_1 = require("discord.js");
const permissions_1 = require("../../utils/permissions");
const prisma_1 = require("../../database/prisma");
const adminLog_1 = require("../../utils/adminLog");
const enums_1 = require("../../structures/enums");
const admModerationMenu_1 = require("../buttons/admModerationMenu");
function backRow(customId) {
    return new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId(customId).setLabel("Voltar").setStyle(discord_js_1.ButtonStyle.Secondary));
}
async function replyOrUpdate(interaction, embed, components) {
    if (interaction.isFromMessage()) {
        await interaction.update({ embeds: [embed], components });
    }
    else {
        await interaction.reply({ embeds: [embed], components, ephemeral: true });
    }
}
async function handlePunishment(i, type, userId) {
    const raw = type === "mute" ? i.fields.getTextInputValue("duration").trim() : "";
    return (0, moderationPanel_1.reviewModeration)(i, type, userId, i.fields.getTextInputValue("reason"), type === "mute" ? Number(raw) : undefined);
}
async function handleUnban(i) {
    return (0, moderationPanel_1.reviewModeration)(i, "unban", i.fields.getTextInputValue("userId").trim(), i.fields.getTextInputValue("reason") || "");
}
function parseList(raw) {
    return raw
        .split(/[,\n]/)
        .map((v) => v.trim().toLowerCase())
        .filter((v) => v.length > 0)
        .filter((v, i, arr) => arr.indexOf(v) === i);
}
async function handleWordsList(interaction) {
    await (0, panelInteraction_1.deferPanel)(interaction);
    const values = parseList(interaction.fields.getTextInputValue("words"));
    await prisma_1.prisma.$transaction([
        prisma_1.prisma.filterRule.deleteMany({ where: { guildId: interaction.guild.id, type: enums_1.FilterRuleType.WORD } }),
        ...values.map((value) => prisma_1.prisma.filterRule.create({ data: { guildId: interaction.guild.id, type: enums_1.FilterRuleType.WORD, value } })),
    ]);
    await (0, adminLog_1.logAdminAction)({
        guild: interaction.guild,
        actorId: interaction.user.id,
        action: enums_1.AdminLogAction.FILTER_RULE_UPDATED,
        details: `Lista de palavras proibidas atualizada (${values.length} termo(s)).`,
    });
    await (0, admModerationMenu_1.renderFiltersContent)(interaction);
}
async function handleLinksList(interaction) {
    await (0, panelInteraction_1.deferPanel)(interaction);
    const values = parseList(interaction.fields.getTextInputValue("domains"));
    await prisma_1.prisma.$transaction([
        prisma_1.prisma.filterRule.deleteMany({ where: { guildId: interaction.guild.id, type: enums_1.FilterRuleType.LINK_WHITELIST } }),
        ...values.map((value) => prisma_1.prisma.filterRule.create({ data: { guildId: interaction.guild.id, type: enums_1.FilterRuleType.LINK_WHITELIST, value } })),
    ]);
    await (0, adminLog_1.logAdminAction)({
        guild: interaction.guild,
        actorId: interaction.user.id,
        action: enums_1.AdminLogAction.FILTER_RULE_UPDATED,
        details: `Lista de domínios permitidos atualizada (${values.length} domínio(s)).`,
    });
    await (0, admModerationMenu_1.renderFiltersContent)(interaction);
}
async function handleThresholds1(interaction) {
    await (0, panelInteraction_1.deferPanel)(interaction);
    const capsThreshold = Number(interaction.fields.getTextInputValue("capsThreshold").trim());
    const capsMinLength = Number(interaction.fields.getTextInputValue("capsMinLength").trim());
    const floodMaxMessages = Number(interaction.fields.getTextInputValue("floodMaxMessages").trim());
    const floodIntervalSeconds = Number(interaction.fields.getTextInputValue("floodIntervalSeconds").trim());
    const spamMaxDuplicates = Number(interaction.fields.getTextInputValue("spamMaxDuplicates").trim());
    const values = { capsThreshold, capsMinLength, floodMaxMessages, floodIntervalSeconds, spamMaxDuplicates };
    if (Object.values(values).some((v) => !Number.isInteger(v) || v < 0) || capsThreshold > 100 || capsMinLength < 1 || floodMaxMessages < 1 || floodIntervalSeconds < 1 || spamMaxDuplicates < 1) {
        await interaction.followUp({ content: "Confira os limites: use inteiros, percentuais de 0 a 100, contagens/intervalos positivos e silêncio de 1 a 40320 minutos. Zero desativa os limites de advertências.", ephemeral: true });
        return;
    }
    await prisma_1.prisma.guildConfig.update({ where: { guildId: interaction.guild.id }, data: values });
    await (0, adminLog_1.logAdminAction)({
        guild: interaction.guild,
        actorId: interaction.user.id,
        action: enums_1.AdminLogAction.MODERATION_CONFIG_CHANGED,
        details: "Limites de conteúdo atualizados.",
    });
    await (0, admModerationMenu_1.renderFiltersLimits)(interaction);
}
async function handleThresholds2(interaction) {
    await (0, panelInteraction_1.deferPanel)(interaction);
    const toxicityThreshold = Number(interaction.fields.getTextInputValue("toxicityThreshold").trim());
    const autoMuteDurationMinutes = Number(interaction.fields.getTextInputValue("autoMuteDurationMinutes").trim());
    const maxWarnsBeforeMute = Number(interaction.fields.getTextInputValue("maxWarnsBeforeMute").trim());
    const maxWarnsBeforeBan = Number(interaction.fields.getTextInputValue("maxWarnsBeforeBan").trim());
    const values = { toxicityThreshold, autoMuteDurationMinutes, maxWarnsBeforeMute, maxWarnsBeforeBan };
    if (Object.values(values).some((v) => !Number.isInteger(v) || v < 0) || toxicityThreshold > 100 || autoMuteDurationMinutes < 1 || autoMuteDurationMinutes > 40320) {
        await interaction.followUp({ content: "Confira os limites: use inteiros, percentuais de 0 a 100, contagens/intervalos positivos e silêncio de 1 a 40320 minutos. Zero desativa os limites de advertências.", ephemeral: true });
        return;
    }
    await prisma_1.prisma.guildConfig.update({ where: { guildId: interaction.guild.id }, data: values });
    await (0, adminLog_1.logAdminAction)({
        guild: interaction.guild,
        actorId: interaction.user.id,
        action: enums_1.AdminLogAction.MODERATION_CONFIG_CHANGED,
        details: "Limites de ação atualizados.",
    });
    await (0, admModerationMenu_1.renderFiltersLimits)(interaction);
}
const component = {
    customId: "adm-modal:mod:",
    async execute(interaction) {
        if (!interaction.guild)
            return;
        const member = await interaction.guild.members.fetch(interaction.user.id);
        if (!(await (0, permissions_1.isBotAdmin)(member))) {
            await interaction.reply({ content: "🚫 Você não tem permissão para realizar esta ação.", ephemeral: true });
            return;
        }
        const parts = interaction.customId.split(":"); // ["adm-modal", "mod", "tipo", "userId?"]
        const type = parts[2];
        const userId = parts[3];
        switch (type) {
            case "warn":
            case "mute":
            case "kick":
            case "ban":
            case "unmute":
            case "clearwarns":
                return handlePunishment(interaction, type, userId);
            case "unban":
                return handleUnban(interaction);
            case "words":
                return handleWordsList(interaction);
            case "links":
                return handleLinksList(interaction);
            case "limites1":
                return handleThresholds1(interaction);
            case "limites2":
                return handleThresholds2(interaction);
        }
    },
};
exports.default = component;
