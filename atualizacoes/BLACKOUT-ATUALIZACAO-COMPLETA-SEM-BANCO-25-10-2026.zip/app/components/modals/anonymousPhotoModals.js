"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const service_1 = require("../../submundo/service");
const imageMime = new Set(["image/png", "image/jpeg", "image/jpg", "image/pjpeg", "image/webp", "image/gif"]);
const videoMime = new Set(["video/mp4", "video/webm", "video/quicktime", "video/mov"]);
const imageExt = new Set(["png", "jpg", "jpeg", "webp", "gif"]);
const videoExt = new Set(["mp4", "webm", "mov", "m4v"]);
const component = { customId: "anonymous-photo", async execute(i) {
    if (!i.guild || i.customId !== "anonymous-photo-upload") return;
    await i.deferReply({ flags: discord_js_1.MessageFlags.Ephemeral });
    const config = await (0, service_1.getAnonymousPhotoConfig)(i.guild.id);
    if (!config.enabled || !await (0, service_1.isSubmundoOpen)(config)) return void await i.editReply("O Submundo está fechado no momento.");
    const file = i.fields.getUploadedFiles("media", true).first();
    const contentType = file?.contentType?.toLowerCase() || "";
    const extension = file?.name.split(".").pop()?.toLowerCase() || "";
    const isImage = imageMime.has(contentType) || imageExt.has(extension);
    const isVideo = videoMime.has(contentType) || videoExt.has(extension);
    if (!file || (!isImage && !isVideo)) return void await i.editReply("Envie uma imagem (PNG/JPG/WEBP/GIF) ou vídeo (MP4/WEBM/MOV).");
    for (const [key, draft] of service_1.anonymousMediaDrafts) if (draft.expiresAt < Date.now()) service_1.anonymousMediaDrafts.delete(key);
    service_1.anonymousMediaDrafts.set((0, service_1.anonymousMediaDraftKey)(i.guild.id, i.user.id), {
        guildId: i.guild.id, userId: i.user.id, url: file.url, name: file.name, contentType, kind: isVideo ? "VIDEO" : "IMAGE", expiresAt: Date.now() + 10 * 60000,
    });
    const embed = new discord_js_1.EmbedBuilder().setColor(0xd20b20).setTitle("Antes de enviar")
        .setDescription("Ao confirmar, você declara que qualquer pessoa identificável na mídia possui **18 anos ou mais** e que a publicação é feita por ela própria ou possui autorização. Sua identidade fica oculta na publicação pública e disponível à equipe nos registros privados.");
    if (isImage) embed.setImage(file.url); else embed.addFields({ name: "Arquivo", value: `🎥 ${file.name}` });
    const row = new discord_js_1.ActionRowBuilder().addComponents(
        new discord_js_1.ButtonBuilder().setCustomId("anonymous-photo:confirm").setLabel("Confirmar envio").setStyle(discord_js_1.ButtonStyle.Success),
        new discord_js_1.ButtonBuilder().setCustomId("anonymous-photo:cancel").setLabel("Cancelar").setStyle(discord_js_1.ButtonStyle.Danger));
    return void await i.editReply({ embeds: [embed], components: [row] });
} };
exports.default = component;
