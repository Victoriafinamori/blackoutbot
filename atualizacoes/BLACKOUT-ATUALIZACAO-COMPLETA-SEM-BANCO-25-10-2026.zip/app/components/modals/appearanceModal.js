"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const permissions_1 = require("../../utils/permissions");
const prisma_1 = require("../../database/prisma");
const admConfigMenu_1 = require("../buttons/admConfigMenu");
const panelInteraction_1 = require("../../utils/panelInteraction");
const component = { customId: "appearance-modal:", async execute(i) {
        if (!i.guild)
            return;
        if (!await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return void await i.reply({ content: "Você não possui permissão neste servidor.", ephemeral: true });
        const action = i.customId.split(":")[1];
        if (!["nickname", "avatar", "banner", "color"].includes(action))
            return void await i.reply({ content: "Abra Personalização do bot para acessar as opções atuais.", ephemeral: true });
        const value = i.fields.getTextInputValue("value").trim();
        if (action === "color" && !/^#?[0-9a-fA-F]{6}$/.test(value))
            return void await i.reply({ content: "Cor inválida. Exemplo: D71935.", ephemeral: true });
        if (action === "nickname" && (!value || value.length > 32))
            return void await i.reply({ content: "O nome precisa ter de 1 a 32 caracteres.", ephemeral: true });
        if ((action === "avatar" || action === "banner") && !/^https?:\/\/\S+$/i.test(value))
            return void await i.reply({ content: "Informe uma URL de imagem válida.", ephemeral: true });
        await (0, panelInteraction_1.deferPanel)(i);
        try {
            if (action === "color") {
                await prisma_1.prisma.guildConfig.update({ where: { guildId: i.guild.id }, data: { embedColor: value.replace(/^#/, "").toUpperCase() } });
                return (0, admConfigMenu_1.renderDefaultPattern)(i);
            }
            // Always the current guild member. Never change ClientUser or fall back to account editing.
            const member = await i.guild.members.editMe({ [action === "nickname" ? "nick" : action]: value, reason: `Personalização local por ${i.user.id}` });
            await i.editReply(await (0, admConfigMenu_1.buildAppearancePayload)(i.guild, i.user.id, member));
        }
        catch {
            await i.followUp({ content: "Não foi possível alterar o perfil neste servidor. Confira a imagem e as permissões e tente novamente. A identidade da conta e os outros servidores foram preservados.", ephemeral: true });
        }
    } };
exports.default = component;
