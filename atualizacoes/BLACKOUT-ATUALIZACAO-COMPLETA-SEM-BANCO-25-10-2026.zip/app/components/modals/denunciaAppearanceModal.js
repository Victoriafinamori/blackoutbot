"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const prisma_1 = require("../../database/prisma");
const reports_1 = require("../../utils/reports");
const component = { customId: "denuncia-appearance:", async execute(i) {
        if (!i.guild)
            return;
        const action = i.customId.split(":")[1];
        if (action === "button") {
            const c = await (0, reports_1.reportConfig)(i.guild.id);
            const raw = i.fields.getTextInputValue("style").trim().toUpperCase();
            const styles = {
                AZUL: "PRIMARY", PRIMARY: "PRIMARY",
                CINZA: "SECONDARY", SECONDARY: "SECONDARY",
                VERDE: "SUCCESS", SUCCESS: "SUCCESS",
                VERMELHO: "DANGER", DANGER: "DANGER",
            };
            const panelButtonStyle = styles[raw];
            if (!panelButtonStyle)
                return void await i.reply({ content: "❌ Cor inválida. Use AZUL, CINZA, VERDE ou VERMELHO.", flags: discord_js_1.MessageFlags.Ephemeral });
            await prisma_1.prisma.reportConfig.update({
                where: { guildId: i.guild.id },
                data: {
                    panelButtonLabel: i.fields.getTextInputValue("label").trim() || "Iniciar denúncia",
                    panelButtonEmoji: i.fields.getTextInputValue("emoji").trim() || null,
                    panelButtonStyle,
                },
            });
            
            return require('../../utils/adminMessagePreview').showAdminMessagePreview(i,'denuncias');
        }
        const color = i.fields.getTextInputValue("color").replace("#", "").trim();
        if (!/^[0-9a-fA-F]{6}$/.test(color))
            return void await i.reply({ content: "Cor inválida. Exemplo: `D20B20`.", flags: discord_js_1.MessageFlags.Ephemeral });
        const rawAssets = i.fields.getTextInputValue("assets");
        const asset = (name) => rawAssets.split(/\r?\n/).find(line => line.toUpperCase().startsWith(`${name}=`))?.slice(name.length + 1).trim() || null;
        const c = await (0, reports_1.reportConfig)(i.guild.id);
        const data = {
            panelTitle: i.fields.getTextInputValue("title").trim(),
            panelDescription: i.fields.getTextInputValue("description").trim(),
            embedColor: `#${color.toUpperCase()}`,
            embedFooter: i.fields.getTextInputValue("footer").trim() || "Central de Denúncias",
            embedThumbnail: asset("THUMBNAIL"),
            embedImage: asset("IMAGEM"),
        };
        await prisma_1.prisma.reportConfig.update({ where: { guildId: i.guild.id }, data });
        
        return require('../../utils/adminMessagePreview').showAdminMessagePreview(i,'denuncias');
    } };
exports.default = component;
//# sourceMappingURL=denunciaAppearanceModal.js.map