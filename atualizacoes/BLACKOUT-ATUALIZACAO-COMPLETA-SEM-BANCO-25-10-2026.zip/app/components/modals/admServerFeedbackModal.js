"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const permissions_1 = require("../../utils/permissions");
const serverFeedback_1 = require("../../utils/serverFeedback");
const prisma_1 = require("../../database/prisma");
const admServerFeedbackMenu_1 = require("../buttons/admServerFeedbackMenu");
const component = { customId: "adm-feedback-modal:", async execute(i) { if (!i.guild || !(await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id))))
        return; await i.deferUpdate(); try {
        await (0, serverFeedback_1.getServerFeedbackConfig)(i.guild.id);
        const color = i.fields.getTextInputValue("color").replace("#", "").toUpperCase();
        if (!/^[0-9A-F]{6}$/.test(color))
            throw new Error("Cor hexadecimal inválida.");
        const image = i.fields.getTextInputValue("image").trim();
        if (image && !/^https?:\/\/\S+$/i.test(image))
            throw new Error("URL da imagem inválida.");
        await prisma_1.prisma.serverFeedbackConfig.update({ where: { guildId: i.guild.id }, data: { title: i.fields.getTextInputValue("title"), description: i.fields.getTextInputValue("description"), color, image: image || null, buttonLabel: i.fields.getTextInputValue("button") } });
        const config = await (0, serverFeedback_1.getServerFeedbackConfig)(i.guild.id);
        
        return require("../../utils/adminMessagePreview").showAdminMessagePreview(i,"feedback");
    }
    catch (error) {
        await i.followUp({ content: `Erro: ${error instanceof Error ? error.message : String(error)}`, ephemeral: true });
    } } };
exports.default = component;
//# sourceMappingURL=admServerFeedbackModal.js.map