"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const partnerships_1 = require("../../utils/partnerships");
const prisma_1 = require("../../database/prisma");
const asset = (s, k) => s.split(/\r?\n/).find(x => x.toUpperCase().startsWith(k + "="))?.slice(k.length + 1).trim() || null;
const component = { customId: "parceria:", async execute(i) {
        if (!i.guild)
            return;
        const parts = i.customId.split(":"), a = parts[1]; if (['appearance','button','requirements'].includes(a) && !await require('../../utils/permissions').isBotAdmin(await i.guild.members.fetch(i.user.id))) return;
        if (a === "form") {
            const ex = await (0, partnerships_1.findOpenPartnership)(i.guild.id, i.user.id);
            if (ex)
                return void await i.reply({ content: "Você já possui uma solicitação em andamento.", flags: discord_js_1.MessageFlags.Ephemeral });
            const wait = await (0, partnerships_1.partnershipCooldownRemaining)(i.guild.id, i.user.id);
            if (wait > 0)
                return void await i.reply({ content: `⏳ Aguarde **${Math.ceil(wait / 86400000)} dia(s)** antes de enviar uma nova solicitação.`, flags: discord_js_1.MessageFlags.Ephemeral });
            const members = Number(i.fields.getTextInputValue("memberCount").replace(/\D/g, ""));
            const invite = i.fields.getTextInputValue("inviteUrl").trim();
            if (!/^https?:\/\/(www\.)?(discord\.gg|discord\.com\/invite)\//i.test(invite))
                return void await i.reply({ content: "❌ Informe um convite válido do Discord.", flags: discord_js_1.MessageFlags.Ephemeral });
            if (!Number.isFinite(members) || members < 0)
                return void await i.reply({ content: "❌ Quantidade de membros inválida.", flags: discord_js_1.MessageFlags.Ephemeral });
            await i.deferReply({ flags: discord_js_1.MessageFlags.Ephemeral });
            try {
                const { req, ch } = await (0, partnerships_1.createPartnershipChannel)(i.guild, { requesterId: i.user.id, serverName: i.fields.getTextInputValue("serverName").trim(), inviteUrl: invite, memberCount: members, theme: i.fields.getTextInputValue("theme").trim(), proposal: i.fields.getTextInputValue("proposal").trim() });
                await i.editReply(`✅ Solicitação **#${String(req.number).padStart(4, "0")}** criada. Acesse <#${ch.id}>.`);
            }
            catch (e) {
                await i.editReply(`❌ ${e instanceof Error ? e.message : "Não foi possível criar."}`);
            }
            return;
        }
        if (a === "appearance") {
            const c = await (0, partnerships_1.partnershipConfig)(i.guild.id), hex = i.fields.getTextInputValue("color").trim().replace("#", "");
            if (!/^[0-9a-fA-F]{6}$/.test(hex))
                return void await i.reply({ content: "HEX inválido.", flags: discord_js_1.MessageFlags.Ephemeral });
            const assets = i.fields.getTextInputValue("assets");
            await prisma_1.prisma.partnershipConfig.update({ where: { guildId: i.guild.id }, data: { panelTitle: i.fields.getTextInputValue("title").trim(), panelDescription: i.fields.getTextInputValue("description").trim(), embedColor: `#${hex.toUpperCase()}`, embedFooter: i.fields.getTextInputValue("footer").trim() || "Central de Parcerias", embedThumbnail: asset(assets, "THUMBNAIL"), embedImage: asset(assets, "IMAGEM") } });
            
            return require('../../utils/adminMessagePreview').showAdminMessagePreview(i,'parcerias');
        }
        if (a === "button") {
            const c = await (0, partnerships_1.partnershipConfig)(i.guild.id);
            const raw = i.fields.getTextInputValue("style").trim().toUpperCase();
            const styles = { AZUL: "PRIMARY", PRIMARY: "PRIMARY", CINZA: "SECONDARY", SECONDARY: "SECONDARY", VERDE: "SUCCESS", SUCCESS: "SUCCESS", VERMELHO: "DANGER", DANGER: "DANGER" };
            const panelButtonStyle = styles[raw];
            if (!panelButtonStyle)
                return void await i.reply({ content: "❌ Cor inválida. Use AZUL, CINZA, VERDE ou VERMELHO.", flags: discord_js_1.MessageFlags.Ephemeral });
            await prisma_1.prisma.partnershipConfig.update({ where: { guildId: i.guild.id }, data: { panelButtonLabel: i.fields.getTextInputValue("label").trim() || "Solicitar parceria", panelButtonEmoji: i.fields.getTextInputValue("emoji").trim() || null, panelButtonStyle } });
            
            return require('../../utils/adminMessagePreview').showAdminMessagePreview(i,'parcerias');
        }
        if (a === "requirements") {
            const min = Math.max(0, Number(i.fields.getTextInputValue("minMembers")) || 0), days = Math.max(0, Math.min(365, Number(i.fields.getTextInputValue("cooldownDays")) || 0));
            await (0, partnerships_1.partnershipConfig)(i.guild.id);
            await prisma_1.prisma.partnershipConfig.update({ where: { guildId: i.guild.id }, data: { minMembers: min, cooldownDays: days } });
            return require("../buttons/admPartnershipsMenu").renderPartnershipsMenu(i);
        }
        if (a === "decision") {
            if (!(await (0, partnerships_1.canHandlePartnerships)(i.guild, i.user.id)))
                return void await i.reply({ content: "Sem permissão.", flags: discord_js_1.MessageFlags.Ephemeral });
            const id = parts[2], choice = parts[3], reason = i.fields.getTextInputValue("reason").trim() || (choice === "approve" ? "Aprovada pela equipe." : "Encerrado pela equipe.");
            await i.deferReply({ flags: discord_js_1.MessageFlags.Ephemeral });
            try {
                const status = choice === "approve" ? "APPROVED" : choice === "reject" ? "REJECTED" : "CLOSED";
                const { req, ch } = await (0, partnerships_1.finishPartnership)(i.guild, id, i.user.id, status, reason);
                await i.editReply(`✅ Parceria **#${String(req.number).padStart(4, "0")}** ${choice === "approve" ? "aprovada" : choice === "reject" ? "recusada" : "encerrada"}. O transcript foi enviado aos logs.`);
                if (ch?.isTextBased())
                    setTimeout(() => ch.delete("Atendimento de parceria encerrado").catch(() => null), 5000);
            }
            catch (e) {
                await i.editReply(`❌ ${e instanceof Error ? e.message : "Erro ao finalizar."}`);
            }
        }
    } };
exports.default = component;
//# sourceMappingURL=partnershipModals.js.map