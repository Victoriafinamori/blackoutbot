"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const prisma_1 = require("../../database/prisma");
const permissions_1 = require("../../utils/permissions");
const panelInteraction_1 = require("../../utils/panelInteraction");
const registrationAdmin_1 = require("../../utils/registrationAdmin");
const component = { customId: 'registration-embed:', async execute(i) {
        if (!i.guild || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return;
        const prefix = i.customId.split(':')[1];
        if (!['panel', 'internal'].includes(prefix))
            return;
        const color = i.fields.getTextInputValue('color').replace('#', '').trim();
        if (!/^[\da-f]{6}$/i.test(color))
            return i.reply({ content: 'Cor hexadecimal inválida. Exemplo: D71935.', ephemeral: true });
        const raw = i.fields.getTextInputValue('assets'), asset = (name) => raw.split(/\r?\n/).find((line) => line.toUpperCase().startsWith(name + '='))?.slice(name.length + 1).trim() || null;
        const thumbnail = asset('THUMBNAIL'), image = asset('IMAGEM');
        for (const url of [thumbnail, image])
            if (url) {
                try {
                    if (!['https:', 'http:'].includes(new URL(url).protocol))
                        throw Error();
                }
                catch {
                    return i.reply({ content: 'Use uma URL HTTP ou HTTPS válida para as imagens.', ephemeral: true });
                }
            }
        const data = { [prefix + 'Title']: i.fields.getTextInputValue('title').trim(), [prefix + 'Description']: i.fields.getTextInputValue('description').trim(), [prefix + 'Color']: color, [prefix + 'Thumbnail']: thumbnail, [prefix + 'Image']: image, [prefix + 'Footer']: asset('RODAPE') };
        if (prefix === 'panel')
            data.panelAuthor = asset('AUTOR');
        await (0, panelInteraction_1.deferPanel)(i);
        await prisma_1.prisma.registrationConfig.update({ where: { guildId: i.guild.id }, data });
        return (0, registrationAdmin_1.renderRegistrationAdmin)(i, prefix === 'panel' ? 'preview-panel' : 'internal');
    } };
exports.default = component;
