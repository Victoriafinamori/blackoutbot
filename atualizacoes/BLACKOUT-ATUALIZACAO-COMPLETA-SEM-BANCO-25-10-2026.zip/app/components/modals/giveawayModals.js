"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const drafts_1 = require("../../giveaways/drafts");
const views_1 = require("../../giveaways/views");
const service_1 = require("../../giveaways/service");
const prisma_1 = require("../../database/prisma");
const number = (v, min, max) => { const n = Number(v); if (!Number.isFinite(n) || n < min || n > max)
    throw new Error(`Use um número entre ${min} e ${max}.`); return Math.round(n); };
async function refresh(i) { await i.deferUpdate(); await i.editReply(await (0, views_1.wizardView)(i.guild, i.user.id)); }
const component = { customId: "giveaway-", async execute(i) { if (!i.guild)
        return; try {
        if (i.customId === "giveaway-wizard-modal:info") {
            (0, drafts_1.updateGiveawayDraft)(i.guild.id, i.user.id, { title: i.fields.getTextInputValue("title").trim(), description: i.fields.getTextInputValue("description").trim(), winnerCount: number(i.fields.getTextInputValue("winners"), 1, 25), durationMinutes: number(i.fields.getTextInputValue("duration"), 1, 525600) });
            return void await refresh(i);
        }
        if (i.customId === "giveaway-wizard-modal:publication") {
            (0, drafts_1.updateGiveawayDraft)(i.guild.id, i.user.id, { content: i.fields.getTextInputValue("content").trim(), buttonLabel: i.fields.getTextInputValue("button").trim() || "Participar", mentionEveryone: i.fields.getTextInputValue("everyone").trim().toUpperCase() === "SIM" });
            return void await refresh(i);
        }
        if (i.customId === "giveaway-wizard-modal:requirements") {
            (0, drafts_1.updateGiveawayDraft)(i.guild.id, i.user.id, { minCallSeconds: number(i.fields.getTextInputValue("call"), 0, 100000) * 60, minMessages: number(i.fields.getTextInputValue("chat"), 0, 100000) });
            return void await refresh(i);
        }
        if (i.customId.startsWith("giveaway-reroll-modal:")) {
            const id = i.customId.split(":")[1];
            if (!await (0, service_1.canManageGiveaways)(i.guild, i.user.id))
                return void await i.reply({ content: "Sem permissão.", flags: discord_js_1.MessageFlags.Ephemeral });
            const motivo = i.fields.getTextInputValue("motivo").trim();
            const tipoRaw = i.fields.getTextInputValue("tipo").trim().toUpperCase();
            if (tipoRaw !== "SUBSTITUIR" && tipoRaw !== "REFAZER")
                return void await i.reply({ content: "O tipo deve ser SUBSTITUIR ou REFAZER.", flags: discord_js_1.MessageFlags.Ephemeral });
            await i.deferUpdate();
            await (0, service_1.endGiveaway)(i.guild, id, i.user.id, true, tipoRaw === "SUBSTITUIR", motivo);
            return void await i.editReply(await (0, views_1.manageGiveawayView)(i.guild, id));
        }
        if (i.customId.startsWith("giveaway-edit-modal:")) {
            const id = i.customId.split(":")[1];
            if (!await (0, service_1.canManageGiveaways)(i.guild, i.user.id))
                return void await i.reply({ content: "Sem permissão.", flags: discord_js_1.MessageFlags.Ephemeral });
            const winners = number(i.fields.getTextInputValue("winners"), 1, 25);
            const call = number(i.fields.getTextInputValue("call"), 0, 100000) * 60;
            const chat = number(i.fields.getTextInputValue("chat"), 0, 100000);
            await prisma_1.prisma.giveaway.update({ where: { id }, data: { title: i.fields.getTextInputValue("title").trim(), description: i.fields.getTextInputValue("description").trim(), winnerCount: winners, minCallSeconds: call, minMessages: chat } });
            await (0, service_1.refreshGiveaway)(i.guild, id);
            await (0, service_1.logGiveawayAction)(i.guild, id, i.user.id, "EDITADO", "Informações do sorteio foram atualizadas pela equipe.");
            await i.deferUpdate();
            return void await i.editReply(await (0, views_1.manageGiveawayView)(i.guild, id));
        }
        if (i.customId.startsWith("giveaway-config:")) {
            await (0, service_1.giveawayConfig)(i.guild.id);
            const type = i.customId.split(":")[1];
            if (type === "appearance") {
                const color = i.fields.getTextInputValue("color").replace("#", "").toUpperCase();
                if (!/^[0-9A-F]{6}$/.test(color))
                    throw new Error("Cor hexadecimal inválida.");
                await prisma_1.prisma.giveawayConfig.update({ where: { guildId: i.guild.id }, data: { title: i.fields.getTextInputValue("title"), defaultDescription: i.fields.getTextInputValue("description"), color, footer: i.fields.getTextInputValue("footer"), buttonLabel: i.fields.getTextInputValue("button") } });
            }
            if (type === "media")
                await prisma_1.prisma.giveawayConfig.update({ where: { guildId: i.guild.id }, data: { thumbnail: i.fields.getTextInputValue("thumbnail").trim() || null, image: i.fields.getTextInputValue("image").trim() || null } });
            if (type === "messages")
                await prisma_1.prisma.giveawayConfig.update({ where: { guildId: i.guild.id }, data: { joinedMessage: i.fields.getTextInputValue("joined"), endedMessage: i.fields.getTextInputValue("ended") } });
            if (type === "result")
                await prisma_1.prisma.giveawayConfig.update({ where: { guildId: i.guild.id }, data: { resultTitle: i.fields.getTextInputValue("title"), resultFooter: i.fields.getTextInputValue("footer") } });
            return require('../../utils/panelInteraction').refreshPanel(i, await require('../../giveaways/views').giveawayAppearanceView(i.guild));
        }
    }
    catch (error) {
        if (i.deferred || i.replied)
            await i.followUp({ content: error instanceof Error ? error.message : String(error), flags: discord_js_1.MessageFlags.Ephemeral });
        else
            await i.reply({ content: error instanceof Error ? error.message : String(error), flags: discord_js_1.MessageFlags.Ephemeral });
    } } };
exports.default = component;
//# sourceMappingURL=giveawayModals.js.map