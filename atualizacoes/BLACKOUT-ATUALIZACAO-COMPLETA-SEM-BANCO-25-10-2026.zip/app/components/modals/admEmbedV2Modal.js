"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// @ts-nocheck
const panelInteraction_1 = require("../../utils/panelInteraction");
const permissions_1 = require("../../utils/permissions");
const prisma_1 = require("../../database/prisma");
const admEmbedV2Menu_1 = require("../buttons/admEmbedV2Menu");
const customEmbeds_1 = require("../../utils/customEmbeds");
const nullable = (value) => { const v = String(value || "").trim(); return v || null; };
const validUrl = (value) => !value || /^https?:\/\/\S+$/i.test(value);
async function nextPosition(embedId) { return prisma_1.prisma.customEmbedButton.count({ where: { embedId } }); }
exports.default = {
    customId: "embedv2-modal:",
    async execute(interaction) {
        if (!interaction.guild)
            return;
        const member = await interaction.guild.members.fetch(interaction.user.id);
        if (!(await (0, permissions_1.isBotAdmin)(member)))
            return interaction.reply({ content: "🚫 Sem permissão.", ephemeral: true });
        const parts = interaction.customId.split(":");
        const action = parts[1];
        const embedId = parts[2];
        const extra = parts[3];
        const record = await (0, customEmbeds_1.fetchCustomEmbed)(embedId, interaction.guild.id);
        if (!record)
            return interaction.reply({ content: "❌ Embed não encontrada.", ephemeral: true });
        if (action === "text") {
            await (0, panelInteraction_1.deferPanel)(interaction);
            await prisma_1.prisma.customEmbed.update({ where: { id: embedId }, data: { title: nullable(interaction.fields.getTextInputValue("title")), description: nullable(interaction.fields.getTextInputValue("description")), author: nullable(interaction.fields.getTextInputValue("author")), footer: nullable(interaction.fields.getTextInputValue("footer")) } });
            return (0, admEmbedV2Menu_1.renderEmbedEditor)(interaction, embedId);
        }
        if (action === "visual") {
            const normalized = (0, customEmbeds_1.normalizeHex)(interaction.fields.getTextInputValue("color"), "");
            if (!normalized)
                return interaction.reply({ content: "❌ Cor HEX inválida. Exemplo: `#2B6CB0`.", ephemeral: true });
            const image = nullable(interaction.fields.getTextInputValue("image"));
            const thumbnail = nullable(interaction.fields.getTextInputValue("thumbnail"));
            if (!validUrl(image) || !validUrl(thumbnail))
                return interaction.reply({ content: "❌ A imagem/thumbnail precisa ser uma URL válida.", ephemeral: true });
            const timestampRaw = interaction.fields.getTextInputValue("timestamp").trim().toLowerCase();
            if (!["sim", "s", "yes", "1", "não", "nao", "n", "no", "0"].includes(timestampRaw))
                return interaction.reply({ content: "Informe sim ou não para mostrar a data/hora.", ephemeral: true });
            const showTimestamp = ["sim", "s", "yes", "1"].includes(timestampRaw);
            await (0, panelInteraction_1.deferPanel)(interaction);
            await prisma_1.prisma.customEmbed.update({ where: { id: embedId }, data: { color: normalized, imageUrl: image, thumbnailUrl: thumbnail, showTimestamp } });
            return (0, admEmbedV2Menu_1.renderEmbedEditor)(interaction, embedId);
        }
        if (action === "rename") {
            await (0, panelInteraction_1.deferPanel)(interaction);
            await prisma_1.prisma.customEmbed.update({ where: { id: embedId }, data: { name: interaction.fields.getTextInputValue("name").trim().slice(0, 80) || "Embed" } });
            return (0, admEmbedV2Menu_1.renderEmbedEditor)(interaction, embedId);
        }
        if (action === "add-link") {
            const url = interaction.fields.getTextInputValue("url").trim();
            if (!url || !validUrl(url))
                return interaction.reply({ content: "❌ URL inválida.", ephemeral: true });
            if (record.buttons.length >= 25)
                return interaction.reply({ content: "O limite é de 25 botões por mensagem.", ephemeral: true });
            await (0, panelInteraction_1.deferPanel)(interaction);
            await prisma_1.prisma.customEmbedButton.create({ data: { embedId, type: "LINK", label: interaction.fields.getTextInputValue("label").trim(), emoji: nullable(interaction.fields.getTextInputValue("emoji")), url, position: await nextPosition(embedId) } });
            return (0, admEmbedV2Menu_1.renderEmbedButtons)(interaction, embedId);
        }
        if (action === "add-channel") {
            const channel = await interaction.guild.channels.fetch(extra).catch(() => null);
            if (!channel || channel.guildId !== interaction.guild.id)
                return interaction.reply({ content: "Escolha um canal deste servidor.", ephemeral: true });
            if (record.buttons.length >= 25)
                return interaction.reply({ content: "O limite é de 25 botões por mensagem.", ephemeral: true });
            await (0, panelInteraction_1.deferPanel)(interaction);
            await prisma_1.prisma.customEmbedButton.create({ data: { embedId, type: "CHANNEL", label: interaction.fields.getTextInputValue("label").trim(), emoji: nullable(interaction.fields.getTextInputValue("emoji")), channelId: extra, position: await nextPosition(embedId) } });
            return (0, admEmbedV2Menu_1.renderEmbedButtons)(interaction, embedId);
        }
        if (action === "edit-button") {
            const item = record.buttons.find((b) => b.id === extra);
            if (!item)
                return interaction.reply({ content: "❌ Botão não encontrado.", ephemeral: true });
            const data = { label: interaction.fields.getTextInputValue("label").trim(), emoji: nullable(interaction.fields.getTextInputValue("emoji")) };
            if (item.type === "LINK") {
                const url = interaction.fields.getTextInputValue("url").trim();
                if (!url || !validUrl(url))
                    return interaction.reply({ content: "❌ URL inválida.", ephemeral: true });
                data.url = url;
            }
            await (0, panelInteraction_1.deferPanel)(interaction);
            await prisma_1.prisma.customEmbedButton.update({ where: { id: item.id }, data });
            return (0, admEmbedV2Menu_1.renderEmbedButtons)(interaction, embedId);
        }
    },
};
