"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const prisma_1 = require("../../database/prisma");
const permissions_1 = require("../../utils/permissions");
const service_1 = require("../../submundo/service");
const admAnonymousPhotoMenu_1 = require("../buttons/admAnonymousPhotoMenu");
async function respondPanel(i) {
    const payload = await (0, admAnonymousPhotoMenu_1.buildAnonymousPhotoAdminView)(i.guild);
    if (typeof i.isFromMessage === "function" && i.isFromMessage()) return i.update(payload);
    return i.reply({ ...payload, flags: discord_js_1.MessageFlags.Ephemeral });
}
const component = { customId: "adm-anonymous-photo-modal:", async execute(i) {
    if (!i.guild) return;
    if (!await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
        return void await i.reply({ content: "Você não possui permissão.", flags: discord_js_1.MessageFlags.Ephemeral });
    const action = i.customId.split(":")[1];
    await (0, service_1.getAnonymousPhotoConfig)(i.guild.id);
    if (action === "appearance") {
        const color = i.fields.getTextInputValue("color").replace("#", "").trim();
        if (!/^[0-9a-f]{6}$/i.test(color)) return void await i.reply({ content: "Informe uma cor hexadecimal com 6 caracteres.", flags: discord_js_1.MessageFlags.Ephemeral });
        const image = i.fields.getTextInputValue("image").trim();
        if (image && !/^https?:\/\/\S+$/i.test(image)) return void await i.reply({ content: "A imagem deve ser uma URL válida.", flags: discord_js_1.MessageFlags.Ephemeral });
        await prisma_1.prisma.anonymousPhotoConfig.update({ where: { guildId: i.guild.id }, data: {
            title: i.fields.getTextInputValue("title").trim(), description: i.fields.getTextInputValue("description").trim(), color: color.toUpperCase(), image: image || null, buttonLabel: i.fields.getTextInputValue("button").trim(),
        } });
        return require("../../utils/adminMessagePreview").showAdminMessagePreview(i,"anonymous-photo");
    }
    if (action === "schedule") {
        const openTime = i.fields.getTextInputValue("openTime").trim();
        const closeTime = i.fields.getTextInputValue("closeTime").trim();
        const valid = value => /^([01]\d|2[0-3]):[0-5]\d$/.test(value);
        if (!!openTime !== !!closeTime) return void await i.reply({ content: "Preencha **abertura e fechamento** juntos, ou deixe os dois vazios para remover o horário.", flags: discord_js_1.MessageFlags.Ephemeral });
        if (openTime && (!valid(openTime) || !valid(closeTime))) return void await i.reply({ content: "Use o formato **HH:MM**, por exemplo `22:00` e `03:00`.", flags: discord_js_1.MessageFlags.Ephemeral });
        if (openTime && openTime === closeTime) return void await i.reply({ content: "Abertura e fechamento não podem ter o mesmo horário.", flags: discord_js_1.MessageFlags.Ephemeral });
        await prisma_1.prisma.anonymousPhotoConfig.update({ where: { guildId: i.guild.id }, data: { openTime: openTime || null, closeTime: closeTime || null, lastPanelOpen: null } });
        await (0, service_1.refreshAnonymousMediaPanel)(i.guild).catch(() => null);
        return void await respondPanel(i);
    }
    if (action === "remove") {
        await i.deferReply({ flags: discord_js_1.MessageFlags.Ephemeral });
        const publicId = i.fields.getTextInputValue("publicId").trim().toUpperCase();
        const reason = i.fields.getTextInputValue("reason").trim();
        const record = await prisma_1.prisma.anonymousPhotoSubmission.findFirst({ where: { guildId: i.guild.id, publicId } });
        if (!record) return void await i.editReply("Nenhuma publicação foi encontrada com esse ID.");
        if (["REMOVED", "CLEANED"].includes(record.status)) return void await i.editReply("Essa publicação já foi removida.");
        if (record.publicChannelId && record.publicMessageId) {
            const channel = await (0, service_1.resolveTextChannel)(i.guild, record.publicChannelId);
            if (channel) {
                const message = await channel.messages.fetch(record.publicMessageId).catch(() => null);
                if (message && !await message.delete().then(() => true).catch(() => false)) return void await i.editReply("Não consegui excluir a mensagem. Verifique a permissão **Gerenciar Mensagens** do bot.");
            }
        }
        await prisma_1.prisma.anonymousPhotoSubmission.update({ where: { id: record.id }, data: { status: "REMOVED", removedAt: new Date(), removedById: i.user.id, removalReason: reason } });
        await (0, service_1.sendAnonymousMediaLog)(i.guild, { title: "MÍDIA ANÔNIMA REMOVIDA", description: `ID do envio: **${record.publicId}**\nResponsável pelo envio: <@${record.authorId}>\nID do responsável: \`${record.authorId}\`\nRemovida por: <@${i.user.id}>\nMotivo: ${reason}\nStatus: **REMOVIDA**`, color: 0xe74c3c }).catch(() => null);
        return void await i.editReply(`A publicação **${record.publicId}** foi removida e registrada nos logs.`);
    }
} };
exports.default = component;
