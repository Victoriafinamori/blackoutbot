"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const communityInteractions_1 = require("../../bingo/communityInteractions");
exports.default = { customId: "bg-form:", execute: communityInteractions_1.modal };
