"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const permissions_1 = require("../../utils/permissions");
const prisma_1 = require("../../database/prisma");
const admGamesChatMenu_1 = require("../buttons/admGamesChatMenu");
const words_1 = require("../../games-chat/termo/words");
const number = (value, min, max, name) => {
    const parsed = Number(value);
    if (!Number.isInteger(parsed) || parsed < min || parsed > max)
        throw new Error(`${name} deve ficar entre ${min} e ${max}.`);
    return parsed;
};
const color = (value) => {
    const clean = value.replace("#", "").toUpperCase();
    if (!/^[0-9A-F]{6}$/.test(clean))
        throw new Error("Informe uma cor hexadecimal válida, como D20B20.");
    return clean;
};
const component = {
    customId: "adm-games-modal:",
    async execute(i) {
        if (!i.guild || !(await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id))))
            return;
        await i.deferUpdate();
        try {
            const type = i.customId.split(":")[1];
            if (type === "termo-appearance") {
                const get = (key) => i.fields.getTextInputValue(key).trim(), image = get("image");
                if (!get("title") ||
                    get("title").length > 100 ||
                    get("description").length > 1000 ||
                    get("footer").length > 150)
                    throw Error("Use título de até 100 caracteres, texto de até 1000 e rodapé de até 150.");
                if (image) {
                    try {
                        if (new URL(image).protocol !== "https:")
                            throw Error();
                    }
                    catch {
                        throw Error("Use uma URL HTTPS válida para a imagem.");
                    }
                }
                await prisma_1.prisma.termoConfig.update({
                    where: { guildId: i.guild.id },
                    data: {
                        title: get("title"),
                        description: get("description"),
                        color: color(get("color")),
                        image: image || null,
                        footer: get("footer") || null,
                    },
                });
                return void (await i.editReply(await require("../../games-chat/termo/admin").appearance(i.guild)));
            }
            if (type === "winner") {
                await prisma_1.prisma.mysteryBoxConfig.update({
                    where: { guildId: i.guild.id },
                    data: {
                        winnerTitle: i.fields.getTextInputValue("title"),
                        winnerDescription: i.fields.getTextInputValue("description"),
                        winnerColor: color(i.fields.getTextInputValue("color")),
                        winnerImage: i.fields.getTextInputValue("image") || null,
                        winnerFooter: i.fields.getTextInputValue("footer") || null,
                    },
                });
                return void (await i.editReply(await (0, admGamesChatMenu_1.mysteryAdminView)(i.guild)));
            }
            if (type === "reward") {
                const aliases = {
                    NADA: "NOTHING",
                    CARGO: "PERMANENT_ROLE",
                    TEMP: "TEMP_ROLE",
                    VIP: "TEMP_VIP",
                    MOEDA: "COIN",
                    XP: "XP",
                    ITEM: "ITEM",
                    PERSONALIZADA: "CUSTOM",
                    CUSTOM: "CUSTOM",
                };
                const rawType = i.fields
                    .getTextInputValue("type")
                    .trim()
                    .toLocaleUpperCase("pt-BR"), rewardType = aliases[rawType];
                if (!rewardType)
                    throw new Error("Tipo inválido. Use NADA, CARGO, TEMP, VIP, MOEDA, XP, ITEM ou PERSONALIZADA.");
                const details = i.fields
                    .getTextInputValue("details")
                    .split("|")
                    .map((value) => value.trim()), roleType = ["PERMANENT_ROLE", "TEMP_ROLE", "TEMP_VIP"].includes(rewardType), roleId = roleType ? details[1] || details[0] : null;
                if (roleType && !/^\d{15,22}$/.test(roleId || ""))
                    throw new Error("Para cargos, informe em detalhes: quantidade | ID do cargo | duração em minutos.");
                const duration = ["TEMP_ROLE", "TEMP_VIP"].includes(rewardType)
                    ? number(details[2] || "0", 1, 525600, "Duração") * 60
                    : null;
                await prisma_1.prisma.mysteryReward.create({
                    data: {
                        guildId: i.guild.id,
                        name: i.fields.getTextInputValue("name").trim(),
                        type: rewardType,
                        weight: number(i.fields.getTextInputValue("weight"), 1, 1000000, "Peso"),
                        stock: (() => {
                            const value = number(i.fields.getTextInputValue("stock"), 0, 1000000, "Estoque");
                            return value || null;
                        })(),
                        quantity: number(details[0] || "1", 1, 1000000, "Quantidade"),
                        roleId,
                        durationSeconds: duration,
                    },
                });
                return void (await i.editReply(await (0, admGamesChatMenu_1.mysteryAdminView)(i.guild)));
            }
            if (type === "word") {
                const word = i.fields.getTextInputValue("word").trim(), normalized = (0, words_1.normalizeWord)(word), config = await prisma_1.prisma.termoConfig.findUnique({
                    where: { guildId: i.guild.id },
                });
                if (!config)
                    throw new Error("Abra primeiro a página do TERMO.");
                if (normalized.length < 4 ||
                    normalized.length > 12 ||
                    !(0, words_1.validShape)(word, normalized.length))
                    throw new Error("Cadastre uma palavra de 4 a 12 letras, sem números ou símbolos.");
                const canAnswer = !["NAO", "NÃO", "N"].includes(i.fields
                    .getTextInputValue("answer")
                    .trim()
                    .toLocaleUpperCase("pt-BR"));
                await prisma_1.prisma.termoWord.upsert({
                    where: { guildId_normalized: { guildId: i.guild.id, normalized } },
                    update: {
                        word: word.toLocaleLowerCase("pt-BR"),
                        active: true,
                        canAnswer,
                    },
                    create: {
                        guildId: i.guild.id,
                        word: word.toLocaleLowerCase("pt-BR"),
                        normalized,
                        length: normalized.length,
                        canAnswer,
                    },
                });
                return void (await i.editReply(await (0, admGamesChatMenu_1.termoAdminView)(i.guild)));
            }
            if (type === "mystery") {
                const boxes = number(i.fields.getTextInputValue("boxes"), 1, 25, "Caixas"), duration = number(i.fields.getTextInputValue("duration"), 1, 10080, "Duração"), participants = number(i.fields.getTextInputValue("participants"), 0, 100000, "Participantes");
                await prisma_1.prisma.mysteryBoxConfig.update({
                    where: { guildId: i.guild.id },
                    data: {
                        boxCount: boxes,
                        durationSeconds: duration * 60,
                        maxParticipants: participants || null,
                        title: i.fields.getTextInputValue("title"),
                        color: color(i.fields.getTextInputValue("color")),
                    },
                });
                return void (await i.editReply(await (0, admGamesChatMenu_1.mysteryAdminView)(i.guild)));
            }
            if (type !== "termo")
                throw Error("Este formulário não está disponível.");
            const length = number(i.fields.getTextInputValue("length"), 4, 12, "Letras");
            await (0, words_1.ensureDefaultWords)();
            const config = await prisma_1.prisma.termoConfig.findUnique({
                where: { guildId: i.guild.id },
            }), scope = config?.wordSource === "SERVER"
                ? { guildId: i.guild.id }
                : config?.wordSource === "DEFAULT"
                    ? { guildId: null }
                    : { OR: [{ guildId: null }, { guildId: i.guild.id }] };
            if (!(await prisma_1.prisma.termoWord.count({
                where: { ...scope, length, active: true, canAnswer: true },
            })))
                throw Error(`Cadastre primeiro uma resposta de ${length} letras ou escolha o tamanho de 5 letras do dicionário padrão.`);
            await prisma_1.prisma.termoConfig.update({
                where: { guildId: i.guild.id },
                data: {
                    wordLength: number(i.fields.getTextInputValue("length"), 4, 12, "Letras"),
                    maxAttempts: number(i.fields.getTextInputValue("attempts"), 1, 10, "Tentativas"),
                    repeatAfterDays: number(i.fields.getTextInputValue("repeat"), 1, 3650, "Repetição"),
                    title: i.fields.getTextInputValue("title"),
                    color: color(i.fields.getTextInputValue("color")),
                },
            });
            await i.editReply(await (0, admGamesChatMenu_1.termoAdminView)(i.guild));
        }
        catch (error) {
            await i.followUp({
                content: `Erro: ${error instanceof Error ? error.message : String(error)}`,
                ephemeral: true,
            });
        }
    },
};
exports.default = component;
