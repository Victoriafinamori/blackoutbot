"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const prisma_1 = require("../../database/prisma");
const permissions_1 = require("../../utils/permissions");
const panelInteraction_1 = require("../../utils/panelInteraction");
const registrationPageAdmin_1 = require("../../utils/registrationPageAdmin");
const component = { customId: 'adm-reg-page:', async execute(i) {
        if (!i.guild || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return;
        const page = await prisma_1.prisma.registrationPage.findFirst({ where: { id: i.customId.slice('adm-reg-page:'.length), guildId: i.guild.id } });
        if (!page)
            return i.reply({ content: 'Esta página não existe mais. Reabra o formulário.', ephemeral: true });
        const value = (key) => i.fields.getTextInputValue(key).trim(), max = Number(value('max')), required = value('required').toUpperCase();
        if (!value('name') || !value('question') || !Number.isInteger(max) || max < 1 || max > 20 || !['SIM', 'NAO', 'NÃO'].includes(required))
            return i.reply({ content: 'Preencha nome e pergunta, use um limite de 1 a 20 e indique SIM ou NÃO para obrigatoriedade.', ephemeral: true });
        await (0, panelInteraction_1.deferPanel)(i);
        await prisma_1.prisma.registrationPage.update({ where: { id: page.id }, data: { name: value('name').slice(0, 100), question: value('question').slice(0, 256), description: value('description').slice(0, 2000) || null, maxChoices: max, required: required === 'SIM' } });
        return (0, panelInteraction_1.refreshPanel)(i, await (0, registrationPageAdmin_1.registrationPageManagerPayload)(i.guild, page.id));
    } };
exports.default = component;
