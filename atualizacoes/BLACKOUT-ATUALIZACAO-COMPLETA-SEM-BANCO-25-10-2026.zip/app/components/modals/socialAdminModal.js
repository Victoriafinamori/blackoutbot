"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const permissions_1 = require("../../utils/permissions");
const prisma_1 = require("../../database/prisma");
const service_1 = require("../../social/service");
const component = { customId: "social-admin-modal:", async execute(i) { if (!i.guild || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
        return; const hex = i.fields.getTextInputValue("color").replace("#", "").toUpperCase(); if (!/^[0-9A-F]{6}$/.test(hex))
        return void await i.reply({ content: "Cor hexadecimal inválida.", flags: discord_js_1.MessageFlags.Ephemeral }); await (0, service_1.socialConfig)(i.guild.id); await prisma_1.prisma.socialConfig.update({ where: { guildId: i.guild.id }, data: { title: i.fields.getTextInputValue("title"), description: i.fields.getTextInputValue("description"), color: hex, thumbnail: i.fields.getTextInputValue("thumbnail").trim() || null, image: i.fields.getTextInputValue("image").trim() || null } }); await require('../../utils/panelInteraction').refreshPanel(i, await require('../../social/admin').socialAdminView(i.guild)); } };
exports.default = component;
//# sourceMappingURL=socialAdminModal.js.map