"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const manager_1 = require("../../games-chat/termo/manager");
const ui_1 = require("../../games-chat/termo/ui");
const publisher_1 = require("../../games-chat/termo/publisher");
const component = {
    customId: "termo-guess:",
    async execute(i) {
        if (!i.guild)
            return;
        const privateOrigin = i.isFromMessage() && i.message?.flags.has(64);
        if (privateOrigin)
            await i.deferUpdate();
        else
            await i.deferReply({ ephemeral: true });
        try {
            await (0, manager_1.submitGuess)(i.guild.id, i.user.id, i.fields.getTextInputValue("word"), i.customId.split(":")[1] === "submit"
                ? undefined
                : i.customId.split(":")[1]);
            await i.editReply(await (0, ui_1.termoPlayerView)(i.guild, i.user.id));
            await (0, publisher_1.publishTermoPanel)(i.guild).catch(() => null);
        }
        catch (error) {
            if (privateOrigin)
                await i.followUp({
                    content: `Não foi possível registrar a tentativa: ${error instanceof Error ? error.message : String(error)}`,
                    ephemeral: true,
                });
            else
                await i.editReply(`Não foi possível registrar a tentativa: ${error instanceof Error ? error.message : String(error)}`);
        }
    },
};
exports.default = component;
