"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const permissions_1 = require("../../utils/permissions");
const panelInteraction_1 = require("../../utils/panelInteraction");
const config_1 = require("../../logging/config");
const delivery_1 = require("../../logging/delivery");
const panel_1 = require("../../logging/panel");
exports.default = { customId: "logs-center-modal:", async execute(i) {
        if (!i.guild || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return i.reply({ content: "Você não possui permissão neste servidor.", ephemeral: true });
        const [, action, group] = i.customId.split(":"), channel = i.fields.getTextInputValue("channel").trim();
        if (channel && !/^\d{15,25}$/.test(channel))
            return i.reply({ content: "Informe um ID de canal válido.", ephemeral: true });
        await (0, panelInteraction_1.deferPanel)(i);
        const s = await (0, config_1.readLogSettings)(i.guild.id, true);
        try {
            if (action === "external") {
                const guild = i.fields.getTextInputValue("guild").trim();
                if (!/^\d{15,25}$/.test(guild) || !channel)
                    throw Error("Informe IDs válidos para o servidor e o canal geral.");
                const candidate = { ...s, externalGuildId: guild, externalChannelId: channel, externalAuthorizedBy: i.user.id };
                await (0, delivery_1.validateExternal)(i.guild, candidate, i.user.id);
                await (0, config_1.saveLogSettings)(i.guild.id, { externalGuildId: guild, externalChannelId: channel, externalAuthorizedBy: i.user.id, ...(guild !== s.externalGuildId ? { externalChannelsJson: "{}" } : {}) });
                return (0, panel_1.renderLogDestination)(i, "Destino validado e salvo. Você pode enviar um teste e escolher o modo de envio.");
            }
            if (action === "channel" && config_1.LOG_GROUPS[group]) {
                const target = await (0, delivery_1.validateExternal)(i.guild, s, i.user.id);
                if (channel)
                    await (0, delivery_1.usableLogChannel)(target, channel);
                const channels = { ...s.externalChannels };
                if (channel)
                    channels[group] = channel;
                else
                    delete channels[group];
                await (0, config_1.saveLogSettings)(i.guild.id, { externalChannelsJson: JSON.stringify(channels), externalAuthorizedBy: i.user.id });
                return (0, panel_1.renderLogOrganization)(i, "external", group === "system" || group === "reintegration" ? "bot" : undefined);
            }
        }
        catch (error) {
            return i.followUp({ content: error.message || "Não foi possível configurar o destino externo.", ephemeral: true });
        }
    } };
