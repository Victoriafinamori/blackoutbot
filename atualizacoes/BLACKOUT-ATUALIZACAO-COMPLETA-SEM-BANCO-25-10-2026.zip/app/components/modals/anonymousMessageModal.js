"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const prisma_1 = require("../../database/prisma");
const service_1 = require("../../submundo/service");
const component = { customId: "anonymous-message-submit", async execute(i) {
    if (!i.guild) return;
    await i.deferReply({ flags: discord_js_1.MessageFlags.Ephemeral });
    const config = await (0, service_1.getAnonymousMessageConfig)(i.guild.id);
    if (!config.enabled || !await (0, service_1.isSubmundoOpen)(config)) return void await i.editReply("O Submundo está fechado no momento.");
    const destination = await (0, service_1.resolveTextChannel)(i.guild, config.destinationChannelId);
    if (!destination) return void await i.editReply("O canal de destino não está disponível.");
    const content = i.fields.getTextInputValue("content").trim();
    if (!content) return void await i.editReply("A mensagem não pode ficar vazia.");
    try {
        const extension=require('../../social-experience/anonymous');
        const queued=await extension.enqueue(i.guild,i.user.id,'ANON_TEXT',{content});
        if(queued)return void await i.editReply('Mensagem recebida para revisão privada da equipe. Você será avisado sobre a decisão.');
        const record=await extension.publish(i.guild,i.user.id,'ANON_TEXT',{content});
        return void await i.editReply('Mensagem publicada anonimamente. ID: '+record.publicId);
    }catch(error){return void await i.editReply(error.message||'Não foi possível publicar. Tente novamente.');}

} };
exports.default = component;
