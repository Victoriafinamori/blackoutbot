"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const permissions_1 = require("../../utils/permissions");
const prisma_1 = require("../../database/prisma");
const panelInteraction_1 = require("../../utils/panelInteraction");
const admConfigMenu_1 = require("../buttons/admConfigMenu");
const component = { customId: "adm-modal:embed", async execute(i) {
        if (!i.guild || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return;
        const color = i.fields.getTextInputValue("embedColor").trim().replace(/^#/, "");
        const footer = i.fields.getTextInputValue("embedFooter").trim(), author = i.fields.getTextInputValue("embedAuthor").trim(), thumbnail = i.fields.getTextInputValue("embedThumbnail").trim();
        if (!/^[0-9a-f]{6}$/i.test(color))
            return void await i.reply({ content: "Use uma cor hexadecimal de seis dígitos, como D71935.", ephemeral: true });
        if (thumbnail && !/^https?:\/\/\S+$/i.test(thumbnail))
            return void await i.reply({ content: "Use uma URL de imagem válida para a miniatura ou deixe o campo vazio.", ephemeral: true });
        await (0, panelInteraction_1.deferPanel)(i);
        await prisma_1.prisma.guildConfig.update({ where: { guildId: i.guild.id }, data: { embedColor: color.toUpperCase(), embedAuthor: author || null, embedFooter: footer || null, embedThumbnail: thumbnail || null } });
        return (0, admConfigMenu_1.renderDefaultPattern)(i);
    } };
exports.default = component;
