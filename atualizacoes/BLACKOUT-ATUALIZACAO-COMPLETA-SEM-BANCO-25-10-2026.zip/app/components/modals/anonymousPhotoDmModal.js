'use strict';
const {guarded,ephemeral}=require('../../social-experience/common');
exports.default={customId:'submundo-media-dm-submit:',execute(i){return guarded(i,async()=>{if(!i.guild)return;await i.deferReply({flags:ephemeral});await require('../../social-experience/anonymous').sendDm(i.guild,i.user.id,i.customId.slice('submundo-media-dm-submit:'.length),i.fields.getTextInputValue('content'));return i.editReply('DM anônima enviada. O destinatário pode bloquear, denunciar ou recusar novas DMs.');})}};
