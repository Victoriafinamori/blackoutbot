"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const prisma_1 = require("../../database/prisma");
const permissions_1 = require("../../utils/permissions");
const panelInteraction_1 = require("../../utils/panelInteraction");
const registrationPageAdmin_1 = require("../../utils/registrationPageAdmin");
const registrationAdmin_1 = require("../../utils/registrationAdmin");
const component = { customId: 'registration-', async execute(i) {
        if (!i.guild || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return;
        if (i.customId === 'registration-page:create') {
            const value = (key) => i.fields.getTextInputValue(key).trim(), max = Number(value('max'));
            if (!value('name') || !value('question') || !Number.isInteger(max) || max < 1 || max > 20)
                return i.reply({ content: 'Preencha nome e pergunta e use um máximo inteiro entre 1 e 20.', ephemeral: true });
            if (await prisma_1.prisma.registrationPage.count({ where: { guildId: i.guild.id } }) >= 5)
                return i.reply({ content: 'O formulário aceita até cinco páginas.', ephemeral: true });
            await (0, panelInteraction_1.deferPanel)(i);
            const page = await prisma_1.prisma.$transaction(async (tx) => { const pages = await tx.registrationPage.findMany({ where: { guildId: i.guild.id } }); if (pages.length >= 5)
                throw Error('Limite de cinco páginas atingido.'); return tx.registrationPage.create({ data: { guildId: i.guild.id, name: value('name').slice(0, 100), question: value('question').slice(0, 256), description: value('description').slice(0, 2000) || null, roleIds: '', maxChoices: max, order: Math.max(0, ...pages.map(p => p.order)) + 1 } }); });
            return (0, panelInteraction_1.refreshPanel)(i, await (0, registrationPageAdmin_1.registrationPageManagerPayload)(i.guild, page.id));
        }
        if (i.customId === 'registration-external:save') {
            const guildId = i.fields.getTextInputValue('guild').trim(), channelId = i.fields.getTextInputValue('channel').trim();
            await (0, panelInteraction_1.deferPanel)(i);
            const g = await i.client.guilds.fetch(guildId).catch(() => null), ch = g ? await g.channels.fetch(channelId).catch(() => null) : null;
            if (!ch?.isTextBased() || ch.isDMBased() || !ch.isSendable())
                return i.followUp({ content: 'O bot precisa ter acesso ao servidor e a um canal que aceite mensagens.', ephemeral: true });
            const actor = await g.members.fetch(i.user.id).catch(() => null), me = g.members.me ?? await g.members.fetchMe();
            if (!actor?.permissions.has(discord_js_1.PermissionFlagsBits.ManageGuild) && !actor?.permissions.has(discord_js_1.PermissionFlagsBits.Administrator))
                return i.followUp({ content: 'Você precisa de Gerenciar servidor ou Administrador no servidor de destino.', ephemeral: true });
            if (!ch.permissionsFor(me)?.has([discord_js_1.PermissionFlagsBits.ViewChannel, discord_js_1.PermissionFlagsBits.SendMessages, discord_js_1.PermissionFlagsBits.EmbedLinks, discord_js_1.PermissionFlagsBits.AttachFiles]))
                return i.followUp({ content: 'No destino, o bot precisa ver o canal, enviar mensagens, inserir links e anexar arquivos.', ephemeral: true });
            await prisma_1.prisma.registrationConfig.update({ where: { guildId: i.guild.id }, data: { externalGuildId: guildId, externalChannelId: channelId } });
            return (0, registrationAdmin_1.renderRegistrationAdmin)(i, 'logs');
        }
    } };
exports.default = component;
