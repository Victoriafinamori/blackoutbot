"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const permissions_1 = require("../../utils/permissions");
const moderationPanel_1 = require("../../utils/moderationPanel");
exports.default = { customId: "adm-mod-user-select:", async execute(i) {
        if (!i.guild || !i.isUserSelectMenu())
            return;
        if (!await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return i.reply({ content: "Você não possui permissão neste servidor.", ephemeral: true });
        const type = i.customId.split(":")[1], id = i.values[0];
        if (!id)
            return;
        if (type === "member" || type === "historico")
            return (0, moderationPanel_1.renderModerationMember)(i, id);
        return (0, moderationPanel_1.openModerationReason)(i, type, id);
    } };
