"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const hub_1 = require("../../games-chat/experience/hub");
exports.default = { customId: "games-select:", execute: hub_1.select };
