"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const permissions_1 = require("../../utils/permissions");
const prisma_1 = require("../../database/prisma");
const configurationChecks_1 = require("../../utils/configurationChecks");
const panelInteraction_1 = require("../../utils/panelInteraction");
const admLogsMenu_1 = require("../buttons/admLogsMenu");
const admNotifications_1 = require("../buttons/admNotifications");
const component = { customId: "adm-channel-select:", async execute(i) {
        if (!i.guild || !i.isChannelSelectMenu() || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return;
        const key = i.customId.split(":")[1];
        if (key !== "log" && key !== "reports")
            return void await i.reply({ content: "Abra a área de configuração correspondente no painel atual.", ephemeral: true });
        const id = i.values[0] ?? null;
        if (id) {
            const check = await (0, configurationChecks_1.writableChannel)(i.guild, id, key === "log");
            if (check.issue)
                return void await i.reply({ content: check.issue, ephemeral: true });
        }
        await (0, panelInteraction_1.deferPanel)(i);
        await prisma_1.prisma.guildConfig.update({ where: { guildId: i.guild.id }, data: key === "log" ? { logChannelId: id } : { reportsChannelId: id, ...(!id ? { notifyPublicWarns: false } : {}) } });
        return key === "log" ? (0, admLogsMenu_1.renderLogChannelPicker)(i, "geral", "Canal salvo.") : (0, admNotifications_1.renderNotificationPanel)(i, "moderacao", "Canal salvo.");
    } };
exports.default = component;
