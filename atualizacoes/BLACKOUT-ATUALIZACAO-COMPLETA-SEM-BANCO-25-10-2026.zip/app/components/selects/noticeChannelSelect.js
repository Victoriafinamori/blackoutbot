"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const permissions_1 = require("../../utils/permissions");
const prisma_1 = require("../../database/prisma");
const configurationChecks_1 = require("../../utils/configurationChecks");
const panelInteraction_1 = require("../../utils/panelInteraction");
const admNotifications_1 = require("../buttons/admNotifications");
const component = { customId: "notice-channel-select:", async execute(i) {
        if (!i.guild || !i.isChannelSelectMenu() || i.customId !== "notice-channel-select:moderacao")
            return;
        if (!await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return;
        const id = i.values[0] ?? null;
        if (id) {
            const check = await (0, configurationChecks_1.writableChannel)(i.guild, id, false);
            if (check.issue)
                return void await i.reply({ content: check.issue, ephemeral: true });
        }
        await (0, panelInteraction_1.deferPanel)(i);
        await prisma_1.prisma.guildConfig.update({ where: { guildId: i.guild.id }, data: { reportsChannelId: id, ...(!id ? { notifyPublicWarns: false } : {}) } });
        return (0, admNotifications_1.renderNotificationPanel)(i, "moderacao", "Canal atualizado neste painel.");
    } };
exports.default = component;
