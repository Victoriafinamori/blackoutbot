"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const prisma_1 = require("../../database/prisma");
const guildConfig_1 = require("../../database/guildConfig");
const permissions_1 = require("../../utils/permissions");
const configurationChecks_1 = require("../../utils/configurationChecks");
const panelInteraction_1 = require("../../utils/panelInteraction");
const admConfigMenu_1 = require("../buttons/admConfigMenu");
const component = { customId: "auto-role-select:", async execute(i) {
        if (!i.guild || !i.isRoleSelectMenu() || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return;
        const ids = [...new Set(i.values)];
        const issues = (0, configurationChecks_1.autoRoleIssues)(i.guild, ids);
        if (issues.length)
            return (0, admConfigMenu_1.renderAutoRoleMenu)(i, "A seleção não foi salva. " + issues.join(" "));
        await (0, panelInteraction_1.deferPanel)(i);
        await (0, guildConfig_1.getOrCreateGuildConfig)(i.guild.id);
        await prisma_1.prisma.guildConfig.update({ where: { guildId: i.guild.id }, data: { autoRoleIds: ids.length ? ids.join(",") : null, ...(!ids.length ? { autoRoleEnabled: false } : {}) } });
        return (0, admConfigMenu_1.renderAutoRoleMenu)(i, "Cargos salvos. A seleção atual já aparece neste painel.");
    } };
exports.default = component;
