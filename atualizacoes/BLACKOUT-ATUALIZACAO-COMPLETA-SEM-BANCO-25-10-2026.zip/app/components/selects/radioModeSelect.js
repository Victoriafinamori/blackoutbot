"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const permissions_1 = require("../../utils/permissions");
const component = { customId: 'radio-mode-select', async execute(i) {
        if (!i.guild || !i.isStringSelectMenu() || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return;
        if (!['SEQUENTIAL', 'RANDOM'].includes(i.values[0]))
            return;
        await i.deferUpdate();
        await require('../../../app/radio/service').setRadioMode(i.guild.id, i.values[0]);
        await i.editReply(await require('../../../app/components/buttons/admRadioMenu').buildRadioMainView(i.guild));
    } };
exports.default = component;
