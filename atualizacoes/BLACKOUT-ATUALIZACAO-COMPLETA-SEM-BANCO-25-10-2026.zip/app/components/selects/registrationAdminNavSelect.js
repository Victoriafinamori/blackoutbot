"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderRegistrationGeneral = renderRegistrationGeneral;
const permissions_1 = require("../../utils/permissions");
const admPanel_1 = require("../../utils/admPanel");
const panelInteraction_1 = require("../../utils/panelInteraction");
const registrationAdmin_1 = require("../../utils/registrationAdmin");
async function renderRegistrationGeneral(i) { return (0, registrationAdmin_1.renderRegistrationAdmin)(i, 'logs'); }
const component = { customId: 'registration-admin-nav', async execute(i) {
        if (!i.guild || !i.isStringSelectMenu() || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return;
        const value = i.values[0];
        if (value === 'back')
            return (0, panelInteraction_1.refreshPanel)(i, await (0, admPanel_1.buildAdmSectionPanel)(i.guild, 'membros'));
        if (!['general', 'pages', 'embed', 'auto', 'welcome', 'tools', 'team', 'logs', 'publication', 'home'].includes(value))
            return;
        await (0, panelInteraction_1.deferPanel)(i);
        return (0, registrationAdmin_1.renderRegistrationAdmin)(i, value);
    } };
exports.default = component;
