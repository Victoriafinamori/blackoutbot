"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const interactions_1 = require("../../message-maker/interactions");
exports.default = { customId: "maker-select:", execute: interactions_1.execute };
