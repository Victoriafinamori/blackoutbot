"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const permissions_1 = require("../../utils/permissions");
const customEmbeds_1 = require("../../utils/customEmbeds");
const admEmbedV2Menu_1 = require("../buttons/admEmbedV2Menu");
const component = { customId: "embedv2-edit-select:", async execute(i) {
        if (!i.guild || !i.isStringSelectMenu() || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return;
        if (!["text", "visual", "buttons", "destination"].includes(i.values[0]))
            return;
        const record = await (0, customEmbeds_1.fetchCustomEmbed)(i.customId.split(":")[1], i.guild.id);
        if (!record)
            return void await i.reply({ content: "Mensagem não encontrada neste servidor.", ephemeral: true });
        return (0, admEmbedV2Menu_1.openEmbedPart)(i, record, i.values[0]);
    } };
exports.default = component;
