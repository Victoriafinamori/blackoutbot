"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const permissions_1 = require("../../utils/permissions");
const panelInteraction_1 = require("../../utils/panelInteraction");
const config_1 = require("../../logging/config");
const delivery_1 = require("../../logging/delivery");
const panel_1 = require("../../logging/panel");
exports.default = { customId: "logs-center-select:", async execute(i) {
        if (!i.guild || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return i.reply({ content: "Você não possui permissão neste servidor.", ephemeral: true });
        const [, action, arg] = i.customId.split(":"), values = i.values ?? [];
        if (action === "channel-group" && values[0] === "bot" && (arg === "local" || arg === "external")) {
            await (0, panelInteraction_1.deferPanel)(i);
            return (0, panel_1.renderLogOrganization)(i, arg, "bot");
        }
        if (action === "channel-group" && arg === "external") {
            if (!config_1.LOG_GROUPS[values[0]])
                return;
            const s = await (0, config_1.readLogSettings)(i.guild.id);
            if (!s.externalGuildId)
                return i.reply({ content: "Configure primeiro o servidor externo em Onde enviar.", ephemeral: true });
            return (0, panel_1.externalModal)(i, values[0]);
        }
        await (0, panelInteraction_1.deferPanel)(i);
        const s = await (0, config_1.readLogSettings)(i.guild.id, true);
        try {
            if (action === "group")
                return (0, panel_1.renderLogEvents)(i, values[0]);
            if (action === "events") {
                const groups = (0, panel_1.logEventGroups)(arg);
                if (!groups.length || values.some(id => !config_1.LOG_EVENTS[id] || !groups.includes(config_1.LOG_EVENTS[id].group)))
                    return;
                const events = { ...s.events };
                for (const [key, v] of Object.entries(config_1.LOG_EVENTS))
                    if (groups.includes(v.group))
                        events[key] = values.includes(key);
                await (0, config_1.saveLogSettings)(i.guild.id, { eventsJson: JSON.stringify(events) });
                return (0, panel_1.renderLogEvents)(i, arg, "Eventos salvos neste servidor.");
            }
            if (action === "mode") {
                const mode = values[0];
                if (!["LOCAL", "EXTERNAL", "BOTH"].includes(mode))
                    return;
                if (mode !== "LOCAL") {
                    await (0, delivery_1.validateExternal)(i.guild, s, i.user.id);
                    await (0, config_1.saveLogSettings)(i.guild.id, { deliveryMode: mode, externalAuthorizedBy: i.user.id });
                }
                else
                    await (0, config_1.saveLogSettings)(i.guild.id, { deliveryMode: mode });
                return (0, panel_1.renderLogDestination)(i, "Modo de envio salvo. As mensagens antigas permanecem nos destinos anteriores.");
            }
            if (action === "channel-group" && arg === "local")
                return (0, panel_1.renderLocalGroup)(i, values[0]);
            if (action === "local-channel") {
                if (!config_1.LOG_GROUPS[arg])
                    return;
                if (values[0])
                    await (0, delivery_1.usableLogChannel)(i.guild, values[0]);
                await (0, config_1.saveLogSettings)(i.guild.id, { localChannelsJson: JSON.stringify({ ...s.localChannels, [arg]: values[0] ?? null }) });
                return (0, panel_1.renderLocalGroup)(i, arg, "Canal salvo neste servidor.");
            }
            if (action === "ignored-channels") {
                if (values.length > 25)
                    throw Error("Selecione até 25 canais.");
                for (const id of values) {
                    const ch = await i.guild.channels.fetch(id).catch(() => null);
                    if (!ch || ch.guildId !== i.guild.id)
                        throw Error("Escolha canais ou categorias deste servidor.");
                }
                await (0, config_1.saveLogSettings)(i.guild.id, { ignoredChannelIds: JSON.stringify(values) });
                return (0, panel_1.renderLogFilters)(i, "Canais ignorados atualizados.");
            }
            if (action === "ignored-roles") {
                if (values.length > 25 || values.some(id => id === i.guild.id || !i.guild.roles.cache.has(id)))
                    throw Error("Escolha até 25 cargos específicos deste servidor.");
                await (0, config_1.saveLogSettings)(i.guild.id, { ignoredRoleIds: JSON.stringify(values) });
                return (0, panel_1.renderLogFilters)(i, "Cargos ignorados atualizados.");
            }
        }
        catch (error) {
            return i.followUp({ content: error.message || "Não foi possível salvar. Confira os destinos e tente novamente.", ephemeral: true });
        }
    } };
