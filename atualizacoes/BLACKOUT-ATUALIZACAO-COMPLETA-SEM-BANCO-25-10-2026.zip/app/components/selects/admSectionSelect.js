"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const permissions_1 = require("../../utils/permissions");
const admPanel_1 = require("../../utils/admPanel");
const admAdminMenu_1 = require("../buttons/admAdminMenu");
const admConfigMenu_1 = require("../buttons/admConfigMenu");
const admReintegrationMenu_1 = require("../buttons/admReintegrationMenu");
const admModerationMenu_1 = require("../buttons/admModerationMenu");
const admLogsMenu_1 = require("../buttons/admLogsMenu");
const admStatsMenu_1 = require("../buttons/admStatsMenu");
const admMovCallMenu_1 = require("../buttons/admMovCallMenu");
const admFamiliasMenu_1 = require("../buttons/admFamiliasMenu");
const admTicketsMenu_1 = require("../buttons/admTicketsMenu");
const admRegistrationMenu_1 = require("../buttons/admRegistrationMenu");
const admCleanupMenu_1 = require("../buttons/admCleanupMenu");
const admMovMenu_1 = require("../buttons/admMovMenu");
const admEventsMenu_1 = require("../buttons/admEventsMenu");
const admGamesChatMenu_1 = require("../buttons/admGamesChatMenu");
const admServerFeedbackMenu_1 = require("../buttons/admServerFeedbackMenu");
const admFreeFireMenu_1 = require("../buttons/admFreeFireMenu");
const admBingoMenu_1 = require("../buttons/admBingoMenu");
const admDenunciasMenu_1 = require("../buttons/admDenunciasMenu");
const admPartnershipsMenu_1 = require("../buttons/admPartnershipsMenu");
const panel_1 = require("../../memberRise/panel");
const component = { customId: "adm-section-select:", async execute(i) {
        if (!i.guild || !i.isStringSelectMenu())
            return;
        if (!(await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id))))
            return void await i.reply({ content: "Você não possui permissão.", ephemeral: true });
        const value = i.values[0];
        const area = (0, admPanel_1.resolveAdmSection)(i.customId.slice("adm-section-select:".length));
        if (!area)
            return;
        // Keep legacy back values and old module placements usable on existing messages.
        const legacyValues = ["configuracoes", "registro", "reintegracao", "subidamembros", "sorteios", "cfg:canais", "cfg:autocargo", "cfg:notificacoes"];
        if (value !== "back" && !admPanel_1.ADM_SECTIONS[area].modules.some(module => module.value === value) && !legacyValues.includes(value))
            return;
        if (value.startsWith("cfg:"))
            return (0, admConfigMenu_1.renderConfigDestination)(i, value.slice(4));
        if (value === "back")
            return void await i.update(await (0, admPanel_1.buildAdmRootPanel)(i.guild, i.user));
        if (value === "protecao")
            return require("../../security/interactions").open(i);
        if (value === "administracao")
            return (0, admAdminMenu_1.renderAdminMenu)(i);
        if (value === "moderacao")
            return (0, admModerationMenu_1.renderModerationMenu)(i);
        if (value === "reintegracao")
            return (0, admReintegrationMenu_1.renderReintegrationMenu)(i);
        if (value === "logs")
            return (0, admLogsMenu_1.renderLogsMenu)(i);
        if (value === "tickets")
            return (0, admTicketsMenu_1.renderTicketsMenu)(i);
        if (value === "registro")
            return (0, admRegistrationMenu_1.renderRegistrationMenu)(i);
        if (value === "eventos")
            return (0, admEventsMenu_1.renderEventsMenu)(i);
        if (value === "gameschat")
            return (0, admGamesChatMenu_1.renderGamesChatMenu)(i);
        if (value === "estatisticas")
            return (0, admStatsMenu_1.renderStatsMenu)(i);
        if (value === "movchat")
            return (0, admMovMenu_1.renderMovMenu)(i);
        if (value === "movcall")
            return (0, admMovCallMenu_1.renderMovCallRoot)(i);
        if (value === "limpa")
            return (0, admCleanupMenu_1.renderCleanupMenu)(i);
        if (value === "familias")
            return (0, admFamiliasMenu_1.renderFamiliasMenu)(i);
        if (value === "configuracoes")
            return (0, admConfigMenu_1.renderConfigMenu)(i);
        if (value === "feedbackservidor")
            return (0, admServerFeedbackMenu_1.renderServerFeedbackMenu)(i);
        if (value === "freefire")
            return (0, admFreeFireMenu_1.renderFreeFireMenu)(i);
        if (value === "bingo")
            return (0, admBingoMenu_1.renderBingoMenu)(i);
        if (value === "subidamembros")
            return (0, panel_1.renderMemberRise)(i);
        if (value === "denuncias")
            return (0, admDenunciasMenu_1.renderDenunciasMenu)(i);
        if (value === "parcerias")
            return (0, admPartnershipsMenu_1.renderPartnershipsMenu)(i);
  if (value === "dinamicassociais") return require("../../../app/social-experience/interactions").showAdmin(i,"dynamics");
        // These production modules currently exist only in app/.
        if (value === "social")
            return require("../../../app/components/buttons/socialAdminButtons").renderSocialAdmin(i);
        if (value === "submundo")
            return require("../../../app/components/buttons/admSubmundoMenu").renderSubmundoMenu(i);
        if (value === "radio24h")
            return require("../../../app/components/buttons/admRadioMenu").renderRadioMenu(i);
        if (value === "sorteios")
            return require("../../../app/components/buttons/giveawayAdminButtons").renderGiveawayAdmin(i);
    } };
exports.default = component;
