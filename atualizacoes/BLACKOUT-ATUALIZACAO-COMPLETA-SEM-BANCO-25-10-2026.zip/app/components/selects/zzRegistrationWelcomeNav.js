"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const registrationAdminNavSelect_1 = __importDefault(require("./registrationAdminNavSelect"));
const registrationWelcome_1 = require("../../utils/registrationWelcome");
const component = { customId: "registration-admin-nav", async execute(i) {
        return registrationAdminNavSelect_1.default.execute(i);
    } };
exports.default = component;
//# sourceMappingURL=zzRegistrationWelcomeNav.js.map