"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const adminTasks_1 = require("../../utils/adminTasks");
const component = { customId: 'admin-task:', async execute(i) {
        if (!i.isStringSelectMenu())
            return;
        await (0, adminTasks_1.dispatchAdminTask)(i, i.customId.slice('admin-task:'.length), i.values[0]);
    } };
exports.default = component;
