"use strict";
exports.default = {
  customId: "sx-select:",
  execute: (i) => require("../../social-experience/interactions").select(i),
};
