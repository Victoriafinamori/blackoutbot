"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const permissions_1 = require("../../utils/permissions");
const prisma_1 = require("../../database/prisma");
const panelInteraction_1 = require("../../utils/panelInteraction");
const adminLog_1 = require("../../utils/adminLog");
const enums_1 = require("../../structures/enums");
const admModerationMenu_1 = require("../buttons/admModerationMenu");
exports.default = { customId: "adm-automod-select", async execute(i) {
        if (!i.guild || !i.isStringSelectMenu() || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return;
        const action = i.values[0];
        if (!Object.values(enums_1.AutoModAction).includes(action))
            return;
        await (0, panelInteraction_1.deferPanel)(i);
        await prisma_1.prisma.guildConfig.update({ where: { guildId: i.guild.id }, data: { autoModAction: action } });
        await (0, adminLog_1.logAdminAction)({ guild: i.guild, actorId: i.user.id, action: enums_1.AdminLogAction.MODERATION_CONFIG_CHANGED, details: `Resposta automática: ${action}` });
        return (0, admModerationMenu_1.renderFiltersLimits)(i);
    } };
