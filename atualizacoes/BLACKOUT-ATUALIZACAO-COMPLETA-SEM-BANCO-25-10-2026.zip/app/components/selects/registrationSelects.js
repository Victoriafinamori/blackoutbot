"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const prisma_1 = require("../../database/prisma");
const permissions_1 = require("../../utils/permissions");
const registrationPageAdmin_1 = require("../../utils/registrationPageAdmin");
const registrationSettings_1 = require("../../utils/registrationSettings");
const registration_1 = require("../../utils/registration");
const tickets_1 = require("../../utils/tickets");
const panelInteraction_1 = require("../../utils/panelInteraction");
const component = { customId: 'registration-', async execute(i) {
        if (!i.guild || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return;
        if (i.customId === 'registration-manage-page') {
            await (0, panelInteraction_1.deferPanel)(i);
            return (0, panelInteraction_1.refreshPanel)(i, await (0, registrationPageAdmin_1.registrationPageManagerPayload)(i.guild, i.values[0]));
        }
        if (/^registration-page-(roles|addroles|removeroles):/.test(i.customId)) {
            const page = await prisma_1.prisma.registrationPage.findFirst({ where: { id: i.customId.split(':')[1], guildId: i.guild.id } });
            if (!page)
                return i.reply({ content: 'Página não encontrada neste servidor.', ephemeral: true });
            const mode = i.customId.split(':')[0], current = (0, tickets_1.ids)(page.roleIds), values = mode === 'registration-page-removeroles' ? current.filter(id => !i.values.includes(id)) : mode === 'registration-page-addroles' ? [...new Set([...current, ...i.values])] : i.values;
            const error = await (0, registrationSettings_1.registrationRoleError)(i.guild, values, true);
            if (error)
                return i.reply({ content: error, ephemeral: true });
            const c = await (0, registration_1.regConfig)(i.guild.id);
            if (values.some((id) => (0, tickets_1.ids)(c.unregisteredRoleIds).includes(id)))
                return i.reply({ content: 'Estes cargos seriam removidos na conclusão. Revise Cargos após registro antes de adicioná-los ao formulário.', ephemeral: true });
            await (0, panelInteraction_1.deferPanel)(i);
            await prisma_1.prisma.registrationPage.update({ where: { id: page.id }, data: { roleIds: values.join(',') } });
            return (0, panelInteraction_1.refreshPanel)(i, await (0, registrationPageAdmin_1.registrationPageManagerPayload)(i.guild, page.id));
        }
        if (i.customId.startsWith('registration-role:') || i.customId.startsWith('registration-channel:'))
            return (0, registrationSettings_1.updateRegistrationSelection)(i);
    } };
exports.default = component;
