"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const permissions_1 = require("../../utils/permissions");
const admPanel_1 = require("../../utils/admPanel");
const service_1 = require("../../ff/service");
const admFreeFireMenu_1 = require("../buttons/admFreeFireMenu");
const component = {
    customId: "ff-admin-nav",
    async execute(i) {
        if (!i.guild || !i.isStringSelectMenu())
            return;
        if (!(await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))) {
            await i.reply({ content: "🚫 Sem permissão.", ephemeral: true });
            return;
        }
        const value = i.values[0];
        if (value === "back")
            return void (await i.update(await (0, admPanel_1.buildAdmSectionPanel)(i.guild, "staff")));
        if (value === "status")
            return (0, admFreeFireMenu_1.renderFreeFireStatus)(i);
        if (value === "channels")
            return (0, admFreeFireMenu_1.renderFreeFireChannels)(i);
        if (value === "panels")
            return (0, admFreeFireMenu_1.renderFreeFirePanels)(i);
        if (value === "list")
            return (0, admFreeFireMenu_1.renderFreeFireList)(i);
        if (value === "rules") {
            const c = await (0, service_1.getFFConfig)(i.guild.id);
            await i.showModal((0, admFreeFireMenu_1.buildFreeFireRulesModal)(c));
            return;
        }
        if (value === "reset") {
            return void (await i.update({
                embeds: [],
                components: [
                    new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-ff:reset-confirm").setLabel("Confirmar reset das inscrições").setStyle(discord_js_1.ButtonStyle.Danger), new discord_js_1.ButtonBuilder().setCustomId("adm-ff:menu").setLabel("Cancelar").setStyle(discord_js_1.ButtonStyle.Secondary)),
                ],
            }));
        }
    },
};
exports.default = component;
//# sourceMappingURL=ffAdminNavSelect.js.map