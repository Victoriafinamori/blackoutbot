"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const config_1 = require("../../logging/config");
const permissions_1 = require("../../utils/permissions");
const prisma_1 = require("../../database/prisma");
const configurationChecks_1 = require("../../utils/configurationChecks");
const panelInteraction_1 = require("../../utils/panelInteraction");
const admLogsMenu_1 = require("../buttons/admLogsMenu");
const component = { customId: "adm-logchannel-select:", async execute(i) {
        if (!i.guild || !i.isChannelSelectMenu() || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return;
        const key = i.customId.split(":")[1], field = admLogsMenu_1.LOG_CHANNEL_FIELDS[key];
        if (!field)
            return;
        const id = i.values[0] ?? null;
        if (id) {
            const check = await (0, configurationChecks_1.writableChannel)(i.guild, id);
            if (check.issue)
                return void await i.reply({ content: check.issue, ephemeral: true });
        }
        await (0, panelInteraction_1.deferPanel)(i);
        await prisma_1.prisma.guildConfig.update({ where: { guildId: i.guild.id }, data: { [field.column]: id } });
        if (key !== "geral") {
            const groups = { moderacao: "moderation", seguranca: "security", reintegracao: "reintegration", sistema: "system" };
            const settings = await (0, config_1.readLogSettings)(i.guild.id, true);
            await (0, config_1.saveLogSettings)(i.guild.id, { localChannelsJson: JSON.stringify({ ...settings.localChannels, [groups[key]]: id }) });
        }
        return (0, admLogsMenu_1.renderLogChannelPicker)(i, key, "Canal salvo neste servidor.");
    } };
exports.default = component;
