"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const prisma_1 = require("../../database/prisma");
const permissions_1 = require("../../utils/permissions");
const registrationSettings_1 = require("../../utils/registrationSettings");
const partnershipSettings_1 = require("../../utils/partnershipSettings");
const panelInteraction_1 = require("../../utils/panelInteraction");
const component = { customId: 'parceria-admin-select:', async execute(i) {
        if (!i.guild || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return;
        const a = i.customId.split(':')[1], keys = { panel: 'panelChannelId', category: 'categoryId', logs: 'logChannelId', publish: 'publishChannelId', staff: 'staffRoleIds', partner: 'partnerRoleId' };
        if (!keys[a])
            return;
        if (['staff', 'partner'].includes(a)) {
            const error = await (0, registrationSettings_1.registrationRoleError)(i.guild, i.values, a === 'partner');
            if (error)
                return i.reply({ content: error, ephemeral: true });
        }
        else if (i.values[0]) {
            const c = await i.guild.channels.fetch(i.values[0]).catch(() => null);
            if (!c || c.guild.id !== i.guild.id || c.type !== (a === 'category' ? discord_js_1.ChannelType.GuildCategory : discord_js_1.ChannelType.GuildText))
                return i.reply({ content: 'Escolha um canal válido deste servidor.', ephemeral: true });
            if (a !== 'category' && !c.permissionsFor(i.guild.members.me)?.has([discord_js_1.PermissionFlagsBits.ViewChannel, discord_js_1.PermissionFlagsBits.SendMessages, discord_js_1.PermissionFlagsBits.EmbedLinks]))
                return i.reply({ content: 'O bot precisa ver o canal, enviar mensagens e inserir links/embeds.', ephemeral: true });
        }
        await (0, panelInteraction_1.deferPanel)(i);
        await prisma_1.prisma.partnershipConfig.update({ where: { guildId: i.guild.id }, data: { [keys[a]]: a === 'staff' ? JSON.stringify(i.values) : i.values[0] || null } });
        return (0, panelInteraction_1.refreshPanel)(i, await (0, partnershipSettings_1.partnershipSettingsPayload)(i.guild, ['staff', 'partner'].includes(a) ? 'roles' : 'channels'));
    } };
exports.default = component;
