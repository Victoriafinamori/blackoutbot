"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const permissions_1 = require("../../utils/permissions");
const admPanel_1 = require("../../utils/admPanel");
const component = {
    customId: "adm-panel-select",
    async execute(i) {
        if (!i.guild || !i.isStringSelectMenu())
            return;
        if (!await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id))) {
            await i.reply({ content: "Você não possui permissão para acessar o painel administrativo.", ephemeral: true });
            return;
        }
        const section = (0, admPanel_1.resolveAdmSection)(i.values[0]);
        if (!section)
            return;
        await i.update(await (0, admPanel_1.buildAdmSectionPanel)(i.guild, section));
    },
};
exports.default = component;
