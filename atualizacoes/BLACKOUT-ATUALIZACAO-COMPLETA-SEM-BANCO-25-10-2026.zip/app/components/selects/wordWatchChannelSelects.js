"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const panelInteraction_1 = require("../../utils/panelInteraction");
const permissions_1 = require("../../utils/permissions");
const adminLog_1 = require("../../utils/adminLog");
const enums_1 = require("../../structures/enums");
const wordWatch_1 = require("../../utils/wordWatch");
const admModerationMenu_1 = require("../buttons/admModerationMenu");
const component = {
    customId: "adm-watchchannel-select",
    async execute(interaction) {
        if (!interaction.guild || !interaction.isChannelSelectMenu())
            return;
        const member = await interaction.guild.members.fetch(interaction.user.id);
        if (!(await (0, permissions_1.isBotAdmin)(member))) {
            await interaction.reply({ content: "🚫 Você não tem permissão para realizar esta ação.", ephemeral: true });
            return;
        }
        const channelIds = interaction.values.slice(0, wordWatch_1.MAX_WORD_WATCH_CHANNELS);
        for (const id of channelIds) {
            const channel = await interaction.guild.channels.fetch(id).catch(() => null);
            if (!channel || channel.guildId !== interaction.guild.id || channel.type !== 0) {
                await interaction.reply({ content: "Escolha canais de texto deste servidor.", ephemeral: true });
                return;
            }
        }
        await (0, panelInteraction_1.deferPanel)(interaction);
        await (0, wordWatch_1.setWordWatchChannelIds)(interaction.guild.id, channelIds);
        await (0, adminLog_1.logAdminAction)({
            guild: interaction.guild,
            actorId: interaction.user.id,
            action: enums_1.AdminLogAction.MODERATION_CONFIG_CHANGED,
            details: channelIds.length
                ? `Canais monitorados (Monitoramento de Palavras): ${channelIds.map((id) => `<#${id}>`).join(", ")}`
                : "Canais monitorados (Monitoramento de Palavras) limpos.",
        });
        await (0, admModerationMenu_1.renderFiltersWordWatch)(interaction);
    },
};
exports.default = component;
