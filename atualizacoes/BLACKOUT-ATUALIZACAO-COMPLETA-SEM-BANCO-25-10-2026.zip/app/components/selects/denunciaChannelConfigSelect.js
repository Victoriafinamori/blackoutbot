"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const prisma_1 = require("../../database/prisma");
const permissions_1 = require("../../utils/permissions");
const allowed = new Set(["categoryId", "panelChannelId", "logChannelId"]);
const component = { customId: "denuncia-channel:", async execute(i) {
    if (!i.guild || !(await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))) return;
    const key = i.customId.split(":")[1];
    if (!allowed.has(key)) return void await i.reply({ content: "Configuração de canal inválida.", flags: discord_js_1.MessageFlags.Ephemeral });
    await prisma_1.prisma.reportConfig.upsert({ where: { guildId: i.guild.id }, create: { guildId: i.guild.id, [key]: i.values[0] || null }, update: { [key]: i.values[0] || null } });
    return require("../buttons/admDenunciasMenu").renderDenunciasChannels(i);
} };
exports.default = component;
