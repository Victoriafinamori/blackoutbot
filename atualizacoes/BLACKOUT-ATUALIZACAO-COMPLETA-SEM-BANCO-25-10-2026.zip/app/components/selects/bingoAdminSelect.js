"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const permissions_1 = require("../../utils/permissions");
const admPanel_1 = require("../../utils/admPanel");
const service_1 = require("../../bingo/service");
const views_1 = require("../../bingo/views");
const admBingoMenu_1 = require("../buttons/admBingoMenu");
const nav = {
    customId: "bingo-admin-nav",
    async execute(i) {
        if (!i.guild || !i.isStringSelectMenu())
            return;
        if (!(await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))) {
            await i.reply({ content: "🚫 Sem permissão.", ephemeral: true });
            return;
        }
        const value = i.values[0];
        if (value === "back")
            return void (await i.update(await (0, admPanel_1.buildAdmSectionPanel)(i.guild, "staff")));
        if (value === "start")
            return (0, admBingoMenu_1.renderBingoStart)(i);
        if (value === "cards")
            return (0, admBingoMenu_1.renderBingoCardsChannel)(i);
        if (value === "end")
            return (0, admBingoMenu_1.renderBingoEndConfirm)(i);
        if (value === "toggle") {
            const match = await (0, service_1.getCurrentMatch)(i.guild.id);
            if (!match)
                return (0, admBingoMenu_1.renderBingoMenu)(i);
            if (match.status === "PAUSADA")
                await (0, service_1.resumeMatch)(match.id);
            else
                await (0, service_1.pauseMatch)(match.id);
            await (0, views_1.refreshMatchPanel)(i.guild);
            return (0, admBingoMenu_1.renderBingoMenu)(i);
        }
    },
};
const startChannel = {
    customId: "bingo-admin-start-channel",
    async execute(i) {
        if (!i.guild || !i.isChannelSelectMenu())
            return;
        if (!(await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))) {
            await i.reply({ content: "🚫 Sem permissão.", ephemeral: true });
            return;
        }
        const existing = await (0, service_1.getCurrentMatch)(i.guild.id);
        if (existing) {
            await i.reply({ content: `❌ Já existe uma partida em andamento (**PARTIDA #${String(existing.number).padStart(3, "0")}**). Encerre-a antes de iniciar outra.`, ephemeral: true });
            return;
        }
        const channelId = i.values[0];
        const channel = await i.guild.channels.fetch(channelId).catch(() => null);
        if (!channel?.isTextBased() || channel.isDMBased()) {
            await i.reply({ content: "❌ Canal inválido.", ephemeral: true });
            return;
        }
        const match = await (0, service_1.createMatch)(i.guild.id, channelId, i.user.id);
        const draws = await (0, service_1.getDraws)(match.id);
        const message = await channel.send((0, views_1.buildBingoPanel)(match, draws));
        await (0, service_1.setMatchMessage)(match.id, message.id);
        await (0, admBingoMenu_1.renderBingoMenu)(i);
    },
};
const cardsChannel = {
    customId: "bingo-admin-cards-channel",
    async execute(i) {
        if (!i.guild || !i.isChannelSelectMenu())
            return;
        if (!(await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))) {
            await i.reply({ content: "🚫 Sem permissão.", ephemeral: true });
            return;
        }
        try {
            await (0, views_1.publishCardPanel)(i.guild, i.values[0]);
        }
        catch (error) {
            await i.reply({ content: `❌ ${error instanceof Error ? error.message : "Não foi possível publicar o painel."}`, ephemeral: true });
            return;
        }
        await (0, admBingoMenu_1.renderBingoMenu)(i);
    },
};
const cardsCategory = {
    customId: "bingo-admin-cards-category",
    async execute(i) {
        if (!i.guild || !i.isChannelSelectMenu())
            return;
        if (!(await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))) {
            await i.reply({ content: "🚫 Sem permissão.", ephemeral: true });
            return;
        }
        const categoryId = i.values[0];
        const category = await i.guild.channels.fetch(categoryId).catch(() => null);
        if (!category || category.type !== discord_js_1.ChannelType.GuildCategory) {
            await i.reply({ content: "❌ Selecione uma categoria válida.", ephemeral: true });
            return;
        }
        await (0, service_1.updateBingoConfig)(i.guild.id, { cardTicketCategoryId: categoryId });
        await (0, admBingoMenu_1.renderBingoCardsChannel)(i);
    },
};
const handlers = {
    "bingo-admin-nav": nav,
    "bingo-admin-start-channel": startChannel,
    "bingo-admin-cards-channel": cardsChannel,
    "bingo-admin-cards-category": cardsCategory,
};
const component = {
    customId: "bingo-admin-",
    async execute(i) {
        const handler = handlers[i.customId];
        if (handler)
            await handler.execute(i);
    },
};
exports.default = component;
//# sourceMappingURL=bingoAdminSelect.js.map