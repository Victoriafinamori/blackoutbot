"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const prisma_1 = require("../../database/prisma");
const permissions_1 = require("../../utils/permissions");
const component = { customId: "denuncia-role:", async execute(i) {
    if (!i.guild || !(await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))) return;
    const key = i.customId.split(":")[1];
    if (key !== "staffRoleIds") return void await i.reply({ content: "Configuração de cargo inválida.", flags: discord_js_1.MessageFlags.Ephemeral });
    await prisma_1.prisma.reportConfig.upsert({ where: { guildId: i.guild.id }, create: { guildId: i.guild.id, staffRoleIds: i.values.join(",") || null }, update: { staffRoleIds: i.values.join(",") || null } });
    return require("../buttons/admDenunciasMenu").renderDenunciasRoles(i);
} };
exports.default = component;
