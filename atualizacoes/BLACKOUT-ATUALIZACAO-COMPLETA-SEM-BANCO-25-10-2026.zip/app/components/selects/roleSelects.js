const admAdminMenu_1 = require("../buttons/admAdminMenu");
const panelInteraction_1 = require("../../utils/panelInteraction");
const teamRoles_1 = require("../../utils/teamRoles");
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const permissions_1 = require("../../utils/permissions");
const embeds_1 = require("../../utils/embeds");
const roleSync_1 = require("../../utils/roleSync");
const reintegration_1 = require("../../utils/reintegration");
const enums_1 = require("../../structures/enums");
const admReintegrationMenu_1 = require("../buttons/admReintegrationMenu");
const movCallStats_1 = require("../../utils/movCallStats");
const admMovCallMenu_1 = require("../buttons/admMovCallMenu");
const adminLog_1 = require("../../utils/adminLog");
const families_1 = require("../../utils/families");
const admFamiliasMenu_1 = require("../buttons/admFamiliasMenu");
const roleTransfer_1 = require("../../utils/roleTransfer");
const admRoleTransferMenu_1 = require("../buttons/admRoleTransferMenu");
async function handleBotAdmin(i) {
    const issue = (0, teamRoles_1.selectedRoleIssue)(i.guild, i.values);
    if (issue)
        return void await i.reply({ content: issue, ephemeral: true });
    await (0, panelInteraction_1.deferPanel)(i);
    await (0, roleSync_1.syncBotAdminRoles)(i.guild, i.user.id, i.values);
    await (0, admAdminMenu_1.renderBotAdmin)(i, "Cargos salvos neste servidor.");
}
async function handlePermRole(i, type) {
    if (!admAdminMenu_1.PERMISSION_LABELS[type])
        return;
    const issue = (0, teamRoles_1.selectedRoleIssue)(i.guild, i.values);
    if (issue)
        return void await i.reply({ content: issue, ephemeral: true });
    await (0, panelInteraction_1.deferPanel)(i);
    await (0, roleSync_1.syncPermissionRoles)(i.guild, i.user.id, type, i.values);
    await (0, admAdminMenu_1.renderPermRoleType)(i, type, "Permissão salva neste servidor.");
}
async function handleSysRole(i, type) {
    if (!admAdminMenu_1.SYSTEM_ROLE_LABELS[type])
        return;
    const issue = (0, teamRoles_1.selectedRoleIssue)(i.guild, i.values, true);
    if (issue)
        return void await i.reply({ content: issue, ephemeral: true });
    await (0, panelInteraction_1.deferPanel)(i);
    await (0, roleSync_1.setSystemRole)(i.guild, i.user.id, type, i.values[0] ?? null);
    await (0, admAdminMenu_1.renderSysRoleType)(i, type, "Associação salva neste servidor.");
}
async function handleStageRole(interaction, stageId) {
    const newRoleId = interaction.values[0] ?? null;
    await (0, reintegration_1.setStageRole)(interaction.guild, interaction.user.id, stageId, newRoleId);
    await (0, admReintegrationMenu_1.renderStageDetail)(interaction, stageId);
}
async function handleMovCallPermRole(interaction) {
    await (0, roleSync_1.syncPermissionRoles)(interaction.guild, interaction.user.id, enums_1.PermissionType.MOVCALL_COMMANDS, interaction.values);
    await (0, admMovCallMenu_1.renderMovCallConfigMenu)(interaction);
}
async function handleMovCallTop1Role(interaction) {
    const newRoleId = interaction.values[0] ?? null;
    await (0, movCallStats_1.setMovCallTop1Role)(interaction.guild, interaction.user.id, newRoleId);
    await (0, admMovCallMenu_1.renderMovCallTopCallMenu)(interaction);
}
async function handleMovCallRewardAdd(interaction) {
    const roleId = interaction.values[0];
    if (!roleId)
        return;
    const modal = new discord_js_1.ModalBuilder()
        .setCustomId(`adm-modal:movcallreward:${roleId}`)
        .setTitle("Recompensa por Tempo");
    const hoursInput = new discord_js_1.TextInputBuilder()
        .setCustomId("minHours")
        .setLabel("Tempo mínimo em call (horas)")
        .setPlaceholder("Ex: 10")
        .setStyle(discord_js_1.TextInputStyle.Short)
        .setRequired(true)
        .setMaxLength(5);
    modal.addComponents(new discord_js_1.ActionRowBuilder().addComponents(hoursInput));
    await interaction.showModal(modal);
}
async function handleMovCallRewardRemove(interaction) {
    const roleId = interaction.values[0];
    if (!roleId)
        return;
    const rewards = await (0, movCallStats_1.getMovCallRewards)(interaction.guild.id);
    const existing = rewards.find((r) => r.roleId === roleId);
    if (!existing) {
        await interaction.reply({ content: "⚠️ Esse cargo não tem nenhuma recompensa cadastrada.", ephemeral: true });
        return;
    }
    await (0, movCallStats_1.removeMovCallReward)(interaction.guild.id, roleId);
    await (0, adminLog_1.logAdminAction)({
        guild: interaction.guild,
        actorId: interaction.user.id,
        action: enums_1.AdminLogAction.MOVCALL_REWARD_REMOVED,
        details: `Recompensa removida: <@&${roleId}> (${existing.minHours}h)`,
    });
    await (0, admMovCallMenu_1.renderRewardsMenu)(interaction);
}
async function handleAvisosRole(interaction) {
    const roleId = interaction.values[0];
    if (!roleId)
        return;
    const modal = new discord_js_1.ModalBuilder()
        .setCustomId(`adm-modal:aviso:${roleId}`)
        .setTitle("Enviar Aviso por Cargo");
    const messageInput = new discord_js_1.TextInputBuilder()
        .setCustomId("message")
        .setLabel("Mensagem do aviso")
        .setStyle(discord_js_1.TextInputStyle.Paragraph)
        .setPlaceholder("Digite aqui o que será enviado na DM de cada membro com esse cargo...")
        .setRequired(true)
        .setMaxLength(1800);
    modal.addComponents(new discord_js_1.ActionRowBuilder().addComponents(messageInput));
    await interaction.showModal(modal);
}
async function handleFamilyRole(interaction, kind, familyId) {
    const roleId = interaction.values[0];
    if (!roleId)
        return;
    try {
        await (0, families_1.updateFamily)(interaction.guild, interaction.user.id, familyId, {
            [kind === "familymember" ? "memberRoleId" : "leaderRoleId"]: roleId,
        });
    }
    catch (err) {
        if (err instanceof families_1.FamilyError) {
            await interaction.reply({ content: `❌ ${err.message}`, ephemeral: true });
            return;
        }
        throw err;
    }
    await (0, admFamiliasMenu_1.renderFamilyDetail)(interaction, familyId);
}
async function handleRoleTransferRole(interaction, kind) {
    const roleId = interaction.values[0] ?? null;
    const field = kind === "sourcerole" ? "sourceRoleId" : "targetRoleId";
    const label = kind === "sourcerole" ? "Cargo de origem" : "Cargo de destino";
    await (0, roleTransfer_1.updateRoleTransferConfig)(interaction.guild, interaction.user.id, { [field]: roleId }, `${label}: ${roleId ? `<@&${roleId}>` : "removido"}.`);
    await (0, admRoleTransferMenu_1.renderRoleTransferMenu)(interaction);
}
const component = {
    customId: "adm-role-select:",
    async execute(interaction) {
        if (!interaction.guild)
            return;
        const member = await interaction.guild.members.fetch(interaction.user.id);
        const parts = interaction.customId.split(":"); // ["adm-role-select", "kind", "type?"]
        const kind = parts[1];
        const type = parts[2];
        // O gerenciamento de cargo de etapa usa a permissão STAGE_MANAGER,
        // as demais seções (administração) exigem isBotAdmin.
        const authorized = kind === "stage"
            ? await (0, permissions_1.hasPermission)(member, enums_1.PermissionType.STAGE_MANAGER)
            : kind === "sourcerole" || kind === "targetrole"
                ? (await (0, permissions_1.hasPermission)(member, enums_1.PermissionType.STAGE_MANAGER)) ||
                    (await (0, permissions_1.hasPermission)(member, enums_1.PermissionType.REINTEGRATION_GRANTER))
                : await (0, permissions_1.isBotAdmin)(member);
        if (!authorized) {
            await interaction.reply({
                content: "🚫 Você não tem permissão para realizar esta ação.",
                ephemeral: true,
            });
            return;
        }
        if (kind === "botadmin")
            return handleBotAdmin(interaction);
        if (kind === "permrole")
            return handlePermRole(interaction, type);
        if (kind === "sysrole")
            return handleSysRole(interaction, type);
        if (kind === "stage")
            return handleStageRole(interaction, type);
        if (kind === "movcallperm")
            return handleMovCallPermRole(interaction);
        if (kind === "movcalltop1")
            return handleMovCallTop1Role(interaction);
        if (kind === "movcallrewardadd")
            return handleMovCallRewardAdd(interaction);
        if (kind === "movcallrewardremove")
            return handleMovCallRewardRemove(interaction);
        if (kind === "avisos")
            return handleAvisosRole(interaction);
        if (kind === "familymember")
            return handleFamilyRole(interaction, "familymember", type);
        if (kind === "familyleader")
            return handleFamilyRole(interaction, "familyleader", type);
        if (kind === "sourcerole")
            return handleRoleTransferRole(interaction, "sourcerole");
        if (kind === "targetrole")
            return handleRoleTransferRole(interaction, "targetrole");
    },
};
exports.default = component;
//# sourceMappingURL=roleSelects.js.map