"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const permissions_1 = require("../../utils/permissions");
const prisma_1 = require("../../database/prisma");
const customEmbeds_1 = require("../../utils/customEmbeds");
const configurationChecks_1 = require("../../utils/configurationChecks");
const panelInteraction_1 = require("../../utils/panelInteraction");
const admEmbedV2Menu_1 = require("../buttons/admEmbedV2Menu");
const component = { customId: "embedv2-channel:", async execute(i) {
        if (!i.guild || !i.isChannelSelectMenu() || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return;
        const [, action, id] = i.customId.split(":");
        const record = await (0, customEmbeds_1.fetchCustomEmbed)(id, i.guild.id);
        if (!record)
            return void await i.reply({ content: "Mensagem não encontrada neste servidor.", ephemeral: true });
        const channelId = i.values[0];
        if (action === "destination") {
            const check = await (0, configurationChecks_1.writableChannel)(i.guild, channelId);
            if (check.issue)
                return void await i.reply({ content: check.issue, ephemeral: true });
            await (0, panelInteraction_1.deferPanel)(i);
            await prisma_1.prisma.customEmbed.update({ where: { id }, data: { destinationChannelId: channelId } });
            return (0, admEmbedV2Menu_1.renderEmbedEditor)(i, id);
        }
        if (action === "addbutton") {
            const channel = await i.guild.channels.fetch(channelId).catch(() => null);
            if (!channel || channel.guildId !== i.guild.id)
                return void await i.reply({ content: "Escolha um canal deste servidor.", ephemeral: true });
            const label = new discord_js_1.TextInputBuilder().setCustomId("label").setLabel("Texto do botão").setStyle(discord_js_1.TextInputStyle.Short).setRequired(true).setMaxLength(80).setValue(`Ir para #${channel.name}`.slice(0, 80));
            const emoji = new discord_js_1.TextInputBuilder().setCustomId("emoji").setLabel("Emoji opcional").setStyle(discord_js_1.TextInputStyle.Short).setRequired(false).setMaxLength(50);
            return void await i.showModal(new discord_js_1.ModalBuilder().setCustomId(`embedv2-modal:add-channel:${id}:${channelId}`).setTitle("Botão para canal").addComponents(new discord_js_1.ActionRowBuilder().addComponents(label), new discord_js_1.ActionRowBuilder().addComponents(emoji)));
        }
    } };
exports.default = component;
