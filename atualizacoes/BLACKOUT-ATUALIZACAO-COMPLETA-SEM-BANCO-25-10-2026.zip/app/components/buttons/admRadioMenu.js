"use strict";
const { prepareAdminPanel } = require("../../utils/adminTasks");

Object.defineProperty(exports, "__esModule", { value: true });
exports.buildRadioMainView = buildRadioMainView;
exports.buildRadioPlaylistView = buildRadioPlaylistView;
exports.buildRadioVoiceView = buildRadioVoiceView;
exports.buildRadioControlView = buildRadioControlView;
exports.renderRadioMenu = renderRadioMenu;

const discord_js_1 = require("discord.js");
const adminUi_1 = require("../../utils/adminUi");
const permissions_1 = require("../../utils/permissions");
const admPanel_1 = require("../../utils/admPanel");
const service_1 = require("../../radio/service");

const RED = 0xd71935;
const PAGE_SIZE = 8;
const button = (id, label, style = discord_js_1.ButtonStyle.Secondary, disabled = false) => new discord_js_1.ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style).setDisabled(disabled);

function safeText(value, max = 80) {
    const clean = String(value || "").replace(/[\[\]`*_~>|]/g, "").replace(/\s+/g, " ").trim();
    return clean.length > max ? `${clean.slice(0, max - 1)}…` : clean;
}

function modeLabel(mode) {
    return mode === "RANDOM" ? "🔀 Aleatório" : "▶️ Sequencial";
}

function playerLabel(status) {
    const normalized = String(status || "").toLowerCase();
    if (normalized === "playing") return "▶️ Tocando";
    if (normalized === "paused" || normalized === "autopaused") return "⏸️ Pausada";
    if (normalized === "buffering") return "⏳ Carregando";
    return "⏹️ Parada";
}

async function buildRadioMainView(guild) {
    const [config, tracks, runtime] = await Promise.all([
        (0, service_1.getRadioConfig)(guild.id),
        (0, service_1.getRadioTracks)(guild.id),
        (0, service_1.getRadioRuntimeStatus)(guild.id),
    ]);
    const currentIndex = runtime.currentTrack ? tracks.findIndex((track) => track.id === runtime.currentTrack.id) : -1;
    const nowPlaying = runtime.currentTrack
        ? `**${safeText(runtime.currentTrack.title || runtime.currentTrack.videoId, 100)}**${currentIndex >= 0 ? `\nFaixa: **${currentIndex + 1}/${tracks.length}**` : ""}`
        : config.enabled ? "Aguardando conexão/reprodução..." : "Rádio desligada.";
    const embed = (0, adminUi_1.adminEmbed)(guild, "entretenimento")
        .setColor(RED)
        .setTitle("📻 Configurações — Rádio 24h")
        .setDescription("Escolha a call, prepare a playlist e acompanhe a reprodução.")
        .addFields(
        { name: "Estado", value: config.enabled ? "Ativada" : "Desativada", inline: true },
        { name: "Call", value: config.voiceChannelId ? `<#${config.voiceChannelId}>` : "Não configurada", inline: true },
        { name: "Playlist", value: `${tracks.length}/${service_1.MAX_RADIO_TRACKS} faixas · ${config.mode === "RANDOM" ? "Aleatória" : "Sequencial"}` },
        { name: "Tocando agora", value: `${nowPlaying}\n${playerLabel(runtime.playerStatus).replace(/^[^A-Za-zÀ-ÿ]+/, "")}` },
        { name: "Reprodução contínua", value: `Volume: ${config.volume}% · Repetição da playlist e tentativa de reconexão automática.` });
    if (runtime.lastError)
        embed.addFields({ name: "⚠️ Último aviso", value: safeText(runtime.lastError, 500) });
    
    const row1 = new discord_js_1.ActionRowBuilder().addComponents(
        button("adm-radio:back", "Voltar", discord_js_1.ButtonStyle.Primary),
        button("adm-radio:toggle", config.enabled ? "Desativar" : "Ativar", config.enabled ? discord_js_1.ButtonStyle.Danger : discord_js_1.ButtonStyle.Success),
        button("adm-radio:voice", "Call"),
        button("adm-radio:playlist:1", "Playlist"),
        button("adm-radio:mode", "Modo"));
    const row2 = new discord_js_1.ActionRowBuilder().addComponents(
        button("adm-radio:control", "Controle"),
        button("adm-radio:volume", "Volume"),
        button("adm-radio:reset", "Resetar", discord_js_1.ButtonStyle.Danger));
    return prepareAdminPanel(guild, 'radio', { attachments: [], embeds: [embed], components: [row1, row2, require("../../social-experience/common").row(require("../../social-experience/common").btn("sx-admin:radio","Pedidos e painel público"))] });
}

async function buildRadioVoiceView(guild) {
    const config = await (0, service_1.getRadioConfig)(guild.id);
    const embed = (0, adminUi_1.adminEmbed)(guild, "entretenimento")
        .setColor(RED)
        .setTitle("🔊 Call — Rádio 24h")
        .setDescription("Selecione a call onde o bot ficará conectado para reproduzir a rádio continuamente.")
        .addFields({ name: "Call atual", value: config.voiceChannelId ? `<#${config.voiceChannelId}>` : "Não configurada" }, { name: "Permissões necessárias", value: "O bot precisa conseguir **Ver o canal**, **Conectar** e **Falar**." });
    const select = new discord_js_1.ChannelSelectMenuBuilder()
        .setCustomId("radio-voice-channel")
        .setPlaceholder("Selecione uma call...")
        .addChannelTypes(discord_js_1.ChannelType.GuildVoice, discord_js_1.ChannelType.GuildStageVoice)
        .setMinValues(1)
        .setMaxValues(1);
    const row = new discord_js_1.ActionRowBuilder().addComponents(select);
    const actions = new discord_js_1.ActionRowBuilder().addComponents(button("adm-radio:voice-clear", "Remover Call"), button("adm-radio:home", "Voltar", discord_js_1.ButtonStyle.Primary));
    return { attachments: [], embeds: [embed], components: [row, actions] };
}

async function buildRadioPlaylistView(guild, requestedPage = 1) {
    const [config, tracks] = await Promise.all([(0, service_1.getRadioConfig)(guild.id), (0, service_1.getRadioTracks)(guild.id)]);
    const pageCount = Math.max(1, Math.ceil(tracks.length / PAGE_SIZE));
    const page = Math.max(1, Math.min(pageCount, Number(requestedPage) || 1));
    const start = (page - 1) * PAGE_SIZE;
    const slice = tracks.slice(start, start + PAGE_SIZE);
    const knownSeconds = tracks.reduce((sum, track) => sum + (track.durationSeconds || 0), 0);
    const unknown = tracks.filter((track) => !track.durationSeconds).length;
    const lines = slice.length ? slice.map((track, offset) => {
        const position = start + offset + 1;
        const title = safeText(track.title || `YouTube • ${track.videoId}`, 70);
        const duration = track.durationSeconds ? ` • ${(0, service_1.formatRadioDuration)(track.durationSeconds)}` : "";
        const warning = track.lastError ? " ⚠️" : "";
        return `**${String(position).padStart(2, "0")}.** [${title}](${track.url})${duration}${warning}`;
    }).join("\n") : "Nenhuma faixa cadastrada.";
    const durationText = knownSeconds ? `${(0, service_1.formatRadioDuration)(knownSeconds)}${unknown ? ` + ${unknown} sem duração carregada` : ""}` : tracks.length ? "Metadados sendo carregados" : "0s";
    const embed = (0, adminUi_1.adminEmbed)(guild, "entretenimento")
        .setColor(RED)
        .setTitle("🎶 Playlist — Rádio 24h")
        .addFields({ name: "ℹ️ Informações", value: `Faixas cadastradas: **${tracks.length}/${service_1.MAX_RADIO_TRACKS}**\nDuração estimada: **${durationText}**\nModo atual: **${modeLabel(config.mode)}**` }, { name: `📋 Faixas — Página ${page}/${pageCount}`, value: lines });
    const actions = new discord_js_1.ActionRowBuilder().addComponents(
        button("adm-radio:playlist-add", "➕ Adicionar", discord_js_1.ButtonStyle.Success),
        button("adm-radio:playlist-remove", "➖ Remover", undefined, !tracks.length),
        button("adm-radio:playlist-move", "🔃 Organizar", undefined, tracks.length < 2),
        button("adm-radio:playlist-clear", "🗑 Limpar", discord_js_1.ButtonStyle.Danger, !tracks.length),
        button("adm-radio:home", "Voltar", discord_js_1.ButtonStyle.Primary));
    const pagination = new discord_js_1.ActionRowBuilder().addComponents(
        button(`adm-radio:playlist:${page - 1}`, "◀", undefined, page <= 1),
        button("adm-radio:noop", `${page}/${pageCount}`, undefined, true),
        button(`adm-radio:playlist:${page + 1}`, "▶", undefined, page >= pageCount));
    return { attachments: [], embeds: [embed], components: pageCount > 1 ? [actions, pagination] : [actions] };
}

async function buildRadioControlView(guild) {
    const [config, tracks, runtime] = await Promise.all([
        (0, service_1.getRadioConfig)(guild.id),
        (0, service_1.getRadioTracks)(guild.id),
        (0, service_1.getRadioRuntimeStatus)(guild.id),
    ]);
    const index = runtime.currentTrack ? tracks.findIndex((track) => track.id === runtime.currentTrack.id) : -1;
    const trackText = runtime.currentTrack
        ? `**${safeText(runtime.currentTrack.title || runtime.currentTrack.videoId, 120)}**\n${index >= 0 ? `Faixa **${index + 1}/${tracks.length}**` : ""}`
        : "Nenhuma faixa tocando agora.";
    const embed = (0, adminUi_1.adminEmbed)(guild, "entretenimento")
        .setColor(RED)
        .setTitle("🎛 Controle — Rádio 24h")
        .addFields({ name: "🎵 Tocando", value: trackText }, { name: "Estado", value: `Rádio: **${config.enabled ? "Ativada" : "Desativada"}**\nPlayer: **${playerLabel(runtime.playerStatus)}**\nVolume: **${config.volume}%**\nFila preparada: **${runtime.queueLength}**` });
    const disabled = !config.enabled;
    const controls = new discord_js_1.ActionRowBuilder().addComponents(
        button("adm-radio:previous", "⏮ Anterior", undefined, disabled),
        button("adm-radio:pause", runtime.paused ? "▶ Retomar" : "⏯ Pausar", undefined, disabled),
        button("adm-radio:next", "⏭ Pular", undefined, disabled),
        button("adm-radio:restart-track", "🔁 Reiniciar", undefined, disabled),
        button("adm-radio:shuffle", "🔀 Embaralhar", undefined, disabled));
    const back = new discord_js_1.ActionRowBuilder().addComponents(button("adm-radio:home", "Voltar", discord_js_1.ButtonStyle.Primary));
    return { attachments: [], embeds: [embed], components: [controls, back] };
}

function buildAddModal() {
    const input = new discord_js_1.TextInputBuilder().setCustomId("urls").setLabel("Links do YouTube — um por linha").setStyle(discord_js_1.TextInputStyle.Paragraph).setRequired(true).setMaxLength(4000).setPlaceholder("https://youtu.be/...\nhttps://www.youtube.com/watch?v=...");
    return new discord_js_1.ModalBuilder().setCustomId("adm-radio-modal:add").setTitle("Adicionar faixas").addComponents(new discord_js_1.ActionRowBuilder().addComponents(input));
}

function buildRemoveModal() {
    const input = new discord_js_1.TextInputBuilder().setCustomId("positions").setLabel("Posições para remover").setStyle(discord_js_1.TextInputStyle.Short).setRequired(true).setMaxLength(100).setPlaceholder("Ex.: 2, 5, 8-10");
    return new discord_js_1.ModalBuilder().setCustomId("adm-radio-modal:remove").setTitle("Remover faixas").addComponents(new discord_js_1.ActionRowBuilder().addComponents(input));
}

function buildMoveModal() {
    const from = new discord_js_1.TextInputBuilder().setCustomId("from").setLabel("Posição atual").setStyle(discord_js_1.TextInputStyle.Short).setRequired(true).setMaxLength(5).setPlaceholder("Ex.: 12");
    const to = new discord_js_1.TextInputBuilder().setCustomId("to").setLabel("Nova posição").setStyle(discord_js_1.TextInputStyle.Short).setRequired(true).setMaxLength(5).setPlaceholder("Ex.: 3");
    return new discord_js_1.ModalBuilder().setCustomId("adm-radio-modal:move").setTitle("Organizar playlist").addComponents(new discord_js_1.ActionRowBuilder().addComponents(from), new discord_js_1.ActionRowBuilder().addComponents(to));
}

async function buildVolumeModal(guildId) {
    const config = await (0, service_1.getRadioConfig)(guildId);
    const input = new discord_js_1.TextInputBuilder().setCustomId("volume").setLabel("Volume de 1 a 100").setStyle(discord_js_1.TextInputStyle.Short).setRequired(true).setMaxLength(3).setValue(String(config.volume));
    return new discord_js_1.ModalBuilder().setCustomId("adm-radio-modal:volume").setTitle("Volume da Rádio 24h").addComponents(new discord_js_1.ActionRowBuilder().addComponents(input));
}

async function renderRadioMenu(interaction) {
    await interaction.update(await buildRadioMainView(interaction.guild));
}

async function editAfterDeferred(interaction, payload) {
    if (!interaction.deferred && !interaction.replied)
        await interaction.deferUpdate();
    return interaction.editReply(payload);
}

async function sendEphemeral(interaction, content) {
    if (interaction.deferred || interaction.replied)
        return interaction.followUp({ content, flags: discord_js_1.MessageFlags.Ephemeral });
    return interaction.reply({ content, flags: discord_js_1.MessageFlags.Ephemeral });
}

const component = {
    customId: "adm-radio:",
    async execute(i) {
        if (!i.guild)
            return;
        if (!(await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id))))
            return void await sendEphemeral(i, "Você não possui permissão.");
        const parts = i.customId.split(":");
        const action = parts[1];
        if (action === "noop")
            return;
        if (action === "back")
            return void await i.update(await (0, admPanel_1.buildAdmSectionPanel)(i.guild, "entretenimento"));
        if (action === "home")
            return void await i.update(await buildRadioMainView(i.guild));
        if (action === "voice")
            return void await i.update(await buildRadioVoiceView(i.guild));
        if (action === "voice-clear") {
            await (0, service_1.setRadioVoiceChannel)(i.guild.id, null);
            const cfg = await (0, service_1.getRadioConfig)(i.guild.id);
            if (cfg.enabled) {
                await (0, service_1.setRadioEnabled)(i.guild.id, false);
                await (0, service_1.stopRadio)(i.guild.id).catch(() => null);
            }
            return void await i.update(await buildRadioVoiceView(i.guild));
        }
        if (action === "playlist")
            return void await i.update(await buildRadioPlaylistView(i.guild, parts[2] || 1));
        if (action === "playlist-add")
            return void await i.showModal(buildAddModal());
        if (action === "playlist-remove")
            return void await i.showModal(buildRemoveModal());
        if (action === "playlist-move")
            return void await i.showModal(buildMoveModal());
        if (action === "playlist-clear") {
            const embed = (0, adminUi_1.adminEmbed)(i.guild, "entretenimento").setColor(RED).setTitle("🗑 Limpar playlist").setDescription("Deseja apagar **todas as faixas** da Rádio 24h? Se a rádio estiver ativa, ela será desligada.");
            const row = new discord_js_1.ActionRowBuilder().addComponents(button("adm-radio:playlist-clear-confirm", "Confirmar", discord_js_1.ButtonStyle.Danger), button("adm-radio:playlist:1", "Cancelar"));
            return void await i.update({ attachments: [], embeds: [embed], components: [row] });
        }
        if (action === "playlist-clear-confirm") {
            await (0, service_1.setRadioEnabled)(i.guild.id, false);
            await (0, service_1.stopRadio)(i.guild.id).catch(() => null);
            await (0, service_1.clearRadioPlaylist)(i.guild.id);
            return void await i.update(await buildRadioPlaylistView(i.guild, 1));
        }
        if (action === "volume")
            return void await i.showModal(await buildVolumeModal(i.guild.id));
        if (action === "mode") {
            const cfg = await (0, service_1.getRadioConfig)(i.guild.id);
            const mode = new discord_js_1.StringSelectMenuBuilder().setCustomId("radio-mode-select").setPlaceholder("Ordem de reprodução").addOptions({label:"Sequencial",value:"SEQUENTIAL",description:"Tocar na ordem da playlist",default:cfg.mode === "SEQUENTIAL"},{label:"Aleatória",value:"RANDOM",description:"Embaralhar um ciclo completo antes de repetir",default:cfg.mode === "RANDOM"});
            return void await i.update({content:null,attachments:[],embeds:[(0,adminUi_1.adminEmbed)(i.guild,"entretenimento").setTitle("Ordem de reprodução").setDescription("Escolha como as faixas serão tocadas. A seleção salva e atualiza esta tela.")],components:[new discord_js_1.ActionRowBuilder().addComponents(mode),new discord_js_1.ActionRowBuilder().addComponents(button("adm-radio:home","Voltar"))]});
        }
        if (action === "toggle") {
            const cfg = await (0, service_1.getRadioConfig)(i.guild.id);
            if (!cfg.enabled) {
                const tracks = await (0, service_1.getRadioTracks)(i.guild.id);
                if (!cfg.voiceChannelId)
                    return void await sendEphemeral(i, "Configure uma **Call** antes de ativar a Rádio 24h.");
                if (!tracks.length)
                    return void await sendEphemeral(i, "Adicione pelo menos uma faixa à **Playlist** antes de ativar a Rádio 24h.");
                await i.deferUpdate();
                await (0, service_1.setRadioEnabled)(i.guild.id, true);
                try {
                    await (0, service_1.startRadio)(i.guild, { resumeCurrent: true });
                }
                catch (error) {
                    await (0, service_1.setRadioEnabled)(i.guild.id, false);
                    await (0, service_1.stopRadio)(i.guild.id).catch(() => null);
                    await i.editReply(await buildRadioMainView(i.guild));
                    return void await i.followUp({ content: `Não consegui iniciar a rádio: **${safeText(error?.message || error, 400)}**`, flags: discord_js_1.MessageFlags.Ephemeral });
                }
                return void await i.editReply(await buildRadioMainView(i.guild));
            }
            await i.deferUpdate();
            await (0, service_1.setRadioEnabled)(i.guild.id, false);
            await (0, service_1.stopRadio)(i.guild.id).catch(() => null);
            return void await i.editReply(await buildRadioMainView(i.guild));
        }
        if (action === "control")
            return void await i.update(await buildRadioControlView(i.guild));
        if (["previous", "pause", "next", "restart-track", "shuffle"].includes(action)) {
            await i.deferUpdate();
            try {
                if (action === "previous") await (0, service_1.previousRadioTrack)(i.guild.id);
                if (action === "pause") await (0, service_1.pauseOrResumeRadio)(i.guild.id);
                if (action === "next") await (0, service_1.skipRadioTrack)(i.guild.id);
                if (action === "restart-track") await (0, service_1.restartCurrentRadioTrack)(i.guild.id);
                if (action === "shuffle") await (0, service_1.shuffleRadioQueue)(i.guild.id);
            }
            catch (error) {
                await i.followUp({ content: `Não consegui executar esse controle: **${safeText(error?.message || error, 400)}**`, flags: discord_js_1.MessageFlags.Ephemeral }).catch(() => null);
            }
            return void await i.editReply(await buildRadioControlView(i.guild));
        }
        if (action === "reset") {
            const embed = (0, adminUi_1.adminEmbed)(i.guild, "entretenimento").setColor(RED).setTitle("Resetar Rádio 24h").setDescription("Isso desativa a rádio, remove a call configurada e **apaga toda a playlist**. Deseja continuar?");
            const row = new discord_js_1.ActionRowBuilder().addComponents(button("adm-radio:reset-confirm", "Confirmar Reset", discord_js_1.ButtonStyle.Danger), button("adm-radio:home", "Cancelar"));
            return void await i.update({ attachments: [], embeds: [embed], components: [row] });
        }
        if (action === "reset-confirm") {
            await i.deferUpdate();
            await (0, service_1.resetRadioConfig)(i.guild.id);
            return void await i.editReply(await buildRadioMainView(i.guild));
        }
    },
};
exports.default = component;
