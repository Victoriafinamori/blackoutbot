"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderGiveawayAdmin = renderGiveawayAdmin;
const discord_js_1 = require("discord.js");
const admPanel_1 = require("../../utils/admPanel");
const views_1 = require("../../giveaways/views");
const service_1 = require("../../giveaways/service");
const drafts_1 = require("../../giveaways/drafts");
const prisma_1 = require("../../database/prisma");
async function renderGiveawayAdmin(i) { await i.update(await (0, views_1.adminGiveawayView)(i.guild)); }
const input = (id, label, value, style = discord_js_1.TextInputStyle.Short, required = true) => new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId(id).setLabel(label).setValue(value).setStyle(style).setRequired(required));
const component = { customId: "giveaway-admin:", async execute(i) {
        if (!i.guild || !await (0, service_1.canManageGiveaways)(i.guild, i.user.id))
            return void await i.reply({ content: "Você não possui permissão.", flags: discord_js_1.MessageFlags.Ephemeral });
        const action = i.customId.split(":")[1];
        if (action === "back")
            return void await i.update(await (0, admPanel_1.buildAdmSectionPanel)(i.guild, "staff"));
        if (action === "home")
            return void await i.update(await (0, views_1.adminGiveawayView)(i.guild));
        if (action === "history")
            return void await i.update(await (0, views_1.giveawayHistoryView)(i.guild));
        if (action === "stats")
            return void await i.update(await (0, views_1.giveawayStatsView)(i.guild));
        if (action === "new") {
            (0, drafts_1.clearGiveawayDraft)(i.guild.id, i.user.id);
            const c = await (0, service_1.giveawayConfig)(i.guild.id);
            (0, drafts_1.getGiveawayDraft)(i.guild.id, i.user.id, { buttonLabel: c.buttonLabel });
            return void await i.update(await (0, views_1.wizardView)(i.guild, i.user.id));
        }
        const c = await (0, service_1.giveawayConfig)(i.guild.id);
        if (action === "appearance")
            return void await i.update(await (0, views_1.giveawayAppearanceView)(i.guild));
        if (action === "appearance-basic")
            return void await i.showModal(new discord_js_1.ModalBuilder().setCustomId("giveaway-config:appearance").setTitle("Aparência • Texto e Cor").addComponents(input("title", "Título padrão", c.title), input("description", "Descrição padrão", c.defaultDescription, discord_js_1.TextInputStyle.Paragraph), input("color", "Cor hexadecimal", c.color), input("footer", "Rodapé", c.footer), input("button", "Texto do botão", c.buttonLabel)));
        if (action === "appearance-media")
            return void await i.showModal(new discord_js_1.ModalBuilder().setCustomId("giveaway-config:media").setTitle("Aparência • Imagens").addComponents(input("thumbnail", "URL da thumbnail", c.thumbnail || "", discord_js_1.TextInputStyle.Short, false), input("image", "URL da imagem/banner", c.image || "", discord_js_1.TextInputStyle.Short, false)));
        if (action === "appearance-messages")
            return void await i.showModal(new discord_js_1.ModalBuilder().setCustomId("giveaway-config:messages").setTitle("Aparência • Mensagens").addComponents(input("joined", "Mensagem de participação", c.joinedMessage, discord_js_1.TextInputStyle.Paragraph), input("ended", "Mensagem de encerramento", c.endedMessage, discord_js_1.TextInputStyle.Paragraph)));
        if (action === "appearance-result")
            return void await i.showModal(new discord_js_1.ModalBuilder().setCustomId("giveaway-config:result").setTitle("Aparência • Resultado").addComponents(input("title", "Título do resultado", c.resultTitle), input("footer", "Rodapé do resultado", c.resultFooter)));
        if (action === "appearance-reset") {
            await prisma_1.prisma.giveawayConfig.update({ where: { guildId: i.guild.id }, data: { title: "SORTEIO AUDAZ", defaultDescription: "Participe e cumpra os requisitos durante o período do sorteio para ficar elegível.", color: "D20B20", thumbnail: null, image: null, footer: "AUDAZ • Sorteios", buttonLabel: "Participar", joinedMessage: "Você entrou no sorteio com sucesso.", endedMessage: "O sorteio foi encerrado.", resultTitle: "SORTEIO FINALIZADO", resultFooter: "AUDAZ • Sorteio encerrado" } });
            return void await i.update(await (0, views_1.giveawayAppearanceView)(i.guild));
        }
        if (action === "permissions") {
            const roles = new discord_js_1.RoleSelectMenuBuilder().setCustomId("giveaway-config-role:managers").setPlaceholder("Cargos gestores").setMinValues(0).setMaxValues(20), logs = new discord_js_1.ChannelSelectMenuBuilder().setCustomId("giveaway-config-channel:logs").setPlaceholder("Canal de logs").addChannelTypes(discord_js_1.ChannelType.GuildText).setMinValues(0).setMaxValues(1);
            return void await i.update({ embeds: (await (0, views_1.adminGiveawayView)(i.guild)).embeds, components: [new discord_js_1.ActionRowBuilder().addComponents(roles), new discord_js_1.ActionRowBuilder().addComponents(logs), new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("giveaway-admin:home").setLabel("Voltar").setStyle(discord_js_1.ButtonStyle.Secondary))] });
        }
    } };
exports.default = component;
//# sourceMappingURL=giveawayAdminButtons.js.map