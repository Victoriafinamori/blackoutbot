"use strict";
const { prepareAdminPanel } = require("../../utils/adminTasks");
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderCleanupMenu = renderCleanupMenu;
exports.buildCleanupRunSetup = buildCleanupRunSetup;
const discord_js_1 = require("discord.js");
const prisma_1 = require("../../database/prisma");
const adminUi_1 = require("../../utils/adminUi");
const permissions_1 = require("../../utils/permissions");
const tickets_1 = require("../../utils/tickets");
const movStats_1 = require("../../utils/movStats");
const cleanupRunDrafts_1 = require("../../utils/cleanupRunDrafts");
async function config(guildId) { return prisma_1.prisma.cleanupConfig.upsert({ where: { guildId }, update: {}, create: { guildId } }); }
const modeLabel = (mode) => ({ BOTH: "CALL e CHAT", CALL: "Somente CALL", CHAT: "Somente CHAT", EITHER: "CALL ou CHAT" }[mode] || mode);
const input = (id, label, value) => new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId(id).setLabel(label).setStyle(discord_js_1.TextInputStyle.Short).setValue(value).setRequired(true));
async function renderCleanupMenu(i) {
    const c = await config(i.guild.id), analyses = await prisma_1.prisma.cleanupAnalysis.count({ where: { guildId: i.guild.id } });
    const e = (await (0, adminUi_1.adminEmbed)(i.guild, "servidor")).setTitle("🧹 Ajudante de Limpa").setDescription(`O sistema apenas analisa e organiza membros. **Nenhuma expulsão ou banimento é executado pelo bot.**\n\n` +
        `**Metas configuradas**\nCALL: **${(0, movStats_1.formatDuration)(c.minCallSeconds)}**\nMensagens: **${c.minMessages}**\nModo: **${modeLabel(c.analysisMode)}**\n\n` +
        `**Cargos analisados:** ${(0, tickets_1.ids)(c.includedRoleIds).map(x => `<@&${x}>`).join(", ") || "Todos os membros"}\n` +
        `**Cargos ignorados:** ${(0, tickets_1.ids)(c.ignoredRoleIds).map(x => `<@&${x}>`).join(", ") || "Nenhum"}\n` +
        `**Membros recentes:** ${c.recentMemberMode}\n**Ignorar primeiros:** ${c.ignoreNewerThanDays} dias\n` +
        `**Canal de resultados:** ${c.resultChannelId ? `<#${c.resultChannelId}>` : "Não configurado"}\n**Análises salvas:** ${analyses}\n\n` +
        `Use **Executar análise** abaixo. Não é necessário utilizar comandos.`);
    const included = new discord_js_1.RoleSelectMenuBuilder().setCustomId("cleanup-role:includedRoleIds").setPlaceholder("Cargos analisados").setMinValues(0).setMaxValues(20);
    const ignored = new discord_js_1.RoleSelectMenuBuilder().setCustomId("cleanup-role:ignoredRoleIds").setPlaceholder("Cargos ignorados").setMinValues(0).setMaxValues(20);
    const channel = new discord_js_1.ChannelSelectMenuBuilder().setCustomId("cleanup-channel:resultChannelId").setPlaceholder("Canal de resultados").addChannelTypes(discord_js_1.ChannelType.GuildText).setMinValues(0);
    const payload = { attachments: [], embeds: [e], components: [
            new discord_js_1.ActionRowBuilder().addComponents(included),
            new discord_js_1.ActionRowBuilder().addComponents(ignored),
            new discord_js_1.ActionRowBuilder().addComponents(channel),
            new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-cleanup:analyze").setLabel("Executar análise").setStyle(discord_js_1.ButtonStyle.Success), new discord_js_1.ButtonBuilder().setCustomId("adm-cleanup:goals").setLabel("Configurar metas").setStyle(discord_js_1.ButtonStyle.Success), new discord_js_1.ButtonBuilder().setCustomId("adm-cleanup:mode:PROPORTIONAL").setLabel("Meta Proporcional").setStyle(discord_js_1.ButtonStyle.Primary), new discord_js_1.ButtonBuilder().setCustomId("adm-cleanup:mode:IGNORE").setLabel("Ignorar Recentes").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId("adm-cleanup:mode:NORMAL").setLabel("Analisar Normalmente").setStyle(discord_js_1.ButtonStyle.Secondary)),
            new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-nav:servidor").setLabel("Voltar").setStyle(discord_js_1.ButtonStyle.Secondary))
        ] };
    if (i.isModalSubmit?.())
        await i.editReply(prepareAdminPanel(i.guild, 'inatividade', payload));
    else
        await i.update(prepareAdminPanel(i.guild, 'inatividade', payload));
}
async function buildCleanupRunSetup(guild, userId) {
    const draft = (0, cleanupRunDrafts_1.getCleanupRunDraft)(guild.id, userId), role = draft.roleId ? await guild.roles.fetch(draft.roleId).catch(() => null) : null;
    const label = draft.resultFilter === "APPROVED" ? "Somente quem atingiu" : draft.resultFilter === "FAILED" ? "Somente quem não atingiu" : "Todos os resultados";
    const embed = new discord_js_1.EmbedBuilder().setColor(0xd71935).setTitle("Análise de inatividade").setDescription("Defina exatamente quem será analisado e quais resultados deverão aparecer nas páginas.").addFields({ name: "Cargo/tag da análise", value: role ? `${role}` : "Usar os cargos gerais configurados no painel" }, { name: "Exibição", value: label }, { name: "Observação", value: "O filtro altera apenas a lista exibida e o arquivo gerado. O resumo continuará mostrando quantos atingiram e quantos não atingiram a meta." });
    const roleSelect = new discord_js_1.RoleSelectMenuBuilder().setCustomId("cleanup-run-role:select").setPlaceholder("Filtrar por um único cargo/tag").setMinValues(0).setMaxValues(1);
    if (role)
        roleSelect.setDefaultRoles(role.id);
    const filter = new discord_js_1.StringSelectMenuBuilder().setCustomId("cleanup-run-filter:select").setPlaceholder("Escolha quais resultados serão exibidos").addOptions({ label: "Todos os resultados", value: "ALL", default: draft.resultFilter === "ALL" }, { label: "Somente quem atingiu", value: "APPROVED", default: draft.resultFilter === "APPROVED" }, { label: "Somente quem não atingiu", value: "FAILED", default: draft.resultFilter === "FAILED" });
    const actions = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-cleanup:period").setLabel("Escolher Período e Executar").setStyle(discord_js_1.ButtonStyle.Success), new discord_js_1.ButtonBuilder().setCustomId("adm-cleanup:setupback").setLabel("Voltar").setStyle(discord_js_1.ButtonStyle.Primary));
    return { attachments: [], embeds: [embed], components: [new discord_js_1.ActionRowBuilder().addComponents(roleSelect), new discord_js_1.ActionRowBuilder().addComponents(filter), actions] };
}
const component = { customId: "adm-cleanup:", async execute(i) {
        if (!i.guild || !(await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id))))
            return;
        const [, action, value] = i.customId.split(":"), c = await config(i.guild.id);
        if (action === "analyze") {
            await i.update(await buildCleanupRunSetup(i.guild, i.user.id));
            return;
        }
        if (action === "setupback") {
            await renderCleanupMenu(i);
            return;
        }
        if (action === "period") {
            const end = new Date(), start = new Date(end.getTime() - 14 * 86400000), date = (value) => value.toISOString().slice(0, 10);
            const modal = new discord_js_1.ModalBuilder().setCustomId("cleanup-run:execute").setTitle("Executar análise da limpa").addComponents(input("start", "Data inicial (AAAA-MM-DD)", date(start)), input("end", "Data final (AAAA-MM-DD)", date(end)));
            await i.showModal(modal);
            return;
        }
        if (action === "goals") {
            const modal = new discord_js_1.ModalBuilder().setCustomId("cleanup-goals:save").setTitle("Metas da Limpa").addComponents(input("callHours", "Meta de CALL em horas", String(c.minCallSeconds / 3600)), input("messages", "Meta de mensagens", String(c.minMessages)), input("mode", "Modo: BOTH, CALL, CHAT ou EITHER", c.analysisMode), input("recentDays", "Ignorar membros com até quantos dias", String(c.ignoreNewerThanDays)));
            await i.showModal(modal);
            return;
        }
        if (action === "mode") {
            await prisma_1.prisma.cleanupConfig.upsert({ where: { guildId: i.guild.id }, create: { guildId: i.guild.id, recentMemberMode: value }, update: { recentMemberMode: value } });
            await renderCleanupMenu(i);
        }
    } };
exports.default = component;
//# sourceMappingURL=admCleanupMenu.js.map