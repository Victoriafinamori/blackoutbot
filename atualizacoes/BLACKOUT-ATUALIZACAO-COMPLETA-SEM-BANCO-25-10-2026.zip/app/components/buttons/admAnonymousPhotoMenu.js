const adminUi_1 = require("../../utils/adminUi");
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildAnonymousPhotoAdminView = buildAnonymousPhotoAdminView;
exports.buildAnonymousPhotoChannelsView = buildAnonymousPhotoChannelsView;
exports.buildAnonymousPhotoLogsView = buildAnonymousPhotoLogsView;
exports.buildAnonymousPhotoCleanupView = buildAnonymousPhotoCleanupView;
exports.renderAnonymousPhotoMenu = renderAnonymousPhotoMenu;
const discord_js_1 = require("discord.js");
const prisma_1 = require("../../database/prisma");
const permissions_1 = require("../../utils/permissions");
const service_1 = require("../../submundo/service");
const RED = 0xd20b20;
const button = (id, label, style = discord_js_1.ButtonStyle.Secondary) => new discord_js_1.ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style);
const textInput = (id, label, value, style = discord_js_1.TextInputStyle.Short, required = true) => new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId(id).setLabel(label).setStyle(style).setValue(value || "").setRequired(required));
async function buildAnonymousPhotoAdminView(guild) {
    const config = await (0, service_1.getAnonymousPhotoConfig)(guild.id);
    const [total, published, removed] = await Promise.all([
        prisma_1.prisma.anonymousPhotoSubmission.count({ where: { guildId: guild.id } }),
        prisma_1.prisma.anonymousPhotoSubmission.count({ where: { guildId: guild.id, status: "PUBLISHED" } }),
        prisma_1.prisma.anonymousPhotoSubmission.count({ where: { guildId: guild.id, status: { in: ["REMOVED", "CLEANED"] } } }),
    ]);
    const embed = (0, adminUi_1.adminEmbed)(guild, "entretenimento").setColor(RED).setTitle("📸 Configurações — Fotos/Vídeos Anônimos")
        .addFields(
        { name: "ℹ️ Informações", value: `Status: **${config.enabled ? "✅ Ativado" : "❌ Desativado"}**\nCanal: ${config.destinationChannelId ? `<#${config.destinationChannelId}>` : "Não configurado"}\nPainel: ${config.panelChannelId ? `<#${config.panelChannelId}>` : "Não configurado"}\nLogs: ${config.logChannelId ? `<#${config.logChannelId}>` : "Não configurado"}` },
        { name: "🕒 Funcionamento", value: `Horário: **${(0, service_1.scheduleText)(config)}**\nLimpar após fechamento: **${config.cleanupOnClose ? "Sim" : "Não"}**` },
        { name: "📊 Publicações", value: `Recebidas: **${total}** · Ativas: **${published}** · Removidas/Limpas: **${removed}**` },
        { name: "📝 Observações", value: "1. Fotos e vídeos são publicados sem nome, avatar ou ID do autor.\n2. A autoria aparece somente no canal privado de logs.\n3. O painel abre e fecha automaticamente quando um horário é configurado.\n4. A reação 🔥 da publicação é usada para definir o Destaque." });
    const row1 = new discord_js_1.ActionRowBuilder().addComponents(
        button("adm-anonymous-photo:back", "Voltar", discord_js_1.ButtonStyle.Primary),
        button("adm-anonymous-photo:toggle", config.enabled ? "Desativar" : "Ativar", config.enabled ? discord_js_1.ButtonStyle.Danger : discord_js_1.ButtonStyle.Success),
        button("adm-anonymous-photo:channels", "Canal"),
        button("adm-anonymous-photo:schedule", "Horário"),
        button("adm-anonymous-photo:publish", config.panelMessageId ? "Atualizar Painel" : "Publicar Painel", discord_js_1.ButtonStyle.Primary));
    const row2 = new discord_js_1.ActionRowBuilder().addComponents(
        button("adm-anonymous-photo:cleanup", "Limpeza"),
        button("adm-anonymous-photo:logs", "Logs"),
        button("adm-anonymous-photo:appearance", "Aparência"),
        button("adm-anonymous-photo:remove", "Remover", discord_js_1.ButtonStyle.Danger),
        button("adm-anonymous-photo:reset", "Resetar", discord_js_1.ButtonStyle.Danger));
    return { embeds: [embed], components: [row1, row2] };
}
async function buildAnonymousPhotoChannelsView(guild) {
    const config = await (0, service_1.getAnonymousPhotoConfig)(guild.id);
    const embed = (0, adminUi_1.adminEmbed)(guild, "entretenimento").setColor(RED).setTitle("📸 Fotos/Vídeos — Canais").setDescription("Defina onde ficará o painel de envio e onde as mídias anônimas serão publicadas. Por segurança, ambos precisam ser canais **Restrito por idade (NSFW)**.")
        .addFields({ name: "Atual", value: `Painel: ${config.panelChannelId ? `<#${config.panelChannelId}>` : "Não configurado"}\nPublicações: ${config.destinationChannelId ? `<#${config.destinationChannelId}>` : "Não configurado"}` });
    const panel = new discord_js_1.ChannelSelectMenuBuilder().setCustomId("adm-anonymous-photo-channel:panel").setPlaceholder("Canal do painel").addChannelTypes(discord_js_1.ChannelType.GuildText).setMinValues(1).setMaxValues(1);
    const destination = new discord_js_1.ChannelSelectMenuBuilder().setCustomId("adm-anonymous-photo-channel:destination").setPlaceholder("Canal das fotos/vídeos").addChannelTypes(discord_js_1.ChannelType.GuildText).setMinValues(1).setMaxValues(1);
    return { embeds: [embed], components: [new discord_js_1.ActionRowBuilder().addComponents(panel), new discord_js_1.ActionRowBuilder().addComponents(destination), new discord_js_1.ActionRowBuilder().addComponents(button("adm-anonymous-photo:home", "Voltar", discord_js_1.ButtonStyle.Primary))] };
}
async function buildAnonymousPhotoLogsView(guild) {
    const config = await (0, service_1.getAnonymousPhotoConfig)(guild.id);
    const embed = (0, adminUi_1.adminEmbed)(guild, "entretenimento").setColor(RED).setTitle("📜 Fotos/Vídeos — Logs").setDescription("O autor real de cada envio fica registrado somente neste canal. O canal precisa ser privado e não pode estar visível para @everyone.")
        .addFields({ name: "Canal atual", value: config.logChannelId ? `<#${config.logChannelId}>` : "Não configurado" });
    const logs = new discord_js_1.ChannelSelectMenuBuilder().setCustomId("adm-anonymous-photo-channel:logs").setPlaceholder("Canal privado de logs").addChannelTypes(discord_js_1.ChannelType.GuildText).setMinValues(1).setMaxValues(1);
    return { embeds: [embed], components: [new discord_js_1.ActionRowBuilder().addComponents(logs), new discord_js_1.ActionRowBuilder().addComponents(button("adm-anonymous-photo:home", "Voltar", discord_js_1.ButtonStyle.Primary))] };
}
async function buildAnonymousPhotoCleanupView(guild) {
    const config = await (0, service_1.getAnonymousPhotoConfig)(guild.id);
    const embed = (0, adminUi_1.adminEmbed)(guild, "entretenimento").setColor(RED).setTitle("🧹 Fotos/Vídeos — Limpeza").setDescription("Quando ativada, as publicações da sessão são apagadas após o horário de fechamento. Os logs e registros internos são preservados.")
        .addFields({ name: "Estado atual", value: `Limpeza automática: **${config.cleanupOnClose ? "Ativada" : "Desativada"}**\nÚltima sessão limpa: **${config.lastCleanupSession || "Nenhuma"}**` });
    const row = new discord_js_1.ActionRowBuilder().addComponents(
        button("adm-anonymous-photo:cleanup-toggle", config.cleanupOnClose ? "Desativar" : "Ativar", config.cleanupOnClose ? discord_js_1.ButtonStyle.Danger : discord_js_1.ButtonStyle.Success),
        button("adm-anonymous-photo:cleanup-now", "Limpar Agora", discord_js_1.ButtonStyle.Danger),
        button("adm-anonymous-photo:home", "Voltar", discord_js_1.ButtonStyle.Primary));
    return { embeds: [embed], components: [row] };
}
async function renderAnonymousPhotoMenu(i) { await i.update(await buildAnonymousPhotoAdminView(i.guild)); }
const component = { customId: "adm-anonymous-photo:", async execute(i) {
    if (!i.guild) return;
    if (!await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
        return void await i.reply({ content: "Você não possui permissão.", flags: discord_js_1.MessageFlags.Ephemeral });
    const action = i.customId.split(":")[1];
    const config = await (0, service_1.getAnonymousPhotoConfig)(i.guild.id);
    if (action === "back") {
        const mod = require("./admSubmundoMenu");
        return void await i.update(await mod.buildSubmundoView(i.guild));
    }
    if (action === "home") return void await i.update(await buildAnonymousPhotoAdminView(i.guild));
    if (action === "channels") return void await i.update(await buildAnonymousPhotoChannelsView(i.guild));
    if (action === "logs") return void await i.update(await buildAnonymousPhotoLogsView(i.guild));
    if (action === "cleanup") return void await i.update(await buildAnonymousPhotoCleanupView(i.guild));
    if (action === "toggle") {
        if (!config.enabled && (!config.panelChannelId || !config.destinationChannelId || !config.logChannelId))
            return void await i.reply({ content: "Configure o canal do painel, das publicações e de logs antes de ativar.", flags: discord_js_1.MessageFlags.Ephemeral });
        await prisma_1.prisma.anonymousPhotoConfig.update({ where: { guildId: i.guild.id }, data: { enabled: !config.enabled, lastPanelOpen: null } });
        await (0, service_1.refreshAnonymousMediaPanel)(i.guild).catch(() => null);
        return void await i.update(await buildAnonymousPhotoAdminView(i.guild));
    }
    if (action === "publish") {
        await i.deferReply({ flags: discord_js_1.MessageFlags.Ephemeral });
        try { await (0, service_1.publishAnonymousMediaPanel)(i.guild); await i.editReply("Painel de Fotos/Vídeos publicado/atualizado com sucesso."); }
        catch (error) { await i.editReply(error instanceof Error ? error.message : String(error)); }
        return;
    }
    if (action === "schedule") {
        const modal = new discord_js_1.ModalBuilder().setCustomId("adm-anonymous-photo-modal:schedule").setTitle("Horário — Fotos/Vídeos")
            .addComponents(textInput("openTime", "Horário de abertura (HH:MM)", config.openTime || "", discord_js_1.TextInputStyle.Short, false), textInput("closeTime", "Horário de fechamento (HH:MM)", config.closeTime || "", discord_js_1.TextInputStyle.Short, false));
        return void await i.showModal(modal);
    }
    if (action === "appearance") {
        const modal = new discord_js_1.ModalBuilder().setCustomId("adm-anonymous-photo-modal:appearance").setTitle("Aparência — Fotos/Vídeos")
            .addComponents(textInput("title", "Título", config.title), textInput("description", "Descrição", config.description, discord_js_1.TextInputStyle.Paragraph), textInput("color", "Cor hexadecimal", config.color), textInput("image", "Imagem/Banner (URL, opcional)", config.image || "", discord_js_1.TextInputStyle.Short, false), textInput("button", "Texto do botão", config.buttonLabel));
        return void await i.showModal(modal);
    }
    if (action === "remove") {
        const modal = new discord_js_1.ModalBuilder().setCustomId("adm-anonymous-photo-modal:remove").setTitle("Remover Publicação")
            .addComponents(textInput("publicId", "ID do envio", ""), textInput("reason", "Motivo da remoção", "", discord_js_1.TextInputStyle.Paragraph));
        return void await i.showModal(modal);
    }
    if (action === "cleanup-toggle") {
        await prisma_1.prisma.anonymousPhotoConfig.update({ where: { guildId: i.guild.id }, data: { cleanupOnClose: !config.cleanupOnClose } });
        return void await i.update(await buildAnonymousPhotoCleanupView(i.guild));
    }
    if (action === "cleanup-now") {
        const timezone = await (0, service_1.getGuildTimezone)(i.guild.id);
        const state = (0, service_1.getScheduleState)(config, timezone);
        await i.deferReply({ flags: discord_js_1.MessageFlags.Ephemeral });
        const removed = await (0, service_1.cleanupAnonymousMediaSession)(i.guild, config, state.sessionKey);
        return void await i.editReply(`Limpeza concluída. **${removed}** publicação(ões) removida(s) da sessão ${state.sessionKey}.`);
    }
    if (action === "reset") {
        if (config.panelMessageId) {
            await prisma_1.prisma.anonymousPhotoConfig.update({ where: { guildId: i.guild.id }, data: { enabled: false } });
            await (0, service_1.refreshAnonymousMediaPanel)(i.guild).catch(() => null);
        }
        await prisma_1.prisma.anonymousPhotoConfig.update({ where: { guildId: i.guild.id }, data: {
            enabled: false, panelChannelId: null, panelMessageId: null, destinationChannelId: null, logChannelId: null,
            title: "Fotos e Vídeos Anônimos", description: "Envie uma foto ou vídeo de forma anônima. Sua identidade não será exibida publicamente.", color: "D20B20", image: null,
            footer: "Sua identidade não será exibida publicamente.", buttonLabel: "Enviar foto/vídeo", openTime: null, closeTime: null, cleanupOnClose: false,
            lastPanelOpen: false, lastCleanupSession: null, highlightEnabled: false, highlightChannelId: null, lastHighlightSession: null,
        } });
        return void await i.update(await buildAnonymousPhotoAdminView(i.guild));
    }
} };
exports.default = component;
