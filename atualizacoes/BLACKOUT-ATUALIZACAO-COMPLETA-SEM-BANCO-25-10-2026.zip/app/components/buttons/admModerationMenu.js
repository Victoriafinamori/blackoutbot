"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderModerationMenu = renderModerationMenu;
exports.renderWarnCategory = renderWarnCategory;
exports.renderMuteCategory = renderMuteCategory;
exports.renderKickCategory = renderKickCategory;
exports.renderBanCategory = renderBanCategory;
exports.renderFiltersMenu = renderFiltersMenu;
exports.renderWordWatchChannelPicker = renderWordWatchChannelPicker;
exports.renderUserPicker = renderUserPicker;
exports.renderFiltersToggles = renderFiltersToggles;
exports.renderFiltersContent = renderFiltersContent;
exports.renderFiltersLimits = renderFiltersLimits;
exports.renderFiltersWordWatch = renderFiltersWordWatch;
const moderationPanel_1 = require("../../utils/moderationPanel");
const panelInteraction_1 = require("../../utils/panelInteraction");
const discord_js_1 = require("discord.js");
const permissions_1 = require("../../utils/permissions");
const adminUi_1 = require("../../utils/adminUi");
const guildConfig_1 = require("../../database/guildConfig");
const prisma_1 = require("../../database/prisma");
const adminLog_1 = require("../../utils/adminLog");
const enums_1 = require("../../structures/enums");
const wordWatch_1 = require("../../utils/wordWatch");
const FILTER_FIELDS = {
    palavras: { label: "Palavras", column: "filterWordsEnabled" },
    links: { label: "Links", column: "filterLinksEnabled" },
    flood: { label: "Flood", column: "filterFloodEnabled" },
    caps: { label: "Caps Lock", column: "filterCapsEnabled" },
    spam: { label: "Spam", column: "filterSpamEnabled" },
    toxicidade: { label: "Toxicidade", column: "filterToxicityEnabled" },
};
// Cada categoria vira sua própria tela — nada de warn/mute/kick/ban
// misturados num único menu "Aplicar Ação".
const MOD_CATEGORIES = [
    { value: "warn", label: "Advertências", emoji: "⚠️", description: "Advertir e limpar advertências" },
    { value: "mute", label: "Mute", emoji: "🔇", description: "Mutar e desmutar membros" },
    { value: "kick", label: "Expulsão", emoji: "👢", description: "Expulsar um membro do servidor" },
    { value: "ban", label: "Banimento", emoji: "🔨", description: "Banir e desbanir membros" },
    { value: "historico", label: "Histórico", emoji: "📜", description: "Ver histórico de moderação de um membro" },
    { value: "filtros", label: "Filtros", emoji: "🧹", description: "Palavras, links, flood, caps, spam e toxicidade" },
];
// Para onde o botão "Voltar" leva depois de escolher um membro (ou aplicar
// a ação), de acordo com o tipo — cada ação volta pra sua própria categoria.
const BACK_TARGETS = {
    warn: "adm-mod:cat:warn",
    clearwarns: "adm-mod:cat:warn",
    mute: "adm-mod:cat:mute",
    unmute: "adm-mod:cat:mute",
    kick: "adm-mod:cat:kick",
    ban: "adm-mod:cat:ban",
    historico: "adm-mod:menu",
};
const ACTION_LABELS = {
    warn: "Advertir",
    mute: "Mutar",
    kick: "Expulsar",
    ban: "Banir",
    unmute: "Desmutar",
    clearwarns: "Limpar Advertências",
    historico: "Ver Histórico",
};
function backRow(customId, label = "Voltar") {
    return new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId(customId).setLabel(label).setStyle(discord_js_1.ButtonStyle.Secondary));
}
async function replyOrUpdate(interaction, payload) {
    return (0, panelInteraction_1.refreshPanel)(interaction, { content: null, ...payload, allowedMentions: { parse: [] } });
}
async function renderModerationMenu(interaction) { return (0, moderationPanel_1.renderMemberModeration)(interaction); }
async function renderWarnCategory(interaction) {
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "seguranca"))
        .setTitle("⚠️ Advertências")
        .setDescription("Aplique uma advertência ou limpe o histórico de advertências de um membro.");
    const row = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-mod:pick:warn").setLabel("Advertir").setStyle(discord_js_1.ButtonStyle.Danger), new discord_js_1.ButtonBuilder().setCustomId("adm-mod:pick:clearwarns").setLabel("Limpar Advertências").setStyle(discord_js_1.ButtonStyle.Success));
    await interaction.update({ attachments: [], embeds: [embed], components: [row, backRow("adm-mod:menu")] });
}
async function renderMuteCategory(interaction) {
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "seguranca"))
        .setTitle("🔇 Mute")
        .setDescription("Mute ou desmute um membro do servidor.");
    const row = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-mod:pick:mute").setLabel("Mutar").setStyle(discord_js_1.ButtonStyle.Danger), new discord_js_1.ButtonBuilder().setCustomId("adm-mod:pick:unmute").setLabel("Desmutar").setStyle(discord_js_1.ButtonStyle.Success));
    await interaction.update({ attachments: [], embeds: [embed], components: [row, backRow("adm-mod:menu")] });
}
async function renderKickCategory(interaction) {
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "seguranca"))
        .setTitle("👢 Expulsão")
        .setDescription("Expulsa um membro do servidor. Ele pode entrar novamente com um novo convite.");
    const row = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-mod:pick:kick").setLabel("Expulsar").setStyle(discord_js_1.ButtonStyle.Danger));
    await interaction.update({ attachments: [], embeds: [embed], components: [row, backRow("adm-mod:menu")] });
}
async function renderBanCategory(interaction) {
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "seguranca"))
        .setTitle("🔨 Banimento")
        .setDescription("Banir impede o retorno ao servidor até que o membro seja desbanido manualmente.");
    const row = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-mod:pick:ban").setLabel("Banir").setStyle(discord_js_1.ButtonStyle.Danger), new discord_js_1.ButtonBuilder().setCustomId("adm-mod:unban").setLabel("Desbanir").setStyle(discord_js_1.ButtonStyle.Success));
    await interaction.update({ attachments: [], embeds: [embed], components: [row, backRow("adm-mod:menu")] });
}
async function renderUserPicker(interaction, type) {
    const label = ACTION_LABELS[type] ?? type;
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "seguranca"))
        .setTitle(`⚖️ ${label}`)
        .setDescription("Selecione o membro abaixo.");
    const select = new discord_js_1.UserSelectMenuBuilder()
        .setCustomId(`adm-mod-user-select:${type}`)
        .setPlaceholder(`Selecione o membro para: ${label}`)
        .setMinValues(1)
        .setMaxValues(1);
    const selectRow = new discord_js_1.ActionRowBuilder().addComponents(select);
    await interaction.update({ attachments: [], embeds: [embed], components: [selectRow, backRow(BACK_TARGETS[type] ?? "adm-mod:menu")] });
}
async function openUnbanModal(interaction) {
    const modal = new discord_js_1.ModalBuilder().setCustomId("adm-modal:mod:unban").setTitle("Desbanir Membro");
    const userIdInput = new discord_js_1.TextInputBuilder()
        .setCustomId("userId")
        .setLabel("ID do usuário")
        .setStyle(discord_js_1.TextInputStyle.Short)
        .setPlaceholder("Ex: 123456789012345678")
        .setRequired(true)
        .setMinLength(15)
        .setMaxLength(25);
    const reasonInput = new discord_js_1.TextInputBuilder()
        .setCustomId("reason")
        .setLabel("Motivo (opcional)")
        .setStyle(discord_js_1.TextInputStyle.Paragraph)
        .setRequired(false)
        .setMaxLength(300);
    modal.addComponents(new discord_js_1.ActionRowBuilder().addComponents(userIdInput), new discord_js_1.ActionRowBuilder().addComponents(reasonInput));
    await interaction.showModal(modal);
}
// -----------------------------
// Filtros — hub + sub-seções
// -----------------------------
// Antes era uma única tela lotada (status + limites + monitoramento + 5
// fileiras de botão). Agora é um hub com 4 seções focadas, cada uma com
// seu próprio embed e botões relevantes só àquele assunto.
function filtersBackRow() {
    return new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-mod:filtros").setLabel("Voltar aos Filtros").setStyle(discord_js_1.ButtonStyle.Secondary));
}
async function renderFiltersMenu(interaction) {
    const config = await (0, guildConfig_1.getOrCreateGuildConfig)(interaction.guild.id);
    const activeCount = Object.values(FILTER_FIELDS).filter((v) => config[v.column]).length;
    const totalCount = Object.values(FILTER_FIELDS).length;
    const wordRules = await prisma_1.prisma.filterRule.count({ where: { guildId: interaction.guild.id, type: enums_1.FilterRuleType.WORD } });
    const linkRules = await prisma_1.prisma.filterRule.count({
        where: { guildId: interaction.guild.id, type: enums_1.FilterRuleType.LINK_WHITELIST },
    });
    const embed = (0, adminUi_1.adminEmbed)(interaction.guild, "seguranca").setTitle("Proteção automática")
        .setDescription("Configure na ordem: filtros → regras e limites → resposta às violações.")
        .addFields({ name: "Filtros ativos", value: `${activeCount}/${totalCount} · ${Object.values(FILTER_FIELDS).filter(f => config[f.column]).map(f => f.label).join(", ") || "Nenhum"}` }, { name: "Regras de conteúdo", value: `${wordRules} palavras bloqueadas · ${linkRules} domínios permitidos` }, { name: "Resposta às violações", value: { DELETE_ONLY: "Apagar mensagem", WARN: "Apagar e advertir", MUTE: "Apagar e silenciar" }[config.autoModAction] || config.autoModAction }, { name: "Monitoramento de reintegração", value: `${config.wordWatchEnabled ? "Ativado" : "Desativado"} · observa e registra, sem punir.` });
    const me = interaction.guild.members.me;
    if (me && !me.permissions.has("ManageMessages"))
        embed.addFields({ name: "Permissão pendente", value: "O bot precisa de Gerenciar Mensagens para apagar conteúdo. Ajuste a permissão do cargo e dos canais protegidos." });
    const row1 = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-mod:filtros:secao:toggles").setLabel("1. Escolher filtros").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId("adm-mod:filtros:secao:conteudo").setLabel("2. Palavras e links").setStyle(discord_js_1.ButtonStyle.Secondary));
    const row2 = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-mod:filtros:secao:limites").setLabel("3. Limites e resposta").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId("adm-mod:filtros:secao:wordwatch").setLabel("Monitoramento").setStyle(discord_js_1.ButtonStyle.Secondary));
    await replyOrUpdate(interaction, { attachments: [], embeds: [embed], components: [row1, row2, new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("security:home").setLabel("Central de segurança").setStyle(discord_js_1.ButtonStyle.Secondary)), backRow("adm-nav:seguranca")] });
}
// --- Seção 1: Filtros Automáticos (liga/desliga cada filtro) ---
async function renderFiltersToggles(interaction) {
    const config = await (0, guildConfig_1.getOrCreateGuildConfig)(interaction.guild.id);
    const statusLines = Object.entries(FILTER_FIELDS)
        .map(([, v]) => `**${v.label}:** ${config[v.column] ? "Ativado" : "Desativado"}`)
        .join("\n");
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "seguranca"))
        .setTitle("🧩 Filtros Automáticos")
        .setDescription(`Altere um filtro para atualizar o estado nesta embed.\n\n${statusLines}\n\nPalavras: termos bloqueados. Links: endereços externos. Flood: muitas mensagens em sequência. Caps: excesso de maiúsculas. Spam: mensagens repetidas. Toxicidade: pontuação pelas regras do bot.`);
    const row1 = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder()
        .setCustomId("adm-mod:filtros:toggle:palavras")
        .setLabel(`${config.filterWordsEnabled ? "Desativar" : "Ativar"} Palavras`)
        .setStyle(config.filterWordsEnabled ? discord_js_1.ButtonStyle.Success : discord_js_1.ButtonStyle.Danger), new discord_js_1.ButtonBuilder()
        .setCustomId("adm-mod:filtros:toggle:links")
        .setLabel(`${config.filterLinksEnabled ? "Desativar" : "Ativar"} Links`)
        .setStyle(config.filterLinksEnabled ? discord_js_1.ButtonStyle.Success : discord_js_1.ButtonStyle.Danger), new discord_js_1.ButtonBuilder()
        .setCustomId("adm-mod:filtros:toggle:flood")
        .setLabel(`${config.filterFloodEnabled ? "Desativar" : "Ativar"} Flood`)
        .setStyle(config.filterFloodEnabled ? discord_js_1.ButtonStyle.Success : discord_js_1.ButtonStyle.Danger));
    const row2 = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder()
        .setCustomId("adm-mod:filtros:toggle:caps")
        .setLabel(`${config.filterCapsEnabled ? "Desativar" : "Ativar"} Caps Lock`)
        .setStyle(config.filterCapsEnabled ? discord_js_1.ButtonStyle.Success : discord_js_1.ButtonStyle.Danger), new discord_js_1.ButtonBuilder()
        .setCustomId("adm-mod:filtros:toggle:spam")
        .setLabel(`${config.filterSpamEnabled ? "Desativar" : "Ativar"} Spam`)
        .setStyle(config.filterSpamEnabled ? discord_js_1.ButtonStyle.Success : discord_js_1.ButtonStyle.Danger), new discord_js_1.ButtonBuilder()
        .setCustomId("adm-mod:filtros:toggle:toxicidade")
        .setLabel(`${config.filterToxicityEnabled ? "Desativar" : "Ativar"} Toxicidade`)
        .setStyle(config.filterToxicityEnabled ? discord_js_1.ButtonStyle.Success : discord_js_1.ButtonStyle.Danger));
    await replyOrUpdate(interaction, { attachments: [], embeds: [embed], components: [row1, row2, filtersBackRow()] });
}
// --- Seção 2: Palavras & Links (listas e modo de link) ---
async function renderFiltersContent(interaction) {
    const config = await (0, guildConfig_1.getOrCreateGuildConfig)(interaction.guild.id);
    const wordRules = await prisma_1.prisma.filterRule.findMany({
        where: { guildId: interaction.guild.id, type: enums_1.FilterRuleType.WORD },
    });
    const linkRules = await prisma_1.prisma.filterRule.findMany({
        where: { guildId: interaction.guild.id, type: enums_1.FilterRuleType.LINK_WHITELIST },
    });
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "seguranca"))
        .setTitle("📝 Palavras & Links")
        .setDescription(`**Palavras proibidas (${wordRules.length}):** ${wordRules.length ? wordRules.map((r) => `\`${r.value}\``).join(", ") : "*nenhuma*"}\n\n` +
        `**Modo de links:** ${config.filterLinksMode === "WHITELIST" ? "Somente lista permitida" : "Bloquear todos"}\n` +
        `**Domínios permitidos (${linkRules.length}):** ${linkRules.length ? linkRules.map((r) => `\`${r.value}\``).join(", ") : "*nenhum*"}`);
    const row = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-mod:filtros:palavras").setLabel("Editar Palavras").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId("adm-mod:filtros:links").setLabel("Editar Links Permitidos").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId("adm-mod:filtros:linkmode").setLabel("Alternar Modo de Links").setStyle(discord_js_1.ButtonStyle.Secondary));
    await replyOrUpdate(interaction, { attachments: [], embeds: [embed], components: [row, filtersBackRow()] });
}
// --- Seção 3: Limites & Ação (sensibilidade + ação automática) ---
async function renderFiltersLimits(interaction) {
    const config = await (0, guildConfig_1.getOrCreateGuildConfig)(interaction.guild.id);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "seguranca"))
        .setTitle("📐 Limites & Ação")
        .setDescription(`**Resposta ao violar um filtro:** ${{ DELETE_ONLY: "Apagar mensagem", WARN: "Apagar e advertir", MUTE: "Apagar e silenciar" }[config.autoModAction] || config.autoModAction}\n\n` +
        "**Limites de conteúdo**\n" +
        `Caps: ${config.capsThreshold}% (mín. ${config.capsMinLength} caracteres)\n` +
        `Flood: ${config.floodMaxMessages} msgs / ${config.floodIntervalSeconds}s\n` +
        `Spam: ${config.spamMaxDuplicates} mensagens repetidas\n\n` +
        "**Limites de ação**\n" +
        `Toxicidade: score ≥ ${config.toxicityThreshold}\n` +
        `Mute automático: ${config.autoMuteDurationMinutes} min\n` +
        `Advertências p/ mute automático: ${config.maxWarnsBeforeMute || "desativado"}\n` +
        `Advertências p/ ban automático: ${config.maxWarnsBeforeBan || "desativado"}`);
    const row = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-mod:filtros:limites1").setLabel("Limites de Conteúdo").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId("adm-mod:filtros:limites2").setLabel("Limites de Ação").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId("adm-mod:filtros:automod").setLabel("Escolher resposta").setStyle(discord_js_1.ButtonStyle.Secondary));
    await replyOrUpdate(interaction, { attachments: [], embeds: [embed], components: [row, filtersBackRow()] });
}
// --- Seção 4: Monitoramento de Palavras ---
async function renderFiltersWordWatch(interaction) {
    const config = await (0, guildConfig_1.getOrCreateGuildConfig)(interaction.guild.id);
    const watchChannels = (0, wordWatch_1.getWordWatchChannelIds)(config);
    const watchChannelsText = watchChannels.length
        ? watchChannels.map((id) => `<#${id}>`).join(", ")
        : "*nenhum canal selecionado*";
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "seguranca"))
        .setTitle("🔎 Monitoramento de Palavras")
        .setDescription(`**Status:** ${config.wordWatchEnabled ? "✅ ativado" : "❌ desativado"}\n\n` +
        "Observa (sem apagar nem punir) apenas membros em reintegração ativa, " +
        "usando a mesma lista de Palavras Proibidas, e registra ocorrências no " +
        "histórico do membro.\n\n" +
        `**Canais observados (até ${wordWatch_1.MAX_WORD_WATCH_CHANNELS}):** ${watchChannelsText}`);
    const row = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder()
        .setCustomId("adm-mod:filtros:toggle:wordwatch")
        .setLabel(config.wordWatchEnabled ? "Desativar" : "Ativar")
        .setStyle(config.wordWatchEnabled ? discord_js_1.ButtonStyle.Success : discord_js_1.ButtonStyle.Danger), new discord_js_1.ButtonBuilder()
        .setCustomId("adm-mod:filtros:wordwatchchannels")
        .setLabel("Canais Monitorados")
        .setStyle(discord_js_1.ButtonStyle.Secondary));
    await replyOrUpdate(interaction, { attachments: [], embeds: [embed], components: [row, filtersBackRow()] });
}
async function toggleFilter(interaction, key) {
    const field = FILTER_FIELDS[key];
    if (!field)
        return;
    await (0, panelInteraction_1.deferPanel)(interaction);
    const config = await (0, guildConfig_1.getOrCreateGuildConfig)(interaction.guild.id);
    const newValue = !config[field.column];
    await prisma_1.prisma.guildConfig.update({
        where: { guildId: interaction.guild.id },
        data: { [field.column]: newValue },
    });
    await (0, adminLog_1.logAdminAction)({
        guild: interaction.guild,
        actorId: interaction.user.id,
        action: enums_1.AdminLogAction.MODERATION_CONFIG_CHANGED,
        details: `Filtro de ${field.label}: ${newValue ? "ativado" : "desativado"}`,
    });
    await renderFiltersToggles(interaction);
}
async function toggleWordWatch(interaction) {
    await (0, panelInteraction_1.deferPanel)(interaction);
    const config = await (0, guildConfig_1.getOrCreateGuildConfig)(interaction.guild.id);
    const newValue = !config.wordWatchEnabled;
    await prisma_1.prisma.guildConfig.update({
        where: { guildId: interaction.guild.id },
        data: { wordWatchEnabled: newValue },
    });
    await (0, adminLog_1.logAdminAction)({
        guild: interaction.guild,
        actorId: interaction.user.id,
        action: enums_1.AdminLogAction.MODERATION_CONFIG_CHANGED,
        details: `Monitoramento de Palavras: ${newValue ? "ativado" : "desativado"}`,
    });
    await renderFiltersWordWatch(interaction);
}
async function renderWordWatchChannelPicker(interaction) {
    const config = await (0, guildConfig_1.getOrCreateGuildConfig)(interaction.guild.id);
    const current = (0, wordWatch_1.getWordWatchChannelIds)(config);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "seguranca"))
        .setTitle("📡 Canais Monitorados")
        .setDescription(`Selecione até ${wordWatch_1.MAX_WORD_WATCH_CHANNELS} canais de texto para o Monitoramento de Palavras. ` +
        "Apenas mensagens enviadas nesses canais, por membros em reintegração ativa, são observadas.\n\n" +
        `**Atuais:** ${current.length ? current.map((id) => `<#${id}>`).join(", ") : "*nenhum*"}`);
    const select = new discord_js_1.ChannelSelectMenuBuilder()
        .setCustomId("adm-watchchannel-select")
        .setPlaceholder(`Selecione até ${wordWatch_1.MAX_WORD_WATCH_CHANNELS} canais`)
        .addChannelTypes(discord_js_1.ChannelType.GuildText)
        .setMinValues(0)
        .setMaxValues(wordWatch_1.MAX_WORD_WATCH_CHANNELS);
    const existing = current.filter(id => interaction.guild.channels.cache.has(id));
    if (existing.length)
        select.setDefaultChannels(existing);
    const selectRow = new discord_js_1.ActionRowBuilder().addComponents(select);
    await replyOrUpdate(interaction, { attachments: [], embeds: [embed], components: [selectRow, filtersBackRow()] });
}
async function toggleLinkMode(interaction) {
    await (0, panelInteraction_1.deferPanel)(interaction);
    const config = await (0, guildConfig_1.getOrCreateGuildConfig)(interaction.guild.id);
    const newMode = config.filterLinksMode === "WHITELIST" ? "BLOCK_ALL" : "WHITELIST";
    await prisma_1.prisma.guildConfig.update({
        where: { guildId: interaction.guild.id },
        data: { filterLinksMode: newMode },
    });
    await (0, adminLog_1.logAdminAction)({
        guild: interaction.guild,
        actorId: interaction.user.id,
        action: enums_1.AdminLogAction.MODERATION_CONFIG_CHANGED,
        details: `Modo de links: ${newMode}`,
    });
    await renderFiltersContent(interaction);
}
async function cycleAutoModAction(interaction) {
    const config = await (0, guildConfig_1.getOrCreateGuildConfig)(interaction.guild.id);
    const select = new discord_js_1.StringSelectMenuBuilder().setCustomId("adm-automod-select").setPlaceholder("Escolha a resposta às violações").addOptions({ label: "Apagar mensagem", value: enums_1.AutoModAction.DELETE_ONLY, default: config.autoModAction === enums_1.AutoModAction.DELETE_ONLY }, { label: "Apagar e advertir", value: enums_1.AutoModAction.WARN, default: config.autoModAction === enums_1.AutoModAction.WARN }, { label: "Apagar e silenciar", value: enums_1.AutoModAction.MUTE, default: config.autoModAction === enums_1.AutoModAction.MUTE });
    return (0, panelInteraction_1.refreshPanel)(interaction, { content: null, attachments: [], embeds: [(0, adminUi_1.adminEmbed)(interaction.guild, "seguranca").setTitle("Resposta às violações").setDescription("A escolha será salva automaticamente. Advertências podem acionar os limites de silêncio ou banimento configurados.")], components: [new discord_js_1.ActionRowBuilder().addComponents(select), filtersBackRow()] });
}
async function openWordsModal(interaction) {
    const rules = await prisma_1.prisma.filterRule.findMany({
        where: { guildId: interaction.guild.id, type: enums_1.FilterRuleType.WORD },
    });
    const modal = new discord_js_1.ModalBuilder().setCustomId("adm-modal:mod:words").setTitle("Palavras Proibidas");
    const wordsInput = new discord_js_1.TextInputBuilder()
        .setCustomId("words")
        .setLabel("Palavras (separadas por vírgula)")
        .setStyle(discord_js_1.TextInputStyle.Paragraph)
        .setPlaceholder("palavrão1, palavrão2, palavrão3")
        .setValue(rules.length ? rules.map((r) => r.value).join(", ").slice(0, 1000) : " ")
        .setRequired(false)
        .setMaxLength(1000);
    modal.addComponents(new discord_js_1.ActionRowBuilder().addComponents(wordsInput));
    await interaction.showModal(modal);
}
async function openLinksModal(interaction) {
    const rules = await prisma_1.prisma.filterRule.findMany({
        where: { guildId: interaction.guild.id, type: enums_1.FilterRuleType.LINK_WHITELIST },
    });
    const modal = new discord_js_1.ModalBuilder().setCustomId("adm-modal:mod:links").setTitle("Domínios Permitidos");
    const domainsInput = new discord_js_1.TextInputBuilder()
        .setCustomId("domains")
        .setLabel("Domínios (separados por vírgula)")
        .setStyle(discord_js_1.TextInputStyle.Paragraph)
        .setPlaceholder("discord.com, youtube.com, tenor.com")
        .setValue(rules.length ? rules.map((r) => r.value).join(", ").slice(0, 1000) : " ")
        .setRequired(false)
        .setMaxLength(1000);
    modal.addComponents(new discord_js_1.ActionRowBuilder().addComponents(domainsInput));
    await interaction.showModal(modal);
}
async function openThresholds1Modal(interaction) {
    const config = await (0, guildConfig_1.getOrCreateGuildConfig)(interaction.guild.id);
    const modal = new discord_js_1.ModalBuilder().setCustomId("adm-modal:mod:limites1").setTitle("Limites de Conteúdo");
    const fields = [
        ["capsThreshold", "% de caixa alta para acionar", String(config.capsThreshold)],
        ["capsMinLength", "Tamanho mínimo p/ avaliar caps", String(config.capsMinLength)],
        ["floodMaxMessages", "Máx. mensagens (flood)", String(config.floodMaxMessages)],
        ["floodIntervalSeconds", "Intervalo do flood (segundos)", String(config.floodIntervalSeconds)],
        ["spamMaxDuplicates", "Mensagens repetidas = spam", String(config.spamMaxDuplicates)],
    ];
    modal.addComponents(...fields.map(([id, label, value]) => new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder()
        .setCustomId(id)
        .setLabel(label)
        .setStyle(discord_js_1.TextInputStyle.Short)
        .setValue(value)
        .setRequired(true)
        .setMaxLength(5))));
    await interaction.showModal(modal);
}
async function openThresholds2Modal(interaction) {
    const config = await (0, guildConfig_1.getOrCreateGuildConfig)(interaction.guild.id);
    const modal = new discord_js_1.ModalBuilder().setCustomId("adm-modal:mod:limites2").setTitle("Limites de Ação");
    const fields = [
        ["toxicityThreshold", "Score mínimo de toxicidade (0-100)", String(config.toxicityThreshold)],
        ["autoMuteDurationMinutes", "Duração do mute automático (min)", String(config.autoMuteDurationMinutes)],
        ["maxWarnsBeforeMute", "Advertências p/ mute automático (0=off)", String(config.maxWarnsBeforeMute)],
        ["maxWarnsBeforeBan", "Advertências p/ ban automático (0=off)", String(config.maxWarnsBeforeBan)],
    ];
    modal.addComponents(...fields.map(([id, label, value]) => new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder()
        .setCustomId(id)
        .setLabel(label)
        .setStyle(discord_js_1.TextInputStyle.Short)
        .setValue(value)
        .setRequired(true)
        .setMaxLength(6))));
    await interaction.showModal(modal);
}
const component = {
    customId: "adm-mod:",
    async execute(interaction) {
        if (!interaction.guild)
            return;
        const member = await interaction.guild.members.fetch(interaction.user.id);
        if (!(await (0, permissions_1.isBotAdmin)(member))) {
            await interaction.reply({ content: "🚫 Você não tem permissão para acessar esta seção.", ephemeral: true });
            return;
        }
        const parts = interaction.customId.split(":"); // ["adm-mod", "acao", "sub?"]
        const action = parts[1];
        const sub = parts[2];
        switch (action) {
            case "menu":
                return renderModerationMenu(interaction);
            case "cat": {
                if (sub === "warn")
                    return renderWarnCategory(interaction);
                if (sub === "mute")
                    return renderMuteCategory(interaction);
                if (sub === "kick")
                    return renderKickCategory(interaction);
                if (sub === "ban")
                    return renderBanCategory(interaction);
                return renderModerationMenu(interaction);
            }
            case "unban":
                return openUnbanModal(interaction);
            case "pick":
                return renderUserPicker(interaction, sub);
            case "filtros": {
                if (!sub)
                    return renderFiltersMenu(interaction);
                if (sub === "secao") {
                    const section = parts[3];
                    if (section === "toggles")
                        return renderFiltersToggles(interaction);
                    if (section === "conteudo")
                        return renderFiltersContent(interaction);
                    if (section === "limites")
                        return renderFiltersLimits(interaction);
                    if (section === "wordwatch")
                        return renderFiltersWordWatch(interaction);
                    return renderFiltersMenu(interaction);
                }
                if (sub === "toggle") {
                    if (parts[3] === "wordwatch")
                        return toggleWordWatch(interaction);
                    return toggleFilter(interaction, parts[3]);
                }
                if (sub === "linkmode")
                    return toggleLinkMode(interaction);
                if (sub === "automod")
                    return cycleAutoModAction(interaction);
                if (sub === "palavras")
                    return openWordsModal(interaction);
                if (sub === "links")
                    return openLinksModal(interaction);
                if (sub === "limites1")
                    return openThresholds1Modal(interaction);
                if (sub === "limites2")
                    return openThresholds2Modal(interaction);
                if (sub === "wordwatchchannels")
                    return renderWordWatchChannelPicker(interaction);
                return renderFiltersMenu(interaction);
            }
            default:
                return renderModerationMenu(interaction);
        }
    },
};
exports.default = component;
