"use strict";
const { prepareAdminPanel } = require("../../utils/adminTasks");
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderStatsMenu = renderStatsMenu;
exports.renderReintegrationStats = renderReintegrationStats;
exports.renderModerationStats = renderModerationStats;
exports.renderSecurityStats = renderSecurityStats;
exports.renderStaffStats = renderStaffStats;
exports.renderServerStats = renderServerStats;
const discord_js_1 = require("discord.js");
const permissions_1 = require("../../utils/permissions");
const adminUi_1 = require("../../utils/adminUi");
const prisma_1 = require("../../database/prisma");
const enums_1 = require("../../structures/enums");
function backRow(customId, label = "Voltar") {
    return new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId(customId).setLabel(label).setStyle(discord_js_1.ButtonStyle.Secondary));
}
const DAY_MS = 24 * 60 * 60 * 1000;
const STATS_CATEGORIES = [
    { value: "reintegracao", label: "Reintegração", emoji: "👥", description: "Membros ativos, concluídos, por etapa" },
    { value: "moderacao", label: "Moderação", emoji: "⚖️", description: "Advertências, mutes, kicks, bans" },
    { value: "seguranca", label: "Segurança", emoji: "🛡️", description: "Entradas, saídas e ocorrências de auto-mod" },
    { value: "staff", label: "Staff", emoji: "🎖️", description: "Cargos configurados e atividade da equipe" },
    { value: "servidor", label: "Servidor", emoji: "🌐", description: "Membros, canais, cargos e boosts" },
    { value: "ranking", label: "Ranking (Chat)", emoji: "💬", description: "Atividade de mensagens, com reset configurável" },
];
async function renderStatsMenu(interaction) {
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor"))
        .setTitle("📊 Estatísticas")
        .setDescription("Selecione um painel abaixo para ver os números atualizados do servidor.\n\n" +
        "O tempo em voz pode ser consultado em **Comunidade e atividade → Atividade em call**.")
        .addFields({
        name: "📋 Painéis",
        value: STATS_CATEGORIES.map((c) => `${c.emoji} \`${c.label}\` — ${c.description}`).join("\n"),
    });
    const select = new discord_js_1.StringSelectMenuBuilder()
        .setCustomId("adm-stats-select")
        .setPlaceholder("Selecione um painel...")
        .addOptions(STATS_CATEGORIES.map((c) => ({
        value: c.value,
        label: c.label,
        emoji: c.emoji,
        description: c.description,
    })));
    const selectRow = new discord_js_1.ActionRowBuilder().addComponents(select);
    await interaction.update(prepareAdminPanel(interaction.guild, 'estatisticas', { attachments: [], embeds: [embed], components: [selectRow, backRow("adm-nav:servidor")] }));
}
// -----------------------------
// Reintegração
// -----------------------------
async function renderReintegrationStats(interaction) {
    const guildId = interaction.guild.id;
    const [active, completed, removed, blacklisted, evaluations, stages, byStage] = await Promise.all([
        prisma_1.prisma.reintegrationMember.count({ where: { guildId, status: enums_1.MemberStatus.ACTIVE } }),
        prisma_1.prisma.reintegrationMember.count({ where: { guildId, status: enums_1.MemberStatus.COMPLETED } }),
        prisma_1.prisma.reintegrationMember.count({ where: { guildId, status: enums_1.MemberStatus.REMOVED } }),
        prisma_1.prisma.blacklist.count({ where: { guildId } }),
        prisma_1.prisma.evaluation.groupBy({ by: ["approved"], where: { guildId }, _count: { _all: true } }),
        prisma_1.prisma.stage.findMany({ where: { guildId }, orderBy: { order: "asc" } }),
        prisma_1.prisma.reintegrationMember.groupBy({
            by: ["currentStageId"],
            where: { guildId, status: enums_1.MemberStatus.ACTIVE },
            _count: { _all: true },
        }),
    ]);
    const approved = evaluations.find((e) => e.approved)?._count._all ?? 0;
    const reproved = evaluations.find((e) => !e.approved)?._count._all ?? 0;
    const stageCounts = new Map(byStage.map((b) => [b.currentStageId, b._count._all]));
    const stageLines = stages.length
        ? stages
            .map((s) => `**${s.name}** — ${stageCounts.get(s.id) ?? 0} membro(s)`)
            .join("\n")
        : "*Nenhuma etapa cadastrada.*";
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor"))
        .setTitle("👥 Estatísticas — Reintegração")
        .addFields({ name: "Ativos", value: String(active), inline: true }, { name: "Concluídos", value: String(completed), inline: true }, { name: "Removidos", value: String(removed), inline: true }, { name: "Na blacklist", value: String(blacklisted), inline: true }, { name: "Avaliações aprovadas", value: String(approved), inline: true }, { name: "Avaliações reprovadas", value: String(reproved), inline: true }, { name: "Distribuição por etapa (ativos)", value: stageLines });
    await interaction.update({ attachments: [], embeds: [embed], components: [backRow("adm-stats:menu")] });
}
// -----------------------------
// Moderação
// -----------------------------
async function renderModerationStats(interaction) {
    const guildId = interaction.guild.id;
    const [warnsActive, warnsTotal, mutesActive, mutesTotal, kicks, bans, unbans, automodTotal, automod7d] = await Promise.all([
        prisma_1.prisma.warn.count({ where: { guildId, active: true } }),
        prisma_1.prisma.warn.count({ where: { guildId } }),
        prisma_1.prisma.mute.count({ where: { guildId, active: true } }),
        prisma_1.prisma.mute.count({ where: { guildId } }),
        prisma_1.prisma.moderationAction.count({ where: { guildId, type: enums_1.ModerationActionType.KICK } }),
        prisma_1.prisma.moderationAction.count({ where: { guildId, type: enums_1.ModerationActionType.BAN } }),
        prisma_1.prisma.moderationAction.count({ where: { guildId, type: enums_1.ModerationActionType.UNBAN } }),
        prisma_1.prisma.adminLog.count({ where: { guildId, action: enums_1.AdminLogAction.AUTO_MOD_TRIGGERED } }),
        prisma_1.prisma.adminLog.count({
            where: {
                guildId,
                action: enums_1.AdminLogAction.AUTO_MOD_TRIGGERED,
                createdAt: { gte: new Date(Date.now() - 7 * DAY_MS) },
            },
        }),
    ]);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor"))
        .setTitle("⚖️ Estatísticas — Moderação")
        .addFields({ name: "Advertências ativas", value: String(warnsActive), inline: true }, { name: "Advertências (histórico)", value: String(warnsTotal), inline: true }, { name: "Mutes ativos", value: String(mutesActive), inline: true }, { name: "Mutes (histórico)", value: String(mutesTotal), inline: true }, { name: "Expulsões (kick)", value: String(kicks), inline: true }, { name: "Banimentos", value: String(bans), inline: true }, { name: "Desbanimentos", value: String(unbans), inline: true }, { name: "Violações de filtro (auto-mod)", value: String(automodTotal), inline: true }, { name: "Violações nos últimos 7 dias", value: String(automod7d), inline: true });
    await interaction.update({ attachments: [], embeds: [embed], components: [backRow("adm-stats:menu")] });
}
// -----------------------------
// Segurança
// -----------------------------
async function renderSecurityStats(interaction) {
    const guildId = interaction.guild.id;
    const since7d = new Date(Date.now() - 7 * DAY_MS);
    const since30d = new Date(Date.now() - 30 * DAY_MS);
    const [joins7d, joins30d, leaves7d, leaves30d, automodTotal, banExternalTotal] = await Promise.all([
        prisma_1.prisma.adminLog.count({ where: { guildId, action: enums_1.AdminLogAction.MEMBER_JOINED, createdAt: { gte: since7d } } }),
        prisma_1.prisma.adminLog.count({ where: { guildId, action: enums_1.AdminLogAction.MEMBER_JOINED, createdAt: { gte: since30d } } }),
        prisma_1.prisma.adminLog.count({ where: { guildId, action: enums_1.AdminLogAction.MEMBER_LEFT, createdAt: { gte: since7d } } }),
        prisma_1.prisma.adminLog.count({ where: { guildId, action: enums_1.AdminLogAction.MEMBER_LEFT, createdAt: { gte: since30d } } }),
        prisma_1.prisma.adminLog.count({ where: { guildId, action: enums_1.AdminLogAction.AUTO_MOD_TRIGGERED, createdAt: { gte: since30d } } }),
        prisma_1.prisma.adminLog.count({
            where: {
                guildId,
                action: { in: [enums_1.AdminLogAction.MEMBER_BANNED_EXTERNAL, enums_1.AdminLogAction.MEMBER_UNBANNED_EXTERNAL] },
                createdAt: { gte: since30d },
            },
        }),
    ]);
    const net30d = joins30d - leaves30d;
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor"))
        .setTitle("🛡️ Estatísticas — Segurança")
        .addFields({ name: "Entradas (7 dias)", value: String(joins7d), inline: true }, { name: "Saídas (7 dias)", value: String(leaves7d), inline: true }, { name: "Saldo (7 dias)", value: String(joins7d - leaves7d), inline: true }, { name: "Entradas (30 dias)", value: String(joins30d), inline: true }, { name: "Saídas (30 dias)", value: String(leaves30d), inline: true }, { name: "Saldo (30 dias)", value: String(net30d), inline: true }, { name: "Ocorrências de auto-mod (30 dias)", value: String(automodTotal), inline: true });
    if (banExternalTotal > 0) {
        embed.addFields({ name: "Bans/unbans externos (30 dias)", value: String(banExternalTotal), inline: true });
    }
    await interaction.update({ attachments: [], embeds: [embed], components: [backRow("adm-stats:menu")] });
}
// -----------------------------
// Staff
// -----------------------------
async function renderStaffStats(interaction) {
    const guildId = interaction.guild.id;
    const [botAdmins, permissionRoles, topActors] = await Promise.all([
        prisma_1.prisma.botAdmin.count({ where: { guildId } }),
        prisma_1.prisma.permissionRole.count({ where: { guildId } }),
        prisma_1.prisma.adminLog.groupBy({
            by: ["actorId"],
            where: {
                guildId,
                action: { notIn: [enums_1.AdminLogAction.MEMBER_JOINED, enums_1.AdminLogAction.MEMBER_LEFT, enums_1.AdminLogAction.BOT_STARTED] },
            },
            _count: { _all: true },
            orderBy: { _count: { actorId: "desc" } },
            take: 5,
        }),
    ]);
    const ranking = topActors.length
        ? topActors
            .map((t, i) => `**${i + 1}.** <@${t.actorId}> — ${t._count._all} ação(ões)`)
            .join("\n")
        : "*Nenhuma ação administrativa registrada ainda.*";
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor"))
        .setTitle("🎖️ Estatísticas — Staff")
        .addFields({ name: "Cargos de Administrador do BOT", value: String(botAdmins), inline: true }, { name: "Cargos de permissão configurados", value: String(permissionRoles), inline: true }, { name: "Staff mais ativa (todas as ações)", value: ranking });
    await interaction.update({ attachments: [], embeds: [embed], components: [backRow("adm-stats:menu")] });
}
// -----------------------------
// Servidor
// -----------------------------
async function renderServerStats(interaction) {
    const guild = interaction.guild;
    await guild.members.fetch().catch(() => null);
    const humans = guild.members.cache.filter((m) => !m.user.bot).size;
    const bots = guild.members.cache.filter((m) => m.user.bot).size;
    const embed = (await (0, adminUi_1.adminEmbed)(guild, "servidor"))
        .setTitle("🌐 Estatísticas — Servidor")
        .addFields({ name: "Membros (total)", value: String(guild.memberCount), inline: true }, { name: "Humanos", value: String(humans), inline: true }, { name: "Bots", value: String(bots), inline: true }, { name: "Canais", value: String(guild.channels.cache.size), inline: true }, { name: "Cargos", value: String(guild.roles.cache.size), inline: true }, { name: "Boosts", value: `${guild.premiumSubscriptionCount ?? 0} (nível ${guild.premiumTier})`, inline: true }, { name: "Servidor criado em", value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:D>`, inline: true });
    await interaction.update({ attachments: [], embeds: [embed], components: [backRow("adm-stats:menu")] });
}
const component = {
    customId: "adm-stats:",
    async execute(interaction) {
        if (!interaction.guild)
            return;
        const member = await interaction.guild.members.fetch(interaction.user.id);
        if (!(await (0, permissions_1.isBotAdmin)(member))) {
            await interaction.reply({
                content: "🚫 Você não tem permissão para acessar esta seção.",
                ephemeral: true,
            });
            return;
        }
        const action = interaction.customId.split(":")[1];
        switch (action) {
            case "menu":
                return renderStatsMenu(interaction);
            case "reintegracao":
                return renderReintegrationStats(interaction);
            case "moderacao":
                return renderModerationStats(interaction);
            case "seguranca":
                return renderSecurityStats(interaction);
            case "staff":
                return renderStaffStats(interaction);
            case "servidor":
                return renderServerStats(interaction);
            default:
                return renderStatsMenu(interaction);
        }
    },
};
exports.default = component;
//# sourceMappingURL=admStatsMenu.js.map