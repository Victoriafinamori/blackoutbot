"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderBingoMenu = renderBingoMenu;
exports.renderBingoStart = renderBingoStart;
exports.renderBingoCardsChannel = renderBingoCardsChannel;
exports.renderBingoEndConfirm = renderBingoEndConfirm;
const { prepareAdminPanel } = require("../../utils/adminTasks");
const discord_js_1 = require("discord.js");
const adminUi_1 = require("../../utils/adminUi");
const permissions_1 = require("../../utils/permissions");
const admEmojis_1 = require("../../utils/admEmojis");
const service_1 = require("../../bingo/service");
const views_1 = require("../../bingo/views");
const RED = 0xd71935;
const button = (customId, label, style = discord_js_1.ButtonStyle.Secondary) => new discord_js_1.ButtonBuilder().setCustomId(customId).setLabel(label).setStyle(style);
function nav(customId, placeholder, options) {
    return new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.StringSelectMenuBuilder()
        .setCustomId(customId)
        .setPlaceholder(placeholder)
        .addOptions(options));
}
// -----------------------------------------------------------------------
// Tela principal — "Configurações do Bingo"
// -----------------------------------------------------------------------
async function renderBingoMenu(interaction) {
    const icon = (0, admEmojis_1.admEmoji)(interaction.guild, "campeonatos");
    const match = await (0, service_1.getCurrentMatch)(interaction.guild.id);
    const draws = match ? await (0, service_1.getDraws)(match.id) : [];
    const community = match
        ? await require("../../database/prisma").prisma.bingoExperienceState.findUnique({ where: { matchId: match.id } })
        : null;
    const communityStatus = {
        LOBBY: "Inscrições abertas",
        RUNNING: "Em andamento",
        PAUSED: "Pausada",
        REVIEW: "Conferência de vencedores",
        ENDED: "Encerrada",
    };
    const info = match
        ? `Partida atual: **#${String(match.number).padStart(3, "0")}**\n` +
            `Canal: **<#${match.channelId}>**\n` +
            `Status: **${community ? communityStatus[community.phase] : match.status === "EM_ANDAMENTO" ? "Em andamento" : "Pausada"}**\n` +
            `Números sorteados: **${draws.length}/75**`
        : "Nenhuma partida em andamento no momento.";
    const cfg = await (0, service_1.getBingoConfig)(interaction.guild.id);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "staff"))
        .setColor(RED)
        .setTitle("Configurações do Bingo")
        .addFields({
        name: "ℹ️ Informações",
        value: `${info}\nPainel de cartelas: **${cfg.cardPanelChannelId ? `<#${cfg.cardPanelChannelId}>` : "N/A"}**`,
    }, {
        name: "Observações",
        value: "1. Iniciar uma nova partida só é possível se não houver outra em andamento.\n" +
            "2. O modo comunitário tem inscrições gratuitas, cartela no servidor e controles privados da equipe.\n" +
            "3. Pausar/retomar/encerrar por aqui atualiza automaticamente o painel publicado no canal.\n" +
            "4. As cartelas só podem ser retiradas antes do sorteio da partida começar.",
    });
    const options = [
        {
            label: "Voltar",
            value: "back",
            description: "Retornar para Jogos e eventos",
            emoji: "↩️",
        },
        {
            label: "Iniciar com cartelas do servidor",
            value: "start",
            description: "Escolher o canal e publicar o painel",
            emoji: icon,
        },
        {
            label: "Painel de cartelas",
            value: "cards",
            description: "Publicar onde a galera pega a cartela",
            emoji: icon,
        },
    ];
    if (match) {
        options.push({
            label: match.status === "PAUSADA" ? "Retomar partida" : "Pausar partida",
            value: "toggle",
            description: "Controla o sorteio sem abrir o painel público",
            emoji: icon,
        }, {
            label: "Encerrar partida",
            value: "end",
            description: "Finaliza a partida atual",
            emoji: icon,
        });
    }
    await interaction.update(prepareAdminPanel(interaction.guild, "bingo", {
        attachments: [],
        embeds: [embed],
        components: [
            nav("bingo-admin-nav", "O que deseja configurar?", options),
            new discord_js_1.ActionRowBuilder().addComponents(button("bg-admin:home", "Bingo comunitário e dinâmica", discord_js_1.ButtonStyle.Primary)),
        ],
    }));
}
// -----------------------------------------------------------------------
// Iniciar partida (escolha de canal)
// -----------------------------------------------------------------------
async function renderBingoStart(interaction) {
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "staff"))
        .setColor(RED)
        .setTitle("Iniciar Partida de Bingo")
        .setDescription("Selecione o canal onde o painel da partida será publicado.");
    const select = new discord_js_1.ChannelSelectMenuBuilder()
        .setCustomId("bingo-admin-start-channel")
        .setPlaceholder("Selecione um canal...")
        .addChannelTypes(discord_js_1.ChannelType.GuildText)
        .setMinValues(1)
        .setMaxValues(1);
    await interaction.update({
        attachments: [],
        embeds: [embed],
        components: [
            new discord_js_1.ActionRowBuilder().addComponents(select),
            new discord_js_1.ActionRowBuilder().addComponents(button("adm-bingo:menu", "Voltar")),
        ],
    });
}
// -----------------------------------------------------------------------
// Painel de cartelas (escolha de canal)
// -----------------------------------------------------------------------
async function renderBingoCardsChannel(interaction) {
    const cfg = await (0, service_1.getBingoConfig)(interaction.guild.id);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "staff"))
        .setColor(RED)
        .setTitle("Painel de Cartelas")
        .setDescription("Selecione o canal onde o painel de compra de cartelas será publicado.")
        .addFields({
        name: "Canal atual",
        value: cfg.cardPanelChannelId ? `<#${cfg.cardPanelChannelId}>` : "N/A",
    }, {
        name: "Categoria do ticket de compra",
        value: cfg.cardTicketCategoryId
            ? `<#${cfg.cardTicketCategoryId}>`
            : "Padrão (usa a categoria configurada no sistema de Tickets)",
    }, {
        name: "Preços atuais",
        value: `${cfg.price1Qty} cartela — **${cfg.price1Text}**\n${cfg.price3Qty} cartelas — **${cfg.price3Text}**\n${cfg.price10Qty} cartelas — **${cfg.price10Text}**`,
    }, {
        name: "Personalização atual",
        value: `Título: **${cfg.cardEmbedTitle || "padrão"}**\n` +
            `Banner: **${cfg.cardEmbedImage ? "definido" : "padrão"}**\n` +
            `Thumbnail: **${cfg.cardEmbedThumbnail ? "definido" : "padrão"}**\n` +
            `Cor: **${cfg.cardEmbedColor ? `#${cfg.cardEmbedColor}` : "padrão"}**`,
    });
    const select = new discord_js_1.ChannelSelectMenuBuilder()
        .setCustomId("bingo-admin-cards-channel")
        .setPlaceholder("Canal do painel de compra...")
        .addChannelTypes(discord_js_1.ChannelType.GuildText)
        .setMinValues(1)
        .setMaxValues(1);
    const categorySelect = new discord_js_1.ChannelSelectMenuBuilder()
        .setCustomId("bingo-admin-cards-category")
        .setPlaceholder("Categoria onde abrir o ticket de compra...")
        .addChannelTypes(discord_js_1.ChannelType.GuildCategory)
        .setMinValues(1)
        .setMaxValues(1);
    await interaction.update({
        attachments: [],
        embeds: [embed],
        components: [
            new discord_js_1.ActionRowBuilder().addComponents(select),
            new discord_js_1.ActionRowBuilder().addComponents(categorySelect),
            new discord_js_1.ActionRowBuilder().addComponents(button("adm-bingo:prices", "Preços e pagamento", discord_js_1.ButtonStyle.Primary), button("adm-bingo:customize-embed", "Personalizar embed (banner/thumbnail)", discord_js_1.ButtonStyle.Primary), button("adm-bingo:cards-category-reset", "Usar categoria padrão dos Tickets"), button("adm-bingo:menu", "Voltar")),
        ],
    });
}
// -----------------------------------------------------------------------
// Confirmação de encerramento
// -----------------------------------------------------------------------
async function renderBingoEndConfirm(interaction) {
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "staff"))
        .setColor(RED)
        .setDescription("**Deseja realmente encerrar a partida atual?**");
    await interaction.update({
        attachments: [],
        embeds: [embed],
        components: [
            new discord_js_1.ActionRowBuilder().addComponents(button("adm-bingo:end-confirm", "Confirmar", discord_js_1.ButtonStyle.Danger), button("adm-bingo:menu", "Cancelar")),
        ],
    });
}
// -----------------------------------------------------------------------
// Modal — preços e instruções de pagamento
// -----------------------------------------------------------------------
function buildPricesModal(cfg) {
    const field = (id, label, style, value, required = true) => {
        const input = new discord_js_1.TextInputBuilder()
            .setCustomId(id)
            .setLabel(label)
            .setStyle(style)
            .setRequired(required);
        if (value)
            input.setValue(value);
        return new discord_js_1.ActionRowBuilder().addComponents(input);
    };
    return new discord_js_1.ModalBuilder()
        .setCustomId("bingo-admin-modal:prices")
        .setTitle("Preços e pagamento")
        .addComponents(field("price1", "Preço — 1 cartela", discord_js_1.TextInputStyle.Short, cfg.price1Text), field("price3", "Preço — 3 cartelas", discord_js_1.TextInputStyle.Short, cfg.price3Text), field("price10", "Preço — 10 cartelas", discord_js_1.TextInputStyle.Short, cfg.price10Text), field("payment", "Instruções de pagamento (chave PIX etc.)", discord_js_1.TextInputStyle.Paragraph, cfg.paymentInstructions, false));
}
// -----------------------------------------------------------------------
// Modal — personalização da embed do painel de cartelas
// -----------------------------------------------------------------------
function buildCardEmbedModal(cfg) {
    const field = (id, label, style, value, required = false) => {
        const input = new discord_js_1.TextInputBuilder()
            .setCustomId(id)
            .setLabel(label)
            .setStyle(style)
            .setRequired(required);
        if (value)
            input.setValue(value);
        return new discord_js_1.ActionRowBuilder().addComponents(input);
    };
    return new discord_js_1.ModalBuilder()
        .setCustomId("bingo-admin-modal:card-embed")
        .setTitle("Personalizar embed das cartelas")
        .addComponents(field("title", "Título (em branco = padrão)", discord_js_1.TextInputStyle.Short, cfg.cardEmbedTitle), field("description", "Descrição (em branco = padrão)", discord_js_1.TextInputStyle.Paragraph, cfg.cardEmbedDescription), field("image", "URL do banner (imagem grande)", discord_js_1.TextInputStyle.Short, cfg.cardEmbedImage), field("thumbnail", "URL da thumbnail (imagem pequena)", discord_js_1.TextInputStyle.Short, cfg.cardEmbedThumbnail), field("color", "Cor em hex, sem # (ex: D20B20)", discord_js_1.TextInputStyle.Short, cfg.cardEmbedColor));
}
// -----------------------------------------------------------------------
// Botões: adm-bingo:<ação>
// -----------------------------------------------------------------------
const component = {
    customId: "adm-bingo:",
    async execute(interaction) {
        if (!interaction.guild ||
            !(await (0, permissions_1.isBotAdmin)(await interaction.guild.members.fetch(interaction.user.id)))) {
            await interaction.reply({
                content: "🚫 Sem permissão.",
                ephemeral: true,
            });
            return;
        }
        const [, action] = interaction.customId.split(":");
        if (action === "menu")
            return renderBingoMenu(interaction);
        if (action === "prices") {
            const cfg = await (0, service_1.getBingoConfig)(interaction.guild.id);
            await interaction.showModal(buildPricesModal(cfg));
            return;
        }
        if (action === "customize-embed") {
            const cfg = await (0, service_1.getBingoConfig)(interaction.guild.id);
            await interaction.showModal(buildCardEmbedModal(cfg));
            return;
        }
        if (action === "cards-category-reset") {
            await (0, service_1.updateBingoConfig)(interaction.guild.id, {
                cardTicketCategoryId: null,
            });
            return renderBingoCardsChannel(interaction);
        }
        if (action === "end-confirm") {
            const match = await (0, service_1.getCurrentMatch)(interaction.guild.id);
            if (match) {
                await (0, service_1.endMatch)(match.id);
                await (0, views_1.refreshMatchPanel)(interaction.guild, match.id);
            }
            return renderBingoMenu(interaction);
        }
    },
};
exports.default = component;
