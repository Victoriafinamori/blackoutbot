"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const registration_1 = require("../../utils/registration");
const registrationUi_1 = require("../../utils/registrationUi");
const prisma_1 = require("../../database/prisma");
const component = { customId: "registration-nav:", async execute(i) { if (!i.guild)
        return; const [, action, owner] = i.customId.split(":"); await i.deferUpdate(); if (owner !== i.user.id) {
        await i.followUp({ content: "Somente o registrador desta sessão pode navegar.", flags: discord_js_1.MessageFlags.Ephemeral });
        return;
    } const s = registration_1.sessions.get(owner); if (!s || s.guildId !== i.guild.id) {
        await i.editReply({ content: "Sessão expirada. Execute `/registrar` novamente.", embeds: [], components: [] });
        return;
    } const pages = await prisma_1.prisma.registrationPage.findMany({ where: { guildId: i.guild.id }, orderBy: { order: "asc" } }); if (action === "cancel") {
        registration_1.sessions.delete(owner);
        await i.editReply({ content: "Registro cancelado.", embeds: [], components: [] });
        return;
    } if (action === "prev") {
        s.page = Math.max(0, s.page - 1);
        await i.editReply((await (0, registrationUi_1.prettyRegistrationView)(i.guild, owner)));
        return;
    } if (action === "next") {
        const p = pages[s.page];
        if (p?.required && !(s.answers[p.id]?.length)) {
            await i.followUp({ content: "Selecione ao menos um cargo nesta página.", flags: discord_js_1.MessageFlags.Ephemeral });
            return;
        }
        s.page++;
        await i.editReply(s.page >= pages.length ? await (0, registrationUi_1.prettyConfirmationView)(i.guild, owner) : (await (0, registrationUi_1.prettyRegistrationView)(i.guild, owner)));
        return;
    } if (action === "finish") {
        const missing = pages.find(p => p.required && !(s.answers[p.id]?.length));
        if (missing) {
            await i.followUp({ content: `A página “${missing.name}” ainda precisa ser respondida.`, flags: discord_js_1.MessageFlags.Ephemeral });
            return;
        }
        await i.editReply(await (0, registrationUi_1.prettyConfirmationView)(i.guild, owner));
        return;
    } if (action === "confirm") {const missingRequired = pages.find(p => p.required && !(s.answers[p.id]?.length)); if (missingRequired) { await i.followUp({content:`Responda à página “${missingRequired.name}” antes de concluir.`,ephemeral:true}); return; }
        await i.editReply({ content: "Finalizando registro, aplicando cargos e gerando transcript...", embeds: [], components: [] });
        try {
            const r = await (0, registration_1.finishRegistration)(i.guild, owner);
            await i.editReply({ content: r.test ? "Teste concluído sem alterar cargos." : `Registro concluído com sucesso: **${r.id}**`, embeds: [], components: [] });
        }
        catch (e) {
            console.error("[registration-confirm]", e);
            await i.editReply({ content: `Não foi possível concluir o registro: ${e.message}`, embeds: [], components: [] });
        }
    } } };
exports.default = component;
//# sourceMappingURL=registrationNav.js.map