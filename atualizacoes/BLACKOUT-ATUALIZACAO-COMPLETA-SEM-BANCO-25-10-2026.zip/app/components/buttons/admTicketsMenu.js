"use strict";
const { prepareAdminPanel } = require("../../utils/adminTasks");
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderTicketsMenu = renderTicketsMenu;
exports.renderTicketAlerts = renderTicketAlerts;
exports.renderTicketSettings = renderTicketSettings;
exports.renderTicketRegister = renderTicketRegister;
exports.renderTicketManager = renderTicketManager;
exports.renderTicketRatings = renderTicketRatings;
exports.renderTicketChannels = renderTicketChannels;
exports.renderTicketRoles = renderTicketRoles;
exports.renderTicketBehavior = renderTicketBehavior;
exports.renderTicketExternal = renderTicketExternal;
exports.renderTicketMode = renderTicketMode;
const discord_js_1 = require("discord.js");
const adminUi_1 = require("../../utils/adminUi");
const permissions_1 = require("../../utils/permissions");
const tickets_1 = require("../../utils/tickets");
const prisma_1 = require("../../database/prisma");
const admEmojis_1 = require("../../utils/admEmojis");
const RED = 0xd71935;
const yesNo = (value) => (value ? "Sim" : "Não");
const roles = (value) => (0, tickets_1.ids)(value).map(id => `<@&${id}>`).join(", ") || "N/A";
const button = (customId, label, style = discord_js_1.ButtonStyle.Secondary) => new discord_js_1.ButtonBuilder().setCustomId(customId).setLabel(label).setStyle(style);
function nav(customId, placeholder, options) {
    return new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.StringSelectMenuBuilder().setCustomId(customId).setPlaceholder(placeholder).addOptions(options));
}
async function renderTicketsMenu(interaction) {
    const icon = (0, admEmojis_1.admEmoji)(interaction.guild, "tickets");
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "atendimento"))
        .setColor(RED)
        .setTitle("Central de Tickets")
        .setDescription("Configure e gerencie o atendimento do servidor por uma área de cada vez. Selecione uma opção abaixo para continuar.")
        .addFields({ name: "Configurações", value: "Logs, marcações, trava, motivos e relatórios externos.", inline: true }, { name: "Cadastrar ticket", value: "Escolha o canal e publique o painel de atendimento.", inline: true }, { name: "Gerenciar tickets", value: "Categoria, responsáveis, aparência e funcionamento.", inline: true }, { name: "Avaliação e ranking", value: "Feedback no chat do ticket e desempenho da equipe.", inline: true }, { name: "Alertas de atendimento", value: "Prazos, lembretes, escalonamento e horário de pausa.", inline: true });
    await interaction.update(prepareAdminPanel(interaction.guild, 'tickets', { attachments: [], embeds: [embed], components: [nav("ticket-admin-nav", "Selecione uma área dos tickets", [
                { label: "Voltar", value: "back", description: "Retornar para Atendimento", emoji: "↩️" },
                { label: "Configurações", value: "settings", description: "Logs, permissões e comportamento", emoji: icon },
                { label: "Cadastrar ticket", value: "register", description: "Definir onde o painel será enviado", emoji: icon },
                { label: "Gerenciar tickets", value: "manage", description: "Editar painel, categoria e responsáveis", emoji: icon },
                { label: "Avaliação e ranking", value: "ratings", description: "Feedback e desempenho dos atendimentos", emoji: icon },
                { label: "Alertas de atendimento", value: "alerts", description: "Monitorar tickets aguardando a staff", emoji: "⚠️" },
            ])] }));
}
async function renderTicketAlerts(interaction) {
    const c = await (0, tickets_1.ticketConfig)(interaction.guild.id);
    const destination = c.alertDestination === "DM" ? "DM do responsável" : c.alertDestination === "BOTH" ? "Canal e DM" : "Canal configurado";
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "atendimento")).setColor(RED).setTitle("Alertas de Atendimento")
        .setDescription("Monitore automaticamente tickets em que o membro respondeu e ainda aguarda retorno da equipe.")
        .addFields({ name: "Status do Sistema", value: c.alertsEnabled ? "**Ativado**" : "**Desativado**", inline: true }, { name: "Destino dos Alertas", value: `**${destination}**`, inline: true }, { name: "Canal de Alertas", value: c.alertChannelId ? `<#${c.alertChannelId}>` : "Não configurado", inline: true }, { name: "Tempo para Alerta", value: `**${c.alertAfterMinutes} minutos**`, inline: true }, { name: "Repetição", value: c.alertRepeatEnabled ? `A cada **${c.alertRepeatMinutes} minutos**` : "Desativada", inline: true }, { name: "Escalonamento", value: `Após **${c.escalationAfterMinutes} minutos**`, inline: true }, { name: "Cargo de Escalonamento", value: c.escalationRoleId ? `<@&${c.escalationRoleId}>` : "Não configurado", inline: true }, { name: "Ignorar Período", value: c.alertQuietEnabled ? `**${c.alertQuietStart} até ${c.alertQuietEnd}**` : "Desativado", inline: true }, { name: "Funcionamento", value: "🟠 **Aguardando Staff:** o membro foi o último a responder.\n🟡 **Aguardando Usuário:** a staff respondeu e o contador foi encerrado." });
    const destinationSelect = new discord_js_1.StringSelectMenuBuilder().setCustomId("ticket-alert-destination").setPlaceholder("Destino dos alertas").addOptions({ label: "Canal configurado", value: "CHANNEL", default: c.alertDestination === "CHANNEL" }, { label: "DM do responsável", value: "DM", default: c.alertDestination === "DM" }, { label: "Canal e DM", value: "BOTH", default: c.alertDestination === "BOTH" });
    const channelSelect = new discord_js_1.ChannelSelectMenuBuilder().setCustomId("ticket-alert-channel").setPlaceholder("Canal de alertas").addChannelTypes(discord_js_1.ChannelType.GuildText, discord_js_1.ChannelType.GuildAnnouncement).setMinValues(0).setMaxValues(1);
    const roleSelect = new discord_js_1.RoleSelectMenuBuilder().setCustomId("ticket-alert-role").setPlaceholder("Cargo de escalonamento").setMinValues(0).setMaxValues(1);
    await interaction.update({ attachments: [], embeds: [embed], components: [
            new discord_js_1.ActionRowBuilder().addComponents(destinationSelect),
            new discord_js_1.ActionRowBuilder().addComponents(channelSelect),
            new discord_js_1.ActionRowBuilder().addComponents(roleSelect),
            new discord_js_1.ActionRowBuilder().addComponents(button("adm-ticket:alert-toggle:alertsEnabled", c.alertsEnabled ? "Desativar sistema" : "Ativar sistema", c.alertsEnabled ? discord_js_1.ButtonStyle.Danger : discord_js_1.ButtonStyle.Success), button("adm-ticket:alert-toggle:alertRepeatEnabled", c.alertRepeatEnabled ? "Desativar repetição" : "Ativar repetição"), button("adm-ticket:alert-toggle:alertQuietEnabled", c.alertQuietEnabled ? "Desativar pausa" : "Ativar pausa")),
            new discord_js_1.ActionRowBuilder().addComponents(button("adm-ticket:alert-times", "Configurar tempos", discord_js_1.ButtonStyle.Primary), button("adm-ticket:menu", "Voltar")),
        ] });
}
async function renderTicketSettings(interaction) {
    const c = await (0, tickets_1.ticketConfig)(interaction.guild.id);
    const total = await prisma_1.prisma.ticket.count({ where: { guildId: interaction.guild.id } });
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "atendimento")).setColor(RED).setTitle("Configurações dos Tickets").addFields({ name: "ℹ️ Informações", value: `Canal de Logs: **${c.logChannelId ? `<#${c.logChannelId}>` : "N/A"}**\nMarcar membro/staff: **${yesNo(c.pingMember)} / ${yesNo(c.pingStaff)}**\nMotivo ao fechar: **Não solicitado**\nTickets Configurados: **${total} tickets**\nTrava Ticket: **${c.lockToClaimer ? "Somente quem assumiu" : "N/A"}**` }, { name: "Observações", value: "1. Defina se membro e staff serão marcados ao abrir.\n2. Torne obrigatório informar o motivo ao fechar.\n3. Restrinja o fechamento a quem assumiu, mantendo cargos imunes.\n4. Relatórios podem continuar sendo enviados para outro servidor." });
    await interaction.update({ attachments: [], embeds: [embed], components: [nav("ticket-admin-settings-nav", "O que deseja configurar?", [
                { label: "Voltar", value: "back" },
                { label: "Canais", value: "channels", description: "Logs, feedback e relatórios" },
                { label: "Cargos e permissões", value: "roles", description: "Responsáveis, imunes e relatórios" },
                { label: "Marcações e regras", value: "behavior", description: "Pings, motivo e trava do ticket" },
                { label: "Relatórios externos", value: "external", description: "Envio dos quatro tipos para outro servidor" },
                { label: "Resetar tudo", value: "reset", description: "Restaurar as configurações padrão" },
            ])] });
}
async function renderTicketRegister(interaction) {
    const c = await (0, tickets_1.ticketConfig)(interaction.guild.id);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "atendimento")).setColor(RED).setTitle("Cadastrar Ticket")
        .setDescription("Selecione o canal em que será enviado o painel deste ticket.")
        .addFields({ name: "Canal selecionado", value: c.panelChannelId ? `<#${c.panelChannelId}>` : "N/A" });
    const channel = new discord_js_1.ChannelSelectMenuBuilder().setCustomId("ticket-admin-panel-channel").setPlaceholder("Selecione um canal...").addChannelTypes(discord_js_1.ChannelType.GuildText).setMinValues(1).setMaxValues(1);
    await interaction.update({ attachments: [], embeds: [embed], components: [new discord_js_1.ActionRowBuilder().addComponents(channel), new discord_js_1.ActionRowBuilder().addComponents(button("adm-ticket:menu", "Voltar"))] });
}
async function renderTicketManager(interaction) {
    const c = await (0, tickets_1.ticketConfig)(interaction.guild.id);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "atendimento")).setColor(RED).setTitle("Gerenciador de Tickets")
        .addFields({ name: "ℹ️ Informações", value: `Canal Painel: **${c.panelChannelId ? `<#${c.panelChannelId}>` : "N/A"}**\nCategoria: **${c.categoryId ? `<#${c.categoryId}>` : "N/A"}**\nCargos Responsáveis: **${roles(c.staffRoleIds)}**` }, { name: "🛠️ Personalizar", value: `Usar Tópico: **${yesNo(c.useThreads)}**\nUsar botão: **${yesNo(c.useButton)}**\nMenus de Seleção: **N/A**` }, { name: "Observações", value: "Você pode usar tópicos ou canal de texto para o ticket, além de botão ou menu de seleção. As opções atuais do bot foram preservadas." });
    await interaction.update({ attachments: [], embeds: [embed], components: [nav("ticket-admin-manager-nav", "Selecione uma ação para gerenciar", [
                { label: "Voltar", value: "back" },
                { label: "Canal e categoria", value: "channels", description: "Local do painel e categoria dos tickets" },
                { label: "Cargos responsáveis", value: "roles", description: "Equipe autorizada e cargos imunes" },
                { label: "Formato de abertura", value: "mode", description: "Tópico/canal e botão/menu" },
                { label: "Embed do painel", value: "panelAppearance", description: "Textos, botão, HEX, thumbnail, imagem e rodapé" },
                { label: "Embed interna", value: "internalAppearance", description: "Textos, HEX, thumbnail, imagem e rodapé" },
                { label: "Publicar/Atualizar painel", value: "publish", description: "Enviar o painel no canal configurado" },
            ])] });
}
async function renderTicketRatings(interaction) {
    const c = await (0, tickets_1.ticketConfig)(interaction.guild.id);
    const ratings = await prisma_1.prisma.ticketRating.findMany({ where: { guildId: interaction.guild.id } });
    const average = ratings.length ? (ratings.reduce((sum, item) => sum + item.stars, 0) / ratings.length).toFixed(1) : "N/A";
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "atendimento")).setColor(RED).setTitle("Avaliação e Ranking — Tickets")
        .setDescription("Ative ou desative o sistema de avaliações dos atendimentos nos tickets.")
        .addFields({ name: "Como funciona?", value: "Ao finalizar o atendimento, o feedback aparece **no chat do ticket**. O membro escolhe as estrelas e digita sua avaliação; o resultado segue para o canal configurado." }, { name: "Status", value: `Sistema: **${c.ratingsEnabled ? "Ativado" : "Desativado"}**\nCanal de feedback: **${c.feedbackChannelId ? `<#${c.feedbackChannelId}>` : "N/A"}**\nAvaliações recebidas: **${ratings.length}**\nMédia geral: **${average}${ratings.length ? "/5" : ""}**` }, { name: "Configuração", value: "Esta configuração é aplicada a todos os tickets criados por este painel." });
    await interaction.update({ attachments: [], embeds: [embed], components: [nav("ticket-admin-ratings-nav", "Configure avaliação e ranking", [
                { label: "Voltar", value: "back" },
                { label: c.ratingsEnabled ? "Desativar avaliações" : "Ativar avaliações", value: "toggle" },
                { label: "Canal de feedback", value: "channel", description: "Escolher onde as avaliações serão enviadas" },
                { label: "Atualizar ranking", value: "refresh", description: "Recalcular os números exibidos" },
            ])] });
}
async function renderTicketChannels(interaction, manager = false) {
    const fields = manager
        ? [["panelChannelId", "Canal do painel", [discord_js_1.ChannelType.GuildText]], ["categoryId", "Categoria dos tickets", [discord_js_1.ChannelType.GuildCategory]]]
        : [["logChannelId", "Canal de logs", [discord_js_1.ChannelType.GuildText]], ["feedbackChannelId", "Canal de feedback", [discord_js_1.ChannelType.GuildText]], ["reportChannelId", "Canal de relatórios", [discord_js_1.ChannelType.GuildText]]];
    const rows = fields.map(([key, label, types]) => new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ChannelSelectMenuBuilder().setCustomId(`ticket-channel:${key}`).setPlaceholder(label).addChannelTypes(...types).setMinValues(0).setMaxValues(1)));
    await interaction.update({ attachments: [], embeds: [(await (0, adminUi_1.adminEmbed)(interaction.guild, "atendimento")).setColor(RED).setTitle(manager ? "Canal e Categoria" : "Canais dos Tickets").setDescription("Escolha os canais abaixo. Uma seleção vazia remove a configuração.")], components: [...rows, new discord_js_1.ActionRowBuilder().addComponents(button(manager ? "adm-ticket:manager" : "adm-ticket:settings", "Voltar"))] });
}
async function renderTicketRoles(interaction, manager = false) {
    const definitions = manager ? [["staffRoleIds", "Cargos responsáveis"], ["immuneRoleIds", "Cargos imunes à trava"]] : [["staffRoleIds", "Cargos responsáveis"], ["immuneRoleIds", "Cargos imunes à trava"], ["reportRoleIds", "Cargos que geram relatórios"]];
    const rows = definitions.map(([key, label]) => new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.RoleSelectMenuBuilder().setCustomId(`ticket-role:${key}`).setPlaceholder(label).setMinValues(0).setMaxValues(10)));
    await interaction.update({ attachments: [], embeds: [(await (0, adminUi_1.adminEmbed)(interaction.guild, "atendimento")).setColor(RED).setTitle("Cargos e Permissões")], components: [...rows, new discord_js_1.ActionRowBuilder().addComponents(button(manager ? "adm-ticket:manager" : "adm-ticket:settings", "Voltar"))] });
}
async function renderTicketBehavior(interaction) {
    const c = await (0, tickets_1.ticketConfig)(interaction.guild.id);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "atendimento")).setColor(RED).setTitle("Marcações e Regras")
        .setDescription("Altere as regras abaixo sem sair desta página.")
        .addFields({ name: "Estado atual", value: `Marcar membro: **${yesNo(c.pingMember)}**\nMarcar staff: **${yesNo(c.pingStaff)}**\nMotivo ao fechar: **Não solicitado**\nTrava do ticket: **${yesNo(c.lockToClaimer)}**` });
    await interaction.update({ attachments: [], embeds: [embed], components: [
            new discord_js_1.ActionRowBuilder().addComponents(button("adm-ticket:toggle-behavior:pingMember", `Membro: ${yesNo(c.pingMember)}`, c.pingMember ? discord_js_1.ButtonStyle.Success : discord_js_1.ButtonStyle.Secondary), button("adm-ticket:toggle-behavior:pingStaff", `Staff: ${yesNo(c.pingStaff)}`, c.pingStaff ? discord_js_1.ButtonStyle.Success : discord_js_1.ButtonStyle.Secondary), button("adm-ticket:toggle-behavior:lockToClaimer", `Trava: ${yesNo(c.lockToClaimer)}`, c.lockToClaimer ? discord_js_1.ButtonStyle.Success : discord_js_1.ButtonStyle.Secondary)),
            new discord_js_1.ActionRowBuilder().addComponents(button("adm-ticket:settings", "Voltar")),
        ] });
}
async function renderTicketExternal(interaction) {
    const c = await (0, tickets_1.ticketConfig)(interaction.guild.id);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "atendimento")).setColor(RED).setTitle("Relatórios Externos")
        .setDescription("Ative o sistema de relatórios e, opcionalmente, envie cada tipo para outro servidor.")
        .addFields({ name: "Sistema de relatórios", value: `Relatórios: **${yesNo(c.reportsEnabled)}**\nEnvio para outro servidor: **${yesNo(c.externalReportsEnabled)}**` })
        .addFields({ name: "Destino", value: `Envio externo: **${yesNo(c.externalReportsEnabled)}**\nServidor: **${c.reportTargetGuildId || "N/A"}**\nJustificativa: **${c.reportJustificationChannelId || "N/A"}**\nTroca de conta: **${c.reportAccountChangeChannelId || "N/A"}**\nTroca de nome: **${c.reportNameChangeChannelId || "N/A"}**\nBenefício VIP/Patrocínio: **${c.reportVipSponsorshipChannelId || "N/A"}**\nOutros: **${c.reportOtherChannelId || "N/A"}**` });
    await interaction.update({ attachments: [], embeds: [embed], components: [new discord_js_1.ActionRowBuilder().addComponents(button("adm-ticket:toggle-external:reportsEnabled", c.reportsEnabled ? "Desativar relatórios" : "Ativar relatórios", c.reportsEnabled ? discord_js_1.ButtonStyle.Danger : discord_js_1.ButtonStyle.Success), button("adm-ticket:toggle-external:externalReportsEnabled", c.externalReportsEnabled ? "Desativar envio" : "Ativar envio", c.externalReportsEnabled ? discord_js_1.ButtonStyle.Danger : discord_js_1.ButtonStyle.Success), button("adm-ticket-external:configure", "Destinos principais", discord_js_1.ButtonStyle.Primary), button("adm-ticket-external:configure-extra", "VIP e outros", discord_js_1.ButtonStyle.Secondary), button("adm-ticket:settings", "Voltar"))] });
}
async function renderTicketMode(interaction) {
    const c = await (0, tickets_1.ticketConfig)(interaction.guild.id);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "atendimento")).setColor(RED).setTitle("Formato de Abertura")
        .setDescription("Escolha como os atendimentos serão criados. As alterações permanecem nesta página.")
        .addFields({ name: "Estado atual", value: `Usar tópico: **${yesNo(c.useThreads)}**\nUsar botão: **${yesNo(c.useButton)}**\nMenu de seleção: **N/A**` });
    await interaction.update({ attachments: [], embeds: [embed], components: [new discord_js_1.ActionRowBuilder().addComponents(button("adm-ticket:toggle-manager:useThreads", `Usar tópico: ${yesNo(c.useThreads)}`, c.useThreads ? discord_js_1.ButtonStyle.Success : discord_js_1.ButtonStyle.Secondary), button("adm-ticket:toggle-manager:useButton", `Usar botão: ${yesNo(c.useButton)}`, c.useButton ? discord_js_1.ButtonStyle.Success : discord_js_1.ButtonStyle.Secondary), button("adm-ticket:manager", "Voltar"))] });
}
const component = { customId: "adm-ticket:", async execute(interaction) {
        if (!interaction.guild || !(await (0, permissions_1.isBotAdmin)(await interaction.guild.members.fetch(interaction.user.id))))
            return void await interaction.reply({ content: "Sem permissão.", ephemeral: true });
        const [, action, arg] = interaction.customId.split(":");
        if (action === "menu")
            return renderTicketsMenu(interaction);
        if (action === "settings")
            return renderTicketSettings(interaction);
        if (action === "manager")
            return renderTicketManager(interaction);
        if (action === "ratings")
            return renderTicketRatings(interaction);
        if (action === "alerts")
            return renderTicketAlerts(interaction);
        if (action === "alert-toggle") {
            const c = await (0, tickets_1.ticketConfig)(interaction.guild.id);
            await prisma_1.prisma.ticketConfig.update({ where: { guildId: interaction.guild.id }, data: { [arg]: !c[arg] } });
            return renderTicketAlerts(interaction);
        }
        if (action === "alert-times") {
            const c = await (0, tickets_1.ticketConfig)(interaction.guild.id);
            const modal = new discord_js_1.ModalBuilder().setCustomId("ticket-alert-times").setTitle("Tempos dos alertas").addComponents(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("first").setLabel("Primeiro alerta (minutos)").setStyle(discord_js_1.TextInputStyle.Short).setValue(String(c.alertAfterMinutes)).setRequired(true)), new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("repeat").setLabel("Repetição (minutos)").setStyle(discord_js_1.TextInputStyle.Short).setValue(String(c.alertRepeatMinutes)).setRequired(true)), new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("escalation").setLabel("Escalonamento (minutos)").setStyle(discord_js_1.TextInputStyle.Short).setValue(String(c.escalationAfterMinutes)).setRequired(true)), new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("quietStart").setLabel("Início da pausa (HH:MM)").setStyle(discord_js_1.TextInputStyle.Short).setValue(c.alertQuietStart).setRequired(true)), new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("quietEnd").setLabel("Fim da pausa (HH:MM)").setStyle(discord_js_1.TextInputStyle.Short).setValue(c.alertQuietEnd).setRequired(true)));
            return void await interaction.showModal(modal);
        }
        if (action === "toggle") {
            const c = await (0, tickets_1.ticketConfig)(interaction.guild.id);
            await prisma_1.prisma.ticketConfig.update({ where: { guildId: interaction.guild.id }, data: { [arg]: !c[arg] } });
            return renderTicketSettings(interaction);
        }
        if (action === "toggle-behavior") {
            const c = await (0, tickets_1.ticketConfig)(interaction.guild.id);
            await prisma_1.prisma.ticketConfig.update({ where: { guildId: interaction.guild.id }, data: { [arg]: !c[arg] } });
            return renderTicketBehavior(interaction);
        }
        if (action === "toggle-external") {
            const c = await (0, tickets_1.ticketConfig)(interaction.guild.id);
            await prisma_1.prisma.ticketConfig.update({ where: { guildId: interaction.guild.id }, data: { [arg]: !c[arg] } });
            return renderTicketExternal(interaction);
        }
        if (action === "toggle-manager") {
            const c = await (0, tickets_1.ticketConfig)(interaction.guild.id);
            await prisma_1.prisma.ticketConfig.update({ where: { guildId: interaction.guild.id }, data: { [arg]: !c[arg] } });
            return renderTicketMode(interaction);
        }
        if (action === "reset-confirm") {
            await prisma_1.prisma.ticketConfig.delete({ where: { guildId: interaction.guild.id } }).catch(() => null);
            await (0, tickets_1.ticketConfig)(interaction.guild.id);
            return renderTicketSettings(interaction);
        }
        if (action === "publish") {
            await interaction.deferReply({ ephemeral: true });
            await (0, tickets_1.publishTicketPanel)(interaction.guild);
            await interaction.editReply("Painel de tickets publicado/atualizado.");
            return;
        }
        if (action === "customize") {
            const c = await (0, tickets_1.ticketConfig)(interaction.guild.id);
            const modal = new discord_js_1.ModalBuilder().setCustomId("ticket-modal:customize").setTitle("Personalizar painel e ticket");
            const values = [["panelTitle", "Título do painel", c.panelTitle], ["panelDescription", "Descrição do painel", c.panelDescription], ["panelButtonLabel", "Texto do botão", c.panelButtonLabel], ["internalTitle", "Título interno", c.internalTitle], ["internalDescription", "Descrição interna", c.internalDescription]];
            modal.addComponents(...values.map(([id, label, value]) => new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId(id).setLabel(label).setStyle(id.includes("Description") ? discord_js_1.TextInputStyle.Paragraph : discord_js_1.TextInputStyle.Short).setValue(value).setRequired(true))));
            await interaction.showModal(modal);
        }
    } };
exports.default = component;
//# sourceMappingURL=admTicketsMenu.js.map