"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.moduleDm = moduleDm;
exports.renderNotificationPanel = renderNotificationPanel;
const discord_js_1 = require("discord.js");
const guildConfig_1 = require("../../database/guildConfig");
const prisma_1 = require("../../database/prisma");
const permissions_1 = require("../../utils/permissions");
const adminUi_1 = require("../../utils/adminUi");
const configurationChecks_1 = require("../../utils/configurationChecks");
const panelInteraction_1 = require("../../utils/panelInteraction");
function moduleDm(config, module) {
    return (module === "moderacao" ? config.moderationNotifyDm : config.reintegrationNotifyDm) ?? config.notifyDm;
}
async function renderNotificationPanel(i, module, notice) {
    const c = await (0, guildConfig_1.getOrCreateGuildConfig)(i.guild.id), mod = module === "moderacao";
    const embed = (0, adminUi_1.adminEmbed)(i.guild, mod ? "seguranca" : "membros").setTitle(mod ? "Avisos de moderação" : "Mensagens de reintegração")
        .setDescription(mod ? "Defina as mensagens enviadas aos membros e o destino dos avisos públicos de moderação." : "Defina se os participantes recebem as mensagens de reintegração por DM.")
        .addFields({ name: "DMs deste módulo", value: `${moduleDm(c, module) ? "Ativadas" : "Desativadas"}\nO envio depende de o membro permitir mensagens diretas.` });
    if (mod)
        embed.addFields({ name: "Avisos públicos de moderação", value: `${c.notifyPublicWarns ? "Ativados" : "Desativados"}\nDestino: ${c.reportsChannelId ? `<#${c.reportsChannelId}>` : "Não definido. Escolha um canal antes de ativar."}` });
    if (notice)
        embed.addFields({ name: "Resultado", value: notice.slice(0, 1024) });
    const buttons = [new discord_js_1.ButtonBuilder().setCustomId(`adm-notify:${module}:dm`).setLabel(moduleDm(c, module) ? "Desativar DMs" : "Ativar DMs").setStyle(discord_js_1.ButtonStyle.Secondary)];
    const rows = [];
    if (mod) {
        const select = new discord_js_1.ChannelSelectMenuBuilder().setCustomId("notice-channel-select:moderacao").setPlaceholder("Canal dos avisos públicos").addChannelTypes(discord_js_1.ChannelType.GuildText, discord_js_1.ChannelType.GuildAnnouncement).setMinValues(0).setMaxValues(1);
        if (c.reportsChannelId && i.guild.channels.cache.has(c.reportsChannelId))
            select.setDefaultChannels([c.reportsChannelId]);
        rows.push(new discord_js_1.ActionRowBuilder().addComponents(select));
        buttons.push(new discord_js_1.ButtonBuilder().setCustomId("adm-notify:moderacao:public").setLabel(c.notifyPublicWarns ? "Desativar avisos públicos" : "Ativar avisos públicos").setStyle(discord_js_1.ButtonStyle.Secondary).setDisabled(!c.notifyPublicWarns && !c.reportsChannelId));
    }
    rows.push(new discord_js_1.ActionRowBuilder().addComponents(buttons));
    rows.push(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId(mod ? "adm-mod:menu" : "adm-reint:menu").setLabel("Voltar").setStyle(discord_js_1.ButtonStyle.Secondary)));
    return (0, panelInteraction_1.refreshPanel)(i, { content: null, attachments: [], embeds: [embed], components: rows });
}
const component = { customId: "adm-notify:", async execute(i) {
        if (!i.guild || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return;
        const [, module, action] = i.customId.split(":");
        if (module !== "moderacao" && module !== "reintegracao")
            return;
        if (!action)
            return renderNotificationPanel(i, module);
        const c = await (0, guildConfig_1.getOrCreateGuildConfig)(i.guild.id);
        if (action !== "dm" && !(action === "public" && module === "moderacao"))
            return;
        if (action === "public" && !c.notifyPublicWarns) {
            if (!c.reportsChannelId)
                return renderNotificationPanel(i, module, "Escolha um canal para os avisos públicos.");
            const check = await (0, configurationChecks_1.writableChannel)(i.guild, c.reportsChannelId, false);
            if (check.issue)
                return renderNotificationPanel(i, module, check.issue);
        }
        await (0, panelInteraction_1.deferPanel)(i);
        const data = action === "public" ? { notifyPublicWarns: !c.notifyPublicWarns } : module === "moderacao" ? { moderationNotifyDm: !moduleDm(c, module) } : { reintegrationNotifyDm: !moduleDm(c, module) };
        await prisma_1.prisma.guildConfig.update({ where: { guildId: i.guild.id }, data });
        return renderNotificationPanel(i, module, "Alteração salva neste servidor.");
    } };
exports.default = component;
