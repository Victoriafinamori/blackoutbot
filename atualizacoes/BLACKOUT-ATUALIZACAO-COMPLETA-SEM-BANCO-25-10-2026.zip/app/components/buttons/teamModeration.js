"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const moderationPanel_1 = require("../../utils/moderationPanel");
exports.default = { customId: "team-mod:", execute: moderationPanel_1.executeModerationPanel };
