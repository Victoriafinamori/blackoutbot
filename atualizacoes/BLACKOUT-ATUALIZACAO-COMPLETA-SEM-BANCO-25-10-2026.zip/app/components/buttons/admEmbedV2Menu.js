"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderEmbedHub = renderEmbedHub;
exports.renderEmbedList = renderEmbedList;
exports.buildEmbedEditorPayload = buildEmbedEditorPayload;
exports.buildEmbedPreviewPayload = buildEmbedPreviewPayload;
exports.renderEmbedEditor = renderEmbedEditor;
exports.renderEmbedButtons = renderEmbedButtons;
exports.openEmbedPart = openEmbedPart;
const discord_js_1 = require("discord.js");
const adminUi_1 = require("../../utils/adminUi");
const permissions_1 = require("../../utils/permissions");
const prisma_1 = require("../../database/prisma");
const guildConfig_1 = require("../../database/guildConfig");
const customEmbeds_1 = require("../../utils/customEmbeds");
const embedPublication_1 = require("../../utils/embedPublication");
const configurationChecks_1 = require("../../utils/configurationChecks");
const panelInteraction_1 = require("../../utils/panelInteraction");
const button = (id, label, style = discord_js_1.ButtonStyle.Secondary) => new discord_js_1.ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style);
const row = (...items) => new discord_js_1.ActionRowBuilder().addComponents(items);
const input = (id, label, value, max, paragraph = false, required = false) => {
    const f = new discord_js_1.TextInputBuilder().setCustomId(id).setLabel(label).setStyle(paragraph ? discord_js_1.TextInputStyle.Paragraph : discord_js_1.TextInputStyle.Short).setRequired(required).setMaxLength(max);
    if (value)
        f.setValue(value);
    return new discord_js_1.ActionRowBuilder().addComponents(f);
};
async function renderEmbedHub(i) { return require("../../message-maker/interactions").openHome(i); }
async function renderEmbedList(i, page = 0) {
    page = Math.max(0, Math.floor(Number(page) || 0));
    const total = await prisma_1.prisma.customEmbed.count({ where: { guildId: i.guild.id } });
    page = Math.min(page, Math.max(0, Math.ceil(total / 25) - 1));
    const records = await prisma_1.prisma.customEmbed.findMany({ where: { guildId: i.guild.id }, orderBy: { updatedAt: "desc" }, skip: page * 25, take: 25 });
    const rows = [];
    if (records.length)
        rows.push(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.StringSelectMenuBuilder().setCustomId("embedv2-select:open").setPlaceholder("Escolha a mensagem para editar").addOptions(records.map(r => ({ label: r.name.slice(0, 100), value: r.id, description: (r.title || "Sem título").slice(0, 100) })))));
    rows.push(row(button(`embedv2:list:${page - 1}`, "Anterior").setDisabled(page === 0), button(`embedv2:list:${page + 1}`, "Próxima").setDisabled((page + 1) * 25 >= total), button("embedv2:create", "Nova mensagem", discord_js_1.ButtonStyle.Primary)), row(button("embedv2:hub", "Voltar")));
    return (0, panelInteraction_1.refreshPanel)(i, { content: null, attachments: [], embeds: [(0, adminUi_1.adminEmbed)(i.guild, "sistema").setTitle("Mensagens salvas").setDescription(total ? "Escolha uma mensagem. As alterações ficam salvas no modelo antes da publicação." : "Você ainda não criou mensagens. Use Nova mensagem para começar.").setFooter({ text: `Página ${page + 1}/${Math.max(1, Math.ceil(total / 25))} · ${total} mensagens` })], components: rows });
}
async function buildEmbedEditorPayload(guild, record, requestedPage = 0) {
    const preview = (0, customEmbeds_1.buildCustomEmbedMessage)(record, guild.id);
    const pages = Math.max(1, Math.ceil(preview.components.length / 2));
    const page = Math.min(Math.max(0, Math.floor(Number(requestedPage) || 0)), pages - 1);
    const check = record.destinationChannelId ? await (0, configurationChecks_1.writableChannel)(guild, record.destinationChannelId) : { issue: "Escolha um canal de destino." };
    const ready = (0, embedPublication_1.hasMessageContent)(record) && !check.issue;
    const edit = new discord_js_1.StringSelectMenuBuilder().setCustomId(`embedv2-edit-select:${record.id}`).setPlaceholder("Escolha uma parte da mensagem").addOptions({ label: "1. Conteúdo", value: "text", description: "Título, descrição, autor e rodapé" }, { label: "2. Imagens e cor", value: "visual", description: "Imagem, miniatura, cor e data da mensagem" }, { label: "3. Botões", value: "buttons", description: "Links e atalhos para canais" }, { label: "4. Canal de destino", value: "destination", description: "Onde a mensagem será publicada" });
    const controls = [];
    if (pages > 1)
        controls.push(button(`embedv2:editor:${record.id}:${page - 1}`, "Botões anteriores").setDisabled(page === 0), button(`embedv2:editor:${record.id}:${page + 1}`, "Mais botões").setDisabled(page === pages - 1));
    controls.push(button(`embedv2:publish:${record.id}`, record.publishedMessageId && record.publishedChannelId === record.destinationChannelId ? "Atualizar publicação" : "Publicar", discord_js_1.ButtonStyle.Primary).setDisabled(!ready), button(`embedv2:more:${record.id}`, "Mais opções"), button("embedv2:hub", "Voltar"));
    const issues = [!(0, embedPublication_1.hasMessageContent)(record) ? "Adicione um título, texto ou imagem antes de publicar." : null, check.issue].filter(Boolean);
    const destination = record.destinationChannelId ? `<#${record.destinationChannelId}>` : "não definido";
    const buttonsNote = record.buttons.length > 10 ? `\nBotões: página ${page + 1}/${pages}. A publicação inclui todos os ${record.buttons.length}.` : "";
    const changeDestination = record.publishedMessageId && record.publishedChannelId !== record.destinationChannelId ? "\nO novo destino criará uma publicação lá; a mensagem anterior será preservada." : "";
    return { content: `**Editar · ${record.name}**\n${(0, embedPublication_1.publicationState)(record)} · Destino: ${destination}${buttonsNote}${changeDestination}${issues.length ? "\n" + issues.join(" ") : ""}`.slice(0, 1800), attachments: [], embeds: preview.embeds,
        components: [...preview.components.slice(page * 2, page * 2 + 2), new discord_js_1.ActionRowBuilder().addComponents(edit), row(button(`embedv2:preview:${record.id}`, "Ver prévia")), row(...controls)], allowedMentions: { parse: [] } };
}
function buildEmbedPreviewPayload(guild, record, requestedPage = 0) {
    const preview = (0, customEmbeds_1.buildCustomEmbedMessage)(record, guild.id);
    const pages = Math.max(1, Math.ceil(preview.components.length / 2));
    const page = Math.min(Math.max(0, Math.floor(Number(requestedPage) || 0)), pages - 1);
    const controls = [];
    if (pages > 1)
        controls.push(button(`embedv2:preview:${record.id}:${page - 1}`, "Botões anteriores").setDisabled(page === 0), button(`embedv2:preview:${record.id}:${page + 1}`, "Mais botões").setDisabled(page === pages - 1));
    controls.push(button(`embedv2:editor:${record.id}`, "Voltar ao editor"));
    return { content: `**Prévia · ${record.name}**${pages > 1 ? `\nBotões: página ${page + 1}/${pages}.` : ""}`, attachments: [], embeds: preview.embeds,
        components: [...preview.components.slice(page * 2, page * 2 + 2), row(...controls)], allowedMentions: { parse: [] } };
}
async function renderEmbedEditor(i, id, page = 0) {
    await (0, panelInteraction_1.deferPanel)(i);
    const record = await (0, customEmbeds_1.fetchCustomEmbed)(id, i.guild.id);
    if (!record)
        return renderEmbedHub(i);
    return (0, panelInteraction_1.refreshPanel)(i, await buildEmbedEditorPayload(i.guild, record, page));
}
async function renderEmbedButtons(i, id) {
    const record = await (0, customEmbeds_1.fetchCustomEmbed)(id, i.guild.id);
    if (!record)
        return renderEmbedHub(i);
    const preview = (0, customEmbeds_1.buildCustomEmbedMessage)(record, i.guild.id), rows = [...preview.components.slice(0, 2)];
    if (record.buttons.length)
        rows.push(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.StringSelectMenuBuilder().setCustomId(`embedv2-btn-select:${id}`).setPlaceholder("Editar, mover ou remover um botão").addOptions(record.buttons.slice(0, 25).map((b, n) => ({ label: `${n + 1}. ${b.label}`.slice(0, 100), value: b.id, description: b.type === "CHANNEL" ? "Canal do Discord" : "Link externo" })))));
    rows.push(row(button(`embedv2:add-link:${id}`, "Adicionar link", discord_js_1.ButtonStyle.Primary).setDisabled(record.buttons.length >= 25), button(`embedv2:add-channel:${id}`, "Adicionar canal").setDisabled(record.buttons.length >= 25), button(`embedv2:editor:${id}`, "Voltar")));
    return (0, panelInteraction_1.refreshPanel)(i, { content: `**Botões · ${record.name}**\n${(0, embedPublication_1.publicationState)(record)} · ${record.buttons.length}/25 botões salvos.${record.buttons.length > 10 ? " Os primeiros dez aparecem aqui; todos serão publicados." : ""}`, attachments: [], embeds: preview.embeds, components: rows, allowedMentions: { parse: [] } });
}
async function openEmbedPart(i, record, action) {
    const id = record.id;
    if (action === "text")
        return i.showModal(new discord_js_1.ModalBuilder().setCustomId(`embedv2-modal:text:${id}`).setTitle("Conteúdo da mensagem").addComponents(input("title", "Título", record.title, 256), input("description", "Descrição", record.description, 4000, true), input("author", "Autor — vazio para remover", record.author, 256), input("footer", "Rodapé — vazio para remover", record.footer, 1000)));
    if (action === "visual")
        return i.showModal(new discord_js_1.ModalBuilder().setCustomId(`embedv2-modal:visual:${id}`).setTitle("Imagens e cor").addComponents(input("color", "Cor hexadecimal", (0, customEmbeds_1.normalizeHex)(record.color), 7, false, true), input("image", "URL da imagem — vazio para remover", record.imageUrl, 500), input("thumbnail", "URL da miniatura — vazio para remover", record.thumbnailUrl, 500), input("timestamp", "Mostrar data/hora? sim ou não", record.showTimestamp ? "sim" : "não", 3, false, true)));
    if (action === "buttons")
        return renderEmbedButtons(i, id);
    if (action === "destination") {
        const select = new discord_js_1.ChannelSelectMenuBuilder().setCustomId(`embedv2-channel:destination:${id}`).setPlaceholder("Canal onde a mensagem será publicada").addChannelTypes(discord_js_1.ChannelType.GuildText, discord_js_1.ChannelType.GuildAnnouncement).setMinValues(1).setMaxValues(1);
        if (record.destinationChannelId && i.guild.channels.cache.has(record.destinationChannelId))
            select.setDefaultChannels([record.destinationChannelId]);
        return (0, panelInteraction_1.refreshPanel)(i, { content: `**Canal de destino · ${record.name}**\nA escolha será conferida antes de salvar.`, attachments: [], embeds: (0, customEmbeds_1.buildCustomEmbedMessage)(record, i.guild.id).embeds, components: [new discord_js_1.ActionRowBuilder().addComponents(select), row(button(`embedv2:editor:${id}`, "Voltar"))], allowedMentions: { parse: [] } });
    }
}
exports.default = { customId: "embedv2:", async execute(i) {
        if (!i.guild || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return i.reply({ content: "Você não possui permissão neste servidor.", ephemeral: true });
        const [, action, id, extra] = i.customId.split(":");
        if (action === "hub")
            return renderEmbedHub(i);
        if (action === "list")
            return renderEmbedList(i, Number(id) || 0);
        if (action === "create") {
            await (0, panelInteraction_1.deferPanel)(i);
            await (0, guildConfig_1.getOrCreateGuildConfig)(i.guild.id);
            const record = await prisma_1.prisma.customEmbed.create({ data: { guildId: i.guild.id, createdById: i.user.id, name: "Nova mensagem", color: "D71935" } });
            return renderEmbedEditor(i, record.id);
        }
        const record = id ? await (0, customEmbeds_1.fetchCustomEmbed)(id, i.guild.id) : null;
        if (!record)
            return renderEmbedHub(i);
        if (action === "editor")
            return renderEmbedEditor(i, id, Number(extra) || 0);
        if (action === "preview") {
            await (0, panelInteraction_1.deferPanel)(i);
            return (0, panelInteraction_1.refreshPanel)(i, buildEmbedPreviewPayload(i.guild, record, Number(extra) || 0));
        }
        if (["text", "visual", "buttons", "destination"].includes(action))
            return openEmbedPart(i, record, action);
        if (action === "publish") {
            if (!(0, embedPublication_1.hasMessageContent)(record))
                return i.reply({ content: "Adicione um título, texto ou imagem antes de publicar.", ephemeral: true });
            if (!record.destinationChannelId)
                return i.reply({ content: "Escolha primeiro o canal de destino.", ephemeral: true });
            await (0, panelInteraction_1.deferPanel)(i);
            const check = await (0, configurationChecks_1.writableChannel)(i.guild, record.destinationChannelId);
            if (check.issue)
                return (0, panelInteraction_1.refreshPanel)(i, await buildEmbedEditorPayload(i.guild, record));
            const channel = check.channel;
            const payload = (0, customEmbeds_1.buildCustomEmbedMessage)(record, i.guild.id);
            let message = null;
            try {
                if (record.publishedMessageId && record.publishedChannelId === record.destinationChannelId) {
                    try {
                        message = await channel.messages.fetch(record.publishedMessageId);
                    }
                    catch (error) {
                        if (error.code !== 10008)
                            throw error;
                    }
                    if (message)
                        await message.edit(payload);
                }
                if (!message)
                    message = await channel.send(payload);
                await prisma_1.prisma.customEmbed.update({ where: { id }, data: { publishedChannelId: channel.id, publishedMessageId: message.id, publishedPayloadHash: (0, embedPublication_1.publicationHash)(record) } });
                return renderEmbedEditor(i, id);
            }
            catch {
                return i.followUp({ content: "Não foi possível concluir a publicação. Confira o canal e tente novamente; o modelo continua salvo.", ephemeral: true });
            }
        }
        if (action === "more")
            return (0, panelInteraction_1.refreshPanel)(i, { content: `**Mais opções · ${record.name}**`, attachments: [], embeds: (0, customEmbeds_1.buildCustomEmbedMessage)(record, i.guild.id).embeds, components: [row(button(`embedv2:rename:${id}`, "Renomear"), button(`embedv2:clone:${id}`, "Duplicar"), button(`embedv2:delete:${id}`, "Excluir", discord_js_1.ButtonStyle.Danger)), row(button(`embedv2:editor:${id}`, "Voltar"))], allowedMentions: { parse: [] } });
        if (action === "rename")
            return i.showModal(new discord_js_1.ModalBuilder().setCustomId(`embedv2-modal:rename:${id}`).setTitle("Nome da mensagem").addComponents(input("name", "Nome interno", record.name, 80, false, true)));
        if (action === "clone") {
            await (0, panelInteraction_1.deferPanel)(i);
            const clone = await prisma_1.prisma.customEmbed.create({ data: { guildId: record.guildId, createdById: i.user.id, name: `${record.name} — Cópia`.slice(0, 80), title: record.title, description: record.description, author: record.author, footer: record.footer, color: record.color, imageUrl: record.imageUrl, thumbnailUrl: record.thumbnailUrl, showTimestamp: record.showTimestamp, buttons: { create: record.buttons.map((b, n) => ({ type: b.type, label: b.label, emoji: b.emoji, url: b.url, channelId: b.channelId, position: n })) } } });
            return renderEmbedEditor(i, clone.id);
        }
        if (action === "delete")
            return (0, panelInteraction_1.refreshPanel)(i, { content: null, attachments: [], embeds: [(0, adminUi_1.adminEmbed)(i.guild, "sistema").setTitle("Excluir mensagem salva?").setDescription(`O modelo **${record.name}** será excluído. A mensagem já publicada no servidor será preservada.`)], components: [row(button(`embedv2:delete-confirm:${id}`, "Excluir modelo", discord_js_1.ButtonStyle.Danger), button(`embedv2:editor:${id}`, "Cancelar"))] });
        if (action === "delete-confirm") {
            await (0, panelInteraction_1.deferPanel)(i);
            await prisma_1.prisma.customEmbed.delete({ where: { id } });
            return renderEmbedHub(i);
        }
        if (action === "add-link")
            return i.showModal(new discord_js_1.ModalBuilder().setCustomId(`embedv2-modal:add-link:${id}`).setTitle("Botão de link").addComponents(input("label", "Texto do botão", null, 80, false, true), input("emoji", "Emoji opcional", null, 50), input("url", "Link https://...", null, 500, false, true)));
        if (action === "add-channel")
            return (0, panelInteraction_1.refreshPanel)(i, { content: `**Adicionar botão de canal · ${record.name}**`, attachments: [], embeds: (0, customEmbeds_1.buildCustomEmbedMessage)(record, i.guild.id).embeds, components: [new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ChannelSelectMenuBuilder().setCustomId(`embedv2-channel:addbutton:${id}`).setPlaceholder("Escolha o canal do botão").addChannelTypes(discord_js_1.ChannelType.GuildText, discord_js_1.ChannelType.GuildAnnouncement, discord_js_1.ChannelType.GuildForum, discord_js_1.ChannelType.GuildVoice, discord_js_1.ChannelType.GuildStageVoice).setMinValues(1).setMaxValues(1)), row(button(`embedv2:buttons:${id}`, "Voltar"))], allowedMentions: { parse: [] } });
    } };
