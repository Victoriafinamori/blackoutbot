"use strict";
const { prepareAdminPanel } = require("../../utils/adminTasks");
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderDenunciasMenu = renderDenunciasMenu;
exports.renderDenunciasSettings = renderDenunciasSettings;
exports.renderDenunciasChannels = renderDenunciasChannels;
exports.renderDenunciasRoles = renderDenunciasRoles;
const discord_js_1 = require("discord.js");
const adminUi_1 = require("../../utils/adminUi");
const permissions_1 = require("../../utils/permissions");
const tickets_1 = require("../../utils/tickets");
const prisma_1 = require("../../database/prisma");
const admPanel_1 = require("../../utils/admPanel");
const reports_1 = require("../../utils/reports");
const RED = 0xd71935;
const roleText = (value) => (0, tickets_1.ids)(value).map(id => `<@&${id}>`).join(", ") || "Não configurado";
const styleName = (value) => ({ PRIMARY: "Azul", SECONDARY: "Cinza", SUCCESS: "Verde", DANGER: "Vermelho" }[String(value || "DANGER").toUpperCase()] || "Vermelho");
const button = (customId, label, style = discord_js_1.ButtonStyle.Secondary, emoji) => {
    const b = new discord_js_1.ButtonBuilder().setCustomId(customId).setLabel(label).setStyle(style);
    if (emoji)
        b.setEmoji(emoji);
    return b;
};
async function showPanelEditor(i) { return require('../../utils/adminMessagePreview').showAdminMessagePreview(i, 'denuncias'); }

async function renderDenunciasMenu(interaction) {
    const c = await (0, reports_1.reportConfig)(interaction.guild.id);
    const open = await prisma_1.prisma.report.count({ where: { guildId: interaction.guild.id, status: { in: ["RECEIVED", "ANALYSIS", "INVESTIGATION"] } } });
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "atendimento")).setColor(RED).setTitle("🚨 Configurações — Central de Denúncias")
        .addFields({ name: "ℹ️ Informações", value: `Status: **${c.enabled ? "✅ Ativada" : "❌ Desativada"}**\nDenúncias abertas: **${open}**\nCargos responsáveis: **${roleText(c.staffRoleIds)}**` }, { name: "📍 Canais", value: `Painel: **${c.panelChannelId ? `<#${c.panelChannelId}>` : "Não configurado"}**\nCategoria: **${c.categoryId ? `<#${c.categoryId}>` : "Não configurada"}**\nLogs: **${c.logChannelId ? `<#${c.logChannelId}>` : "Não configurado"}**` }, { name: "🎨 Painel", value: `Título: **${c.panelTitle}**\nBotão: ${c.panelButtonEmoji || ""} **${c.panelButtonLabel}** • ${styleName(c.panelButtonStyle)}` }, { name: "📨 Atendimento", value: "O membro inicia pelo botão do painel, informa denunciado, motivo e relato. Um canal privado é criado para o denunciante e os cargos responsáveis." });
    await interaction.update(prepareAdminPanel(interaction.guild, 'denuncias', { attachments: [], embeds: [embed], components: [
            new discord_js_1.ActionRowBuilder().addComponents(button("adm-denuncia:back", "Voltar", discord_js_1.ButtonStyle.Secondary, "↩️"), button("adm-denuncia:toggle", c.enabled ? "Desativar" : "Ativar", c.enabled ? discord_js_1.ButtonStyle.Danger : discord_js_1.ButtonStyle.Success, c.enabled ? "⛔" : "✅"), button("adm-denuncia:publish", "Publicar/Atualizar", discord_js_1.ButtonStyle.Primary, "📨")),
            new discord_js_1.ActionRowBuilder().addComponents(button("adm-denuncia:appearance", "Painel", discord_js_1.ButtonStyle.Secondary, "🎨"), button("adm-denuncia:channels", "Canais e Logs", discord_js_1.ButtonStyle.Secondary, "📍"), button("adm-denuncia:roles", "Cargos", discord_js_1.ButtonStyle.Secondary, "👮")),
        ] }));
}
async function renderDenunciasSettings(interaction) { return renderDenunciasMenu(interaction); }
async function renderDenunciasChannels(interaction) {
    const c = await (0, reports_1.reportConfig)(interaction.guild.id);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "atendimento")).setColor(RED).setTitle("📍 Canais e Logs — Denúncias")
        .setDescription("Selecione onde o painel será publicado, em qual categoria os atendimentos serão criados e onde os logs/transcripts serão enviados.")
        .addFields({ name: "Estado atual", value: `Painel: **${c.panelChannelId ? `<#${c.panelChannelId}>` : "Não configurado"}**\nCategoria: **${c.categoryId ? `<#${c.categoryId}>` : "Não configurada"}**\nLogs: **${c.logChannelId ? `<#${c.logChannelId}>` : "Não configurado"}**` });
    const fields = [
        ["panelChannelId", "Canal do painel de denúncias", [discord_js_1.ChannelType.GuildText]],
        ["categoryId", "Categoria dos atendimentos", [discord_js_1.ChannelType.GuildCategory]],
        ["logChannelId", "Canal de logs e transcripts", [discord_js_1.ChannelType.GuildText]],
    ];
    const rows = fields.map(([key, label, types]) => new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ChannelSelectMenuBuilder().setCustomId(`denuncia-channel:${key}`).setPlaceholder(label).addChannelTypes(...types).setMinValues(0).setMaxValues(1)));
    await interaction.update({ attachments: [], embeds: [embed], components: [...rows, new discord_js_1.ActionRowBuilder().addComponents(button("adm-denuncia:menu", "Voltar", discord_js_1.ButtonStyle.Secondary, "↩️"))] });
}
async function renderDenunciasRoles(interaction) {
    const c = await (0, reports_1.reportConfig)(interaction.guild.id);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "atendimento")).setColor(RED).setTitle("👮 Cargos Responsáveis — Denúncias")
        .setDescription("Esses cargos poderão visualizar, assumir e encerrar denúncias.")
        .addFields({ name: "Cargos atuais", value: roleText(c.staffRoleIds) });
    const row = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.RoleSelectMenuBuilder().setCustomId("denuncia-role:staffRoleIds").setPlaceholder("Selecione os cargos responsáveis").setMinValues(0).setMaxValues(10));
    await interaction.update({ attachments: [], embeds: [embed], components: [row, new discord_js_1.ActionRowBuilder().addComponents(button("adm-denuncia:menu", "Voltar", discord_js_1.ButtonStyle.Secondary, "↩️"))] });
}
const component = { customId: "adm-denuncia:", async execute(interaction) {
        if (!interaction.guild || !(await (0, permissions_1.isBotAdmin)(await interaction.guild.members.fetch(interaction.user.id))))
            return void await interaction.reply({ content: "Sem permissão.", flags: discord_js_1.MessageFlags.Ephemeral });
        const [, action] = interaction.customId.split(":");
        if (action === "back")
            return void await interaction.update(await (0, admPanel_1.buildAdmSectionPanel)(interaction.guild, "atendimento"));
        if (action === "menu")
            return renderDenunciasMenu(interaction);
        if (action === "channels")
            return renderDenunciasChannels(interaction);
        if (action === "roles")
            return renderDenunciasRoles(interaction);
        if (action === "appearance")
            return void await showPanelEditor(interaction);
        if (action === "edit-embed")
            return void await interaction.showModal(await (0, reports_1.buildReportAppearanceModal)(interaction.guild.id));
        if (action === "edit-button") {
            const c = await (0, reports_1.reportConfig)(interaction.guild.id);
            const modal = new discord_js_1.ModalBuilder().setCustomId("denuncia-appearance:button").setTitle("Botão da Central de Denúncias").addComponents(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("label").setLabel("Texto do botão").setStyle(discord_js_1.TextInputStyle.Short).setMaxLength(80).setValue(c.panelButtonLabel || "Iniciar denúncia").setRequired(true)), new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("emoji").setLabel("Emoji (opcional)").setStyle(discord_js_1.TextInputStyle.Short).setMaxLength(50).setValue(c.panelButtonEmoji || "").setRequired(false)), new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("style").setLabel("Cor: AZUL, CINZA, VERDE ou VERMELHO").setStyle(discord_js_1.TextInputStyle.Short).setValue(styleName(c.panelButtonStyle).toUpperCase()).setRequired(true)));
            return void await interaction.showModal(modal);
        }
        if (action === "toggle") {
            const c = await (0, reports_1.reportConfig)(interaction.guild.id);
            await prisma_1.prisma.reportConfig.update({ where: { guildId: interaction.guild.id }, data: { enabled: !c.enabled } });
            return renderDenunciasMenu(interaction);
        }
        if (action === "publish") {
            await interaction.deferReply({ flags: discord_js_1.MessageFlags.Ephemeral });
            try {
                const message = await (0, reports_1.publishReportPanel)(interaction.guild);
                await interaction.editReply(`✅ Painel de denúncias publicado/atualizado: ${message.url}`);
            }
            catch (error) {
                await interaction.editReply(error instanceof Error ? `❌ ${error.message}` : "❌ Não foi possível publicar o painel.");
            }
        }
    } };
exports.default = component;
//# sourceMappingURL=admDenunciasMenu.js.map