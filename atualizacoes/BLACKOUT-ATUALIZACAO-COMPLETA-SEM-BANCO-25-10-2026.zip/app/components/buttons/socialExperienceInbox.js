"use strict";
const { guarded, ephemeral } = require("../../social-experience/common");
exports.default = {
  customId: "sx-inbox:",
  execute: (i) =>
    guarded(i, async () => {
      await i.deferReply({ flags: ephemeral });
      const [, action, id] = i.customId.split(":");
      return i.editReply(
        await require("../../social-experience/anonymous").inbox(i, action, id),
      );
    }),
};
