"use strict";
const { guarded, ephemeral } = require("../../social-experience/common");
exports.default = {
  customId: "sx-review:",
  execute: (i) =>
    guarded(i, async () => {
      if (!i.guild) return;
      const [, action, id] = i.customId.split(":");
      if (!["approve", "reject"].includes(action)) return;
      await i.deferReply({ flags: ephemeral });
      const result = await require("../../social-experience/anonymous").review(
        i,
        action === "approve",
        id,
      );
      await i.message
        .edit({
          components: i.message.components.map((r) => {
            const json = r.toJSON();
            function disable(c) {
              if (c.type === 2) c.disabled = true;
              (c.components || []).forEach(disable);
            }
            disable(json);
            return json;
          }),
        })
        .catch(() => null);
      return i.editReply(result);
    }),
};
