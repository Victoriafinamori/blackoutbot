"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const permissions_1 = require("../../utils/permissions");
const admPanel_1 = require("../../utils/admPanel");
const admEmojis_1 = require("../../utils/admEmojis");
const component = {
    customId: "adm-nav:",
    async execute(i) {
        if (!i.guild)
            return;
        if (!await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id))) {
            await i.reply({ content: "Você não possui permissão para acessar o painel administrativo.", ephemeral: true });
            return;
        }
        const target = i.customId.slice("adm-nav:".length);
        const area = (0, admPanel_1.resolveAdmSection)(target);
        if (target !== "root" && !area)
            return;
        await i.deferUpdate();
        if (target === "root")
            await (0, admEmojis_1.ensureAdmEmojis)(i.guild);
        await i.editReply(area ? await (0, admPanel_1.buildAdmSectionPanel)(i.guild, area) : await (0, admPanel_1.buildAdmRootPanel)(i.guild, i.user));
    },
};
exports.default = component;
