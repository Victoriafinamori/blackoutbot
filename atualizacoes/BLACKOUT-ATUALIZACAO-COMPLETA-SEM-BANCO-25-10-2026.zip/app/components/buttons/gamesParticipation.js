"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const hub_1 = require("../../games-chat/experience/hub");
exports.default = { customId: "play:", execute: hub_1.player };
