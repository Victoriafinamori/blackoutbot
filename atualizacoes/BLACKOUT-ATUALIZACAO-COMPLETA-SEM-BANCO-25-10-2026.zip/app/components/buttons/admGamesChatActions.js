"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const permissions_1 = require("../../utils/permissions");
const config_1 = require("../../games-chat/core/config");
const prisma_1 = require("../../database/prisma");
const manager_1 = require("../../games-chat/mystery-box/manager");
const publisher_1 = require("../../games-chat/termo/publisher");
const admGamesChatMenu_1 = require("./admGamesChatMenu");
const ui_1 = require("../../games-chat/termo/ui");
const input = (id, label, value, required = true, paragraph = false) => {
    const field = new discord_js_1.TextInputBuilder()
        .setCustomId(id)
        .setLabel(label)
        .setStyle(paragraph ? discord_js_1.TextInputStyle.Paragraph : discord_js_1.TextInputStyle.Short)
        .setRequired(required);
    if (value)
        field.setValue(value);
    return new discord_js_1.ActionRowBuilder().addComponents(field);
};
const component = {
    customId: "adm-games-action:",
    async execute(i) {
        if (!i.guild || !(await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id))))
            return void (await i.reply({
                content: "Você não possui permissão.",
                ephemeral: true,
            }));
        const action = i.customId.split(":")[1];
        if (action === "mystery-settings") {
            const c = await (0, config_1.mysteryConfig)(i.guild.id);
            return void (await i.showModal(new discord_js_1.ModalBuilder()
                .setCustomId("adm-games-modal:mystery")
                .setTitle("Caixa Misteriosa — Configuração")
                .addComponents(input("boxes", "Quantidade de caixas (1-25)", String(c.boxCount)), input("duration", "Duração em minutos", String(Math.ceil(c.durationSeconds / 60))), input("participants", "Máximo de participantes (0 = ilimitado)", String(c.maxParticipants ?? 0)), input("title", "Título da embed", c.title), input("color", "Cor hexadecimal", c.color))));
        }
        if (action === "termo-home")
            return void (await i.update(await (0, admGamesChatMenu_1.termoAdminView)(i.guild)));
        if (action === "termo-appearance")
            return void (await i.update(await require("../../games-chat/termo/admin").appearance(i.guild)));
        if (action === "termo-appearance-edit") {
            const c = await (0, config_1.termoConfig)(i.guild.id);
            return void (await i.showModal(new discord_js_1.ModalBuilder()
                .setCustomId("adm-games-modal:termo-appearance")
                .setTitle("Mensagem do TERMO")
                .addComponents(input("title", "Título", c.title), input("description", "Texto do painel", c.description, true, true), input("color", "Cor hexadecimal", c.color), input("image", "URL da imagem (opcional)", c.image || "", false), input("footer", "Rodapé (opcional)", c.footer || "", false))));
        }
        if (action === "termo-settings") {
            const c = await (0, config_1.termoConfig)(i.guild.id);
            return void (await i.showModal(new discord_js_1.ModalBuilder()
                .setCustomId("adm-games-modal:termo")
                .setTitle("TERMO — Configuração")
                .addComponents(input("length", "Quantidade de letras", String(c.wordLength)), input("attempts", "Máximo de tentativas", String(c.maxAttempts)), input("repeat", "Dias antes de repetir palavra", String(c.repeatAfterDays)), input("title", "Título da embed", c.title), input("color", "Cor hexadecimal", c.color))));
        }
        if (action === "mystery-reward-add")
            return void (await i.showModal(new discord_js_1.ModalBuilder()
                .setCustomId("adm-games-modal:reward")
                .setTitle("Cadastrar recompensa")
                .addComponents(input("name", "Nome da recompensa", ""), input("type", "Tipo: NADA, CARGO, TEMP, VIP, XP...", "NADA"), input("weight", "Peso no sorteio", "1"), input("stock", "Estoque (0 = ilimitado)", "0"), input("details", "Quantidade | cargo ID | duração em min", "1", false))));
        if (action === "mystery-winner") {
            const c = await (0, config_1.mysteryConfig)(i.guild.id);
            return void (await i.showModal(new discord_js_1.ModalBuilder()
                .setCustomId("adm-games-modal:winner")
                .setTitle("Embed do ganhador")
                .addComponents(input("title", "Título", c.winnerTitle), input("description", "Mensagem: {membro} {premio} {caixa}", c.winnerDescription), input("color", "Cor hexadecimal", c.winnerColor), input("image", "URL da imagem (opcional)", c.winnerImage || "", false), input("footer", "Rodapé (opcional)", c.winnerFooter || "", false))));
        }
        if (action === "mystery-reward-delete") {
            const rewards = await prisma_1.prisma.mysteryReward.findMany({
                where: { guildId: i.guild.id, active: true },
                orderBy: { createdAt: "desc" },
                take: 25,
            });
            if (!rewards.length)
                return void (await i.reply({
                    content: "Não existem recompensas ativas para excluir.",
                    ephemeral: true,
                }));
            const select = new discord_js_1.StringSelectMenuBuilder()
                .setCustomId("adm-games-reward-delete:select")
                .setPlaceholder("Escolha a recompensa que será excluída")
                .addOptions(rewards.map((reward) => ({
                label: reward.name.slice(0, 100),
                value: reward.id,
                description: `${reward.type} · peso ${reward.weight}`.slice(0, 100),
            })));
            return void (await i.reply({
                content: "Selecione uma recompensa. Itens já usados serão desativados para preservar o histórico.",
                components: [
                    new discord_js_1.ActionRowBuilder().addComponents(select),
                ],
                ephemeral: true,
            }));
        }
        if (action === "termo-word-add")
            return void (await i.showModal(new discord_js_1.ModalBuilder()
                .setCustomId("adm-games-modal:word")
                .setTitle("Adicionar palavra ao TERMO")
                .addComponents(input("word", "Palavra (4 a 12 letras)", ""), input("answer", "Pode ser resposta? SIM ou NAO", "SIM"))));
        if (action === "mystery-rewards") {
            const rewards = await prisma_1.prisma.mysteryReward.findMany({
                where: { guildId: i.guild.id },
                orderBy: { createdAt: "desc" },
                take: 25,
            });
            return void (await i.reply({
                content: rewards.length
                    ? rewards
                        .map((r, n) => `**${n + 1}. ${r.name}** · ${r.type} · peso ${r.weight} · estoque ${r.stock ?? "∞"} · ${r.active ? "ativa" : "inativa"}`)
                        .join("\n")
                    : "Nenhuma recompensa cadastrada.",
                ephemeral: true,
            }));
        }
        if (action === "termo-words") {
            const words = await prisma_1.prisma.termoWord.findMany({
                where: {
                    OR: [{ guildId: null }, { guildId: i.guild.id }],
                    active: true,
                },
                orderBy: { word: "asc" },
                take: 50,
            });
            return void (await i.reply({
                content: words.length
                    ? `**Banco de palavras (${words.length} exibidas):**\n${words.map((w) => `\`${w.word.toLocaleUpperCase("pt-BR")}\`${w.canAnswer ? "" : " (somente tentativa)"}`).join(", ")}`
                    : "O banco está vazio.",
                ephemeral: true,
            }));
        }
        if (action === "termo-ranking")
            return void (await i.reply({
                ...(await (0, ui_1.termoRankingView)(i.guild)),
                ephemeral: true,
            }));
        await i.deferUpdate();
        try {
            if (action === "mystery-toggle") {
                const c = await (0, config_1.mysteryConfig)(i.guild.id);
                await prisma_1.prisma.mysteryBoxConfig.update({
                    where: { guildId: i.guild.id },
                    data: { enabled: !c.enabled },
                });
            }
            if (action === "termo-toggle") {
                const c = await (0, config_1.termoConfig)(i.guild.id);
                await prisma_1.prisma.termoConfig.update({
                    where: { guildId: i.guild.id },
                    data: { enabled: !c.enabled },
                });
            }
            if (action === "mystery-start")
                await (0, manager_1.createMysteryEvent)(i.guild, i.user.id);
            if (action === "mystery-end") {
                const event = await prisma_1.prisma.mysteryEvent.findFirst({
                    where: { guildId: i.guild.id, status: "ACTIVE" },
                });
                if (event)
                    await (0, manager_1.endMysteryEvent)(i.guild, event.id);
            }
            if (action === "termo-publish")
                await (0, publisher_1.publishTermoPanel)(i.guild);
            await i.editReply(action.startsWith("termo")
                ? await (0, admGamesChatMenu_1.termoAdminView)(i.guild)
                : await (0, admGamesChatMenu_1.mysteryAdminView)(i.guild));
        }
        catch (error) {
            await i.followUp({
                content: `Erro: ${error instanceof Error ? error.message : String(error)}`,
                ephemeral: true,
            });
        }
    },
};
exports.default = component;
