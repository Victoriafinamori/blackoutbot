"use strict";
const { prepareAdminPanel } = require("../../utils/adminTasks");
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildServerFeedbackAdminView = buildServerFeedbackAdminView;
exports.renderServerFeedbackMenu = renderServerFeedbackMenu;
const discord_js_1 = require("discord.js");
const adminUi_1 = require("../../utils/adminUi");
const serverFeedback_1 = require("../../utils/serverFeedback");
const prisma_1 = require("../../database/prisma");
const admPanel_1 = require("../../utils/admPanel");
const permissions_1 = require("../../utils/permissions");
async function buildServerFeedbackAdminView(guild) {
    const config = await (0, serverFeedback_1.getServerFeedbackConfig)(guild.id), count = await prisma_1.prisma.serverFeedback.count({ where: { guildId: guild.id } });
    const embed = (await (0, adminUi_1.adminEmbed)(guild, "servidor")).setTitle("Feedback do Servidor").setDescription("Painel público de sugestões anônimas com votação por reações.").addFields({ name: "Configurações", value: `Sistema: **${config.enabled ? "Ativo" : "Desativado"}**\nCanal do painel: ${config.panelChannelId ? `<#${config.panelChannelId}>` : "Não configurado"}\nCanal das sugestões: ${config.destinationChannelId ? `<#${config.destinationChannelId}>` : "Não configurado"}\nFeedbacks recebidos: **${count}**` }, { name: "Privacidade", value: "O nome do autor nunca aparece na publicação pública. A identidade fica disponível somente no histórico administrativo." });
    const panelChannel = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ChannelSelectMenuBuilder().setCustomId("adm-feedback-channel:panel").setPlaceholder("Escolher canal do painel público").setChannelTypes(discord_js_1.ChannelType.GuildText));
    const destination = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ChannelSelectMenuBuilder().setCustomId("adm-feedback-channel:destination").setPlaceholder("Escolher canal das sugestões").setChannelTypes(discord_js_1.ChannelType.GuildText));
    const actions = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-feedback:toggle").setLabel(config.enabled ? "Desativar" : "Ativar").setStyle(config.enabled ? discord_js_1.ButtonStyle.Secondary : discord_js_1.ButtonStyle.Success), new discord_js_1.ButtonBuilder().setCustomId("adm-feedback:appearance").setLabel("Editar painel").setStyle(discord_js_1.ButtonStyle.Primary), new discord_js_1.ButtonBuilder().setCustomId("adm-feedback:publish").setLabel("Publicar/Atualizar").setStyle(discord_js_1.ButtonStyle.Success).setDisabled(!config.enabled || !config.panelChannelId || !config.destinationChannelId), new discord_js_1.ButtonBuilder().setCustomId("adm-feedback:history").setLabel("Histórico privado").setStyle(discord_js_1.ButtonStyle.Secondary));
    const back = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-feedback:back").setLabel("Voltar").setStyle(discord_js_1.ButtonStyle.Secondary));
    return { attachments: [], embeds: [embed], components: [panelChannel, destination, actions, back] };
}
async function renderServerFeedbackMenu(i) { await i.update(prepareAdminPanel(i.guild, 'feedback', await buildServerFeedbackAdminView(i.guild))); }
const field = (id, label, value, style = discord_js_1.TextInputStyle.Short, required = true) => { const input = new discord_js_1.TextInputBuilder().setCustomId(id).setLabel(label).setStyle(style).setRequired(required); if (value)
    input.setValue(value); return new discord_js_1.ActionRowBuilder().addComponents(input); };
const component = { customId: "adm-feedback:", async execute(i) {
        if (!i.guild)
            return;
        if (!(await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id))))
            return void await i.reply({ content: "Você não possui permissão.", ephemeral: true });
        const action = i.customId.split(":")[1], config = await (0, serverFeedback_1.getServerFeedbackConfig)(i.guild.id);
        if (action === "appearance")
            return void await i.showModal(new discord_js_1.ModalBuilder().setCustomId("adm-feedback-modal:appearance").setTitle("Painel de Feedback").addComponents(field("title", "Título", config.title), field("description", "Descrição", config.description, discord_js_1.TextInputStyle.Paragraph), field("color", "Cor hexadecimal", config.color), field("image", "URL da imagem (opcional)", config.image || "", discord_js_1.TextInputStyle.Short, false), field("button", "Texto do botão", config.buttonLabel)));
        if (action === "history") {
            const rows = await prisma_1.prisma.serverFeedback.findMany({ where: { guildId: i.guild.id }, orderBy: { createdAt: "desc" }, take: 10 });
            const history = rows.map(row => `**${row.id}** · Autor: <@${row.authorId}> · <t:${Math.floor(row.createdAt.getTime() / 1000)}:R>\n${row.content.slice(0, 150)}${row.content.length > 150 ? "…" : ""}`).join("\n\n").slice(0, 1900);
            return void await i.reply({ content: history || "Nenhum feedback recebido.", ephemeral: true });
        }
        if (action === "back")
            return void await i.update(await (0, admPanel_1.buildAdmSectionPanel)(i.guild, "servidor"));
        await i.deferUpdate();
        try {
            if (action === "toggle")
                await prisma_1.prisma.serverFeedbackConfig.update({ where: { guildId: i.guild.id }, data: { enabled: !config.enabled } });
            if (action === "publish")
                await (0, serverFeedback_1.publishServerFeedbackPanel)(i.guild);
            await i.editReply(await buildServerFeedbackAdminView(i.guild));
        }
        catch (error) {
            await i.followUp({ content: `Erro: ${error instanceof Error ? error.message : String(error)}`, ephemeral: true });
        }
    } };
exports.default = component;
//# sourceMappingURL=admServerFeedbackMenu.js.map