"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const permissions_1 = require("../../utils/permissions");
const tickets_1 = require("../../utils/tickets");
const ticketVisualEditor_1 = require("../../utils/ticketVisualEditor");
const component = { customId: "ticket-visual-editor:", async execute(i) { if (!i.guild || !(await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id))))
        return; const [, action, prefixRaw] = i.customId.split(":"), prefix = prefixRaw; if (!["panel", "internal"].includes(prefix)) return;
    if (action === "open") return require("../../utils/panelInteraction").refreshPanel(i, await (0, ticketVisualEditor_1.ticketVisualEditor)(i.guild, prefix));
    if (action === "preview") {
        const c = await (0, tickets_1.ticketConfig)(i.guild.id);
        const preview = prefix === "panel" ? (0, tickets_1.ticketPanel)(c) : { embeds: [(0, ticketVisualEditor_1.ticketInternalPreview)(c)], components: [] };
        for (const row of preview.components || []) for (const b of row.components) b.setDisabled(true);
        return require("../../utils/panelInteraction").refreshPanel(i, {content: "**Prévia · Tickets**", attachments: [], embeds: preview.embeds, components: [...preview.components, new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId(`ticket-visual-editor:open:${prefix}`).setLabel("Voltar ao editor").setStyle(discord_js_1.ButtonStyle.Secondary))], allowedMentions: {parse: []}});
    }
    if (action === "color") {
        const c = await (0, tickets_1.ticketConfig)(i.guild.id);
        await i.showModal(new discord_js_1.ModalBuilder().setCustomId(`ticket-visual-color:${prefix}`).setTitle("Cor da embed").addComponents(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("color").setLabel("Cor hexadecimal").setStyle(discord_js_1.TextInputStyle.Short).setValue(c[`${prefix}Color`]).setRequired(true))));
        return;
    } if (action === "save") {
        await i.deferUpdate();
        const c = await (0, tickets_1.ticketConfig)(i.guild.id);
        
        await i.editReply(await (0, ticketVisualEditor_1.ticketVisualEditor)(i.guild, prefix));
    } } };
exports.default = component;
//# sourceMappingURL=ticketVisualEditorButton.js.map