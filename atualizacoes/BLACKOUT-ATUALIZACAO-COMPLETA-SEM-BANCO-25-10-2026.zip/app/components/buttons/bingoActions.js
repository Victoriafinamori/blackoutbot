"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const permissions_1 = require("../../utils/permissions");
const service_1 = require("../../bingo/service");
const views_1 = require("../../bingo/views");
const types_1 = require("../../bingo/types");
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
async function requireStaff(interaction) {
    const member = await interaction.guild.members.fetch(interaction.user.id);
    const ok = await (0, permissions_1.isBotAdmin)(member);
    if (!ok)
        await interaction.reply({
            content: "🚫 Apenas a staff pode controlar a partida.",
            ephemeral: true,
        });
    return ok;
}
const component = {
    customId: "bingo:",
    async execute(interaction) {
        if (!interaction.guild)
            return;
        const guildId = interaction.guild.id;
        // A compra de cartelas agora é feita pelo select "bingo:comprar-select"
        // (ver src/components/selects/bingoCardsSelect.ts) — não é mais um botão.
        // --- REENVIAR CARTELAS (qualquer pessoa; funciona com ou sem partida) ---
        if (interaction.customId === types_1.BINGO_IDS.reenviarCartelas) {
            const cards = await (0, service_1.getAllActiveCardsForPlayer)(guildId, interaction.user.id);
            if (!cards.length) {
                await interaction.reply({
                    content: "❌ Você ainda não possui cartelas para a próxima partida.",
                    ephemeral: true,
                });
                return;
            }
            const dmSent = await interaction.user
                .send({
                content: `🎫 Suas cartelas do Bingo (${cards.length}):`,
                embeds: (0, views_1.buildCardsDeliveryDM)(cards),
            })
                .then(() => true)
                .catch(() => false);
            await interaction.reply({
                content: dmSent
                    ? `✅ Reenviei suas ${cards.length} cartela${cards.length > 1 ? "s" : ""} na sua DM.`
                    : "Não consegui enviar a DM. Consulte suas cartelas aqui no servidor pelo botão abaixo.",
                ephemeral: true,
                components: !dmSent
                    ? [
                        require("../../games-chat/experience/common").row(require("../../games-chat/experience/common").button("bingo-card-view:0", "Ver minhas cartelas aqui")),
                    ]
                    : [],
            });
            return;
        }
        const match = await (0, service_1.getCurrentMatch)(guildId);
        if (!match) {
            await interaction.reply({
                content: "❌ Não há nenhuma partida em andamento. Use `/bingo iniciar`.",
                ephemeral: true,
            });
            return;
        }
        if (interaction.message.id !== match.messageId ||
            interaction.channelId !== match.channelId) {
            await interaction.reply({
                content: "Este painel pertence a outra partida. Abra a mensagem da partida atual.",
                ephemeral: true,
            });
            return;
        }
        // --- HISTÓRICO (qualquer pessoa) ---
        if (interaction.customId === types_1.BINGO_IDS.historico) {
            const draws = await (0, service_1.getDraws)(match.id);
            await interaction.reply({
                embeds: [(0, views_1.buildHistoryEmbed)(draws)],
                ephemeral: true,
            });
            return;
        }
        // --- BINGO (qualquer jogador) ---
        // CRÍTICO: um jogador pode ter várias cartelas na mesma partida (1, 3,
        // 10...). É preciso checar TODAS as cartelas dele, não só a primeira
        // encontrada — basta UMA delas ter uma combinação vencedora.
        if (interaction.customId === types_1.BINGO_IDS.jogarBingo) {
            const cards = await (0, service_1.getPlayerCards)(guildId, match.id, interaction.user.id);
            if (!cards.length) {
                await interaction.reply({
                    content: "❌ Você não possui nenhuma cartela cadastrada para esta partida.",
                    ephemeral: true,
                });
                return;
            }
            const draws = await (0, service_1.getDraws)(match.id);
            const drawnNumbers = new Set(draws.map((d) => d.number));
            // Fonte de verdade: os números salvos no banco de cada cartela — a
            // imagem/embed nunca é consultada aqui.
            const winningCards = cards.filter((c) => (0, service_1.checkWinningCard)(JSON.parse(c.numbers), drawnNumbers));
            for (const c of cards) {
                await (0, service_1.recordWinnerAttempt)(match.id, c.id, interaction.user.id, winningCards.includes(c));
            }
            if (!winningCards.length) {
                await interaction.reply({
                    content: cards.length > 1
                        ? `❌ BINGO inválido.\nNenhuma das suas ${cards.length} cartelas possui uma combinação vencedora neste momento.`
                        : "❌ BINGO inválido.\nSua cartela ainda não possui uma combinação vencedora.",
                    ephemeral: true,
                });
                return;
            }
            const paused = await (0, service_1.pauseMatch)(match.id);
            await interaction.update((0, views_1.buildBingoPanel)(paused, draws));
            await interaction.followUp({
                embeds: [
                    (0, views_1.buildBingoValidEmbed)(interaction.user.id, winningCards.map((c) => c.cardNumber)),
                ],
            });
            return;
        }
        // --- Ações restritas à staff ---
        if (!(await requireStaff(interaction)))
            return;
        if (interaction.customId === types_1.BINGO_IDS.pausar) {
            const updated = await (0, service_1.pauseMatch)(match.id);
            const draws = await (0, service_1.getDraws)(match.id);
            await interaction.update((0, views_1.buildBingoPanel)(updated, draws));
            return;
        }
        if (interaction.customId === types_1.BINGO_IDS.retomar) {
            const updated = await (0, service_1.resumeMatch)(match.id);
            const draws = await (0, service_1.getDraws)(match.id);
            await interaction.update((0, views_1.buildBingoPanel)(updated, draws));
            return;
        }
        if (interaction.customId === types_1.BINGO_IDS.encerrar) {
            await interaction.update((0, views_1.buildEncerrarConfirm)());
            return;
        }
        if (interaction.customId === types_1.BINGO_IDS.encerrarCancelar) {
            const draws = await (0, service_1.getDraws)(match.id);
            await interaction.update((0, views_1.buildBingoPanel)(match, draws));
            return;
        }
        if (interaction.customId === types_1.BINGO_IDS.encerrarConfirmar) {
            const ended = await (0, service_1.endMatch)(match.id);
            const draws = await (0, service_1.getDraws)(match.id);
            await interaction.update((0, views_1.buildBingoPanel)(ended, draws));
            return;
        }
        if (interaction.customId === types_1.BINGO_IDS.sortear) {
            if (match.status !== "EM_ANDAMENTO") {
                await interaction.reply({
                    content: "❌ A partida precisa estar em andamento para sortear.",
                    ephemeral: true,
                });
                return;
            }
            let draw;
            try {
                draw = await (0, service_1.drawNumber)(match.id);
            }
            catch (error) {
                await interaction.reply({
                    content: `❌ ${error instanceof Error ? error.message : "Não foi possível sortear."}`,
                    ephemeral: true,
                });
                return;
            }
            await interaction.deferUpdate();
            await interaction.editReply((0, views_1.buildAnimationFrame)("**Sorteando...**"));
            await sleep(500);
            await interaction.editReply((0, views_1.buildAnimationFrame)(`**${draw.letter}...**`));
            await sleep(500);
            const draws = await (0, service_1.getDraws)(match.id);
            await interaction.editReply((0, views_1.buildDrawResultFrame)(draw.letter, draw.number, draws.length));
            await sleep(900);
            await interaction.editReply((0, views_1.buildBingoPanel)(match, draws));
            return;
        }
    },
};
exports.default = component;
