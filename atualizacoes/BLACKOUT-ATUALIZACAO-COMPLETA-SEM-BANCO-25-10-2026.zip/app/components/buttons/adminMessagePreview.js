"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const permissions_1 = require("../../utils/permissions");
const adminMessagePreview_1 = require("../../utils/adminMessagePreview");
const component = { customId: 'admin-preview:', async execute(i) {
        if (!i.guild || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return;
        const value = i.customId.slice('admin-preview:'.length), editing = value.startsWith('edit-'), key = editing ? value.slice(5) : value;
        if (!['parcerias', 'denuncias', 'feedback', 'anonymous-photo', 'anonymous-message'].includes(key))
            return;
        await i.deferUpdate();
        return (0, adminMessagePreview_1.showAdminMessagePreview)(i, key, !editing);
    } };
exports.default = component;
