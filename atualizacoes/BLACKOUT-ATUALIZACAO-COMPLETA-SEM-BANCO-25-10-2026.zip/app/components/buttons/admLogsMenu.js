"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LOG_CHANNEL_FIELDS = void 0;
exports.renderLogsMenu = renderLogsMenu;
exports.renderLogCategories = renderLogCategories;
exports.renderLogChannelPicker = renderLogChannelPicker;
const panel_1 = require("../../logging/panel");
const discord_js_1 = require("discord.js");
const configurationChecks_1 = require("../../utils/configurationChecks");
const panelInteraction_1 = require("../../utils/panelInteraction");
const permissions_1 = require("../../utils/permissions");
const adminUi_1 = require("../../utils/adminUi");
const guildConfig_1 = require("../../database/guildConfig");
const prisma_1 = require("../../database/prisma");
const enums_1 = require("../../structures/enums");
// Mapa de chave curta (usada no customId) -> categoria + coluna no GuildConfig.
exports.LOG_CHANNEL_FIELDS = {
    geral: { category: enums_1.LogCategory.SYSTEM, label: "Logs gerais", column: "logChannelId" },
    moderacao: { category: enums_1.LogCategory.MODERATION, column: "moderationLogChannelId" },
    seguranca: { category: enums_1.LogCategory.SECURITY, column: "securityLogChannelId" },
    reintegracao: { category: enums_1.LogCategory.REINTEGRATION, column: "reintegrationLogChannelId" },
    sistema: { category: enums_1.LogCategory.SYSTEM, column: "systemLogChannelId" },
};
function backRow(customId, label = "Voltar") {
    return new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId(customId).setLabel(label).setStyle(discord_js_1.ButtonStyle.Secondary));
}
async function destinationText(guild, id) {
    if (!id)
        return "Não definido. Escolha um canal de texto acessível ao bot.";
    const check = await (0, configurationChecks_1.writableChannel)(guild, id);
    return `<#${id}>${check.issue ? ` · ${check.issue.startsWith("Escolha") ? "Canal excluído ou inacessível; escolha outro destino." : check.issue}` : ""}`;
}
async function renderLogsMenu(i) { return (0, panel_1.renderLogHome)(i); }
async function renderLogCategories(i) { return (0, panel_1.renderLogOrganization)(i); }
async function renderLogChannelPicker(interaction, key, notice) {
    const field = exports.LOG_CHANNEL_FIELDS[key];
    if (!field)
        return renderLogsMenu(interaction);
    const label = field.label || enums_1.LOG_CATEGORY_LABELS[field.category].label;
    const config = await (0, guildConfig_1.getOrCreateGuildConfig)(interaction.guild.id), current = config[field.column];
    const embed = (0, adminUi_1.adminEmbed)(interaction.guild, "seguranca").setTitle(label)
        .setDescription(key === "geral" ? "Destino dos registros sem canal específico. Prefira um canal privado acessível à equipe." : "Deixe a seleção vazia para usar o canal geral.")
        .addFields({ name: "Canal atual", value: current ? await destinationText(interaction.guild, current) : key !== "geral" ? `${await destinationText(interaction.guild, config.logChannelId)} · usa o canal geral` : "Não definido" });
    if (notice)
        embed.addFields({ name: "Resultado", value: notice });
    const select = new discord_js_1.ChannelSelectMenuBuilder().setCustomId(`adm-logchannel-select:${key}`).setPlaceholder(`Canal de ${label.toLowerCase()}`).addChannelTypes(discord_js_1.ChannelType.GuildText, discord_js_1.ChannelType.GuildAnnouncement).setMinValues(0).setMaxValues(1);
    if (current && interaction.guild.channels.cache.has(current))
        select.setDefaultChannels([current]);
    return (0, panelInteraction_1.refreshPanel)(interaction, { content: null, attachments: [], embeds: [embed], components: [new discord_js_1.ActionRowBuilder().addComponents(select), backRow("logs-center:destination")] });
}
async function renderRecentAudit(interaction) {
    const logs = await prisma_1.prisma.adminLog.findMany({
        where: { guildId: interaction.guild.id },
        orderBy: { createdAt: "desc" },
        take: 15,
    });
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "seguranca")).setTitle("Ações da equipe").setDescription(logs.length === 0
        ? "Nenhum evento registrado ainda."
        : logs
            .map((log) => {
            const timestamp = `<t:${Math.floor(log.createdAt.getTime() / 1000)}:R>`;
            const target = log.targetId ? ` → <@${log.targetId}>` : "";
            const details = log.details ? ` — ${log.details}` : "";
            return `**${log.action}** por <@${log.actorId}>${target}${details} (${timestamp})`;
        })
            .join("\n").slice(0, 3900)).setFooter({ text: "Últimas 15 ações registradas pelo bot · Não inclui toda a auditoria nativa do Discord" });
    await (0, panelInteraction_1.refreshPanel)(interaction, { content: null, attachments: [], embeds: [embed], components: [backRow("adm-logs:menu")] });
}
const component = {
    customId: "adm-logs:",
    async execute(interaction) {
        if (!interaction.guild)
            return;
        const member = await interaction.guild.members.fetch(interaction.user.id);
        if (!(await (0, permissions_1.isBotAdmin)(member))) {
            await interaction.reply({
                content: "🚫 Você não tem permissão para acessar esta seção.",
                ephemeral: true,
            });
            return;
        }
        const parts = interaction.customId.split(":");
        const action = parts[1];
        const sub = parts[2];
        switch (action) {
            case "menu":
                return renderLogsMenu(interaction);
            case "categorias":
                return renderLogCategories(interaction);
            case "canal":
                return renderLogChannelPicker(interaction, sub);
            case "auditoria":
                return renderRecentAudit(interaction);
            default:
                return renderLogsMenu(interaction);
        }
    },
};
exports.default = component;
