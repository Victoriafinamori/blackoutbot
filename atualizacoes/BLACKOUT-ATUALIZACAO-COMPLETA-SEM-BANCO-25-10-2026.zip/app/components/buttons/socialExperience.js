"use strict";
exports.default = {
  customId: "sx:",
  execute: (i) =>
    require("../../social-experience/interactions").memberButton(i),
};
