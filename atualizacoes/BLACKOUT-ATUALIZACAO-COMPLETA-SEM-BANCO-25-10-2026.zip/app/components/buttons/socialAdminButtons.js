"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderSocialAdmin = renderSocialAdmin;
const discord_js_1 = require("discord.js");
const permissions_1 = require("../../utils/permissions");
const admPanel_1 = require("../../utils/admPanel");
const admin_1 = require("../../social/admin");
const prisma_1 = require("../../database/prisma");
const service_1 = require("../../social/service");
async function renderSocialAdmin(i) { await i.update(await (0, admin_1.socialAdminView)(i.guild)); }
const input = (id, label, value, required = true) => new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId(id).setLabel(label).setStyle(discord_js_1.TextInputStyle.Short).setValue(value).setRequired(required));
const component = { customId: "social-admin:", async execute(i) {
        if (!i.guild || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return void await i.reply({ content: "Sem permissão.", flags: discord_js_1.MessageFlags.Ephemeral });
        const action = i.customId.split(":")[1], c = await (0, service_1.socialConfig)(i.guild.id);
        if (action === "back")
            return void await i.update(await (0, admPanel_1.buildAdmSectionPanel)(i.guild, "entretenimento"));
        if (action === "home")
            return void await i.update(await (0, admin_1.socialAdminView)(i.guild));
        if (action === "ranking")
            return void await i.update(await (0, admin_1.socialRankingView)(i.guild));
        if (action === "toggle") {
            if (!c.enabled && !c.instaChannelId)
                return void await i.reply({ content: "Configure o canal do INSTA antes de ativar.", flags: discord_js_1.MessageFlags.Ephemeral });
            await prisma_1.prisma.socialConfig.update({ where: { guildId: i.guild.id }, data: { enabled: !c.enabled } });
            await (0, service_1.refreshHighlights)(i.guild);
            return void await i.update(await (0, admin_1.socialAdminView)(i.guild));
        }
        if (action === "highlight-role-remove") {
            await prisma_1.prisma.socialConfig.update({ where: { guildId: i.guild.id }, data: { highlightRoleId: null } });
            await (0, service_1.refreshHighlights)(i.guild);
            return void await i.update(await (0, admin_1.socialHighlightsView)(i.guild));
        }
        if (action === "personalize")
            return void await i.showModal(new discord_js_1.ModalBuilder().setCustomId("social-admin-modal:personalize").setTitle("Aparência do INSTA").addComponents(input("title", "Título", c.title), input("description", "Texto", c.description), input("color", "Cor hexadecimal", c.color), input("thumbnail", "URL da thumbnail", c.thumbnail || "", false), input("image", "URL do banner/imagem", c.image || "", false)));
    } };
exports.default = component;
//# sourceMappingURL=socialAdminButtons.js.map
