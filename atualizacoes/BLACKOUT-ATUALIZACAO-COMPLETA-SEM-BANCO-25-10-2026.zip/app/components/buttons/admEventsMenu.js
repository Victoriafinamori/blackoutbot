"use strict";
const { prepareAdminPanel } = require("../../utils/adminTasks");
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderEventsMenu = renderEventsMenu;
const discord_js_1 = require("discord.js");
const adminUi_1 = require("../../utils/adminUi");
async function renderEventsMenu(i) {
    const embed = (await (0, adminUi_1.adminEmbed)(i.guild, "staff")).setColor(0xd71935).setTitle("Eventos de interação")
        .setDescription("Módulos para organizar eventos de interação sem substituir a brincadeira entre os membros.")
        .addFields({ name: "GAMES", value: "Base reutilizável para jogos em call e eventos sociais." }, { name: "🍾 Verdade ou Desafio • Modo Híbrido", value: "Use `/verdade` no canal do evento. O bot controla participantes, sorteio, fontes das rodadas e atualiza sempre a mesma embed." }, { name: "🎵 Game Musical • Duas Roletas", value: "Participação por botão, sorteio justo do participante e uma segunda roleta configurável somente para o gênero musical." }, { name: "Quiz em equipes", value: "Inscrições por time, perguntas e placar. Configuração acessível pelo botão abaixo." }, { name: "Permissão para iniciar", value: "Administradores do bot ou membros com permissão **Gerenciar Eventos**." }, { name: "Organização", value: "Prepare o jogo musical, Verdade ou Desafio ou o quiz em equipes." });
    await i.update(prepareAdminPanel(i.guild, 'eventos', { attachments: [], embeds: [embed], components: [new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-event-info:truth").setLabel("Como usar").setEmoji("🍾").setStyle(discord_js_1.ButtonStyle.Primary), new discord_js_1.ButtonBuilder().setCustomId("music-admin:menu").setLabel("Game Musical").setEmoji("🎵").setStyle(discord_js_1.ButtonStyle.Primary), new discord_js_1.ButtonBuilder().setCustomId("games-admin:war").setLabel("Quiz em equipes").setStyle(discord_js_1.ButtonStyle.Primary), new discord_js_1.ButtonBuilder().setCustomId("adm-event-info:back").setLabel("Voltar").setStyle(discord_js_1.ButtonStyle.Secondary))] }));
}
//# sourceMappingURL=admEventsMenu.js.map