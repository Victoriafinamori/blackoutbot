"use strict";
const { prepareAdminPanel } = require("../../utils/adminTasks");
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildSubmundoView = buildSubmundoView;
exports.renderSubmundoMenu = renderSubmundoMenu;
const discord_js_1 = require("discord.js");
const adminUi_1 = require("../../utils/adminUi");
const permissions_1 = require("../../utils/permissions");
const admPanel_1 = require("../../utils/admPanel");
const prisma_1 = require("../../database/prisma");
const service_1 = require("../../submundo/service");
const RED = 0xd71935;
const button = (id, label, style = discord_js_1.ButtonStyle.Secondary) => new discord_js_1.ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style);
async function buildSubmundoView(guild) {
    const [media, messages] = await Promise.all([
        (0, service_1.getAnonymousPhotoConfig)(guild.id),
        (0, service_1.getAnonymousMessageConfig)(guild.id),
    ]);
    const embed = (0, adminUi_1.adminEmbed)(guild, "entretenimento")
        .setColor(RED)
        .setTitle("Submundo")
        .addFields(
        { name: "ℹ️ Informações", value: `Fotos/Vídeos Anônimos: **${media.enabled ? "✅ Ativado" : "❌ Desativado"}**\nMensagens Anônimas: **${messages.enabled ? "✅ Ativado" : "❌ Desativado"}**\nDestaque: **${media.highlightEnabled ? "✅ Ativado" : "❌ Desativado"}**` },
        { name: "📸 Fotos/Vídeos", value: `Canal: ${media.destinationChannelId ? `<#${media.destinationChannelId}>` : "Não configurado"}\nHorário: **${(0, service_1.scheduleText)(media)}**`, inline: true },
        { name: "💌 Mensagens", value: `Canal: ${messages.destinationChannelId ? `<#${messages.destinationChannelId}>` : "Não configurado"}\nHorário: **${(0, service_1.scheduleText)(messages)}**`, inline: true },
        { name: "⭐ Destaque", value: `Canal: ${media.highlightChannelId ? `<#${media.highlightChannelId}>` : "Não configurado"}\nCritério: **Mais 🔥**\nPublicação automática: **ao fechamento**` },
        { name: "📝 Observações", value: "1. O autor nunca aparece nas publicações públicas.\n2. A identidade fica registrada somente nos logs configurados dentro de cada função.\n3. Fotos/Vídeos e Mensagens podem ter horários e limpeza independentes." });
    
    const actions = new discord_js_1.ActionRowBuilder().addComponents(
        button("adm-submundo:back", "Voltar", discord_js_1.ButtonStyle.Primary),
        button("adm-submundo:photos", "Fotos/Vídeos"),
        button("adm-submundo:messages", "Mensagens"),
        button("adm-submundo:highlight", "Destaque"),
        button("adm-submundo:reset", "Resetar Tudo", discord_js_1.ButtonStyle.Danger));
    return prepareAdminPanel(guild, 'submundo', { attachments: [], embeds: [embed], components: [actions, require("../../social-experience/common").row(require("../../social-experience/common").btn("sx-admin:anonymous","Privacidade e aprovação"))] });
}
async function renderSubmundoMenu(i) { await i.update(await buildSubmundoView(i.guild)); }
async function resetAll(guild) {
    const media = await (0, service_1.getAnonymousPhotoConfig)(guild.id);
    const messages = await (0, service_1.getAnonymousMessageConfig)(guild.id);
    if (media.panelMessageId) {
        await prisma_1.prisma.anonymousPhotoConfig.update({ where: { guildId: guild.id }, data: { enabled: false } });
        await (0, service_1.refreshAnonymousMediaPanel)(guild).catch(() => null);
    }
    if (messages.panelMessageId) {
        await prisma_1.prisma.anonymousMessageConfig.update({ where: { guildId: guild.id }, data: { enabled: false } });
        await (0, service_1.refreshAnonymousMessagePanel)(guild).catch(() => null);
    }
    await prisma_1.prisma.$transaction([
        prisma_1.prisma.anonymousPhotoConfig.update({ where: { guildId: guild.id }, data: {
            enabled: false, panelChannelId: null, panelMessageId: null, destinationChannelId: null, logChannelId: null,
            title: "Fotos e Vídeos Anônimos", description: "Envie uma foto ou vídeo de forma anônima. Sua identidade não será exibida publicamente.",
            color: "D20B20", image: null, footer: "Sua identidade não será exibida publicamente.", buttonLabel: "Enviar foto/vídeo",
            openTime: null, closeTime: null, cleanupOnClose: false, lastPanelOpen: false, lastCleanupSession: null,
            highlightEnabled: false, highlightChannelId: null, lastHighlightSession: null,
        } }),
        prisma_1.prisma.anonymousMessageConfig.update({ where: { guildId: guild.id }, data: {
            enabled: false, panelChannelId: null, panelMessageId: null, destinationChannelId: null, logChannelId: null,
            title: "📮 Correio Anônimo", description: "Tem algo que você quer dizer sem colocar seu nome? Escreva sua mensagem e deixe o correio entregar por você.",
            color: "D20B20", image: null, footer: null, buttonLabel: "Enviar mensagem",
            openTime: null, closeTime: null, cleanupOnClose: false, lastPanelOpen: false, lastCleanupSession: null,
        } }),
    ]);
    // Mantém as submissões no banco. Painéis antigos são desativados antes de os IDs serem limpos.
}
const component = { customId: "adm-submundo:", async execute(i) {
    if (!i.guild) return;
    if (!await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
        return void await i.reply({ content: "Você não possui permissão.", flags: discord_js_1.MessageFlags.Ephemeral });
    const action = i.customId.split(":")[1];
    if (action === "back") return void await i.update(await (0, admPanel_1.buildAdmSectionPanel)(i.guild, "entretenimento"));
    if (action === "photos") {
        const mod = require("./admAnonymousPhotoMenu");
        return void await i.update(await mod.buildAnonymousPhotoAdminView(i.guild));
    }
    if (action === "messages") {
        const mod = require("./admAnonymousMessageMenu");
        return void await i.update(await mod.buildAnonymousMessageAdminView(i.guild));
    }
    if (action === "highlight") {
        const mod = require("./admSubmundoHighlightMenu");
        return void await i.update(await mod.buildSubmundoHighlightView(i.guild));
    }
    if (action === "reset") {
        const embed = (0, adminUi_1.adminEmbed)(i.guild, "entretenimento").setColor(RED).setTitle("Resetar Submundo").setDescription("Isso restaura as configurações de Fotos/Vídeos, Mensagens e Destaque. **O histórico de envios não será apagado.**");
        const row = new discord_js_1.ActionRowBuilder().addComponents(button("adm-submundo:reset-confirm", "Confirmar Reset", discord_js_1.ButtonStyle.Danger), button("adm-submundo:home", "Cancelar"));
        return void await i.update({ attachments: [], embeds: [embed], components: [row] });
    }
    if (action === "reset-confirm") {
        await resetAll(i.guild);
        return void await i.update(await buildSubmundoView(i.guild));
    }
    if (action === "home") return void await i.update(await buildSubmundoView(i.guild));
} };
exports.default = component;
