"use strict";
const { prepareAdminPanel } = require("../../utils/adminTasks");
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderPartnershipsMenu = renderPartnershipsMenu;
const discord_js_1 = require("discord.js");
const adminUi_1 = require("../../utils/adminUi");
const admPanel_1 = require("../../utils/admPanel");
const permissions_1 = require("../../utils/permissions");
const partnerships_1 = require("../../utils/partnerships");
const prisma_1 = require("../../database/prisma");
const styleName = (value) => ({ PRIMARY: "Azul", SECONDARY: "Cinza", SUCCESS: "Verde", DANGER: "Vermelho" }[String(value || "SUCCESS").toUpperCase()] || "Verde");
async function showPanelEditor(i) { return require('../../utils/adminMessagePreview').showAdminMessagePreview(i, 'parcerias'); }

async function renderPartnershipsMenu(i) {
    const c = await (0, partnerships_1.partnershipConfig)(i.guild.id);
    const e = (await (0, adminUi_1.adminEmbed)(i.guild, "atendimento")).setColor(0xd71935).setTitle("🤝 Configurações — Parcerias").setDescription("Painel privado para receber, analisar e concluir propostas de parceria.")
        .addFields({ name: "ℹ️ Informações", value: `Status: ${c.enabled ? "✅ Ativado" : "❌ Desativado"}\nCanal do painel: ${c.panelChannelId ? `<#${c.panelChannelId}>` : "Não configurado"}\nCategoria: ${c.categoryId ? `<#${c.categoryId}>` : "Não configurada"}\nLogs: ${c.logChannelId ? `<#${c.logChannelId}>` : "Não configurado"}` }, { name: "👮 Atendimento", value: `Cargos responsáveis: ${(0, partnerships_1.ids)(c.staffRoleIds).map(x => `<@&${x}>`).join(", ") || "Não configurado"}\nCargo ao aprovar: ${c.partnerRoleId ? `<@&${c.partnerRoleId}>` : "Não configurado"}\nDivulgação: ${c.publishChannelId ? `<#${c.publishChannelId}>` : "Não configurada"}` }, { name: "🎨 Painel", value: `Título: **${c.panelTitle}**\nBotão: ${c.panelButtonEmoji || ""} **${c.panelButtonLabel}** • ${styleName(c.panelButtonStyle)}` }, { name: "📋 Requisitos", value: `Mínimo de membros: **${c.minMembers}**\nCooldown após recusa: **${c.cooldownDays} dia(s)**` });
    const rows = [
        new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("parceria-admin:toggle").setLabel(c.enabled ? "Desativar" : "Ativar").setStyle(c.enabled ? discord_js_1.ButtonStyle.Danger : discord_js_1.ButtonStyle.Success), new discord_js_1.ButtonBuilder().setCustomId("parceria-admin:channels").setLabel("Canais").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId("parceria-admin:roles").setLabel("Cargos").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId("parceria-admin:appearance").setLabel("Painel").setEmoji("🎨").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId("parceria-admin:requirements").setLabel("Requisitos").setStyle(discord_js_1.ButtonStyle.Secondary)),
        new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("parceria-admin:publish").setLabel("Publicar/Atualizar").setEmoji("📨").setStyle(discord_js_1.ButtonStyle.Success), new discord_js_1.ButtonBuilder().setCustomId("parceria-admin:back").setLabel("Voltar").setStyle(discord_js_1.ButtonStyle.Secondary)),
    ];
    await i.update(prepareAdminPanel(i.guild, 'parcerias', { attachments: [], embeds: [e], components: rows }));
}
const component = { customId: "parceria-admin:", async execute(i) {
        if (!i.guild)
            return;
        if (!(await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id))))
            return void await i.reply({ content: "Sem permissão.", ephemeral: true });
        const a = i.customId.split(":")[1];
        if (a === "channels" || a === "roles") return require("../../utils/panelInteraction").refreshPanel(i, await require("../../utils/partnershipSettings").partnershipSettingsPayload(i.guild,a));
        const c = await (0, partnerships_1.partnershipConfig)(i.guild.id);
        if (a === "back")
            return void await i.update(await (0, admPanel_1.buildAdmSectionPanel)(i.guild, "atendimento"));
        if (a === "toggle") {
            await prisma_1.prisma.partnershipConfig.update({ where: { guildId: i.guild.id }, data: { enabled: !c.enabled } });
            return renderPartnershipsMenu(i);
        }
        if (a === "publish") {
            try {
                await (0, partnerships_1.publishPartnershipPanel)(i.guild);
                await i.reply({ content: "✅ Painel publicado/atualizado.", ephemeral: true });
            }
            catch (e) {
                await i.reply({ content: `❌ ${e instanceof Error ? e.message : "Erro ao publicar."}`, ephemeral: true });
            }
            return;
        }
        if (a === "appearance")
            return void await showPanelEditor(i);
        if (a === "edit-embed") {
            const m = new discord_js_1.ModalBuilder().setCustomId("parceria:appearance").setTitle("Embed de Parcerias").addComponents(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("title").setLabel("Título").setStyle(discord_js_1.TextInputStyle.Short).setValue(c.panelTitle).setRequired(true)), new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("description").setLabel("Descrição").setStyle(discord_js_1.TextInputStyle.Paragraph).setValue(c.panelDescription).setMaxLength(2000).setRequired(true)), new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("color").setLabel("Cor HEX").setStyle(discord_js_1.TextInputStyle.Short).setValue(c.embedColor.replace("#", "")).setRequired(true)), new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("footer").setLabel("Rodapé").setStyle(discord_js_1.TextInputStyle.Short).setValue(c.embedFooter).setRequired(false)), new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("assets").setLabel("THUMBNAIL=URL / IMAGEM=URL").setStyle(discord_js_1.TextInputStyle.Paragraph).setValue(`THUMBNAIL=${c.embedThumbnail || ""}\nIMAGEM=${c.embedImage || ""}`).setRequired(false)));
            return void await i.showModal(m);
        }
        if (a === "edit-button") {
            const m = new discord_js_1.ModalBuilder().setCustomId("parceria:button").setTitle("Botão do Painel").addComponents(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("label").setLabel("Texto do botão").setStyle(discord_js_1.TextInputStyle.Short).setMaxLength(80).setValue(c.panelButtonLabel || "Solicitar parceria").setRequired(true)), new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("emoji").setLabel("Emoji (opcional)").setStyle(discord_js_1.TextInputStyle.Short).setMaxLength(50).setValue(c.panelButtonEmoji || "").setRequired(false)), new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("style").setLabel("Cor: AZUL, CINZA, VERDE ou VERMELHO").setStyle(discord_js_1.TextInputStyle.Short).setValue(styleName(c.panelButtonStyle).toUpperCase()).setRequired(true)));
            return void await i.showModal(m);
        }
        if (a === "channels") {
            const rows = [
                new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ChannelSelectMenuBuilder().setCustomId("parceria-admin-select:panel").setPlaceholder("Canal do painel").addChannelTypes(discord_js_1.ChannelType.GuildText)),
                new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ChannelSelectMenuBuilder().setCustomId("parceria-admin-select:category").setPlaceholder("Categoria dos atendimentos").addChannelTypes(discord_js_1.ChannelType.GuildCategory)),
                new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ChannelSelectMenuBuilder().setCustomId("parceria-admin-select:logs").setPlaceholder("Canal de logs").addChannelTypes(discord_js_1.ChannelType.GuildText)),
                new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ChannelSelectMenuBuilder().setCustomId("parceria-admin-select:publish").setPlaceholder("Canal de divulgação").addChannelTypes(discord_js_1.ChannelType.GuildText)),
            ];
            return void await i.reply({ content: "Configure os canais da Central de Parcerias:", components: rows, ephemeral: true });
        }
        if (a === "roles") {
            const rows = [
                new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.RoleSelectMenuBuilder().setCustomId("parceria-admin-select:staff").setPlaceholder("Cargos responsáveis").setMinValues(1).setMaxValues(10)),
                new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.RoleSelectMenuBuilder().setCustomId("parceria-admin-select:partner").setPlaceholder("Cargo concedido ao aprovar").setMinValues(1).setMaxValues(1)),
            ];
            return void await i.reply({ content: "Configure os cargos:", components: rows, ephemeral: true });
        }
        if (a === "requirements") {
            const m = new discord_js_1.ModalBuilder().setCustomId("parceria:requirements").setTitle("Requisitos de Parceria").addComponents(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("minMembers").setLabel("Mínimo de membros (0 = sem mínimo)").setStyle(discord_js_1.TextInputStyle.Short).setValue(String(c.minMembers)).setRequired(true)), new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("cooldownDays").setLabel("Cooldown após recusa (dias)").setStyle(discord_js_1.TextInputStyle.Short).setValue(String(c.cooldownDays)).setRequired(true)));
            return void await i.showModal(m);
        }
    } };
exports.default = component;
//# sourceMappingURL=admPartnershipsMenu.js.map