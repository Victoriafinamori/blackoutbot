"use strict";
const { prepareAdminPanel } = require("../../utils/adminTasks");
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderFamiliasMenu = renderFamiliasMenu;
exports.renderFamiliesList = renderFamiliesList;
exports.renderFamilyDetail = renderFamilyDetail;
exports.renderFamilyInfo = renderFamilyInfo;
exports.renderExcluirConfirm = renderExcluirConfirm;
exports.renderLeaderUserPicker = renderLeaderUserPicker;
exports.renderFamiliaPicker = renderFamilyPicker;
const discord_js_1 = require("discord.js");
const permissions_1 = require("../../utils/permissions");
const adminUi_1 = require("../../utils/adminUi");
const families_1 = require("../../utils/families");
const adminDrafts_1 = require("../../family-app/adminDrafts");
const adminViews_1 = require("../../family-app/adminViews");
const phaseOneViews_1 = require("../../family-app/phaseOneViews");
const prisma_1 = require("../../database/prisma");
const movStats_1 = require("../../utils/movStats");
function backRow(customId, label = "Voltar") {
    return new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId(customId).setLabel(label).setStyle(discord_js_1.ButtonStyle.Secondary));
}
async function replyOrUpdate(interaction, payload) {
    if (interaction.isButton() || interaction.isAnySelectMenu()) {
        await interaction.update(payload);
        return;
    }
    if (interaction.isFromMessage()) {
        await interaction.update(payload);
    }
    else {
        await interaction.reply({ ...payload, ephemeral: true });
    }
}
async function renderFamiliasMenu(interaction) {
    await interaction.update(prepareAdminPanel(interaction.guild, 'familias', await (0, phaseOneViews_1.familyOverviewView)(interaction.guild)));
}
async function openCreateFamilyModal(interaction) {
    const modal = new discord_js_1.ModalBuilder().setCustomId("adm-modal:familia:criar").setTitle("Criar Família/Irmandade");
    const nameInput = new discord_js_1.TextInputBuilder()
        .setCustomId("name")
        .setLabel("Nome da Família/Irmandade")
        .setStyle(discord_js_1.TextInputStyle.Short)
        .setPlaceholder("Ex: Black Dragons")
        .setRequired(true)
        .setMaxLength(60);
    modal.addComponents(new discord_js_1.ActionRowBuilder().addComponents(nameInput));
    await interaction.showModal(modal);
}
async function renderFamilyPicker(interaction, action) {
    const families = await (0, families_1.listFamilies)(interaction.guild.id);
    const titles = {
        detail: "Editar Família",
        excluir: "Excluir Família",
        lider: "Definir Líder",
        info: "Visualizar Informações",
    };
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor"))
        .setTitle(titles[action] ?? "Famílias")
        .setDescription(families.length === 0
        ? "Nenhuma Família/Irmandade cadastrada ainda. Use **Criar Família** primeiro."
        : "Selecione a Família abaixo.");
    const components = [];
    if (families.length > 0) {
        const select = new discord_js_1.StringSelectMenuBuilder()
            .setCustomId(`adm-familia-picker:${action}`)
            .setPlaceholder("Selecione uma Família...")
            .addOptions(families.slice(0, 25).map((f) => ({
            value: f.id,
            label: f.name,
            description: f.active ? "Ativa" : "Inativa",
        })));
        components.push(new discord_js_1.ActionRowBuilder().addComponents(select));
    }
    components.push(backRow("adm-familias:menu"));
    await interaction.update({ attachments: [], embeds: [embed], components });
}
async function renderFamiliesList(interaction) {
    const families = await (0, families_1.listFamilies)(interaction.guild.id);
    const summaries = await Promise.all(families.map(async (f) => ({ family: f, members: (await (0, families_1.getFamilyMembers)(interaction.guild, f)).length })));
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor"))
        .setTitle("FAMÍLIAS - AUDAZ")
        .addFields({ name: "Informações", value: `Famílias cadastradas: ${families.length}\nAtivas: ${families.filter(f => f.active).length}\nDesativadas: ${families.filter(f => !f.active).length}` }, { name: "Gerenciamento", value: families.length ? "Selecione uma família abaixo para visualizar ou alterar suas configurações." : "Nenhuma família cadastrada. Use o botão abaixo para adicionar a primeira." });
    const components = [];
    if (families.length > 0) {
        const select = new discord_js_1.StringSelectMenuBuilder()
            .setCustomId("adm-familia-picker:detail")
            .setPlaceholder("Selecione uma Família para ver/editar...")
            .addOptions(families.slice(0, 25).map((f) => ({
            value: f.id,
            label: f.name,
            description: `${summaries.find(x => x.family.id === f.id)?.members || 0} membros - ${f.active ? "Ativa" : "Desativada"}`,
        })));
        components.push(new discord_js_1.ActionRowBuilder().addComponents(select));
    }
    components.push(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-familias:menu").setLabel("Voltar").setStyle(discord_js_1.ButtonStyle.Primary), new discord_js_1.ButtonBuilder().setCustomId("adm-familias:criar").setLabel("Adicionar Família").setStyle(discord_js_1.ButtonStyle.Success)));
    await interaction.update({ attachments: [], embeds: [embed], components });
}
async function renderFamilyDetail(interaction, familyId) {
    const family = await (0, families_1.getFamily)(interaction.guild.id, familyId);
    if (!family) {
        await interaction.reply({ content: "Família não encontrada. Ela pode ter sido excluída.", ephemeral: true });
        return;
    }
    const [representatives, members] = await Promise.all([(0, families_1.listFamilyRepresentatives)(family.id), (0, families_1.getFamilyMembers)(interaction.guild, family)]);
    const since = new Date(Date.now() - 6 * 86400000).toISOString().slice(0, 10), memberIds = members.map(m => m.id);
    const [chat, call, chatActive, callActive] = await Promise.all([prisma_1.prisma.familyChatDailyStat.aggregate({ where: { familyId, date: { gte: since } }, _sum: { count: true } }), memberIds.length ? prisma_1.prisma.movCallDailyStat.aggregate({ where: { guildId: interaction.guild.id, userId: { in: memberIds }, date: { gte: since } }, _sum: { seconds: true } }) : null, prisma_1.prisma.familyChatDailyStat.findMany({ where: { familyId, date: { gte: since }, count: { gt: 0 } }, select: { userId: true } }), memberIds.length ? prisma_1.prisma.movCallDailyStat.findMany({ where: { guildId: interaction.guild.id, userId: { in: memberIds }, date: { gte: since }, seconds: { gt: 0 } }, select: { userId: true } }) : []]);
    const active = new Set([...chatActive.map(x => x.userId), ...callActive.map(x => x.userId)]).size;
    const missing = [];
    if (family.leaderUserId && !await interaction.guild.members.fetch(family.leaderUserId).catch(() => null))
        missing.push("O dono cadastrado não está mais no servidor.");
    for (const representative of representatives)
        if (!await interaction.guild.members.fetch(representative.userId).catch(() => null))
            missing.push(`O representante <@${representative.userId}> não está mais no servidor.`);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor"))
        .setTitle(`${family.name.toUpperCase()} - PAINEL DA FAMÍLIA`)
        .addFields({ name: "Informações", value: `Status: ${family.active ? "Ativa" : "Desativada"}\nDono: ${family.leaderUserId ? `<@${family.leaderUserId}>` : "Não definido"}\nCargo: ${family.memberRoleId ? `<@&${family.memberRoleId}>` : "Não definido"}\nCall oficial: ${family.voiceChannelId ? `<#${family.voiceChannelId}>` : "Não configurada"}` }, { name: "Liderança", value: `Representantes: ${representatives.length}\nMembros: ${members.length}` }, { name: "Atividade", value: `Ativos na semana: ${active}\nAusentes: ${Math.max(0, members.length - active)}\nMensagens: ${(chat._sum.count || 0).toLocaleString("pt-BR")}\nCall: ${(0, movStats_1.formatDuration)(call?._sum.seconds || 0)}` })
        .setDescription(missing.length ? missing.map(x => `Atenção: ${x}`).join("\n") : null);
    const row1 = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-familias:listar").setLabel("Voltar").setStyle(discord_js_1.ButtonStyle.Primary), new discord_js_1.ButtonBuilder().setCustomId(`adm-familias:members:${family.id}:0`).setLabel("Membros").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId(`adm-familias:leadership:${family.id}`).setLabel("Liderança").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId(`adm-familias:edit:${family.id}`).setLabel("Configurar").setStyle(discord_js_1.ButtonStyle.Secondary));
    const row2 = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId(`adm-familias:toggleconfirm:${family.id}`).setLabel(family.active ? "Desativar" : "Ativar").setStyle(family.active ? discord_js_1.ButtonStyle.Danger : discord_js_1.ButtonStyle.Success), new discord_js_1.ButtonBuilder().setCustomId(`adm-familias:excluirconfirm:${family.id}`).setLabel("Excluir").setStyle(discord_js_1.ButtonStyle.Danger));
    await replyOrUpdate(interaction, { attachments: [], embeds: [embed], components: [row1, row2] });
}
async function renderEditMenu(interaction, familyId) {
    const family = await (0, families_1.getFamily)(interaction.guild.id, familyId);
    if (!family)
        return;
    const monitored = (0, families_1.getFamilyMonitoredChannelIds)(family);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor")).setTitle(`CONFIGURAR - ${family.name.toUpperCase()}`).addFields({ name: "Identidade", value: `Nome: ${family.name}\nCargo: ${family.memberRoleId ? `<@&${family.memberRoleId}>` : "Não configurado"}\nDono: ${family.leaderUserId ? `<@${family.leaderUserId}>` : "Não configurado"}` }, { name: "Canais", value: `Call oficial: ${family.voiceChannelId ? `<#${family.voiceChannelId}>` : "Não configurada"}\nMov Chat: ${monitored.length ? `${monitored.length} canal(is) monitorado(s)` : "Não configurado"}\nPainel oficial: ${family.panelChannelId ? `<#${family.panelChannelId}>` : "Não publicado"}` }, { name: "Sistema", value: `Status: ${family.active ? "Ativada" : "Desativada"}` }).setTimestamp();
    const row1 = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId(`adm-familias:nome:${familyId}`).setLabel("Nome").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId(`adm-familias:cargomembro:${familyId}`).setLabel("Cargo").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId(`adm-familias:owner:${familyId}`).setLabel("Dono").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId(`adm-familias:leadership:${familyId}`).setLabel("Representantes").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId(`adm-familias:toggleconfirm:${familyId}`).setLabel("Status").setStyle(discord_js_1.ButtonStyle.Secondary));
    const row2 = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId(`adm-familias:canalvoz:${familyId}`).setLabel("Call Oficial").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId(`adm-familias:canaismonitor:${familyId}`).setLabel("Mov Chat").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId(`family-app-admin:panel:${familyId}`).setLabel(family.panelMessageId ? "Atualizar Painel" : "Publicar Painel").setStyle(discord_js_1.ButtonStyle.Primary));
    await interaction.update({ attachments: [], embeds: [embed], components: [row1, row2, backRow(`adm-familias:detail:${familyId}`)] });
}
async function renderMembers(interaction, familyId, page) {
    const family = await (0, families_1.getFamily)(interaction.guild.id, familyId);
    if (!family)
        return;
    const reps = await (0, families_1.listFamilyRepresentatives)(familyId), repIds = new Set(reps.map(x => x.userId));
    const members = (await (0, families_1.getFamilyMembers)(interaction.guild, family)).sort((a, b) => a.displayName.localeCompare(b.displayName, "pt-BR"));
    const pages = Math.max(1, Math.ceil(members.length / 10)), safe = Math.max(0, Math.min(page, pages - 1));
    const list = members.slice(safe * 10, safe * 10 + 10).map((m, n) => `${safe * 10 + n + 1}. ${m} | ${m.id === family.leaderUserId ? "Dono" : repIds.has(m.id) ? "Representante" : "Membro"}`).join("\n") || "Nenhum membro possui o cargo configurado.";
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor")).setTitle(`MEMBROS — ${family.name}`).setDescription(`**Cargo utilizado:** ${family.memberRoleId ? `<@&${family.memberRoleId}>` : "Não definido"}\n**Total:** ${members.length} membros\n\n${list}`).setFooter({ text: `Página ${safe + 1}/${pages} | Fonte: cargo do Discord` });
    const nav = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId(`adm-familias:members:${familyId}:${safe - 1}`).setLabel("Anterior").setStyle(discord_js_1.ButtonStyle.Secondary).setDisabled(safe === 0), new discord_js_1.ButtonBuilder().setCustomId(`adm-familias:members:${familyId}:${safe + 1}`).setLabel("Próxima").setStyle(discord_js_1.ButtonStyle.Secondary).setDisabled(safe >= pages - 1));
    await interaction.update({ attachments: [], embeds: [embed], components: [nav, backRow(`adm-familias:detail:${familyId}`)] });
}
async function renderLeadership(interaction, familyId) {
    const family = await (0, families_1.getFamily)(interaction.guild.id, familyId);
    if (!family)
        return;
    const reps = await (0, families_1.listFamilyRepresentatives)(familyId);
    const statuses = await Promise.all(reps.map(async (r) => ({ r, exists: !!await interaction.guild.members.fetch(r.userId).catch(() => null) })));
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor")).setTitle(`LIDERANÇA — ${family.name}`).setDescription(`**Dono**\n${family.leaderUserId ? `<@${family.leaderUserId}>` : "Não definido"}\n\n**Representantes**\n${statuses.length ? statuses.map((x, n) => `${n + 1}. <@${x.r.userId}>${x.exists ? "" : " | Fora do servidor"}`).join("\n") : "Nenhum representante"}`);
    const row = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId(`adm-familias:owner:${familyId}`).setLabel("Trocar dono").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId(`adm-familias:repadd:${familyId}`).setLabel("Adicionar representante").setStyle(discord_js_1.ButtonStyle.Success), new discord_js_1.ButtonBuilder().setCustomId(`adm-familias:repremove:${familyId}`).setLabel("Remover representante").setStyle(discord_js_1.ButtonStyle.Danger));
    await interaction.update({ attachments: [], embeds: [embed], components: [row, backRow(`adm-familias:detail:${familyId}`)] });
}
async function renderStatusConfirm(interaction, familyId) { const family = await (0, families_1.getFamily)(interaction.guild.id, familyId); if (!family)
    return; const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor")).setTitle(family.active ? `DESATIVAR ${family.name.toUpperCase()}?` : `ATIVAR ${family.name.toUpperCase()}?`).setDescription(family.active ? "A família permanecerá cadastrada, com sua liderança, cargo e históricos preservados. Seus sistemas ficarão temporariamente indisponíveis." : "A família voltará a participar dos sistemas ativos."); const row = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId(`adm-familias:toggle:${familyId}`).setLabel(family.active ? "Confirmar desativação" : "Confirmar ativação").setStyle(family.active ? discord_js_1.ButtonStyle.Danger : discord_js_1.ButtonStyle.Success), new discord_js_1.ButtonBuilder().setCustomId(`adm-familias:detail:${familyId}`).setLabel("Cancelar").setStyle(discord_js_1.ButtonStyle.Secondary)); await interaction.update({ attachments: [], embeds: [embed], components: [row] }); }
async function renderFamilyInfo(interaction, familyId) {
    const family = await (0, families_1.getFamily)(interaction.guild.id, familyId);
    if (!family) {
        await interaction.reply({ content: "Família não encontrada. Ela pode ter sido excluída.", ephemeral: true });
        return;
    }
    const members = await (0, families_1.getFamilyMembers)(interaction.guild, family);
    const monitored = (0, families_1.getFamilyMonitoredChannelIds)(family);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor"))
        .setTitle(family.name)
        .setDescription(`**Líder atual:** ${family.leaderUserId ? `<@${family.leaderUserId}>` : "*não definido*"}\n` +
        `**Quantidade de membros:** ${members.length}\n` +
        `**Cargo dos Membros:** ${family.memberRoleId ? `<@&${family.memberRoleId}>` : "*não definido*"}\n` +
        `**Cargo do Líder:** ${family.leaderRoleId ? `<@&${family.leaderRoleId}>` : "*não definido*"}\n` +
        `**Canal de Voz:** ${family.voiceChannelId ? `<#${family.voiceChannelId}>` : "*não definido*"}\n` +
        `**Canais Monitorados:** ${monitored.length ? monitored.map((id) => `<#${id}>`).join(", ") : "*nenhum*"}\n` +
        `**Status do Sistema:** ${family.active ? "Ativo" : "Inativo"}`);
    await replyOrUpdate(interaction, { attachments: [], embeds: [embed], components: [backRow("adm-familias:pick:info")] });
}
async function renderExcluirConfirm(interaction, familyId) {
    const family = await (0, families_1.getFamily)(interaction.guild.id, familyId);
    if (!family) {
        await interaction.reply({ content: "Família não encontrada.", ephemeral: true });
        return;
    }
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor"))
        .setTitle("CONFIRMAR EXCLUSÃO")
        .setDescription(`Você está prestes a excluir o cadastro da família **${family.name}**.\n\n` +
        "Esta ação remove os dados vinculados no bot. Os cargos e canais do Discord **não serão excluídos automaticamente**.");
    const row = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId(`adm-familias:excluirok:${family.id}`).setLabel("Sim, excluir").setStyle(discord_js_1.ButtonStyle.Danger), new discord_js_1.ButtonBuilder().setCustomId(`adm-familias:detail:${family.id}`).setLabel("Cancelar").setStyle(discord_js_1.ButtonStyle.Secondary));
    await interaction.update({ attachments: [], embeds: [embed], components: [row] });
}
async function handleExcluirOk(interaction, familyId) {
    try {
        await (0, families_1.deleteFamily)(interaction.guild, interaction.user.id, familyId);
    }
    catch (err) {
        if (err instanceof families_1.FamilyError) {
            await interaction.reply({ content: err.message, ephemeral: true });
            return;
        }
        throw err;
    }
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor"))
        .setTitle("FAMÍLIA EXCLUÍDA")
        .setDescription("A família foi removida do sistema.");
    await interaction.update({ attachments: [], embeds: [embed], components: [backRow("adm-familias:menu")] });
}
async function handleToggleActive(interaction, familyId) {
    const family = await (0, families_1.getFamily)(interaction.guild.id, familyId);
    if (!family) {
        await interaction.reply({ content: "Família não encontrada.", ephemeral: true });
        return;
    }
    try {
        await (0, families_1.updateFamily)(interaction.guild, interaction.user.id, familyId, { active: !family.active });
    }
    catch (err) {
        if (err instanceof families_1.FamilyError) {
            await interaction.reply({ content: err.message, ephemeral: true });
            return;
        }
        throw err;
    }
    await renderFamilyDetail(interaction, familyId);
}
function openEditNameModal(interaction, familyId) {
    const modal = new discord_js_1.ModalBuilder().setCustomId(`adm-modal:familia:nome:${familyId}`).setTitle("Editar Nome");
    const nameInput = new discord_js_1.TextInputBuilder()
        .setCustomId("name")
        .setLabel("Nome da Família/Irmandade")
        .setStyle(discord_js_1.TextInputStyle.Short)
        .setRequired(true)
        .setMaxLength(60);
    modal.addComponents(new discord_js_1.ActionRowBuilder().addComponents(nameInput));
    return interaction.showModal(modal);
}
async function renderRolePickerScreen(interaction, familyId, kind) {
    const family = await (0, families_1.getFamily)(interaction.guild.id, familyId);
    if (!family) {
        await interaction.reply({ content: "Família não encontrada.", ephemeral: true });
        return;
    }
    const isMembro = kind === "membro";
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor"))
        .setTitle(isMembro ? `CARGO DE MEMBROS — ${family.name}` : `CARGO DO LÍDER — ${family.name}`)
        .setDescription(isMembro
        ? "Selecione o cargo que define quem é membro dessa Família."
        : "Selecione o cargo que o Dono da Família precisa possuir.");
    const select = new discord_js_1.RoleSelectMenuBuilder()
        .setCustomId(`adm-role-select:${isMembro ? "familymember" : "familyleader"}:${familyId}`)
        .setPlaceholder("Selecione o cargo")
        .setMinValues(1)
        .setMaxValues(1);
    const selectRow = new discord_js_1.ActionRowBuilder().addComponents(select);
    await interaction.update({ attachments: [], embeds: [embed], components: [selectRow, backRow(`adm-familias:detail:${familyId}`)] });
}
async function renderVoiceChannelPicker(interaction, familyId) {
    const family = await (0, families_1.getFamily)(interaction.guild.id, familyId);
    if (!family) {
        await interaction.reply({ content: "Família não encontrada.", ephemeral: true });
        return;
    }
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor"))
        .setTitle(`CANAL DE VOZ — ${family.name}`)
        .setDescription("Selecione o canal de voz oficial dessa Família (usado em Gerenciar Call, no /grupo).");
    const select = new discord_js_1.ChannelSelectMenuBuilder()
        .setCustomId(`adm-familychannel-select:voice:${familyId}`)
        .setPlaceholder("Selecione o canal de voz")
        .addChannelTypes(discord_js_1.ChannelType.GuildVoice)
        .setMinValues(1)
        .setMaxValues(1);
    const selectRow = new discord_js_1.ActionRowBuilder().addComponents(select);
    await interaction.update({ attachments: [], embeds: [embed], components: [selectRow, backRow(`adm-familias:detail:${familyId}`)] });
}
async function renderMonitorChannelsPicker(interaction, familyId) {
    const family = await (0, families_1.getFamily)(interaction.guild.id, familyId);
    if (!family) {
        await interaction.reply({ content: "Família não encontrada.", ephemeral: true });
        return;
    }
    const current = (0, families_1.getFamilyMonitoredChannelIds)(family);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor"))
        .setTitle(`CANAIS MONITORADOS — ${family.name}`)
        .setDescription(`Selecione até ${families_1.MAX_FAMILY_MONITORED_CHANNELS} canais de texto que serão contados no Mov Chat exclusivo dessa Família.\n\n` +
        `**Atuais:** ${current.length ? current.map((id) => `<#${id}>`).join(", ") : "*nenhum*"}`);
    const select = new discord_js_1.ChannelSelectMenuBuilder()
        .setCustomId(`adm-familychannel-select:monitor:${familyId}`)
        .setPlaceholder(`Selecione até ${families_1.MAX_FAMILY_MONITORED_CHANNELS} canais`)
        .addChannelTypes(discord_js_1.ChannelType.GuildText)
        .setMinValues(0)
        .setMaxValues(families_1.MAX_FAMILY_MONITORED_CHANNELS);
    if (current.length)
        select.setDefaultChannels(current);
    const selectRow = new discord_js_1.ActionRowBuilder().addComponents(select);
    await interaction.update({ attachments: [], embeds: [embed], components: [selectRow, backRow(`adm-familias:detail:${familyId}`)] });
}
async function renderLeaderUserPicker(interaction, familyId) {
    const family = await (0, families_1.getFamily)(interaction.guild.id, familyId);
    if (!family) {
        await interaction.reply({ content: "Família não encontrada.", ephemeral: true });
        return;
    }
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor"))
        .setTitle(`DEFINIR LÍDER — ${family.name}`)
        .setDescription(`Selecione o usuário que será o Dono oficial. A identificação é feita pelo ID, sem exigir um cargo específico.\n\n` +
        `**Dono atual:** ${family.leaderUserId ? `<@${family.leaderUserId}>` : "*não definido*"}`);
    const select = new discord_js_1.UserSelectMenuBuilder()
        .setCustomId(`adm-familyuser-select:${familyId}`)
        .setPlaceholder("Selecione o novo Dono da Família")
        .setMinValues(1)
        .setMaxValues(1);
    const selectRow = new discord_js_1.ActionRowBuilder().addComponents(select);
    await replyOrUpdate(interaction, { attachments: [], embeds: [embed], components: [selectRow, backRow(`adm-familias:detail:${familyId}`)] });
}
const component = {
    customId: "adm-familias:",
    async execute(interaction) {
        if (!interaction.guild)
            return;
        const member = await interaction.guild.members.fetch(interaction.user.id);
        if (!(await (0, permissions_1.isBotAdmin)(member))) {
            await interaction.reply({
                content: " Você não tem permissão para acessar esta seção.",
                ephemeral: true,
            });
            return;
        }
        const parts = interaction.customId.split(":"); // ["adm-familias", "acao", "sub?"]
        const action = parts[1];
        const sub = parts[2];
        switch (action) {
            case "menu":
                return renderFamiliasMenu(interaction);
            case "criar":
                return openCreateFamilyModal(interaction);
            case "draftskipreps": {
                const draft = (0, adminDrafts_1.getFamilyDraft)(interaction.guild.id, interaction.user.id);
                if (!draft) {
                    await interaction.reply({ content: "Cadastro expirado.", ephemeral: true });
                    return;
                }
                draft.representativeIds = [];
                await interaction.update(await (0, adminViews_1.familyDraftPreview)(interaction.guild, draft));
                return;
            }
            case "draftcancel":
                (0, adminDrafts_1.clearFamilyDraft)(interaction.guild.id, interaction.user.id);
                return renderFamiliasMenu(interaction);
            case "draftalter":
                (0, adminDrafts_1.clearFamilyDraft)(interaction.guild.id, interaction.user.id);
                return openCreateFamilyModal(interaction);
            case "draftconfirm": {
                const draft = (0, adminDrafts_1.getFamilyDraft)(interaction.guild.id, interaction.user.id);
                if (!draft?.roleId || !draft.ownerId) {
                    await interaction.reply({ content: "Cadastro incompleto ou expirado.", ephemeral: true });
                    return;
                }
                try {
                    const family = await (0, families_1.createFamilyComplete)(interaction.guild, interaction.user.id, { name: draft.name, memberRoleId: draft.roleId, leaderUserId: draft.ownerId, representativeIds: draft.representativeIds });
                    (0, adminDrafts_1.clearFamilyDraft)(interaction.guild.id, interaction.user.id);
                    return renderFamilyDetail(interaction, family.id);
                }
                catch (error) {
                    await interaction.reply({ content: error instanceof Error ? error.message : String(error), ephemeral: true });
                    return;
                }
            }
            case "listar":
                return renderFamiliesList(interaction);
            case "membrosglobais": return void await interaction.update(await (0, phaseOneViews_1.globalMembersView)(interaction.guild));
            case "ausencias": return void await interaction.update(await (0, phaseOneViews_1.absencesView)(interaction.guild));
            case "configuracoes": return void await interaction.update(await (0, phaseOneViews_1.familySettingsView)(interaction.guild));
            case "config": {
                const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor")).setTitle("CONFIGURAÇÕES — FAMÍLIAS").setDescription("As configurações operacionais existentes continuam preservadas dentro de cada família. Selecione uma família em **Ver Famílias** para configurar cargo, liderança, Call, Mov Chat e painel oficial.");
                await interaction.update({ attachments: [], embeds: [embed], components: [backRow("adm-familias:menu")] });
                return;
            }
            case "pick":
                return renderFamilyPicker(interaction, sub);
            case "detail":
                return renderFamilyDetail(interaction, sub);
            case "info":
                return renderFamilyInfo(interaction, sub);
            case "edit": return renderEditMenu(interaction, sub);
            case "members": return renderMembers(interaction, sub, Number(parts[3]) || 0);
            case "leadership": return renderLeadership(interaction, sub);
            case "owner": return renderLeaderUserPicker(interaction, sub);
            case "repadd": {
                const select = new discord_js_1.UserSelectMenuBuilder().setCustomId(`adm-family-admin:rep-add:${sub}`).setPlaceholder("Selecione um representante").setMinValues(1).setMaxValues(1);
                await interaction.update({ attachments: [], embeds: [(await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor")).setTitle("ADICIONAR REPRESENTANTE").setDescription("Selecione um usuário. O limite atual é de 3 representantes por família.")], components: [new discord_js_1.ActionRowBuilder().addComponents(select), backRow(`adm-familias:leadership:${sub}`)] });
                return;
            }
            case "repremove": {
                const reps = await (0, families_1.listFamilyRepresentatives)(sub);
                const select = new discord_js_1.StringSelectMenuBuilder().setCustomId(`adm-family-admin:rep-remove:${sub}`).setPlaceholder("Selecione quem será removido").setDisabled(!reps.length).addOptions((reps.length ? reps : [{ userId: "none" }]).map(r => ({ label: r.userId === "none" ? "Nenhum representante" : interaction.guild.members.cache.get(r.userId)?.displayName || r.userId, value: r.userId })));
                await interaction.update({ attachments: [], embeds: [(await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor")).setTitle("REMOVER REPRESENTANTE")], components: [new discord_js_1.ActionRowBuilder().addComponents(select), backRow(`adm-familias:leadership:${sub}`)] });
                return;
            }
            case "nome":
                return openEditNameModal(interaction, sub);
            case "toggle":
                return handleToggleActive(interaction, sub);
            case "toggleconfirm": return renderStatusConfirm(interaction, sub);
            case "excluirconfirm":
                return renderExcluirConfirm(interaction, sub);
            case "excluirok":
                return handleExcluirOk(interaction, sub);
            case "cargomembro":
                return renderRolePickerScreen(interaction, sub, "membro");
            case "cargolider":
                return renderRolePickerScreen(interaction, sub, "lider");
            case "canalvoz":
                return renderVoiceChannelPicker(interaction, sub);
            case "canaismonitor":
                return renderMonitorChannelsPicker(interaction, sub);
            // "cargomembro", "cargolider", "canalvoz", "canaismonitor" abrem
            // seletores tratados em outros arquivos (roleSelects.ts / familySelects.ts),
            // então aqui só precisamos renderizar a tela quando o customId bate
            // exatamente com o prefixo — o roteamento de fato acontece nos selects.
            default:
                return renderFamiliasMenu(interaction);
        }
    },
};
exports.default = component;
//# sourceMappingURL=admFamiliasMenu.js.map