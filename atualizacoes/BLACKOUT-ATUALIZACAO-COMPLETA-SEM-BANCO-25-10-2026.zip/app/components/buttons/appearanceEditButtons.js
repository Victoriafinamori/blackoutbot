"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const permissions_1 = require("../../utils/permissions");
const guildConfig_1 = require("../../database/guildConfig");
const component = { customId: "appearance-edit:", async execute(i) {
        if (!i.guild || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return;
        const action = i.customId.split(":")[1];
        const labels = { nickname: "Nome do bot neste servidor", avatar: "URL do avatar neste servidor", banner: "URL do banner neste servidor", color: "Cor hexadecimal das mensagens" };
        if (!labels[action])
            return void await i.reply({ content: "Use as opções atuais em Personalização do bot.", ephemeral: true });
        const me = await i.guild.members.fetchMe({ force: true });
        const value = action === "nickname" ? me.displayName : action === "avatar" ? me.avatarURL() : action === "banner" ? me.bannerURL() : (await (0, guildConfig_1.getOrCreateGuildConfig)(i.guild.id)).embedColor;
        const input = new discord_js_1.TextInputBuilder().setCustomId("value").setLabel(labels[action]).setStyle(discord_js_1.TextInputStyle.Short).setRequired(true).setMaxLength(action === "nickname" ? 32 : action === "color" ? 7 : 500);
        if (value)
            input.setValue(value);
        await i.showModal(new discord_js_1.ModalBuilder().setCustomId(`appearance-modal:${action}`).setTitle(action === "nickname" ? "Nome neste servidor" : action === "avatar" ? "Avatar neste servidor" : action === "banner" ? "Banner neste servidor" : "Cor das mensagens").addComponents(new discord_js_1.ActionRowBuilder().addComponents(input)));
    } };
exports.default = component;
