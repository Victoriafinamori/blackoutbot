"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderRegistrationMenu = renderRegistrationMenu;
const discord_js_1 = require("discord.js");
const adminUi_1 = require("../../utils/adminUi");
const permissions_1 = require("../../utils/permissions");
const registration_1 = require("../../utils/registration");
const registrationUi_1 = require("../../utils/registrationUi");
const prisma_1 = require("../../database/prisma");
const admEmojis_1 = require("../../utils/admEmojis");
const registrationPageAdmin_1 = require("../../utils/registrationPageAdmin");
const button = (id, label, style = discord_js_1.ButtonStyle.Secondary) => new discord_js_1.ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style);
async function renderRegistrationMenu(i) { return require('../../utils/registrationAdmin').renderRegistrationAdmin(i); }

const component = { customId: "adm-reg:", async execute(i) { if (!i.guild || !(await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id))))
        return; const parts = i.customId.split(":"), a = parts[1], c = await (0, registration_1.regConfig)(i.guild.id);
if (['general','auto','embed','welcome','tools'].includes(a)) return require('../../utils/registrationAdmin').renderRegistrationAdmin(i,a);
 if (a === "menu")
        return renderRegistrationMenu(i); if (a === "general") {
        const log = new discord_js_1.ChannelSelectMenuBuilder().setCustomId("registration-channel:logChannelId").setPlaceholder("Canal de logs").addChannelTypes(discord_js_1.ChannelType.GuildText), registrars = new discord_js_1.RoleSelectMenuBuilder().setCustomId("registration-role:registrarRoleIds").setPlaceholder("Cargos permitidos para registrar").setMinValues(0).setMaxValues(10), leaders = new discord_js_1.RoleSelectMenuBuilder().setCustomId("registration-role:leaderRoleIds").setPlaceholder("Cargos Líderes").setMinValues(0).setMaxValues(10);
        await i.update({ attachments: [], embeds: [(await (0, adminUi_1.adminEmbed)(i.guild, "membros")).setTitle("Configurações Gerais").setDescription(`**Status do Sistema:** ${c.enabled ? "Ativado" : "Desativado"}\n**Canal de Logs:** ${c.logChannelId ? `<#${c.logChannelId}>` : "Não configurado"}\n**Cargos Líderes:** ${c.leaderRoleIds ? c.leaderRoleIds.split(",").map(id => `<@&${id}>`).join(", ") : "Nenhum"}\n**Cargos Registradores:** ${c.registrarRoleIds ? c.registrarRoleIds.split(",").map(id => `<@&${id}>`).join(", ") : "Nenhum"}\n**Envio para outro servidor:** ${c.externalEnabled ? "Ativado" : "Desativado"}\n**Servidor de destino:** ${c.externalGuildId || "Não configurado"}\n**Canal externo:** ${c.externalChannelId ? `<#${c.externalChannelId}>` : "Não configurado"}`)], components: [new discord_js_1.ActionRowBuilder().addComponents(button("adm-reg:toggle", c.enabled ? "Desativar Sistema" : "Ativar Sistema", c.enabled ? discord_js_1.ButtonStyle.Danger : discord_js_1.ButtonStyle.Success), button("adm-reg:external", c.externalEnabled ? "Desativar envio externo" : "Enviar para outro servidor", c.externalEnabled ? discord_js_1.ButtonStyle.Danger : discord_js_1.ButtonStyle.Success), button("adm-reg:externalconfig", "Configurar destino externo", discord_js_1.ButtonStyle.Primary)), new discord_js_1.ActionRowBuilder().addComponents(log), new discord_js_1.ActionRowBuilder().addComponents(registrars), new discord_js_1.ActionRowBuilder().addComponents(leaders), new discord_js_1.ActionRowBuilder().addComponents(button("adm-reg:menu", "Voltar"))] });
        return;
    } if (a === "toggle" || a === "external") {
        await prisma_1.prisma.registrationConfig.update({ where: { guildId: i.guild.id }, data: a === "toggle" ? { enabled: !c.enabled } : { externalEnabled: !c.externalEnabled } });
        return renderRegistrationMenu(i);
    } if (a === "externalconfig") {
        const m = new discord_js_1.ModalBuilder().setCustomId("registration-external:save").setTitle("Destino externo").addComponents(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("guild").setLabel("ID do servidor de destino").setStyle(discord_js_1.TextInputStyle.Short).setValue(c.externalGuildId || "").setRequired(true)), new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("channel").setLabel("ID do canal de registros").setStyle(discord_js_1.TextInputStyle.Short).setValue(c.externalChannelId || "").setRequired(true)));
        await i.showModal(m);
        return;
    } if (a === "pages") {
        await i.update(await (0, registrationPageAdmin_1.registrationPagesPayload)(i.guild));
        return;
    } if (a === "createpage") {
        if (await prisma_1.prisma.registrationPage.count({ where: { guildId: i.guild.id } }) >= 5)
            return void await i.reply({ content: "Limite de cinco páginas atingido.", ephemeral: true });
        const m = new discord_js_1.ModalBuilder().setCustomId("registration-page:create").setTitle("Nova Página").addComponents(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("name").setLabel("Nome da página").setStyle(discord_js_1.TextInputStyle.Short).setPlaceholder("Gênero").setRequired(true)), new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("question").setLabel("Pergunta").setStyle(discord_js_1.TextInputStyle.Short).setPlaceholder("Qual seu gênero?").setRequired(true)), new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("description").setLabel("Descrição opcional").setStyle(discord_js_1.TextInputStyle.Paragraph).setRequired(false)), new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("max").setLabel("Máximo de cargos escolhidos").setStyle(discord_js_1.TextInputStyle.Short).setValue("1").setRequired(true)));
        await i.showModal(m);
        return;
    } if (a === "pagedelete") {
        const pageId = parts[2];
        if (!pageId)
            return;
        await i.update({ attachments: [], embeds: [(await (0, adminUi_1.adminEmbed)(i.guild, "membros")).setTitle("Excluir Página").setDescription("Tem certeza que deseja excluir esta página específica? Os cargos das outras páginas serão mantidos.")], components: [new discord_js_1.ActionRowBuilder().addComponents(button(`adm-reg:pagedeleteconfirm:${pageId}`, "Confirmar Exclusão", discord_js_1.ButtonStyle.Danger), button(`adm-reg:pagemanage:${pageId}`, "Cancelar", discord_js_1.ButtonStyle.Secondary))] });
        return;
    } if (a === "pagedeleteconfirm") {
        const pageId = parts[2];
        if (pageId)
            await (0, registrationPageAdmin_1.deleteRegistrationPage)(i.guild.id, pageId);
        await i.update(await (0, registrationPageAdmin_1.registrationPagesPayload)(i.guild));
        return;
    } if (a === "pagemanage") {
        const pageId = parts[2];
        if (pageId)
            await i.update(await (0, registrationPageAdmin_1.registrationPageManagerPayload)(i.guild, pageId));
        return;
    } if (a === "auto") {
        const no = new discord_js_1.RoleSelectMenuBuilder().setCustomId("registration-role:unregisteredRoleIds").setPlaceholder("Não Registrado — cargos removidos").setMinValues(0).setMaxValues(10), yes = new discord_js_1.RoleSelectMenuBuilder().setCustomId("registration-role:registeredRoleIds").setPlaceholder("Registrado — cargos adicionados").setMinValues(0).setMaxValues(10);
        await i.update({ attachments: [], embeds: [(await (0, adminUi_1.adminEmbed)(i.guild, "membros")).setTitle("Finalização do Registro").setDescription("Esta é a última configuração: escolha os cargos removidos e adicionados ao concluir.")], components: [new discord_js_1.ActionRowBuilder().addComponents(no), new discord_js_1.ActionRowBuilder().addComponents(yes), new discord_js_1.ActionRowBuilder().addComponents(button("adm-reg:menu", "Voltar"))] });
        return;
    } if (a === "embed") {
        await i.update({ attachments: [], embeds: [(await (0, adminUi_1.adminEmbed)(i.guild, "membros")).setTitle("EMBED").setDescription("Personalize o painel público e a interface interna do registro, no mesmo padrão do sistema de Tickets.")], components: [new discord_js_1.ActionRowBuilder().addComponents(button("adm-reg-embed:panel", "Visual do Painel", discord_js_1.ButtonStyle.Primary), button("adm-reg-embed:internal", "EMBED INTERNA", discord_js_1.ButtonStyle.Primary), button("adm-reg-embed:publish", "Enviar / Atualizar Painel", discord_js_1.ButtonStyle.Success), button("adm-reg:menu", "Voltar"))] });
        return;
    } if (a === "commands")
        return void await i.reply({ content: "`/registrar @membro` e `/r @membro` iniciam a seleção visual. Use dentro do canal privado do registro.", ephemeral: true }); if (a === "stats") {
        const top = await prisma_1.prisma.registrarStat.findMany({ where: { guildId: i.guild.id }, orderBy: { cycle: "desc" }, take: 10 });
        return void await i.reply({ content: top.map((x, n) => `${n + 1}. <@${x.userId}> — ${x.cycle}`).join("\n") || "Sem registros.", ephemeral: true });
    } if (a === "test") {
        if (!(await prisma_1.prisma.registrationPage.count({ where: { guildId: i.guild.id } })))
            return void await i.reply({ content: "Crie ao menos uma página.", ephemeral: true });
        registration_1.sessions.set(i.user.id, { guildId: i.guild.id, memberId: i.user.id, registrarId: i.user.id, method: "Teste", page: 0, answers: {}, test: true });
        await i.update((await (0, registrationUi_1.prettyRegistrationView)(i.guild, i.user.id)));
    } } };
exports.default = component;
//# sourceMappingURL=admRegistrationMenu.js.map