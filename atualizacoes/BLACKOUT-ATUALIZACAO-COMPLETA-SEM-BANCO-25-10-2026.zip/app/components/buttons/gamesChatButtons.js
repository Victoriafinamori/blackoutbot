"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.termoButtons = void 0;
const discord_js_1 = require("discord.js");
const manager_1 = require("../../games-chat/mystery-box/manager");
const ui_1 = require("../../games-chat/termo/ui");
const config_1 = require("../../games-chat/core/config");
const mysteryButtons = {
    customId: "mystery-open:",
    async execute(i) {
        if (!i.guild)
            return;
        await i.deferReply({ ephemeral: true });
        const [, eventId, number] = i.customId.split(":");
        try {
            const result = await (0, manager_1.openMysteryBox)(i.guild, eventId, Number(number), i.user.id), config = await (0, config_1.mysteryConfig)(i.guild.id);
            const announcements = (await require("../../games-chat/experience/hub").config(i.guild.id)).mysteryIndividualAnnouncements;
            if (announcements) {
                try {
                    const replace = (value) => value
                        .split("{membro}")
                        .join("<@" + i.user.id + ">")
                        .split("{premio}")
                        .join(result.reward.name)
                        .split("{caixa}")
                        .join(number);
                    const winner = new discord_js_1.EmbedBuilder()
                        .setColor(parseInt(config.winnerColor, 16) || 0xd71935)
                        .setTitle(replace(config.winnerTitle).slice(0, 256))
                        .setDescription(replace(config.winnerDescription).slice(0, 4096));
                    if (config.winnerImage)
                        winner.setImage(replace(config.winnerImage));
                    if (config.winnerFooter)
                        winner.setFooter({
                            text: replace(config.winnerFooter).slice(0, 2048),
                        });
                    const event = await require("../../games-chat/mystery-box/manager").getMysteryEvent(eventId), channel = event?.guildId === i.guild.id
                        ? await i.guild.channels
                            .fetch(event.channelId)
                            .catch(() => null)
                        : null;
                    if (channel?.isTextBased() && !channel.isDMBased())
                        await channel.send({
                            content: "<@" + i.user.id + ">",
                            embeds: [winner],
                            allowedMentions: { users: [i.user.id] },
                        });
                }
                catch (error) {
                    console.warn("[mystery-announcement]", error instanceof Error ? error.message : "Falha no anúncio");
                }
            }
            const note = result.delivery.status === "PENDING_EXTERNAL"
                ? " A entrega aguarda a integração ou a equipe."
                : result.delivery.status === "FAILED"
                    ? " A entrega falhou; a equipe pode consultar o registro."
                    : "";
            await i.editReply({
                content: "Caixa " +
                    number +
                    " aberta. Resultado: **" +
                    result.reward.name.slice(0, 100) +
                    "**." +
                    note,
                components: [
                    require("../../games-chat/experience/common").row(require("../../games-chat/experience/common").button("mystery-panel:mine:" + eventId, "Meu resultado")),
                ],
                allowedMentions: { parse: [] },
            });
        }
        catch (error) {
            await i.editReply({
                content: "Não foi possível concluir a abertura nesta tela: " +
                    (error instanceof Error ? error.message : String(error)) +
                    ". Consulte seu resultado antes de tentar outra caixa.",
                components: [
                    require("../../games-chat/experience/common").row(require("../../games-chat/experience/common").button("mystery-panel:mine:" + eventId, "Meu resultado")),
                ],
                allowedMentions: { parse: [] },
            });
        }
    },
};
exports.default = mysteryButtons;
exports.termoButtons = {
    customId: "termo-game:",
    async execute(i) {
        if (!i.guild)
            return;
        const guild = i.guild;
        return require("../../games-chat/experience/common").guard(i, async () => {
            await require("../../games-chat/experience/common").member(guild, i.user.id);
            const action = i.customId.split(":")[1];
            if (action === "guess") {
                const game = await require("../../games-chat/termo/manager").getOrCreateGame(guild.id, i.user.id);
                if (game.status !== "PLAYING")
                    throw Error("Sua partida terminou. Consulte seu resultado.");
                return i.showModal(new discord_js_1.ModalBuilder()
                    .setCustomId("termo-guess:" + game.roundId)
                    .setTitle("TERMO · Nova tentativa")
                    .addComponents(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder()
                    .setCustomId("word")
                    .setLabel("Palavra de " +
                    (game.round.wordLengthSnapshot ??
                        game.round.word.length) +
                    " letras")
                    .setStyle(discord_js_1.TextInputStyle.Short)
                    .setMinLength(1)
                    .setMaxLength(30)
                    .setRequired(true))));
            }
            if (action === "share") {
                await i.deferReply({ ephemeral: true });
                const message = await require("../../games-chat/termo/manager").shareResult(guild, i.user.id);
                return i.editReply({
                    content: "Resultado compartilhado sem a palavra-resposta. " + message.url,
                });
            }
            if (action === "help")
                return i.reply({
                    content: "Descubra a palavra diária. Verde: letra e posição corretas; amarelo: letra em outra posição; cinza: letra ausente ou repetida além da quantidade correta. Acentos são aceitos. Uma palavra inválida não consome tentativa. Seu tabuleiro fica salvo e só você o vê.",
                    ephemeral: true,
                });
            const render = () => action === "ranking"
                ? (0, ui_1.termoRankingView)(guild)
                : (0, ui_1.termoPlayerView)(guild, i.user.id);
            if (i.message.flags.has(64)) {
                await i.deferUpdate();
                return i.editReply(await render());
            }
            await i.deferReply({ ephemeral: true });
            return i.editReply(await render());
        });
    },
};
