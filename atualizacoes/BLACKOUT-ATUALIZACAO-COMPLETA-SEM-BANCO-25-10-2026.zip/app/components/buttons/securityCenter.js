"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const interactions_1 = require("../../security/interactions");
const component = { customId: "security:", execute: interactions_1.execute };
exports.default = component;
