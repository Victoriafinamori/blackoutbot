"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const cardAccess_1 = require("../../bingo/cardAccess");
exports.default = { customId: "bingo-card-view:", execute: cardAccess_1.execute };
