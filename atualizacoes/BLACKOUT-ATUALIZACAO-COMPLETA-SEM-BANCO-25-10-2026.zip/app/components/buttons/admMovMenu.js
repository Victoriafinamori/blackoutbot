"use strict";
const { prepareAdminPanel } = require("../../utils/adminTasks");
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderMovMenu = renderMovMenu;
exports.renderMovSettings = renderMovSettings;
exports.renderMovUsers = renderMovUsers;
exports.renderMovLevels = renderMovLevels;
const discord_js_1 = require("discord.js");
const permissions_1 = require("../../utils/permissions");
const adminUi_1 = require("../../utils/adminUi");
const adminLog_1 = require("../../utils/adminLog");
const enums_1 = require("../../structures/enums");
const movStats_1 = require("../../utils/movStats");
function backRow(customId, label = "Voltar") {
    return new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId(customId).setLabel(label).setStyle(discord_js_1.ButtonStyle.Secondary));
}
// Estas telas são chamadas tanto por botões quanto por selects de canal e,
// no caso do intervalo de reset, pelo submit do modal — por isso o tipo
// "any" aqui, igual ao padrão já usado em renderStageChatPanel.
//
// Este menu cuida só do MOV CHAT (mensagens). O tempo em call agora é o
// sistema Mov.Call, separado — ver /adm > Mov.Call e admMovCallMenu.ts.
async function renderMovMenu(interaction) {
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor")).setTitle("Atividade no chat").setDescription("Selecione abaixo qual área do sistema de mensagens deseja gerenciar.");
    const select = new discord_js_1.StringSelectMenuBuilder().setCustomId("adm-mov-nav").setPlaceholder("Selecione uma opção").addOptions({ label: "Página Inicial", value: "home", description: "Voltar ao painel inicial" }, { label: "Painel Usuário", value: "users", description: "Ranking e gerenciamento de usuários" }, { label: "Configurações", value: "settings", description: "Canais, mensagens e reset" }, { label: "Levels", value: "levels", description: "Mensagem automática de level" });
    await interaction.update(prepareAdminPanel(interaction.guild, 'movchat', { attachments: [], embeds: [embed], components: [new discord_js_1.ActionRowBuilder().addComponents(select)] }));
}
async function renderMovSettings(interaction) {
    const config = await (0, movStats_1.getGuildConfigForMov)(interaction.guild.id);
    const chatChannels = (0, movStats_1.getMovChatChannelIds)(config);
    const nextReset = (0, movStats_1.computeNextResetAt)(config);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor"))
        .setTitle("Ranking de mensagens")
        .setDescription("ℹ️ **Informações**\n" +
        `Rank Status: ${config.movChatEnabled ? "Ativado" : "Desativado"}\n` +
        `Canais de Contagem: **${chatChannels.length} configurado(s)**\n` +
        `Canal de Logs: ${config.movChatLogChannelId ? `<#${config.movChatLogChannelId}>` : "Não configurado"}\n` +
        `Mensagens por Level: **${config.movChatMessagesPerLevel} mensagens/level**\n` +
        `**Reset automático:** ${config.movResetIntervalDays
            ? `a cada ${config.movResetIntervalDays} dia(s) — próximo em <t:${Math.floor(nextReset.getTime() / 1000)}:R>`
            : "desativado (apenas manual)"}\n\nℹ️ **Observações**\nO botão **Configurar Mensagens** define a quantidade necessária para subir de nível.`);
    const row1 = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-mov:chatchannels").setLabel("Configurar Canais").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId("adm-mov:messages").setLabel("Configurar Mensagens").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId("adm-mov:interval").setLabel("Configurar Reset").setStyle(discord_js_1.ButtonStyle.Secondary));
    const row2 = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-mov:ranking:CHAT").setLabel("Enviar Rank").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId("adm-mov:requestreset").setLabel("Resetar Ranking Geral").setStyle(discord_js_1.ButtonStyle.Danger));
    await interaction.update({ attachments: [], embeds: [embed], components: [backRow("adm-mov:menu"), row1, row2] });
}
async function renderMovUsers(interaction) { const c = await (0, movStats_1.getGuildConfigForMov)(interaction.guild.id), rows = await (0, movStats_1.getRanking)(interaction.guild.id, enums_1.MovStatType.CHAT, 10); const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor")).setTitle("Ranking de mensagens").setDescription(`ℹ️ **Informações**\nCanal de Logs: ${c.movChatLogChannelId ? `<#${c.movChatLogChannelId}>` : "Não configurado"}\nUsuários Bloqueados: **Nenhum**\n\nℹ️ **Observações**\nConsulte os usuários e níveis atuais pelo ranking abaixo.\n\n${rows.map((x, n) => `${n + 1}. <@${x.userId}> — Level ${Math.floor(x.value / Math.max(1, c.movChatMessagesPerLevel))} — ${x.value} mensagens`).join("\n") || "Nenhum usuário pontuou."}`); await interaction.update({ attachments: [], embeds: [embed], components: [new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-mov:ranking:CHAT").setLabel("Listar Ranking").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId("adm-mov:logchannel").setLabel("Canal de Logs").setStyle(discord_js_1.ButtonStyle.Secondary)), backRow("adm-mov:menu")] }); }
async function renderMovLevels(interaction) { const c = await (0, movStats_1.getGuildConfigForMov)(interaction.guild.id), embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor")).setTitle("AUDAZ — Área de Ranking").setDescription(`Olá, <@${interaction.user.id}>\nBem-vindo(a) ao sistema de Ranking.\n\n{member} — Marca o usuário\n{username} — Exibe o nome do usuário\n{level} — Exibe o level conquistado\n\n**Informações**\nStatus: ${c.movChatLevelChannelId ? "Ativado" : "Desativado"}\nCanal: ${c.movChatLevelChannelId ? `<#${c.movChatLevelChannelId}>` : "Não configurado"}\nTempo de exclusão: **${c.movChatLevelDeleteSeconds} segundos**\nMensagem:\n\`\`\`${c.movChatLevelMessage}\`\`\``); const row = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-mov:levelchannel").setLabel("Setar Canal").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId("adm-mov:levelmessage").setLabel("Setar Mensagem").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId("adm-mov:leveltime").setLabel("Setar Tempo").setStyle(discord_js_1.ButtonStyle.Secondary)); await interaction.update({ attachments: [], embeds: [embed], components: [backRow("adm-mov:menu"), row] }); }
async function renderChatChannelsPicker(interaction) {
    const config = await (0, movStats_1.getGuildConfigForMov)(interaction.guild.id);
    const current = (0, movStats_1.getMovChatChannelIds)(config);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor"))
        .setTitle("💬 MOV CHAT — Canais Contados")
        .setDescription(`Selecione até ${movStats_1.MAX_MOV_CHAT_CHANNELS} canais de texto que contam mensagens no ranking.`);
    const select = new discord_js_1.ChannelSelectMenuBuilder()
        .setCustomId("adm-movchatchannel-select")
        .setPlaceholder(`Selecione até ${movStats_1.MAX_MOV_CHAT_CHANNELS} canais`)
        .addChannelTypes(discord_js_1.ChannelType.GuildText)
        .setMinValues(0)
        .setMaxValues(movStats_1.MAX_MOV_CHAT_CHANNELS);
    if (current.length)
        select.setDefaultChannels(current);
    const selectRow = new discord_js_1.ActionRowBuilder().addComponents(select);
    await interaction.update({ attachments: [], embeds: [embed], components: [selectRow, backRow("adm-mov:menu")] });
}
async function openResetIntervalModal(interaction) {
    const config = await (0, movStats_1.getGuildConfigForMov)(interaction.guild.id);
    const modal = new discord_js_1.ModalBuilder().setCustomId("adm-modal:movinterval").setTitle("Intervalo de Reset do Ranking");
    const daysInput = new discord_js_1.TextInputBuilder()
        .setCustomId("days")
        .setLabel("Reseta a cada quantos dias?")
        .setPlaceholder("Vazio = só reseto manualmente")
        .setStyle(discord_js_1.TextInputStyle.Short)
        .setValue(config.movResetIntervalDays ? String(config.movResetIntervalDays) : "")
        .setRequired(false)
        .setMaxLength(4);
    modal.addComponents(new discord_js_1.ActionRowBuilder().addComponents(daysInput));
    await interaction.showModal(modal);
}
async function handleResetNow(interaction) {
    await (0, movStats_1.resetMovStats)(interaction.guild.id);
    await (0, adminLog_1.logAdminAction)({
        guild: interaction.guild,
        actorId: interaction.user.id,
        action: enums_1.AdminLogAction.MOV_RESET,
        details: "Reset manual do ranking de atividade (MOV CHAT).",
    });
    await renderMovMenu(interaction);
}
async function renderResetConfirmation(interaction) {
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor")).setColor(0xd71935).setTitle("Confirmar reset — MOV CHAT").setDescription("Esta ação zera o ranking atual de mensagens e inicia uma nova contagem a partir deste momento.\n\nCanais configurados e histórico diário da Limpa serão preservados.");
    const row = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-mov:confirmreset").setLabel("Confirmar reset").setStyle(discord_js_1.ButtonStyle.Danger), new discord_js_1.ButtonBuilder().setCustomId("adm-mov:menu").setLabel("Cancelar").setStyle(discord_js_1.ButtonStyle.Secondary));
    await interaction.update({ attachments: [], embeds: [embed], components: [row] });
}
async function renderRanking(interaction, type) {
    const rows = await (0, movStats_1.getRanking)(interaction.guild.id, type, 10);
    const lines = rows.length
        ? rows
            .map((r, i) => `**${i + 1}.** <@${r.userId}> — ${r.value} mensagem(ns)`)
            .join("\n")
        : "*Ninguém pontuou ainda.*";
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor")).setTitle("📈 Ranking — MOV CHAT").setDescription(lines);
    await interaction.update({ attachments: [], embeds: [embed], components: [backRow("adm-mov:menu")] });
}
const component = {
    customId: "adm-mov:",
    async execute(interaction) {
        if (!interaction.guild)
            return;
        const member = await interaction.guild.members.fetch(interaction.user.id);
        if (!(await (0, permissions_1.isBotAdmin)(member))) {
            await interaction.reply({ content: "🚫 Você não tem permissão para acessar esta seção.", ephemeral: true });
            return;
        }
        const parts = interaction.customId.split(":"); // ["adm-mov", "acao", "sub?"]
        const action = parts[1];
        const sub = parts[2];
        switch (action) {
            case "menu":
                return renderMovMenu(interaction);
            case "chatchannels":
                return renderChatChannelsPicker(interaction);
            case "interval":
                return openResetIntervalModal(interaction);
            case "requestreset":
                return renderResetConfirmation(interaction);
            case "confirmreset":
                return handleResetNow(interaction);
            case "ranking":
                return renderRanking(interaction, sub);
            case "settings": return renderMovSettings(interaction);
            case "users": return renderMovUsers(interaction);
            case "levels": return renderMovLevels(interaction);
            case "messages": return openSimpleModal(interaction, "movmessages", "Mensagens por Level", "messages", "Quantidade de mensagens", 1000);
            case "levelmessage": return openSimpleModal(interaction, "movlevelmessage", "Mensagem de Level", "value", "Use {member}, {username} e {level}", null, true);
            case "leveltime": return openSimpleModal(interaction, "movleveltime", "Tempo de Exclusão", "value", "Segundos (0 não exclui)", 60);
            case "logchannel": return renderSingleChannel(interaction, "log");
            case "levelchannel": return renderSingleChannel(interaction, "level");
            default:
                return renderMovMenu(interaction);
        }
    },
};
async function openSimpleModal(i, id, title, key, label, value, paragraph = false) { const modal = new discord_js_1.ModalBuilder().setCustomId(`adm-modal:${id}`).setTitle(title).addComponents(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId(key).setLabel(label).setStyle(paragraph ? discord_js_1.TextInputStyle.Paragraph : discord_js_1.TextInputStyle.Short).setRequired(true).setValue(value === null ? "" : String(value)))); await i.showModal(modal); }
async function renderSingleChannel(i, kind) { const select = new discord_js_1.ChannelSelectMenuBuilder().setCustomId(`adm-mov-single-channel:${kind}`).setPlaceholder("Selecione o canal").addChannelTypes(discord_js_1.ChannelType.GuildText).setMinValues(0).setMaxValues(1); await i.update({ attachments: [], embeds: [], components: [new discord_js_1.ActionRowBuilder().addComponents(select), backRow(kind === "level" ? "adm-mov:levels" : "adm-mov:users")] }); }
exports.default = component;
//# sourceMappingURL=admMovMenu.js.map