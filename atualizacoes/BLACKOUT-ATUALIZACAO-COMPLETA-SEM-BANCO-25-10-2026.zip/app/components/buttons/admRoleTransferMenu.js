"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderRoleTransferMenu = renderRoleTransferMenu;
const discord_js_1 = require("discord.js");
const permissions_1 = require("../../utils/permissions");
const embeds_1 = require("../../utils/embeds");
const enums_1 = require("../../structures/enums");
const roleTransfer_1 = require("../../utils/roleTransfer");
const movStats_1 = require("../../utils/movStats");
function backRow(customId, label = "Voltar") {
    return new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId(customId).setLabel(label).setStyle(discord_js_1.ButtonStyle.Secondary));
}
// Chamado por botões, selects de cargo e pelo submit dos modais — mesmo
// padrão "any" já usado em renderMovMenu/renderStageChatPanel.
async function renderRoleTransferMenu(interaction) {
    const config = await (0, roleTransfer_1.getRoleTransferConfig)(interaction.guild.id);
    const ready = (0, roleTransfer_1.isRoleTransferReady)(config);
    const requisitos = [];
    if (config.minCallSeconds)
        requisitos.push(`⏱️ Mínimo em call: **${(0, movStats_1.formatDuration)(config.minCallSeconds)}**`);
    if (config.minChatMessages)
        requisitos.push(`💬 Mínimo de mensagens: **${config.minChatMessages}**`);
    if (!requisitos.length)
        requisitos.push("*Nenhum requisito configurado — todos com o cargo de origem seriam movidos.*");
    const embed = (await (0, embeds_1.baseEmbed)(interaction.guild))
        .setTitle("🔁 Transferência Automática de Cargo")
        .setDescription("Move membros de um cargo para outro (ex: `Perdido` → `Membro`) assim que cumprem os requisitos.\n\n" +
        `**Cargo de origem:** ${config.sourceRoleId ? `<@&${config.sourceRoleId}>` : "*não definido*"}\n` +
        `**Cargo de destino:** ${config.targetRoleId ? `<@&${config.targetRoleId}>` : "*não definido*"}\n\n` +
        `**Requisitos:**\n${requisitos.join("\n")}\n\n` +
        `**Modo:** ${config.mode === enums_1.TransferMode.AUTOMATIC ? "🤖 Automático" : "🖐️ Manual"}\n` +
        (config.mode === enums_1.TransferMode.AUTOMATIC
            ? `**Agendamento:** toda(o) ${(0, roleTransfer_1.weekdayLabel)(config.weekday)}, às ${String(config.hour).padStart(2, "0")}:${String(config.minute).padStart(2, "0")}\n`
            : "") +
        `**Última execução:** ${config.lastRunAt ? `<t:${Math.floor(new Date(config.lastRunAt).getTime() / 1000)}:R>` : "*nunca*"}\n\n` +
        (ready ? "" : "⚠️ *Defina o cargo de origem e o cargo de destino para poder rodar a transferência.*"));
    const row1 = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-roletransfer:sourcerole").setLabel("Cargo de Origem").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId("adm-roletransfer:targetrole").setLabel("Cargo de Destino").setStyle(discord_js_1.ButtonStyle.Secondary));
    const row2 = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-roletransfer:requisitos").setLabel("Requisitos").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId("adm-roletransfer:togglemode").setLabel(config.mode === enums_1.TransferMode.AUTOMATIC ? "Modo: Automático" : "Modo: Manual").setStyle(discord_js_1.ButtonStyle.Secondary));
    const row3Components = [];
    if (config.mode === enums_1.TransferMode.AUTOMATIC) {
        row3Components.push(new discord_js_1.ButtonBuilder().setCustomId("adm-roletransfer:schedule").setLabel("Agendamento").setStyle(discord_js_1.ButtonStyle.Secondary));
    }
    row3Components.push(new discord_js_1.ButtonBuilder()
        .setCustomId("adm-roletransfer:runnow")
        .setLabel("Rodar Agora")
        .setStyle(discord_js_1.ButtonStyle.Success)
        .setDisabled(!ready));
    const row3 = new discord_js_1.ActionRowBuilder().addComponents(...row3Components);
    const payload = { embeds: [embed], components: [row1, row2, row3, backRow("adm-cfg:autocargo")] };
    if (interaction.deferred || interaction.replied) {
        await interaction.editReply(payload);
    }
    else {
        await interaction.update(payload);
    }
}
async function openRolePicker(interaction, kind) {
    const config = await (0, roleTransfer_1.getRoleTransferConfig)(interaction.guild.id);
    const currentId = kind === "sourcerole" ? config.sourceRoleId : config.targetRoleId;
    const label = kind === "sourcerole" ? "cargo de ORIGEM (ex: Perdido)" : "cargo de DESTINO (ex: AUDAZ)";
    const embed = (await (0, embeds_1.baseEmbed)(interaction.guild))
        .setTitle("🔁 Transferência Automática de Cargo")
        .setDescription(`Selecione o ${label}.`);
    const select = new discord_js_1.RoleSelectMenuBuilder()
        .setCustomId(`adm-role-select:${kind}`)
        .setPlaceholder(`Selecione o ${label}`)
        .setMinValues(0)
        .setMaxValues(1);
    if (currentId)
        select.setDefaultRoles([currentId]);
    const selectRow = new discord_js_1.ActionRowBuilder().addComponents(select);
    await interaction.update({ embeds: [embed], components: [selectRow, backRow("adm-roletransfer:menu")] });
}
async function openRequisitosModal(interaction) {
    const config = await (0, roleTransfer_1.getRoleTransferConfig)(interaction.guild.id);
    const modal = new discord_js_1.ModalBuilder().setCustomId("adm-modal:roletransferreqs").setTitle("Requisitos para Transferência");
    const callHoursInput = new discord_js_1.TextInputBuilder()
        .setCustomId("minCallHours")
        .setLabel("Mínimo de horas em call")
        .setPlaceholder("Vazio = sem requisito de call")
        .setStyle(discord_js_1.TextInputStyle.Short)
        .setValue(config.minCallSeconds ? String(config.minCallSeconds / 3600) : "")
        .setRequired(false)
        .setMaxLength(6);
    const chatMessagesInput = new discord_js_1.TextInputBuilder()
        .setCustomId("minChatMessages")
        .setLabel("Mínimo de mensagens (MOV CHAT)")
        .setPlaceholder("Vazio = sem requisito de mensagens")
        .setStyle(discord_js_1.TextInputStyle.Short)
        .setValue(config.minChatMessages ? String(config.minChatMessages) : "")
        .setRequired(false)
        .setMaxLength(6);
    modal.addComponents(new discord_js_1.ActionRowBuilder().addComponents(callHoursInput), new discord_js_1.ActionRowBuilder().addComponents(chatMessagesInput));
    await interaction.showModal(modal);
}
async function openScheduleModal(interaction) {
    const config = await (0, roleTransfer_1.getRoleTransferConfig)(interaction.guild.id);
    const modal = new discord_js_1.ModalBuilder().setCustomId("adm-modal:roletransferschedule").setTitle("Agendamento Semanal");
    const weekdayInput = new discord_js_1.TextInputBuilder()
        .setCustomId("weekday")
        .setLabel("Dia da semana (0=Dom, 1=Seg ... 6=Sáb)")
        .setPlaceholder("Ex: 6 para sábado")
        .setStyle(discord_js_1.TextInputStyle.Short)
        .setValue(String(config.weekday))
        .setRequired(true)
        .setMaxLength(1);
    const hourInput = new discord_js_1.TextInputBuilder()
        .setCustomId("hour")
        .setLabel("Horário — hora (0-23)")
        .setPlaceholder("Ex: 12")
        .setStyle(discord_js_1.TextInputStyle.Short)
        .setValue(String(config.hour))
        .setRequired(true)
        .setMaxLength(2);
    const minuteInput = new discord_js_1.TextInputBuilder()
        .setCustomId("minute")
        .setLabel("Horário — minuto (0-59)")
        .setPlaceholder("Ex: 0")
        .setStyle(discord_js_1.TextInputStyle.Short)
        .setValue(String(config.minute))
        .setRequired(true)
        .setMaxLength(2);
    modal.addComponents(new discord_js_1.ActionRowBuilder().addComponents(weekdayInput), new discord_js_1.ActionRowBuilder().addComponents(hourInput), new discord_js_1.ActionRowBuilder().addComponents(minuteInput));
    await interaction.showModal(modal);
}
async function handleToggleMode(interaction) {
    const config = await (0, roleTransfer_1.getRoleTransferConfig)(interaction.guild.id);
    const nextMode = config.mode === enums_1.TransferMode.AUTOMATIC ? enums_1.TransferMode.MANUAL : enums_1.TransferMode.AUTOMATIC;
    await (0, roleTransfer_1.updateRoleTransferConfig)(interaction.guild, interaction.user.id, { mode: nextMode }, `Modo alterado para ${nextMode === enums_1.TransferMode.AUTOMATIC ? "Automático" : "Manual"}.`);
    await renderRoleTransferMenu(interaction);
}
async function handleRunNow(interaction) {
    // A verificação de todos os membros pode levar mais de 3s em servidores
    // grandes, então confirmamos a interação (sem alterar a mensagem ainda)
    // antes de rodar, e só depois atualizamos o painel via editReply.
    await interaction.deferUpdate();
    const result = await (0, roleTransfer_1.runRoleTransfer)(interaction.guild, interaction.user.id);
    await renderRoleTransferMenu(interaction);
    if (!result.ok) {
        await interaction.followUp({ content: `❌ ${result.error}`, ephemeral: true });
        return;
    }
    await interaction.followUp({
        content: `✅ Verificação concluída: **${result.checked}** membro(s) verificado(s), ` +
            `**${result.transferredUserIds.length}** transferido(s).`,
        ephemeral: true,
    });
}
const component = {
    customId: "adm-roletransfer:",
    async execute(interaction) {
        if (!interaction.guild)
            return;
        const member = await interaction.guild.members.fetch(interaction.user.id);
        const authorized = (await (0, permissions_1.hasPermission)(member, enums_1.PermissionType.STAGE_MANAGER)) ||
            (await (0, permissions_1.hasPermission)(member, enums_1.PermissionType.REINTEGRATION_GRANTER));
        if (!authorized) {
            await interaction.reply({ content: "🚫 Você não tem permissão para acessar esta seção.", ephemeral: true });
            return;
        }
        const parts = interaction.customId.split(":"); // ["adm-roletransfer", "acao"]
        const action = parts[1];
        switch (action) {
            case "menu":
                return renderRoleTransferMenu(interaction);
            case "sourcerole":
                return openRolePicker(interaction, "sourcerole");
            case "targetrole":
                return openRolePicker(interaction, "targetrole");
            case "requisitos":
                return openRequisitosModal(interaction);
            case "schedule":
                return openScheduleModal(interaction);
            case "togglemode":
                return handleToggleMode(interaction);
            case "runnow":
                return handleRunNow(interaction);
            default:
                return renderRoleTransferMenu(interaction);
        }
    },
};
exports.default = component;
//# sourceMappingURL=admRoleTransferMenu.js.map