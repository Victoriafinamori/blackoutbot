"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const permissions_1 = require("../../utils/permissions");
const component = { customId: 'admin-task-home:', async execute(i) {
        if (!i.guild || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return;
        if (i.customId === 'admin-task-home:parcerias')
            return require('./admPartnershipsMenu').renderPartnershipsMenu(i);
    } };
exports.default = component;
