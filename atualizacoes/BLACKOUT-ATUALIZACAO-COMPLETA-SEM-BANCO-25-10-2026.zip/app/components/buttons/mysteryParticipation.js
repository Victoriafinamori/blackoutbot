"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const interactions_1 = require("../../games-chat/mystery-box/interactions");
exports.default = { customId: "mystery-panel:", execute: interactions_1.execute };
