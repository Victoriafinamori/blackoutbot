"use strict";
const { prepareAdminPanel } = require("../../utils/adminTasks");
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderReintegrationMenu = renderReintegrationMenu;
exports.renderStageDetail = renderStageDetail;
exports.renderStageChatPanel = renderStageChatPanel;
exports.renderStageChatChannelsPanel = renderStageChatChannelsPanel;
const discord_js_1 = require("discord.js");
const permissions_1 = require("../../utils/permissions");
const adminUi_1 = require("../../utils/adminUi");
const enums_1 = require("../../structures/enums");
const guildConfig_1 = require("../../database/guildConfig");
const stageChat_1 = require("../../utils/stageChat");
const reintegration_1 = require("../../utils/reintegration");
async function canManageStages(interaction) {
    const member = await interaction.guild.members.fetch(interaction.user.id);
    return (0, permissions_1.hasPermission)(member, enums_1.PermissionType.STAGE_MANAGER);
}
async function canGrantReintegration(interaction) {
    const member = await interaction.guild.members.fetch(interaction.user.id);
    return (0, permissions_1.hasPermission)(member, enums_1.PermissionType.REINTEGRATION_GRANTER);
}
async function renderReintegrationMenu(interaction) {
    const [canStages, canGrant] = await Promise.all([
        canManageStages(interaction),
        canGrantReintegration(interaction),
    ]);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "membros"))
        .setTitle("Gestão de Reintegração")
        .setDescription("Gerencie o fluxo de reintegração social do servidor e acompanhe os participantes.\n\n" +
        "**Categorias disponíveis:**\n" +
        "> **Fases do Programa:** Crie, ordene e configure o tempo ou os cargos de cada fase.\n" +
        "> **Gerenciar Membros:** Insira novos membros, registre avaliações, progrida-os ou aplique punições.\n" +
        "A transferência geral de cargos fica em **Cargos e automações**.");
    const buttons = [];
    if (canStages) {
        buttons.push(new discord_js_1.ButtonBuilder()
            .setCustomId("adm-reint:etapas")
            .setLabel("Fases do Programa")
            .setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder()
            .setCustomId("adm-reint:chatcanais")
            .setLabel("Canais de Chat (Fases)")
            .setStyle(discord_js_1.ButtonStyle.Secondary));
    }
    if (canStages || canGrant) {
        buttons.push(new discord_js_1.ButtonBuilder()
            .setCustomId("adm-reint:membros")
            .setLabel("Gerenciar Membros")
            .setStyle(discord_js_1.ButtonStyle.Secondary));
    }
    if (await (0, permissions_1.isBotAdmin)(await interaction.guild.members.fetch(interaction.user.id))) {
        buttons.push(new discord_js_1.ButtonBuilder().setCustomId("adm-notify:reintegracao").setLabel("Mensagens aos membros").setStyle(discord_js_1.ButtonStyle.Secondary));
    }
    const backRow = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder()
        .setCustomId("adm-nav:membros")
        .setLabel("Voltar")
        .setStyle(discord_js_1.ButtonStyle.Secondary));
    const rows = buttons.length
        ? [new discord_js_1.ActionRowBuilder().addComponents(...buttons), backRow]
        : [backRow];
    await interaction.update(prepareAdminPanel(interaction.guild, 'reintegracao', { attachments: [], embeds: [embed], components: rows }));
}
async function renderStagesList(interaction) {
    const stages = await (0, reintegration_1.getStages)(interaction.guild.id);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "membros"))
        .setTitle("Fases do Programa")
        .setDescription("Lista de todas as fases configuradas no sistema de reintegração.\n\n" +
        (stages.length
            ? stages
                .map((s, i) => `**${i + 1}. ${s.name}**\n` +
                `> Duração Mínima: ${s.minDays} dia(s) | Cargo: ${s.roleId ? `<@&${s.roleId}>` : "*Não vinculado*"} | Progressão: ${s.autoProgress ? "Automática" : "Manual"}`)
                .join("\n\n")
            : "> *Nenhuma fase foi configurada ainda.*"));
    const components = [];
    if (stages.length) {
        const select = new discord_js_1.StringSelectMenuBuilder()
            .setCustomId("adm-select:stage-pick")
            .setPlaceholder("Selecione uma fase para gerenciar")
            .addOptions(stages.map((s) => ({ label: s.name, value: s.id })));
        components.push(new discord_js_1.ActionRowBuilder().addComponents(select));
    }
    const actionRow = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder()
        .setCustomId("adm-reint:etapa:novo")
        .setLabel("Criar Nova Fase")
        .setStyle(discord_js_1.ButtonStyle.Success), new discord_js_1.ButtonBuilder()
        .setCustomId("adm-reint:menu")
        .setLabel("Voltar")
        .setStyle(discord_js_1.ButtonStyle.Secondary));
    components.push(actionRow);
    await interaction.update({ attachments: [], embeds: [embed], components });
}
async function openCreateStageModal(interaction) {
    const modal = new discord_js_1.ModalBuilder().setCustomId("adm-modal:stage:novo").setTitle("Criar Nova Fase");
    const nameInput = new discord_js_1.TextInputBuilder()
        .setCustomId("name")
        .setLabel("Nome da fase")
        .setStyle(discord_js_1.TextInputStyle.Short)
        .setRequired(true)
        .setMaxLength(50);
    const minDaysInput = new discord_js_1.TextInputBuilder()
        .setCustomId("minDays")
        .setLabel("Dias mínimos de permanência")
        .setStyle(discord_js_1.TextInputStyle.Short)
        .setPlaceholder("0")
        .setRequired(true)
        .setMaxLength(4);
    const restrictionsInput = new discord_js_1.TextInputBuilder()
        .setCustomId("restrictions")
        .setLabel("Restrições aplicadas (Opcional)")
        .setStyle(discord_js_1.TextInputStyle.Paragraph)
        .setPlaceholder("Ex: Membro não tem acesso ao canal de denúncias.")
        .setRequired(false)
        .setMaxLength(300);
    modal.addComponents(new discord_js_1.ActionRowBuilder().addComponents(nameInput), new discord_js_1.ActionRowBuilder().addComponents(minDaysInput), new discord_js_1.ActionRowBuilder().addComponents(restrictionsInput));
    await interaction.showModal(modal);
}
async function renderStageDetail(interaction, stageId) {
    const stage = await (0, reintegration_1.getStage)(stageId);
    if (!stage) {
        await interaction.reply({ content: "❌ Fase não encontrada.", ephemeral: true });
        return;
    }
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "membros"))
        .setTitle(`Gerenciar Fase: ${stage.name}`)
        .setDescription("**Configurações Atuais:**\n" +
        `> **Posição (Ordem):** ${stage.order}\n` +
        `> **Permanência Mínima:** ${stage.minDays} dia(s)\n` +
        `> **Cargo Vinculado:** ${stage.roleId ? `<@&${stage.roleId}>` : "*Nenhum*"}\n` +
        `> **Progressão para a Próxima Fase:** ${stage.autoProgress ? "Automática (por tempo)" : "Apenas Manual (Staff)"}\n` +
        `> **Restrições Documentadas:** ${stage.restrictions ?? "*Nenhuma*"}`);
    const row1 = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder()
        .setCustomId(`adm-reint:etapa:editar:${stage.id}`)
        .setLabel("Editar Dados")
        .setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder()
        .setCustomId(`adm-reint:etapa:cargo:${stage.id}`)
        .setLabel("Vincular Cargo")
        .setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder()
        .setCustomId(`adm-reint:etapa:auto:${stage.id}`)
        .setLabel(stage.autoProgress ? "Mudar p/ Progressão Manual" : "Mudar p/ Automática")
        .setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder()
        .setCustomId(`adm-reint:etapa:chat:${stage.id}`)
        .setLabel("Configurar Chat")
        .setStyle(discord_js_1.ButtonStyle.Secondary));
    const row2 = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder()
        .setCustomId(`adm-reint:etapa:mover:up:${stage.id}`)
        .setLabel("Subir Ordem ↑")
        .setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder()
        .setCustomId(`adm-reint:etapa:mover:down:${stage.id}`)
        .setLabel("Descer Ordem ↓")
        .setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder()
        .setCustomId(`adm-reint:etapa:excluir:${stage.id}`)
        .setLabel("Excluir Fase")
        .setStyle(discord_js_1.ButtonStyle.Danger));
    const backRow = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder()
        .setCustomId("adm-reint:etapas")
        .setLabel("Voltar")
        .setStyle(discord_js_1.ButtonStyle.Secondary));
    await interaction.update({ attachments: [], embeds: [embed], components: [row1, row2, backRow] });
}
async function renderStageChatPanel(interaction, stageId) {
    const stage = await (0, reintegration_1.getStage)(stageId);
    if (!stage) {
        await interaction.reply({ content: "❌ Fase não encontrada.", ephemeral: true });
        return;
    }
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "membros"))
        .setTitle(`Chat da Fase: ${stage.name}`)
        .setDescription("**Configurações de Chat:**\n" +
        `> **Modo Atual:** ${(0, reintegration_1.chatModeLabel)(stage.chatMode)}\n` +
        `> **Limite Diário de Mensagens:** ${stage.chatMaxMessagesPerDay ?? "*Sem limite*"}\n` +
        `> **Cooldown Entre Mensagens:** ${stage.chatCooldownSeconds ? `${stage.chatCooldownSeconds}s` : "*Sem cooldown*"}`);
    const row = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder()
        .setCustomId(`adm-reint:etapa:chat-modo:${stage.id}`)
        .setLabel("Alternar Modo")
        .setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder()
        .setCustomId(`adm-reint:etapa:chat-limites:${stage.id}`)
        .setLabel("Editar Limites")
        .setStyle(discord_js_1.ButtonStyle.Secondary));
    const backRow = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder()
        .setCustomId(`adm-reint:etapa:manage:${stage.id}`)
        .setLabel("Voltar")
        .setStyle(discord_js_1.ButtonStyle.Secondary));
    await interaction.update({ attachments: [], embeds: [embed], components: [row, backRow] });
}
async function renderStageChatChannelsPanel(interaction) {
    const config = await (0, guildConfig_1.getOrCreateGuildConfig)(interaction.guild.id);
    const current = (0, stageChat_1.getStageChatChannelIds)(config);
    const currentText = current.length ? current.map((id) => `<#${id}>`).join(", ") : "*nenhum canal selecionado*";
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "membros"))
        .setTitle("💬 Canais de Chat (Fases)")
        .setDescription(`Selecione até ${stageChat_1.MAX_STAGE_CHAT_CHANNELS} canais de texto onde a Restrição de Chat das Fases ` +
        "(Bloqueado / Limitado) deve valer. Fora desses canais, nenhuma fase restringe o chat — " +
        "e enquanto nenhum canal for escolhido, a restrição não é aplicada em lugar nenhum.\n\n" +
        `**Atuais:** ${currentText}`);
    const select = new discord_js_1.ChannelSelectMenuBuilder()
        .setCustomId("adm-stagechatchannel-select")
        .setPlaceholder(`Selecione até ${stageChat_1.MAX_STAGE_CHAT_CHANNELS} canais`)
        .addChannelTypes(discord_js_1.ChannelType.GuildText)
        .setMinValues(0)
        .setMaxValues(stageChat_1.MAX_STAGE_CHAT_CHANNELS);
    if (current.length)
        select.setDefaultChannels(current);
    const selectRow = new discord_js_1.ActionRowBuilder().addComponents(select);
    const backRow = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder()
        .setCustomId("adm-reint:menu")
        .setLabel("Voltar")
        .setStyle(discord_js_1.ButtonStyle.Secondary));
    if (interaction.isChannelSelectMenu() || interaction.isButton()) {
        await interaction.update({ attachments: [], embeds: [embed], components: [selectRow, backRow] });
    }
    else {
        await interaction.reply({ embeds: [embed], components: [selectRow, backRow], ephemeral: true });
    }
}
async function openStageChatLimitsModal(interaction, stageId) {
    const stage = await (0, reintegration_1.getStage)(stageId);
    if (!stage) {
        await interaction.reply({ content: "❌ Fase não encontrada.", ephemeral: true });
        return;
    }
    const modal = new discord_js_1.ModalBuilder()
        .setCustomId(`adm-modal:stagechat:${stageId}`)
        .setTitle(`Limites de Chat: ${stage.name}`.slice(0, 45));
    const maxMessagesInput = new discord_js_1.TextInputBuilder()
        .setCustomId("maxMessagesPerDay")
        .setLabel("Limite diário de mensagens")
        .setPlaceholder("Vazio = sem limite")
        .setStyle(discord_js_1.TextInputStyle.Short)
        .setValue(stage.chatMaxMessagesPerDay != null ? String(stage.chatMaxMessagesPerDay) : "")
        .setRequired(false)
        .setMaxLength(6);
    const cooldownInput = new discord_js_1.TextInputBuilder()
        .setCustomId("cooldownSeconds")
        .setLabel("Cooldown em segundos")
        .setPlaceholder("Vazio = sem cooldown")
        .setStyle(discord_js_1.TextInputStyle.Short)
        .setValue(stage.chatCooldownSeconds != null ? String(stage.chatCooldownSeconds) : "")
        .setRequired(false)
        .setMaxLength(6);
    modal.addComponents(new discord_js_1.ActionRowBuilder().addComponents(maxMessagesInput), new discord_js_1.ActionRowBuilder().addComponents(cooldownInput));
    await interaction.showModal(modal);
}
async function openEditStageModal(interaction, stageId) {
    const stage = await (0, reintegration_1.getStage)(stageId);
    if (!stage) {
        await interaction.reply({ content: "❌ Fase não encontrada.", ephemeral: true });
        return;
    }
    const modal = new discord_js_1.ModalBuilder()
        .setCustomId(`adm-modal:stage:editar:${stageId}`)
        .setTitle(`Editar ${stage.name}`.slice(0, 45));
    const nameInput = new discord_js_1.TextInputBuilder()
        .setCustomId("name")
        .setLabel("Nome da fase")
        .setStyle(discord_js_1.TextInputStyle.Short)
        .setValue(stage.name)
        .setRequired(true)
        .setMaxLength(50);
    const minDaysInput = new discord_js_1.TextInputBuilder()
        .setCustomId("minDays")
        .setLabel("Dias mínimos de permanência")
        .setStyle(discord_js_1.TextInputStyle.Short)
        .setValue(String(stage.minDays))
        .setRequired(true)
        .setMaxLength(4);
    const restrictionsInput = new discord_js_1.TextInputBuilder()
        .setCustomId("restrictions")
        .setLabel("Restrições aplicadas (Opcional)")
        .setStyle(discord_js_1.TextInputStyle.Paragraph)
        .setValue(stage.restrictions ?? "")
        .setRequired(false)
        .setMaxLength(300);
    modal.addComponents(new discord_js_1.ActionRowBuilder().addComponents(nameInput), new discord_js_1.ActionRowBuilder().addComponents(minDaysInput), new discord_js_1.ActionRowBuilder().addComponents(restrictionsInput));
    await interaction.showModal(modal);
}
async function openStageRolePicker(interaction, stageId) {
    const stage = await (0, reintegration_1.getStage)(stageId);
    if (!stage)
        return;
    const select = new discord_js_1.RoleSelectMenuBuilder()
        .setCustomId(`adm-role-select:stage:${stageId}`)
        .setPlaceholder(`Selecione o cargo para: ${stage.name}`)
        .setMinValues(0)
        .setMaxValues(1);
    if (stage.roleId)
        select.setDefaultRoles([stage.roleId]);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "membros"))
        .setTitle(`Vincular Cargo: ${stage.name}`)
        .setDescription("Membros nesta fase receberão o cargo selecionado abaixo automaticamente.\n\n" +
        `**Cargo Vinculado:**\n> ${stage.roleId ? `<@&${stage.roleId}>` : "*Nenhum cargo vinculado.*"}`);
    const selectRow = new discord_js_1.ActionRowBuilder().addComponents(select);
    const backRow = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder()
        .setCustomId(`adm-reint:etapa:manage:${stageId}`)
        .setLabel("Voltar")
        .setStyle(discord_js_1.ButtonStyle.Secondary));
    await interaction.update({ attachments: [], embeds: [embed], components: [selectRow, backRow] });
}
async function renderMembersMenu(interaction) {
    const [canStages, canGrant] = await Promise.all([
        canManageStages(interaction),
        canGrantReintegration(interaction),
    ]);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "membros"))
        .setTitle("Gerenciamento de Membros")
        .setDescription("Selecione qual ação deseja realizar com os participantes do programa de reintegração.");
    const buttons = [
        new discord_js_1.ButtonBuilder()
            .setCustomId("adm-reint:membros:inserir")
            .setLabel("Inserir Membro")
            .setStyle(discord_js_1.ButtonStyle.Success),
    ];
    if (canStages) {
        buttons.push(new discord_js_1.ButtonBuilder()
            .setCustomId("adm-reint:membros:remover")
            .setLabel("Remover Membro")
            .setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder()
            .setCustomId("adm-reint:membros:blacklist")
            .setLabel("Adicionar à Blacklist")
            .setStyle(discord_js_1.ButtonStyle.Danger));
    }
    const row1 = new discord_js_1.ActionRowBuilder().addComponents(...buttons);
    const rows = [row1];
    if (canStages) {
        rows.push(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder()
            .setCustomId("adm-reint:membros:progressao")
            .setLabel("Progressão Manual de Fase")
            .setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder()
            .setCustomId("adm-reint:membros:avaliacao")
            .setLabel("Avaliar Membro")
            .setStyle(discord_js_1.ButtonStyle.Secondary)));
    }
    rows.push(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder()
        .setCustomId("adm-reint:menu")
        .setLabel("Voltar")
        .setStyle(discord_js_1.ButtonStyle.Secondary)));
    await interaction.update({ attachments: [], embeds: [embed], components: rows });
}
function memberUserSelect(interaction, action, label) {
    const select = new discord_js_1.UserSelectMenuBuilder()
        .setCustomId(`adm-user-select:${action}`)
        .setPlaceholder(label)
        .setMinValues(1)
        .setMaxValues(1);
    const selectRow = new discord_js_1.ActionRowBuilder().addComponents(select);
    const backRow = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder()
        .setCustomId("adm-reint:membros")
        .setLabel("Voltar")
        .setStyle(discord_js_1.ButtonStyle.Secondary));
    return [selectRow, backRow];
}
async function renderExcluirConfirm(interaction, stageId) {
    const stage = await (0, reintegration_1.getStage)(stageId);
    if (!stage)
        return;
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "membros"))
        .setTitle("Confirmar Exclusão de Fase")
        .setDescription(`Tem certeza que deseja excluir permanentemente a fase **${stage.name}**?\n\n` +
        "> *Membros que estão atualmente nesta etapa perderão a referência a ela. As fases seguintes serão renumeradas automaticamente.*");
    const row = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder()
        .setCustomId(`adm-reint:etapa:excluir-confirmar:${stageId}`)
        .setLabel("Sim, Excluir Definitivamente")
        .setStyle(discord_js_1.ButtonStyle.Danger), new discord_js_1.ButtonBuilder()
        .setCustomId(`adm-reint:etapa:manage:${stageId}`)
        .setLabel("Cancelar Operação")
        .setStyle(discord_js_1.ButtonStyle.Secondary));
    await interaction.update({ attachments: [], embeds: [embed], components: [row] });
}
const component = {
    customId: "adm-reint:",
    async execute(interaction) {
        if (!interaction.guild)
            return;
        const member = await interaction.guild.members.fetch(interaction.user.id);
        const authorized = (await (0, permissions_1.hasPermission)(member, enums_1.PermissionType.STAGE_MANAGER)) ||
            (await (0, permissions_1.hasPermission)(member, enums_1.PermissionType.REINTEGRATION_GRANTER));
        if (!authorized) {
            await interaction.reply({
                content: "🚫 Você não tem permissão para acessar esta seção.",
                ephemeral: true,
            });
            return;
        }
        const parts = interaction.customId.split(":"); // ["adm-reint", "acao", "sub?", "id?"]
        const action = parts[1];
        const sub = parts[2];
        const idOrDir = parts[3];
        switch (action) {
            case "menu":
                return renderReintegrationMenu(interaction);
            case "chatcanais": {
                if (!(await canManageStages(interaction))) {
                    await interaction.reply({ content: "🚫 Acesso restrito aos Gerentes de Fase.", ephemeral: true });
                    return;
                }
                return renderStageChatChannelsPanel(interaction);
            }
            case "etapas": {
                if (!(await canManageStages(interaction))) {
                    await interaction.reply({ content: "🚫 Acesso restrito aos Gerentes de Fase.", ephemeral: true });
                    return;
                }
                return renderStagesList(interaction);
            }
            case "etapa": {
                if (!(await canManageStages(interaction))) {
                    await interaction.reply({ content: "🚫 Acesso restrito aos Gerentes de Fase.", ephemeral: true });
                    return;
                }
                if (sub === "novo")
                    return openCreateStageModal(interaction);
                if (sub === "manage")
                    return renderStageDetail(interaction, idOrDir);
                if (sub === "editar")
                    return openEditStageModal(interaction, idOrDir);
                if (sub === "cargo")
                    return openStageRolePicker(interaction, idOrDir);
                if (sub === "auto") {
                    await (0, reintegration_1.toggleStageAutoProgress)(interaction.guild, interaction.user.id, idOrDir);
                    return renderStageDetail(interaction, idOrDir);
                }
                if (sub === "chat")
                    return renderStageChatPanel(interaction, idOrDir);
                if (sub === "chat-modo") {
                    await (0, reintegration_1.cycleStageChatMode)(interaction.guild, interaction.user.id, idOrDir);
                    return renderStageChatPanel(interaction, idOrDir);
                }
                if (sub === "chat-limites")
                    return openStageChatLimitsModal(interaction, idOrDir);
                if (sub === "excluir")
                    return renderExcluirConfirm(interaction, idOrDir);
                if (sub === "excluir-confirmar") {
                    await (0, reintegration_1.deleteStage)(interaction.guild, interaction.user.id, idOrDir);
                    return renderStagesList(interaction);
                }
                if (sub === "mover") {
                    try {
                        // Nota: Se parts for [adm-reint, etapa, mover, up, ID], direction é parts[3] e o ID é parts[4].
                        // Ajustado para garantir que a lógica funcione com a sua string de divisão.
                        const direction = parts[3];
                        const targetId = parts[4] || idOrDir;
                        await (0, reintegration_1.moveStage)(interaction.guild, interaction.user.id, targetId, direction);
                    }
                    catch (err) {
                        if (err instanceof reintegration_1.ReintegrationError) {
                            await interaction.reply({ content: `❌ ${err.message}`, ephemeral: true });
                            return;
                        }
                        throw err;
                    }
                    return renderStagesList(interaction);
                }
                return;
            }
            case "membros": {
                const actions = {
                    inserir: { action: "insert", label: "Selecione quem será inserido", title: "Inserir Membro", needsStageManager: false },
                    remover: { action: "remove", label: "Selecione quem será removido", title: "Remover Membro", needsStageManager: true },
                    blacklist: { action: "blacklist", label: "Selecione o membro para blacklist", title: "Adicionar à Blacklist", needsStageManager: true },
                    progressao: { action: "progress", label: "Selecione o participante", title: "Progressão de Fase", needsStageManager: true },
                    avaliacao: { action: "evaluate", label: "Selecione o participante", title: "Avaliar Desempenho", needsStageManager: true },
                };
                const cfg = actions[sub];
                if (!cfg)
                    return renderMembersMenu(interaction);
                if (cfg.needsStageManager && !(await canManageStages(interaction))) {
                    await interaction.reply({ content: "🚫 Acesso restrito aos Gerentes de Fase.", ephemeral: true });
                    return;
                }
                const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "membros")).setTitle(cfg.title).setDescription(`> ${cfg.label}`);
                await interaction.update({ attachments: [], embeds: [embed],
                    components: memberUserSelect(interaction, cfg.action, cfg.label),
                });
                return;
            }
            case "progress": {
                if (!(await canManageStages(interaction))) {
                    await interaction.reply({ content: "🚫 Acesso restrito aos Gerentes de Fase.", ephemeral: true });
                    return;
                }
                // Nota: Garantindo captura correta do UserId.
                const userId = parts[4] || parts[3];
                try {
                    const direction = sub;
                    const result = await (0, reintegration_1.progressMember)(interaction.guild, interaction.user.id, userId, direction);
                    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "membros"))
                        .setTitle("Progressão Realizada")
                        .setDescription(result.completed
                        ? `✅ O membro <@${userId}> **concluiu** o processo de reintegração com sucesso!`
                        : `✅ O membro <@${userId}> foi movido para a fase **${result.stage?.name}**.`);
                    await interaction.update({ attachments: [], embeds: [embed], components: [] });
                }
                catch (err) {
                    if (err instanceof reintegration_1.ReintegrationError) {
                        await interaction.reply({ content: `❌ ${err.message}`, ephemeral: true });
                        return;
                    }
                    throw err;
                }
                return;
            }
            case "evaluate": {
                const userId = parts[4] || parts[3];
                const isApproved = sub === "aprovar";
                const modal = new discord_js_1.ModalBuilder()
                    .setCustomId(`adm-modal:evaluation:${isApproved}:${userId}`)
                    .setTitle(isApproved ? "Aprovar Participante" : "Reprovar Participante");
                const notesInput = new discord_js_1.TextInputBuilder()
                    .setCustomId("notes")
                    .setLabel("Descreva o motivo (Opcional)")
                    .setStyle(discord_js_1.TextInputStyle.Paragraph)
                    .setRequired(false)
                    .setMaxLength(300);
                modal.addComponents(new discord_js_1.ActionRowBuilder().addComponents(notesInput));
                await interaction.showModal(modal);
                return;
            }
            default:
                return renderReintegrationMenu(interaction);
        }
    },
};
exports.default = component;
//# sourceMappingURL=admReintegrationMenu.js.map