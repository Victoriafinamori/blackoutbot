"use strict";
const { prepareAdminPanel } = require("../../utils/adminTasks");
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderMovCallRoot = renderMovCallRoot;
exports.renderMovCallConfigMenu = renderMovCallConfigMenu;
exports.renderMovCallTopCallMenu = renderMovCallTopCallMenu;
exports.renderRewardsMenu = renderRewardsMenu;
exports.renderMovCallStatsMenu = renderMovCallStatsMenu;
const discord_js_1 = require("discord.js");
const admPanel_1 = require("../../utils/admPanel");
const permissions_1 = require("../../utils/permissions");
const adminUi_1 = require("../../utils/adminUi");
const adminLog_1 = require("../../utils/adminLog");
const enums_1 = require("../../structures/enums");
const movStats_1 = require("../../utils/movStats");
const prisma_1 = require("../../database/prisma");
const movCallStats_1 = require("../../utils/movCallStats");
function backRow(customId, label = "Voltar") {
    return new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId(customId).setLabel(label).setStyle(discord_js_1.ButtonStyle.Secondary));
}
// Várias telas aqui são chamadas tanto por botões quanto por selects de canal
// e cargo (e, no caso do intervalo/recompensas, por submits de modal) — por
// isso o tipo "any", igual ao padrão já usado em admMovMenu.ts.
// -----------------------------
// 📞 Raiz do Mov.Call
// -----------------------------
async function renderMovCallRoot(interaction) {
    const config = await (0, movCallStats_1.getGuildConfigForMovCall)(interaction.guild.id);
    const categories = (0, movCallStats_1.getMovCallCategoryIds)(config);
    const roles = await prisma_1.prisma.permissionRole.count({ where: { guildId: interaction.guild.id, type: enums_1.PermissionType.MOVCALL_COMMANDS } });
    const lastReset = Math.floor(config.movCallLastResetAt.getTime() / 1000);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor"))
        .setTitle("Atividade em call")
        .setDescription("ℹ️ **Informações**\n" +
        `Status: ${config.movCallSystemEnabled ? "🟢 (Ativado)" : "🔴 (Desativado)"}\n` +
        `Cargos com acesso aos comandos: **${roles}**\n` +
        `Categorias: **${categories.length} categoria(s)**\n` +
        `Último Reset: <t:${lastReset}:R>\n` +
        `Contar tempo mutado: **${config.movCallCountMuted ? "Sim" : "Não"}**\n` +
        `\n` +
        "👤 **Observações**\n" +
        "Escolha as categorias monitoradas, revise as regras de contagem e configure o ranking. Os cargos de acesso controlam os comandos do módulo.");
    const row1 = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-nav:servidor").setLabel("Voltar").setStyle(discord_js_1.ButtonStyle.Primary), new discord_js_1.ButtonBuilder().setCustomId("adm-movcall:togglesystemroot").setLabel(config.movCallSystemEnabled ? "Desativar" : "Ativar").setStyle(config.movCallSystemEnabled ? discord_js_1.ButtonStyle.Danger : discord_js_1.ButtonStyle.Success), new discord_js_1.ButtonBuilder().setCustomId("adm-movcall:permroles").setLabel("Gerenciar Cargos").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId("adm-movcall:categories").setLabel("Gerenciar Categorias").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId("adm-movcall:interval").setLabel("Horários").setStyle(discord_js_1.ButtonStyle.Secondary));
    const row2 = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-movcall:togglemutedroot").setLabel("Tempo Mutado").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId("adm-movcall:topcall").setLabel("Recompensas").setStyle(discord_js_1.ButtonStyle.Primary), new discord_js_1.ButtonBuilder().setCustomId("adm-movcall:stats").setLabel("Estatísticas").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId("adm-movcall:requestreset").setLabel("Resetar Tempo Global").setStyle(discord_js_1.ButtonStyle.Danger), new discord_js_1.ButtonBuilder().setCustomId("adm-movcall:resetconfigrequest").setLabel("Resetar Configs").setStyle(discord_js_1.ButtonStyle.Danger));
    await interaction.update(prepareAdminPanel(interaction.guild, 'movcall', { attachments: [], embeds: [embed], components: [row1, row2, (0, admPanel_1.adminBackRow)("servidor")] }));
}
// -----------------------------
// ⚙️ Configurações
// -----------------------------
async function renderMovCallConfigMenu(interaction) {
    const config = await (0, movCallStats_1.getGuildConfigForMovCall)(interaction.guild.id);
    const categories = (0, movCallStats_1.getMovCallCategoryIds)(config);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor"))
        .setTitle("⚙️ Mov.Call — Configurações")
        .setDescription("ℹ️ **Informações**")
        .addFields({ name: "Status", value: config.movCallSystemEnabled ? "🟢 `Ativado`" : "🔴 `Desativado`", inline: true }, { name: "Contar Tempo Mutado", value: config.movCallCountMuted ? "🟢 `Ativado`" : "🔴 `Desativado`", inline: true }, {
        name: "📂 Categorias Monitoradas",
        value: categories.length ? categories.map((id) => `<#${id}>`).join(", ") : "*nenhuma selecionada*",
    }, {
        name: "👮 Observações",
        value: "Defina os **cargos com permissão** para usar `/tempocall`, `/rankingcall` e `/callinfo` em outros membros.",
    });
    const row1 = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder()
        .setCustomId("adm-movcall:togglesystem")
        .setLabel(config.movCallSystemEnabled ? "Desativar Sistema" : "Ativar Sistema")
        .setStyle(config.movCallSystemEnabled ? discord_js_1.ButtonStyle.Danger : discord_js_1.ButtonStyle.Success), new discord_js_1.ButtonBuilder()
        .setCustomId("adm-movcall:togglemuted")
        .setLabel(config.movCallCountMuted ? "Não Contar Mutado" : "Contar Mutado")
        .setStyle(config.movCallCountMuted ? discord_js_1.ButtonStyle.Danger : discord_js_1.ButtonStyle.Success));
    const row2 = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-movcall:categories").setLabel("Categorias Monitoradas").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId("adm-movcall:permroles").setLabel("Cargos com Permissão").setStyle(discord_js_1.ButtonStyle.Secondary));
    await interaction.update({ attachments: [], embeds: [embed], components: [row1, row2, backRow("adm-movcall:root")] });
}
async function toggleSystem(interaction) {
    const next = await (0, movCallStats_1.toggleMovCallSystem)(interaction.guild.id);
    if (next)
        await (0, movCallStats_1.recoverActiveCallSessions)(interaction.guild);
    else
        await (0, movCallStats_1.clearActiveCallSessions)(interaction.guild.id);
    await (0, adminLog_1.logAdminAction)({
        guild: interaction.guild,
        actorId: interaction.user.id,
        action: enums_1.AdminLogAction.MOVCALL_CONFIG_CHANGED,
        details: `Status do Sistema: ${next ? "ativado" : "desativado"}`,
    });
    await renderMovCallConfigMenu(interaction);
}
async function toggleSystemRoot(interaction) { const next = await (0, movCallStats_1.toggleMovCallSystem)(interaction.guild.id); if (next)
    await (0, movCallStats_1.recoverActiveCallSessions)(interaction.guild);
else
    await (0, movCallStats_1.clearActiveCallSessions)(interaction.guild.id); await (0, adminLog_1.logAdminAction)({ guild: interaction.guild, actorId: interaction.user.id, action: enums_1.AdminLogAction.MOVCALL_CONFIG_CHANGED, details: `Status do Sistema: ${next ? "ativado" : "desativado"}` }); await renderMovCallRoot(interaction); }
async function toggleCountMuted(interaction) {
    const next = await (0, movCallStats_1.toggleMovCallCountMuted)(interaction.guild.id);
    await (0, adminLog_1.logAdminAction)({
        guild: interaction.guild,
        actorId: interaction.user.id,
        action: enums_1.AdminLogAction.MOVCALL_CONFIG_CHANGED,
        details: `Contabilizar Tempo Mutado: ${next ? "ativado" : "desativado"}`,
    });
    await renderMovCallConfigMenu(interaction);
}
async function toggleCountMutedRoot(interaction) { const next = await (0, movCallStats_1.toggleMovCallCountMuted)(interaction.guild.id); await (0, adminLog_1.logAdminAction)({ guild: interaction.guild, actorId: interaction.user.id, action: enums_1.AdminLogAction.MOVCALL_CONFIG_CHANGED, details: `Contabilizar Tempo Mutado: ${next ? "ativado" : "desativado"}` }); await renderMovCallRoot(interaction); }
async function renderCategoriesPicker(interaction) {
    const config = await (0, movCallStats_1.getGuildConfigForMovCall)(interaction.guild.id);
    const current = (0, movCallStats_1.getMovCallCategoryIds)(config);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor"))
        .setTitle("📂 Categorias Monitoradas")
        .setDescription(`Selecione até ${movCallStats_1.MAX_MOV_CALL_CATEGORIES} categorias do Discord. Qualquer canal de voz dentro delas conta tempo no Mov.Call.`);
    const select = new discord_js_1.ChannelSelectMenuBuilder()
        .setCustomId("adm-movcallcategory-select")
        .setPlaceholder(`Selecione até ${movCallStats_1.MAX_MOV_CALL_CATEGORIES} categorias`)
        .addChannelTypes(discord_js_1.ChannelType.GuildCategory)
        .setMinValues(0)
        .setMaxValues(movCallStats_1.MAX_MOV_CALL_CATEGORIES);
    if (current.length)
        select.setDefaultChannels(current);
    const selectRow = new discord_js_1.ActionRowBuilder().addComponents(select);
    await interaction.update({ attachments: [], embeds: [embed], components: [selectRow, backRow("adm-movcall:config")] });
}
async function renderPermRolesPicker(interaction) {
    const roles = await prisma_1.prisma.permissionRole.findMany({
        where: { guildId: interaction.guild.id, type: enums_1.PermissionType.MOVCALL_COMMANDS },
        select: { roleId: true },
    });
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor"))
        .setTitle("👮 Cargos com Permissão")
        .setDescription("Cargos que poderão usar `/tempocall @membro`, `/rankingcall` e `/callinfo @membro`.\n\n" +
        `**Atuais:** ${roles.length ? roles.map((r) => `<@&${r.roleId}>`).join(", ") : "*nenhum cadastrado*"}`);
    const select = new discord_js_1.RoleSelectMenuBuilder()
        .setCustomId("adm-role-select:movcallperm")
        .setPlaceholder("Selecione os cargos autorizados")
        .setMinValues(0)
        .setMaxValues(10);
    if (roles.length)
        select.setDefaultRoles(roles.map((r) => r.roleId));
    const selectRow = new discord_js_1.ActionRowBuilder().addComponents(select);
    await interaction.update({ attachments: [], embeds: [embed], components: [selectRow, backRow("adm-movcall:config")] });
}
// -----------------------------
// 🏆 Top Call
// -----------------------------
async function renderMovCallTopCallMenu(interaction) {
    const config = await (0, movCallStats_1.getGuildConfigForMovCall)(interaction.guild.id);
    const nextReset = (0, movCallStats_1.computeNextMovCallResetAt)(config);
    const rewards = await (0, movCallStats_1.getMovCallRewards)(interaction.guild.id);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor"))
        .setTitle("Mov Call — AUDAZ")
        .setDescription("ℹ️ **Informações**\n" +
        `Status: ${config.movCallRankingEnabled ? "🟢 (Ativado)" : "🔴 (Desativado)"}\n` +
        `Reset Global: ${config.movCallResetIntervalDays
            ? `**a cada ${config.movCallResetIntervalDays} dia(s)** — próximo em <t:${Math.floor(nextReset.getTime() / 1000)}:R>`
            : "**Não definido**"}\n` +
        `Tempo por Cargo: **${rewards.length ? `${rewards.length} configurado(s)` : "Não definido"}**\n` +
        `Cargo Top1: ${config.movCallTop1RoleId ? `<@&${config.movCallTop1RoleId}>` : "**Não definido**"}\n\n` +
        "📌 **Canais**\n" +
        `Canal de Logs: ${config.movCallLogChannelId ? `<#${config.movCallLogChannelId}>` : "**Não definido**"}\n` +
        `Canal de Rank: ${config.movCallRankingChannelId ? `<#${config.movCallRankingChannelId}>` : "**Não definido**"}\n\n` +
        "👤 **Observações**\nAqui você pode configurar quais **cargos por X tempo em call** o usuário ganhará. Também pode configurar apenas 1 cargo para o **top1**, deixando o ranking disputado!");
    const row1 = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder()
        .setCustomId("adm-movcall:toggleranking")
        .setLabel(config.movCallRankingEnabled ? "Desativar" : "Ativar")
        .setStyle(config.movCallRankingEnabled ? discord_js_1.ButtonStyle.Danger : discord_js_1.ButtonStyle.Success), new discord_js_1.ButtonBuilder().setCustomId("adm-movcall:rankingchannel").setLabel("Configurar Canais").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId("adm-movcall:rewards").setLabel("Configurar Cargos").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId("adm-movcall:top1role").setLabel("Cargo Top1").setStyle(discord_js_1.ButtonStyle.Secondary));
    const row2 = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-movcall:interval").setLabel("Tempo Reset").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId("adm-movcall:logchannel").setLabel("Canal de Logs").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId("adm-movcall:stats").setLabel("Listar Configs").setStyle(discord_js_1.ButtonStyle.Primary));
    const row3 = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-movcall:requestreset").setLabel("Resetar Tudo").setStyle(discord_js_1.ButtonStyle.Danger));
    await interaction.update({ attachments: [], embeds: [embed], components: [backRow("adm-movcall:root"), row1, row2, row3] });
}
async function toggleRanking(interaction) {
    const next = await (0, movCallStats_1.toggleMovCallRanking)(interaction.guild.id);
    await (0, adminLog_1.logAdminAction)({
        guild: interaction.guild,
        actorId: interaction.user.id,
        action: enums_1.AdminLogAction.MOVCALL_CONFIG_CHANGED,
        details: `Status do Ranking (Top Call): ${next ? "ativado" : "desativado"}`,
    });
    await renderMovCallTopCallMenu(interaction);
}
async function openIntervalModal(interaction) {
    const config = await (0, movCallStats_1.getGuildConfigForMovCall)(interaction.guild.id);
    const modal = new discord_js_1.ModalBuilder().setCustomId("adm-modal:movcallinterval").setTitle("Período de Reset — Top Call");
    const daysInput = new discord_js_1.TextInputBuilder()
        .setCustomId("days")
        .setLabel("Reseta a cada quantos dias? (1 a 90)")
        .setPlaceholder("Vazio = só reseto manualmente")
        .setStyle(discord_js_1.TextInputStyle.Short)
        .setValue(config.movCallResetIntervalDays ? String(config.movCallResetIntervalDays) : "")
        .setRequired(false)
        .setMaxLength(2);
    modal.addComponents(new discord_js_1.ActionRowBuilder().addComponents(daysInput));
    await interaction.showModal(modal);
}
async function renderChannelPicker(interaction, kind) {
    const config = await (0, movCallStats_1.getGuildConfigForMovCall)(interaction.guild.id);
    const current = kind === "ranking" ? config.movCallRankingChannelId : config.movCallLogChannelId;
    const label = kind === "ranking" ? "Canal do Ranking" : "Canal de Logs";
    const emoji = kind === "ranking" ? "🏅" : "📜";
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor"))
        .setTitle(`${emoji} ${label}`)
        .setDescription(`**Atual:** ${current ? `<#${current}>` : "*não definido*"}\n\nSelecione um canal de texto abaixo.`);
    const select = new discord_js_1.ChannelSelectMenuBuilder()
        .setCustomId(`adm-movcallchannel-select:${kind}`)
        .setPlaceholder(`Selecione o ${label.toLowerCase()}`)
        .addChannelTypes(discord_js_1.ChannelType.GuildText)
        .setMinValues(0)
        .setMaxValues(1);
    if (current)
        select.setDefaultChannels([current]);
    const selectRow = new discord_js_1.ActionRowBuilder().addComponents(select);
    await interaction.update({ attachments: [], embeds: [embed], components: [selectRow, backRow("adm-movcall:topcall")] });
}
async function renderTop1RolePicker(interaction) {
    const config = await (0, movCallStats_1.getGuildConfigForMovCall)(interaction.guild.id);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor"))
        .setTitle("👑 Cargo do Top 1")
        .setDescription(`**Atual:** ${config.movCallTop1RoleId ? `<@&${config.movCallTop1RoleId}>` : "*não definido*"}\n\n` +
        "Cargo concedido automaticamente ao membro que estiver na 1ª posição do Top Call. É removido de quem perder a posição.");
    const select = new discord_js_1.RoleSelectMenuBuilder().setCustomId("adm-role-select:movcalltop1").setPlaceholder("Selecione o cargo").setMinValues(0).setMaxValues(1);
    if (config.movCallTop1RoleId)
        select.setDefaultRoles([config.movCallTop1RoleId]);
    const selectRow = new discord_js_1.ActionRowBuilder().addComponents(select);
    await interaction.update({ attachments: [], embeds: [embed], components: [selectRow, backRow("adm-movcall:topcall")] });
}
async function handleResetNow(interaction) {
    await (0, movCallStats_1.resetMovCallStats)(interaction.guild.id);
    await (0, adminLog_1.logAdminAction)({
        guild: interaction.guild,
        actorId: interaction.user.id,
        action: enums_1.AdminLogAction.MOVCALL_RESET,
        details: "Reset manual do Top Call.",
    });
    await (0, movCallStats_1.refreshCallRankingMessage)(interaction.guild).catch(() => null);
    await renderMovCallTopCallMenu(interaction);
}
async function renderResetConfirmation(interaction) {
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor")).setColor(0xd71935).setTitle("Confirmar reset — MOV CALL").setDescription("Esta ação zera o Top Call e inicia uma nova contagem a partir deste momento.\n\nQuem estiver em call continuará sendo contado, mas somente o tempo posterior ao reset será considerado. Configurações e histórico diário da Limpa serão preservados.");
    const row = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-movcall:confirmreset").setLabel("Confirmar reset").setStyle(discord_js_1.ButtonStyle.Danger), new discord_js_1.ButtonBuilder().setCustomId("adm-movcall:topcall").setLabel("Cancelar").setStyle(discord_js_1.ButtonStyle.Secondary));
    await interaction.update({ attachments: [], embeds: [embed], components: [row] });
}
async function renderResetConfigConfirmation(interaction) { const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor")).setColor(0xd71935).setTitle("Resetar configurações do MOV CALL?").setDescription("Esta ação restaura canais, categorias, cargos autorizados, cargo Top1, recompensas e período automático. As estatísticas de tempo não serão apagadas."); const row = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-movcall:resetconfigconfirm").setLabel("Confirmar reset das configurações").setStyle(discord_js_1.ButtonStyle.Danger), new discord_js_1.ButtonBuilder().setCustomId("adm-movcall:root").setLabel("Cancelar").setStyle(discord_js_1.ButtonStyle.Secondary)); await interaction.update({ attachments: [], embeds: [embed], components: [row] }); }
async function resetMovCallConfig(interaction) { await prisma_1.prisma.$transaction([prisma_1.prisma.guildConfig.update({ where: { guildId: interaction.guild.id }, data: { movCallSystemEnabled: true, movCallCountMuted: true, movCallRankingEnabled: true, movCallResetIntervalDays: null, movCallRankingChannelId: null, movCallRankingMessageId: null, movCallLogChannelId: null, movCallTop1RoleId: null, movCallCategoryIds: null } }), prisma_1.prisma.permissionRole.deleteMany({ where: { guildId: interaction.guild.id, type: enums_1.PermissionType.MOVCALL_COMMANDS } }), prisma_1.prisma.movCallReward.deleteMany({ where: { guildId: interaction.guild.id } })]); await (0, adminLog_1.logAdminAction)({ guild: interaction.guild, actorId: interaction.user.id, action: enums_1.AdminLogAction.MOVCALL_CONFIG_CHANGED, details: "Configurações do MOV CALL restauradas. Estatísticas preservadas." }); await renderMovCallRoot(interaction); }
// -----------------------------
// 🎖️ Recompensas por Tempo
// -----------------------------
async function renderRewardsMenu(interaction) {
    const rewards = await (0, movCallStats_1.getMovCallRewards)(interaction.guild.id);
    const lines = rewards.length
        ? rewards
            .map((r) => `**${r.minHours}h** → <@&${r.roleId}>`)
            .join("\n")
        : "*Nenhuma recompensa cadastrada ainda.*";
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor"))
        .setTitle("🎖️ Recompensas por Tempo")
        .setDescription("Cargos automáticos conforme o tempo acumulado em call. Todos os limiares atingidos são concedidos " +
        "(cargos anteriores não são removidos).\n\n" +
        lines);
    const row = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId("adm-movcall:rewardadd").setLabel("Adicionar / Editar").setStyle(discord_js_1.ButtonStyle.Success), new discord_js_1.ButtonBuilder().setCustomId("adm-movcall:rewardremove").setLabel("Remover").setStyle(discord_js_1.ButtonStyle.Danger));
    await interaction.update({ attachments: [], embeds: [embed], components: [row, backRow("adm-movcall:topcall")] });
}
async function openRewardRoleAdd(interaction) {
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor"))
        .setTitle("➕ Adicionar / Editar Recompensa")
        .setDescription("Selecione o cargo que será concedido. Em seguida, informe o tempo mínimo (em horas).");
    const select = new discord_js_1.RoleSelectMenuBuilder().setCustomId("adm-role-select:movcallrewardadd").setPlaceholder("Selecione o cargo").setMinValues(1).setMaxValues(1);
    const selectRow = new discord_js_1.ActionRowBuilder().addComponents(select);
    await interaction.update({ attachments: [], embeds: [embed], components: [selectRow, backRow("adm-movcall:rewards")] });
}
async function openRewardRoleRemove(interaction) {
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor"))
        .setTitle("🗑️ Remover Recompensa")
        .setDescription("Selecione o cargo da recompensa que deseja remover.");
    const select = new discord_js_1.RoleSelectMenuBuilder().setCustomId("adm-role-select:movcallrewardremove").setPlaceholder("Selecione o cargo").setMinValues(1).setMaxValues(1);
    const selectRow = new discord_js_1.ActionRowBuilder().addComponents(select);
    await interaction.update({ attachments: [], embeds: [embed], components: [selectRow, backRow("adm-movcall:rewards")] });
}
// -----------------------------
// 📊 Estatísticas
// -----------------------------
async function renderMovCallStatsMenu(interaction) {
    const rows = await (0, movStats_1.getRanking)(interaction.guild.id, enums_1.MovStatType.CALL, 10);
    const lines = rows.length
        ? rows
            .map((r, i) => `**${i + 1}.** <@${r.userId}> — ${(0, movStats_1.formatDuration)(r.value)}`)
            .join("\n")
        : "*Ninguém pontuou ainda.*";
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "servidor"))
        .setTitle("📊 Mov.Call — Estatísticas")
        .setDescription("**Top 10 — Tempo em Call**\n" +
        lines +
        "\n\n" +
        "Cada membro pode consultar os próprios números com:\n" +
        "`/tempocall` — tempo em call (hoje, semana, mês, total)\n" +
        "`/callinfo` — estatísticas completas (tempo, sequência e companhia)\n" +
        "`/topcall` — Top 10 do servidor\n" +
        "`/rankingcall` — ranking completo (requer permissão, se configurada)");
    await interaction.update({ attachments: [], embeds: [embed], components: [backRow("adm-movcall:root")] });
}
const component = {
    customId: "adm-movcall:",
    async execute(interaction) {
        if (!interaction.guild)
            return;
        const member = await interaction.guild.members.fetch(interaction.user.id);
        if (!(await (0, permissions_1.isBotAdmin)(member))) {
            await interaction.reply({ content: "🚫 Você não tem permissão para acessar esta seção.", ephemeral: true });
            return;
        }
        const parts = interaction.customId.split(":"); // ["adm-movcall", "acao"]
        const action = parts[1];
        switch (action) {
            case "root":
                return renderMovCallRoot(interaction);
            case "config":
                return renderMovCallConfigMenu(interaction);
            case "togglesystem":
                return toggleSystem(interaction);
            case "togglesystemroot": return toggleSystemRoot(interaction);
            case "togglemuted":
                return toggleCountMuted(interaction);
            case "togglemutedroot": return toggleCountMutedRoot(interaction);
            case "categories":
                return renderCategoriesPicker(interaction);
            case "permroles":
                return renderPermRolesPicker(interaction);
            case "topcall":
                return renderMovCallTopCallMenu(interaction);
            case "toggleranking":
                return toggleRanking(interaction);
            case "interval":
                return openIntervalModal(interaction);
            case "rankingchannel":
                return renderChannelPicker(interaction, "ranking");
            case "logchannel":
                return renderChannelPicker(interaction, "logs");
            case "top1role":
                return renderTop1RolePicker(interaction);
            case "requestreset":
                return renderResetConfirmation(interaction);
            case "confirmreset":
                return handleResetNow(interaction);
            case "resetconfigrequest": return renderResetConfigConfirmation(interaction);
            case "resetconfigconfirm": return resetMovCallConfig(interaction);
            case "rewards":
                return renderRewardsMenu(interaction);
            case "rewardadd":
                return openRewardRoleAdd(interaction);
            case "rewardremove":
                return openRewardRoleRemove(interaction);
            case "stats":
                return renderMovCallStatsMenu(interaction);
            default:
                return renderMovCallRoot(interaction);
        }
    },
};
exports.default = component;
//# sourceMappingURL=admMovCallMenu.js.map