"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const permissions_1 = require("../../utils/permissions");
const registration_1 = require("../../utils/registration");
const prisma_1 = require("../../database/prisma");
const panelInteraction_1 = require("../../utils/panelInteraction");
const registrationAdmin_1 = require("../../utils/registrationAdmin");
const editor = require('../../../app/utils/registrationPanelEditor');
const input = (id, label, value, paragraph = false) => new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId(id).setLabel(label).setValue(value || '').setStyle(paragraph ? discord_js_1.TextInputStyle.Paragraph : discord_js_1.TextInputStyle.Short).setRequired(id !== 'assets'));
const component = { customId: 'adm-reg-embed:', async execute(i) {
        if (!i.guild || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return;
        const action = i.customId.split(':')[1], c = await (0, registration_1.regConfig)(i.guild.id);
        if (action === 'panel')
            return (0, panelInteraction_1.refreshPanel)(i, await editor.registrationPanelEditor(i.guild));
        if (action === 'publish')
            return (0, registrationAdmin_1.renderRegistrationAdmin)(i, 'publication');
        if (action === 'internal')
            return i.showModal(new discord_js_1.ModalBuilder().setCustomId('registration-embed:internal').setTitle('Mensagem do chat de registro').addComponents(input('title', 'Título', c.internalTitle), input('description', 'Descrição', c.internalDescription, true), input('color', 'Cor hexadecimal', c.internalColor), input('assets', 'Thumbnail, imagem e rodapé', `THUMBNAIL=${c.internalThumbnail || ''}\nIMAGEM=${c.internalImage || ''}\nRODAPE=${c.internalFooter || ''}`, true)));
        if (action === 'send') {
            await (0, panelInteraction_1.deferPanel)(i);
            try {
                const fresh = await (0, registration_1.regConfig)(i.guild.id);
                if (!fresh.panelChannelId || !fresh.registrationCategoryId)
                    return (0, panelInteraction_1.refreshPanel)(i, { ...await (0, registrationAdmin_1.registrationAdminPayload)(i.guild, 'publication'), content: 'Escolha o canal público e a categoria dos chats privados antes de publicar.' });
                const ch = await i.guild.channels.fetch(fresh.panelChannelId);
                if (!ch?.isTextBased() || ch.isDMBased() || !ch.isSendable())
                    throw Error('O canal do painel não aceita mensagens. Revise o destino.');
                let message = null;
                if (fresh.panelMessageId) {
                    try {
                        message = await ch.messages.fetch(fresh.panelMessageId);
                    }
                    catch (error) {
                        if (error.code !== 10008)
                            throw error;
                    }
                }
                const payload = { ...editor.registrationPanelPayload(fresh), allowedMentions: { parse: [] } };
                if (message)
                    await message.edit(payload);
                else {
                    message = await ch.send(payload);
                    await prisma_1.prisma.registrationConfig.update({ where: { guildId: i.guild.id }, data: { panelMessageId: message.id } });
                }
                return (0, panelInteraction_1.refreshPanel)(i, { ...await (0, registrationAdmin_1.registrationAdminPayload)(i.guild, 'publication'), content: `Painel publicado/atualizado em <#${fresh.panelChannelId}>.` });
            }
            catch (error) {
                return i.followUp({ content: `Não foi possível publicar: ${error.message}. Revise o canal e as permissões antes de repetir.`, ephemeral: true });
            }
        }
    } };
exports.default = component;
