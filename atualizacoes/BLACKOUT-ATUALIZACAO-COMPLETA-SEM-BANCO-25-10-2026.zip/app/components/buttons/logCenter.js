"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const permissions_1 = require("../../utils/permissions");
const panelInteraction_1 = require("../../utils/panelInteraction");
const adminUi_1 = require("../../utils/adminUi");
const config_1 = require("../../logging/config");
const delivery_1 = require("../../logging/delivery");
const panel_1 = require("../../logging/panel");
exports.default = { customId: "logs-center:", async execute(i) {
        if (!i.guild || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return i.reply({ content: "Você não possui permissão neste servidor.", ephemeral: true });
        const [, action, scope, section] = i.customId.split(":");
        if (action === "external")
            return (0, panel_1.externalModal)(i);
        await (0, panelInteraction_1.deferPanel)(i);
        if (action === "events")
            return (0, panel_1.renderLogEvents)(i, scope);
        if (action === "destination")
            return (0, panel_1.renderLogDestination)(i);
        if (action === "organization")
            return (0, panel_1.renderLogOrganization)(i, scope, section);
        if (action === "diagnostic")
            return (0, panel_1.renderLogDiagnostic)(i);
        if (action === "diagnostic-details")
            return (0, panel_1.renderLogTechnicalDiagnostic)(i);
        if (action === "help")
            return (0, panel_1.renderLogHelp)(i, scope);
        if (action === "modules")
            return (0, panel_1.renderModuleLogLinks)(i);
        if (action === "module")
            return (0, panel_1.openModuleLogLink)(i, scope);
        if (action === "filters")
            return (0, panel_1.renderLogFilters)(i);
        if (action === "toggle-bots") {
            const s = await (0, config_1.readLogSettings)(i.guild.id, true);
            await (0, config_1.saveLogSettings)(i.guild.id, { ignoreBots: !s.ignoreBots });
            return (0, panel_1.renderLogFilters)(i, "Filtro salvo neste servidor.");
        }
        if (action === "test" || action === "test-external") {
            const result = await (0, delivery_1.deliverLog)(i.guild, "system.actions", (0, adminUi_1.adminEmbed)(i.guild, "seguranca").setTitle("Teste da central de logs").setDescription(`Solicitado por ${i.user.id}. Este é um evento de teste.`), {}, true, action === "test-external" ? "EXTERNAL" : undefined);
            const notice = `${result.sent} destinos receberam o teste.${result.errors.length ? " " + result.errors.join(" ") : ""}`;
            return action === "test-external" ? (0, panel_1.renderLogDestination)(i, notice) : (0, panel_1.renderLogDiagnostic)(i, notice);
        }
        return (0, panel_1.renderLogHome)(i);
    } };
