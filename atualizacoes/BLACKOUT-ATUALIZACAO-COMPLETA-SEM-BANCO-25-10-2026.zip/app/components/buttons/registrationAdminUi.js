"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const prisma_1 = require("../../database/prisma");
const registration_1 = require("../../utils/registration");
const registrationAdmin_1 = require("../../utils/registrationAdmin");
const permissions_1 = require("../../utils/permissions");
const panelInteraction_1 = require("../../utils/panelInteraction");
const component = { customId: 'registration-ui:', async execute(i) {
        if (!i.guild || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return;
        const action = i.customId.slice('registration-ui:'.length), c = await (0, registration_1.regConfig)(i.guild.id);
        if (action.startsWith('page-edit:')) {
            const p = await prisma_1.prisma.registrationPage.findFirst({ where: { id: action.slice(10), guildId: i.guild.id } });
            if (!p)
                return;
            const input = (id, label, value, required = true) => new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId(id).setLabel(label).setValue(value).setMaxLength(id === 'description' ? 2000 : 256).setStyle(id === 'description' ? discord_js_1.TextInputStyle.Paragraph : discord_js_1.TextInputStyle.Short).setRequired(required));
            return i.showModal(new discord_js_1.ModalBuilder().setCustomId(`adm-reg-page:${p.id}`).setTitle('Editar pergunta').addComponents(input('name', 'Nome da página', p.name), input('question', 'Pergunta', p.question), input('description', 'Descrição opcional', p.description || '', false), input('max', 'Máximo de escolhas · 1 a 20', String(p.maxChoices)), input('required', 'Resposta obrigatória? SIM ou NÃO', p.required ? 'SIM' : 'NÃO')));
        }
        if (action.startsWith('page-up:') || action.startsWith('page-down:')) {
            const [direction, id] = action.split(':'), pages = await prisma_1.prisma.registrationPage.findMany({ where: { guildId: i.guild.id }, orderBy: { order: 'asc' } }), index = pages.findIndex(p => p.id === id), target = index + (direction === 'page-up' ? -1 : 1);
            if (index < 0 || target < 0 || target >= pages.length)
                return;
            await (0, panelInteraction_1.deferPanel)(i);
            const p = pages[index], other = pages[target], sourceOrder = p.order, targetOrder = other.order, temporary = Math.max(...pages.map(x => x.order)) + 1;
            await prisma_1.prisma.$transaction(async (tx) => { await tx.registrationPage.update({ where: { id: p.id }, data: { order: temporary } }); await tx.registrationPage.update({ where: { id: other.id }, data: { order: sourceOrder } }); await tx.registrationPage.update({ where: { id: p.id }, data: { order: targetOrder } }); });
            return (0, panelInteraction_1.refreshPanel)(i, await require('../../utils/registrationPageAdmin').registrationPageManagerPayload(i.guild, p.id));
        }
        if (action === 'toggle') {
            const pages = await prisma_1.prisma.registrationPage.findMany({ where: { guildId: i.guild.id } });
            if (!c.enabled && (0, registrationAdmin_1.registrationIssues)(c, pages).length)
                return i.reply({ content: 'Revise as pendências antes de ativar. Use Resolver pendências na visão geral.', ephemeral: true });
            await (0, panelInteraction_1.deferPanel)(i);
            await prisma_1.prisma.registrationConfig.update({ where: { guildId: i.guild.id }, data: { enabled: !c.enabled } });
            return (0, registrationAdmin_1.renderRegistrationAdmin)(i);
        }
        if (action === 'external') {
            if (!c.externalEnabled && (!c.externalGuildId || !c.externalChannelId))
                return i.reply({ content: 'Configure o servidor e o canal externo antes de ativar o envio.', ephemeral: true });
            await (0, panelInteraction_1.deferPanel)(i);
            await prisma_1.prisma.registrationConfig.update({ where: { guildId: i.guild.id }, data: { externalEnabled: !c.externalEnabled } });
            return (0, registrationAdmin_1.renderRegistrationAdmin)(i, 'logs');
        }
        const views = ['home', 'pending', 'messages', 'team', 'logs', 'roles', 'tools', 'publication', 'internal', 'preview-panel', 'preview-internal', 'welcome'];
        if (views.includes(action)) {
            await (0, panelInteraction_1.deferPanel)(i);
            return (0, registrationAdmin_1.renderRegistrationAdmin)(i, action);
        }
    } };
exports.default = component;
