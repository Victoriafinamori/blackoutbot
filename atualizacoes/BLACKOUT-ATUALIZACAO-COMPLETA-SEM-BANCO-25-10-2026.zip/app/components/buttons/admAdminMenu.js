"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SYSTEM_ROLE_LABELS = exports.PERMISSION_LABELS = void 0;
exports.renderAdminMenu = renderAdminMenu;
exports.renderBotAdmin = renderBotAdmin;
exports.renderPermRolesMenu = renderPermRolesMenu;
exports.renderPermRoleType = renderPermRoleType;
exports.renderSysRolesMenu = renderSysRolesMenu;
exports.renderSysRoleType = renderSysRoleType;
const discord_js_1 = require("discord.js");
const prisma_1 = require("../../database/prisma");
const permissions_1 = require("../../utils/permissions");
const adminUi_1 = require("../../utils/adminUi");
const panelInteraction_1 = require("../../utils/panelInteraction");
const teamRoles_1 = require("../../utils/teamRoles");
const admPanel_1 = require("../../utils/admPanel");
exports.PERMISSION_LABELS = {
    STAGE_MANAGER: { label: "Gerenciar etapas", description: "Passar ou regredir membros de etapa" },
    REINTEGRATION_GRANTER: { label: "Conceder reintegração", description: "Conceder o cargo de reintegração" },
    MOVCALL_COMMANDS: { label: "Consultas de call", description: "Consultar tempo, informações e ranking de call de outros membros" }
};
exports.SYSTEM_ROLE_LABELS = { STAGE_1: "Etapa 1", STAGE_2: "Etapa 2", STAGE_3: "Etapa 3", BLACKLIST: "Blacklist", MUTED: "Mutado", SUSPENDED: "Suspenso", STAFF: "Staff", OBSERVATION: "Observação" };
const back = (id) => new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId(id).setLabel("Voltar").setStyle(discord_js_1.ButtonStyle.Secondary));
async function show(i, embed, components) { return (0, panelInteraction_1.refreshPanel)(i, { content: null, attachments: [], embeds: [embed], components, allowedMentions: { parse: [] } }); }
async function renderAdminMenu(i) {
    const [admins, permissions, roles] = await Promise.all([prisma_1.prisma.botAdmin.findMany({ where: { guildId: i.guild.id } }), prisma_1.prisma.permissionRole.findMany({ where: { guildId: i.guild.id } }), prisma_1.prisma.systemRole.findMany({ where: { guildId: i.guild.id } })]);
    const modules = [{ value: "botadmin", label: "Administradores do bot", description: "Cargos com acesso total ao painel /adm" }, { value: "permroles", label: "Permissões por função", description: "Ações específicas de etapas, reintegração e call" }, { value: "sysroles", label: "Cargos usados pelo bot", description: "Associações de etapas, restrições e equipe" }];
    const embed = (0, adminUi_1.adminEmbed)(i.guild, "seguranca").setTitle("Equipe e permissões").setDescription("Defina quem administra o bot e os cargos usados no funcionamento. Associar um cargo do sistema não concede acesso ao painel.")
        .addFields({ name: "Administradores do bot", value: (0, teamRoles_1.roleSummary)(i.guild, admins.map(r => r.roleId)) }, { name: "Permissões por função", value: `${permissions.length} associações de acesso específico.` }, { name: "Cargos usados pelo bot", value: `${roles.length}/8 funções configuradas.` });
    return show(i, embed, [new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.StringSelectMenuBuilder().setCustomId("adm-admin-select").setPlaceholder("Escolha o tipo de configuração").addOptions(modules)), back("adm-nav:seguranca")]);
}
async function rolePicker(i, title, description, ids, customId, backId, single = false, notice) {
    const embed = (0, adminUi_1.adminEmbed)(i.guild, "seguranca").setTitle(title).setDescription(description).addFields({ name: "Cargos atuais", value: (0, teamRoles_1.roleSummary)(i.guild, ids, single) });
    if (notice)
        embed.addFields({ name: "Resultado", value: notice });
    const select = new discord_js_1.RoleSelectMenuBuilder().setCustomId(customId).setPlaceholder("Selecione os cargos; vazio para remover").setMinValues(0).setMaxValues(single ? 1 : 25);
    const existing = ids.filter(id => i.guild.roles.cache.has(id)).slice(0, single ? 1 : 25);
    if (existing.length)
        select.setDefaultRoles(existing);
    return show(i, embed, [new discord_js_1.ActionRowBuilder().addComponents(select), back(backId)]);
}
async function renderBotAdmin(i, notice) {
    const current = await prisma_1.prisma.botAdmin.findMany({ where: { guildId: i.guild.id } });
    return rolePicker(i, "Administradores do bot", "Acesso total ao /adm neste servidor. A seleção é salva automaticamente. Membros com Administrador no Discord continuam com acesso.", current.map(r => r.roleId), "adm-role-select:botadmin", "adm-adm:menu", false, notice);
}
async function renderPermRolesMenu(i) {
    const current = await prisma_1.prisma.permissionRole.findMany({ where: { guildId: i.guild.id } });
    const embed = (0, adminUi_1.adminEmbed)(i.guild, "seguranca").setTitle("Permissões por função").setDescription("Selecione a ação e depois os cargos autorizados. Administradores do bot já têm acesso a essas ações.")
        .addFields(Object.entries(exports.PERMISSION_LABELS).map(([type, v]) => ({ name: v.label, value: `${v.description}\n${(0, teamRoles_1.roleSummary)(i.guild, current.filter(r => r.type === type).map(r => r.roleId))}`.slice(0, 1024) })));
    return show(i, embed, [new discord_js_1.ActionRowBuilder().addComponents(Object.entries(exports.PERMISSION_LABELS).map(([type, v]) => new discord_js_1.ButtonBuilder().setCustomId(`adm-adm:permroles:${type}`).setLabel(v.label).setStyle(discord_js_1.ButtonStyle.Secondary))), back("adm-adm:menu")]);
}
async function renderPermRoleType(i, type, notice) {
    const info = exports.PERMISSION_LABELS[type];
    if (!info)
        return renderPermRolesMenu(i);
    const current = await prisma_1.prisma.permissionRole.findMany({ where: { guildId: i.guild.id, type } });
    return rolePicker(i, info.label, `${info.description}. A seleção é salva automaticamente; não concede acesso total ao painel.`, current.map(r => r.roleId), `adm-role-select:permrole:${type}`, "adm-adm:permroles", false, notice);
}
async function renderSysRolesMenu(i) {
    const current = await prisma_1.prisma.systemRole.findMany({ where: { guildId: i.guild.id } });
    const embed = (0, adminUi_1.adminEmbed)(i.guild, "seguranca").setTitle("Cargos usados pelo bot").setDescription("Cada função utiliza um cargo do servidor. Essa associação não concede acesso ao /adm.")
        .addFields(Object.entries(exports.SYSTEM_ROLE_LABELS).map(([type, label]) => ({ name: label, value: (0, teamRoles_1.roleSummary)(i.guild, current.filter(r => r.type === type).map(r => r.roleId), true) })));
    const select = new discord_js_1.StringSelectMenuBuilder().setCustomId("adm-sysrole-select").setPlaceholder("Escolha uma função do sistema").addOptions(Object.entries(exports.SYSTEM_ROLE_LABELS).map(([value, label]) => ({ value, label })));
    return show(i, embed, [new discord_js_1.ActionRowBuilder().addComponents(select), back("adm-adm:menu")]);
}
async function renderSysRoleType(i, type, notice) {
    if (!exports.SYSTEM_ROLE_LABELS[type])
        return renderSysRolesMenu(i);
    const current = await prisma_1.prisma.systemRole.findUnique({ where: { guildId_type: { guildId: i.guild.id, type } } });
    return rolePicker(i, exports.SYSTEM_ROLE_LABELS[type], "Escolha um cargo que o bot possa atribuir. Vazio remove a associação. A seleção é salva automaticamente.", current ? [current.roleId] : [], `adm-role-select:sysrole:${type}`, "adm-adm:sysroles", true, notice);
}
exports.default = { customId: "adm-adm:", async execute(i) {
        if (!i.guild)
            return;
        if (!await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return i.reply({ content: "Você não possui permissão neste servidor.", ephemeral: true });
        const [, action, sub] = i.customId.split(":");
        await (0, panelInteraction_1.deferPanel)(i);
        if (action === "root")
            return (0, panelInteraction_1.refreshPanel)(i, await (0, admPanel_1.buildAdmRootPanel)(i.guild, i.user));
        if (action === "botadmin")
            return renderBotAdmin(i);
        if (action === "permroles")
            return sub ? renderPermRoleType(i, sub) : renderPermRolesMenu(i);
        if (action === "sysroles")
            return sub ? renderSysRoleType(i, sub) : renderSysRolesMenu(i);
        return renderAdminMenu(i);
    } };
