"use strict";
const { prepareAdminPanel } = require("../../utils/adminTasks");
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderFreeFireMenu = renderFreeFireMenu;
exports.renderFreeFireStatus = renderFreeFireStatus;
exports.renderFreeFireChannels = renderFreeFireChannels;
exports.renderFreeFirePanels = renderFreeFirePanels;
exports.renderFreeFireList = renderFreeFireList;
exports.buildFreeFireRulesModal = buildFreeFireRulesModal;
const discord_js_1 = require("discord.js");
const adminUi_1 = require("../../utils/adminUi");
const permissions_1 = require("../../utils/permissions");
const admEmojis_1 = require("../../utils/admEmojis");
const service_1 = require("../../ff/service");
const views_1 = require("../../ff/views");
const RED = 0xd71935;
const yesNo = (value) => (value ? "Sim" : "Não");
const button = (customId, label, style = discord_js_1.ButtonStyle.Secondary) => new discord_js_1.ButtonBuilder().setCustomId(customId).setLabel(label).setStyle(style);
function nav(customId, placeholder, options) {
    return new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.StringSelectMenuBuilder().setCustomId(customId).setPlaceholder(placeholder).addOptions(options));
}
// -----------------------------------------------------------------------
// Tela principal — "Configurações do Free Fire"
// -----------------------------------------------------------------------
async function renderFreeFireMenu(interaction) {
    const icon = (0, admEmojis_1.admEmoji)(interaction.guild, "campeonatos");
    const c = await (0, service_1.getFFConfig)(interaction.guild.id);
    const active = await (0, service_1.countActiveDuos)(interaction.guild.id);
    const dataHorario = c.eventDate || c.eventTime ? `${c.eventDate ?? "A definir"} às ${c.eventTime ?? "A definir"}` : "A definir";
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "staff"))
        .setColor(RED)
        .setTitle("Configurações do Free Fire")
        .addFields({
        name: "ℹ️ Informações",
        value: `Inscrições: **${c.enabled ? "Abertas" : "Fechadas"}**\n` +
            `Duplas: **${active}/${c.maxDuos}**\n` +
            `Tamanho máx. do nick: **${c.nickMaxLength} caracteres**\n` +
            `Data e horário: **${dataHorario}**\n` +
            `Canal de staff: **${c.staffChannelId ? `<#${c.staffChannelId}>` : "N/A"}**\n` +
            `Canal de logs: **${c.logChannelId ? `<#${c.logChannelId}>` : "N/A"}**\n` +
            `Painel de inscrição: **${c.panelChannelId ? `<#${c.panelChannelId}>` : "N/A"}**\n` +
            `Painel de duplas: **${c.listChannelId ? `<#${c.listChannelId}>` : "N/A"}**`,
    }, {
        name: "Observações",
        value: "1. Abra as inscrições só depois de configurar os canais.\n" +
            "2. O painel de inscrição precisa ser publicado para os membros participarem.\n" +
            "3. Novas inscrições chegam pendentes no canal de staff para aprovação.\n" +
            "4. Resetar apaga todas as duplas e reinicia a numeração (#01, #02…).",
    });
    await interaction.update(prepareAdminPanel(interaction.guild, 'freefire', { attachments: [], embeds: [embed],
        components: [
            nav("ff-admin-nav", "O que deseja configurar?", [
                { label: "Voltar", value: "back", description: "Retornar para Jogos e eventos", emoji: "↩️" },
                { label: "Abrir/Fechar inscrições", value: "status", description: "Controla se membros podem se inscrever", emoji: icon },
                { label: "Canais", value: "channels", description: "Canal de staff e de logs", emoji: icon },
                { label: "Vagas, nick e evento", value: "rules", description: "Limite de duplas, tamanho do nick, data e horário", emoji: icon },
                { label: "Painéis", value: "panels", description: "Publicar o painel de inscrição e a lista de duplas", emoji: icon },
                { label: "Duplas inscritas", value: "list", description: "Ver todas as inscrições e seus status", emoji: icon },
                { label: "Resetar tudo", value: "reset", description: "Apagar todas as duplas e reiniciar a numeração", emoji: icon },
            ]),
        ],
    }));
}
// -----------------------------------------------------------------------
// Status (abrir/fechar)
// -----------------------------------------------------------------------
async function renderFreeFireStatus(interaction) {
    const c = await (0, service_1.getFFConfig)(interaction.guild.id);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "staff"))
        .setColor(RED)
        .setTitle("Status das Inscrições")
        .setDescription("Controle se os membros podem se inscrever agora. A mudança é refletida automaticamente nos painéis publicados.")
        .addFields({ name: "Estado atual", value: `Inscrições: **${c.enabled ? "Abertas" : "Fechadas"}**` });
    await interaction.update({ attachments: [], embeds: [embed],
        components: [
            new discord_js_1.ActionRowBuilder().addComponents(button("adm-ff:toggle-status", c.enabled ? "Fechar inscrições" : "Abrir inscrições", c.enabled ? discord_js_1.ButtonStyle.Danger : discord_js_1.ButtonStyle.Success), button("adm-ff:menu", "Voltar")),
        ],
    });
}
// -----------------------------------------------------------------------
// Canais (staff e logs)
// -----------------------------------------------------------------------
async function renderFreeFireChannels(interaction) {
    const c = await (0, service_1.getFFConfig)(interaction.guild.id);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "staff"))
        .setColor(RED)
        .setTitle("Canais do Free Fire")
        .setDescription("Selecione abaixo. Uma seleção vazia remove a configuração.")
        .addFields({
        name: "Canais atuais",
        value: `Canal de staff: **${c.staffChannelId ? `<#${c.staffChannelId}>` : "N/A"}**\nCanal de logs: **${c.logChannelId ? `<#${c.logChannelId}>` : "N/A"}**`,
    });
    const staffSelect = new discord_js_1.ChannelSelectMenuBuilder().setCustomId("ff-channel:staffChannelId").setPlaceholder("Canal de staff (novas inscrições)").addChannelTypes(discord_js_1.ChannelType.GuildText).setMinValues(0).setMaxValues(1);
    const logsSelect = new discord_js_1.ChannelSelectMenuBuilder().setCustomId("ff-channel:logChannelId").setPlaceholder("Canal de logs de ações").addChannelTypes(discord_js_1.ChannelType.GuildText).setMinValues(0).setMaxValues(1);
    await interaction.update({ attachments: [], embeds: [embed],
        components: [
            new discord_js_1.ActionRowBuilder().addComponents(staffSelect),
            new discord_js_1.ActionRowBuilder().addComponents(logsSelect),
            new discord_js_1.ActionRowBuilder().addComponents(button("adm-ff:menu", "Voltar")),
        ],
    });
}
// -----------------------------------------------------------------------
// Painéis (inscrição e lista de duplas)
// -----------------------------------------------------------------------
async function renderFreeFirePanels(interaction) {
    const c = await (0, service_1.getFFConfig)(interaction.guild.id);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "staff"))
        .setColor(RED)
        .setTitle("Painéis do Free Fire")
        .setDescription("Selecione um canal para publicar (ou mover) cada painel.")
        .addFields({
        name: "Painéis atuais",
        value: `Inscrição: **${c.panelChannelId ? `<#${c.panelChannelId}>` : "N/A"}**\nLista de duplas: **${c.listChannelId ? `<#${c.listChannelId}>` : "N/A"}**`,
    });
    const registerSelect = new discord_js_1.ChannelSelectMenuBuilder().setCustomId("ff-panel-channel:register").setPlaceholder("Publicar painel de inscrição em...").addChannelTypes(discord_js_1.ChannelType.GuildText).setMinValues(1).setMaxValues(1);
    const listSelect = new discord_js_1.ChannelSelectMenuBuilder().setCustomId("ff-panel-channel:list").setPlaceholder("Publicar lista de duplas em...").addChannelTypes(discord_js_1.ChannelType.GuildText).setMinValues(1).setMaxValues(1);
    await interaction.update({ attachments: [], embeds: [embed],
        components: [
            new discord_js_1.ActionRowBuilder().addComponents(registerSelect),
            new discord_js_1.ActionRowBuilder().addComponents(listSelect),
            new discord_js_1.ActionRowBuilder().addComponents(button("adm-ff:menu", "Voltar")),
        ],
    });
}
// -----------------------------------------------------------------------
// Lista de duplas
// -----------------------------------------------------------------------
async function renderFreeFireList(interaction) {
    const duos = await (0, service_1.listDuos)(interaction.guild.id);
    const embed = (await (0, adminUi_1.adminEmbed)(interaction.guild, "staff")).setColor(RED).setTitle("Duplas Inscritas");
    if (duos.length === 0) {
        embed.setDescription("Nenhuma inscrição registrada ainda.");
    }
    else {
        const lines = duos.map((d) => `**DUO #${String(d.number).padStart(2, "0")}** — ${d.player1Nick} (${d.player1GameId}) + ${d.player2Nick} (${d.player2GameId}) — ${(0, views_1.statusLabel)(d.status)}`);
        embed.setDescription(lines.join("\n").slice(0, 3900));
    }
    await interaction.update({ attachments: [], embeds: [embed], components: [new discord_js_1.ActionRowBuilder().addComponents(button("adm-ff:menu", "Voltar"))] });
}
// -----------------------------------------------------------------------
// Modal — vagas, tamanho do nick, data e horário do evento
// -----------------------------------------------------------------------
function buildFreeFireRulesModal(c) {
    const field = (id, label, value, required = true) => new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId(id).setLabel(label).setStyle(discord_js_1.TextInputStyle.Short).setRequired(required).setValue(value));
    return new discord_js_1.ModalBuilder()
        .setCustomId("ff-admin-modal:rules")
        .setTitle("Vagas, nick e evento")
        .addComponents(field("maxDuos", "Limite de duplas (número)", String(c.maxDuos)), field("nickMaxLength", "Tamanho máx. do nick (número)", String(c.nickMaxLength)), field("eventDate", "Data do evento (ex: 20/09/2026)", c.eventDate ?? "", false), field("eventTime", "Horário do evento (ex: 20:00)", c.eventTime ?? "", false));
}
// -----------------------------------------------------------------------
// Botões: adm-ff:<ação>
// -----------------------------------------------------------------------
const component = {
    customId: "adm-ff:",
    async execute(interaction) {
        if (!interaction.guild || !(await (0, permissions_1.isBotAdmin)(await interaction.guild.members.fetch(interaction.user.id)))) {
            await interaction.reply({ content: "🚫 Sem permissão.", ephemeral: true });
            return;
        }
        const [, action] = interaction.customId.split(":");
        if (action === "menu")
            return renderFreeFireMenu(interaction);
        if (action === "status")
            return renderFreeFireStatus(interaction);
        if (action === "toggle-status") {
            const c = await (0, service_1.getFFConfig)(interaction.guild.id);
            await (0, service_1.updateFFConfig)(interaction.guild.id, { enabled: !c.enabled });
            await (0, views_1.refreshFFPanels)(interaction.guild);
            return renderFreeFireStatus(interaction);
        }
        if (action === "reset-confirm") {
            await (0, service_1.resetTournament)(interaction.guild.id);
            await (0, views_1.refreshFFPanels)(interaction.guild);
            return renderFreeFireMenu(interaction);
        }
    },
};
exports.default = component;
//# sourceMappingURL=admFreeFireMenu.js.map