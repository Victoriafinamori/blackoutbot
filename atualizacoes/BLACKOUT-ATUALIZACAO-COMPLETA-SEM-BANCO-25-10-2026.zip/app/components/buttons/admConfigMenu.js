"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderConfigMenu = renderConfigMenu;
exports.renderConfigDestination = renderConfigDestination;
exports.buildAppearancePayload = buildAppearancePayload;
exports.renderAppearanceMenu = renderAppearanceMenu;
exports.buildDefaultPatternPayload = buildDefaultPatternPayload;
exports.renderDefaultPattern = renderDefaultPattern;
exports.renderAutoRoleMenu = renderAutoRoleMenu;
const discord_js_1 = require("discord.js");
const permissions_1 = require("../../utils/permissions");
const adminUi_1 = require("../../utils/adminUi");
const guildConfig_1 = require("../../database/guildConfig");
const prisma_1 = require("../../database/prisma");
const adminLog_1 = require("../../utils/adminLog");
const enums_1 = require("../../structures/enums");
const admPanel_1 = require("../../utils/admPanel");
const configurationChecks_1 = require("../../utils/configurationChecks");
const panelInteraction_1 = require("../../utils/panelInteraction");
const customEmbeds_1 = require("../../utils/customEmbeds");
const admEmbedV2Menu_1 = require("./admEmbedV2Menu");
const admLogsMenu_1 = require("./admLogsMenu");
const admNotifications_1 = require("./admNotifications");
const button = (id, label, style = discord_js_1.ButtonStyle.Secondary) => new discord_js_1.ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style);
const row = (...items) => new discord_js_1.ActionRowBuilder().addComponents(items);
async function renderConfigMenu(interaction) {
    return (0, panelInteraction_1.refreshPanel)(interaction, await (0, admPanel_1.buildAdmSectionPanel)(interaction.guild, "sistema"));
}
async function renderConfigDestination(interaction, action) {
    switch (action) {
        case "aparencia": return renderAppearanceMenu(interaction);
        case "padrao": return renderDefaultPattern(interaction);
        case "embeds": return (0, admEmbedV2Menu_1.renderEmbedHub)(interaction);
        case "autocargo": return require("../../message-maker/navigation").automations(interaction);
        // Existing messages still resolve to the new owners of these settings.
        case "canais": return (0, admLogsMenu_1.renderLogsMenu)(interaction);
        case "notificacoes": return (0, admNotifications_1.renderNotificationPanel)(interaction, "moderacao");
        default: return renderConfigMenu(interaction);
    }
}
async function buildAppearancePayload(guild, _requesterId, updatedMember) {
    const me = updatedMember ?? await guild.members.fetchMe({ force: true });
    const bot = guild.client.user;
    const name = me?.displayName || bot?.username || "Bot";
    const avatar = me?.displayAvatarURL?.({ size: 256 }) || bot?.displayAvatarURL({ size: 256 });
    const banner = me?.displayBannerURL?.({ size: 1024 }) || null;
    const embed = new discord_js_1.EmbedBuilder().setColor(0xd71935).setTitle(name.slice(0, 256))
        .setDescription(`Perfil do bot em **${guild.name}**.\nNome, avatar e banner são personalizados somente nesta comunidade.`)
        .setFooter({ text: "Perfil neste servidor · Atualizado ao salvar" });
    embed.setAuthor({ name: name.slice(0, 256), ...(avatar ? { iconURL: avatar } : {}) });
    if (avatar)
        embed.setThumbnail(avatar);
    if (banner)
        embed.setImage(banner);
    return { content: "**Personalização do bot · Perfil neste servidor**", attachments: [], embeds: [embed],
        components: [row(button("appearance-edit:nickname", "Editar nome"), button("appearance-edit:avatar", "Editar avatar"), button("appearance-edit:banner", "Editar banner")), row(button("adm-cfg:menu", "Voltar"))], allowedMentions: { parse: [] } };
}
async function renderAppearanceMenu(interaction) {
    await (0, panelInteraction_1.deferPanel)(interaction);
    return (0, panelInteraction_1.refreshPanel)(interaction, await buildAppearancePayload(interaction.guild, interaction.user.id));
}
async function buildDefaultPatternPayload(guild) {
    const config = await (0, guildConfig_1.getOrCreateGuildConfig)(guild.id);
    const embed = new discord_js_1.EmbedBuilder().setColor(`#${(0, customEmbeds_1.normalizeHex)(config.embedColor, "D71935")}`)
        .setTitle("Prévia do padrão das mensagens").setDescription("As mensagens que usam o padrão deste servidor seguem esta cor, autor, miniatura e rodapé.\n\nOs modelos personalizados podem ter seu próprio visual.");
    if (config.embedAuthor)
        embed.setAuthor({ name: config.embedAuthor });
    if (config.embedFooter)
        embed.setFooter({ text: config.embedFooter });
    if (config.embedThumbnail)
        embed.setThumbnail(config.embedThumbnail);
    return { content: "**Personalização do bot · Padrão das mensagens**\nAs alterações salvas aparecem nesta mesma embed. Os menus administrativos mantêm a identidade BLACKOUT.", attachments: [], embeds: [embed],
        components: [row(button("adm-cfg:embeds-default", "Editar padrão", discord_js_1.ButtonStyle.Primary)), row(button("adm-cfg:menu", "Voltar"))], allowedMentions: { parse: [] } };
}
async function renderDefaultPattern(interaction) {
    return (0, panelInteraction_1.refreshPanel)(interaction, await buildDefaultPatternPayload(interaction.guild));
}
async function openEmbedModal(interaction) {
    const config = await (0, guildConfig_1.getOrCreateGuildConfig)(interaction.guild.id);
    const input = (id, label, value, max, required = false) => {
        const field = new discord_js_1.TextInputBuilder().setCustomId(id).setLabel(label).setStyle(discord_js_1.TextInputStyle.Short).setRequired(required).setMaxLength(max);
        if (value)
            field.setValue(value);
        return new discord_js_1.ActionRowBuilder().addComponents(field);
    };
    await interaction.showModal(new discord_js_1.ModalBuilder().setCustomId("adm-modal:embed").setTitle("Padrão das mensagens").addComponents(input("embedColor", "Cor hexadecimal", (0, customEmbeds_1.normalizeHex)(config.embedColor, "D71935"), 7, true), input("embedAuthor", "Autor — vazio para remover", config.embedAuthor, 256), input("embedFooter", "Rodapé — vazio para remover", config.embedFooter, 1000), input("embedThumbnail", "URL da miniatura — vazio para remover", config.embedThumbnail, 500)));
}
async function renderAutoRoleMenu(interaction, notice) {
    const guild = interaction.guild;
    const config = await (0, guildConfig_1.getOrCreateGuildConfig)(guild.id);
    const ids = (config.autoRoleIds ?? "").split(",").map((id) => id.trim()).filter(Boolean);
    const issues = (0, configurationChecks_1.autoRoleIssues)(guild, ids);
    const me = guild.members.me ?? await guild.members.fetchMe();
    const canManage = me?.permissions?.has(discord_js_1.PermissionFlagsBits.ManageRoles) ?? false;
    const embed = (0, adminUi_1.adminEmbed)(guild, "membros").setTitle("Cargos e automações")
        .setDescription("Escolha os cargos atribuídos aos novos membros. Alterar a lista não modifica quem já está no servidor.")
        .addFields({ name: "Estado atual", value: config.autoRoleEnabled ? "Ativado" : "Desativado", inline: true }, { name: "Cargos selecionados", value: ids.map((id) => guild.roles.cache.has(id) ? `<@&${id}>` : "Cargo removido").join(", ") || "Nenhum cargo selecionado." });
    if (issues.length || !canManage)
        embed.addFields({ name: "Ajustes necessários", value: [...(!canManage ? ["O bot precisa da permissão Gerenciar Cargos."] : []), ...issues].join("\n").slice(0, 1024) });
    if (notice)
        embed.addFields({ name: "Resultado", value: notice.slice(0, 1024) });
    const select = new discord_js_1.RoleSelectMenuBuilder().setCustomId("auto-role-select:roles").setPlaceholder("Selecionar cargos de entrada").setMinValues(0).setMaxValues(10);
    const existing = ids.filter((id) => guild.roles.cache.has(id));
    if (existing.length)
        select.setDefaultRoles(existing);
    return (0, panelInteraction_1.refreshPanel)(interaction, { content: null, attachments: [], embeds: [embed], components: [new discord_js_1.ActionRowBuilder().addComponents(select),
            row(button("adm-cfg:autocargo-toggle", config.autoRoleEnabled ? "Desativar" : "Ativar cargos automáticos", config.autoRoleEnabled ? discord_js_1.ButtonStyle.Secondary : discord_js_1.ButtonStyle.Primary).setDisabled(!config.autoRoleEnabled && (!ids.length || !!issues.length || !canManage)), button("adm-cfg:autocargo-clear", "Limpar seleção").setDisabled(!ids.length)),
            row(button("adm-roletransfer:menu", "Transferência programada"), button("maker:r-home:0", "Cargos por reação")), row(button("adm-nav:membros", "Voltar"))] });
}
async function updateAutoRole(interaction, action) {
    const config = await (0, guildConfig_1.getOrCreateGuildConfig)(interaction.guild.id);
    const ids = (config.autoRoleIds ?? "").split(",").filter(Boolean);
    if (action === "toggle" && !config.autoRoleEnabled) {
        const me = interaction.guild.members.me ?? await interaction.guild.members.fetchMe();
        if (!ids.length || (0, configurationChecks_1.autoRoleIssues)(interaction.guild, ids).length || !me.permissions.has(discord_js_1.PermissionFlagsBits.ManageRoles))
            return renderAutoRoleMenu(interaction, "Revise os cargos e as permissões antes de ativar.");
    }
    await (0, panelInteraction_1.deferPanel)(interaction);
    await prisma_1.prisma.guildConfig.update({ where: { guildId: interaction.guild.id }, data: action === "clear" ? { autoRoleIds: null, autoRoleEnabled: false } : { autoRoleEnabled: !config.autoRoleEnabled } });
    await (0, adminLog_1.logAdminAction)({ guild: interaction.guild, actorId: interaction.user.id, action: enums_1.AdminLogAction.CONFIG_CHANGED, details: action === "clear" ? "Cargos automáticos: seleção limpa e sistema desativado" : `Cargos automáticos: ${config.autoRoleEnabled ? "desativado" : "ativado"}` });
    return renderAutoRoleMenu(interaction, "Alteração salva neste servidor.");
}
const component = { customId: "adm-cfg:", async execute(i) {
        if (!i.guild)
            return;
        if (!await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return void await i.reply({ content: "Você não possui permissão para alterar estas configurações.", ephemeral: true });
        const [, action, sub] = i.customId.split(":");
        if (action === "embeds-default")
            return openEmbedModal(i);
        if (action === "autocargo-toggle")
            return updateAutoRole(i, "toggle");
        if (action === "autocargo-clear")
            return updateAutoRole(i, "clear");
        if (action === "canal")
            return sub === "reports" ? (0, admNotifications_1.renderNotificationPanel)(i, "moderacao") : (0, admLogsMenu_1.renderLogChannelPicker)(i, sub === "log" ? "geral" : sub);
        return renderConfigDestination(i, action);
    } };
exports.default = component;
