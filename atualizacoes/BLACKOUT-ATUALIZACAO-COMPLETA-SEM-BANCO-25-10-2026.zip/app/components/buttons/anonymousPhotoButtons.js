"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const prisma_1 = require("../../database/prisma");
const service_1 = require("../../submundo/service");
const component = { customId: "anonymous-photo:", async execute(i) {
    if (!i.guild) return;
    const action = i.customId.split(":")[1];
    const config = await (0, service_1.getAnonymousPhotoConfig)(i.guild.id);
    if (action === "open") {
        if (!config.enabled || !config.destinationChannelId || !config.logChannelId || !await (0, service_1.isSubmundoOpen)(config))
            return void await i.reply({ content: "O Submundo está fechado ou indisponível no momento.", flags: discord_js_1.MessageFlags.Ephemeral });
        const upload = new discord_js_1.FileUploadBuilder().setCustomId("media").setMinValues(1).setMaxValues(1).setRequired(true);
        const modal = new discord_js_1.ModalBuilder().setCustomId("anonymous-photo-upload").setTitle("Enviar foto/vídeo anônimo")
            .addLabelComponents(new discord_js_1.LabelBuilder().setLabel("Foto ou vídeo").setDescription("Envie uma imagem ou vídeo compatível com o Discord.").setFileUploadComponent(upload));
        return void await i.showModal(modal);
    }
    if (action === "cancel") {
        service_1.anonymousMediaDrafts.delete((0, service_1.anonymousMediaDraftKey)(i.guild.id, i.user.id));
        return void await i.update({ content: "Envio cancelado. Nenhuma mídia foi publicada.", embeds: [], components: [] });
    }
    if (action !== "confirm") return;
    const key = (0, service_1.anonymousMediaDraftKey)(i.guild.id, i.user.id);
    const draft = service_1.anonymousMediaDrafts.get(key);
    if (!draft || draft.expiresAt < Date.now()) {
        service_1.anonymousMediaDrafts.delete(key);
        return void await i.reply({ content: "O envio expirou. Abra o formulário novamente.", flags: discord_js_1.MessageFlags.Ephemeral });
    }
    service_1.anonymousMediaDrafts.delete(key);
    await i.deferReply({ flags: discord_js_1.MessageFlags.Ephemeral });
    const current = await (0, service_1.getAnonymousPhotoConfig)(i.guild.id);
    const destination = await (0, service_1.resolveTextChannel)(i.guild, current.destinationChannelId);
    if (!current.enabled || !destination || !await (0, service_1.isSubmundoOpen)(current))
        return void await i.editReply("O Submundo fechou antes da confirmação. Nada foi publicado.");
    try {
        const extension=require('../../social-experience/anonymous');
        const queued=await extension.enqueue(i.guild,i.user.id,'ANON_MEDIA',draft);
        if(queued)return void await i.editReply('Envio recebido para revisão privada da equipe. Você será avisado sobre a decisão.');
        const record=await extension.publish(i.guild,i.user.id,'ANON_MEDIA',draft);
        return void await i.editReply('Mídia publicada anonimamente. ID: '+record.publicId);
    }catch(error){return void await i.editReply(error.message||'Não foi possível publicar. Tente novamente.');}

} };
exports.default = component;
