"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const permissions_1 = require("../../utils/permissions");
const prisma_1 = require("../../database/prisma");
const service_1 = require("../../memberRise/service");
const panel_1 = require("../../memberRise/panel");
const admPanel_1 = require("../../utils/admPanel");
const field = (id, label, value, style = discord_js_1.TextInputStyle.Short) => new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId(id).setLabel(label).setStyle(style).setValue(value.slice(0, style === discord_js_1.TextInputStyle.Paragraph ? 4000 : 100)).setRequired(true));
const component = { customId: "member-rise:", async execute(i) {
        if (!i.guild || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
            return void await i.reply({ content: "Sem permissão.", ephemeral: true });
        const [, action, arg] = i.customId.split(":");
        if (action === "back")
            return void await i.update(await (0, admPanel_1.buildAdmSectionPanel)(i.guild, "membros"));
        const s = await (0, service_1.stage)(i.guild.id);
        if (action === "toggle") {
            if (!s.enabled) {
                const issue = (0, service_1.roleProblem)(i.guild, s);
                if (issue)
                    return void await i.reply({ content: issue, ephemeral: true });
                if (!s.messageEnabled && !s.voiceEnabled)
                    return void await i.reply({ content: "Ative ao menos um requisito.", ephemeral: true });
            }
            await prisma_1.prisma.memberRiseStage.update({ where: { id: s.id }, data: { enabled: !s.enabled } });
            if (s.enabled)
                await prisma_1.prisma.memberRiseProgress.updateMany({ where: { stageId: s.id, status: "ACTIVE" }, data: { voiceChannelId: null, voiceCheckedAt: null } });
            return (0, panel_1.renderMemberRise)(i);
        }
        if (action === "roles") return (0, panel_1.renderMemberRise)(i,"roles");
        if (action === "requirements")
            return void await i.showModal(new discord_js_1.ModalBuilder().setCustomId("member-rise-modal:requirements").setTitle("Requisitos").addComponents(field("messages", "Mensagens (0 desativa)", s.messageEnabled ? String(s.minMessages) : "0"), field("hours", "Horas de call (0 desativa)", s.voiceEnabled ? String(Math.floor(s.minVoiceSeconds / 3600)) : "0"), field("minutes", "Minutos adicionais", String(Math.floor(s.minVoiceSeconds % 3600 / 60))), field("mode", "Modo: TODOS ou QUALQUER UM", s.requirementMode === "ALL" ? "TODOS" : "QUALQUER UM"), field("interval", "Intervalo entre mensagens (segundos)", String(s.messageIntervalSeconds))));
        if (action === "voice")
            return void await i.showModal(new discord_js_1.ModalBuilder().setCustomId("member-rise-modal:voice").setTitle("Regras de call").addComponents(field("people", "Mínimo de pessoas", String(s.minVoicePeople)), field("afk", "Ignorar AFK? SIM ou NÃO", s.ignoreAfk ? "SIM" : "NÃO"), field("muted", "Contar mutado? SIM ou NÃO", s.countMuted ? "SIM" : "NÃO"), field("deaf", "Contar ensurdecido? SIM ou NÃO", s.countDeafened ? "SIM" : "NÃO")));
        if (action === "messages")
            return void await i.showModal(new discord_js_1.ModalBuilder().setCustomId("member-rise-modal:messages").setTitle("Mensagens e automação").addComponents(field("public", "Mensagem pública", s.publicMessage, discord_js_1.TextInputStyle.Paragraph), field("dm", "Mensagem privada", s.dmMessage, discord_js_1.TextInputStyle.Paragraph)));
        if (action === "search")
            return void await i.showModal(new discord_js_1.ModalBuilder().setCustomId("member-rise-modal:search").setTitle("Buscar membro").addComponents(field("member", "ID ou menção do membro", " ")));
        if (action === "progress")
            return (0, panel_1.renderMemberRise)(i, "progress", Number(arg) || 0);
        if (action === "history")
            return (0, panel_1.renderMemberRise)(i, "history", Number(arg) || 0);
        if (action === "home")
            return (0, panel_1.renderMemberRise)(i);
        if (action === "preview")
            return (0, panel_1.renderMemberRise)(i, "preview");
        if (action === "detail")
            return (0, panel_1.renderMemberRise)(i, "detail", 0, arg);
        if (action === "confirm-promote" || action === "confirm-reset")
            return (0, panel_1.renderMemberRise)(i, "confirm", 0, `${action.slice(8)}:${arg}`);
        if (action === "promote" && arg) {
            await i.deferUpdate();
            await (0, service_1.promote)(i.guild, arg, "MANUAL", i.user.id);
            return (0, panel_1.renderMemberRise)(i, "detail", 0, arg);
        }
        if (action === "reset" && arg) {
            await prisma_1.prisma.memberRiseProgress.updateMany({ where: { stageId: s.id, userId: arg }, data: { generation: { increment: 1 }, messages: 0, voiceSeconds: 0, lastMessageAt: null, voiceChannelId: null, voiceCheckedAt: null, status: "ACTIVE", promotedAt: null } });
            return (0, panel_1.renderMemberRise)(i, "detail", 0, arg);
        }
    } };
exports.default = component;
//# sourceMappingURL=memberRiseButtons.js.map