"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// @ts-nocheck
const discord_js_1 = require("discord.js");
const panelInteraction_1 = require("../../utils/panelInteraction");
const permissions_1 = require("../../utils/permissions");
const prisma_1 = require("../../database/prisma");
const admEmbedV2Menu_1 = require("./admEmbedV2Menu");
const customEmbeds_1 = require("../../utils/customEmbeds");
async function normalizePositions(embedId) {
    const items = await prisma_1.prisma.customEmbedButton.findMany({ where: { embedId }, orderBy: { position: "asc" } });
    await prisma_1.prisma.$transaction(items.map((item, i) => prisma_1.prisma.customEmbedButton.update({ where: { id: item.id }, data: { position: i } })));
}
exports.default = {
    customId: "embedv2-btn:",
    async execute(interaction) {
        if (!interaction.guild)
            return;
        const member = await interaction.guild.members.fetch(interaction.user.id);
        if (!(await (0, permissions_1.isBotAdmin)(member)))
            return interaction.reply({ content: "🚫 Sem permissão.", ephemeral: true });
        const [, action, embedId, buttonId] = interaction.customId.split(":");
        const record = await (0, customEmbeds_1.fetchCustomEmbed)(embedId, interaction.guild.id);
        const item = record?.buttons.find((b) => b.id === buttonId);
        if (!record || !item)
            return interaction.reply({ content: "❌ Botão não encontrado.", ephemeral: true });
        if (action === "delete") {
            await (0, panelInteraction_1.deferPanel)(interaction);
            await prisma_1.prisma.customEmbedButton.delete({ where: { id: buttonId } });
            await normalizePositions(embedId);
            return (0, admEmbedV2Menu_1.renderEmbedButtons)(interaction, embedId);
        }
        if (action === "left" || action === "right") {
            const index = record.buttons.findIndex((b) => b.id === buttonId);
            const targetIndex = action === "left" ? index - 1 : index + 1;
            if (targetIndex < 0 || targetIndex >= record.buttons.length)
                return (0, admEmbedV2Menu_1.renderEmbedButtons)(interaction, embedId);
            const target = record.buttons[targetIndex];
            await (0, panelInteraction_1.deferPanel)(interaction);
            await prisma_1.prisma.$transaction([
                prisma_1.prisma.customEmbedButton.update({ where: { id: item.id }, data: { position: target.position } }),
                prisma_1.prisma.customEmbedButton.update({ where: { id: target.id }, data: { position: item.position } }),
            ]);
            return (0, admEmbedV2Menu_1.renderEmbedButtons)(interaction, embedId);
        }
        if (action === "edit") {
            const modal = new discord_js_1.ModalBuilder().setCustomId(`embedv2-modal:edit-button:${embedId}:${buttonId}`).setTitle("Editar botão").addComponents(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("label").setLabel("Texto do botão").setStyle(discord_js_1.TextInputStyle.Short).setRequired(true).setMaxLength(80).setValue(item.label)), new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("emoji").setLabel("Emoji (opcional)").setStyle(discord_js_1.TextInputStyle.Short).setRequired(false).setMaxLength(50).setValue(item.emoji || "")));
            if (item.type === "LINK")
                modal.addComponents(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("url").setLabel("Link (https://...)").setStyle(discord_js_1.TextInputStyle.Short).setRequired(true).setMaxLength(500).setValue(item.url || "")));
            return interaction.showModal(modal);
        }
    },
};
