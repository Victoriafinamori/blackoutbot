"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const hub_1 = require("../../games-chat/experience/hub");
exports.default = { customId: "games-admin:", execute: hub_1.admin };
