"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const permissions_1 = require("../../utils/permissions");
const registration_1 = require("../../utils/registration");
const registrationPanelEditor_1 = require("../../utils/registrationPanelEditor");
const component = { customId: "registration-panel-editor:", async execute(i) {
        if (!i.guild || !(await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id))))
            return;
        const action = i.customId.split(":")[1];
        if (action === "color") {
            const c = await (0, registration_1.regConfig)(i.guild.id);
            const modal = new discord_js_1.ModalBuilder().setCustomId("registration-panel-color").setTitle("Cor da embed").addComponents(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId("color").setLabel("Cor hexadecimal").setPlaceholder("Exemplo: D20B20").setValue(c.panelColor).setStyle(discord_js_1.TextInputStyle.Short).setRequired(true)));
            await i.showModal(modal);
            return;
        }
        if (action === "preview") return require("../../utils/panelInteraction").refreshPanel(i, await require("../../utils/registrationAdmin").registrationPublicPreview(i.guild));
        if (action === "save") {
            await i.deferUpdate();
            await i.editReply(await (0, registrationPanelEditor_1.registrationPanelEditor)(i.guild));
            await i.followUp({ content: "Modelo salvo. Use Publicar / atualizar para alterar a mensagem pública.", ephemeral: true });
        }
    } };
exports.default = component;
