"use strict";
exports.default = {
  customId: "sx-admin:",
  execute: (i) =>
    require("../../social-experience/interactions").adminButton(i),
};
