"use strict";
const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();
const required = ["memberRiseStage", "memberRiseProgress", "memberRiseHistory", "socialHighlight", "makerTemplate", "makerPublication", "makerSession", "makerAction", "reactionRolePanel", "reactionRoleBinding", "reactionRoleGrant", "reactionRoleOwnership", "securitySettings", "securityState", "securityIncident", "securityAuditEntry", "securityDenyEntry", "securityReview", "securityChannelLock", "securityMemberSnapshot"];
const missing = required.filter(name => !prisma[name]);
if (missing.length) {
  console.error(`[startup] Prisma Client desatualizado. Models ausentes: ${missing.join(", ")}.`);
  process.exit(1);
}
console.log("[startup] Prisma Client validado (módulos existentes + Mensagens V2, Cargos por reação e Central de segurança).");
