"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getOrCreateGuildConfig = getOrCreateGuildConfig;
const prisma_1 = require("./prisma");
/**
 * Retorna a configuração do servidor, criando uma configuração
 * padrão automaticamente caso ainda não exista.
 */
async function getOrCreateGuildConfig(guildId) {
    const existing = await prisma_1.prisma.guildConfig.findUnique({ where: { guildId } });
    if (existing)
        return existing;
    try {
        return await prisma_1.prisma.guildConfig.upsert({
            where: { guildId },
            create: { guildId },
            update: {},
        });
    }
    catch (error) {
        if (error.code === "P2002")
            return prisma_1.prisma.guildConfig.findUniqueOrThrow({ where: { guildId } });
        throw error;
    }
}
