"use strict";
const {
  prisma,
  config,
  btn,
  row,
  text,
  embed,
  payload,
  member,
} = require("./common");
async function own(guild, userId) {
  return prisma.socialProfile.upsert({
    where: { guildId_userId: { guildId: guild.id, userId } },
    create: { guildId: guild.id, userId },
    update: {},
  });
}
async function save(guild, userId, data) {
  if (!(await config(guild.id)).profilesEnabled)
    throw Error("Os perfis sociais estão desativados.");
  await member(guild, userId);
  for (const [k, limit] of [
    ["bio", 300],
    ["interests", 150],
    ["games", 150],
  ])
    if (String(data[k] || "").length > limit)
      throw Error("Um dos campos excede o tamanho permitido.");
  return prisma.socialProfile.upsert({
    where: { guildId_userId: { guildId: guild.id, userId } },
    create: { guildId: guild.id, userId, ...data },
    update: data,
  });
}
async function view(guild, userId) {
  const p = await own(guild, userId);
  return payload(
    embed(
      "Meu perfil social",
      p.visible
        ? "Seu perfil está visível somente na comunidade deste servidor."
        : "Seu perfil está oculto. Edite e escolha “Publicar perfil” para aparecer.",
    ).addFields(
      { name: "Sobre mim", value: p.bio || "Ainda não preenchido." },
      { name: "Interesses", value: p.interests || "Ainda não preenchido." },
      { name: "Jogos favoritos", value: p.games || "Ainda não preenchido." },
    ),
    [
      row(
        btn("sx:profile-edit", "Editar perfil"),
        btn(
          "sx:profile-visibility",
          p.visible ? "Ocultar perfil" : "Publicar perfil",
        ),
        btn("sx:discover:0", "Conhecer pessoas"),
        btn("sx:profile-delete", "Apagar meus dados"),
      ),
    ],
  );
}
const searches = new Map();
async function discover(guild, page = 0, query = "", searchId = "") {
  for (const [id, v] of searches)
    if (v.expires < Date.now()) searches.delete(id);
  if (searchId) {
    const search = searches.get(searchId);
    if (!search || search.guildId !== guild.id)
      throw Error("A busca expirou. Pesquise novamente.");
    query = search.query;
  } else if (query) {
    searchId = require("node:crypto").randomBytes(8).toString("hex");
    searches.set(searchId, {
      guildId: guild.id,
      query,
      expires: Date.now() + 10 * 60000,
    });
  }
  if (!(await config(guild.id)).profilesEnabled)
    throw Error("Os perfis sociais estão desativados.");
  const filter = {
      guildId: guild.id,
      visible: true,
      ...(query
        ? {
            OR: [
              { interests: { contains: query } },
              { games: { contains: query } },
            ],
          }
        : {}),
    },
    count = await prisma.socialProfile.count({ where: filter }),
    p = Math.max(
      0,
      Math.min(Number(page) || 0, Math.max(0, Math.ceil(count / 5) - 1)),
    ),
    rows = await prisma.socialProfile.findMany({
      where: filter,
      orderBy: { updatedAt: "desc" },
      skip: p * 5,
      take: 5,
    });
  return payload(
    embed(
      "Conhecer pessoas",
      rows
        .map(
          (r) =>
            `<@${r.userId}>\n${text(r.bio, 300)}\nInteresses: ${text(r.interests, 150) || "—"}\nJogos: ${text(r.games, 150) || "—"}`,
        )
        .join("\n\n") || "Nenhum perfil público encontrado.",
    ).setFooter({
      text: `Página ${p + 1} · ${count} perfis · ${query ? "Filtro: " + text(query, 60) : "Neste servidor"}`,
    }),
    [
      row(
        btn(`sx:discover:${p - 1}:${searchId}`, "Anterior", 2, p === 0),
        btn(
          `sx:discover:${p + 1}:${searchId}`,
          "Próxima",
          2,
          (p + 1) * 5 >= count,
        ),
        btn("sx:profile-search", "Buscar por interesse"),
      ),
    ],
  );
}
module.exports = { own, save, view, discover };
