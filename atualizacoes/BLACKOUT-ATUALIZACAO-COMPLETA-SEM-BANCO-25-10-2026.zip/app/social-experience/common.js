"use strict";
const D = require("discord.js"),
  { prisma } = require("../database/prisma");
const { randomUUID } = require("node:crypto");
const locks = new Map();
async function locked(key, fn) {
  if (locks.has(key))
    throw Error("Uma ação está em andamento. Aguarde alguns segundos.");
  locks.set(key, true);
  try {
    return await fn();
  } finally {
    locks.delete(key);
  }
}
const config = (guildId) =>
  prisma.socialExperienceConfig.upsert({
    where: { guildId },
    create: { guildId },
    update: {},
  });
const btn = (id, label, style = D.ButtonStyle.Secondary, disabled = false) =>
  new D.ButtonBuilder()
    .setCustomId(id)
    .setLabel(label)
    .setStyle(style)
    .setDisabled(disabled);
const row = (...c) => new D.ActionRowBuilder().addComponents(...c);
const text = (s, max = 100) =>
  String(s || "")
    .replace(/[\[\]`*_~>|]/g, "")
    .trim()
    .slice(0, max);
const json = (s) => {
  try {
    return JSON.parse(s || "[]");
  } catch {
    return [];
  }
};
const embed = (title, description = "") =>
  new D.EmbedBuilder()
    .setColor(0xd71935)
    .setTitle(title)
    .setDescription(description || null);
const payload = (e, components = []) => ({
  content: null,
  embeds: [e],
  components,
  allowedMentions: { parse: [] },
});
async function admin(i) {
  if (!i.guild) throw Error("Abra no servidor.");
  const m = await i.guild.members.fetch(i.user.id);
  if (!(await require("../utils/permissions").isBotAdmin(m)))
    throw Error("Você não possui permissão para configurar este servidor.");
  return m;
}
async function member(guild, userId) {
  const m = await guild.members.fetch(userId).catch(() => null);
  if (!m || m.user.bot) throw Error("Você precisa participar deste servidor.");
  return m;
}
async function channel(guild, id, { privateReview = false } = {}) {
  const ch = id ? await guild.channels.fetch(id).catch(() => null) : null;
  if (!ch || ch.guildId !== guild.id || ch.type !== D.ChannelType.GuildText)
    throw Error("Escolha um canal de texto deste servidor.");
  const me = guild.members.me || (await guild.members.fetchMe());
  if (
    !ch
      .permissionsFor(me)
      ?.has([
        D.PermissionFlagsBits.ViewChannel,
        D.PermissionFlagsBits.SendMessages,
        D.PermissionFlagsBits.EmbedLinks,
        D.PermissionFlagsBits.AttachFiles,
        D.PermissionFlagsBits.ReadMessageHistory,
      ])
  )
    throw Error(
      "O bot precisa ver o canal, enviar mensagens e arquivos, inserir links e ler o histórico.",
    );
  if (
    privateReview &&
    ch
      .permissionsFor(guild.roles.everyone || guild.id)
      ?.has(D.PermissionFlagsBits.ViewChannel)
  )
    throw Error(
      "Escolha um canal privado, sem acesso de @everyone, para a revisão.",
    );
  return ch;
}
function form(id, title, fields) {
  const m = new D.ModalBuilder().setCustomId(id).setTitle(title);
  for (const f of fields) {
    const t = new D.TextInputBuilder()
      .setCustomId(f.id)
      .setLabel(f.label)
      .setStyle(f.long ? D.TextInputStyle.Paragraph : D.TextInputStyle.Short)
      .setRequired(f.required !== false)
      .setMaxLength(f.max || 1000);
    if (f.value) t.setValue(String(f.value));
    if (f.placeholder) t.setPlaceholder(f.placeholder);
    m.addComponents(row(t));
  }
  return m;
}
const ephemeral = D.MessageFlags.Ephemeral;
async function guarded(i, fn) {
  try {
    return await fn();
  } catch (e) {
    console.error("[social-experience]", e.message);
    const p = {
      content: e.message || "Não foi possível concluir. Tente novamente.",
      allowedMentions: { parse: [] },
    };
    if (i.deferred && !i.replied && i.ephemeral === true) return i.editReply(p);
    return i.deferred || i.replied
      ? i.followUp({ ...p, flags: ephemeral })
      : i.reply({ ...p, flags: ephemeral });
  }
}
function localDay(date, timezone = "America/Sao_Paulo") {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: timezone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).formatToParts(date);
  const v = Object.fromEntries(parts.map((p) => [p.type, p.value]));
  return {
    date: `${v.year}-${v.month}-${v.day}`,
    minute: Number(v.hour) * 60 + Number(v.minute),
  };
}
module.exports = {
  D,
  prisma,
  config,
  btn,
  row,
  text,
  json,
  embed,
  payload,
  admin,
  member,
  channel,
  form,
  ephemeral,
  guarded,
  locked,
  localDay,
  randomUUID,
};
