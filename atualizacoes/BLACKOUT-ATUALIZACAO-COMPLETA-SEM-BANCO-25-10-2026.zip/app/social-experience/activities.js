"use strict";
const {
  D,
  prisma,
  config,
  btn,
  row,
  text,
  json,
  embed,
  payload,
  channel,
  localDay,
  locked,
} = require("./common");
const KINDS = {
  QUESTION: "Pergunta do dia",
  PREFER: "Você prefere?",
  POLL: "Enquete",
  CHALLENGE: "Desafio temático",
};
const DEFAULTS = [
  {
    kind: "QUESTION",
    prompt: "Qual música representa seu dia e por quê?",
    options: [],
  },
  {
    kind: "PREFER",
    prompt: "Qual rolê você prefere com a comunidade?",
    options: ["Jogar em grupo", "Conversar ouvindo música"],
  },
  {
    kind: "POLL",
    prompt: "Qual atividade vamos fazer juntos?",
    options: ["Noite de jogos", "Sessão de música", "Conversa em call"],
  },
  {
    kind: "CHALLENGE",
    prompt:
      "Publique no INSTA uma foto que represente seu hobby e compartilhe o link na resposta.",
    options: [],
  },
];
function templateData(kind, prompt, options) {
  if (!KINDS[kind])
    throw Error("Tipo inválido. Use QUESTION, PREFER, POLL ou CHALLENGE.");
  prompt = String(prompt || "").trim();
  if (!prompt || prompt.length > 700)
    throw Error("Escreva uma proposta de até 700 caracteres.");
  options = options.map((o) => o.trim()).filter(Boolean);
  const poll = ["PREFER", "POLL"].includes(kind);
  if (
    poll &&
    (options.length < 2 ||
      options.length > 10 ||
      options.some((o) => o.length > 80) ||
      new Set(options).size !== options.length)
  )
    throw Error(
      "Use de 2 a 10 alternativas diferentes, com até 80 caracteres cada.",
    );
  return { kind, prompt, options: JSON.stringify(poll ? options : []) };
}
async function view(guild, a) {
  if (a.guildId !== guild.id) throw Error("Dinâmica de outro servidor.");
  const where = { guildId: guild.id, activityId: a.id },
    total = await prisma.socialActivityResponse.count({ where }),
    options = json(a.options),
    counts = await Promise.all(
      options.map((_, n) =>
        prisma.socialActivityResponse.count({
          where: { ...where, content: String(n) },
        }),
      ),
    );
  const e = embed(KINDS[a.kind], a.prompt).setFooter({
    text: `${total} participantes · Uma resposta por membro · Você pode alterar sua resposta`,
  });
  const rows = [];
  if (options.length) {
    e.addFields({
      name: "Resultados",
      value: options
        .map((o, n) => `${n + 1}. ${text(o, 80)} — **${counts[n]}**`)
        .join("\n"),
    });
    rows.push(
      row(
        new D.StringSelectMenuBuilder()
          .setCustomId(`sx-select:vote:${a.id}`)
          .setPlaceholder("Escolha ou altere seu voto")
          .addOptions(options.map((o, n) => ({ label: o, value: String(n) }))),
      ),
    );
  } else
    rows.push(
      row(
        btn(`sx:answer:${a.id}`, "Responder"),
        btn(`sx:answers:${a.id}:0`, "Ver respostas"),
      ),
    );
  if (a.status !== "ACTIVE")
    rows.forEach((r) => r.components.forEach((c) => c.setDisabled(true)));
  return payload(e, rows);
}
async function publish(guild, key, chosenKind) {
  return locked(`activity:${guild.id}`, async () => {
    const c = await config(guild.id);
    if (!c.dynamicsEnabled)
      throw Error(
        "Ative as dinâmicas depois de configurar o canal e a programação.",
      );
    const ch = await channel(guild, c.dynamicsChannelId);
    const existing = await prisma.socialActivity.findUnique({
      where: { guildId_scheduleKey: { guildId: guild.id, scheduleKey: key } },
    });
    if (existing) return existing;
    const kinds = c.dynamicsKinds.split(",").filter((k) => KINDS[k]);
    if (!kinds.length) throw Error("Escolha ao menos um tipo de dinâmica.");
    if (chosenKind && !kinds.includes(chosenKind))
      throw Error("Esse tipo está desativado.");
    const total = await prisma.socialActivity.count({
        where: { guildId: guild.id, status: "ACTIVE" },
      }),
      kind = chosenKind || kinds[total % kinds.length];
    const custom = await prisma.socialActivityTemplate.findMany({
      where: { guildId: guild.id, kind, enabled: true },
      orderBy: { createdAt: "asc" },
    });
    const sample =
      custom[total % Math.max(1, custom.length)] ||
      DEFAULTS.find((t) => t.kind === kind);
    const data = templateData(
      kind,
      sample.prompt,
      Array.isArray(sample.options) ? sample.options : json(sample.options),
    );
    const a = await prisma.socialActivity.create({
      data: { guildId: guild.id, scheduleKey: key, ...data, channelId: ch.id },
    });
    try {
      const message = await ch.send(
        await view(guild, { ...a, status: "ACTIVE" }),
      );
      await prisma.socialActivity.update({
        where: { id: a.id },
        data: { status: "ACTIVE", messageId: message.id },
      });
      await prisma.socialExperienceConfig.update({
        where: { guildId: guild.id },
        data: { lastError: null },
      });
      return { ...a, status: "ACTIVE", messageId: message.id };
    } catch (e) {
      await prisma.socialActivity.update({
        where: { id: a.id },
        data: { status: "FAILED" },
      });
      throw e;
    }
  });
}
async function get(guild, id) {
  const a = await prisma.socialActivity.findUnique({ where: { id } });
  if (!a || a.guildId !== guild.id || a.status !== "ACTIVE")
    throw Error("Esta dinâmica não está disponível.");
  return a;
}
async function respond(guild, id, userId, content) {
  const a = await get(guild, id),
    c = await config(guild.id);
  if (!c.dynamicsEnabled) throw Error("As dinâmicas estão desativadas.");
  await require("./common").member(guild, userId);
  content = String(content || "").trim();
  const options = json(a.options);
  if (
    !content ||
    content.length > 1000 ||
    (options.length &&
      (!/^(0|[1-9]\d*)$/.test(content) || Number(content) >= options.length))
  )
    throw Error("Resposta inválida.");
  await prisma.socialActivityResponse.upsert({
    where: { activityId_userId: { activityId: id, userId } },
    create: { guildId: guild.id, activityId: id, userId, content },
    update: { content },
  });
  const ch = await channel(guild, a.channelId),
    m = await ch.messages.fetch(a.messageId).catch(() => null);
  if (m) await m.edit(await view(guild, a));
  return a;
}
async function answers(guild, id, page = 0) {
  const a = await get(guild, id),
    count = await prisma.socialActivityResponse.count({
      where: { guildId: guild.id, activityId: id },
    }),
    p = Math.max(
      0,
      Math.min(Number(page) || 0, Math.max(0, Math.ceil(count / 5) - 1)),
    );
  const rows = await prisma.socialActivityResponse.findMany({
    where: { guildId: guild.id, activityId: id },
    orderBy: { createdAt: "desc" },
    skip: p * 5,
    take: 5,
  });
  return payload(
    embed(
      "Respostas da comunidade",
      rows
        .map((r) => `<@${r.userId}>\n${r.content.slice(0, 600)}`)
        .join("\n\n") || "Seja a primeira pessoa a responder.",
    ).setFooter({ text: `Página ${p + 1} · ${count} participantes` }),
    [
      row(
        btn(`sx:answers:${id}:${p - 1}`, "Anterior", 2, p === 0),
        btn(`sx:answers:${id}:${p + 1}`, "Próxima", 2, (p + 1) * 5 >= count),
      ),
    ],
  );
}
async function schedule(guild, c, date = new Date()) {
  if (!c.dynamicsEnabled) return;
  const gc = await prisma.guildConfig.findUnique({
      where: { guildId: guild.id },
    }),
    day = localDay(date, gc?.timezone || "America/Sao_Paulo");
  if (
    day.minute < c.dynamicsHour * 60 + c.dynamicsMinute ||
    c.dynamicsLastDate === day.date
  )
    return;
  if (
    c.dynamicsLastDate &&
    (Date.parse(day.date) - Date.parse(c.dynamicsLastDate)) / 86400000 <
      c.dynamicsIntervalDays
  )
    return;
  const key = "scheduled:" + day.date;
  await publish(guild, key);
  await prisma.socialExperienceConfig.update({
    where: { guildId: guild.id },
    data: { dynamicsLastDate: day.date },
  });
}
module.exports = {
  KINDS,
  DEFAULTS,
  templateData,
  view,
  publish,
  get,
  respond,
  answers,
  schedule,
};
