"use strict";
const {
  D,
  prisma,
  config,
  btn,
  row,
  text,
  embed,
  payload,
  channel,
  member,
  locked,
} = require("./common");
const sub = () => require("../submundo/service");
const preference = (guildId, userId) =>
  prisma.socialAnonymousPreference.findUnique({
    where: { guildId_userId: { guildId, userId } },
  });
async function allowed(guild, senderId, recipientId) {
  await member(guild, senderId);
  await member(guild, recipientId);
  if (senderId === recipientId)
    throw Error("Você não pode enviar uma mensagem para si mesmo.");
  const [p, b] = await Promise.all([
    preference(guild.id, recipientId),
    prisma.socialAnonymousBlock.findUnique({
      where: {
        guildId_blockerId_blockedId: {
          guildId: guild.id,
          blockerId: recipientId,
          blockedId: senderId,
        },
      },
    }),
  ]);
  if (p?.allowDms === false || b)
    throw Error(
      "Esta pessoa não está disponível para receber mensagens anônimas.",
    );
}
async function sendDm(guild, senderId, publicId, content) {
  return locked(`anon-dm:${guild.id}:${senderId}`, async () => {
    content = String(content || "").trim();
    if (!content || content.length > 1000)
      throw Error("Escreva até 1000 caracteres.");
    const p = await prisma.anonymousPhotoSubmission.findUnique({
      where: { publicId },
    });
    if (!p || p.guildId !== guild.id || p.status !== "PUBLISHED")
      throw Error("Envio indisponível.");
    await allowed(guild, senderId, p.authorId);
    const auditConfig = await sub().getAnonymousPhotoConfig(guild.id);
    await channel(guild, auditConfig.logChannelId, { privateReview: true });
    const last = await prisma.socialAnonymousDelivery.findFirst({
      where: { guildId: guild.id, senderId },
      orderBy: { createdAt: "desc" },
    });
    if (last && Date.now() - last.createdAt.getTime() < 30000)
      throw Error("Aguarde 30 segundos entre mensagens.");
    const d = await prisma.socialAnonymousDelivery.create({
      data: {
        guildId: guild.id,
        senderId,
        recipientId: p.authorId,
        publicId,
        content,
        expiresAt: new Date(Date.now() + 7 * 86400000),
      },
    });
    try {
      const recipient = await guild.client.users.fetch(p.authorId);
      await recipient.send(
        payload(
          embed("DM anônima · Submundo", content)
            .addFields({
              name: "Origem",
              value: `Envio ${text(publicId, 40)} · ${text(guild.name, 100)}`,
            })
            .setFooter({
              text: "Anônimo para você. A equipe pode consultar a identidade nos registros.",
            }),
          [
            row(
              btn(`sx-inbox:block:${d.id}`, "Bloquear remetente"),
              btn(`sx-inbox:report:${d.id}`, "Denunciar"),
              btn(`sx-inbox:optout:${d.id}`, "Recusar DMs anônimas"),
            ),
          ],
        ),
      );
      await prisma.socialAnonymousDelivery.update({
        where: { id: d.id },
        data: { status: "DELIVERED" },
      });
      await sub()
        .sendAnonymousMediaLog(guild, {
          title: "DM ANÔNIMA ENTREGUE",
          description: `Referência: ${d.id}\nEnvio: ${publicId}\nRemetente: <@${senderId}>\nDestinatário: <@${p.authorId}>\n${content}`,
          color: 0xd71935,
        })
        .catch(() => null);
      return d;
    } catch (e) {
      await prisma.socialAnonymousDelivery.update({
        where: { id: d.id },
        data: { status: "FAILED" },
      });
      throw Error(
        "Não foi possível entregar a DM. A pessoa pode estar com mensagens privadas desativadas.",
      );
    }
  });
}
async function inbox(i, action, id) {
  const d = await prisma.socialAnonymousDelivery.findUnique({ where: { id } });
  if (
    !d ||
    d.recipientId !== i.user.id ||
    d.status !== "DELIVERED" ||
    d.expiresAt <= new Date()
  )
    throw Error("Esta opção expirou ou pertence a outra pessoa.");
  const guild = await i.client.guilds.fetch(d.guildId).catch(() => null);
  if (!guild) throw Error("O servidor não está mais disponível.");
  if (action === "block") {
    await prisma.socialAnonymousBlock.upsert({
      where: {
        guildId_blockerId_blockedId: {
          guildId: d.guildId,
          blockerId: d.recipientId,
          blockedId: d.senderId,
        },
      },
      create: {
        guildId: d.guildId,
        blockerId: d.recipientId,
        blockedId: d.senderId,
      },
      update: {},
    });
    return "Remetente bloqueado neste servidor. Sua identidade continua oculta.";
  }
  if (action === "optout") {
    await prisma.socialAnonymousPreference.upsert({
      where: { guildId_userId: { guildId: d.guildId, userId: i.user.id } },
      create: { guildId: d.guildId, userId: i.user.id, allowDms: false },
      update: { allowDms: false },
    });
    return "DMs anônimas desativadas para você neste servidor.";
  }
  if (action === "report") {
    if (d.reportedAt) throw Error("Esta mensagem já foi denunciada.");
    const c = await sub().getAnonymousPhotoConfig(d.guildId),
      ch = await channel(guild, c.logChannelId, { privateReview: true });
    const claim = await prisma.socialAnonymousDelivery.updateMany({
      where: { id, reportedAt: null },
      data: { reportedAt: new Date() },
    });
    if (!claim.count) throw Error("Esta mensagem já foi denunciada.");
    try {
      await ch.send(
        payload(
          embed(
            "Denúncia de DM anônima",
            `Referência: ${d.id}\nRemetente real: <@${d.senderId}>\nDenunciante: <@${d.recipientId}>\nEnvio: ${text(d.publicId, 40)}\n\n${d.content}`,
          ),
        ),
      );
      return "Denúncia entregue à equipe do servidor.";
    } catch (e) {
      await prisma.socialAnonymousDelivery.update({
        where: { id },
        data: { reportedAt: null },
      });
      throw Error("Falha ao entregar a denúncia. Tente novamente.");
    }
  }
  throw Error("Ação inválida.");
}
async function enqueue(guild, authorId, kind, source) {
  await member(guild, authorId);
  if (source.content && source.content.length > 2000)
    throw Error("Escreva até 2000 caracteres.");
  const c = await config(guild.id);
  if (!c.anonymousModerated) return null;
  return locked(`anonymous-queue:${guild.id}:${authorId}`, async () => {
    const ch = await channel(guild, c.reviewChannelId, { privateReview: true });
    const pending = await prisma.socialSubmission.count({
      where: { guildId: guild.id, authorId, status: "PENDING" },
    });
    if (pending >= 3)
      throw Error("Você já tem três envios aguardando revisão.");
    const d = await prisma.socialSubmission.create({
      data: {
        guildId: guild.id,
        authorId,
        kind,
        status: "PROCESSING",
        content: source.content || "",
        mediaUrl: source.url || null,
        mediaName: source.name || null,
        mediaType: source.kind || null,
        reviewChannelId: ch.id,
        expiresAt: new Date(Date.now() + 48 * 3600000),
      },
    });
    try {
      const actions = row(
        btn(`sx-review:approve:${d.id}`, "Aprovar", D.ButtonStyle.Success),
        btn(`sx-review:reject:${d.id}`, "Recusar", D.ButtonStyle.Danger),
      );
      let view = payload(
        embed(
          "Submundo · Revisão privada",
          `Autor: <@${authorId}>\nTipo: ${kind === "ANON_MEDIA" ? "Mídia" : "Mensagem"}\n\n${source.content || "Confirme a mídia antes de aprovar."}`,
        ),
        [actions],
      );
      if (source.url) {
        if (!ch.nsfw)
          throw Error("O canal de revisão de mídia também deve ser +18.");
        const name =
          "revisao-" +
          d.id +
          "." +
          String(source.name || "")
            .split(".")
            .pop()
            .replace(/[^a-z0-9]/gi, "");
        view = {
          flags: D.MessageFlags.IsComponentsV2,
          components: [
            new D.ContainerBuilder()
              .setAccentColor(0xd71935)
              .addTextDisplayComponents(
                new D.TextDisplayBuilder().setContent(
                  `### Revisão privada\nAutor: <@${authorId}>\nAnônimo apenas na publicação pública.`,
                ),
              )
              .addMediaGalleryComponents(
                new D.MediaGalleryBuilder().addItems({
                  media: { url: "attachment://" + name },
                }),
              )
              .addActionRowComponents(actions),
          ],
          files: [
            {
              attachment: await require("../social/media").downloadMedia(
                source.url,
              ),
              name,
            },
          ],
          allowedMentions: { parse: [] },
        };
      }
      const m = await ch.send(view);
      const mediaUrl = m.attachments?.first()?.url;
      await prisma.socialSubmission.update({
        where: { id: d.id },
        data: {
          status: "PENDING",
          reviewMessageId: m.id,
          mediaUrl: mediaUrl || null,
        },
      });
      return d;
    } catch (e) {
      await prisma.socialSubmission.update({
        where: { id: d.id },
        data: { status: "FAILED", error: text(e.message, 500) },
      });
      throw e;
    }
  });
}
async function publish(guild, authorId, kind, source) {
  await member(guild, authorId);
  const isMedia = kind === "ANON_MEDIA",
    c = await (isMedia
      ? sub().getAnonymousPhotoConfig(guild.id)
      : sub().getAnonymousMessageConfig(guild.id));
  if (!c.enabled || !(await sub().isSubmundoOpen(c)))
    throw Error("O Submundo está fechado. Nenhum envio foi publicado.");
  const ch = await channel(guild, c.destinationChannelId);
  if (!ch.nsfw) throw Error("O destino do Submundo precisa ser um canal +18.");
  await channel(guild, c.logChannelId, { privateReview: true });
  const timezone = await sub().getGuildTimezone(guild.id),
    sessionKey = sub().getScheduleState(c, timezone).sessionKey,
    publicId = await (isMedia
      ? sub().nextAnonymousMediaId(guild.id)
      : sub().nextAnonymousMessageId(guild.id));
  const model = isMedia
    ? prisma.anonymousPhotoSubmission
    : prisma.anonymousMessageSubmission;
  const r = await model.create({
    data: {
      guildId: guild.id,
      configId: c.id,
      authorId,
      publicId,
      sessionKey,
      status: "PROCESSING",
      ...(isMedia
        ? { mediaType: source.kind, mediaName: source.name }
        : { content: source.content }),
    },
  });
  let sent;
  try {
    let view;
    if (isMedia) {
      const filename =
        `submundo-${publicId}.` +
        String(source.name || "")
          .split(".")
          .pop()
          .replace(/[^a-z0-9]/gi, "");
      view = {
        flags: D.MessageFlags.IsComponentsV2,
        components: [
          new D.ContainerBuilder()
            .setAccentColor(parseInt(c.color, 16) || 0xd71935)
            .addTextDisplayComponents(
              new D.TextDisplayBuilder().setContent(
                `### Envio anônimo\n-# ID ${publicId}`,
              ),
            )
            .addMediaGalleryComponents(
              new D.MediaGalleryBuilder().addItems({
                media: { url: "attachment://" + filename },
              }),
            )
            .addActionRowComponents(
              row(btn(`submundo-media-dm:${publicId}`, "Enviar DM anônima")),
            ),
        ],
        files: [
          {
            attachment: await require("../social/media").downloadMedia(
              source.url,
            ),
            name: filename,
          },
        ],
        allowedMentions: { parse: [] },
      };
    } else
      view = payload(
        embed(
          "Correio anônimo",
          String(source.content).slice(0, 2000),
        ).setFooter({ text: `Carta ${publicId}` }),
      );
    sent = await ch.send(view);
    const url = sent.attachments?.first()?.url || null;
    await model.update({
      where: { id: r.id },
      data: {
        status: "PUBLISHED",
        publicChannelId: ch.id,
        publicMessageId: sent.id,
        ...(isMedia
          ? { mediaUrl: url, imageUrl: source.kind === "IMAGE" ? url : null }
          : {}),
      },
    });
    await sent.react("🔥").catch(() => null);
    if (!isMedia) await sent.react("🔞").catch(() => null);
    await (
      isMedia ? sub().sendAnonymousMediaLog : sub().sendAnonymousMessageLog
    )(guild, {
      title: "ENVIO ANÔNIMO PUBLICADO",
      description: `ID ${publicId}\nAutor real: <@${authorId}>\nSessão: ${sessionKey}\n${source.content || ""}\nhttps://discord.com/channels/${guild.id}/${ch.id}/${sent.id}`,
      color: 0xd71935,
    }).catch(() => null);
    return r;
  } catch (e) {
    if (sent) await sent.delete().catch(() => null);
    await model.update({ where: { id: r.id }, data: { status: "FAILED" } });
    throw e;
  }
}
async function review(i, approve, id) {
  const d = await prisma.socialSubmission.findUnique({ where: { id } });
  if (
    !d ||
    d.guildId !== i.guild.id ||
    !["ANON_MEDIA", "ANON_TEXT"].includes(d.kind) ||
    d.status !== "PENDING" ||
    d.expiresAt <= new Date()
  )
    throw Error("Este envio já foi analisado ou expirou.");
  const ch = await channel(i.guild, d.reviewChannelId, { privateReview: true });
  const actor = await member(i.guild, i.user.id);
  if (
    !ch.permissionsFor(actor)?.has(D.PermissionFlagsBits.ViewChannel) ||
    !(
      actor.permissions.has(D.PermissionFlagsBits.ManageMessages) ||
      (await require("../utils/permissions").isBotAdmin(actor))
    )
  )
    throw Error("Você não pode revisar este envio.");
  const claim = await prisma.socialSubmission.updateMany({
    where: { id, status: "PENDING" },
    data: {
      status: approve ? "PROCESSING" : "REJECTED",
      reviewerId: i.user.id,
    },
  });
  if (!claim.count) throw Error("Este envio já foi analisado.");
  let result;
  try {
    if (approve) {
      let url = d.mediaUrl;
      if (d.mediaUrl) {
        const reviewMessage = await ch.messages.fetch(d.reviewMessageId);
        url = reviewMessage.attachments.first()?.url;
        if (!url) throw Error("A mídia da revisão não está mais disponível.");
      }
      result = await publish(i.guild, d.authorId, d.kind, {
        content: d.content,
        url,
        name: d.mediaName,
        kind: d.mediaType,
      });
      await prisma.socialSubmission.update({
        where: { id },
        data: { status: "PUBLISHED", resultId: result.id },
      });
    }
    const author = await i.client.users.fetch(d.authorId).catch(() => null);
    await author
      ?.send({
        content: `Seu envio no Submundo de ${text(i.guild.name, 100)} foi ${approve ? "aprovado e publicado" : "recusado"}. Referência: ${d.id}`,
        allowedMentions: { parse: [] },
      })
      .catch(() => null);
    return approve
      ? "Envio aprovado e publicado."
      : "Envio recusado. Nada foi publicado.";
  } catch (e) {
    await prisma.socialSubmission.update({
      where: { id },
      data: { status: "FAILED", error: text(e.message, 500) },
    });
    throw e;
  }
}
module.exports = {
  preference,
  allowed,
  sendDm,
  inbox,
  enqueue,
  publish,
  review,
};
