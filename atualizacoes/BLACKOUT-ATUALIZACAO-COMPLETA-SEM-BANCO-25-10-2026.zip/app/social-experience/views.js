"use strict";
const C = require("./common"),
  { D, prisma, config, btn, row, text, embed, payload } = C;
const { adminEmbed } = require("../utils/adminUi");
const link = (id) => (id ? `<#${id}>` : "Não configurado");
const on = (b) => (b ? "Ativado" : "Desativado");
function selectChannel(target, value, label) {
  const s = new D.ChannelSelectMenuBuilder()
    .setCustomId(`sx-select:channel:${target}`)
    .setPlaceholder(label)
    .addChannelTypes(D.ChannelType.GuildText);
  if (value) s.setDefaultChannels(value);
  return row(s);
}
function nav(current) {
  return row(
    new D.StringSelectMenuBuilder()
      .setCustomId("sx-select:admin")
      .setPlaceholder("Configurar Social e entretenimento")
      .addOptions(
        [
          {
            label: "Dinâmicas sociais",
            value: "dynamics",
            description: "Canal, programação e tipos de interação",
          },
          {
            label: "Temas e propostas",
            value: "templates",
            description: "Criar e administrar propostas das dinâmicas",
          },
          {
            label: "Painel de participação e perfis",
            value: "participation",
            description: "Prévia, publicação e perfis opcionais",
          },
          {
            label: "Pedidos da rádio",
            value: "radio",
            description: "Limites, aprovação e painel público",
          },
          {
            label: "Privacidade e aprovação do Submundo",
            value: "anonymous",
            description: "Revisão privada e proteção das DMs",
          },
        ].map((o) => ({ ...o, default: o.value === current })),
      ),
  );
}
async function adminView(guild, page = "dynamics", offset = 0) {
  const c = await config(guild.id),
    e = adminEmbed(guild, "entretenimento"),
    rows = [nav(page)];
  if (page === "dynamics") {
    const tz =
      (await prisma.guildConfig.findUnique({ where: { guildId: guild.id } }))
        ?.timezone || "America/Sao_Paulo";
    e.setTitle("Dinâmicas sociais")
      .setDescription(
        "Perguntas, enquetes e desafios no mesmo canal. Os membros participam e veem o resultado atualizado na própria mensagem.",
      )
      .addFields(
        {
          name: "Estado e destino",
          value: `${on(c.dynamicsEnabled)} · ${link(c.dynamicsChannelId)}`,
        },
        {
          name: "Programação",
          value: `Às ${String(c.dynamicsHour).padStart(2, "0")}:${String(c.dynamicsMinute).padStart(2, "0")} · A cada ${c.dynamicsIntervalDays} dia(s)\nFuso: ${text(tz)}\nÚltima publicação automática: ${c.dynamicsLastDate || "Ainda não publicada"}`,
        },
        {
          name: "Tipos ativos",
          value:
            c.dynamicsKinds
              .split(",")
              .map((k) => require("./activities").KINDS[k])
              .filter(Boolean)
              .join(" · ") || "Nenhum",
        },
        {
          name: "Como começar",
          value:
            "1. Escolha o canal e a programação.\n2. Revise os tipos e temas.\n3. Ative a rotina. Use “Publicar agora” para antecipar uma proposta.",
        },
      );
    rows.push(
      selectChannel(
        "dynamicsChannelId",
        c.dynamicsChannelId,
        "Canal das dinâmicas",
      ),
      row(
        btn(
          "sx-admin:toggle:dynamicsEnabled",
          c.dynamicsEnabled ? "Desativar rotina" : "Ativar rotina",
        ),
        btn("sx-admin:schedule", "Horário e frequência"),
        btn(
          "sx-admin:publish-confirm",
          "Publicar agora",
          D.ButtonStyle.Primary,
        ),
      ),
      row(
        new D.StringSelectMenuBuilder()
          .setCustomId("sx-select:kinds")
          .setPlaceholder("Tipos que podem ser publicados")
          .setMinValues(1)
          .setMaxValues(4)
          .addOptions(
            Object.entries(require("./activities").KINDS).map(
              ([value, label]) => ({
                value,
                label,
                default: c.dynamicsKinds.split(",").includes(value),
              }),
            ),
          ),
      ),
    );
  } else if (page === "templates") {
    const n = Math.max(0, Number(offset) || 0),
      templates = await prisma.socialActivityTemplate.findMany({
        where: { guildId: guild.id },
        orderBy: { createdAt: "asc" },
        skip: n,
        take: 20,
      });
    e.setTitle("Temas e propostas")
      .setDescription(
        "Pergunta, preferência, enquete ou desafio. As propostas prontas são usadas quando não há um tema ativo do tipo escolhido. Alterações valem para as próximas publicações.",
      )
      .addFields({
        name: "Propostas cadastradas",
        value:
          templates
            .slice(0, 10)
            .map(
              (t, i) =>
                `${i + 1}. ${t.enabled ? "Ativa" : "Pausada"} · ${text(t.prompt, 65)}`,
            )
            .join("\n") ||
          "Você pode começar com as quatro propostas prontas e criar suas próprias aqui.",
      });
    if (templates.length > 10)
      e.addFields({
        name: "Mais propostas desta página",
        value: templates
          .slice(10)
          .map(
            (t, i) =>
              `${i + 11}. ${t.enabled ? "Ativa" : "Pausada"} · ${text(t.prompt, 65)}`,
          )
          .join("\n"),
      });
    rows.push(
      row(
        btn("sx-admin:template-new", "Criar proposta", D.ButtonStyle.Primary),
        btn(
          `sx-admin:templates:${Math.max(0, n - 20)}`,
          "Anterior",
          2,
          n === 0,
        ),
        btn(
          `sx-admin:templates:${n + 20}`,
          "Próximas",
          2,
          templates.length < 20,
        ),
      ),
    );
    if (templates.length)
      rows.push(
        row(
          new D.StringSelectMenuBuilder()
            .setCustomId("sx-select:template")
            .setPlaceholder("Editar ou pausar uma proposta")
            .addOptions(
              templates.map((t) => ({
                value: t.id,
                label: text(t.prompt, 90),
                description: `${require("./activities").KINDS[t.kind]} · ${t.enabled ? "Ativa" : "Pausada"}`,
              })),
            ),
        ),
      );
  } else if (page === "participation") {
    e.setTitle("Painel de participação e perfis")
      .setDescription(
        "Um acesso simples para publicar no INSTA, responder dinâmicas, pedir músicas e cuidar da privacidade.",
      )
      .addFields(
        {
          name: "Painel público",
          value: `Canal: ${link(c.panelChannelId)}\n${c.panelMessageId ? "Publicado · Salve e use “Publicar / atualizar” para aplicar alterações." : "Ainda não publicado"}`,
        },
        {
          name: "Perfis sociais",
          value: `${on(c.profilesEnabled)}\nO membro decide se quer publicar bio, interesses e jogos favoritos. Nenhum dado do Registro é importado.`,
        },
      );
    rows.push(
      selectChannel(
        "panelChannelId",
        c.panelChannelId,
        "Canal do painel de participação",
      ),
      row(
        btn("sx-admin:hub-preview", "Ver prévia"),
        btn(
          "sx-admin:hub-publish",
          "Publicar / atualizar",
          D.ButtonStyle.Primary,
        ),
        btn(
          "sx-admin:toggle:profilesEnabled",
          c.profilesEnabled ? "Desativar perfis" : "Ativar perfis",
        ),
      ),
    );
  } else if (page === "radio") {
    const count = await prisma.socialRadioRequest.count({
      where: { guildId: guild.id, status: "PENDING" },
    });
    e.setTitle("Pedidos de música")
      .setDescription(
        "Pedidos aprovados tocam antes da próxima faixa da playlist. Eles são removidos da fila ao terminar, sem alterar a playlist do servidor.",
      )
      .addFields(
        {
          name: "Recebimento",
          value: `${on(c.requestsEnabled)} · ${c.requestsModerated ? "Com aprovação da equipe" : "Entrada direta na fila"}\nAté ${c.requestsLimit} pedidos ativos por pessoa · Intervalo ${c.requestsCooldown}s\nAguardando revisão: ${count}`,
        },
        {
          name: "Painel da rádio",
          value: `${link(c.radioPanelChannelId)}\n${c.radioPanelMessageId ? "Publicado" : "Ainda não publicado"} · Mostra faixa atual e próximos pedidos.`,
        },
        {
          name: "Votação para pular",
          value:
            "Somente ouvintes presentes, com áudio ativado. Um voto por faixa; exige maioria absoluta.",
        },
      );
    rows.push(
      row(
        btn(
          "sx-admin:toggle:requestsEnabled",
          c.requestsEnabled ? "Desativar pedidos" : "Ativar pedidos",
        ),
        btn(
          "sx-admin:toggle:requestsModerated",
          c.requestsModerated ? "Usar fila direta" : "Exigir aprovação",
        ),
        btn("sx-admin:radio-limits", "Limites"),
        btn("sx-admin:radio-queue:0", "Revisar pedidos"),
      ),
    );
    rows.push(
      selectChannel(
        "radioPanelChannelId",
        c.radioPanelChannelId,
        "Canal do painel da rádio",
      ),
      row(
        btn("sx-admin:radio-preview", "Ver prévia"),
        btn(
          "sx-admin:radio-publish",
          "Publicar / atualizar",
          D.ButtonStyle.Primary,
        ),
        btn("adm-radio:home", "Configurar reprodução"),
      ),
    );
  } else if (page === "anonymous") {
    const pending = await prisma.socialSubmission.count({
      where: {
        guildId: guild.id,
        status: "PENDING",
        kind: { in: ["ANON_MEDIA", "ANON_TEXT"] },
      },
    });
    e.setTitle("Submundo · Privacidade e aprovação")
      .setDescription(
        "O anonimato vale para as publicações públicas. A equipe autorizada consegue consultar as identidades nos registros privados.",
      )
      .addFields(
        {
          name: "Aprovação antes de publicar",
          value: `${on(c.anonymousModerated)}\nCanal de revisão: ${link(c.reviewChannelId)}\n${pending} envios aguardando análise · Expiram em 48 horas.`,
        },
        {
          name: "Proteções da DM anônima",
          value:
            "O destinatário pode bloquear o remetente sem descobrir sua identidade, denunciar à equipe ou recusar novas DMs. A preferência é salva por servidor.",
        },
        {
          name: "Antes de ativar",
          value:
            "Escolha um canal privado para a equipe. Para mídia, esse canal também precisa estar marcado como +18. Os logs do Submundo continuam obrigatórios.",
        },
      );
    rows.push(
      selectChannel(
        "reviewChannelId",
        c.reviewChannelId,
        "Canal privado de revisão",
      ),
      row(
        btn(
          "sx-admin:toggle:anonymousModerated",
          c.anonymousModerated ? "Desativar aprovação" : "Exigir aprovação",
        ),
        btn("sx-admin:anonymous-queue", "Ver fila de revisão"),
        btn("sx-admin:privacy-preview", "Ver privacidade do membro"),
      ),
    );
  } else throw Error("Página inválida.");
  if (c.lastError)
    e.addFields({
      name: "Último aviso da automação",
      value: text(c.lastError, 500),
    });
  rows.push(
    row(btn("adm-nav:entretenimento", "Voltar a Social e entretenimento")),
  );
  return { attachments: [], ...payload(e, rows) };
}
async function hub(guild, { preview = false } = {}) {
  const c = await config(guild.id),
    social = await require("../social/service").socialConfig(guild.id);
  const e = embed(
    "Seu espaço na comunidade",
    "Compartilhe o que você gosta, entre na conversa e encontre pessoas com interesses parecidos.",
  )
    .setColor(parseInt(social.color, 16) || 0xd71935)
    .setFooter({
      text: "Suas escolhas e preferências valem somente neste servidor.",
    });
  return payload(e, [
    row(
      btn(
        "sx:post",
        "Publicar no INSTA",
        D.ButtonStyle.Primary,
        preview || !social.enabled,
      ),
      btn("sx:dynamics", "Dinâmicas", 2, preview || !c.dynamicsEnabled),
      btn("sx:radio-refresh", "Rádio e pedidos", 2, preview),
    ),
    row(
      btn("sx:mine:0", "Minhas publicações", 2, preview),
      btn("sx:profile", "Meu perfil social", 2, preview || !c.profilesEnabled),
      btn("sx:privacy", "Minha privacidade", 2, preview),
    ),
  ]);
}
async function privacy(guild, userId) {
  const [a, s] = await Promise.all([
    require("./anonymous").preference(guild.id, userId),
    prisma.socialUserPreference.findUnique({
      where: { guildId_userId: { guildId: guild.id, userId } },
    }),
  ]);
  return payload(
    embed(
      "Minha privacidade",
      `**DMs do INSTA:** ${s?.allowDms === false ? "Recusadas" : "Aceitas"}\n**DMs anônimas do Submundo:** ${a?.allowDms === false ? "Recusadas" : "Aceitas"}\n\nAs escolhas são independentes e valem apenas neste servidor. No Submundo, o remetente é anônimo para você e identificado nos registros da equipe.`,
    ),
    [
      row(
        btn(
          "sx:privacy-insta",
          s?.allowDms === false
            ? "Aceitar DMs do INSTA"
            : "Recusar DMs do INSTA",
        ),
        btn(
          "sx:privacy-anonymous",
          a?.allowDms === false
            ? "Aceitar DMs anônimas"
            : "Recusar DMs anônimas",
        ),
      ),
    ],
  );
}
async function publishPanel(guild, kind) {
  const c = await config(guild.id),
    isRadio = kind === "radio",
    channelKey = isRadio ? "radioPanelChannelId" : "panelChannelId",
    messageKey = isRadio ? "radioPanelMessageId" : "panelMessageId",
    hashKey = isRadio ? "radioPanelHash" : "panelHash",
    ch = await C.channel(guild, c[channelKey]),
    p = await (isRadio ? require("./radio").view(guild) : hub(guild)),
    old = c[messageKey]
      ? await ch.messages.fetch(c[messageKey]).catch(() => null)
      : null,
    m = old ? await old.edit(p) : await ch.send(p);
  const hash = require("node:crypto")
    .createHash("sha256")
    .update(JSON.stringify(p))
    .digest("hex");
  await prisma.socialExperienceConfig.update({
    where: { guildId: guild.id },
    data: { [messageKey]: m.id, [hashKey]: hash },
  });
  return m;
}
module.exports = { adminView, hub, privacy, publishPanel, selectChannel };
