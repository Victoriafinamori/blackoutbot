"use strict";
const { prisma, config, channel } = require("./common");
let running = false;
async function refreshExisting(guild, c, kind) {
  const isRadio = kind === "radio",
    id = isRadio ? c.radioPanelMessageId : c.panelMessageId,
    chId = isRadio ? c.radioPanelChannelId : c.panelChannelId,
    key = isRadio ? "radioPanelHash" : "panelHash";
  if (!id || !chId) return;
  const p = await (isRadio
      ? require("./radio").view(guild)
      : require("./views").hub(guild)),
    hash = require("node:crypto")
      .createHash("sha256")
      .update(JSON.stringify(p))
      .digest("hex");
  if (c[key] === hash) return;
  const ch = await channel(guild, chId),
    m = await ch.messages.fetch(id).catch(() => null);
  if (!m) return;
  await m.edit(p);
  await prisma.socialExperienceConfig.update({
    where: { guildId: guild.id },
    data: { [key]: hash },
  });
}
async function run(client) {
  if (running) return;
  running = true;
  try {
    const configs = await prisma.socialExperienceConfig.findMany();
    for (const c of configs) {
      const g = client.guilds.cache.get(c.guildId);
      if (!g) continue;
      for (const action of [
        () => require("./activities").schedule(g, c),
        () => refreshExisting(g, c, "radio"),
      ])
        try {
          await action();
        } catch (e) {
          await prisma.socialExperienceConfig
            .update({
              where: { guildId: g.id },
              data: { lastError: String(e.message).slice(0, 500) },
            })
            .catch(() => null);
          console.error("[social-experience:" + g.id + "]", e.message);
        }
    }
    const now = new Date();
    await prisma.socialSubmission.updateMany({
      where: { status: { in: ["DRAFT", "PENDING"] }, expiresAt: { lte: now } },
      data: { status: "EXPIRED" },
    });
    await prisma.socialAnonymousDelivery.deleteMany({
      where: { expiresAt: { lte: now }, reportedAt: null },
    });
    await prisma.socialRadioVote.deleteMany({
      where: { createdAt: { lt: new Date(Date.now() - 86400000) } },
    });
    await prisma.socialSubmission.deleteMany({
      where: {
        kind: "INSTA",
        status: { in: ["CANCELLED", "EXPIRED", "FAILED", "PUBLISHED"] },
        expiresAt: { lt: new Date(Date.now() - 7 * 86400000) },
      },
    });
  } finally {
    running = false;
  }
}
module.exports = { run, refreshExisting };
