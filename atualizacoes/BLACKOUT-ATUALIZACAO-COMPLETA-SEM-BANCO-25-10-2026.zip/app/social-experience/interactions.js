"use strict";
const C = require("./common"),
  { D, prisma, config, btn, row, text, embed, payload, form, ephemeral } = C,
  V = require("./views"),
  A = require("./activities");
const { deferPanel, refreshPanel } = require("../utils/panelInteraction");
const pageFor = (k) =>
  k.startsWith("dynamics")
    ? "dynamics"
    : k.startsWith("requests")
      ? "radio"
      : k === "anonymousModerated"
        ? "anonymous"
        : "participation";
async function showAdmin(i, page = "dynamics", offset = 0) {
  await deferPanel(i);
  return refreshPanel(i, await V.adminView(i.guild, page, offset));
}
async function privateView(i, fn) {
  if (i.message?.flags?.has?.(ephemeral)) {
    await deferPanel(i);
    return refreshPanel(i, await fn());
  }
  await i.deferReply({ flags: ephemeral });
  return i.editReply(await fn());
}
async function templateView(guild, id) {
  const t = await prisma.socialActivityTemplate.findUnique({ where: { id } });
  if (!t || t.guildId !== guild.id) throw Error("Proposta não encontrada.");
  return payload(
    require("../utils/adminUi")
      .adminEmbed(guild, "entretenimento")
      .setTitle("Revisar proposta")
      .setDescription(t.prompt)
      .addFields(
        {
          name: "Tipo e estado",
          value: `${A.KINDS[t.kind]} · ${t.enabled ? "Ativa" : "Pausada"}`,
        },
        {
          name: "Alternativas",
          value: C.json(t.options).join("\n") || "Resposta livre",
        },
      ),
    [
      row(
        btn(`sx-admin:template-edit:${id}`, "Editar proposta"),
        btn(`sx-admin:template-toggle:${id}`, t.enabled ? "Pausar" : "Ativar"),
        btn("sx-admin:templates:0", "Voltar"),
      ),
    ],
  );
}
async function queueView(guild, offset = 0) {
  const n = Math.max(0, Number(offset) || 0),
    q = await prisma.socialRadioRequest.findMany({
      where: { guildId: guild.id, status: "PENDING" },
      orderBy: { createdAt: "asc" },
      skip: n,
      take: 10,
    });
  const rows = [];
  if (q.length)
    rows.push(
      row(
        new D.StringSelectMenuBuilder()
          .setCustomId("sx-select:radio-review")
          .setPlaceholder("Escolha um pedido para analisar")
          .addOptions(
            q.map((x) => ({
              label: text(x.title, 90),
              description: "Pedido de " + x.userId,
              value: x.id,
            })),
          ),
      ),
    );
  rows.push(
    row(
      btn(
        `sx-admin:radio-queue:${Math.max(0, n - 10)}`,
        "Anterior",
        2,
        n === 0,
      ),
      btn(`sx-admin:radio-queue:${n + 10}`, "Próximos", 2, q.length < 10),
      btn("sx-admin:radio", "Voltar"),
    ),
  );
  return payload(
    embed(
      "Revisar pedidos",
      q
        .map((r) => `<@${r.userId}> · [${text(r.title, 100)}](${r.url})`)
        .join("\n") || "Nenhum pedido aguardando aprovação.",
    ),
    rows,
  );
}
async function adminButton(i) {
  return C.guarded(i, async () => {
    await C.admin(i);
    const [, action, arg] = i.customId.split(":"),
      c = await config(i.guild.id);
    if (
      ["dynamics", "radio", "anonymous", "participation", "templates"].includes(
        action,
      )
    )
      return showAdmin(i, action, Number(arg) || 0);
    if (action === "toggle") {
      const keys = [
        "dynamicsEnabled",
        "profilesEnabled",
        "requestsEnabled",
        "requestsModerated",
        "anonymousModerated",
      ];
      if (!keys.includes(arg)) throw Error("Configuração inválida.");
      if (!c[arg] && arg === "dynamicsEnabled")
        await C.channel(i.guild, c.dynamicsChannelId);
      if (!c[arg] && arg === "anonymousModerated") {
        const ch = await C.channel(i.guild, c.reviewChannelId, {
          privateReview: true,
        });
        if (!ch.nsfw)
          throw Error("O canal de revisão do Submundo também precisa ser +18.");
      }
      await prisma.socialExperienceConfig.update({
        where: { guildId: i.guild.id },
        data: { [arg]: !c[arg] },
      });
      return showAdmin(i, pageFor(arg));
    }
    if (action === "schedule")
      return i.showModal(
        form("sx-form:schedule", "Programação das dinâmicas", [
          {
            id: "time",
            label: "Horário local (HH:MM)",
            value: `${String(c.dynamicsHour).padStart(2, "0")}:${String(c.dynamicsMinute).padStart(2, "0")}`,
            max: 5,
          },
          {
            id: "interval",
            label: "A cada quantos dias? (1 a 7)",
            value: c.dynamicsIntervalDays,
            max: 1,
          },
        ]),
      );
    if (action === "radio-limits")
      return i.showModal(
        form("sx-form:radio-limits", "Limites dos pedidos", [
          {
            id: "limit",
            label: "Pedidos ativos por pessoa (1 a 10)",
            value: c.requestsLimit,
            max: 2,
          },
          {
            id: "cooldown",
            label: "Intervalo em segundos (30 a 3600)",
            value: c.requestsCooldown,
            max: 4,
          },
        ]),
      );
    if (action === "publish-confirm")
      return refreshPanel(
        i,
        payload(
          embed(
            "Publicar dinâmica agora?",
            `Uma proposta será enviada em ${c.dynamicsChannelId ? "<#" + c.dynamicsChannelId + ">" : "um canal ainda não configurado"}. A rotina deve estar ativada. Esta ação cria uma mensagem pública.`,
          ),
          [
            row(
              btn(
                `sx-admin:publish-now:${i.id}`,
                "Confirmar publicação",
                D.ButtonStyle.Success,
              ),
              btn("sx-admin:dynamics", "Cancelar"),
            ),
          ],
        ),
      );
    if (action === "publish-now") {
      await deferPanel(i);
      await A.publish(i.guild, "manual:" + arg);
      return showAdmin(i);
    }
    if (action === "template-new" || action === "template-edit") {
      let t;
      if (arg) {
        t = await prisma.socialActivityTemplate.findUnique({
          where: { id: arg },
        });
        if (!t || t.guildId !== i.guild.id)
          throw Error("Proposta não encontrada.");
      }
      return i.showModal(
        form(
          `sx-form:template:${t?.id || "new"}`,
          "Proposta para a comunidade",
          [
            {
              id: "kind",
              label: "QUESTION / PREFER / POLL / CHALLENGE",
              value: t?.kind || "QUESTION",
              max: 10,
            },
            {
              id: "prompt",
              label: "Pergunta ou desafio",
              long: true,
              value: t?.prompt || "",
              max: 700,
            },
            {
              id: "options",
              label: "Alternativas: uma por linha (enquetes)",
              long: true,
              required: false,
              value: t ? C.json(t.options).join("\n") : "",
              max: 810,
            },
          ],
        ),
      );
    }
    if (action === "template-toggle") {
      const t = await prisma.socialActivityTemplate.findUnique({
        where: { id: arg },
      });
      if (!t || t.guildId !== i.guild.id)
        throw Error("Proposta não encontrada.");
      await prisma.socialActivityTemplate.update({
        where: { id: arg },
        data: { enabled: !t.enabled },
      });
      return refreshPanel(i, await templateView(i.guild, arg));
    }
    if (action === "hub-preview" || action === "radio-preview") {
      const view =
        action === "hub-preview"
          ? await V.hub(i.guild, { preview: true })
          : await require("./radio").view(i.guild);
      view.components.forEach((r) =>
        r.components.forEach((b) => b.setDisabled(true)),
      );
      return i.reply({ ...view, flags: ephemeral });
    }
    if (action === "hub-publish" || action === "radio-publish") {
      await deferPanel(i);
      await V.publishPanel(i.guild, action === "hub-publish" ? "hub" : "radio");
      return showAdmin(i, action === "hub-publish" ? "participation" : "radio");
    }
    if (action === "privacy-preview")
      return privateView(i, () => V.privacy(i.guild, i.user.id));
    if (action === "radio-queue") {
      await deferPanel(i);
      return refreshPanel(i, await queueView(i.guild, Number(arg) || 0));
    }
    if (action === "radio-approve" || action === "radio-reject") {
      await deferPanel(i);
      await require("./radio").review(
        i.guild,
        arg,
        i.user.id,
        action === "radio-approve",
      );
      return refreshPanel(i, await queueView(i.guild));
    }
    if (action === "anonymous-queue") {
      const q = await prisma.socialSubmission.findMany({
        where: {
          guildId: i.guild.id,
          status: "PENDING",
          kind: { in: ["ANON_TEXT", "ANON_MEDIA"] },
        },
        orderBy: { createdAt: "asc" },
        take: 10,
      });
      return refreshPanel(
        i,
        payload(
          embed(
            "Fila privada de revisão",
            q
              .map(
                (d) =>
                  `[Abrir revisão](https://discord.com/channels/${d.guildId}/${d.reviewChannelId}/${d.reviewMessageId}) · ${d.kind === "ANON_MEDIA" ? "Mídia" : "Mensagem"} · <t:${Math.floor(d.createdAt.getTime() / 1000)}:R>`,
              )
              .join("\n") || "Nenhum envio aguardando revisão.",
          ),
          [row(btn("sx-admin:anonymous", "Voltar"))],
        ),
      );
    }
    throw Error("Opção não encontrada.");
  });
}
async function memberButton(i) {
  return C.guarded(i, async () => {
    if (!i.guild) throw Error("Abra esta opção no servidor.");
    await C.member(i.guild, i.user.id);
    const [, action, arg, arg2] = i.customId.split(":");
    if (action === "post") {
      const c = await require("../social/service").socialConfig(i.guild.id);
      if (!c.enabled) throw Error("O INSTA está desativado.");
      const m = new D.ModalBuilder()
        .setCustomId("sx-form:post")
        .setTitle("Publicar no INSTA");
      m.addLabelComponents(
        new D.LabelBuilder()
          .setLabel("Imagem, GIF ou vídeo")
          .setDescription("Até 25 MB. Você verá a prévia antes de publicar.")
          .setFileUploadComponent(
            new D.FileUploadBuilder()
              .setCustomId("media")
              .setMinValues(1)
              .setMaxValues(1)
              .setRequired(true),
          ),
        new D.LabelBuilder().setLabel("Legenda").setTextInputComponent(
          new D.TextInputBuilder()
            .setCustomId("caption")
            .setStyle(D.TextInputStyle.Paragraph)
            .setRequired(false)
            .setMaxLength(Math.max(1, Math.min(c.maxCaptionLength, 2000))),
        ),
      );
      return i.showModal(m);
    }
    if (action === "post-confirm" || action === "post-cancel") {
      await i.deferUpdate();
      return require("./posts").confirm(i, arg, action === "post-cancel");
    }
    if (action === "mine")
      return privateView(i, () =>
        require("./posts").mine(i.guild, i.user.id, Number(arg) || 0),
      );
    if (
      action === "privacy" ||
      action === "privacy-insta" ||
      action === "privacy-anonymous"
    ) {
      if (action !== "privacy") {
        const model =
            action === "privacy-insta"
              ? prisma.socialUserPreference
              : prisma.socialAnonymousPreference,
          p = await model.findUnique({
            where: {
              guildId_userId: { guildId: i.guild.id, userId: i.user.id },
            },
          }),
          allowDms = !(p?.allowDms ?? true);
        await model.upsert({
          where: { guildId_userId: { guildId: i.guild.id, userId: i.user.id } },
          create: { guildId: i.guild.id, userId: i.user.id, allowDms },
          update: { allowDms },
        });
        return refreshPanel(i, await V.privacy(i.guild, i.user.id));
      }
      return privateView(i, () => V.privacy(i.guild, i.user.id));
    }
    if (action === "dynamics")
      return privateView(i, async () => {
        const q = await prisma.socialActivity.findMany({
          where: { guildId: i.guild.id, status: "ACTIVE" },
          orderBy: { createdAt: "desc" },
          take: 8,
        });
        return payload(
          embed(
            "Dinâmicas da comunidade",
            q
              .map(
                (a) =>
                  `[${text(a.prompt, 160)}](https://discord.com/channels/${a.guildId}/${a.channelId}/${a.messageId})`,
              )
              .join("\n\n") || "Ainda não há dinâmicas publicadas.",
          ),
        );
      });
    if (action === "answer") {
      const a = await A.get(i.guild, arg);
      return i.showModal(
        form(`sx-form:answer:${a.id}`, "Responder à dinâmica", [
          { id: "content", label: text(a.prompt, 45), long: true, max: 1000 },
        ]),
      );
    }
    if (action === "answers")
      return privateView(i, () => A.answers(i.guild, arg, Number(arg2) || 0));
    if (action === "radio-request")
      return i.showModal(
        form("sx-form:radio-request", "Pedir uma música", [
          { id: "url", label: "Link do vídeo no YouTube", max: 300 },
        ]),
      );
    if (action === "radio-refresh")
      return privateView(i, () => require("./radio").view(i.guild));
    if (action === "radio-mine")
      return privateView(i, () =>
        require("./radio").myRequests(i.guild, i.user.id),
      );
    if (action === "radio-vote") {
      await i.deferReply({ flags: ephemeral });
      const v = await require("./radio").vote(i.guild, i.user.id, arg);
      return i.editReply(
        v.skipped
          ? "Maioria atingida. A rádio pulou a faixa."
          : `Seu voto foi registrado: ${v.votes}/${v.needed} votos necessários.`,
      );
    }
    if (action === "profile")
      return privateView(i, () =>
        require("./profiles").view(i.guild, i.user.id),
      );
    if (action === "profile-edit") {
      const p = await require("./profiles").own(i.guild, i.user.id);
      return i.showModal(
        form("sx-form:profile", "Meu perfil social", [
          {
            id: "bio",
            label: "Sobre mim",
            long: true,
            required: false,
            max: 300,
            value: p.bio,
          },
          {
            id: "interests",
            label: "Interesses",
            required: false,
            max: 150,
            value: p.interests,
          },
          {
            id: "games",
            label: "Jogos favoritos",
            required: false,
            max: 150,
            value: p.games,
          },
        ]),
      );
    }
    if (action === "profile-visibility") {
      const p = await require("./profiles").own(i.guild, i.user.id);
      await require("./profiles").save(i.guild, i.user.id, {
        visible: !p.visible,
      });
      return refreshPanel(
        i,
        await require("./profiles").view(i.guild, i.user.id),
      );
    }
    if (action === "profile-delete")
      return refreshPanel(
        i,
        payload(
          embed(
            "Apagar meu perfil social?",
            "Sua bio, interesses e jogos serão apagados deste servidor.",
          ),
          [
            row(
              btn(
                "sx:profile-delete-confirm",
                "Confirmar exclusão",
                D.ButtonStyle.Danger,
              ),
              btn("sx:profile", "Cancelar"),
            ),
          ],
        ),
      );
    if (action === "profile-delete-confirm") {
      await prisma.socialProfile.deleteMany({
        where: { guildId: i.guild.id, userId: i.user.id },
      });
      return refreshPanel(
        i,
        await require("./profiles").view(i.guild, i.user.id),
      );
    }
    if (action === "discover")
      return privateView(i, () =>
        require("./profiles").discover(
          i.guild,
          Number(arg) || 0,
          "",
          arg2 || "",
        ),
      );
    if (action === "profile-search")
      return i.showModal(
        form("sx-form:profile-search", "Encontrar pessoas", [
          { id: "query", label: "Interesse ou jogo", max: 40 },
        ]),
      );
    throw Error("Opção indisponível.");
  });
}
async function select(i) {
  return C.guarded(i, async () => {
    if (!i.guild) return;
    const [, action, arg] = i.customId.split(":"),
      value = i.values[0];
    if (action === "vote") {
      await i.deferReply({ flags: ephemeral });
      await A.respond(i.guild, arg, i.user.id, value);
      return i.editReply(
        "Seu voto foi salvo. O resultado foi atualizado na dinâmica.",
      );
    }
    await C.admin(i);
    if (action === "admin") return showAdmin(i, value);
    if (action === "channel") {
      const keys = [
        "panelChannelId",
        "dynamicsChannelId",
        "radioPanelChannelId",
        "reviewChannelId",
      ];
      if (!keys.includes(arg)) throw Error("Destino inválido.");
      await C.channel(i.guild, value, {
        privateReview: arg === "reviewChannelId",
      });
      const data = { [arg]: value };
      if (arg === "panelChannelId")
        Object.assign(data, { panelMessageId: null, panelHash: null });
      if (arg === "radioPanelChannelId")
        Object.assign(data, {
          radioPanelMessageId: null,
          radioPanelHash: null,
        });
      await prisma.socialExperienceConfig.update({
        where: { guildId: i.guild.id },
        data,
      });
      return showAdmin(
        i,
        arg === "dynamicsChannelId"
          ? "dynamics"
          : arg === "radioPanelChannelId"
            ? "radio"
            : arg === "reviewChannelId"
              ? "anonymous"
              : "participation",
      );
    }
    if (action === "kinds") {
      if (i.values.some((k) => !A.KINDS[k]) || !i.values.length)
        throw Error("Escolha tipos válidos.");
      await prisma.socialExperienceConfig.update({
        where: { guildId: i.guild.id },
        data: { dynamicsKinds: i.values.join(",") },
      });
      return showAdmin(i);
    }
    if (action === "template")
      return refreshPanel(i, await templateView(i.guild, value));
    if (action === "radio-review") {
      const r = await prisma.socialRadioRequest.findUnique({
        where: { id: value },
      });
      if (!r || r.guildId !== i.guild.id || r.status !== "PENDING")
        throw Error("Pedido indisponível.");
      return refreshPanel(
        i,
        payload(
          embed(
            "Analisar pedido",
            `<@${r.userId}> pediu [${text(r.title, 100)}](${r.url}).\nConfira a música antes de aprovar.`,
          ),
          [
            row(
              btn(
                `sx-admin:radio-approve:${r.id}`,
                "Aprovar",
                D.ButtonStyle.Success,
              ),
              btn(
                `sx-admin:radio-reject:${r.id}`,
                "Recusar",
                D.ButtonStyle.Danger,
              ),
              btn("sx-admin:radio-queue:0", "Voltar"),
            ),
          ],
        ),
      );
    }
    throw Error("Opção inválida.");
  });
}
async function modal(i) {
  return C.guarded(i, async () => {
    if (!i.guild) return;
    const [, action, arg] = i.customId.split(":"),
      get = (k) => i.fields.getTextInputValue(k).trim();
    await C.member(i.guild, i.user.id);
    if (action === "post") {
      await i.deferReply({ flags: ephemeral });
      return i.editReply(
        await require("./posts").draft(
          i,
          i.fields.getUploadedFiles("media", true).first(),
          get("caption"),
        ),
      );
    }
    if (action === "answer") {
      await i.deferReply({ flags: ephemeral });
      await A.respond(i.guild, arg, i.user.id, get("content"));
      return i.editReply(
        "Resposta salva. A dinâmica já mostra sua participação.",
      );
    }
    if (action === "radio-request") {
      await i.deferReply({ flags: ephemeral });
      const r = await require("./radio").request(
        i.guild,
        i.user.id,
        get("url"),
      );
      return i.editReply(
        r.status === "PENDING"
          ? "Pedido enviado para aprovação da equipe."
          : "Pedido adicionado à fila da rádio.",
      );
    }
    if (action === "profile") {
      await require("./profiles").save(i.guild, i.user.id, {
        bio: get("bio"),
        interests: get("interests"),
        games: get("games"),
      });
      return refreshPanel(
        i,
        await require("./profiles").view(i.guild, i.user.id),
      );
    }
    if (action === "profile-search")
      return privateView(i, () =>
        require("./profiles").discover(i.guild, 0, get("query")),
      );
    await C.admin(i);
    if (action === "schedule") {
      const t = /^(\d{2}):(\d{2})$/.exec(get("time")),
        interval = Number(get("interval"));
      if (
        !t ||
        Number(t[1]) > 23 ||
        Number(t[2]) > 59 ||
        !Number.isInteger(interval) ||
        interval < 1 ||
        interval > 7
      )
        throw Error(
          "Informe HH:MM entre 00:00 e 23:59 e um intervalo de 1 a 7 dias.",
        );
      await prisma.socialExperienceConfig.update({
        where: { guildId: i.guild.id },
        data: {
          dynamicsHour: Number(t[1]),
          dynamicsMinute: Number(t[2]),
          dynamicsIntervalDays: interval,
        },
      });
      return showAdmin(i);
    }
    if (action === "radio-limits") {
      const limit = Number(get("limit")),
        cooldown = Number(get("cooldown"));
      if (
        !Number.isInteger(limit) ||
        limit < 1 ||
        limit > 10 ||
        !Number.isInteger(cooldown) ||
        cooldown < 30 ||
        cooldown > 3600
      )
        throw Error("Use de 1 a 10 pedidos e intervalo de 30 a 3600 segundos.");
      await prisma.socialExperienceConfig.update({
        where: { guildId: i.guild.id },
        data: { requestsLimit: limit, requestsCooldown: cooldown },
      });
      return showAdmin(i, "radio");
    }
    if (action === "template") {
      const data = A.templateData(
        get("kind").toUpperCase(),
        get("prompt"),
        get("options").split("\n"),
      );
      let t;
      if (arg === "new") {
        if (
          (await prisma.socialActivityTemplate.count({
            where: { guildId: i.guild.id },
          })) >= 100
        )
          throw Error("Limite de 100 propostas por servidor.");
        t = await prisma.socialActivityTemplate.create({
          data: { guildId: i.guild.id, ...data },
        });
      } else {
        t = await prisma.socialActivityTemplate.findUnique({
          where: { id: arg },
        });
        if (!t || t.guildId !== i.guild.id)
          throw Error("Proposta não encontrada.");
        t = await prisma.socialActivityTemplate.update({
          where: { id: arg },
          data,
        });
      }
      return refreshPanel(i, await templateView(i.guild, t.id));
    }
    throw Error("Formulário inválido.");
  });
}
module.exports = {
  adminButton,
  memberButton,
  select,
  modal,
  showAdmin,
  templateView,
  queueView,
};
