"use strict";
const {
  prisma,
  config,
  btn,
  row,
  text,
  embed,
  payload,
  locked,
  member,
} = require("./common");
const radio = () => require("../radio/service");
async function request(guild, userId, input) {
  return locked(`request:${guild.id}:${userId}`, async () => {
    await member(guild, userId);
    const c = await config(guild.id);
    if (!c.requestsEnabled)
      throw Error("Os pedidos de música estão desativados.");
    const videoId = radio().extractYouTubeVideoId(input);
    if (!videoId) throw Error("Envie um link de vídeo do YouTube válido.");
    const active = await prisma.socialRadioRequest.count({
      where: {
        guildId: guild.id,
        userId,
        status: { in: ["PENDING", "APPROVED", "PLAYING"] },
      },
    });
    if (active >= c.requestsLimit)
      throw Error(
        `Você já tem ${c.requestsLimit} pedidos na fila. Aguarde a reprodução.`,
      );
    const last = await prisma.socialRadioRequest.findFirst({
      where: { guildId: guild.id, userId },
      orderBy: { createdAt: "desc" },
    });
    if (
      last &&
      Date.now() - last.createdAt.getTime() < c.requestsCooldown * 1000
    )
      throw Error(`Aguarde ${c.requestsCooldown}s entre pedidos.`);
    if (
      await prisma.socialRadioRequest.findFirst({
        where: {
          guildId: guild.id,
          videoId,
          status: { in: ["PENDING", "APPROVED", "PLAYING"] },
        },
      })
    )
      throw Error("Esta música já está na fila.");
    return prisma.socialRadioRequest.create({
      data: {
        guildId: guild.id,
        userId,
        videoId,
        url: `https://www.youtube.com/watch?v=${videoId}`,
        title: `YouTube · ${videoId}`,
        status: c.requestsModerated ? "PENDING" : "APPROVED",
      },
    });
  });
}
async function claimNext(guildId) {
  const c = await config(guildId);
  if (!c.requestsEnabled) return null;
  for (let n = 0; n < 3; n++) {
    const next = await prisma.socialRadioRequest.findFirst({
      where: { guildId, status: "APPROVED" },
      orderBy: { createdAt: "asc" },
    });
    if (!next) return null;
    const claim = await prisma.socialRadioRequest.updateMany({
      where: { id: next.id, guildId, status: "APPROVED" },
      data: { status: "PLAYING" },
    });
    if (claim.count)
      return { ...next, requestId: next.id, requesterId: next.userId };
  }
  return null;
}
async function finish(track, status = "PLAYED", error = null) {
  if (track?.requestId)
    await prisma.socialRadioRequest.updateMany({
      where: { id: track.requestId, status: "PLAYING" },
      data: { status, error: error ? String(error).slice(0, 500) : null },
    });
}
async function vote(guild, userId, expectedToken) {
  return locked(`skip:${guild.id}`, async () => {
    await member(guild, userId);
    const c = await config(guild.id);
    if (!c.requestsEnabled)
      throw Error("A participação na rádio está desativada.");
    const state = await radio().getRadioRuntimeStatus(guild.id),
      rc = await radio().getRadioConfig(guild.id),
      voice = rc.voiceChannelId
        ? await guild.channels.fetch(rc.voiceChannelId).catch(() => null)
        : null;
    if (
      !state.playToken ||
      state.playToken !== expectedToken ||
      state.playerStatus !== "playing"
    )
      throw Error("A faixa mudou ou a rádio está parada. Atualize o painel.");
    const listeners = [...(voice?.members?.values() || [])].filter(
      (m) =>
        !m.user.bot &&
        !m.voice?.deaf &&
        !m.voice?.serverDeaf &&
        !m.voice?.selfDeaf,
    );
    if (!listeners.some((m) => m.id === userId))
      throw Error("Entre na call da rádio e ative o áudio para votar.");
    await prisma.socialRadioVote.upsert({
      where: {
        guildId_playToken_userId: {
          guildId: guild.id,
          playToken: expectedToken,
          userId,
        },
      },
      create: { guildId: guild.id, playToken: expectedToken, userId },
      update: {},
    });
    const votes = await prisma.socialRadioVote.count({
        where: {
          guildId: guild.id,
          playToken: expectedToken,
          userId: { in: listeners.map((m) => m.id) },
        },
      }),
      needed = Math.floor(listeners.length / 2) + 1;
    let skipped = false;
    if (votes >= needed) {
      if (
        (await radio().getRadioRuntimeStatus(guild.id)).playToken !==
        expectedToken
      )
        throw Error("A faixa já mudou.");
      skipped = await radio().skipRadioTrack(guild.id);
    }
    return { votes, needed, skipped };
  });
}
async function view(guild) {
  const [s, c, q] = await Promise.all([
    radio().getRadioRuntimeStatus(guild.id),
    config(guild.id),
    prisma.socialRadioRequest.findMany({
      where: { guildId: guild.id, status: "APPROVED" },
      orderBy: { createdAt: "asc" },
      take: 5,
    }),
  ]);
  const e = embed(
    "Rádio 24h",
    s.currentTrack
      ? `**Tocando agora**\n${text(s.currentTrack.title, 150)}${s.currentTrack.requesterId ? `\nPedido de <@${s.currentTrack.requesterId}>` : ""}`
      : "A rádio está parada. A equipe pode iniciar a reprodução.",
  ).addFields(
    {
      name: "Próximos pedidos",
      value:
        q
          .map(
            (r, n) =>
              `${n + 1}. [${text(r.title, 100)}](${r.url}) · <@${r.userId}>`,
          )
          .join("\n") ||
        "Nenhum pedido aprovado. A playlist do servidor continua normalmente.",
    },
    {
      name: "Como participar",
      value: c.requestsEnabled
        ? `Até ${c.requestsLimit} pedidos por pessoa · ${c.requestsModerated ? "Aprovação da equipe" : "Entrada direta na fila"}\nVotação para pular: maioria dos ouvintes presentes e com áudio ativado.`
        : "Pedidos de música desativados neste servidor.",
    },
  );
  return payload(e, [
    row(
      btn("sx:radio-request", "Pedir música", 2, !c.requestsEnabled),
      btn(
        `sx:radio-vote:${s.playToken || "stopped"}`,
        "Votar para pular",
        2,
        !c.requestsEnabled || !s.playToken,
      ),
      btn("sx:radio-refresh", "Atualizar"),
      btn("sx:radio-mine", "Meus pedidos"),
    ),
  ]);
}
async function review(guild, id, actorId, approve) {
  const r = await prisma.socialRadioRequest.findUnique({ where: { id } });
  if (!r || r.guildId !== guild.id || r.status !== "PENDING")
    throw Error("Pedido já analisado ou indisponível.");
  return prisma.socialRadioRequest.updateMany({
    where: { id, guildId: guild.id, status: "PENDING" },
    data: { status: approve ? "APPROVED" : "REJECTED", reviewerId: actorId },
  });
}
async function myRequests(guild, userId) {
  const q = await prisma.socialRadioRequest.findMany({
    where: { guildId: guild.id, userId },
    orderBy: { createdAt: "desc" },
    take: 10,
  });
  const labels = {
    PENDING: "Aguardando aprovação",
    APPROVED: "Na fila",
    PLAYING: "Tocando",
    PLAYED: "Reproduzida",
    FAILED: "Falhou",
    REJECTED: "Recusada",
    CANCELLED: "Cancelada",
  };
  return payload(
    embed(
      "Meus pedidos",
      q
        .map(
          (r) =>
            `[${text(r.title, 100)}](${r.url}) · ${labels[r.status] || r.status}${r.error ? "\n" + text(r.error, 150) : ""}`,
        )
        .join("\n\n") || "Você ainda não fez pedidos.",
    ),
    [row(btn("sx:radio-refresh", "Voltar à rádio"))],
  );
}
module.exports = { request, claimNext, finish, vote, view, review, myRequests };
