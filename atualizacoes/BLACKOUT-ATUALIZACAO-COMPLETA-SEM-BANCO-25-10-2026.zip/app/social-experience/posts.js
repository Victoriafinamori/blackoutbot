"use strict";
const { D, prisma, btn, row, member, ephemeral } = require("./common");
const social = require("../social/service"),
  media = require("../social/media");
function kind(file) {
  const ext = (file.name || "").split(".").pop().toLowerCase();
  if (["mp4", "mov", "webm", "m4v"].includes(ext)) return "VIDEO";
  if (ext === "gif") return "GIF";
  if (["png", "jpg", "jpeg", "webp", "avif"].includes(ext)) return "IMAGE";
  throw Error("Envie uma imagem PNG/JPG/WEBP/GIF ou vídeo MP4/WEBM/MOV.");
}
async function draft(i, file, content) {
  const c = await social.socialConfig(i.guild.id);
  if (!c.enabled || !c.instaChannelId)
    throw Error("O INSTA está desativado ou ainda não possui canal.");
  await member(i.guild, i.user.id);
  if (!file || file.size > 25 * 1024 * 1024)
    throw Error("Envie um arquivo de até 25 MB.");
  if (content.length > c.maxCaptionLength)
    throw Error(`A legenda pode ter até ${c.maxCaptionLength} caracteres.`);
  const k = kind(file);
  if (!c[{ IMAGE: "allowImages", GIF: "allowGifs", VIDEO: "allowVideos" }[k]])
    throw Error("Este formato está desativado neste servidor.");
  const d = await prisma.socialSubmission.create({
    data: {
      guildId: i.guild.id,
      authorId: i.user.id,
      kind: "INSTA",
      content,
      mediaUrl: file.url,
      mediaName: file.name,
      mediaType: k,
      sourceMessageId: i.id,
      expiresAt: new Date(Date.now() + 10 * 60000),
    },
  });
  const p = {
    id: d.id,
    authorId: i.user.id,
    publicId: "PRÉVIA",
    content,
    mediaUrl: file.url,
    mediaType: k,
    likesCount: 0,
    commentsCount: 0,
  };
  const view = media.publicationPayload(c, p, await member(i.guild, i.user.id));
  const card = view.components[0];
  card.components.at(-1).components.forEach((b) => b.setDisabled(true));
  card.addActionRowComponents(
    row(
      btn(
        `sx:post-confirm:${d.id}`,
        "Confirmar publicação",
        D.ButtonStyle.Success,
      ),
      btn(`sx:post-cancel:${d.id}`, "Cancelar", D.ButtonStyle.Danger),
    ),
  );
  return { ...view, flags: D.MessageFlags.IsComponentsV2 };
}
async function confirm(i, id, cancel = false) {
  return require("./common").locked(
    `posts:${i.guild.id}:${i.user.id}`,
    async () => {
      const d = await prisma.socialSubmission.findUnique({ where: { id } });
      if (
        !d ||
        d.guildId !== i.guild.id ||
        d.authorId !== i.user.id ||
        d.kind !== "INSTA" ||
        d.status !== "DRAFT" ||
        d.expiresAt <= new Date()
      )
        throw Error(
          "Esta prévia expirou ou já foi confirmada. Abra uma nova publicação.",
        );
      const claim = await prisma.socialSubmission.updateMany({
        where: { id, status: "DRAFT" },
        data: { status: cancel ? "CANCELLED" : "PROCESSING" },
      });
      if (!claim.count) throw Error("Esta prévia já foi utilizada.");
      if (cancel) return finish(i, "Publicação cancelada.");
      try {
        const c = await social.socialConfig(i.guild.id),
          ch = await require("./common").channel(i.guild, c.instaChannelId);
        if (!c.enabled) throw Error("O INSTA foi desativado.");
        const actor = await member(i.guild, i.user.id);
        const warnings = [];
        const message = {
          id: d.sourceMessageId || i.id,
          guild: i.guild,
          author: actor.user,
          member: actor,
          channel: ch,
          channelId: ch.id,
          content: d.content,
          attachments: new D.Collection([
            [
              "media",
              {
                id: "media",
                url: d.mediaUrl,
                name: d.mediaName,
                size: 0,
                contentType:
                  d.mediaType === "VIDEO"
                    ? "video/mp4"
                    : d.mediaType === "GIF"
                      ? "image/gif"
                      : "image/png",
              },
            ],
          ]),
          reply: async (s) => {
            warnings.push(s);
            return null;
          },
          delete: async () => null,
        };
        const handled = await social.createSocialPublication(message);
        const p = await prisma.socialPublication.findFirst({
          where: {
            guildId: i.guild.id,
            sourceMessageId: message.id,
            status: "ACTIVE",
          },
        });
        if (!handled || !p)
          throw Error(
            warnings[0] ||
              "Sua publicação não foi aceita pelas regras do servidor.",
          );
        await prisma.socialSubmission.update({
          where: { id },
          data: { status: "PUBLISHED", resultId: p.id },
        });
        return finish(
          i,
          `Publicação confirmada.\n[Ver publicação](https://discord.com/channels/${p.guildId}/${p.channelId}/${p.messageId})`,
        );
      } catch (e) {
        await prisma.socialSubmission.update({
          where: { id },
          data: { status: "FAILED", error: String(e.message).slice(0, 500) },
        });
        throw e;
      }
    },
  );
}
async function finish(i, s) {
  const p = {
    flags: D.MessageFlags.IsComponentsV2,
    components: [
      new D.ContainerBuilder()
        .setAccentColor(0xd71935)
        .addTextDisplayComponents(new D.TextDisplayBuilder().setContent(s)),
    ],
    allowedMentions: { parse: [] },
  };
  return i.deferred || i.replied ? i.editReply(p) : i.update(p);
}
async function mine(guild, userId, page = 0) {
  const where = { guildId: guild.id, authorId: userId, status: "ACTIVE" },
    count = await prisma.socialPublication.count({ where }),
    p = Math.max(
      0,
      Math.min(Number(page) || 0, Math.max(0, Math.ceil(count / 5) - 1)),
    );
  const posts = await prisma.socialPublication.findMany({
    where,
    orderBy: { createdAt: "desc" },
    skip: p * 5,
    take: 5,
  });
  return require("./common").payload(
    require("./common")
      .embed(
        "Minhas publicações",
        posts
          .map(
            (x) =>
              `**${x.publicId}** · ${x.likesCount} curtidas · ${x.commentsCount} comentários\n${require("./common").text(x.content || "Publicação com mídia", 200)}\n[Ver publicação](https://discord.com/channels/${x.guildId}/${x.channelId}/${x.messageId})`,
          )
          .join("\n\n") || "Você ainda não tem publicações neste servidor.",
      )
      .setFooter({ text: `Página ${p + 1} · ${count} publicações` }),
    [
      row(
        btn(`sx:mine:${p - 1}`, "Anterior", 2, p === 0),
        btn(`sx:mine:${p + 1}`, "Próxima", 2, (p + 1) * 5 >= count),
      ),
    ],
  );
}
module.exports = { draft, confirm, mine, kind };
