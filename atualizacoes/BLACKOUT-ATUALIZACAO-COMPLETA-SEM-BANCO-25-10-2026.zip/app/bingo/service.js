"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getBingoConfig = getBingoConfig;
exports.updateBingoConfig = updateBingoConfig;
exports.getCurrentMatch = getCurrentMatch;
exports.getMatchById = getMatchById;
exports.createMatch = createMatch;
exports.setMatchMessage = setMatchMessage;
exports.pauseMatch = pauseMatch;
exports.resumeMatch = resumeMatch;
exports.endMatch = endMatch;
exports.getDraws = getDraws;
exports.drawNumber = drawNumber;
exports.getPlayerCard = getPlayerCard;
exports.getPlayerCards = getPlayerCards;
exports.getAllActiveCardsForPlayer = getAllActiveCardsForPlayer;
exports.getActiveCardForPlayer = getActiveCardForPlayer;
exports.generateCardNumbers = generateCardNumbers;
exports.createCardForPlayer = createCardForPlayer;
exports.registerCard = registerCard;
exports.createPaidCards = createPaidCards;
exports.createOrder = createOrder;
exports.getOrder = getOrder;
exports.getOrderByChannel = getOrderByChannel;
exports.markOrderDelivered = markOrderDelivered;
exports.markOrderCancelled = markOrderCancelled;
exports.checkWinningCard = checkWinningCard;
exports.recordWinnerAttempt = recordWinnerAttempt;
const prisma_1 = require("../database/prisma");
const types_1 = require("./types");
// -----------------------------------------------------------------------
// Configuração (painel de cartelas)
// -----------------------------------------------------------------------
async function getBingoConfig(guildId) {
    return prisma_1.prisma.bingoConfig.upsert({
        where: { guildId },
        update: {},
        create: { guildId },
    });
}
async function updateBingoConfig(guildId, data) {
    await getBingoConfig(guildId);
    return prisma_1.prisma.bingoConfig.update({ where: { guildId }, data });
}
// -----------------------------------------------------------------------
// Partida
// -----------------------------------------------------------------------
// Só existe uma partida "em jogo" (não encerrada) por servidor.
async function getCurrentMatch(guildId) {
    return prisma_1.prisma.bingoMatch.findFirst({
        where: { guildId, status: { in: ["EM_ANDAMENTO", "PAUSADA"] } },
        orderBy: { createdAt: "desc" },
    });
}
async function getMatchById(matchId) {
    return prisma_1.prisma.bingoMatch.findUnique({ where: { id: matchId } });
}
async function createMatch(guildId, channelId, startedById) {
    return require("../games-chat/experience/common").lock("bingo:" + guildId, () => prisma_1.prisma.$transaction(async (tx) => {
        if (await tx.bingoMatch.findFirst({
            where: { guildId, status: { in: ["EM_ANDAMENTO", "PAUSADA"] } },
        }))
            throw Error("Já existe uma partida em andamento.");
        const last = await tx.bingoMatch.findFirst({
            where: { guildId },
            orderBy: { number: "desc" },
        }), match = await tx.bingoMatch.create({
            data: {
                guildId,
                channelId,
                number: (last?.number || 0) + 1,
                startedById,
                status: "EM_ANDAMENTO",
            },
        });
        await tx.bingoCard.updateMany({
            where: { guildId, matchId: null },
            data: { matchId: match.id },
        });
        return match;
    }));
}
async function setMatchMessage(matchId, messageId) {
    return prisma_1.prisma.bingoMatch.update({
        where: { id: matchId },
        data: { messageId },
    });
}
async function pauseMatch(matchId) {
    const community = await prisma_1.prisma.bingoExperienceState.findUnique({
        where: { matchId },
    });
    if (community) {
        await require("./community").pause(community.guildId, matchId);
        return prisma_1.prisma.bingoMatch.findUniqueOrThrow({ where: { id: matchId } });
    }
    return prisma_1.prisma.bingoMatch.update({
        where: { id: matchId },
        data: { status: "PAUSADA" },
    });
}
async function resumeMatch(matchId) {
    const community = await prisma_1.prisma.bingoExperienceState.findUnique({
        where: { matchId },
    });
    if (community) {
        await require("./community").resume(community.guildId, matchId);
        return prisma_1.prisma.bingoMatch.findUniqueOrThrow({ where: { id: matchId } });
    }
    return prisma_1.prisma.bingoMatch.update({
        where: { id: matchId },
        data: { status: "EM_ANDAMENTO" },
    });
}
async function endMatch(matchId) {
    const community = await prisma_1.prisma.bingoExperienceState.findUnique({
        where: { matchId },
    });
    if (community) {
        await require("./community").end(community.guildId, matchId);
        return prisma_1.prisma.bingoMatch.findUniqueOrThrow({ where: { id: matchId } });
    }
    return prisma_1.prisma.bingoMatch.update({
        where: { id: matchId },
        data: { status: "ENCERRADA", endedAt: new Date() },
    });
}
// -----------------------------------------------------------------------
// Sorteio
// -----------------------------------------------------------------------
async function getDraws(matchId) {
    return prisma_1.prisma.bingoDraw.findMany({
        where: { matchId },
        orderBy: { order: "asc" },
    });
}
async function drawNumber(matchId) {
    const community = await prisma_1.prisma.bingoExperienceState.findUnique({
        where: { matchId },
    });
    if (community)
        return require("./community").draw(community.guildId, matchId);
    return require("../games-chat/experience/common").lock("bingo-draw:" + matchId, () => prisma_1.prisma.$transaction(async (tx) => {
        const match = await tx.bingoMatch.findUnique({
            where: { id: matchId },
        });
        if (!match || match.status !== "EM_ANDAMENTO")
            throw Error("A partida precisa estar em andamento para sortear.");
        const existing = await tx.bingoDraw.findMany({
            where: { matchId },
            select: { number: true },
        }), used = new Set(existing.map((d) => d.number)), remaining = Array.from({ length: 75 }, (_, i) => i + 1).filter((n) => !used.has(n));
        if (!remaining.length)
            throw Error("Todos os 75 números já foram sorteados nesta partida.");
        const number = remaining[require("node:crypto").randomInt(remaining.length)];
        return tx.bingoDraw.create({
            data: {
                matchId,
                number,
                letter: (0, types_1.letterFor)(number),
                order: existing.length + 1,
            },
        });
    }));
}
// -----------------------------------------------------------------------
// Cartelas (a criação é feita pelo bot de inscrição — aqui só consultamos)
// -----------------------------------------------------------------------
async function getPlayerCard(guildId, matchId, playerId) {
    return prisma_1.prisma.bingoCard.findFirst({ where: { guildId, matchId, playerId } });
}
// Todas as cartelas de um jogador em uma partida específica. Um jogador
// pode ter comprado várias (1, 3, 10...) — a validação de BINGO precisa
// checar TODAS, nunca só a primeira encontrada.
async function getPlayerCards(guildId, matchId, playerId) {
    return prisma_1.prisma.bingoCard.findMany({
        where: { guildId, matchId, playerId },
        orderBy: { cardNumber: "asc" },
    });
}
// Todas as cartelas "ativas" de um jogador: vinculadas à partida atual ou
// ainda soltas (compradas durante a semana, antes da próxima partida
// começar). Usado pelo reenvio de cartelas, que funciona a qualquer
// momento, com ou sem partida em andamento.
async function getAllActiveCardsForPlayer(guildId, playerId) {
    const match = await getCurrentMatch(guildId);
    return prisma_1.prisma.bingoCard.findMany({
        where: {
            guildId,
            playerId,
            OR: [{ matchId: null }, ...(match ? [{ matchId: match.id }] : [])],
        },
        orderBy: { cardNumber: "asc" },
    });
}
// Cartela "ativa" de um jogador: tanto uma já vinculada à partida atual
// quanto uma retirada durante a semana e ainda não vinculada (matchId
// nulo). Usado pelo painel de retirada, que funciona com ou sem partida
// em andamento.
async function getActiveCardForPlayer(guildId, playerId) {
    const match = await getCurrentMatch(guildId);
    return prisma_1.prisma.bingoCard.findFirst({
        where: {
            guildId,
            playerId,
            OR: [{ matchId: null }, ...(match ? [{ matchId: match.id }] : [])],
        },
    });
}
// Sorteia uma cartela clássica: cada coluna (B/I/N/G/O) recebe 5 números
// únicos dentro da sua faixa; o centro (índice 12) fica livre.
function randomUniqueInRange(min, max, count) {
    const pool = [];
    for (let n = min; n <= max; n++)
        pool.push(n);
    for (let i = pool.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [pool[i], pool[j]] = [pool[j], pool[i]];
    }
    return pool.slice(0, count);
}
function generateCardNumbers() {
    const columns = [
        randomUniqueInRange(1, 15, 5),
        randomUniqueInRange(16, 30, 5),
        randomUniqueInRange(31, 45, 5),
        randomUniqueInRange(46, 60, 5),
        randomUniqueInRange(61, 75, 5),
    ];
    const grid = new Array(25).fill(null);
    for (let row = 0; row < 5; row++) {
        for (let col = 0; col < 5; col++) {
            grid[row * 5 + col] = row * 5 + col === 12 ? null : columns[col][row];
        }
    }
    return grid;
}
// Gera e salva uma cartela nova para o jogador. Funciona com ou sem
// partida em andamento — se ainda não existe partida (ou ela ainda não
// começou a sortear), a cartela fica "solta" (matchId nulo) e é
// automaticamente vinculada assim que a próxima partida for iniciada
// (ver createMatch). Se a partida atual já estiver sorteando, bloqueia.
async function createCardForPlayer(guildId, playerId) {
    const match = await getCurrentMatch(guildId);
    if (match) {
        const drawCount = await prisma_1.prisma.bingoDraw.count({
            where: { matchId: match.id },
        });
        if (drawCount > 0)
            throw new Error("As cartelas já não podem mais ser retiradas: o sorteio da partida atual já começou.");
    }
    const count = await prisma_1.prisma.bingoCard.count({ where: { guildId } });
    const numbers = generateCardNumbers();
    return registerCard(guildId, match ? match.id : null, count + 1, playerId, numbers);
}
// Recebe uma cartela pronta (número, jogador e os 25 números da grade) e
// vincula à partida — ponto de integração para o bot de inscrição.
async function registerCard(guildId, matchId, cardNumber, playerId, numbers) {
    return prisma_1.prisma.bingoCard.create({
        data: {
            guildId,
            matchId,
            cardNumber,
            playerId,
            numbers: JSON.stringify(numbers),
        },
    });
}
// Gera N cartelas pagas de uma vez (sem o limite de 1-por-jogador da
// retirada gratuita — é usado depois que o pagamento é confirmado).
async function createPaidCards(guildId, playerId, quantity) {
    const community = await prisma_1.prisma.bingoExperienceState.findFirst({
        where: { guildId, phase: { in: ["LOBBY", "RUNNING", "PAUSED", "REVIEW"] } },
    });
    if (community)
        throw new Error("O Bingo comunitário está aberto. Este evento tem participação gratuita e não recebe cartelas de outros pedidos.");
    const match = await getCurrentMatch(guildId);
    if (match) {
        const drawCount = await prisma_1.prisma.bingoDraw.count({
            where: { matchId: match.id },
        });
        if (drawCount > 0)
            throw new Error("O sorteio da partida atual já começou — não é mais possível entregar cartelas para ela.");
    }
    const cards = [];
    for (let i = 0; i < quantity; i++) {
        const count = await prisma_1.prisma.bingoCard.count({ where: { guildId } });
        const numbers = generateCardNumbers();
        cards.push(await registerCard(guildId, match ? match.id : null, count + 1, playerId, numbers));
    }
    return cards;
}
// -----------------------------------------------------------------------
// Pedidos de compra (ticket de atendimento até a entrega)
// -----------------------------------------------------------------------
async function createOrder(guildId, buyerId, channelId, quantity, price) {
    return prisma_1.prisma.bingoOrder.create({
        data: { guildId, buyerId, channelId, quantity, price },
    });
}
async function getOrder(orderId) {
    return prisma_1.prisma.bingoOrder.findUnique({ where: { id: orderId } });
}
async function getOrderByChannel(channelId) {
    return prisma_1.prisma.bingoOrder.findFirst({
        where: { channelId },
        orderBy: { createdAt: "desc" },
    });
}
async function markOrderDelivered(orderId, staffId) {
    return prisma_1.prisma.bingoOrder.update({
        where: { id: orderId },
        data: {
            status: "ENTREGUE",
            deliveredAt: new Date(),
            deliveredById: staffId,
        },
    });
}
async function markOrderCancelled(orderId, staffId) {
    return prisma_1.prisma.bingoOrder.update({
        where: { id: orderId },
        data: { status: "CANCELADO", cancelledById: staffId },
    });
}
// Cartela 5x5 clássica, índice 12 (centro) é o espaço livre. Vitória =
// qualquer linha, coluna ou uma das duas diagonais totalmente sorteada.
function checkWinningCard(numbers, drawnNumbers) {
    const marked = numbers.map((n) => n === null || drawnNumbers.has(n));
    const lines = [];
    for (let row = 0; row < 5; row++)
        lines.push([0, 1, 2, 3, 4].map((col) => row * 5 + col));
    for (let col = 0; col < 5; col++)
        lines.push([0, 1, 2, 3, 4].map((row) => row * 5 + col));
    lines.push([0, 6, 12, 18, 24]);
    lines.push([4, 8, 12, 16, 20]);
    return lines.some((line) => line.every((index) => marked[index]));
}
async function recordWinnerAttempt(matchId, cardId, playerId, valid) {
    return prisma_1.prisma.bingoWinner.create({
        data: { matchId, cardId, playerId, valid },
    });
}
