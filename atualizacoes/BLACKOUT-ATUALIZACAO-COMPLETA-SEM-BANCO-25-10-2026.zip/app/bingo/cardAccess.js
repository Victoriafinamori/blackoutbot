"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.view = view;
exports.execute = execute;
const common_1 = require("../games-chat/experience/common");
const service_1 = require("./service");
const views_1 = require("./views");
async function view(guild, userId, page = 0) {
    const cards = await (0, service_1.getAllActiveCardsForPlayer)(guild.id, userId), match = await (0, service_1.getCurrentMatch)(guild.id);
    if (!cards.length)
        return (0, common_1.payload)((0, common_1.embed)("Suas cartelas do Bingo", "Você ainda não possui cartelas registradas para a partida atual ou a próxima partida. Consulte o painel de inscrições da comunidade."));
    const n = Math.max(0, Math.min(Number(page) || 0, cards.length - 1)), card = cards[n], draws = card.matchId && card.matchId === match?.id
        ? await (0, service_1.getDraws)(card.matchId)
        : [], e = (0, views_1.buildCardEmbed)(card, new Set(draws.map((d) => d.number))).setFooter({
        text: `Só você vê · ${n + 1}/${cards.length} · ${card.matchId ? "Cartela da partida" : "Aguardando a próxima partida"}`,
    });
    return (0, common_1.payload)(e, [
        (0, common_1.row)((0, common_1.button)(`bingo-card-view:${n}`, "Atualizar"), (0, common_1.button)(`bingo-card-view:${n - 1}`, "Anterior", 2, n === 0), (0, common_1.button)(`bingo-card-view:${n + 1}`, "Próxima", 2, n === cards.length - 1)),
    ]);
}
async function execute(i) {
    return (0, common_1.guard)(i, async () => {
        if (!i.guild)
            return;
        await (0, common_1.member)(i.guild, i.user.id);
        const page = Number(i.customId.split(":")[1]) || 0;
        if (i.message?.flags?.has?.(common_1.D.MessageFlags.Ephemeral)) {
            await i.deferUpdate();
            return i.editReply(await view(i.guild, i.user.id, page));
        }
        await i.deferReply({ flags: common_1.D.MessageFlags.Ephemeral });
        return i.editReply(await view(i.guild, i.user.id, page));
    });
}
