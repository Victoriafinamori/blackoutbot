"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = exports.OBJECTIVES = void 0;
exports.patterns = patterns;
exports.progress = progress;
exports.load = load;
exports.create = create;
exports.join = join;
exports.leave = leave;
exports.start = start;
exports.pause = pause;
exports.resume = resume;
exports.end = end;
exports.draw = draw;
exports.check = check;
exports.refresh = refresh;
exports.tick = tick;
const node_crypto_1 = require("node:crypto");
const common_1 = require("../games-chat/experience/common");
exports.OBJECTIVES = {
    ANY_LINE: "Uma linha, coluna ou diagonal",
    FULL_CARD: "Cartela cheia",
    FOUR_CORNERS: "Os quatro cantos",
};
const config = (guildId) => common_1.prisma.bingoExperienceConfig.upsert({
    where: { guildId },
    create: { guildId },
    update: {},
});
exports.config = config;
function patterns(objective) {
    if (objective === "FULL_CARD")
        return [Array.from({ length: 25 }, (_, i) => i)];
    if (objective === "FOUR_CORNERS")
        return [[0, 4, 20, 24]];
    if (objective !== "ANY_LINE")
        throw Error("Objetivo inválido.");
    return [
        ...Array.from({ length: 5 }, (_, r) => Array.from({ length: 5 }, (_, c) => r * 5 + c)),
        ...Array.from({ length: 5 }, (_, c) => Array.from({ length: 5 }, (_, r) => r * 5 + c)),
        [0, 6, 12, 18, 24],
        [4, 8, 12, 16, 20],
    ];
}
function progress(numbers, drawn, objective) {
    if (!Array.isArray(numbers) ||
        numbers.length !== 25 ||
        numbers.some((n, i) => i === 12
            ? n !== null
            : !Number.isInteger(n) || Number(n) < 1 || Number(n) > 75))
        throw Error("A cartela está inconsistente. Avise a equipe.");
    if (new Set(numbers.filter((n) => n !== null)).size !== 24 ||
        numbers.some((n, i) => n !== null &&
            (n < Math.floor((i % 5) * 15) + 1 || n > ((i % 5) + 1) * 15)))
        throw Error("A cartela está inconsistente. Avise a equipe.");
    const missing = patterns(objective).map((indices) => indices
        .map((i) => numbers[i])
        .filter((n) => n !== null && !drawn.has(n)));
    missing.sort((a, b) => a.length - b.length);
    return { won: missing[0].length === 0, missing: missing[0] };
}
async function load(guildId, matchId) {
    const [state, match] = await Promise.all([
        common_1.prisma.bingoExperienceState.findUnique({ where: { matchId } }),
        common_1.prisma.bingoMatch.findUnique({ where: { id: matchId } }),
    ]);
    if (!state ||
        !match ||
        state.guildId !== guildId ||
        match.guildId !== guildId)
        throw Error("Esta partida não pertence a este servidor ou não está disponível.");
    return { state, match };
}
async function nextCard(tx, guildId) {
    return ((await tx.bingoCard.findFirst({
        where: { guildId },
        orderBy: { cardNumber: "desc" },
    }))?.cardNumber + 1 || 1);
}
async function create(guild, actorId) {
    return (0, common_1.lock)("bingo:" + guild.id, async () => {
        const c = await (0, exports.config)(guild.id), ch = await (0, common_1.textChannel)(guild, c.channelId);
        if (!exports.OBJECTIVES[c.objective])
            throw Error("Escolha um objetivo válido.");
        const { match, state } = await common_1.prisma.$transaction(async (tx) => {
            if (await tx.bingoMatch.findFirst({
                where: {
                    guildId: guild.id,
                    status: { in: ["EM_ANDAMENTO", "PAUSADA"] },
                },
            }))
                throw Error("Já existe um Bingo aberto. Acompanhe ou encerre a partida atual.");
            const last = await tx.bingoMatch.findFirst({
                where: { guildId: guild.id },
                orderBy: { number: "desc" },
            }), match = await tx.bingoMatch.create({
                data: {
                    guildId: guild.id,
                    channelId: ch.id,
                    number: (last?.number || 0) + 1,
                    startedById: actorId,
                    status: "PAUSADA",
                },
            });
            const state = await tx.bingoExperienceState.create({
                data: {
                    guildId: guild.id,
                    matchId: match.id,
                    objective: c.objective,
                    minPlayers: c.minPlayers,
                    maxPlayers: c.maxPlayers,
                    automatic: c.automatic,
                    intervalSeconds: c.intervalSeconds,
                },
            });
            return { match, state };
        });
        let message;
        try {
            message = await ch.send(await require("./communityViews").publicView(guild, match.id));
            await common_1.prisma.bingoMatch.update({
                where: { id: match.id },
                data: { messageId: message.id },
            });
            return { match: { ...match, messageId: message.id }, state };
        }
        catch (e) {
            if (message)
                await message.delete().catch(() => null);
            await common_1.prisma.bingoExperienceState.update({
                where: { matchId: match.id },
                data: {
                    phase: "ENDED",
                    lastError: "Não foi possível publicar as inscrições.",
                },
            });
            await common_1.prisma.bingoMatch.update({
                where: { id: match.id },
                data: { status: "ENCERRADA", endedAt: new Date() },
            });
            throw e;
        }
    });
}
async function join(guild, matchId, userId) {
    await (0, common_1.member)(guild, userId);
    return (0, common_1.lock)("bingo:" + guild.id, async () => {
        const { state } = await load(guild.id, matchId);
        if (state.phase !== "LOBBY")
            throw Error("As inscrições foram encerradas. Acompanhe esta partida e entre na próxima.");
        return common_1.prisma.$transaction(async (tx) => {
            const existing = await tx.bingoCard.findFirst({
                where: { guildId: guild.id, matchId, playerId: userId },
            });
            if (existing)
                return existing;
            if ((await tx.bingoCard.count({ where: { guildId: guild.id, matchId } })) >=
                state.maxPlayers)
                throw Error("As vagas desta partida foram preenchidas.");
            const numbers = require("./service").generateCardNumbers();
            return tx.bingoCard.create({
                data: {
                    guildId: guild.id,
                    matchId,
                    playerId: userId,
                    cardNumber: await nextCard(tx, guild.id),
                    numbers: JSON.stringify(numbers),
                },
            });
        });
    });
}
async function leave(guild, matchId, userId) {
    return (0, common_1.lock)("bingo:" + guild.id, async () => {
        const { state } = await load(guild.id, matchId);
        if (state.phase !== "LOBBY")
            throw Error("A partida já começou. Sua cartela permanece registrada.");
        await common_1.prisma.bingoCard.deleteMany({
            where: { guildId: guild.id, matchId, playerId: userId },
        });
    });
}
async function start(guildId, matchId) {
    return (0, common_1.lock)("bingo:" + guildId, async () => {
        const { state } = await load(guildId, matchId);
        if (state.phase !== "LOBBY")
            throw Error("Esta partida já começou.");
        if ((await common_1.prisma.bingoCard.count({ where: { guildId, matchId } })) <
            state.minPlayers)
            throw Error(`Aguarde ao menos ${state.minPlayers} participantes para começar.`);
        await common_1.prisma.$transaction([
            common_1.prisma.bingoMatch.update({
                where: { id: matchId },
                data: { status: "EM_ANDAMENTO" },
            }),
            common_1.prisma.bingoExperienceState.update({
                where: { matchId },
                data: {
                    phase: "RUNNING",
                    nextDrawAt: state.automatic
                        ? new Date(Date.now() + state.intervalSeconds * 1000)
                        : null,
                    lastError: null,
                },
            }),
        ]);
    });
}
async function pause(guildId, matchId) {
    return (0, common_1.lock)("bingo:" + guildId, async () => {
        const { state } = await load(guildId, matchId);
        if (state.phase !== "RUNNING")
            throw Error("Esta rodada não está em andamento.");
        await common_1.prisma.$transaction([
            common_1.prisma.bingoMatch.update({
                where: { id: matchId },
                data: { status: "PAUSADA" },
            }),
            common_1.prisma.bingoExperienceState.update({
                where: { matchId },
                data: { phase: "PAUSED", nextDrawAt: null },
            }),
        ]);
    });
}
async function resume(guildId, matchId) {
    return (0, common_1.lock)("bingo:" + guildId, async () => {
        const { state } = await load(guildId, matchId);
        if (state.phase !== "PAUSED")
            throw Error("Conclua as inscrições ou a conferência antes de retomar.");
        await common_1.prisma.$transaction([
            common_1.prisma.bingoMatch.update({
                where: { id: matchId },
                data: { status: "EM_ANDAMENTO" },
            }),
            common_1.prisma.bingoExperienceState.update({
                where: { matchId },
                data: {
                    phase: "RUNNING",
                    nextDrawAt: state.automatic
                        ? new Date(Date.now() + state.intervalSeconds * 1000)
                        : null,
                },
            }),
        ]);
    });
}
async function end(guildId, matchId) {
    return (0, common_1.lock)("bingo:" + guildId, async () => {
        await load(guildId, matchId);
        await common_1.prisma.$transaction([
            common_1.prisma.bingoMatch.update({
                where: { id: matchId },
                data: { status: "ENCERRADA", endedAt: new Date() },
            }),
            common_1.prisma.bingoExperienceState.update({
                where: { matchId },
                data: { phase: "ENDED", nextDrawAt: null },
            }),
        ]);
    });
}
async function draw(guildId, matchId, scheduled = false) {
    return (0, common_1.lock)("bingo:" + guildId, async () => {
        const { state, match } = await load(guildId, matchId);
        if (state.phase !== "RUNNING" || match.status !== "EM_ANDAMENTO")
            throw Error("A partida precisa estar em andamento para sortear.");
        if (scheduled &&
            (!state.automatic || !state.nextDrawAt || state.nextDrawAt > new Date()))
            return null;
        return common_1.prisma.$transaction(async (tx) => {
            const draws = await tx.bingoDraw.findMany({
                where: { matchId },
                orderBy: { order: "asc" },
            }), used = new Set(draws.map((d) => d.number)), remaining = Array.from({ length: 75 }, (_, i) => i + 1).filter((n) => !used.has(n));
            if (!remaining.length)
                throw Error("Os 75 números já foram sorteados. Confira os vencedores ou encerre a partida.");
            const claim = await tx.bingoExperienceState.updateMany({
                where: { matchId, phase: "RUNNING", drawVersion: state.drawVersion },
                data: {
                    drawVersion: { increment: 1 },
                    nextDrawAt: state.automatic && remaining.length > 1
                        ? new Date(Date.now() + state.intervalSeconds * 1000)
                        : null,
                    lastError: null,
                },
            });
            if (!claim.count)
                throw Error("O sorteio foi atualizado por outra ação. Atualize o painel.");
            const number = remaining[(0, node_crypto_1.randomInt)(remaining.length)];
            return tx.bingoDraw.create({
                data: {
                    matchId,
                    number,
                    letter: require("./types").letterFor(number),
                    order: draws.length + 1,
                },
            });
        });
    });
}
async function check(guild, matchId, userId) {
    await (0, common_1.member)(guild, userId);
    return (0, common_1.lock)("bingo:" + guild.id, async () => {
        const { state } = await load(guild.id, matchId);
        if (!["RUNNING", "PAUSED", "REVIEW"].includes(state.phase))
            throw Error("Aguarde o início da partida para conferir sua cartela.");
        const mine = await common_1.prisma.bingoCard.findMany({
            where: { guildId: guild.id, matchId, playerId: userId },
        });
        if (!mine.length)
            throw Error("Você não tem uma cartela nesta partida.");
        const draws = await common_1.prisma.bingoDraw.findMany({ where: { matchId } }), drawn = new Set(draws.map((d) => d.number)), own = mine.map((c) => ({
            card: c,
            ...progress(JSON.parse(c.numbers), drawn, state.objective),
        }));
        if (!own.some((c) => c.won))
            return {
                won: false,
                missing: own.sort((a, b) => a.missing.length - b.missing.length)[0]
                    .missing,
                winners: [],
            };
        // Evaluate all registered cards against the same frozen draw: equal results count together.
        const all = await common_1.prisma.bingoCard.findMany({
            where: { guildId: guild.id, matchId },
        }), winners = all.filter((c) => progress(JSON.parse(c.numbers), drawn, state.objective).won);
        await common_1.prisma.$transaction(async (tx) => {
            await tx.bingoMatch.update({
                where: { id: matchId },
                data: { status: "PAUSADA" },
            });
            await tx.bingoExperienceState.update({
                where: { matchId },
                data: { phase: "REVIEW", nextDrawAt: null },
            });
            for (const c of winners) {
                const existing = await tx.bingoExperienceClaim.findUnique({
                    where: { matchId_cardId: { matchId, cardId: c.id } },
                });
                if (existing)
                    continue;
                await tx.bingoExperienceClaim.create({
                    data: {
                        guildId: guild.id,
                        matchId,
                        cardId: c.id,
                        playerId: c.playerId,
                        drawVersion: state.drawVersion,
                    },
                });
                await tx.bingoWinner.create({
                    data: { matchId, cardId: c.id, playerId: c.playerId, valid: true },
                });
            }
        });
        return { won: true, missing: [], winners };
    });
}
async function refresh(guild, matchId) {
    const { match } = await load(guild.id, matchId);
    if (!match.messageId)
        return;
    const ch = await (0, common_1.textChannel)(guild, match.channelId), message = await ch.messages.fetch(match.messageId).catch(() => null);
    if (message)
        await message.edit(await require("./communityViews").publicView(guild, matchId));
}
let ticking = false;
async function tick(client) {
    if (ticking)
        return;
    ticking = true;
    try {
        const states = await common_1.prisma.bingoExperienceState.findMany({
            where: {
                phase: "RUNNING",
                automatic: true,
                nextDrawAt: { lte: new Date() },
            },
        });
        for (const state of states) {
            const guild = client.guilds.cache.get(state.guildId);
            if (!guild)
                continue;
            try {
                await draw(guild.id, state.matchId, true);
                await refresh(guild, state.matchId);
            }
            catch (e) {
                if (e.code === "GAME_BUSY")
                    continue;
                await common_1.prisma.bingoExperienceState
                    .update({
                    where: { matchId: state.matchId },
                    data: {
                        phase: "PAUSED",
                        nextDrawAt: null,
                        lastError: String(e.message).slice(0, 500),
                    },
                })
                    .catch(() => null);
                await common_1.prisma.bingoMatch
                    .updateMany({
                    where: { id: state.matchId, status: "EM_ANDAMENTO" },
                    data: { status: "PAUSADA" },
                })
                    .catch(() => null);
                await refresh(guild, state.matchId).catch(() => null);
            }
        }
    }
    finally {
        ticking = false;
    }
}
