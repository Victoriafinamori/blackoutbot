"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.publicView = publicView;
exports.cardsView = cardsView;
exports.rulesView = rulesView;
exports.historyView = historyView;
exports.winnersView = winnersView;
exports.appearanceView = appearanceView;
exports.adminView = adminView;
const common_1 = require("../games-chat/experience/common");
const community_1 = require("./community");
const adminUi_1 = require("../utils/adminUi");
async function publicView(guild, matchId) {
    const { state, match } = await (0, community_1.load)(guild.id, matchId), c = await (0, community_1.config)(guild.id), [draws, count, claims] = await Promise.all([
        common_1.prisma.bingoDraw.findMany({
            where: { matchId },
            orderBy: { order: "asc" },
        }),
        common_1.prisma.bingoCard.count({ where: { guildId: guild.id, matchId } }),
        common_1.prisma.bingoExperienceClaim.findMany({
            where: { guildId: guild.id, matchId },
            orderBy: { createdAt: "asc" },
            take: 10,
        }),
    ]);
    const e = (0, common_1.embed)(c.title, c.description)
        .setColor(Number.isNaN(parseInt(c.color, 16)) ? 0xd71935 : parseInt(c.color, 16))
        .setFooter(c.footer ? { text: c.footer } : null), status = {
        LOBBY: "Inscrições abertas",
        RUNNING: "Em andamento",
        PAUSED: "Pausada pela equipe",
        REVIEW: "Vitória conferida · Sorteio pausado",
        ENDED: "Encerrada",
    };
    e.addFields({
        name: "Como participar",
        value: `Gratuito · 1 cartela por pessoa\nParticipantes: ${count}/${state.maxPlayers}`,
    }, {
        name: "Objetivo desta partida",
        value: community_1.OBJECTIVES[state.objective] || state.objective,
    }, { name: "Estado", value: status[state.phase] || state.phase });
    if (draws.length) {
        const last = draws[draws.length - 1];
        e.addFields({
            name: "Último número",
            value: `**${last.letter} — ${String(last.number).padStart(2, "0")}**`,
        }, {
            name: "Andamento",
            value: `${draws.length}/75 números\n${draws
                .slice(-5)
                .map((d) => `${d.letter}–${String(d.number).padStart(2, "0")}`)
                .join(" · ")}`,
        });
    }
    if (state.phase === "LOBBY")
        e.addFields({
            name: "Próximo passo",
            value: `Entre antes do início. A equipe abre a rodada quando houver ao menos ${state.minPlayers} participantes.`,
        });
    if (state.phase === "RUNNING")
        e.addFields({
            name: "Ritmo",
            value: state.automatic
                ? state.nextDrawAt
                    ? `Próximo número <t:${Math.floor(state.nextDrawAt.getTime() / 1000)}:R> · intervalo ${state.intervalSeconds}s`
                    : "Sorteios concluídos. Confira sua cartela."
                : "Sorteios conduzidos pela equipe.",
        });
    if (claims.length)
        e.addFields({
            name: "Vencedores conferidos",
            value: claims.map((c) => `<@${c.playerId}> · Cartela registrada`).join("\n") +
                (claims.length === 10
                    ? "\nA equipe pode consultar a lista completa."
                    : ""),
        });
    return (0, common_1.payload)(e, [
        (0, common_1.row)((0, common_1.button)(`bg:join:${matchId}`, "Participar", common_1.D.ButtonStyle.Primary, state.phase !== "LOBBY"), (0, common_1.button)(`bg:cards:${matchId}:0`, "Minha cartela"), (0, common_1.button)(`bg:check:${matchId}`, "Conferir bingo", common_1.D.ButtonStyle.Secondary, !["RUNNING", "PAUSED", "REVIEW"].includes(state.phase))),
        (0, common_1.row)((0, common_1.button)(`bg:history:${matchId}`, "Números sorteados"), (0, common_1.button)(`bg:rules:${matchId}`, "Como jogar")),
    ]);
}
async function cardsView(guild, matchId, userId, page = 0) {
    const { state } = await (0, community_1.load)(guild.id, matchId), cards = await common_1.prisma.bingoCard.findMany({
        where: { guildId: guild.id, matchId, playerId: userId },
        orderBy: { cardNumber: "asc" },
    });
    if (!cards.length)
        return (0, common_1.payload)((0, common_1.embed)("Você ainda não entrou nesta partida", state.phase === "LOBBY"
            ? "Participe para receber uma cartela gratuita."
            : "As inscrições terminaram. Você poderá entrar na próxima partida."), [
            (0, common_1.row)((0, common_1.button)(`bg:join:${matchId}`, "Participar", common_1.D.ButtonStyle.Primary, state.phase !== "LOBBY")),
        ]);
    const n = Math.max(0, Math.min(Number(page) || 0, cards.length - 1)), card = cards[n], draws = await common_1.prisma.bingoDraw.findMany({
        where: { matchId },
        orderBy: { order: "asc" },
    }), drawn = new Set(draws.map((d) => d.number)), numbers = JSON.parse(card.numbers), p = (0, community_1.progress)(numbers, drawn, state.objective), lines = [" B    I    N    G    O"];
    for (let r = 0; r < 5; r++)
        lines.push(Array.from({ length: 5 }, (_, c) => {
            const value = numbers[r * 5 + c];
            return value === null
                ? " ** "
                : drawn.has(value)
                    ? `[${String(value).padStart(2, "0")}]`
                    : ` ${String(value).padStart(2, "0")} `;
        }).join(" "));
    const last = draws[draws.length - 1], e = (0, common_1.embed)(`Sua cartela #${String(card.cardNumber).padStart(4, "0")}`, "```\n" + lines.join("\n") + "\n```")
        .addFields({ name: "Objetivo", value: community_1.OBJECTIVES[state.objective] }, {
        name: "Seu progresso",
        value: p.won
            ? "Você completou o objetivo. Use Conferir bingo."
            : `Faltam ${p.missing.length} números na melhor combinação: ${p.missing.map((x) => String(x).padStart(2, "0")).join(", ")}.`,
    }, {
        name: "Última consulta",
        value: `${last ? `${last.letter}–${String(last.number).padStart(2, "0")}` : "Nenhum número sorteado"}\n[ ] = sorteado · ** = centro livre\nUse Atualizar para acompanhar novos números.`,
    })
        .setFooter({
        text: `Só você vê esta cartela · ${n + 1}/${cards.length}`,
    });
    const actions = [
        (0, common_1.row)((0, common_1.button)(`bg:cards:${matchId}:${n}`, "Atualizar"), (0, common_1.button)(`bg:check:${matchId}`, "Conferir bingo", common_1.D.ButtonStyle.Primary, !["RUNNING", "PAUSED", "REVIEW"].includes(state.phase)), (0, common_1.button)(`bg:rules:${matchId}`, "Como jogar")),
    ];
    if (cards.length > 1)
        actions.push((0, common_1.row)((0, common_1.button)(`bg:cards:${matchId}:${n - 1}`, "Anterior", 2, n === 0), (0, common_1.button)(`bg:cards:${matchId}:${n + 1}`, "Próxima", 2, n === cards.length - 1)));
    if (state.phase === "LOBBY")
        actions.push((0, common_1.row)((0, common_1.button)(`bg:leave-confirm:${matchId}`, "Sair antes de começar")));
    return (0, common_1.payload)(e, actions);
}
async function rulesView(guild, matchId) {
    const { state } = await (0, community_1.load)(guild.id, matchId);
    return (0, common_1.payload)((0, common_1.embed)("Como jogar Bingo", `1. Participe enquanto as inscrições estiverem abertas.\n2. Consulte Minha cartela: os números sorteados aparecem marcados.\n3. Complete o objetivo: **${community_1.OBJECTIVES[state.objective]}**.\n4. Use Conferir bingo. A validação usa os números registrados da partida.\n\nAs cartelas aptas no mesmo sorteio são conferidas juntas. Você pode acessar a sua cartela pelo servidor, sem depender de DM.`), [
        (0, common_1.row)((0, common_1.button)(`bg:cards:${matchId}:0`, "Minha cartela", common_1.D.ButtonStyle.Primary)),
    ]);
}
async function historyView(guild, matchId) {
    await (0, community_1.load)(guild.id, matchId);
    const draws = await common_1.prisma.bingoDraw.findMany({
        where: { matchId },
        orderBy: { order: "asc" },
    });
    const e = (0, common_1.embed)("Números sorteados", `${draws.length}/75 números registrados.`);
    for (const letter of ["B", "I", "N", "G", "O"])
        e.addFields({
            name: letter,
            value: draws
                .filter((d) => d.letter === letter)
                .map((d) => String(d.number).padStart(2, "0"))
                .join(" · ") || "Ainda não sorteado.",
        });
    return (0, common_1.payload)(e, [(0, common_1.row)((0, common_1.button)(`bg:cards:${matchId}:0`, "Minha cartela"))]);
}
async function winnersView(guild, matchId, page = 0) {
    await (0, community_1.load)(guild.id, matchId);
    const where = { guildId: guild.id, matchId }, count = await common_1.prisma.bingoExperienceClaim.count({ where }), n = Math.max(0, Math.min(Number(page) || 0, Math.max(0, Math.ceil(count / 10) - 1))), claims = await common_1.prisma.bingoExperienceClaim.findMany({
        where,
        orderBy: { createdAt: "asc" },
        skip: n * 10,
        take: 10,
    });
    return (0, common_1.payload)((0, common_1.embed)("Conferência de vencedores", claims.length
        ? claims
            .map((c, k) => `${n * 10 + k + 1}. <@${c.playerId}> · Registro ${(0, common_1.clean)(c.cardId, 35)}`)
            .join("\n")
        : "Nenhuma vitória conferida nesta partida.").setFooter({ text: `${count} cartelas aptas · Página ${n + 1}` }), [
        (0, common_1.row)((0, common_1.button)(`bg-admin:winners:${matchId}:${n - 1}`, "Anterior", 2, n === 0), (0, common_1.button)(`bg-admin:winners:${matchId}:${n + 1}`, "Próxima", 2, (n + 1) * 10 >= count), (0, common_1.button)("bg-admin:home", "Voltar")),
    ]);
}
async function appearanceView(guild) {
    const c = await (0, community_1.config)(guild.id);
    return {
        content: "**Prévia · Bingo da comunidade**\nO visual salvo aparece abaixo. Aplicar ao painel publicado é uma ação separada.",
        embeds: [
            (0, common_1.embed)(c.title, c.description)
                .setColor(Number.isNaN(parseInt(c.color, 16))
                ? 0xd71935
                : parseInt(c.color, 16))
                .setFooter(c.footer ? { text: c.footer } : null),
        ],
        components: [
            (0, common_1.row)((0, common_1.button)("bg-admin:appearance-edit", "Editar mensagem"), (0, common_1.button)("bg-admin:publish-update", "Atualizar painel publicado", common_1.D.ButtonStyle.Primary), (0, common_1.button)("bg-admin:home", "Voltar")),
        ],
        allowedMentions: { parse: [] },
    };
}
async function adminView(guild) {
    const c = await (0, community_1.config)(guild.id), match = await common_1.prisma.bingoMatch.findFirst({
        where: { guildId: guild.id, status: { in: ["EM_ANDAMENTO", "PAUSADA"] } },
    }), state = match
        ? await common_1.prisma.bingoExperienceState.findUnique({
            where: { matchId: match.id },
        })
        : null;
    const e = (0, adminUi_1.adminEmbed)(guild, "staff")
        .setTitle("Bingo da comunidade")
        .setDescription("Inscrições gratuitas, uma cartela por participante e acesso pelo próprio servidor. As regras salvas são usadas na próxima partida.")
        .addFields({
        name: "Próximo evento",
        value: `Canal: ${c.channelId ? "<#" + c.channelId + ">" : "Não configurado"}\nObjetivo: ${community_1.OBJECTIVES[c.objective]}`,
    }, {
        name: "Participação e ritmo",
        value: `De ${c.minPlayers} a ${c.maxPlayers} participantes\n${c.automatic ? "Automático · " + c.intervalSeconds + " segundos entre números" : "Sorteio manual pela equipe"}`,
    }, {
        name: "Partida atual",
        value: state
            ? `#${match.number} · ${state.phase === "LOBBY" ? "Inscrições abertas" : state.phase === "RUNNING" ? "Em andamento" : state.phase === "PAUSED" ? "Pausada" : "Conferência de vencedores"}\n${await common_1.prisma.bingoCard.count({ where: { guildId: guild.id, matchId: state.matchId } })} participantes`
            : match
                ? "Há uma partida do fluxo anterior aberta. Finalize-a antes de abrir um Bingo comunitário."
                : "Nenhum Bingo aberto.",
    });
    if (state?.lastError)
        e.addFields({
            name: "Aviso da partida",
            value: (0, common_1.clean)(state.lastError, 500),
        });
    const rows = [
        (0, common_1.row)(new common_1.D.StringSelectMenuBuilder()
            .setCustomId("bg-select:objective")
            .setPlaceholder("Objetivo da próxima partida")
            .addOptions(Object.entries(community_1.OBJECTIVES).map(([value, label]) => ({
            value,
            label,
            default: c.objective === value,
        })))),
        (0, common_1.row)(new common_1.D.ChannelSelectMenuBuilder()
            .setCustomId("bg-select:channel")
            .setPlaceholder("Canal das inscrições")
            .addChannelTypes(common_1.D.ChannelType.GuildText)
            .setDefaultChannels(...(c.channelId ? [c.channelId] : []))),
        (0, common_1.row)((0, common_1.button)("bg-admin:rules", "Regras e ritmo"), (0, common_1.button)("bg-admin:appearance", "Mensagem e prévia"), (0, common_1.button)("bg-admin:create-confirm", "Abrir inscrições", common_1.D.ButtonStyle.Primary, Boolean(match) || !c.channelId)),
    ];
    if (state) {
        rows.push((0, common_1.row)((0, common_1.button)(`bg-admin:start:${state.matchId}`, "Iniciar rodada", common_1.D.ButtonStyle.Primary, state.phase !== "LOBBY"), (0, common_1.button)(`bg-admin:${state.phase === "PAUSED" ? "resume" : "pause"}:${state.matchId}`, state.phase === "PAUSED" ? "Retomar" : "Pausar", 2, !["RUNNING", "PAUSED"].includes(state.phase)), (0, common_1.button)(`bg-admin:draw:${state.matchId}`, "Sortear número", 2, state.phase !== "RUNNING"), (0, common_1.button)(`bg-admin:winners:${state.matchId}:0`, "Vencedores"), (0, common_1.button)(`bg-admin:end-confirm:${state.matchId}`, "Encerrar", common_1.D.ButtonStyle.Danger)));
    }
    rows.push((0, common_1.row)((0, common_1.button)("bg-admin:home", "Atualizar"), (0, common_1.button)("adm-bingo:menu", "Bingo geral"), (0, common_1.button)("adm-nav:staff", "Voltar a Jogos e eventos")));
    return { attachments: [], ...(0, common_1.payload)(e, rows) };
}
