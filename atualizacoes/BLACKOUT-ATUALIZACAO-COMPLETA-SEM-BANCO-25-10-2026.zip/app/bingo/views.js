"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildBingoPanel = buildBingoPanel;
exports.buildAnimationFrame = buildAnimationFrame;
exports.buildDrawResultFrame = buildDrawResultFrame;
exports.buildHistoryEmbed = buildHistoryEmbed;
exports.buildEncerrarConfirm = buildEncerrarConfirm;
exports.buildBingoValidEmbed = buildBingoValidEmbed;
exports.refreshMatchPanel = refreshMatchPanel;
exports.buildCardPanelMessage = buildCardPanelMessage;
exports.buildCardEmbed = buildCardEmbed;
exports.publishCardPanel = publishCardPanel;
exports.refreshCardPanel = refreshCardPanel;
exports.buildOrderTicketMessage = buildOrderTicketMessage;
exports.createOrderTicket = createOrderTicket;
exports.buildCardsDeliveryDM = buildCardsDeliveryDM;
const discord_js_1 = require("discord.js");
const types_1 = require("./types");
const service_1 = require("./service");
const tickets_1 = require("../utils/tickets");
const COLOR = 0xd20b20;
function statusLine(status) {
    if (status === "EM_ANDAMENTO")
        return "🟢 Em andamento";
    if (status === "PAUSADA")
        return "🟡 Partida pausada";
    return "🔴 Encerrada";
}
function matchLabel(number) {
    return `PARTIDA #${String(number).padStart(3, "0")}`;
}
// -----------------------------------------------------------------------
// Painel principal
// -----------------------------------------------------------------------
function buildBingoPanel(match, draws) {
    const last = draws[draws.length - 1];
    const lastLine = last
        ? `# ${last.letter} — ${String(last.number).padStart(2, "0")}`
        : "Nenhum número sorteado ainda.";
    const recent = draws
        .slice(-5)
        .map((d) => `${d.letter}-${String(d.number).padStart(2, "0")}`)
        .join(" · ") || "—";
    const embed = new discord_js_1.EmbedBuilder()
        .setColor(COLOR)
        .setDescription("🎱 **BINGO AUDAZ**\n\n" +
        `**${matchLabel(match.number)}**\n\n` +
        `**Último número sorteado**\n\n${lastLine}\n\n` +
        `**Números sorteados:** ${draws.length}/75\n\n` +
        `**Últimos sorteios:**\n${recent}\n\n` +
        `**Status:** ${statusLine(match.status)}`);
    const ended = match.status === "ENCERRADA";
    const paused = match.status === "PAUSADA";
    const row1 = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder()
        .setCustomId(types_1.BINGO_IDS.sortear)
        .setLabel("SORTEAR NÚMERO")
        .setStyle(discord_js_1.ButtonStyle.Success)
        .setDisabled(ended || paused || draws.length >= 75), paused
        ? new discord_js_1.ButtonBuilder()
            .setCustomId(types_1.BINGO_IDS.retomar)
            .setLabel("RETOMAR")
            .setStyle(discord_js_1.ButtonStyle.Primary)
            .setDisabled(ended)
        : new discord_js_1.ButtonBuilder()
            .setCustomId(types_1.BINGO_IDS.pausar)
            .setLabel("PAUSAR")
            .setStyle(discord_js_1.ButtonStyle.Secondary)
            .setDisabled(ended), new discord_js_1.ButtonBuilder()
        .setCustomId(types_1.BINGO_IDS.historico)
        .setLabel("HISTÓRICO")
        .setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder()
        .setCustomId(types_1.BINGO_IDS.encerrar)
        .setLabel("ENCERRAR")
        .setStyle(discord_js_1.ButtonStyle.Danger)
        .setDisabled(ended));
    const row2 = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder()
        .setCustomId(types_1.BINGO_IDS.jogarBingo)
        .setLabel("BINGO")
        .setStyle(discord_js_1.ButtonStyle.Primary)
        .setDisabled(ended));
    return { embeds: [embed], components: ended ? [] : [row1, row2] };
}
// -----------------------------------------------------------------------
// Animação do sorteio — quadros exibidos em sequência antes do painel final
// -----------------------------------------------------------------------
function buildAnimationFrame(text) {
    return {
        embeds: [
            new discord_js_1.EmbedBuilder()
                .setColor(COLOR)
                .setDescription(`🎱 **BINGO AUDAZ**\n\n${text}`),
        ],
        components: [],
    };
}
function buildDrawResultFrame(letter, number, total) {
    const embed = new discord_js_1.EmbedBuilder()
        .setColor(COLOR)
        .setDescription(`🎱 **NÚMERO SORTEADO**\n\n# ${letter} — ${String(number).padStart(2, "0")}\n\n**Sorteados:** ${total}/75`);
    return { embeds: [embed], components: [] };
}
// -----------------------------------------------------------------------
// Histórico
// -----------------------------------------------------------------------
function buildHistoryEmbed(draws) {
    const byLetter = {
        B: [],
        I: [],
        N: [],
        G: [],
        O: [],
    };
    for (const d of draws)
        byLetter[d.letter]?.push(d.number);
    for (const letter of Object.keys(byLetter))
        byLetter[letter].sort((a, b) => a - b);
    const embed = new discord_js_1.EmbedBuilder()
        .setColor(COLOR)
        .setTitle("Histórico da Partida")
        .setDescription(["B", "I", "N", "G", "O"]
        .map((letter) => `**${letter}:** ${byLetter[letter].length ? byLetter[letter].map((n) => String(n).padStart(2, "0")).join(" · ") : "—"}`)
        .join("\n"))
        .addFields({
        name: "Total",
        value: `${draws.length}/75 números sorteados.`,
    });
    return embed;
}
// -----------------------------------------------------------------------
// Confirmação de encerramento
// -----------------------------------------------------------------------
function buildEncerrarConfirm() {
    const embed = new discord_js_1.EmbedBuilder()
        .setColor(COLOR)
        .setDescription("**Deseja realmente encerrar esta partida?**");
    const row = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder()
        .setCustomId(types_1.BINGO_IDS.encerrarConfirmar)
        .setLabel("CONFIRMAR")
        .setStyle(discord_js_1.ButtonStyle.Danger), new discord_js_1.ButtonBuilder()
        .setCustomId(types_1.BINGO_IDS.encerrarCancelar)
        .setLabel("CANCELAR")
        .setStyle(discord_js_1.ButtonStyle.Secondary));
    return { embeds: [embed], components: [row] };
}
// -----------------------------------------------------------------------
// Resultado do BINGO
// -----------------------------------------------------------------------
// Recebe TODAS as cartelas vencedoras encontradas (um jogador pode ter
// mais de uma cartela e mais de uma bater ao mesmo tempo).
function buildBingoValidEmbed(playerId, cardNumbers) {
    const list = cardNumbers
        .map((n) => `#${String(n).padStart(4, "0")}`)
        .join(", ");
    const label = cardNumbers.length > 1 ? "Cartelas vencedoras" : "Cartela vencedora";
    return new discord_js_1.EmbedBuilder()
        .setColor(0x2ecc71)
        .setDescription("━━━━━━━━━━━━━━━━━━━━\n**BINGO!**\n━━━━━━━━━━━━━━━━━━━━\n\n" +
        `**Jogador:** <@${playerId}>\n**${label}:** ${list}\n\n**BINGO VÁLIDO**`);
}
// -----------------------------------------------------------------------
// Usado pelo painel administrativo (/adm) para refletir mudanças feitas
// por lá (pausar/retomar/encerrar) na mensagem pública da partida.
// -----------------------------------------------------------------------
async function refreshMatchPanel(guild, matchId) {
    const match = matchId
        ? await (0, service_1.getMatchById)(matchId)
        : await (0, service_1.getCurrentMatch)(guild.id);
    if (!match || match.guildId !== guild.id || !match.messageId)
        return;
    if (await require("../database/prisma").prisma.bingoExperienceState.findUnique({
        where: { matchId: match.id },
    }))
        return require("./community").refresh(guild, match.id);
    const channel = await guild.channels.fetch(match.channelId).catch(() => null);
    if (!channel?.isTextBased() || channel.isDMBased())
        return;
    const message = await channel.messages
        .fetch(match.messageId)
        .catch(() => null);
    if (!message)
        return;
    const draws = await (0, service_1.getDraws)(match.id);
    await message.edit(buildBingoPanel(match, draws)).catch(() => null);
}
// -----------------------------------------------------------------------
// Painel de retirada de cartelas
// -----------------------------------------------------------------------
function buildCardPanelMessage(config) {
    const p1q = config?.price1Qty ?? 1;
    const p1t = config?.price1Text ?? "R$ 2,00";
    const p3q = config?.price3Qty ?? 3;
    const p3t = config?.price3Text ?? "R$ 5,00";
    const p10q = config?.price10Qty ?? 10;
    const p10t = config?.price10Text ?? "R$ 10,00";
    const embed = new discord_js_1.EmbedBuilder()
        .setColor((config?.cardEmbedColor
        ? `#${config.cardEmbedColor}`
        : COLOR))
        .setTitle(config?.cardEmbedTitle || "🎫 CARTELAS DO BINGO")
        .setDescription(config?.cardEmbedDescription ||
        "Selecione abaixo o pacote que deseja comprar.\n\n" +
            `**${p1q} cartela** — ${p1t}\n**${p3q} cartelas** — ${p3t}\n**${p10q} cartelas** — ${p10t}\n\n` +
            "Ao selecionar, um canal privado é aberto para você combinar o pagamento com a staff. Assim que confirmado, suas cartelas chegam na sua DM.");
    if (config?.cardEmbedImage)
        embed.setImage(config.cardEmbedImage);
    if (config?.cardEmbedThumbnail)
        embed.setThumbnail(config.cardEmbedThumbnail);
    const select = new discord_js_1.StringSelectMenuBuilder()
        .setCustomId(types_1.BINGO_IDS.comprarSelect)
        .setPlaceholder("🎟️ Selecione a quantidade de cartelas...")
        .addOptions({ label: `${p1q} CARTELA — ${p1t}`, value: "1", emoji: "🎫" }, { label: `${p3q} CARTELAS — ${p3t}`, value: "3", emoji: "🎫" }, { label: `${p10q} CARTELAS — ${p10t}`, value: "10", emoji: "🎫" });
    const row = new discord_js_1.ActionRowBuilder().addComponents(select);
    const row2 = new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder()
        .setCustomId(types_1.BINGO_IDS.reenviarCartelas)
        .setLabel("Reenviar por DM")
        .setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder()
        .setCustomId("bingo-card-view:0")
        .setLabel("Ver minhas cartelas aqui")
        .setStyle(discord_js_1.ButtonStyle.Primary));
    return { embeds: [embed], components: [row, row2] };
}
// Grade 5x5 em formato de tabela (monoespaçado) para exibir a cartela do
// jogador, com os números já sorteados marcados.
function buildCardEmbed(card, drawnNumbers = new Set()) {
    const numbers = JSON.parse(card.numbers);
    const header = " B    I    N    G    O ";
    const rows = [header, "-".repeat(header.length)];
    for (let row = 0; row < 5; row++) {
        const cells = [0, 1, 2, 3, 4].map((col) => {
            const value = numbers[row * 5 + col];
            if (value === null)
                return " ** ";
            const marked = drawnNumbers.has(value);
            const text = String(value).padStart(2, "0");
            return marked ? `[${text}]` : ` ${text} `;
        });
        rows.push(cells.join(" "));
    }
    return new discord_js_1.EmbedBuilder()
        .setColor(COLOR)
        .setTitle(`Cartela #${String(card.cardNumber).padStart(4, "0")}`)
        .setDescription("```\n" + rows.join("\n") + "\n```");
}
// Publica (ou move) o painel de retirada de cartelas no canal informado.
async function publishCardPanel(guild, channelId) {
    const config = await (0, service_1.getBingoConfig)(guild.id);
    if (config.cardPanelChannelId && config.cardPanelMessageId) {
        const oldChannel = await guild.channels
            .fetch(config.cardPanelChannelId)
            .catch(() => null);
        if (oldChannel?.isTextBased() && !oldChannel.isDMBased()) {
            const oldMessage = await oldChannel.messages
                .fetch(config.cardPanelMessageId)
                .catch(() => null);
            await oldMessage?.delete().catch(() => null);
        }
    }
    const channel = await guild.channels.fetch(channelId);
    if (!channel?.isTextBased() || channel.isDMBased())
        throw new Error("Canal inválido para o painel de cartelas.");
    const message = await channel.send(buildCardPanelMessage(config));
    await (0, service_1.updateBingoConfig)(guild.id, {
        cardPanelChannelId: channelId,
        cardPanelMessageId: message.id,
    });
    return message;
}
// Reaplica a personalização atual no painel de cartelas já publicado
// (chamado depois de editar título/descrição/banner/thumbnail/cor).
async function refreshCardPanel(guild) {
    const config = await (0, service_1.getBingoConfig)(guild.id);
    if (!config.cardPanelChannelId || !config.cardPanelMessageId)
        return;
    const channel = await guild.channels
        .fetch(config.cardPanelChannelId)
        .catch(() => null);
    if (!channel?.isTextBased() || channel.isDMBased())
        return;
    const message = await channel.messages
        .fetch(config.cardPanelMessageId)
        .catch(() => null);
    if (!message)
        return;
    await message.edit(buildCardPanelMessage(config)).catch(() => null);
}
// -----------------------------------------------------------------------
// Ticket de compra
// -----------------------------------------------------------------------
function buildOrderTicketMessage(order, paymentInstructions) {
    const embed = new discord_js_1.EmbedBuilder()
        .setColor(COLOR)
        .setTitle("🎫 Pedido de Cartelas")
        .addFields({ name: "Comprador", value: `<@${order.buyerId}>`, inline: true }, {
        name: "Pacote",
        value: `${order.quantity} cartela${order.quantity > 1 ? "s" : ""} — ${order.price}`,
        inline: true,
    }, {
        name: "Status",
        value: order.status === "AGUARDANDO_PAGAMENTO"
            ? "**Aguardando pagamento**"
            : order.status === "ENTREGUE"
                ? "**Entregue**"
                : "**Cancelado**",
        inline: false,
    });
    if (paymentInstructions)
        embed.addFields({ name: "Como pagar", value: paymentInstructions });
    const deliverButton = new discord_js_1.ButtonBuilder()
        .setCustomId(`${types_1.BINGO_IDS.orderDeliverPrefix}${order.id}`)
        .setLabel("ENTREGAR CARTELAS")
        .setStyle(discord_js_1.ButtonStyle.Success)
        .setDisabled(order.status !== "AGUARDANDO_PAGAMENTO");
    const cancelButton = new discord_js_1.ButtonBuilder()
        .setCustomId(`${types_1.BINGO_IDS.orderCancelPrefix}${order.id}`)
        .setLabel("CANCELAR PEDIDO")
        .setStyle(discord_js_1.ButtonStyle.Danger)
        .setDisabled(order.status !== "AGUARDANDO_PAGAMENTO");
    return {
        embeds: [embed],
        components: order.status === "AGUARDANDO_PAGAMENTO"
            ? [
                new discord_js_1.ActionRowBuilder().addComponents(deliverButton, cancelButton),
            ]
            : [],
    };
}
// Abre o canal privado ("ticket") do pedido, reaproveitando a categoria e
// os cargos de staff já configurados no sistema de Tickets do bot.
async function createOrderTicket(guild, buyerId, quantity, priceText) {
    const tConfig = await (0, tickets_1.ticketConfig)(guild.id);
    const bConfig = await (0, service_1.getBingoConfig)(guild.id);
    const buyer = await guild.members.fetch(buyerId);
    const overwrites = [
        { id: guild.roles.everyone.id, deny: [discord_js_1.PermissionFlagsBits.ViewChannel] },
        {
            id: buyerId,
            allow: [
                discord_js_1.PermissionFlagsBits.ViewChannel,
                discord_js_1.PermissionFlagsBits.SendMessages,
                discord_js_1.PermissionFlagsBits.ReadMessageHistory,
            ],
        },
        ...(0, tickets_1.ids)(tConfig.staffRoleIds).map((id) => ({
            id,
            allow: [
                discord_js_1.PermissionFlagsBits.ViewChannel,
                discord_js_1.PermissionFlagsBits.SendMessages,
                discord_js_1.PermissionFlagsBits.ReadMessageHistory,
            ],
        })),
    ];
    const channel = await guild.channels.create({
        name: `cartela-${buyer.user.username}`
            .toLowerCase()
            .replace(/[^a-z0-9-]/g, "")
            .slice(0, 90),
        type: discord_js_1.ChannelType.GuildText,
        // Categoria própria do Bingo, se configurada; senão cai na categoria
        // do sistema de Tickets, igual antes.
        parent: bConfig.cardTicketCategoryId || tConfig.categoryId || undefined,
        permissionOverwrites: overwrites,
    });
    const order = await (0, service_1.createOrder)(guild.id, buyerId, channel.id, quantity, priceText);
    await channel.send({
        content: `<@${buyerId}>`,
        ...buildOrderTicketMessage(order, bConfig.paymentInstructions),
    });
    return { channel, order };
}
// Monta as embeds das cartelas entregues para enviar na DM do comprador.
function buildCardsDeliveryDM(cards) {
    return cards.map((card) => buildCardEmbed(card));
}
