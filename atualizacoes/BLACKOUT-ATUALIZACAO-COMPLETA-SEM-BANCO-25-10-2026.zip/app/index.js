"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("dotenv/config");
const discord_js_1 = require("discord.js");
const loadCommands_1 = require("./handlers/loadCommands");
const loadEvents_1 = require("./handlers/loadEvents");
const loadButtons_1 = require("./handlers/loadButtons");
const loadSelects_1 = require("./handlers/loadSelects");
const loadModals_1 = require("./handlers/loadModals");
const prisma_1 = require("./database/prisma");
const reintegration_1 = require("./utils/reintegration");
const roleTransfer_1 = require("./utils/roleTransfer");
const radioService_1 = require("./radio/service");
if (!process.env.DISCORD_TOKEN || !process.env.CLIENT_ID) {
    console.error("❌ DISCORD_TOKEN e CLIENT_ID precisam estar definidos no .env");
    process.exit(1);
}
function tokenOwnerId(token) {
    try {
        return Buffer.from(token.split(".")[0], "base64url").toString("utf8");
    }
    catch {
        return null;
    }
}
const configuredClientId = process.env.CLIENT_ID;
const tokenClientId = tokenOwnerId(process.env.DISCORD_TOKEN);
if (tokenClientId && /^\d+$/.test(tokenClientId) && tokenClientId !== configuredClientId) {
    console.error("❌ CONFIGURAÇÃO INVÁLIDA: DISCORD_TOKEN e CLIENT_ID pertencem a bots diferentes.");
    console.error(`   ID identificado pelo token: ${tokenClientId}`);
    console.error(`   CLIENT_ID configurado:       ${configuredClientId}`);
    console.error("   Corrija as variáveis na Square Cloud antes de iniciar o bot.");
    process.exit(1);
}
const client = new discord_js_1.Client({
    intents: [
        discord_js_1.GatewayIntentBits.Guilds,
        discord_js_1.GatewayIntentBits.GuildMembers,
        discord_js_1.GatewayIntentBits.GuildMessages,
    discord_js_1.GatewayIntentBits.GuildMessageReactions,
        discord_js_1.GatewayIntentBits.GuildVoiceStates,
        discord_js_1.GatewayIntentBits.MessageContent,
        discord_js_1.GatewayIntentBits.GuildModeration,
    ],
    partials: [discord_js_1.Partials.Message, discord_js_1.Partials.Channel, discord_js_1.Partials.GuildMember, discord_js_1.Partials.Reaction, discord_js_1.Partials.User],
});
client.commands = new discord_js_1.Collection();
client.buttons = new discord_js_1.Collection();
client.selects = new discord_js_1.Collection();
client.modals = new discord_js_1.Collection();
(0, loadCommands_1.loadCommands)(client);
(0, loadButtons_1.loadButtons)(client);
(0, loadSelects_1.loadSelects)(client);
(0, loadModals_1.loadModals)(client);
(0, loadEvents_1.loadEvents)(client);
client.once(discord_js_1.Events.ClientReady, readyClient => {
    if (readyClient.user.id !== configuredClientId) {
        console.error("❌ O bot conectado não corresponde ao CLIENT_ID configurado.");
        console.error(`   Bot conectado: ${readyClient.user.tag} (${readyClient.user.id})`);
        console.error(`   CLIENT_ID: ${configuredClientId}`);
        void shutdown();
    }
    else
        console.log(`✅ Identidade validada: ${readyClient.user.tag} (${readyClient.user.id})`);
});
// Rádio 24h: restaura automaticamente as rádios persistidas como ativas após o login.
client.once(discord_js_1.Events.ClientReady, readyClient => {
    (0, radioService_1.restoreEnabledRadios)(readyClient).catch((err) => console.error("[radio] Erro ao restaurar rádios 24h:", err));
});
client.login(process.env.DISCORD_TOKEN);
// Progressão automática de reintegração: verifica periodicamente se algum
// membro em etapa "automática" já cumpriu os dias mínimos e o avança.
const AUTO_PROGRESSION_INTERVAL_MS = 5 * 60 * 1000; // 5 minutos
client.once(discord_js_1.Events.ClientReady, () => {
    setInterval(() => {
        (0, reintegration_1.runAutoProgression)(client).catch((err) => console.error("[auto-progression] Erro na verificação periódica:", err));
    }, AUTO_PROGRESSION_INTERVAL_MS);
});
// Transferência automática de cargo (ex: "Perdido" -> "AUDAZ"): verifica
// periodicamente se algum servidor com modo AUTOMATIC configurado chegou
// no dia/horário agendado e, se sim, roda a transferência sozinho.
const ROLE_TRANSFER_CHECK_INTERVAL_MS = 5 * 60 * 1000; // 5 minutos
client.once(discord_js_1.Events.ClientReady, () => {
    setInterval(() => {
        (0, roleTransfer_1.checkAllGuildsRoleTransferSchedule)(client).catch((err) => console.error("[role-transfer] Erro na verificação periódica:", err));
    }, ROLE_TRANSFER_CHECK_INTERVAL_MS);
});
// Encerramento gracioso (fecha conexão com o banco corretamente)
async function shutdown() {
    console.log("\n🔻 Encerrando bot...");
    await (0, radioService_1.shutdownRadios)().catch(() => null);
    await prisma_1.prisma.$disconnect();
    client.destroy();
    process.exit(0);
}
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
//# sourceMappingURL=index.js.map