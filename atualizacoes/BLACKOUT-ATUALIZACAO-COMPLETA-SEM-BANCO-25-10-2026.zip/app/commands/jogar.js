"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const common_1 = require("../games-chat/experience/common");
const hub_1 = require("../games-chat/experience/hub");
const command = {
    data: new discord_js_1.SlashCommandBuilder()
        .setName("jogar")
        .setDescription("Encontre os jogos e eventos da comunidade")
        .setDMPermission(false)
        .addStringOption((o) => o
        .setName("jogo")
        .setDescription("Abrir um jogo diretamente")
        .addChoices({ name: "TERMO diário", value: "termo" }, { name: "Bingo comunitário", value: "bingo" }, { name: "Caixa Misteriosa", value: "mystery" }, { name: "Quiz em equipes", value: "quiz" }, { name: "Rankings do TERMO", value: "ranking" })),
    async execute(i) {
        await (0, common_1.guard)(i, async () => {
            if (!i.guild)
                return;
            await (0, common_1.member)(i.guild, i.user.id);
            await i.deferReply({ flags: discord_js_1.MessageFlags.Ephemeral });
            const choice = i.options.getString("jogo");
            await i.editReply(choice
                ? await (0, hub_1.playView)(i.guild, i.user.id, choice)
                : await (0, hub_1.publicView)(i.guild));
        });
    },
};
exports.default = command;
