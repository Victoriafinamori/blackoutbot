"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const permissions_1 = require("../utils/permissions");
const admPanel_1 = require("../utils/admPanel");
const admEmojis_1 = require("../utils/admEmojis");
const command = {
    data: new discord_js_1.SlashCommandBuilder()
        .setName("adm")
        .setDescription("Abre o painel de moderação do bot")
        .setDMPermission(false),
    async execute(interaction) {
        if (!interaction.inGuild() || !interaction.guild) {
            await interaction.reply({
                content: "Esse comando só pode ser usado dentro de um servidor.",
                ephemeral: true,
            });
            return;
        }
        await interaction.deferReply({ ephemeral: true });
        const member = await interaction.guild.members.fetch(interaction.user.id);
        const authorized = await (0, permissions_1.isBotAdmin)(member);
        if (!authorized) {
            await interaction.editReply({
                content: "Você não tem permissão para acessar o painel administrativo.",
            });
            return;
        }
        await (0, admEmojis_1.ensureAdmEmojis)(interaction.guild);
        await interaction.editReply(await (0, admPanel_1.buildAdmRootPanel)(interaction.guild, interaction.user));
    },
};
exports.default = command;
