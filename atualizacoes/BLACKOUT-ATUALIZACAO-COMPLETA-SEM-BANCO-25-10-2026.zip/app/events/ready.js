"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const adminLog_1 = require("../utils/adminLog");
const embeds_1 = require("../utils/embeds");
const enums_1 = require("../structures/enums");
const guildConfig_1 = require("../database/guildConfig");
const admEmojis_1 = require("../utils/admEmojis");
const movStats_1 = require("../utils/movStats");
const movCallStats_1 = require("../utils/movCallStats");
const manager_1 = require("../games-chat/mystery-box/manager");
const publisher_1 = require("../games-chat/termo/publisher");
const scheduler_1 = require("../voteban/scheduler");
const ticketAlerts_1 = require("../utils/ticketAlerts");
const channelCleanup_1 = require("../utils/channelCleanup");
const prisma_1 = require("../database/prisma");
const service_1 = require("../family-app/service");
const service_2 = require("../giveaways/service");
const service_3 = require("../social/service");
const service_4 = require("../war/service");
const memberRise_1 = require("../memberRise/service");
const submundo_1 = require("../submundo/service");
const MOV_RESET_CHECK_INTERVAL_MS = 15 * 60 * 1000; // checa reset automático a cada 15 minutos
const MOVCALL_RANKING_REFRESH_INTERVAL_MS = 10 * 60 * 1000; // atualiza a mensagem do Top Call a cada 10 minutos
exports.default = {
    name: discord_js_1.Events.ClientReady,
    once: true,
    async execute(client) {
        console.log(`✅ Bot online como ${client.user?.tag}`);
        console.log(`📡 Presente em ${client.guilds.cache.size} servidor(es)`);
        for (const guild of client.guilds.cache.values()) {
            await (0, memberRise_1.reconcileVoice)(guild).catch(error => console.error("[member-rise] retomada:", error));
            try {
                await (0, channelCleanup_1.cleanupClosedServiceChannels)(guild);
            }
            catch (error) {
                console.error(`[ready] Erro ao limpar tickets/registros finalizados em ${guild.id}:`, error);
            }
            try {
                await (0, admEmojis_1.ensureAdmEmojis)(guild);
                const embed = (await (0, embeds_1.baseEmbed)(guild))
                    .setTitle("⚙️ Bot Iniciado")
                    .setDescription(`${client.user?.tag} está online e pronto.`)
                    .setTimestamp();
                await (0, adminLog_1.sendCategoryLog)(guild, enums_1.LogCategory.SYSTEM, embed);
            }
            catch (error) {
                console.error(`[ready] Erro ao enviar log de sistema em ${guild.id}:`, error);
            }
            // Mov.Call: quem já estava conectado a um canal de voz contado antes do
            // bot (re)iniciar não geraria evento de entrada — então começamos a
            // sessão manualmente pra não perder o tempo que passar conectado.
            try {
                const config = await (0, guildConfig_1.getOrCreateGuildConfig)(guild.id);
                if (config.movCallSystemEnabled) {
                    const trackedCategories = (0, movCallStats_1.getMovCallCategoryIds)(config);
                    if (trackedCategories.length) {
                        for (const [, voiceState] of guild.voiceStates.cache) {
                            const channel = voiceState.channel;
                            if (!channel || voiceState.member?.user.bot)
                                continue;
                            if (trackedCategories.includes(channel.parentId ?? "")) {
                                await (0, movCallStats_1.startCallVoiceSession)(guild.id, voiceState.id, channel.id, !!voiceState.mute);
                                await (0, movCallStats_1.registerCallStreak)(guild.id, voiceState.id, config.timezone);
                            }
                        }
                    }
                    if (config.movCallRankingEnabled) {
                        await (0, movCallStats_1.refreshCallRankingMessage)(guild);
                    }
                }
            }
            catch (error) {
                console.error(`[ready] Erro ao recuperar sessões de voz (Mov.Call) em ${guild.id}:`, error);
            }
            await (0, service_2.recoverGiveawayVoice)(guild).catch(error => console.error(`[giveaway-recovery] ${guild.id}:`, error));
        }
        // Reset automático do ranking MOV CHAT
        const runMovResetCheck = () => {
            (0, movStats_1.checkAllGuildsMovReset)((guildId) => client.guilds.cache.get(guildId)).catch((err) => console.error("[mov-reset] Erro ao checar resets automáticos (MOV CHAT):", err));
        };
        runMovResetCheck();
        setInterval(runMovResetCheck, MOV_RESET_CHECK_INTERVAL_MS);
        // Reset automático do Top Call (Mov.Call)
        const runMovCallResetCheck = () => {
            (0, movCallStats_1.checkAllGuildsMovCallReset)((guildId) => client.guilds.cache.get(guildId)).catch((err) => console.error("[movcall-reset] Erro ao checar resets automáticos (Mov.Call):", err));
        };
        runMovCallResetCheck();
        setInterval(runMovCallResetCheck, MOV_RESET_CHECK_INTERVAL_MS);
        // Atualização periódica da mensagem fixa do ranking do Top Call
        const runMovCallRankingRefresh = async () => {
            for (const guild of client.guilds.cache.values()) {
                try {
                    const config = await (0, guildConfig_1.getOrCreateGuildConfig)(guild.id);
                    if (config.movCallSystemEnabled && config.movCallRankingEnabled && config.movCallRankingChannelId) {
                        await (0, movCallStats_1.refreshCallRankingMessage)(guild);
                    }
                }
                catch (err) {
                    console.error(`[movcall-ranking] Erro ao atualizar ranking em ${guild.id}:`, err);
                }
            }
        };
        setInterval(() => {
            runMovCallRankingRefresh().catch((err) => console.error("[movcall-ranking] Erro:", err));
        }, MOVCALL_RANKING_REFRESH_INTERVAL_MS);
    const runCommunityBingo=()=>require('../bingo/community').tick(client).catch((error)=>console.error('[community-bingo]',error.message));
    void runCommunityBingo();setInterval(runCommunityBingo,2000);
    const refreshGamesHub=()=>require('../games-chat/experience/hub').refreshPublished(client).catch((error)=>console.error('[games-hub]',error.message));
    void refreshGamesHub();setInterval(refreshGamesHub,60000);
        const runGamesChat = () => Promise.all([(0, manager_1.runMysteryScheduler)(client), (0, publisher_1.runTermoScheduler)(client)]).catch(error => console.error("[games-chat] Erro no agendador:", error));
        void runGamesChat();
        setInterval(runGamesChat, 60 * 1000);
        const runVoteBan = () => (0, scheduler_1.runVoteBanScheduler)(client).catch(error => console.error("[voteban] Erro no agendador:", error));
        void runVoteBan();
        setInterval(runVoteBan, 5 * 60 * 1000);
        const runTicketAlerts = () => (0, ticketAlerts_1.runTicketAlertScheduler)(client).catch(error => console.error("[ticket-alerts] Erro no monitor:", error));
        void runTicketAlerts();
        setInterval(runTicketAlerts, 60 * 1000);
        const refreshFamilyPanels = async () => {
            for (const guild of client.guilds.cache.values()) {
                const families = await prisma_1.prisma.family.findMany({ where: { guildId: guild.id, panelMessageId: { not: null } }, select: { id: true } });
                for (const family of families)
                    await (0, service_1.refreshFamilyPanel)(guild, family.id).catch(error => console.error(`[family-panel] ${family.id}:`, error));
            }
        };
        setInterval(() => void refreshFamilyPanels(), 10 * 60 * 1000);
        const runGiveaways = () => (0, service_2.runGiveawayScheduler)(client).catch(error => console.error("[giveaway-scheduler]", error));
        void runGiveaways();
        setInterval(runGiveaways, 60 * 1000);
        const runExperience=()=>require('../social-experience/scheduler').run(client).catch(error=>console.error('[social-experience-scheduler]',error.message));
        void runExperience();
        setInterval(runExperience,60*1000);
        const runSocial = () => (0, service_3.runSocialScheduler)(client).catch(error => console.error("[social-scheduler]", error));
        void runSocial();
        setInterval(runSocial, 5 * 60 * 1000);
        for (const guild of client.guilds.cache.values()) {
            await (0, submundo_1.refreshAnonymousMediaPanel)(guild).catch(error => console.error(`[submundo-panel-media] ${guild.id}:`, error));
            await (0, submundo_1.refreshAnonymousMessagePanel)(guild).catch(error => console.error(`[submundo-panel-message] ${guild.id}:`, error));
        }
        const runSubmundo = () => (0, submundo_1.runSubmundoScheduler)(client).catch(error => console.error("[submundo-scheduler]", error));
        void runSubmundo();
        setInterval(runSubmundo, 60 * 1000);
        setInterval(() => { for (const guild of client.guilds.cache.values()) void (0, memberRise_1.reconcileVoice)(guild).catch(error => console.error("[member-rise] tick:", error)); }, 60 * 1000);
        await (0, service_4.recoverWars)(client).catch(error => console.error("[war-recovery]", error));
        setInterval(() => void (0, service_4.tickWars)(client).catch(error => console.error("[war-scheduler]", error)), 1000);
    },
};
//# sourceMappingURL=ready.js.map
