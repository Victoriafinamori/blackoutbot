"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const entry_1 = require("../security/entry");
const runtime_1 = require("../security/runtime");
exports.default = { name: discord_js_1.Events.GuildMemberRemove, async execute(member) { await (0, runtime_1.safe)("snapshot de saída", () => (0, entry_1.snapshot)(member)); } };
