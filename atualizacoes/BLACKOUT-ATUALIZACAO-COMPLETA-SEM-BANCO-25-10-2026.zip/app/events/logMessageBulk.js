"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const events_1 = require("../logging/events");
exports.default = { name: discord_js_1.Events.MessageBulkDelete, once: false, async execute(messages, channel) { await (0, events_1.runLogEvent)(() => (0, events_1.messagesDeleted)(messages, channel)); } };
