"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const adminLog_1 = require("../utils/adminLog");
const enums_1 = require("../structures/enums");
const prisma_1 = require("../database/prisma");
exports.default = {
    name: discord_js_1.Events.GuildMemberRemove,
    once: false,
    async execute(member) {
        try {
            await prisma_1.prisma.memberPresenceStat.upsert({ where: { guildId_userId: { guildId: member.guild.id, userId: member.id } }, create: { guildId: member.guild.id, userId: member.id, leaves: 1, lastLeftAt: new Date() }, update: { leaves: { increment: 1 }, lastLeftAt: new Date() } });
            const roles = member.roles.cache
                .filter((role) => role.id !== member.guild.id)
                .map((role) => `<@&${role.id}>`)
                .slice(0, 10)
                .join(", ");
            const details = `Membros no servidor: ${member.guild.memberCount}. Cargos que possuía: ${roles || "nenhum"}.`;
            await (0, adminLog_1.logAdminAction)({
                guild: member.guild,
                actorId: member.id,
                action: enums_1.AdminLogAction.MEMBER_LEFT,
                details,
        context: {userId:member.id,bot:member.user?.bot,roleIds:member.roles.cache.map(role=>role.id)},
            });
        }
        catch (error) {
            console.error("[guildMemberRemove] Erro ao registrar log de segurança:", error);
        }
    },
};
//# sourceMappingURL=guildMemberRemove.js.map