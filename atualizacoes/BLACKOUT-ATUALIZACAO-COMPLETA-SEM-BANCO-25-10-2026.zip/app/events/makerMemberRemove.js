"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const common_1 = require("../message-maker/common");
exports.default = { name: discord_js_1.Events.GuildMemberRemove, async execute(member) {
        try {
            await common_1.prisma.$transaction(async (tx) => {
                await tx.reactionRoleGrant.updateMany({ where: { guildId: member.guild.id, userId: member.id }, data: { active: false, status: "MEMBER_LEFT" } });
                await tx.reactionRoleOwnership.deleteMany({ where: { guildId: member.guild.id, userId: member.id } });
            });
        }
        catch (e) {
            console.error("[maker-member-remove]", e?.code || e?.name);
        }
    } };
