"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const roles_1 = require("../message-maker/roles");
exports.default = { name: discord_js_1.Events.MessageReactionRemoveEmoji, async execute(reaction) { try {
        await (0, roles_1.reactionsCleared)(reaction.message);
    }
    catch (e) {
        console.error("[maker-reaction-cleared]", e?.code || e?.name);
    } } };
