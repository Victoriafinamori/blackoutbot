"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const runtime_1 = require("../security/runtime");
exports.default = { name: discord_js_1.Events.ClientReady, once: true, async execute(client) { await (0, runtime_1.safe)("retomada", () => (0, runtime_1.start)(client)); } };
