"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const audit_1 = require("../security/audit");
const runtime_1 = require("../security/runtime");
exports.default = { name: discord_js_1.Events.GuildAuditLogEntryCreate, async execute(entry, guild) { await (0, runtime_1.safe)("auditoria", () => (0, audit_1.audit)(entry, guild)); } };
