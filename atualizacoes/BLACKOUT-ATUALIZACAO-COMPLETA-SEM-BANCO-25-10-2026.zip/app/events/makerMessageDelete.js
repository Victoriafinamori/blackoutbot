"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const roles_1 = require("../message-maker/roles");
exports.default = { name: discord_js_1.Events.MessageDelete, async execute(message) { try {
        await (0, roles_1.messageDeleted)(message);
    }
    catch (e) {
        console.error("[maker-message-delete]", e?.code || e?.name);
    } } };
