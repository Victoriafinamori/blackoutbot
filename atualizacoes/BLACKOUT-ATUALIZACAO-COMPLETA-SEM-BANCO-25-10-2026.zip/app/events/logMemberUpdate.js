"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const events_1 = require("../logging/events");
exports.default = { name: discord_js_1.Events.GuildMemberUpdate, once: false, async execute(oldMember, newMember) { await (0, events_1.runLogEvent)(() => (0, events_1.memberChanged)(oldMember, newMember)); } };
