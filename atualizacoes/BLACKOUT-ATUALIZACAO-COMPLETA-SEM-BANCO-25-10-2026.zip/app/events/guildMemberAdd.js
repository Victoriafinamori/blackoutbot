"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const adminLog_1 = require("../utils/adminLog");
const enums_1 = require("../structures/enums");
const prisma_1 = require("../database/prisma");
const guildConfig_1 = require("../database/guildConfig");
// Contas criadas há menos de 7 dias são destacadas no log de segurança,
// pois costumam ser um sinal de alerta (possível conta alt/suspeita).
const NEW_ACCOUNT_THRESHOLD_MS = 7 * 24 * 60 * 60 * 1000;
exports.default = {
    name: discord_js_1.Events.GuildMemberAdd,
    once: false,
    async execute(member) {
        try {
            if (await require("../security/entry").joined(member)) return;
            const config = await (0, guildConfig_1.getOrCreateGuildConfig)(member.guild.id);
            if (config.autoRoleEnabled && config.autoRoleIds) {
                const roleIds = config.autoRoleIds.split(",").map((id) => id.trim()).filter(Boolean);
                const assignable = roleIds
                    .map((id) => member.guild.roles.cache.get(id))
                    .filter((role) => Boolean(role && role.id !== member.guild.id && !role.managed && role.editable));
                if (assignable.length) {
                    try {
                        await member.roles.add(assignable, "Auto-Cargo configurado no /adm");
                    }
                    catch (error) {
                        console.error(`[guildMemberAdd] Falha ao aplicar Auto-Cargo em ${member.guild.id}/${member.id}:`, error);
                    }
                }
            }
            await prisma_1.prisma.memberPresenceStat.upsert({ where: { guildId_userId: { guildId: member.guild.id, userId: member.id } }, create: { guildId: member.guild.id, userId: member.id, joins: 1, lastJoinedAt: new Date() }, update: { joins: { increment: 1 }, lastJoinedAt: new Date() } });
            const accountAgeMs = Date.now() - member.user.createdTimestamp;
            const isNewAccount = accountAgeMs < NEW_ACCOUNT_THRESHOLD_MS;
            const details = `Conta criada <t:${Math.floor(member.user.createdTimestamp / 1000)}:R>` +
                (isNewAccount ? " — ⚠️ conta criada há menos de 7 dias" : "") +
                `. Membros no servidor: ${member.guild.memberCount}.`;
            await (0, adminLog_1.logAdminAction)({
                guild: member.guild,
                actorId: member.id,
                action: enums_1.AdminLogAction.MEMBER_JOINED,
                details,
        context: {userId:member.id,bot:member.user?.bot,roleIds:member.roles.cache.map(role=>role.id)},
            });
        }
        catch (error) {
            console.error("[guildMemberAdd] Erro ao registrar log de segurança:", error);
        }
    },
};
