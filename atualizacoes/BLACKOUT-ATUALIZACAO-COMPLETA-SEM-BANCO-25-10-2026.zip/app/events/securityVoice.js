"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const messages_1 = require("../security/messages");
const runtime_1 = require("../security/runtime");
exports.default = { name: discord_js_1.Events.VoiceStateUpdate, async execute(old, next) { await (0, runtime_1.safe)("voz", () => (0, messages_1.voice)(old, next)); } };
