"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const roles_1 = require("../message-maker/roles");
exports.default = { name: discord_js_1.Events.MessageReactionRemove, async execute(reaction, user) { try {
        await (0, roles_1.onReaction)(reaction, user, true);
    }
    catch (e) {
        console.error("[maker-reaction-remove]", e?.code || e?.name);
    } } };
