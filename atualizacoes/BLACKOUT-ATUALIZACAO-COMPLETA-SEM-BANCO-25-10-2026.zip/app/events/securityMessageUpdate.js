"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const messages_1 = require("../security/messages");
const runtime_1 = require("../security/runtime");
exports.default = { name: discord_js_1.Events.MessageUpdate, async execute(_old, message) { await (0, runtime_1.safe)("edição de mensagem", () => (0, messages_1.check)(message, true)); } };
