"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const filters_1 = require("../utils/filters");
const wordWatch_1 = require("../utils/wordWatch");
const stageChat_1 = require("../utils/stageChat");
const guildConfig_1 = require("../database/guildConfig");
const moderation_1 = require("../utils/moderation");
const adminLog_1 = require("../utils/adminLog");
const enums_1 = require("../structures/enums");
const permissions_1 = require("../utils/permissions");
const movStats_1 = require("../utils/movStats");
const familyStats_1 = require("../utils/familyStats");
const prisma_1 = require("../database/prisma");
const tickets_1 = require("../utils/tickets");
const registration_1 = require("../utils/registration");
const registrationClaim_1 = require("../utils/registrationClaim");
const ticketAlerts_1 = require("../utils/ticketAlerts");
const registrationWelcome_1 = require("../utils/registrationWelcome");
const service_1 = require("../giveaways/service");
const service_2 = require("../social/service");
const service_3 = require("../war/service");
const memberRise_1 = require("../memberRise/service");
exports.default = {
    name: discord_js_1.Events.MessageCreate,
    once: false,
    async execute(message) {
        try {
            if (await require("../security/messages").check(message)) return;
            if (!message.guild || message.author.bot || !message.member)
                return;
            await (0, memberRise_1.countMessage)(message).catch(error => console.error("[member-rise] mensagem:", error));
            if (await (0, registrationWelcome_1.captureWelcomeMessage)(message))
                return;
            let ticketToTrack = null;
            let ticketAuthorIsStaff = false;
            if (message.channel.isTextBased() && !message.channel.isDMBased() && "topic" in message.channel && message.channel.topic?.startsWith("registration:") && !message.channel.topic.split(":")[2]) {
                const rc = await (0, registration_1.regConfig)(message.guild.id);
                const canRegister = (0, tickets_1.ids)(rc.registrarRoleIds).some(id => message.member.roles.cache.has(id)) || message.member.permissions.has(discord_js_1.PermissionFlagsBits.Administrator);
                if (canRegister)
                    await (0, registrationClaim_1.claimRegistrationChannel)(message.channel, message.author.id).catch(() => null);
            }
            const activeTicket = await prisma_1.prisma.ticket.findUnique({ where: { channelId: message.channelId } });
            if (activeTicket?.status === "OPEN") {
                const tc = await (0, tickets_1.ticketConfig)(message.guild.id);
                if (tc.lockToClaimer && activeTicket.claimedById && message.author.id !== activeTicket.openerId && message.author.id !== activeTicket.claimedById) {
                    const immune = (0, tickets_1.ids)(tc.immuneRoleIds).some(roleId => message.member.roles.cache.has(roleId));
                    if (!immune) {
                        await message.delete().catch(() => null);
                        return;
                    }
                }
                const ticketStaff = message.member.permissions.has(discord_js_1.PermissionFlagsBits.Administrator)
                    || (0, tickets_1.ids)(tc.staffRoleIds).some(roleId => message.member.roles.cache.has(roleId));
                if (ticketStaff && message.mentions.members?.size && "permissionOverwrites" in message.channel) {
                    const called = [...message.mentions.members.values()].filter(member => !member.user.bot && member.id !== message.author.id);
                    const added = [];
                    for (const member of called) {
                        const permissions = message.channel.permissionsFor(member);
                        if (permissions?.has(discord_js_1.PermissionFlagsBits.ViewChannel))
                            continue;
                        await message.channel.permissionOverwrites.edit(member.id, { ViewChannel: true, SendMessages: true, ReadMessageHistory: true });
                        added.push(member.id);
                    }
                    if (added.length)
                        await message.channel.send({ content: `${added.map(id => `<@${id}>`).join(" ")} ${added.length > 1 ? "foram chamados para este ticket" : "foi chamado para este ticket"}.`, allowedMentions: { users: added } }).catch(() => null);
                }
                if (ticketStaff && message.author.id !== activeTicket.openerId && !activeTicket.claimedById && message.channel.isTextBased() && !message.channel.isDMBased()) {
                    const claimed = await (0, tickets_1.claimTicket)(message.channel, activeTicket.id, message.author.id).catch(error => { console.error("[ticket-auto-claim]", error); return false; });
                    if (claimed)
                        await message.channel.send(`Ticket assumido automaticamente por <@${message.author.id}>.`).catch(() => null);
                }
                ticketToTrack = activeTicket;
                ticketAuthorIsStaff = ticketStaff;
            }
            // MOV CHAT: conta a mensagem se o canal estiver entre os configurados
            // pela staff. Roda para todo mundo (inclusive staff/admin), já que a
            // ideia é medir atividade real, não só de quem é filtrado.
            const movConfig = await (0, guildConfig_1.getOrCreateGuildConfig)(message.guild.id);
            const movChatChannels = (0, movStats_1.getMovChatChannelIds)(movConfig);
            if (movChatChannels.includes(message.channel.id)) {
                await (0, movStats_1.incrementChatCount)(message.guild.id, message.author.id).catch((err) => console.error("[mov-chat] Erro ao contar mensagem:", err));
                await (0, service_1.trackGiveawayMessage)(message.guild.id, message.author.id).catch(err => console.error("[giveaway-chat]", err));
            }
            // VIP Família/Irmandade — Mov Chat: conta a mensagem para cada Família
            // ativa que monitora este canal, desde que o autor possua o cargo de
            // membro daquela Família. Totalmente independente do MOV CHAT global.
            const monitoringFamilies = await (0, familyStats_1.getActiveFamiliesMonitoringChannel)(message.guild.id, message.channel.id);
            if (monitoringFamilies.length) {
                for (const family of monitoringFamilies) {
                    if (family.memberRoleId && message.member.roles.cache.has(family.memberRoleId)) {
                        await (0, familyStats_1.incrementFamilyChatToday)(message.guild.id, family.id, message.author.id, movConfig.timezone).catch((err) => console.error("[family-chat] Erro ao contar mensagem:", err));
                    }
                }
            }
            if (await (0, service_3.lightningMessage)(message))
                return;
            if (await (0, service_2.createSocialPublication)(message))
                return;
            // Monitoramento de Palavras: observação silenciosa (não apaga, não pune),
            // roda antes de qualquer possível exclusão pelo filtro abaixo, e não
            // é afetado pela isenção de staff/admin — a ideia é registrar o que o
            // membro em reintegração fala, ponto.
            await (0, wordWatch_1.checkWordWatch)(message).catch((err) => console.error("[word-watch] Erro:", err));
            // Staff (Gerenciar Mensagens) e Administradores do BOT não são filtrados.
            if (message.member.permissions.has(discord_js_1.PermissionFlagsBits.ManageMessages)) {
                if (ticketToTrack)
                    await (0, ticketAlerts_1.trackTicketMessage)(message.guild, ticketToTrack, message.author.id, ticketAuthorIsStaff);
                return;
            }
            if (await (0, permissions_1.isBotAdmin)(message.member)) {
                if (ticketToTrack)
                    await (0, ticketAlerts_1.trackTicketMessage)(message.guild, ticketToTrack, message.author.id, ticketAuthorIsStaff);
                return;
            }
            // Restrição de chat da etapa de reintegração (Bloqueado / Limitado),
            // roda antes dos filtros de conteúdo: se a etapa travar a mensagem,
            // nem faz sentido avaliar palavra/link/flood/etc.
            const stageChat = await (0, stageChat_1.checkStageChatRestriction)(message);
            if (stageChat.violated) {
                const botId = message.client.user?.id ?? message.author.id;
                await message.delete().catch(() => null);
                const channel = message.channel;
                const notice = channel.isTextBased() && "send" in channel
                    ? await channel
                        .send({ content: `🔒 <@${message.author.id}>, ${stageChat.reason}` })
                        .catch(() => null)
                    : null;
                if (notice)
                    setTimeout(() => notice.delete().catch(() => null), 6000);
                await (0, adminLog_1.logAdminAction)({
                    guild: message.guild,
                    actorId: botId,
                    action: enums_1.AdminLogAction.STAGE_CHAT_RESTRICTED,
                    targetId: message.author.id,
                    details: stageChat.reason,
                });
                return;
            }
            const result = await (0, filters_1.checkMessage)(message);
            if (!result.violated) {
                if (ticketToTrack)
                    await (0, ticketAlerts_1.trackTicketMessage)(message.guild, ticketToTrack, message.author.id, ticketAuthorIsStaff);
                return;
            }
            const config = movConfig;
            const botId = message.client.user?.id ?? message.author.id;
            await message.delete().catch(() => null);
            const channel = message.channel;
            const notice = channel.isTextBased() && "send" in channel
                ? await channel
                    .send({
                    content: `🧹 <@${message.author.id}>, sua mensagem foi removida.\n**Motivo:** ${result.reason}`,
                })
                    .catch(() => null)
                : null;
            if (notice)
                setTimeout(() => notice.delete().catch(() => null), 6000);
            await (0, adminLog_1.logAdminAction)({
                guild: message.guild,
                actorId: botId,
                action: enums_1.AdminLogAction.AUTO_MOD_TRIGGERED,
                targetId: message.author.id,
                details: `[${result.category}] ${result.reason}`,
            });
            if (config.autoModAction === enums_1.AutoModAction.WARN) {
                await (0, moderation_1.warnMember)(message.guild, botId, message.author.id, `Automático: ${result.reason}`).catch(() => null);
            }
            else if (config.autoModAction === enums_1.AutoModAction.MUTE) {
                await (0, moderation_1.muteMember)(message.guild, botId, message.author.id, `Automático: ${result.reason}`, config.autoMuteDurationMinutes, true).catch((err) => {
                    if (!(err instanceof moderation_1.ModerationError))
                        console.error("[auto-mod] Erro ao mutar:", err);
                });
            }
            // "DELETE_ONLY" só apaga a mensagem, sem punição adicional.
        }
        catch (error) {
            console.error("[messageCreate] Erro no filtro de moderação:", error);
        }
    },
};
//# sourceMappingURL=messageCreate.js.map
