"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const events_1 = require("../logging/events");
exports.default = { name: discord_js_1.Events.VoiceStateUpdate, once: false, async execute(oldState, newState) { await (0, events_1.runLogEvent)(() => (0, events_1.voiceLog)(oldState, newState)); } };
