"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const common_1 = require("../message-maker/common");
exports.default = { name: discord_js_1.Events.GuildRoleDelete, async execute(role) {
        try {
            const list = await common_1.prisma.reactionRoleBinding.findMany({ where: { guildId: role.guild.id, roleId: role.id, active: true } });
            for (const b of list)
                await common_1.prisma.reactionRolePanel.update({ where: { id: b.panelId }, data: { status: "PAUSED", lastError: "Um cargo oferecido foi apagado. Revise a associação antes de retomar o painel." } });
        }
        catch (e) {
            console.error("[maker-role-delete]", e?.code || e?.name);
        }
    } };
