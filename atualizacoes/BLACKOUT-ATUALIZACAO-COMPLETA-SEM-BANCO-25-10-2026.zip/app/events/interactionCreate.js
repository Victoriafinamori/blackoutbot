"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
// Encontra handler exato ou por prefixo (ex: "adm-adm:reintegracao" -> "adm-adm:")
function findHandler(collection, customId) {
    const exact = collection.get(customId);
    if (exact)
        return exact;
    return [...collection.values()].find((c) => c.customId !== customId && customId.startsWith(c.customId));
}
exports.default = {
    name: discord_js_1.Events.InteractionCreate,
    once: false,
    async execute(interaction, client) {
        try {
            interaction = require("../utils/componentMessages").compatibleInteraction(interaction);
            const legacyId = interaction.customId;
            if (typeof legacyId === "string" && legacyId.startsWith("embedv2")) {
                const parts = legacyId.split(":");
                const oldId = parts[0] === "embedv2-select" ? interaction.values?.[0] : ["embedv2-edit-select", "embedv2-btn-select"].includes(parts[0]) ? parts[1] : parts[2];
                return require("../message-maker/interactions").legacyEntry(interaction, oldId);
            }

            if (interaction.isChatInputCommand()) {
                const command = client.commands.get(interaction.commandName);
                if (!command)
                    return;
                await command.execute(interaction);
                return;
            }
            if (interaction.isButton()) {
                const handler = findHandler(client.buttons, interaction.customId);
                if (!handler)
                    return;
                await handler.execute(interaction);
                return;
            }
            if (interaction.isAnySelectMenu()) {
                const handler = findHandler(client.selects, interaction.customId);
                if (!handler)
                    return;
                await handler.execute(interaction);
                return;
            }
            if (interaction.isModalSubmit()) {
                const handler = findHandler(client.modals, interaction.customId);
                if (!handler) {
                    console.error(`[interactionCreate] Modal sem handler: ${interaction.customId}`);
                    await interaction.reply({ content: "Este formulário não está disponível nesta versão do bot. Reinicie a aplicação e tente novamente.", flags: discord_js_1.MessageFlags.Ephemeral });
                    return;
                }
                await handler.execute(interaction);
                return;
            }
        }
        catch (error) {
            console.error("[interactionCreate] Erro ao processar interação:", error);
            const errorMessage = {
                content: "❌ Ocorreu um erro ao processar essa ação.",
                flags: discord_js_1.MessageFlags.Ephemeral,
            };
            if (interaction.isRepliable()) {
                if (interaction.replied || interaction.deferred) {
                    await interaction.followUp(errorMessage).catch(() => null);
                }
                else {
                    await interaction.reply(errorMessage).catch(() => null);
                }
            }
        }
    },
};
//# sourceMappingURL=interactionCreate.js.map