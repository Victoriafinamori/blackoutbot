"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.authorized = authorized;
exports.fail = fail;
exports.questionModal = questionModal;
exports.warButton = warButton;
exports.warSelect = warSelect;
exports.warModal = warModal;
const discord_js_1 = require("discord.js");
const prisma_1 = require("../database/prisma");
const permissions_1 = require("../utils/permissions");
const admin_1 = require("./admin");
const repository_1 = require("./repository");
const service_1 = require("./service");
const questions_1 = require("./questions");
const admPanel_1 = require("../utils/admPanel");
const rules_1 = require("./rules");
async function authorized(i) {
    if (!i.guild || !await (0, permissions_1.isBotAdmin)(await i.guild.members.fetch(i.user.id)))
        throw new Error("Somente administradores configurados no bot podem controlar este evento.");
}
async function fail(i, error) {
    const content = error instanceof Error ? error.message : "Não foi possível concluir a ação.";
    if (i.deferred || i.replied)
        await i.editReply({ content, embeds: [], components: [] }).catch(() => null);
    else
        await i.reply({ content, flags: discord_js_1.MessageFlags.Ephemeral }).catch(() => null);
}
const field = (id, label, value, paragraph = false) => new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.TextInputBuilder().setCustomId(id).setLabel(label).setStyle(paragraph ? discord_js_1.TextInputStyle.Paragraph : discord_js_1.TextInputStyle.Short).setRequired(true).setValue(value).setMaxLength(paragraph ? 1000 : 100));
const difficultyValue = (value) => ({ facil: "EASY", medio: "MEDIUM", dificil: "HARD", aleatoria: "RANDOM", aleatorio: "RANDOM" }[(0, questions_1.normalizeAnswer)(value)] || value.toUpperCase());
const firstTeamValue = (value) => ({ meninas: "GIRLS", meninos: "BOYS", sortear: "RANDOM" }[(0, questions_1.normalizeAnswer)(value)] || value.toUpperCase());
async function questionModal(i, id) {
    const q = id ? await prisma_1.prisma.warQuestion.findFirst({ where: { id, guildId: i.guild.id, deleted: false } }) : null;
    if (id && !q)
        throw new Error("Pergunta não encontrada.");
    await i.showModal(new discord_js_1.ModalBuilder().setCustomId(`war-modal:question:${id || "new"}`).setTitle(q ? "Editar pergunta" : "Adicionar pergunta").addComponents(field("category", "Categoria (ex.: Games)", q?.category || "Games"), field("difficulty", "Dificuldade: Fácil, Médio ou Difícil", (0, repository_1.difficultyLabel)(q?.difficulty || "EASY")), field("text", "Pergunta", q?.text || "Digite a pergunta", true), field("options", "4 alternativas ou 1 resposta (relâmpago)", q?.options ? JSON.parse(q.options).join("\n") : "Alternativa A\nAlternativa B\nAlternativa C\nAlternativa D", true), field("correct", "Correta: A/B/C/D | sinônimos separados por ;", q ? `${"ABCD"[q.correct]}${JSON.parse(q.aliases).length ? `|${JSON.parse(q.aliases).join(";")}` : ""}` : "A")));
}
async function warButton(i) {
    try {
        if (!i.guild)
            return;
        const [, action, id, arg] = i.customId.split(":");
        if (action === "join") {
            await i.deferReply({ flags: discord_js_1.MessageFlags.Ephemeral });
            await i.editReply(await (0, service_1.joinGame)(i.guild, id, i.user.id, arg));
            return;
        }
        if (action === "answer") {
            await i.deferReply({ flags: discord_js_1.MessageFlags.Ephemeral });
            await (0, service_1.answerButton)(i.guild, id, i.user.id, Number(arg));
            await i.editReply("Resposta registrada!");
            return;
        }
        if (action === "stats") {
            await i.deferReply({ flags: discord_js_1.MessageFlags.Ephemeral });
            await i.editReply(await (0, admin_1.statsView)(i.guild, id, Math.max(0, Number(arg) || 0)));
            return;
        }
        await authorized(i);
        if (action === "rules" || action === "rulesExtra") {
            await i.deferReply({ flags: discord_js_1.MessageFlags.Ephemeral });
            await i.editReply(await (0, rules_1.rulesView)(i.guild, action === "rulesExtra"));
            return;
        }
        if (action === "qadd" || action === "qedit") {
            await questionModal(i, action === "qedit" ? id : undefined);
            return;
        }
        await i.deferReply({ flags: discord_js_1.MessageFlags.Ephemeral });
        if (action === "back") {
            await i.editReply(await (0, admPanel_1.buildAdmSectionPanel)(i.guild, "staff"));
            return;
        }
        if (["home", "config", "players", "questions", "game"].includes(action)) {
            await i.editReply(await (0, admin_1.adminView)(i.guild, action, Math.max(0, Number(id) || 0)));
            return;
        }
        if (action === "create") {
            await (0, service_1.createGame)(i.guild, i.user.id);
            await i.editReply(await (0, admin_1.adminView)(i.guild, "game"));
            return;
        }
        if (action === "history") {
            const game = await prisma_1.prisma.warGame.findFirst({ where: { guildId: i.guild.id }, orderBy: { createdAt: "desc" } });
            if (!game)
                throw new Error("Nenhuma partida registrada.");
            await i.editReply(await (0, admin_1.statsView)(i.guild, game.id));
            return;
        }
        if (action === "detect" || action === "roster") {
            await i.editReply(await (0, admin_1.rosterView)(i.guild, Math.max(0, Number(id) || 0)));
            return;
        }
        if (action === "qdelete" || action === "qtoggle") {
            const q = await prisma_1.prisma.warQuestion.findFirst({ where: { id, guildId: i.guild.id, deleted: false } });
            if (!q)
                throw new Error("Pergunta não encontrada.");
            await prisma_1.prisma.warQuestion.update({ where: { id }, data: action === "qdelete" ? { deleted: true, enabled: false } : { enabled: !q.enabled } });
            await i.editReply(await (0, admin_1.adminView)(i.guild, "questions"));
            return;
        }
        if (action === "finishAsk") {
            await i.editReply({ content: "Encerrar esta partida agora? O placar e o histórico serão preservados.", components: [new discord_js_1.ActionRowBuilder().addComponents((0, admin_1.button)(`finish:${id}`, "Confirmar encerramento", discord_js_1.ButtonStyle.Danger), (0, admin_1.button)("game", "Cancelar"))] });
            return;
        }
        await (0, service_1.control)(i.guild, action, i.user.id, id, Number(arg));
        await i.editReply(await (0, admin_1.adminView)(i.guild, "game"));
    }
    catch (error) {
        await fail(i, error);
    }
}
async function warSelect(i) {
    try {
        await authorized(i);
        const action = i.customId.split(":")[1];
        if (action === "rule") {
            const key = i.customId.split(":")[2];
            if (!["rounds", "seconds", "lightningChance", "difficulty", "firstTeam"].includes(key))
                throw new Error("Regra inválida.");
            if (i.values[0] === "custom" && key in rules_1.numericRules) {
                const c = await (0, repository_1.settings)(i.guild.id), rule = rules_1.numericRules[key];
                await i.showModal(new discord_js_1.ModalBuilder().setCustomId(`war-modal:rule:${key}`).setTitle(rule.label).addComponents(field("number", `Somente número (${rule.min} a ${rule.max})`, String(c[key]))));
                return;
            }
            await i.deferUpdate();
            const value = key in rules_1.numericRules ? (0, rules_1.parseRuleNumber)(key, i.values[0]) : i.values[0];
            await (0, rules_1.saveRules)(i.guild, { [key]: value });
            await i.editReply(await (0, rules_1.rulesView)(i.guild, key === "difficulty" || key === "firstTeam"));
            return;
        }
        if (!["page", "question", "channelId", "logChannelId"].includes(action))
            throw new Error("Este controle antigo foi substituído. Reabra /guerra; os participantes entram pelos botões da embed.");
        await i.deferUpdate();
        if (action === "page") {
            await i.editReply(await (0, admin_1.adminView)(i.guild, i.values[0]));
            return;
        }
        if (action === "question") {
            const q = await prisma_1.prisma.warQuestion.findFirst({ where: { id: i.values[0], guildId: i.guild.id, deleted: false } });
            if (!q)
                throw new Error("Pergunta não encontrada.");
            await i.editReply({ content: `**${q.category} • ${q.difficulty} • ${q.enabled ? "Ativa" : "Inativa"}**\n${q.text}\n\n${JSON.parse(q.options).map((o, n) => `${"ABCD"[n]}) ${o}`).join("\n")}\n\nCorreta: **${"ABCD"[q.correct]}**`, embeds: [], components: [new discord_js_1.ActionRowBuilder().addComponents((0, admin_1.button)(`qedit:${q.id}`, "Editar"), (0, admin_1.button)(`qtoggle:${q.id}`, "Ativar / Desativar"), (0, admin_1.button)(`qdelete:${q.id}`, "Excluir", discord_js_1.ButtonStyle.Danger), (0, admin_1.button)("questions", "Voltar"))] });
            return;
        }
        await (0, repository_1.settings)(i.guild.id);
        await prisma_1.prisma.warSettings.update({ where: { guildId: i.guild.id }, data: { [action]: i.values[0] } });
        await i.editReply(await (0, admin_1.adminView)(i.guild, action.endsWith("Players") ? "players" : "config"));
    }
    catch (error) {
        await fail(i, error);
    }
}
async function warModal(i) {
    try {
        await authorized(i);
        await i.deferReply({ flags: discord_js_1.MessageFlags.Ephemeral });
        const [, action, id] = i.customId.split(":"), value = (name) => i.fields.getTextInputValue(name).trim();
        if (action === "rule") {
            if (!(id in rules_1.numericRules))
                throw new Error("Regra inválida.");
            await (0, rules_1.saveRules)(i.guild, { [id]: (0, rules_1.parseRuleNumber)(id, value("number")) });
            await i.editReply(await (0, rules_1.rulesView)(i.guild));
            return;
        }
        if (action === "rules") {
            const rounds = Number(value("rounds")), seconds = Number(value("seconds")), lightningChance = Number(value("chance")), difficulty = difficultyValue(value("difficulty")), firstTeam = firstTeamValue(value("first"));
            if (!Number.isInteger(rounds) || rounds < 1 || rounds > 500 || !Number.isInteger(seconds) || seconds < 5 || seconds > 600 || !Number.isInteger(lightningChance) || lightningChance < 0 || lightningChance > 50)
                throw new Error("Use 1–500 rodadas, 5–600 segundos e 0–50% de relâmpago.");
            if (!["EASY", "MEDIUM", "HARD", "RANDOM"].includes(difficulty) || !["GIRLS", "BOYS", "RANDOM"].includes(firstTeam))
                throw new Error("Use as opções indicadas nos campos de dificuldade e primeiro time.");
            await (0, rules_1.saveRules)(i.guild, { rounds, seconds, lightningChance, difficulty, firstTeam });
            await i.editReply(await (0, admin_1.adminView)(i.guild, "config"));
            return;
        }
        if (action === "question") {
            const category = value("category"), difficulty = difficultyValue(value("difficulty")), text = value("text"), options = value("options").split(/\r?\n/).map((v) => v.trim()).filter(Boolean), [letter, aliasText = ""] = value("correct").split("|"), correct = "ABCD".indexOf(letter.trim().toUpperCase());
            if (!questions_1.categories.includes(category))
                throw new Error(`Categoria inválida. Opções: ${questions_1.categories.join(", ")}.`);
            if (!["EASY", "MEDIUM", "HARD"].includes(difficulty) || options.length !== (category === questions_1.lightningCategory ? 1 : 4) || new Set(options).size !== options.length || correct >= options.length || correct < 0 || letter.trim().length !== 1 || text.length > 800 || options.some((o) => o.length > 200))
                throw new Error("Use 4 alternativas distintas nas perguntas normais. Em Pergunta Relâmpago, use apenas a resposta e letra A. Máximo: 800 caracteres na pergunta e 200 por alternativa.");
            const data = { category, difficulty, text, options: JSON.stringify(options), correct, aliases: JSON.stringify(aliasText.split(";").map((v) => v.trim()).filter(Boolean)) };
            if (id === "new")
                await prisma_1.prisma.warQuestion.create({ data: { guildId: i.guild.id, ...data } });
            else {
                const changed = await prisma_1.prisma.warQuestion.updateMany({ where: { id, guildId: i.guild.id, deleted: false }, data });
                if (!changed.count)
                    throw new Error("Pergunta não encontrada.");
            }
            await i.editReply(await (0, admin_1.adminView)(i.guild, "questions"));
        }
    }
    catch (error) {
        await fail(i, error);
    }
}
//# sourceMappingURL=interactions.js.map