"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.button = void 0;
exports.adminView = adminView;
exports.rosterView = rosterView;
exports.statsView = statsView;
const discord_js_1 = require("discord.js");
const prisma_1 = require("../database/prisma");
const embeds_1 = require("../utils/embeds");
const repository_1 = require("./repository");
const players_1 = require("./players");
const questions_1 = require("./questions");
const views_1 = require("./views");
const button = (action, label, style = discord_js_1.ButtonStyle.Secondary) => new discord_js_1.ButtonBuilder().setCustomId(`war:${action}`).setLabel(label).setStyle(style);
exports.button = button;
const row = (...buttons) => new discord_js_1.ActionRowBuilder().addComponents(...buttons);
async function adminView(guild, page = "home", offset = 0) {
    const c = await (0, repository_1.settings)(guild.id), game = await (0, repository_1.activeGame)(guild.id);
    const embed = require("../utils/adminUi").adminEmbed(guild,"staff").setTitle("Quiz em equipes · Central do evento");
    const components = [];
    if (page === "home") {
        embed.setDescription("**Dois lados. Uma só vitória.**\n\nConfigure os times, prepare as perguntas e conduza o evento por aqui.").addFields({ name: "Partida", value: game ? `${(0, repository_1.statusLabel)(game.status)} • Rodada ${game.number}\nMENINAS **${game.girlsScore}** × **${game.boysScore}** MENINOS` : "Nenhuma partida ativa." }, { name: "Regras", value: `${c.rounds} perguntas • ${c.seconds}s • ${c.lightningChance}% relâmpago\nDificuldade: ${(0, repository_1.difficultyLabel)(c.difficulty)} • Participantes: entrada voluntária pelos botões` });
        components.push(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.StringSelectMenuBuilder().setCustomId("war-select:page").setPlaceholder("Escolha uma área").addOptions({ label: "Configuração", value: "config" }, { label: "Participantes", value: "players" }, { label: "Perguntas", value: "questions" }, { label: "Partida • Controles", value: "game" })));
        components.push(row((0, exports.button)("back", "Voltar")));
    }
    else if (page === "config") {
        embed.setDescription(`**Entrada pelos botões da embed**\nCada pessoa escolhe Meninas ou Meninos. Nenhum cargo é necessário.\n\n${c.rounds} rodadas • ${c.seconds}s\nDificuldade: ${(0, repository_1.difficultyLabel)(c.difficulty)}\nRelâmpago: ${c.lightningChance}%\n\nJogo: ${c.channelId ? `<#${c.channelId}>` : "Não configurado"}\nLogs: ${c.logChannelId ? `<#${c.logChannelId}>` : "Não configurado"}`);
        for (const [key, label] of [["channelId", "Canal do jogo"], ["logChannelId", "Canal de logs"]])
            components.push(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ChannelSelectMenuBuilder().setCustomId(`war-select:${key}`).setPlaceholder(label).setChannelTypes(discord_js_1.ChannelType.GuildText).setMaxValues(1)));
        components.push(row((0, exports.button)("rules", "Regras e duração", discord_js_1.ButtonStyle.Primary), (0, exports.button)("home", "Voltar")));
    }
    else if (page === "players") {
        embed.setDescription("**Participação voluntária**\n\nCrie a partida para publicar a embed. Cada pessoa escolhe seu time pelos botões **Meninas** ou **Meninos**.\n\nNão há inclusão por cargo ou seleção automática. A lista fecha quando a staff inicia. Staff e bots continuam fora da competição.");
        components.push(row((0, exports.button)("detect", "Ver inscritos", discord_js_1.ButtonStyle.Primary), (0, exports.button)("game", "Partida"), (0, exports.button)("home", "Voltar")));
    }
    else if (page === "questions") {
        await (0, questions_1.seedQuestions)(guild.id);
        const all = await prisma_1.prisma.warQuestion.findMany({ where: { guildId: guild.id, deleted: false }, orderBy: [{ category: "asc" }, { id: "asc" }] }), visible = all.slice(offset * 25, offset * 25 + 25);
        const counts = new Map();
        for (const q of all)
            counts.set(q.category, (counts.get(q.category) || 0) + 1);
        embed.setDescription(`**${all.length} cadastradas • ${all.filter(q => q.enabled).length} ativas**\n\n${[...counts].map(([name, count]) => `${name}: **${count}**`).join("\n")}\n\nSelecione uma pergunta para editar, excluir ou ativar.`).setFooter({ text: `AUDAZ • Perguntas • Página ${offset + 1}` });
        if (visible.length)
            components.push(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.StringSelectMenuBuilder().setCustomId("war-select:question").setPlaceholder("Gerenciar pergunta").addOptions(visible.map(q => ({ label: q.text.slice(0, 100), value: q.id, description: `${q.category} • ${q.difficulty} • ${q.enabled ? "Ativa" : "Inativa"}`.slice(0, 100) })))));
        components.push(row((0, exports.button)("qadd", "Adicionar", discord_js_1.ButtonStyle.Primary), (0, exports.button)(`questions:${Math.max(0, offset - 1)}`, "Anterior"), (0, exports.button)(`questions:${offset + 1}`, "Próxima").setDisabled((offset + 1) * 25 >= all.length), (0, exports.button)("home", "Voltar")));
    }
    else if (page === "game") {
        embed.setDescription(game ? `**${(0, repository_1.statusLabel)(game.status).toUpperCase()}** • Rodada ${game.number}/${game.totalRounds}\n\nMENINAS **${game.girlsScore}** × **${game.boysScore}** MENINOS\n${game.notice || "Use os controles abaixo."}` : "Crie a partida para publicar a apresentação dos times. As configurações são copiadas para esta partida.");
        if (game) {
            components.push(row((0, exports.button)(`start:${game.id}`, "Iniciar", discord_js_1.ButtonStyle.Success).setDisabled(game.status !== "waiting"), (0, exports.button)(`pause:${game.id}`, "Pausar").setDisabled(game.status !== "running"), (0, exports.button)(`resume:${game.id}`, "Continuar", discord_js_1.ButtonStyle.Primary).setDisabled(game.status !== "paused")));
            components.push(row((0, exports.button)(`next:${game.id}`, "Próxima"), (0, exports.button)(`void:${game.id}`, "Anular"), (0, exports.button)(`finishAsk:${game.id}`, "Finalizar", discord_js_1.ButtonStyle.Danger)));
            components.push(row((0, exports.button)(`girls:${game.id}:1`, "Meninas +1"), (0, exports.button)(`girls:${game.id}:-1`, "Meninas −1"), (0, exports.button)(`boys:${game.id}:1`, "Meninos +1"), (0, exports.button)(`boys:${game.id}:-1`, "Meninos −1")));
            components.push(row((0, exports.button)(`stats:${game.id}`, "Estatísticas"), (0, exports.button)("home", "Voltar")));
        }
        else
            components.push(row((0, exports.button)("create", "Criar partida", discord_js_1.ButtonStyle.Primary), (0, exports.button)("history", "Última partida"), (0, exports.button)("home", "Voltar")));
    }
    return { embeds: [embed], components };
}
async function rosterView(guild, page = 0) {
    const game = await (0, repository_1.activeGame)(guild.id), players = game ? await prisma_1.prisma.warPlayer.findMany({ where: { gameId: game.id, active: true }, orderBy: [{ team: "asc" }, { userId: "asc" }] }) : await (0, players_1.detectPlayers)(guild);
    const pages = Math.max(1, Math.ceil(players.length / 10)), current = Math.min(page, pages - 1);
    const embed = (await (0, embeds_1.baseEmbed)(guild)).setColor(0xd20b20).setTitle("AUDAZ EM GUERRA • Participantes").setDescription(players.slice(current * 10, current * 10 + 10).map(p => `<@${p.userId}> • **${(0, repository_1.teamName)(p.team)}**`).join("\n") || "Nenhum participante elegível.").addFields({ name: "MENINAS", value: String(players.filter(p => p.team === "GIRLS").length), inline: true }, { name: "MENINOS", value: String(players.filter(p => p.team === "BOYS").length), inline: true }).setFooter({ text: `AUDAZ • Página ${current + 1}/${pages}` });
    return { embeds: [embed], components: [row((0, exports.button)(`roster:${Math.max(0, current - 1)}`, "Anterior").setDisabled(current === 0), (0, exports.button)(`roster:${current + 1}`, "Próxima").setDisabled(current + 1 >= pages), (0, exports.button)("players", "Voltar"))] };
}
async function statsView(guild, id, page = 0) {
    const game = await prisma_1.prisma.warGame.findUnique({ where: { id } });
    if (!game || game.guildId !== guild.id)
        throw new Error("Partida não encontrada.");
    const stats = await (0, views_1.statistics)(id), sorted = stats.sort((a, b) => b.correct - a.correct), rounds = await prisma_1.prisma.warRound.findMany({ where: { gameId: id } });
    const themes = new Map();
    rounds.forEach(r => themes.set(r.category, (themes.get(r.category) || 0) + 1));
    const top = [...themes].sort((a, b) => b[1] - a[1])[0];
    const embed = (await (0, embeds_1.baseEmbed)(guild)).setColor(0xd20b20).setTitle("AUDAZ EM GUERRA • Estatísticas").setDescription(sorted.slice(page * 5, page * 5 + 5).map(p => `<@${p.userId}> • ${(0, repository_1.teamName)(p.team)}\n**${p.correct} pontos/acertos** • ${p.answered} perguntas respondidas\n${p.errors} tentativas erradas • ${p.lightning} relâmpagos vencidos`).join("\n\n") || "Sem participantes.");
    for (const team of ["GIRLS", "BOYS"]) {
        const group = stats.filter(p => p.team === team), correct = group.reduce((s, p) => s + p.correct, 0), answered = group.reduce((s, p) => s + p.answered, 0);
        embed.addFields({ name: (0, repository_1.teamName)(team), value: `${correct} acertos / ${answered} participações em perguntas\n${group.reduce((s, p) => s + p.errors, 0)} erros • ${group.reduce((s, p) => s + p.lightning, 0)} relâmpagos\nAproveitamento: ${answered ? Math.round(correct / answered * 100) : 0}%`, inline: true });
    }
    embed.setFooter({ text: `Página ${page + 1} • ${rounds.length} perguntas • Tema mais sorteado: ${top?.[0] || "—"}` });
    return { embeds: [embed], components: [row((0, exports.button)(`stats:${id}:${Math.max(0, page - 1)}`, "Anterior").setDisabled(page === 0), (0, exports.button)(`stats:${id}:${page + 1}`, "Próxima").setDisabled((page + 1) * 5 >= stats.length))] };
}
//# sourceMappingURL=admin.js.map