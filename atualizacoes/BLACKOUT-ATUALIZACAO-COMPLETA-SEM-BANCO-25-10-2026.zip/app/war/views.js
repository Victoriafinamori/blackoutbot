"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.statistics = statistics;
exports.gameView = gameView;
const discord_js_1 = require("discord.js");
const embeds_1 = require("../utils/embeds");
const prisma_1 = require("../database/prisma");
const repository_1 = require("./repository");
async function statistics(gameId) {
    const rounds = await prisma_1.prisma.warRound.findMany({ where: { gameId }, include: { answers: true } });
    const players = await prisma_1.prisma.warPlayer.findMany({ where: { gameId } });
    return players.map(p => {
        const valid = rounds.filter(r => !["void", "skipped"].includes(r.status));
        const answers = valid.flatMap(r => r.answers.filter(a => a.userId === p.userId));
        const wins = valid.filter(r => r.winnerId === p.userId && r.status === "correct");
        return { ...p, answered: new Set(answers.map(a => a.roundId)).size, correct: wins.length, errors: answers.filter(a => !a.correct).length, lightning: wins.filter(r => r.lightning).length };
    });
}
async function gameView(guild, game) {
    const r = await (0, repository_1.currentRound)(game.id, game.number), players = await prisma_1.prisma.warPlayer.findMany({ where: { gameId: game.id, active: true } });
    const embed = (await (0, embeds_1.baseEmbed)(guild)).setColor(r && !r.lightning ? (0, repository_1.teamColor)(r.team) : 0xd20b20).setTitle("Quiz em equipes");
    embed.setFields({ name: "MENINAS", value: `**${String(game.girlsScore).padStart(2, "0")} pontos**\n${players.filter(p => p.team === "GIRLS").length} participantes`, inline: true }, { name: "MENINOS", value: `**${String(game.boysScore).padStart(2, "0")} pontos**\n${players.filter(p => p.team === "BOYS").length} participantes`, inline: true }).setFooter({ text: `AUDAZ • Rodada ${game.number}/${game.totalRounds} • Próxima vez: ${(0, repository_1.teamName)(game.nextTeam)}` });
    const components = [];
    if (game.status === "waiting") {
        embed.setDescription(`**Dois lados. Uma só vitória.**\n\nEscolha **Meninas** ou **Meninos** nos botões para participar!\nSomente quem entrar será sorteado. Sem cargos obrigatórios.\n\n${game.totalRounds} perguntas • ${game.seconds}s por resposta\n⚡ Relâmpago: ${game.lightningChance}%\n\nVocê pode trocar de time ou sair antes do início.`);
        components.push(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId(`war:join:${game.id}:GIRLS`).setLabel("Meninas").setStyle(discord_js_1.ButtonStyle.Secondary), new discord_js_1.ButtonBuilder().setCustomId(`war:join:${game.id}:BOYS`).setLabel("Meninos").setStyle(discord_js_1.ButtonStyle.Primary), new discord_js_1.ButtonBuilder().setCustomId(`war:join:${game.id}:LEAVE`).setLabel("Sair").setStyle(discord_js_1.ButtonStyle.Secondary)));
        components.push(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId(`war:start:${game.id}`).setLabel("INICIAR GUERRA").setStyle(discord_js_1.ButtonStyle.Danger)));
    }
    else if (game.status === "finished") {
        const stats = await statistics(game.id), maximum = Math.max(0, ...stats.map(p => p.correct)), mvps = stats.filter(p => p.correct === maximum && maximum > 0);
        embed.setDescription(`**${game.girlsScore === game.boysScore ? "PARTIDA ENCERRADA — EMPATE" : `${game.girlsScore > game.boysScore ? "MENINAS" : "MENINOS"} VENCERAM!`}**\n\n${game.notice || "A guerra chegou ao fim. Obrigado por participar!"}`);
        embed.addFields({ name: "MVP DA PARTIDA", value: mvps.length ? `${mvps.slice(0, 25).map(p => `<@${p.userId}>`).join(" · ")}\n**${maximum} acertos**${mvps.length > 25 ? " • Todos os empatados em Estatísticas" : ""}` : "Nenhum acerto nesta partida." }, { name: "Duração · Perguntas", value: `${Math.ceil(((game.finishedAt?.getTime() || Date.now()) - (game.startedAt?.getTime() || game.createdAt.getTime())) / 60000)} min • ${game.number} perguntas` }, { name: "Acertos por time", value: `MENINAS: **${stats.filter(p => p.team === "GIRLS").reduce((s, p) => s + p.correct, 0)}** • MENINOS: **${stats.filter(p => p.team === "BOYS").reduce((s, p) => s + p.correct, 0)}**` });
        components.push(new discord_js_1.ActionRowBuilder().addComponents(new discord_js_1.ButtonBuilder().setCustomId(`war:stats:${game.id}`).setLabel("Estatísticas").setStyle(discord_js_1.ButtonStyle.Secondary)));
    }
    else if (game.status === "paused") {
        embed.setDescription(`**PARTIDA PAUSADA**\n\n${game.notice || "A staff pausou o evento."}\nO cronômetro está parado.`);
    }
    else if (game.phase === "countdown")
        embed.setDescription(`**A GUERRA VAI COMEÇAR**\n\n# ${game.countdown}\n\nPrimeiro time: **${(0, repository_1.teamName)(game.nextTeam)}**`);
    else if (r) {
        if (game.phase === "theme")
            embed.setDescription(`**${r.tiebreak ? "DESEMPATE RELÂMPAGO" : r.lightning ? "⚡ RODADA RELÂMPAGO" : "TEMA SORTEADO"}**\n\n${r.category}\n\n${r.lightning ? "Todos os participantes podem responder no chat!" : `Vez de **${(0, repository_1.teamName)(r.team)}**\nParticipante: <@${r.playerId}>`}\n\nA pergunta aparece em instantes…`);
        if (game.phase === "question") {
            const options = JSON.parse(r.options);
            embed.setDescription(`**${r.tiebreak ? "⚡ DESEMPATE" : r.lightning ? "⚡ RELÂMPAGO" : r.category}**\n${r.lightning ? "Primeira resposta correta no chat vale o ponto." : `Respondendo: <@${r.playerId}>`}\n\n### ${r.text}\n${r.lightning ? "" : options.map((o, n) => `**${"ABCD"[n]})** ${o}`).join("\n")}\n\n⏱️ Encerra <t:${Math.ceil((game.deadline?.getTime() || Date.now()) / 1000)}:R>`);
            if (!r.lightning)
                components.push(new discord_js_1.ActionRowBuilder().addComponents(...options.map((_, n) => new discord_js_1.ButtonBuilder().setCustomId(`war:answer:${r.id}:${n}`).setLabel("ABCD"[n]).setStyle(discord_js_1.ButtonStyle.Secondary))));
        }
        if (game.phase === "result") {
            const lastAnswer = await prisma_1.prisma.warAnswer.findFirst({ where: { roundId: r.id }, orderBy: { createdAt: "desc" } });
            const titles = { correct: "RESPOSTA CORRETA!", wrong: "RESPOSTA INCORRETA", timeout: "TEMPO ESGOTADO", void: "PERGUNTA ANULADA", skipped: "PERGUNTA PULADA" };
            embed.setDescription(`**${titles[r.status] || "RODADA CONCLUÍDA"}**\n\n${r.winnerId ? `<@${r.winnerId}> ${r.lightning ? "venceu a Rodada Relâmpago!" : "acertou!"}\n**+1 ponto para ${(0, repository_1.teamName)(r.winnerTeam)}**` : "Nenhum ponto concedido."}${r.status === "wrong" && lastAnswer ? `\n<@${lastAnswer.userId}> respondeu: **${lastAnswer.text.slice(0, 300)}**` : ""}\n\nResposta correta: **${JSON.parse(r.options)[r.correct]}**\n\nPróxima rodada em instantes…`);
        }
    }
    return { embeds: [embed], components, allowedMentions: { parse: [] } };
}
//# sourceMappingURL=views.js.map