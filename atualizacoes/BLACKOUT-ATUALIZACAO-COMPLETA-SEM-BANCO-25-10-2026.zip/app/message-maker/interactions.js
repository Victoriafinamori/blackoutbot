"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.runSync = runSync;
exports.execute = execute;
exports.openHome = openHome;
exports.openRoles = openRoles;
exports.legacyEntry = legacyEntry;
const common_1 = require("./common");
const E = __importStar(require("./editorInteractions"));
const RI = __importStar(require("./roleInteractions"));
const R = __importStar(require("./roles"));
const S = __importStar(require("./service"));
const V = __importStar(require("./views"));
const document_1 = require("./document");
const admPanel_1 = require("../utils/admPanel");
async function runSync(i, id, first = false) {
    let a = await (0, common_1.getAction)(i, id, first);
    (0, common_1.assert)(a.kind === "SYNC", "Revisão inválida.");
    if (!first && a.status !== "MORE")
        return (0, common_1.show)(i, await V.syncProgress(i.guild, a));
    const data = JSON.parse(a.payloadJson), p = await R.panel(i.guild.id, data.panelId);
    (0, common_1.assert)(p.status === "ACTIVE" && p.revision === data.revision, "O painel mudou. Gere uma nova revisão de participações.");
    if (!first) {
        const claimed = await common_1.prisma.makerAction.updateMany({
            where: { id, status: "MORE", cursor: a.cursor },
            data: { status: "RUNNING" },
        });
        if (!claimed.count)
            return (0, common_1.show)(i, await V.syncProgress(i.guild, await (0, common_1.getAction)(i, id)));
    }
    const end = Math.min(a.cursor + 25, data.items.length);
    for (let n = a.cursor; n < end; n++) {
        try {
            await R.syncItem(i.guild, data.panelId, data.items[n]);
        }
        catch (e) {
            data.errors.push({
                index: n,
                message: e instanceof document_1.MakerError ? e.message : "Falha de processamento",
            });
        }
    }
    a = await common_1.prisma.makerAction.update({
        where: { id },
        data: {
            cursor: end,
            payloadJson: JSON.stringify(data),
            status: end >= data.items.length ? "DONE" : "MORE",
        },
    });
    return (0, common_1.show)(i, await V.syncProgress(i.guild, a));
}
async function confirm(i, id) {
    const preview = await (0, common_1.getAction)(i, id), data = JSON.parse(preview.payloadJson);
    if (preview.kind === "SYNC")
        return runSync(i, id, true);
    const op = await (0, common_1.getAction)(i, id, true);
    if (op.kind === "PUBLISH") {
        const s = await (0, common_1.session)(i, data.sessionId, data.revision);
        (0, common_1.assert)(s.documentJson === data.documentJson &&
            s.destinationChannelId === data.channelId &&
            s.publicationId === data.publicationId, "A revisão mudou. Confira novamente.");
        const p = await S.publishSession(i, s);
        await common_1.prisma.makerAction.update({
            where: { id },
            data: { status: "DONE" },
        });
        return (0, common_1.show)(i, await V.publicationView(i.guild, p.id));
    }
    if (op.kind === "ROLE_PUBLISH") {
        await R.publish(i.guild, op.targetId, data.revision);
        await common_1.prisma.makerAction.update({
            where: { id },
            data: { status: "DONE" },
        });
        return (0, common_1.show)(i, await V.roleDetail(i.guild, op.targetId, "Painel publicado e reações preparadas."));
    }
    if (op.kind === "TEMPLATE_DELETE") {
        const r = await common_1.prisma.makerTemplate.updateMany({
            where: {
                id: op.targetId,
                guildId: i.guild.id,
                deletedAt: null,
                revision: data.revision,
            },
            data: { deletedAt: new Date(), revision: { increment: 1 } },
        });
        (0, common_1.assert)(r.count === 1, "O modelo mudou. Abra uma nova revisão.");
        return (0, common_1.show)(i, await V.templates(i.guild));
    }
    if (op.kind === "PUB_DELETE") {
        const p = await S.publication(i.guild.id, op.targetId);
        (0, common_1.assert)(p.revision === data.revision && !p.panelId, "A publicação mudou. Abra uma nova revisão.");
        const message = await S.fetchMessage(i.guild, p);
        try {
            await message.delete();
        }
        catch {
            throw new document_1.MakerError("Não foi possível confirmar a exclusão. Confira a mensagem original antes de repetir.");
        }
        await common_1.prisma.makerPublication.update({
            where: { id: p.id },
            data: { status: "DELETED", lastError: null, revision: { increment: 1 } },
        });
        return (0, common_1.show)(i, await V.publications(i.guild));
    }
    if (op.kind === "BINDING_KEEP" || op.kind === "BINDING_REVOKE") {
        const current = await common_1.prisma.reactionRoleGrant.count({
            where: { guildId: i.guild.id, bindingId: op.targetId, active: true },
        });
        (0, common_1.assert)(current === data.count, "A quantidade de participações mudou. Confira uma nova revisão.");
        const b = await R.disable(i.guild, op.targetId, op.kind === "BINDING_KEEP");
        if (op.kind === "BINDING_REVOKE")
            await R.revokeBatch(i.guild, op.targetId);
        return (0, common_1.show)(i, await V.roleBindings(i.guild, b.panelId));
    }
    throw new document_1.MakerError("Esta ação não está disponível.");
}
function matches(expected, actual) {
    if (Array.isArray(expected))
        return (Array.isArray(actual) &&
            expected.length === actual.length &&
            expected.every((v, n) => matches(v, actual[n])));
    if (expected && typeof expected === "object")
        return (actual &&
            Object.keys(expected)
                .filter((k) => k !== "id")
                .every((k) => matches(expected[k], actual[k])));
    if (expected === false && actual === undefined)
        return true;
    return expected === actual;
}
async function register(i, id) {
    const a = await (0, common_1.getAction)(i, id, true);
    (0, common_1.assert)(a.kind === "REGISTER", "Formulário inválido.");
    const p = await S.publication(i.guild.id, a.targetId);
    (0, common_1.assert)(!p.messageId, "Esta publicação já tem uma mensagem registrada.");
    const messageId = i.fields.getTextInputValue("message").trim();
    (0, common_1.assert)(/^[0-9]{17,22}$/.test(messageId), "Informe o ID numérico da mensagem.");
    const ch = await S.channel(i.guild, p.channelId), m = await ch.messages.fetch(messageId).catch(() => null);
    (0, common_1.assert)(m?.author?.id === i.guild.client.user.id && m.channelId === p.channelId, "A mensagem precisa ter sido enviada por este bot no canal registrado.");
    const actual = m.components.map((c) => (c.toJSON ? c.toJSON() : c));
    let valid = matches((0, document_1.render)(p.snapshotJson).components.map((c) => c.toJSON()), actual);
    if (!valid && p.panelId) {
        const panel = await R.panel(i.guild.id, p.panelId);
        valid = matches((0, document_1.render)(R.withLegend((0, document_1.parse)(panel.documentJson), await R.bindings(i.guild.id, panel.id), panel.removeOnUnreact, true)).components.map((c) => c.toJSON()), actual);
    }
    (0, common_1.assert)(valid, "O conteúdo da mensagem não corresponde a este envio. Nenhuma outra mensagem do bot foi vinculada.");
    const r = await common_1.prisma.makerPublication.updateMany({
        where: { id: p.id, guildId: i.guild.id, messageId: null },
        data: {
            messageId,
            status: p.panelId ? "ACTIVATING" : "ACTIVE",
            legacy: false,
            lastError: null,
        },
    });
    (0, common_1.assert)(r.count === 1, "Esta publicação mudou. Abra novamente.");
    return (0, common_1.show)(i, p.panelId
        ? await V.roleDetail(i.guild, p.panelId, "Mensagem registrada. Use Publicar / atualizar para concluir a ativação.")
        : await V.publicationView(i.guild, p.id));
}
async function execute(i) {
    return (0, common_1.guard)(i, async () => {
        const [prefix, ...parts] = i.customId.split(":"), name = parts[0];
        const modalLaunch = (prefix === "maker" &&
            ["appearance", "link", "button-edit", "pub-register"].includes(name)) ||
            (prefix === "maker-select" &&
                ["block", "add", "button-channel", "r-role"].includes(name));
        if (!modalLaunch)
            await (0, common_1.deferPanel)(i);
        if (prefix === "maker") {
            if (name === "confirm")
                return confirm(i, parts[1]);
            if (name === "confirm-view")
                return (0, common_1.show)(i, await V.confirmation(i.guild, await (0, common_1.getAction)(i, parts[1]), Number(parts[2])));
            if (name === "sync-next")
                return runSync(i, parts[1]);
            if (name === "area")
                return (0, common_1.show)(i, await (0, admPanel_1.buildAdmSectionPanel)(i.guild, parts[1]));
            if (name === "root")
                return (0, common_1.show)(i, await (0, admPanel_1.buildAdmRootPanel)(i.guild, i.user));
            if (name === "automations")
                return require("./navigation").automations(i);
            if (name.startsWith("r-"))
                return RI.buttons(i, parts);
            const result = await E.buttonAction(i, parts);
            if (result !== false)
                return result;
        }
        if (prefix === "maker-select") {
            if (name === "automation") {
                const choice = i.values[0];
                if (choice === "arrival")
                    return require("../components/buttons/admConfigMenu").renderAutoRoleMenu(i);
                if (choice === "transfer")
                    return require("../components/buttons/admRoleTransferMenu").renderRoleTransferMenu(i);
                if (choice === "reactions")
                    return (0, common_1.show)(i, await V.roleHome(i.guild));
            }
            const result = name.startsWith("r-")
                ? await RI.selects(i, parts)
                : await E.selectAction(i, parts);
            if (result !== false)
                return result;
        }
        if (prefix === "maker-form") {
            if (name === "register")
                return register(i, parts[1]);
            const result = name === "binding"
                ? await RI.modals(i, parts)
                : await E.modalAction(i, parts);
            if (result !== false)
                return result;
        }
        throw new document_1.MakerError("Esta opção não está disponível. Reabra o painel com /adm.");
    });
}
async function openHome(i) {
    return (0, common_1.guard)(i, async () => {
        await (0, common_1.deferPanel)(i);
        return (0, common_1.show)(i, await V.home(i.guild));
    });
}
async function openRoles(i) {
    return (0, common_1.guard)(i, async () => {
        await (0, common_1.deferPanel)(i);
        return (0, common_1.show)(i, await V.roleHome(i.guild));
    });
}
async function legacyEntry(i, legacyId) {
    return (0, common_1.guard)(i, async () => {
        await (0, common_1.deferPanel)(i);
        await S.importLegacy(i.guild.id);
        if (legacyId) {
            const t = await common_1.prisma.makerTemplate.findFirst({
                where: { guildId: i.guild.id, legacyId, deletedAt: null },
            });
            if (t)
                return (0, common_1.show)(i, await V.editor(i.guild, await S.start(i, { templateId: t.id })));
        }
        return (0, common_1.show)(i, await V.home(i.guild));
    });
}
