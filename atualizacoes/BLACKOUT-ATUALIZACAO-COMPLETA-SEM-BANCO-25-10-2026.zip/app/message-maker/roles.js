"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.panel = panel;
exports.create = create;
exports.bindings = bindings;
exports.emoji = emoji;
exports.safeRole = safeRole;
exports.addBinding = addBinding;
exports.withLegend = withLegend;
exports.publish = publish;
exports.grant = grant;
exports.release = release;
exports.onReaction = onReaction;
exports.pause = pause;
exports.disable = disable;
exports.revokeBatch = revokeBatch;
exports.inspect = inspect;
exports.planSync = planSync;
exports.syncItem = syncItem;
exports.messageDeleted = messageDeleted;
exports.reactionsCleared = reactionsCleared;
const common_1 = require("./common");
const document_1 = require("./document");
const service_1 = require("./service");
const dangerous = [
    common_1.D.PermissionFlagsBits.Administrator,
    common_1.D.PermissionFlagsBits.ManageGuild,
    common_1.D.PermissionFlagsBits.ManageRoles,
    common_1.D.PermissionFlagsBits.ManageChannels,
    common_1.D.PermissionFlagsBits.BanMembers,
    common_1.D.PermissionFlagsBits.KickMembers,
    common_1.D.PermissionFlagsBits.ModerateMembers,
    common_1.D.PermissionFlagsBits.ManageWebhooks,
    common_1.D.PermissionFlagsBits.ManageMessages,
    common_1.D.PermissionFlagsBits.MentionEveryone,
];
async function panel(guildId, id) {
    const p = await common_1.prisma.reactionRolePanel.findFirst({
        where: { id, guildId },
    });
    (0, common_1.assert)(p, "Este painel de cargos não pertence a este servidor.");
    return p;
}
async function create(guildId, actorId, document = (0, document_1.blank)(), name = "Novo painel de cargos") {
    return common_1.prisma.reactionRolePanel.create({
        data: {
            id: (0, common_1.uid)(),
            guildId,
            createdById: actorId,
            name,
            documentJson: JSON.stringify((0, document_1.parse)(document)),
        },
    });
}
async function bindings(guildId, panelId, published = false) {
    return common_1.prisma.reactionRoleBinding.findMany({
        where: {
            guildId,
            panelId,
            active: true,
            ...(published ? { published: true } : {}),
        },
        orderBy: { createdAt: "asc" },
    });
}
function emoji(value) {
    const custom = value
        .trim()
        .match(/^<(a?):([A-Za-z0-9_]{2,32}):([0-9]{17,22})>$/);
    if (custom)
        return {
            emojiKey: "c:" + custom[3],
            emojiApi: custom[3],
            emojiDisplay: value.trim(),
        };
    const text = value.trim().normalize("NFC");
    const parts = [
        ...new Intl.Segmenter("pt-BR", {
            granularity: "grapheme",
        }).segment(text),
    ];
    (0, common_1.assert)(parts.length === 1 &&
        /\p{Extended_Pictographic}|\p{Regional_Indicator}|\p{Emoji_Presentation}/u.test(text) &&
        text.length <= 20, "Use uma única reação, como 🎮, ou um emoji personalizado no formato <:nome:id>.");
    return {
        emojiKey: "u:" + text.replace(/\uFE0F/g, ""),
        emojiApi: text,
        emojiDisplay: text,
    };
}
async function safeRole(guild, id) {
    const role = await guild.roles.fetch(id).catch(() => null);
    (0, common_1.assert)(role && role.id !== guild.id && !role.managed && role.editable, "O cargo não existe ou não pode ser atribuído pelo bot. Confira a hierarquia e Gerenciar Cargos.");
    (0, common_1.assert)(!dangerous.some((p) => role.permissions?.has(p)), "Cargos com permissões de administração ou moderação não podem ser oferecidos por reação.");
    return role;
}
async function addBinding(guild, panelId, roleId, value, expectedRevision) {
    return (0, common_1.exclusive)("reaction-panel:" + panelId, async () => {
        const p = await panel(guild.id, panelId), e = emoji(value), list = await bindings(guild.id, p.id);
        if (expectedRevision !== undefined)
            (0, common_1.assert)(p.revision === expectedRevision, "O painel mudou. Abra novamente a associação.");
        await safeRole(guild, roleId);
        (0, common_1.assert)(list.length < 20, "Cada painel aceita até 20 reações diferentes.");
        (0, common_1.assert)(!list.some((b) => b.emojiKey === e.emojiKey), "Essa reação já está associada a um cargo neste painel.");
        if (e.emojiKey.startsWith("c:")) {
            const available = guild.emojis?.cache?.get(e.emojiApi) ||
                guild.client.emojis?.cache?.get(e.emojiApi) ||
                guild.client.application?.emojis?.cache?.get(e.emojiApi);
            (0, common_1.assert)(available && available.available !== false, "O bot não tem acesso a esse emoji personalizado. Escolha um emoji disponível para ele.");
        }
        const b = await common_1.prisma.reactionRoleBinding.create({
            data: { id: (0, common_1.uid)(), guildId: guild.id, panelId: p.id, roleId, ...e },
        });
        await common_1.prisma.reactionRolePanel.update({
            where: { id: p.id },
            data: { revision: { increment: 1 } },
        });
        return b;
    });
}
function withLegend(doc, list, remove, preparing = false) {
    const d = (0, document_1.copy)((0, document_1.parse)(doc));
    d.blocks.push({
        id: "role-legend",
        type: "text",
        text: (preparing
            ? "**Painel em preparação. Aguarde a ativação pela equipe.**\n\n"
            : "**Escolha seus cargos pelas reações:**\n") +
            list.map((b) => b.emojiDisplay + " → <@&" + b.roleId + ">").join("\n") +
            "\n\n" +
            (remove
                ? "Retirar a reação remove somente a concessão feita por este painel."
                : "O cargo permanece depois de retirar a reação."),
    });
    return d;
}
async function publish(guild, id, expectedRevision) {
    return (0, common_1.exclusive)("reaction-panel:" + id, async () => {
        let p = await panel(guild.id, id);
        (0, common_1.assert)(p.revision === expectedRevision, "O painel mudou. Confira novamente antes de publicar.");
        const list = await bindings(guild.id, p.id);
        (0, common_1.assert)(list.length > 0, "Associe pelo menos uma reação a um cargo.");
        for (const b of list)
            await safeRole(guild, b.roleId);
        const ch = await (0, service_1.channel)(guild, p.channelId, true), doc = withLegend((0, document_1.parse)(p.documentJson), list, p.removeOnUnreact), payload = (0, document_1.render)(doc), preparation = (0, document_1.render)(withLegend((0, document_1.parse)(p.documentJson), list, p.removeOnUnreact, true));
        let pub = p.publicationId
            ? await (0, service_1.publication)(guild.id, p.publicationId)
            : null, message = null;
        if (pub)
            message = await (0, service_1.fetchMessage)(guild, pub);
        else {
            pub = await common_1.prisma.makerPublication.create({
                data: {
                    id: (0, common_1.uid)(),
                    guildId: guild.id,
                    panelId: p.id,
                    channelId: ch.id,
                    name: p.name,
                    snapshotJson: JSON.stringify(doc),
                    createdById: p.createdById,
                },
            });
            await common_1.prisma.reactionRolePanel.update({
                where: { id: p.id },
                data: { publicationId: pub.id },
            });
        }
        (0, common_1.assert)(pub.channelId === ch.id, "O painel já foi publicado em outro canal. Crie uma cópia para mudar o destino.");
        await common_1.prisma.reactionRolePanel.update({
            where: { id: p.id },
            data: { status: "ACTIVATING", lastError: null },
        });
        try {
            if (message)
                await message.edit({
                    ...preparation,
                    content: null,
                    embeds: [],
                    attachments: [],
                });
            else {
                message = await ch.send(preparation);
                await common_1.prisma.makerPublication.update({
                    where: { id: pub.id },
                    data: { messageId: message.id, status: "ACTIVATING" },
                });
            }
            // Seed the active bindings without clearing members' existing reactions.
            for (const b of list)
                await message.react(b.emojiApi);
            await message.edit({
                ...payload,
                content: null,
                embeds: [],
                attachments: [],
            });
            await common_1.prisma.$transaction(async (tx) => {
                await tx.reactionRoleBinding.updateMany({
                    where: { guildId: guild.id, panelId: p.id, active: true },
                    data: { published: true },
                });
                await tx.makerPublication.update({
                    where: { id: pub.id },
                    data: {
                        messageId: message.id,
                        name: p.name,
                        snapshotJson: JSON.stringify(doc),
                        payloadHash: (0, document_1.hash)(doc),
                        status: "ACTIVE",
                        lastError: null,
                        revision: { increment: 1 },
                    },
                });
                await tx.reactionRolePanel.update({
                    where: { id: p.id },
                    data: {
                        status: "ACTIVE",
                        publishedRemoveOnUnreact: p.removeOnUnreact,
                        lastError: null,
                        revision: { increment: 1 },
                    },
                });
            });
        }
        catch (error) {
            await common_1.prisma.reactionRolePanel.update({
                where: { id: p.id },
                data: {
                    status: "ERROR",
                    lastError: "Ativação não concluída. Confira a mensagem e use Publicar / atualizar para concluir.",
                },
            });
            await common_1.prisma.makerPublication
                .update({
                where: { id: pub.id },
                data: {
                    messageId: message?.id || pub.messageId,
                    status: message ? "UNAVAILABLE" : "UNCERTAIN",
                    lastError: "Painel em preparação; novas concessões estão suspensas.",
                },
            })
                .catch(() => null);
            throw new document_1.MakerError("A ativação não terminou. O painel foi suspenso. Confira o canal e as permissões antes de concluir a ativação.");
        }
        return panel(guild.id, id);
    });
}
async function freshMember(guild, userId) {
    try {
        return await guild.members.fetch({ user: userId, force: true });
    }
    catch (error) {
        if (error?.code === 10007)
            return null;
        throw new document_1.MakerError("Não foi possível consultar o membro. Confira o diagnóstico e tente sincronizar novamente.");
    }
}
const ownershipWhere = (guildId, userId, roleId) => ({
    guildId_userId_roleId: { guildId, userId, roleId },
});
async function grant(guild, bindingId, userId) {
    const b = await common_1.prisma.reactionRoleBinding.findFirst({
        where: { id: bindingId, guildId: guild.id },
    });
    if (!b)
        return;
    return (0, common_1.exclusive)("reaction-role:" + guild.id + ":" + userId + ":" + b.roleId, async () => {
        const current = await common_1.prisma.reactionRoleBinding.findFirst({
            where: { id: b.id, guildId: guild.id, active: true, published: true },
        }), p = await panel(guild.id, b.panelId);
        if (!current || p.status !== "ACTIVE")
            return;
        const member = await freshMember(guild, userId);
        if (!member || member.user.bot)
            return;
        await safeRole(guild, b.roleId);
        const where = { bindingId_userId: { bindingId: b.id, userId } };
        const g = await common_1.prisma.reactionRoleGrant.upsert({
            where,
            create: {
                id: (0, common_1.uid)(),
                guildId: guild.id,
                panelId: p.id,
                bindingId: b.id,
                userId,
                roleId: b.roleId,
            },
            update: {},
        });
        const owns = member.roles.cache.has(b.roleId), key = ownershipWhere(guild.id, userId, b.roleId);
        let owner = await common_1.prisma.reactionRoleOwnership.findUnique({ where: key });
        if (!owner)
            owner = await common_1.prisma.reactionRoleOwnership.create({
                data: {
                    id: (0, common_1.uid)(),
                    guildId: guild.id,
                    userId,
                    roleId: b.roleId,
                    state: owns ? "PREEXISTING" : "PENDING",
                },
            });
        if (owns && ["PENDING", "REMOVING"].includes(owner.state)) {
            // A previous process may have stopped between API success and database write.
            owner = await common_1.prisma.reactionRoleOwnership.update({
                where: { id: owner.id },
                data: { state: "UNCERTAIN" },
            });
        }
        await common_1.prisma.reactionRoleGrant.update({
            where: { id: g.id },
            data: { active: true, status: "PENDING", lastError: null },
        });
        if (!owns) {
            await common_1.prisma.reactionRoleOwnership.update({
                where: { id: owner.id },
                data: { state: "PENDING" },
            });
            try {
                await member.roles.add(b.roleId, "BLACKOUT · Cargo escolhido por reação");
            }
            catch {
                await common_1.prisma.reactionRoleGrant.update({
                    where: { id: g.id },
                    data: {
                        status: "FAILED",
                        lastError: "Concessão não confirmada. Confira permissões e sincronize o painel.",
                    },
                });
                throw new document_1.MakerError("Não foi possível confirmar a concessão do cargo.");
            }
            await common_1.prisma.reactionRoleOwnership.update({
                where: { id: owner.id },
                data: { state: "OWNED" },
            });
        }
        return common_1.prisma.reactionRoleGrant.update({
            where: { id: g.id },
            data: { active: true, status: "ACTIVE", lastError: null },
        });
    });
}
async function release(guild, bindingId, userId, keep = false) {
    const g = await common_1.prisma.reactionRoleGrant.findUnique({
        where: { bindingId_userId: { bindingId, userId } },
    });
    if (!g || g.guildId !== guild.id)
        return;
    return (0, common_1.exclusive)("reaction-role:" + guild.id + ":" + userId + ":" + g.roleId, async () => {
        const current = await common_1.prisma.reactionRoleGrant.findUnique({
            where: { id: g.id },
        });
        if (!current.active && current.status !== "REVOKE_PENDING")
            return;
        await common_1.prisma.reactionRoleGrant.update({
            where: { id: g.id },
            data: { active: false, status: keep ? "RETAINED" : "REVOKE_PENDING" },
        });
        const key = ownershipWhere(guild.id, userId, g.roleId), owner = await common_1.prisma.reactionRoleOwnership.findUnique({ where: key });
        if (keep) {
            if (owner)
                await common_1.prisma.reactionRoleOwnership.update({
                    where: { id: owner.id },
                    data: { state: "PREEXISTING" },
                });
            return;
        }
        if (await common_1.prisma.reactionRoleGrant.count({
            where: { guildId: guild.id, userId, roleId: g.roleId, active: true },
        }))
            return common_1.prisma.reactionRoleGrant.update({
                where: { id: g.id },
                data: { status: "RELEASED", lastError: null },
            });
        const member = await freshMember(guild, userId);
        if (member?.roles.cache.has(g.roleId) && owner?.state === "OWNED") {
            await safeRole(guild, g.roleId);
            const claimed = await common_1.prisma.reactionRoleOwnership.updateMany({
                where: { id: owner.id, state: "OWNED" },
                data: { state: "REMOVING" },
            });
            if (claimed.count) {
                try {
                    await member.roles.remove(g.roleId, "BLACKOUT · Concessão por reação retirada");
                }
                catch {
                    await common_1.prisma.reactionRoleGrant.update({
                        where: { id: g.id },
                        data: {
                            status: "REVOKE_PENDING",
                            lastError: "Retirada não confirmada. Confira o membro e repita a revisão.",
                        },
                    });
                    throw new document_1.MakerError("Não foi possível confirmar a retirada do cargo.");
                }
                await common_1.prisma.reactionRoleOwnership.update({
                    where: { id: owner.id },
                    data: { state: "EMPTY" },
                });
            }
        }
        else if (owner && ["PENDING", "REMOVING"].includes(owner.state))
            await common_1.prisma.reactionRoleOwnership.update({
                where: { id: owner.id },
                data: {
                    state: member?.roles.cache.has(g.roleId) ? "UNCERTAIN" : "EMPTY",
                },
            });
        return common_1.prisma.reactionRoleGrant.update({
            where: { id: g.id },
            data: {
                status: owner?.state === "UNCERTAIN" ? "RETAINED" : "RELEASED",
                lastError: null,
            },
        });
    });
}
async function onReaction(reaction, user, removing = false) {
    if (user?.bot || !user?.id)
        return;
    const messageId = reaction.message?.id;
    const pub = await common_1.prisma.makerPublication.findUnique({
        where: { messageId },
    });
    if (!pub?.panelId)
        return;
    const guild = reaction.message?.guild ||
        (await reaction.client?.guilds?.fetch(pub.guildId).catch(() => null));
    if (!guild ||
        guild.id !== pub.guildId ||
        reaction.message?.channelId !== pub.channelId)
        return;
    const p = await panel(guild.id, pub.panelId);
    if (p.status !== "ACTIVE")
        return;
    const key = reaction.emoji?.id
        ? "c:" + reaction.emoji.id
        : "u:" +
            String(reaction.emoji?.name || "")
                .normalize("NFC")
                .replace(/\uFE0F/g, "");
    const b = await common_1.prisma.reactionRoleBinding.findFirst({
        where: {
            guildId: guild.id,
            panelId: p.id,
            active: true,
            published: true,
            emojiKey: key,
        },
    });
    if (!b)
        return;
    try {
        if (removing)
            await release(guild, b.id, user.id, !p.publishedRemoveOnUnreact);
        else
            await grant(guild, b.id, user.id);
    }
    catch (error) {
        await common_1.prisma.reactionRolePanel.update({
            where: { id: p.id },
            data: {
                lastError: error instanceof document_1.MakerError
                    ? error.message
                    : "Falha ao processar uma reação. Use Conferir funcionamento.",
            },
        });
    }
}
async function pause(guildId, id, paused) {
    const p = await panel(guildId, id);
    (0, common_1.assert)(["ACTIVE", "PAUSED"].includes(p.status), "Conclua a publicação antes de pausar ou retomar.");
    return common_1.prisma.reactionRolePanel.update({
        where: { id },
        data: { status: paused ? "PAUSED" : "ACTIVE", revision: { increment: 1 } },
    });
}
async function disable(guild, bindingId, keep) {
    const b = await common_1.prisma.reactionRoleBinding.findFirst({
        where: { id: bindingId, guildId: guild.id },
    });
    (0, common_1.assert)(b, "Associação indisponível.");
    await common_1.prisma.reactionRoleBinding.update({
        where: { id: b.id },
        data: { active: false, retirement: keep ? "KEEP" : "REVOKE" },
    });
    await common_1.prisma.reactionRolePanel.update({
        where: { id: b.panelId },
        data: {
            revision: { increment: 1 },
            lastError: "Uma associação foi desativada. Atualize a mensagem para ajustar a legenda.",
        },
    });
    if (keep) {
        const users = await common_1.prisma.reactionRoleGrant.findMany({
            where: { guildId: guild.id, bindingId, active: true },
        });
        // No Discord mutation: retaining all tracked grants can be done in SQL.
        for (const g of users)
            await (0, common_1.exclusive)("reaction-role:" + guild.id + ":" + g.userId + ":" + g.roleId, async () => {
                await common_1.prisma.reactionRoleGrant.update({
                    where: { id: g.id },
                    data: { active: false, status: "RETAINED" },
                });
                const owner = await common_1.prisma.reactionRoleOwnership.findUnique({
                    where: ownershipWhere(guild.id, g.userId, g.roleId),
                });
                if (owner)
                    await common_1.prisma.reactionRoleOwnership.update({
                        where: { id: owner.id },
                        data: { state: "PREEXISTING" },
                    });
            });
    }
    return b;
}
async function revokeBatch(guild, bindingId) {
    const b = await common_1.prisma.reactionRoleBinding.findFirst({
        where: {
            id: bindingId,
            guildId: guild.id,
            active: false,
            retirement: "REVOKE",
        },
    });
    (0, common_1.assert)(b, "A remoção não foi autorizada para esta associação.");
    const list = await common_1.prisma.reactionRoleGrant.findMany({
        where: {
            guildId: guild.id,
            bindingId,
            OR: [{ active: true }, { status: "REVOKE_PENDING" }],
        },
        take: 25,
        orderBy: { createdAt: "asc" },
    });
    let failed = 0;
    for (const g of list)
        try {
            await release(guild, b.id, g.userId);
        }
        catch {
            failed++;
        }
    return {
        processed: list.length,
        failed,
        remaining: await common_1.prisma.reactionRoleGrant.count({
            where: {
                guildId: guild.id,
                bindingId,
                OR: [{ active: true }, { status: "REVOKE_PENDING" }],
            },
        }),
    };
}
async function inspect(guild, id) {
    const p = await panel(guild.id, id), list = await bindings(guild.id, id, true);
    const problems = [];
    if (!p.publicationId)
        problems.push("O painel ainda não foi publicado.");
    else {
        const pub = await (0, service_1.publication)(guild.id, p.publicationId);
        try {
            const message = await (0, service_1.fetchMessage)(guild, pub);
            if (list.some((b) => !message.reactions.cache.some((r) => (r.emoji.id
                ? "c:" + r.emoji.id
                : "u:" +
                    String(r.emoji.name)
                        .normalize("NFC")
                        .replace(/\uFE0F/g, "")) === b.emojiKey))) {
                problems.push("Faltam reações configuradas na mensagem. Use Publicar / atualizar para repô-las antes de sincronizar.");
            }
        }
        catch (e) {
            problems.push(e.message);
        }
    }
    for (const b of list)
        try {
            await safeRole(guild, b.roleId);
        }
        catch {
            problems.push("Cargo indisponível: <@&" + b.roleId + ">.");
        }
    return { p, list, problems };
}
async function planSync(guild, id) {
    const { p, list, problems } = await inspect(guild, id);
    (0, common_1.assert)(!problems.length && p.status === "ACTIVE", problems.join("\n") || "Retome o painel antes de sincronizar.");
    const pub = await (0, service_1.publication)(guild.id, p.publicationId), message = await (0, service_1.fetchMessage)(guild, pub), items = [];
    const all = await message.reactions.cache;
    for (const b of list) {
        const r = all.find((v) => (v.emoji.id
            ? "c:" + v.emoji.id
            : "u:" +
                String(v.emoji.name)
                    .normalize("NFC")
                    .replace(/\uFE0F/g, "")) === b.emojiKey);
        const reacted = new Set();
        let after;
        if (r)
            for (let n = 0; n < 100; n++) {
                const batch = await r.users.fetch({
                    limit: 100,
                    ...(after ? { after } : {}),
                });
                for (const u of batch.values())
                    if (!u.bot)
                        reacted.add(u.id);
                if (batch.size < 100)
                    break;
                after = batch.last().id;
                (0, common_1.assert)(n < 99, "O painel excede o limite desta revisão. Nenhum cargo foi alterado.");
            }
        const grants = await common_1.prisma.reactionRoleGrant.findMany({
            where: {
                guildId: guild.id,
                bindingId: b.id,
                OR: [{ active: true }, { status: "REVOKE_PENDING" }],
            },
        });
        const byUser = new Map(grants.map((g) => [g.userId, g]));
        for (const userId of reacted) {
            const g = byUser.get(userId);
            // Validate current membership/roles in the processing batch rather than querying the entire guild here.
            items.push({ type: "ADD", bindingId: b.id, userId });
        }
        for (const g of grants)
            if (!reacted.has(g.userId))
                items.push({
                    type: p.publishedRemoveOnUnreact ? "REMOVE" : "KEEP",
                    bindingId: b.id,
                    userId: g.userId,
                });
        (0, common_1.assert)(items.length <= 2000, "A revisão ultrapassa 2.000 participações. Nenhum cargo foi alterado. Divida os interesses em mais painéis.");
    }
    return { panelId: p.id, revision: p.revision, items, errors: [] };
}
async function syncItem(guild, id, item) {
    const p = await panel(guild.id, id);
    (0, common_1.assert)(p.status === "ACTIVE", "O painel foi pausado. Gere outra revisão depois de retomá-lo.");
    const b = await common_1.prisma.reactionRoleBinding.findFirst({
        where: {
            id: item.bindingId,
            guildId: guild.id,
            panelId: p.id,
            active: true,
            published: true,
        },
    });
    if (!b)
        return;
    const pub = await (0, service_1.publication)(guild.id, p.publicationId), message = await (0, service_1.fetchMessage)(guild, pub);
    const r = message.reactions.cache.find((r) => (r.emoji.id
        ? "c:" + r.emoji.id
        : "u:" +
            String(r.emoji.name)
                .normalize("NFC")
                .replace(/\uFE0F/g, "")) === b.emojiKey);
    const batch = r
        ? await r.users.fetch({
            limit: 1,
            after: (BigInt(item.userId) - 1n).toString(),
        })
        : null;
    const present = batch?.has(item.userId) || false;
    if (item.type === "ADD" && present)
        await grant(guild, b.id, item.userId);
    if (item.type === "REMOVE" && !present)
        await release(guild, b.id, item.userId);
    if (item.type === "KEEP" && !present)
        await release(guild, b.id, item.userId, true);
}
async function messageDeleted(message) {
    const p = await common_1.prisma.makerPublication.findUnique({
        where: { messageId: message.id },
    });
    if (!p || (message.guildId && p.guildId !== message.guildId))
        return;
    await common_1.prisma.makerPublication.update({
        where: { id: p.id },
        data: {
            status: "MISSING",
            lastError: "A mensagem foi apagada. Nenhuma cópia foi criada.",
        },
    });
    if (p.panelId)
        await common_1.prisma.reactionRolePanel.update({
            where: { id: p.panelId },
            data: {
                status: "PAUSED",
                lastError: "A mensagem foi apagada. Os cargos existentes foram preservados.",
            },
        });
}
async function reactionsCleared(message) {
    const p = await common_1.prisma.makerPublication.findUnique({
        where: { messageId: message.id },
    });
    if (p?.panelId)
        await common_1.prisma.reactionRolePanel.update({
            where: { id: p.panelId },
            data: {
                status: "PAUSED",
                lastError: "Reações removidas da mensagem. Use Publicar / atualizar para repô-las; depois revise as participações.",
            },
        });
}
