"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.clean = exports.deferPanel = exports.select = exports.button = exports.row = exports.prisma = exports.uid = exports.assert = exports.MakerError = exports.D = void 0;
exports.exclusive = exclusive;
exports.v2 = v2;
exports.show = show;
exports.authorized = authorized;
exports.guard = guard;
exports.form = form;
exports.session = session;
exports.action = action;
exports.getAction = getAction;
const D = __importStar(require("discord.js"));
exports.D = D;
const prisma_1 = require("../database/prisma");
const permissions_1 = require("../utils/permissions");
const panelInteraction_1 = require("../utils/panelInteraction");
Object.defineProperty(exports, "deferPanel", { enumerable: true, get: function () { return panelInteraction_1.deferPanel; } });
const componentMessages_1 = require("../utils/componentMessages");
const document_1 = require("./document");
Object.defineProperty(exports, "MakerError", { enumerable: true, get: function () { return document_1.MakerError; } });
Object.defineProperty(exports, "assert", { enumerable: true, get: function () { return document_1.assert; } });
Object.defineProperty(exports, "uid", { enumerable: true, get: function () { return document_1.uid; } });
exports.prisma = prisma_1.prisma;
const queue = new Map();
async function exclusive(key, fn) {
    const previous = queue.get(key) || Promise.resolve(), work = previous.catch(() => null).then(fn);
    queue.set(key, work);
    try {
        return await work;
    }
    finally {
        if (queue.get(key) === work)
            queue.delete(key);
    }
}
const row = (...c) => new D.ActionRowBuilder().addComponents(c);
exports.row = row;
const button = (id, label, style = D.ButtonStyle.Secondary, disabled = false) => new D.ButtonBuilder()
    .setCustomId("maker:" + id)
    .setLabel(label)
    .setStyle(style)
    .setDisabled(disabled);
exports.button = button;
const select = (id, placeholder, options) => (0, exports.row)(new D.StringSelectMenuBuilder()
    .setCustomId("maker-select:" + id)
    .setPlaceholder(placeholder)
    .addOptions(options));
exports.select = select;
function v2(p) {
    return {
        ...(0, componentMessages_1.asComponentsV2)(p),
        content: null,
        embeds: [],
        attachments: [],
        allowedMentions: { parse: [] },
    };
}
async function show(i, p) {
    return (0, panelInteraction_1.refreshPanel)(i, v2(p));
}
async function authorized(i) {
    (0, document_1.assert)(i.guild && i.message?.id, "Abra este painel no servidor com /adm.");
    const member = await i.guild.members.fetch(i.user.id);
    (0, document_1.assert)(await (0, permissions_1.isBotAdmin)(member), "Você não possui acesso para configurar este servidor.");
}
async function guard(i, fn) {
    try {
        await authorized(i);
        return await fn();
    }
    catch (error) {
        if (!(error instanceof document_1.MakerError))
            console.error("[message-maker]", error?.code || error?.name || "falha");
        const p = {
            content: error instanceof document_1.MakerError
                ? error.message
                : "Não foi possível concluir. O rascunho permanece salvo; confira o painel antes de repetir.",
            flags: D.MessageFlags.Ephemeral,
        };
        if (i.deferred || i.replied)
            return i.followUp(p).catch(() => null);
        return i.reply(p).catch(() => null);
    }
}
const clean = (value, n = 100) => String(value || "")
    .replace(/[\r\n]/g, " ")
    .slice(0, n);
exports.clean = clean;
function form(id, title, fields) {
    return new D.ModalBuilder()
        .setCustomId("maker-form:" + id)
        .setTitle(title.slice(0, 45))
        .addComponents(...fields.map((f) => {
        const input = new D.TextInputBuilder()
            .setCustomId(f.id)
            .setLabel(f.label)
            .setStyle(f.paragraph ? D.TextInputStyle.Paragraph : D.TextInputStyle.Short)
            .setRequired(f.required !== false)
            .setMaxLength(f.max || 1000);
        if (f.value)
            input.setValue(f.value.slice(0, f.max || 1000));
        return (0, exports.row)(input);
    }));
}
async function session(i, id, revision) {
    const s = await exports.prisma.makerSession.findUnique({ where: { id } });
    (0, document_1.assert)(s &&
        s.guildId === i.guild.id &&
        s.actorId === i.user.id &&
        s.sourceMessageId === i.message.id &&
        s.expiresAt > new Date(), "Esta edição expirou ou pertence a outro painel. Abra novamente em Mensagens salvas ou Mensagens enviadas.");
    if (revision !== undefined)
        (0, document_1.assert)(s.revision === Number(revision), "O rascunho mudou depois que você abriu esta opção. Atualize o editor e tente novamente.");
    return s;
}
async function action(i, kind, targetId, data) {
    return exports.prisma.makerAction.create({
        data: {
            id: (0, document_1.uid)(),
            guildId: i.guild.id,
            actorId: i.user.id,
            sourceMessageId: i.message.id,
            kind,
            targetId,
            payloadJson: JSON.stringify(data),
            expiresAt: new Date(Date.now() + 20 * 60000),
        },
    });
}
async function getAction(i, id, consume = false) {
    const a = await exports.prisma.makerAction.findUnique({ where: { id } });
    (0, document_1.assert)(a &&
        a.guildId === i.guild.id &&
        a.actorId === i.user.id &&
        a.sourceMessageId === i.message.id &&
        a.expiresAt > new Date(), "Esta confirmação expirou. Abra uma nova revisão.");
    if (consume) {
        const r = await exports.prisma.makerAction.updateMany({
            where: { id, usedAt: null, status: "READY" },
            data: { usedAt: new Date(), status: "RUNNING" },
        });
        (0, document_1.assert)(r.count === 1, "Esta confirmação já foi utilizada. Confira o resultado antes de repetir.");
    }
    return a;
}
