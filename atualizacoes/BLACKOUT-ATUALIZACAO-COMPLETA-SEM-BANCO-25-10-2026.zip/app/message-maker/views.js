"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.label = exports.typeName = void 0;
exports.header = header;
exports.home = home;
exports.templates = templates;
exports.editor = editor;
exports.addTypes = addTypes;
exports.organize = organize;
exports.buttons = buttons;
exports.publications = publications;
exports.stateLabel = stateLabel;
exports.publicationView = publicationView;
exports.destination = destination;
exports.confirmation = confirmation;
exports.roleHome = roleHome;
exports.roleDetail = roleDetail;
exports.roleBindings = roleBindings;
exports.roleInspect = roleInspect;
exports.syncProgress = syncProgress;
const common_1 = require("./common");
const document_1 = require("./document");
const admEmojis_1 = require("../utils/admEmojis");
const S = __importStar(require("./service"));
const R = __importStar(require("./roles"));
const TYPES = {
    heading: "Título",
    text: "Texto",
    section: "Texto com miniatura",
    gallery: "Galeria de imagens",
    separator: "Separador",
    buttons: "Botões de links e canais",
};
const typeName = (b) => TYPES[b.type];
exports.typeName = typeName;
const label = (b, n) => n +
    1 +
    ". " +
    TYPES[b.type] +
    (b.text ? " · " + (0, common_1.clean)(b.text.replace(/\*/g, ""), 45) : "");
exports.label = label;
function header(guild, title, text, area = "sistema") {
    const c = new common_1.D.ContainerBuilder().setAccentColor(0xd71935), content = "## " + title + "\n" + text, image = (0, admEmojis_1.adminEmojiImage)(guild, area);
    if (image)
        c.addSectionComponents(new common_1.D.SectionBuilder()
            .addTextDisplayComponents(new common_1.D.TextDisplayBuilder().setContent(content))
            .setThumbnailAccessory(new common_1.D.ThumbnailBuilder().setURL(image)));
    else
        c.addTextDisplayComponents(new common_1.D.TextDisplayBuilder().setContent(content));
    return c;
}
function payload(components) {
    if ((0, document_1.countComponents)(components) > 40 || (0, document_1.textLength)(components) > 4000)
        throw new Error("Maker view exceeds native component budget");
    return {
        flags: common_1.D.MessageFlags.IsComponentsV2,
        components,
        allowedMentions: { parse: [] },
    };
}
function nav(guild, id, placeholder, options, area = "sistema") {
    const icon = (0, admEmojis_1.admEmoji)(guild, area);
    return (0, common_1.select)(id, placeholder, options.map((o) => ({ ...o, ...(icon ? { emoji: { id: icon } } : {}) })));
}
async function home(guild) {
    await S.importLegacy(guild.id);
    const [models, sent] = await Promise.all([
        common_1.prisma.makerTemplate.count({
            where: { guildId: guild.id, deletedAt: null },
        }),
        common_1.prisma.makerPublication.count({
            where: { guildId: guild.id, panelId: null },
        }),
    ]);
    return payload([
        header(guild, "Mensagens Personalizadas / Embeds", "Crie mensagens V2 com prévia durante a edição. Cada envio é gerenciado separadamente.\n\nModelos salvos: **" +
            models +
            "** · Publicações registradas: **" +
            sent +
            "**"),
        nav(guild, "home", "O que você quer fazer?", [
            {
                label: "Criar mensagem",
                value: "create",
                description: "Começar um rascunho V2",
            },
            {
                label: "Modelos salvos",
                value: "templates",
                description: "Editar, duplicar e reutilizar",
            },
            {
                label: "Mensagens enviadas",
                value: "publications",
                description: "Consultar e atualizar cada envio",
            },
        ]),
        (0, common_1.row)((0, common_1.button)("area:sistema", "Voltar a Personalização do bot")),
    ]);
}
async function templates(guild, page = 0) {
    await S.importLegacy(guild.id);
    const total = await common_1.prisma.makerTemplate.count({
        where: { guildId: guild.id, deletedAt: null },
    });
    page = Math.max(0, Math.min(Number(page) || 0, Math.max(0, Math.ceil(total / 10) - 1)));
    const list = await common_1.prisma.makerTemplate.findMany({
        where: { guildId: guild.id, deletedAt: null },
        orderBy: { updatedAt: "desc" },
        skip: page * 10,
        take: 10,
    });
    const components = [
        header(guild, "Modelos salvos", list.length
            ? list
                .map((t, n) => "**" +
                (n + 1) +
                ". " +
                (0, common_1.clean)(t.name, 80) +
                "**" +
                (t.legacyId ? " · Importado" : ""))
                .join("\n") +
                "\n\nPágina " +
                (page + 1) +
                " · " +
                total +
                " modelos"
            : "Você ainda não tem modelos. Crie uma mensagem para começar."),
    ];
    if (list.length)
        components.push((0, common_1.select)("template", "Escolha um modelo para editar", list.map((t) => ({
            value: t.id,
            label: (0, common_1.clean)(t.name),
            description: t.legacyId
                ? "Prévia de conversão para V2"
                : "Abrir rascunho de edição",
        }))));
    components.push((0, common_1.row)((0, common_1.button)("templates:" + (page - 1), "Anterior", 2, page === 0), (0, common_1.button)("templates:" + (page + 1), "Próxima", 2, (page + 1) * 10 >= total), (0, common_1.button)("create", "Criar mensagem", 1)), (0, common_1.row)((0, common_1.button)("home", "Voltar")));
    return payload(components);
}
async function editor(guild, s, requestedPage = 0, pure = false, notice = "") {
    const doc = (0, document_1.parse)(s.documentJson);
    const panel = s.panelId ? await R.panel(guild.id, s.panelId) : null;
    const previewDocument = panel
        ? R.withLegend(doc, await R.bindings(guild.id, panel.id), panel.removeOnUnreact)
        : doc;
    const chunks = (0, document_1.pages)(previewDocument), page = Math.max(0, Math.min(Number(requestedPage) || 0, chunks.length - 1));
    const context = "**" +
        (s.panelId
            ? "Painel de cargos"
            : s.publicationId
                ? "Edição deste envio"
                : "Modelo") +
        " · " +
        (0, common_1.clean)(s.name, 80) +
        "**\n" +
        (notice ||
            (s.publicationId
                ? "Salvar o rascunho não altera a mensagem publicada. A atualização será confirmada separadamente."
                : "As alterações salvas aparecem abaixo. Publicar é uma ação separada.")) +
        (chunks.length > 1
            ? "\nPrévia · página " +
                (page + 1) +
                "/" +
                chunks.length +
                ". A publicação inclui todos os blocos."
            : "");
    const components = [
        new common_1.D.TextDisplayBuilder().setContent(context),
        ...(0, document_1.render)(chunks[page], true).components,
    ], id = s.id + ":" + s.revision;
    if (!pure) {
        components.push((0, common_1.select)("block:" + id, "Escolha um bloco para editar", doc.blocks
            .slice(0, 25)
            .map((b, n) => ({ value: b.id, label: (0, common_1.clean)((0, exports.label)(b, n)) }))));
        components.push((0, common_1.row)((0, common_1.button)("add:" + id, "Adicionar bloco"), (0, common_1.button)("organize:" + id, "Reorganizar / remover"), (0, common_1.button)("appearance:" + id, "Nome e cor"), (0, common_1.button)("undo:" + id, "Desfazer", 2, !s.undoJson)));
        components.push((0, common_1.row)((0, common_1.button)("save:" + id, s.panelId
            ? "Salvar painel"
            : s.publicationId
                ? "Salvar como modelo"
                : "Salvar modelo"), (0, common_1.button)("publish:" + id, s.panelId
            ? "Configurar publicação"
            : s.publicationId
                ? "Atualizar este envio"
                : "Publicar", 1), (0, common_1.button)("preview:" + id + ":" + page, "Ver prévia")));
        if (!s.panelId)
            components.push((0, common_1.row)((0, common_1.button)("more:" + id, "Mais opções"), (0, common_1.button)("copy-role:" + id, "Usar em painel de cargos")));
        else
            components.push((0, common_1.row)((0, common_1.button)("r-detail:" + s.panelId, "Voltar ao painel de cargos")));
    }
    else
        components.push((0, common_1.row)((0, common_1.button)("edit:" + s.id + ":" + page, "Voltar ao editor")));
    if (chunks.length > 1)
        components.push((0, common_1.row)((0, common_1.button)((pure ? "preview:" + id : "edit:" + s.id) + ":" + (page - 1), "Anterior", 2, page === 0), (0, common_1.button)((pure ? "preview:" + id : "edit:" + s.id) + ":" + (page + 1), "Próxima", 2, page === chunks.length - 1)));
    return payload(components);
}
async function addTypes(guild, s) {
    return payload([
        header(guild, "Adicionar bloco", "Escolha o conteúdo. O bloco será inserido ao final; depois você pode reorganizar."),
        (0, common_1.select)("add:" + s.id + ":" + s.revision, "Tipo de bloco", Object.entries(TYPES).map(([value, label]) => ({ value, label }))),
        (0, common_1.row)((0, common_1.button)("edit:" + s.id, "Voltar ao editor")),
    ]);
}
async function organize(guild, s, selected) {
    const doc = (0, document_1.parse)(s.documentJson), b = doc.blocks.find((v) => v.id === selected) || doc.blocks[0], n = doc.blocks.indexOf(b), id = s.id + ":" + s.revision + ":" + b.id;
    return payload([
        header(guild, "Organizar blocos", doc.blocks
            .map((v, i) => (v.id === b.id ? "**" : "") +
            (0, exports.label)(v, i) +
            (v.id === b.id ? "**" : ""))
            .join("\n")),
        (0, common_1.select)("organize:" + s.id + ":" + s.revision, "Escolha o bloco", doc.blocks
            .slice(0, 25)
            .map((v, i) => ({ value: v.id, label: (0, common_1.clean)((0, exports.label)(v, i)) }))),
        (0, common_1.row)((0, common_1.button)("up:" + id, "Subir", 2, n === 0), (0, common_1.button)("down:" + id, "Descer", 2, n === doc.blocks.length - 1), (0, common_1.button)("duplicate:" + id, "Duplicar"), (0, common_1.button)("remove:" + id, "Remover", 4, doc.blocks.length === 1)),
        (0, common_1.row)((0, common_1.button)("edit:" + s.id, "Voltar ao editor")),
    ]);
}
async function buttons(guild, s, blockId, selected) {
    const b = (0, document_1.parse)(s.documentJson).blocks.find((v) => v.id === blockId), values = b?.buttons || [], chosen = values.find((v) => v.id === selected), id = s.id + ":" + s.revision + ":" + blockId;
    const components = [
        header(guild, "Botões da mensagem", values
            .map((v, n) => "**" + (n + 1) + ". " + (0, common_1.clean)(v.label, 80) + "**\n" + v.url)
            .join("\n\n") || "Adicione links ou atalhos para canais."),
    ];
    if (values.length)
        components.push((0, common_1.select)("button:" + id, "Escolha um botão", values.map((v) => ({ value: v.id, label: (0, common_1.clean)(v.label) }))));
    components.push((0, common_1.row)((0, common_1.button)("link:" + id, "Adicionar link", 2, values.length >= 5), (0, common_1.button)("channel-button:" + id, "Adicionar canal", 2, values.length >= 5)));
    if (chosen) {
        const pos = values.indexOf(chosen), full = id + ":" + chosen.id;
        components.push((0, common_1.row)((0, common_1.button)("button-edit:" + full, "Editar"), (0, common_1.button)("button-up:" + full, "Mover antes", 2, pos === 0), (0, common_1.button)("button-down:" + full, "Mover depois", 2, pos === values.length - 1), (0, common_1.button)("button-remove:" + full, "Remover", 4)));
    }
    components.push((0, common_1.row)((0, common_1.button)("edit:" + s.id, "Voltar ao editor")));
    return payload(components);
}
async function publications(guild, page = 0) {
    await S.importLegacy(guild.id);
    const where = { guildId: guild.id, panelId: null }, total = await common_1.prisma.makerPublication.count({ where });
    page = Math.max(0, Math.min(Number(page) || 0, Math.max(0, Math.ceil(total / 10) - 1)));
    const list = await common_1.prisma.makerPublication.findMany({
        where,
        orderBy: { updatedAt: "desc" },
        skip: page * 10,
        take: 10,
    });
    const components = [
        header(guild, "Mensagens enviadas", list.length
            ? list
                .map((p, n) => "**" +
                (n + 1) +
                ". " +
                (0, common_1.clean)(p.name, 80) +
                "** · <#" +
                p.channelId +
                ">\n" +
                stateLabel(p.status) +
                " · <t:" +
                Math.floor(p.createdAt.getTime() / 1000) +
                ":d>")
                .join("\n\n") +
                "\n\nPágina " +
                (page + 1)
            : "Nenhum envio registrado por este editor. Publicações antigas só aparecem quando seu ID já estava salvo."),
    ];
    if (list.length)
        components.push((0, common_1.select)("publication", "Escolha uma publicação", list.map((p) => ({
            value: p.id,
            label: (0, common_1.clean)(p.name),
            description: stateLabel(p.status),
        }))));
    components.push((0, common_1.row)((0, common_1.button)("publications:" + (page - 1), "Anterior", 2, page === 0), (0, common_1.button)("publications:" + (page + 1), "Próxima", 2, (page + 1) * 10 >= total)), (0, common_1.row)((0, common_1.button)("home", "Voltar")));
    return payload(components);
}
function stateLabel(state) {
    return ({
        ACTIVE: "Publicada",
        LEGACY: "Publicação antiga · confira o original",
        SENDING: "Envio em preparação",
        UPDATING: "Atualização em preparação",
        UNCERTAIN: "Entrega não confirmada · confira o canal",
        UNAVAILABLE: "Acesso indisponível",
        MISSING: "Mensagem apagada",
        DELETED: "Mensagem excluída",
        DRAFT: "Rascunho",
        PAUSED: "Pausado",
        ACTIVATING: "Em preparação",
        ERROR: "Ativação pendente",
    }[state] || "Confira o estado");
}
async function publicationView(guild, id, page = 0) {
    const p = await S.publication(guild.id, id), chunks = (0, document_1.pages)(p.snapshotJson);
    page = Math.max(0, Math.min(Number(page) || 0, chunks.length - 1));
    const components = [
        new common_1.D.TextDisplayBuilder().setContent("**" +
            (0, common_1.clean)(p.name, 80) +
            "** · <#" +
            p.channelId +
            ">\n" +
            stateLabel(p.status) +
            (p.legacy
                ? "\nPrévia de conversão do modelo antigo; a mensagem original pode ter conteúdo diferente."
                : "\nPrévia do conteúdo registrado neste envio.") +
            (p.lastError ? "\n" + (0, common_1.clean)(p.lastError, 240) : "") +
            (chunks.length > 1
                ? "\nPágina " + (page + 1) + "/" + chunks.length
                : "")),
        ...(0, document_1.render)(chunks[page], true).components,
    ];
    const actions = [
        (0, common_1.button)(p.panelId ? "r-detail:" + p.panelId : "pub-edit:" + p.id, p.panelId ? "Gerenciar cargos" : "Editar este envio", 2, !p.messageId),
        (0, common_1.button)("pub-copy:" + p.id, "Publicar uma cópia"),
        (0, common_1.button)("pub-check:" + p.id, "Verificar acesso", 2, !p.messageId),
    ];
    if (!p.messageId)
        actions.push((0, common_1.button)("pub-register:" + p.id, "Registrar mensagem existente"));
    if (p.messageId)
        actions.push(new common_1.D.ButtonBuilder()
            .setStyle(common_1.D.ButtonStyle.Link)
            .setLabel("Ir para mensagem")
            .setURL("https://discord.com/channels/" +
            guild.id +
            "/" +
            p.channelId +
            "/" +
            p.messageId));
    components.push((0, common_1.row)(...actions));
    components.push((0, common_1.row)((0, common_1.button)("pub-delete:" + p.id, "Excluir publicação", 4, !p.messageId || !!p.panelId), (0, common_1.button)("publications:0", "Voltar aos envios")));
    if (chunks.length > 1)
        components.push((0, common_1.row)((0, common_1.button)("pub:" + p.id + ":" + (page - 1), "Anterior", 2, page === 0), (0, common_1.button)("pub:" + p.id + ":" + (page + 1), "Próxima", 2, page === chunks.length - 1)));
    return payload(components);
}
async function destination(guild, s) {
    const choose = new common_1.D.ChannelSelectMenuBuilder()
        .setCustomId("maker-select:destination:" + s.id + ":" + s.revision)
        .setPlaceholder("Canal de destino")
        .addChannelTypes(common_1.D.ChannelType.GuildText, common_1.D.ChannelType.GuildAnnouncement);
    if (s.destinationChannelId)
        choose.setDefaultChannels(s.destinationChannelId);
    return payload([
        header(guild, "Canal de publicação", "Escolha onde enviar. O rascunho continua salvo e nenhum envio é feito nesta escolha.\n\nCanal: " +
            (s.destinationChannelId
                ? "<#" + s.destinationChannelId + ">"
                : "Não definido")),
        (0, common_1.row)(choose),
        (0, common_1.row)((0, common_1.button)("review:" + s.id + ":" + s.revision, "Conferir publicação", 1, !s.destinationChannelId), (0, common_1.button)("edit:" + s.id, "Voltar ao editor")),
    ]);
}
async function confirmation(guild, a, page = 0) {
    const data = JSON.parse(a.payloadJson), components = [];
    if (a.kind === "PUBLISH") {
        const chunks = (0, document_1.pages)(data.documentJson);
        page = Math.max(0, Math.min(Number(page) || 0, chunks.length - 1));
        components.push(new common_1.D.TextDisplayBuilder().setContent("**Conferir " +
            (data.publicationId ? "atualização deste envio" : "nova publicação") +
            "**\nCanal: <#" +
            data.channelId +
            ">\n" +
            (data.publicationId
                ? "Somente esta mensagem será atualizada."
                : "Uma nova mensagem será criada. Os envios anteriores serão preservados.") +
            "\nPrévia " +
            (page + 1) +
            "/" +
            chunks.length), ...(0, document_1.render)(chunks[page], true).components);
        if (chunks.length > 1)
            components.push((0, common_1.row)((0, common_1.button)("confirm-view:" + a.id + ":" + (page - 1), "Anterior", 2, page === 0), (0, common_1.button)("confirm-view:" + a.id + ":" + (page + 1), "Próxima", 2, page === chunks.length - 1)));
    }
    else {
        const texts = {
            TEMPLATE_DELETE: [
                "Excluir modelo salvo?",
                "O modelo **" +
                    (0, common_1.clean)(data.name, 80) +
                    "** será retirado da lista. As publicações serão preservadas.",
            ],
            PUB_DELETE: [
                "Excluir esta publicação?",
                "Será apagada somente a mensagem **" +
                    (0, common_1.clean)(data.name, 80) +
                    "** em <#" +
                    data.channelId +
                    ">. O modelo e os outros envios serão preservados.",
            ],
            BINDING_KEEP: [
                "Desativar associação e preservar cargos?",
                "A reação deixará de conceder cargos. " +
                    data.count +
                    " concessões rastreadas serão preservadas.",
            ],
            BINDING_REVOKE: [
                "Desativar e revisar retirada dos cargos?",
                "A reação deixará de conceder cargos. Serão processadas até 25 concessões por etapa, respeitando cargos preexistentes e outras concessões. Vínculos atuais: " +
                    data.count +
                    ".",
            ],
            ROLE_PUBLISH: [
                "Publicar / atualizar painel de cargos?",
                "Canal: <#" +
                    data.channelId +
                    ">. A mensagem e as reações serão preparadas; os cargos existentes serão preservados.",
            ],
            SYNC: [
                "Conferir participações do painel",
                "Serão verificadas **" +
                    (data.items?.length || 0) +
                    "** participações em etapas de 25. Cada reação será conferida novamente antes de conceder ou retirar um cargo. Nada foi alterado nesta revisão.",
            ],
        };
        const info = texts[a.kind] || [
            "Conferir ação",
            "Revise antes de confirmar.",
        ];
        components.push(header(guild, info[0], info[1], a.kind.startsWith("BINDING") ||
            a.kind === "SYNC" ||
            a.kind === "ROLE_PUBLISH"
            ? "membros"
            : "sistema"));
    }
    components.push((0, common_1.row)((0, common_1.button)("confirm:" + a.id, "Confirmar", a.kind.endsWith("DELETE") || a.kind === "BINDING_REVOKE" ? 4 : 1), (0, common_1.button)(data.sessionId
        ? "edit:" + data.sessionId
        : data.panelId
            ? "r-detail:" + data.panelId
            : a.kind === "TEMPLATE_DELETE"
                ? "templates:0"
                : "publications:0", "Cancelar")));
    return payload(components);
}
async function roleHome(guild, page = 0) {
    const total = await common_1.prisma.reactionRolePanel.count({
        where: { guildId: guild.id },
    });
    page = Math.max(0, Math.min(Number(page) || 0, Math.max(0, Math.ceil(total / 10) - 1)));
    const list = await common_1.prisma.reactionRolePanel.findMany({
        where: { guildId: guild.id },
        orderBy: { updatedAt: "desc" },
        skip: page * 10,
        take: 10,
    });
    const components = [
        header(guild, "Cargos por reação", list.length
            ? list
                .map((p, n) => "**" +
                (n + 1) +
                ". " +
                (0, common_1.clean)(p.name, 80) +
                "**\n" +
                stateLabel(p.status) +
                (p.channelId
                    ? " · <#" + p.channelId + ">"
                    : " · Canal não definido"))
                .join("\n\n")
            : "Crie um painel para que os membros escolham jogos, interesses e notificações reagindo à mensagem.", "membros"),
    ];
    if (list.length)
        components.push(nav(guild, "r-panel", "Escolha um painel", list.map((p) => ({
            value: p.id,
            label: (0, common_1.clean)(p.name),
            description: stateLabel(p.status),
        })), "membros"));
    components.push((0, common_1.row)((0, common_1.button)("r-create", "Criar painel", 1), (0, common_1.button)("r-home:" + (page - 1), "Anterior", 2, page === 0), (0, common_1.button)("r-home:" + (page + 1), "Próxima", 2, (page + 1) * 10 >= total)), (0, common_1.row)((0, common_1.button)("automations", "Voltar a Cargos e automações")));
    return payload(components);
}
async function roleDetail(guild, id, notice = "") {
    const p = await R.panel(guild.id, id), list = await R.bindings(guild.id, id), pending = list.filter((b) => !b.published).length;
    const publication = p.publicationId
        ? await S.publication(guild.id, p.publicationId)
        : null;
    return payload([
        header(guild, p.name, "Estado: **" +
            stateLabel(p.status) +
            "**\nCanal: " +
            (p.channelId ? "<#" + p.channelId + ">" : "Não definido") +
            "\nAssociações ativas: " +
            list.length +
            (pending ? " · " + pending + " aguardando publicação" : "") +
            "\nAo retirar a reação: **" +
            (p.removeOnUnreact
                ? "remover a concessão deste painel"
                : "preservar o cargo") +
            "**\n\n" +
            (notice ||
                p.lastError ||
                "Editar e salvar não publica. As novas regras valem após Publicar / atualizar."), "membros"),
        nav(guild, "r-task:" + p.id, "Escolha o que configurar", [
            {
                label: "Mensagem e prévia",
                value: "message",
                description: "Editar o conteúdo com o editor V2",
            },
            {
                label: "Reações e cargos",
                value: "bindings",
                description: "Associar emojis e cargos permitidos",
            },
            {
                label: "Canal do painel",
                value: "channel",
                description: "Escolher onde publicar",
            },
            {
                label: "Ao retirar a reação",
                value: "rule",
                description: "Escolher se a concessão será removida",
            },
            {
                label: "Conferir funcionamento",
                value: "inspect",
                description: "Permissões, mensagem e sincronização",
            },
        ], "membros"),
        (0, common_1.row)((0, common_1.button)("r-publish:" + p.id + ":" + p.revision, "Publicar / atualizar", 1), (0, common_1.button)("r-toggle:" + p.id, p.status === "PAUSED" ? "Retomar painel" : "Pausar painel", 2, !["ACTIVE", "PAUSED"].includes(p.status))),
        (0, common_1.row)((0, common_1.button)("r-copy:" + p.id, "Duplicar painel"), (0, common_1.button)("r-home:0", "Voltar aos painéis")),
        ...(publication && !publication.messageId
            ? [
                (0, common_1.row)((0, common_1.button)("pub-register:" + publication.id, "Registrar mensagem existente")),
            ]
            : []),
    ]);
}
async function roleBindings(guild, id) {
    const p = await R.panel(guild.id, id), list = await R.bindings(guild.id, id);
    const components = [
        header(guild, "Reações e cargos · " + (0, common_1.clean)(p.name, 50), list.length
            ? list
                .map((b) => b.emojiDisplay +
                " → <@&" +
                b.roleId +
                "> · " +
                (b.published ? "Publicada" : "Rascunho"))
                .join("\n")
            : "Associe a primeira reação a um cargo. Cargos administrativos não podem ser oferecidos aqui.", "membros"),
    ];
    if (list.length)
        components.push((0, common_1.select)("r-binding:" + id, "Escolha uma associação para gerenciar", list.map((b, n) => ({
            value: b.id,
            label: (0, common_1.clean)(n +
                1 +
                ". " +
                b.emojiDisplay +
                " · " +
                (guild.roles.cache.get(b.roleId)?.name || "Cargo indisponível")),
        }))));
    components.push((0, common_1.row)((0, common_1.button)("r-add:" + id + ":" + p.revision, "Adicionar associação", 1, list.length >= 20), (0, common_1.button)("r-detail:" + id, "Voltar ao painel")));
    const pending = await common_1.prisma.reactionRoleBinding.findMany({
        where: {
            guildId: guild.id,
            panelId: id,
            active: false,
            retirement: "REVOKE",
        },
        take: 5,
    });
    for (const b of pending)
        if (await common_1.prisma.reactionRoleGrant.count({
            where: {
                guildId: guild.id,
                bindingId: b.id,
                OR: [{ active: true }, { status: "REVOKE_PENDING" }],
            },
        }))
            components.push((0, common_1.row)((0, common_1.button)("r-revoke-batch:" + b.id, "Continuar remoções · " + (0, common_1.clean)(b.emojiDisplay, 20))));
    return payload(components);
}
async function roleInspect(guild, id) {
    const { p, problems } = await R.inspect(guild, id), failed = await common_1.prisma.reactionRoleGrant.count({
        where: {
            guildId: guild.id,
            panelId: id,
            status: { in: ["FAILED", "REVOKE_PENDING"] },
        },
    });
    return payload([
        header(guild, "Conferir funcionamento", (problems.length
            ? problems.join("\n")
            : "Mensagem acessível e cargos publicados disponíveis.") +
            "\nConcessões com falha ou retirada pendente: " +
            failed +
            "\n\nO Discord não reenvia todos os eventos ocorridos durante uma desconexão. Revisar participações compara as reações atuais com os registros antes de aplicar mudanças.", "membros"),
        (0, common_1.row)((0, common_1.button)("r-sync:" + id, "Revisar participações", 1, problems.length > 0 || p.status !== "ACTIVE"), (0, common_1.button)("r-detail:" + id, "Voltar ao painel")),
    ]);
}
async function syncProgress(guild, a) {
    const data = JSON.parse(a.payloadJson), done = a.cursor >= data.items.length;
    return payload([
        header(guild, "Sincronização do painel", "Participações processadas: **" +
            a.cursor +
            "/" +
            data.items.length +
            "**\nFalhas registradas: **" +
            (data.errors?.length || 0) +
            "**\n" +
            (done
                ? "Revisão concluída. As mudanças foram limitadas às reações confirmadas."
                : a.status === "RUNNING"
                    ? "Esta etapa não teve conclusão confirmada. Gere uma nova revisão para conferir o estado atual."
                    : "Continue para processar as próximas 25 participações."), "membros"),
        (0, common_1.row)((0, common_1.button)("sync-next:" + a.id, "Continuar", 1, done || a.status === "RUNNING"), (0, common_1.button)("r-inspect:" + data.panelId, "Voltar ao diagnóstico")),
    ]);
}
