"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.importLegacy = importLegacy;
exports.start = start;
exports.change = change;
exports.save = save;
exports.publication = publication;
exports.channel = channel;
exports.fetchMessage = fetchMessage;
exports.publishSession = publishSession;
exports.verifyPublication = verifyPublication;
const common_1 = require("./common");
const document_1 = require("./document");
const configurationChecks_1 = require("../utils/configurationChecks");
async function importLegacy(guildId) {
    return (0, common_1.exclusive)("maker-import:" + guildId, async () => {
        const records = await common_1.prisma.customEmbed.findMany({
            where: { guildId },
            include: { buttons: { orderBy: { position: "asc" } } },
        });
        for (const r of records) {
            const documentJson = JSON.stringify((0, document_1.legacy)(r, guildId));
            const t = await common_1.prisma.makerTemplate.upsert({
                where: { legacyId: r.id },
                create: {
                    id: (0, common_1.uid)(),
                    guildId,
                    legacyId: r.id,
                    name: r.name,
                    documentJson,
                    createdById: r.createdById,
                },
                update: {},
            });
            if (r.publishedMessageId && r.publishedChannelId)
                await common_1.prisma.makerPublication.upsert({
                    where: { messageId: r.publishedMessageId },
                    create: {
                        id: (0, common_1.uid)(),
                        guildId,
                        templateId: t.id,
                        channelId: r.publishedChannelId,
                        messageId: r.publishedMessageId,
                        name: r.name,
                        snapshotJson: documentJson,
                        status: "LEGACY",
                        legacy: true,
                        createdById: r.createdById,
                        lastError: "Prévia de conversão do modelo antigo. Confira a mensagem original antes de atualizar.",
                    },
                    update: {},
                });
        }
    });
}
async function start(i, options = {}) {
    let doc = options.document || (0, document_1.blank)(), name = options.name || "Nova mensagem", t = null, p = null, panel = null;
    if (options.templateId) {
        t = await common_1.prisma.makerTemplate.findFirst({
            where: { id: options.templateId, guildId: i.guild.id, deletedAt: null },
        });
        (0, common_1.assert)(t, "Este modelo não está disponível neste servidor.");
        doc = (0, document_1.parse)(t.documentJson);
        name = t.name;
    }
    if (options.publicationId) {
        p = await publication(i.guild.id, options.publicationId);
        (0, common_1.assert)(p.messageId, "O envio ainda não possui mensagem confirmada. Confira o canal antes de criar outro.");
        doc = (0, document_1.parse)(p.snapshotJson);
        name = p.name;
        if (p.panelId)
            options.panelId = p.panelId;
    }
    if (options.panelId) {
        panel = await common_1.prisma.reactionRolePanel.findFirst({
            where: { id: options.panelId, guildId: i.guild.id },
        });
        (0, common_1.assert)(panel, "O painel de cargos não pertence a este servidor.");
        doc = (0, document_1.parse)(panel.documentJson);
        name = panel.name;
    }
    if (!options.fresh && (t || p || panel)) {
        const existing = await common_1.prisma.makerSession.findFirst({
            where: {
                guildId: i.guild.id,
                actorId: i.user.id,
                sourceMessageId: i.message.id,
                expiresAt: { gt: new Date() },
                ...(panel
                    ? { panelId: panel.id, panelRevision: panel.revision }
                    : p
                        ? {
                            publicationId: p.id,
                            publicationRevision: p.revision,
                            panelId: null,
                        }
                        : {
                            templateId: t.id,
                            templateRevision: t.revision,
                            publicationId: null,
                            panelId: null,
                        }),
            },
            orderBy: { updatedAt: "desc" },
        });
        if (existing)
            return existing;
    }
    await common_1.prisma.makerSession.deleteMany({
        where: {
            guildId: i.guild.id,
            actorId: i.user.id,
            expiresAt: { lt: new Date() },
        },
    });
    return common_1.prisma.makerSession.create({
        data: {
            id: (0, common_1.uid)(),
            guildId: i.guild.id,
            actorId: i.user.id,
            sourceMessageId: i.message.id,
            name: name.slice(0, 80),
            documentJson: JSON.stringify(doc),
            templateId: t?.id || null,
            templateRevision: t?.revision ?? null,
            publicationId: panel ? null : p?.id || null,
            publicationRevision: panel ? null : (p?.revision ?? null),
            panelId: panel?.id || null,
            panelRevision: panel?.revision ?? null,
            destinationChannelId: panel?.channelId || p?.channelId || null,
            expiresAt: new Date(Date.now() + 86400000),
        },
    });
}
async function change(i, id, revision, fn) {
    return (0, common_1.exclusive)("maker-session:" + id, async () => {
        const s = await (0, common_1.session)(i, id, revision), doc = (0, document_1.parse)(s.documentJson), old = JSON.stringify({ documentJson: s.documentJson, name: s.name });
        fn(doc, s);
        (0, document_1.parse)(doc);
        (0, common_1.assert)(doc.blocks.length <= 25, "Use até 25 blocos editáveis; remova um bloco antes de adicionar outro.");
        (0, common_1.assert)(s.name?.trim() && s.name.length <= 80, "O nome interno precisa ter de 1 a 80 caracteres.");
        const r = await common_1.prisma.makerSession.updateMany({
            where: { id, revision: s.revision },
            data: {
                documentJson: JSON.stringify(doc),
                name: s.name,
                undoJson: old,
                revision: { increment: 1 },
                expiresAt: new Date(Date.now() + 86400000),
            },
        });
        (0, common_1.assert)(r.count === 1, "O rascunho mudou. Abra novamente o editor.");
        return (0, common_1.session)(i, id);
    });
}
async function save(i, id, rev) {
    return (0, common_1.exclusive)("maker-session:" + id, async () => {
        const s = await (0, common_1.session)(i, id, rev);
        if (s.panelId) {
            const panel = await common_1.prisma.reactionRolePanel.findFirst({
                where: { id: s.panelId, guildId: i.guild.id },
            });
            (0, common_1.assert)(panel, "Painel indisponível.");
            const changed = await common_1.prisma.reactionRolePanel.updateMany({
                where: { id: panel.id, guildId: i.guild.id, revision: s.panelRevision },
                data: {
                    name: s.name,
                    documentJson: s.documentJson,
                    revision: { increment: 1 },
                },
            });
            (0, common_1.assert)(changed.count === 1, "O painel mudou em outra edição. Reabra a mensagem pelo painel para conferir.");
            await common_1.prisma.makerSession.update({
                where: { id },
                data: { panelRevision: s.panelRevision + 1 },
            });
            return (0, common_1.session)(i, id);
        }
        if (s.templateId && !s.publicationId) {
            const r = await common_1.prisma.makerTemplate.updateMany({
                where: {
                    id: s.templateId,
                    guildId: i.guild.id,
                    deletedAt: null,
                    revision: s.templateRevision,
                },
                data: {
                    name: s.name,
                    documentJson: s.documentJson,
                    revision: { increment: 1 },
                },
            });
            (0, common_1.assert)(r.count === 1, "O modelo foi alterado em outra edição. Salve uma cópia para preservar este rascunho.");
            await common_1.prisma.makerSession.update({
                where: { id },
                data: { templateRevision: s.templateRevision + 1 },
            });
        }
        else {
            const t = await common_1.prisma.makerTemplate.create({
                data: {
                    id: (0, common_1.uid)(),
                    guildId: i.guild.id,
                    name: s.name,
                    documentJson: s.documentJson,
                    createdById: i.user.id,
                },
            });
            if (!s.publicationId)
                await common_1.prisma.makerSession.update({
                    where: { id },
                    data: { templateId: t.id, templateRevision: t.revision },
                });
        }
        return (0, common_1.session)(i, id);
    });
}
async function publication(guildId, id) {
    const p = await common_1.prisma.makerPublication.findFirst({ where: { id, guildId } });
    (0, common_1.assert)(p, "Esta publicação não pertence a este servidor.");
    return p;
}
async function channel(guild, id, reactions = false) {
    const result = await (0, configurationChecks_1.writableChannel)(guild, id, false);
    (0, common_1.assert)(!result.issue, result.issue || "Canal indisponível.");
    const ch = result.channel, me = guild.members.me || (await guild.members.fetchMe());
    (0, common_1.assert)(ch.permissionsFor(me)?.has(common_1.D.PermissionFlagsBits.ReadMessageHistory), "O bot precisa da permissão Ler histórico de mensagens para gerenciar a publicação.");
    if (reactions)
        (0, common_1.assert)(ch
            .permissionsFor(me)
            ?.has([
            common_1.D.PermissionFlagsBits.AddReactions,
            common_1.D.PermissionFlagsBits.ManageRoles,
        ]), "O bot precisa de Adicionar reações e Gerenciar cargos para ativar este painel.");
    return ch;
}
async function fetchMessage(guild, p) {
    const ch = await channel(guild, p.channelId);
    (0, common_1.assert)(p.messageId, "A entrega não foi confirmada. Confira o canal antes de publicar novamente.");
    let message;
    try {
        message = await ch.messages.fetch(p.messageId);
    }
    catch (error) {
        if (error?.code === 10008) {
            await common_1.prisma.makerPublication.update({
                where: { id: p.id },
                data: { status: "MISSING", lastError: "Mensagem apagada." },
            });
            throw new document_1.MakerError("A mensagem foi apagada. Use Publicar uma cópia para criar outro envio.");
        }
        await common_1.prisma.makerPublication.update({
            where: { id: p.id },
            data: {
                status: "UNAVAILABLE",
                lastError: "Não foi possível acessar a mensagem. Confira as permissões.",
            },
        });
        throw new document_1.MakerError("Não foi possível acessar esta mensagem. Confira as permissões; nenhum envio foi recriado.");
    }
    (0, common_1.assert)(message &&
        message.author?.id === guild.client.user.id &&
        message.channelId === p.channelId, "A mensagem registrada não foi confirmada como uma publicação deste bot.");
    return message;
}
async function publishSession(i, s) {
    (0, common_1.assert)(!s.panelId, "Publique o painel pela área Cargos por reação.");
    const doc = (0, document_1.parse)(s.documentJson), payload = (0, document_1.render)(doc);
    (0, common_1.assert)(s.destinationChannelId, "Escolha o canal de destino antes de publicar.");
    return (0, common_1.exclusive)("maker-publish:" + (s.publicationId || s.id), async () => {
        let p;
        if (s.publicationId) {
            p = await publication(i.guild.id, s.publicationId);
            (0, common_1.assert)(p.revision === s.publicationRevision, "Esta publicação mudou em outra edição. Reabra o envio para conferir a versão atual.");
            (0, common_1.assert)(!p.panelId, "Use o gerenciamento próprio dos cargos por reação.");
            const message = await fetchMessage(i.guild, p);
            const claimed = await common_1.prisma.makerPublication.updateMany({
                where: { id: p.id, revision: p.revision },
                data: { status: "UPDATING", revision: { increment: 1 } },
            });
            (0, common_1.assert)(claimed.count === 1, "Outra atualização já está em andamento.");
            try {
                await message.edit({
                    ...payload,
                    content: null,
                    embeds: [],
                    attachments: [],
                });
                p = await common_1.prisma.makerPublication.update({
                    where: { id: p.id },
                    data: {
                        name: s.name,
                        snapshotJson: s.documentJson,
                        payloadHash: (0, document_1.hash)(doc),
                        status: "ACTIVE",
                        legacy: false,
                        lastError: null,
                    },
                });
            }
            catch {
                await common_1.prisma.makerPublication.update({
                    where: { id: p.id },
                    data: {
                        status: "UNCERTAIN",
                        lastError: "Atualização não confirmada. Confira a mensagem original antes de repetir.",
                    },
                });
                throw new document_1.MakerError("Não foi possível confirmar a atualização. Consulte a mensagem original; nenhum novo envio foi criado.");
            }
        }
        else {
            const ch = await channel(i.guild, s.destinationChannelId);
            p = await common_1.prisma.makerPublication.create({
                data: {
                    id: (0, common_1.uid)(),
                    guildId: i.guild.id,
                    templateId: s.templateId,
                    channelId: ch.id,
                    name: s.name,
                    snapshotJson: s.documentJson,
                    createdById: i.user.id,
                },
            });
            // Bind before the API request: a consumed review cannot silently resend after uncertainty.
            await common_1.prisma.makerSession.update({
                where: { id: s.id },
                data: { publicationId: p.id, publicationRevision: p.revision },
            });
            let message;
            try {
                message = await ch.send(payload);
                p = await common_1.prisma.makerPublication.update({
                    where: { id: p.id },
                    data: {
                        messageId: message.id,
                        status: "ACTIVE",
                        payloadHash: (0, document_1.hash)(doc),
                    },
                });
            }
            catch {
                await common_1.prisma.makerPublication
                    .update({
                    where: { id: p.id },
                    data: {
                        messageId: message?.id || null,
                        status: "UNCERTAIN",
                        lastError: "Envio não confirmado. Confira o canal antes de enviar outra mensagem.",
                    },
                })
                    .catch(() => null);
                throw new document_1.MakerError("Não foi possível confirmar o envio. Confira o canal e Mensagens enviadas antes de repetir.");
            }
        }
        await common_1.prisma.makerSession.update({
            where: { id: s.id },
            data: {
                publicationId: p.id,
                publicationRevision: p.revision,
                templateId: null,
                templateRevision: null,
            },
        });
        return p;
    });
}
async function verifyPublication(guild, id) {
    const p = await publication(guild.id, id);
    await fetchMessage(guild, p);
    if (!["LEGACY", "UNCERTAIN"].includes(p.status))
        await common_1.prisma.makerPublication.update({
            where: { id },
            data: { status: "ACTIVE", lastError: null },
        });
    return p;
}
