"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.automations = automations;
const common_1 = require("./common");
const views_1 = require("./views");
const admEmojis_1 = require("../utils/admEmojis");
async function automations(i) {
    return (0, common_1.guard)(i, async () => {
        await (0, common_1.deferPanel)(i);
        const icon = (0, admEmojis_1.admEmoji)(i.guild, "membros");
        return (0, common_1.show)(i, {
            flags: common_1.D.MessageFlags.IsComponentsV2,
            components: [
                (0, views_1.header)(i.guild, "Cargos e automações", "Defina quando e como os membros recebem cargos. Escolha uma função no menu abaixo.", "membros"),
                (0, common_1.row)(new common_1.D.StringSelectMenuBuilder()
                    .setCustomId("maker-select:automation")
                    .setPlaceholder("Escolha como atribuir os cargos")
                    .addOptions(...[
                    {
                        value: "arrival",
                        label: "Cargos ao entrar",
                        description: "Atribuição automática para novos membros",
                    },
                    {
                        value: "transfer",
                        label: "Transferência programada",
                        description: "Mudanças de cargos pelas regras do servidor",
                    },
                    {
                        value: "reactions",
                        label: "Cargos por reação",
                        description: "O membro escolhe seus cargos reagindo à mensagem",
                    },
                ].map((o) => ({
                    ...o,
                    ...(icon ? { emoji: { id: icon } } : {}),
                })))),
                (0, common_1.row)((0, common_1.button)("area:membros", "Voltar a Entrada e evolução")),
            ],
        });
    });
}
