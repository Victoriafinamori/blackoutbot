"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.openBlock = openBlock;
exports.reviewPublish = reviewPublish;
exports.buttonAction = buttonAction;
exports.selectAction = selectAction;
exports.modalAction = modalAction;
const common_1 = require("./common");
const document_1 = require("./document");
const S = __importStar(require("./service"));
const V = __importStar(require("./views"));
const R = __importStar(require("./roles"));
const textField = (text) => ({
    id: "text",
    label: "Conteúdo",
    value: text,
    max: 3500,
    paragraph: true,
});
async function openBlock(i, s, blockId) {
    const b = (0, document_1.parse)(s.documentJson).blocks.find((b) => b.id === blockId);
    (0, common_1.assert)(b, "O bloco não está disponível.");
    const id = "block:" + s.id + ":" + s.revision + ":" + b.id;
    if (b.type === "separator")
        return (0, common_1.show)(i, await V.organize(i.guild, s, b.id));
    if (b.type === "buttons")
        return (0, common_1.show)(i, await V.buttons(i.guild, s, b.id));
    if (b.type === "gallery")
        return i.showModal((0, common_1.form)(id, "Editar galeria", [
            {
                id: "images",
                label: "Links das imagens — um por linha",
                value: b.images.join("\n"),
                max: 3500,
                paragraph: true,
            },
        ]));
    if (b.type === "section")
        return i.showModal((0, common_1.form)(id, "Texto e miniatura", [
            textField(b.text),
            {
                id: "thumbnail",
                label: "Link da miniatura",
                value: b.thumbnail,
                max: 1000,
            },
        ]));
    return i.showModal((0, common_1.form)(id, b.type === "heading" ? "Editar título" : "Editar texto", [
        {
            ...textField(b.text),
            label: b.type === "heading"
                ? "Título"
                : "Texto — use **texto** para destacar",
            max: b.type === "heading" ? 256 : 3500,
            paragraph: b.type !== "heading",
        },
    ]));
}
async function reviewPublish(i, s) {
    (0, document_1.render)(s.documentJson);
    if (s.panelId) {
        await S.save(i, s.id, s.revision);
        return (0, common_1.show)(i, await V.roleDetail(i.guild, s.panelId, "Rascunho salvo. Confira as associações e escolha Publicar / atualizar."));
    }
    (0, common_1.assert)(s.destinationChannelId, "Escolha o canal de destino.");
    await S.channel(i.guild, s.destinationChannelId);
    const a = await (0, common_1.action)(i, "PUBLISH", s.publicationId, {
        sessionId: s.id,
        revision: s.revision,
        documentJson: s.documentJson,
        name: s.name,
        channelId: s.destinationChannelId,
        publicationId: s.publicationId,
    });
    return (0, common_1.show)(i, await V.confirmation(i.guild, a));
}
async function buttonAction(i, parts) {
    const [a, id, rev, blockId, itemId] = parts;
    if (a === "home")
        return (0, common_1.show)(i, await V.home(i.guild));
    if (a === "templates")
        return (0, common_1.show)(i, await V.templates(i.guild, Number(id)));
    if (a === "publications")
        return (0, common_1.show)(i, await V.publications(i.guild, Number(id)));
    if (a === "create")
        return (0, common_1.show)(i, await V.editor(i.guild, await S.start(i)));
    if (a === "pub")
        return (0, common_1.show)(i, await V.publicationView(i.guild, id, Number(rev)));
    if (a === "pub-edit") {
        const p = await S.publication(i.guild.id, id);
        if (p.panelId)
            return (0, common_1.show)(i, await V.roleDetail(i.guild, p.panelId));
        return (0, common_1.show)(i, await V.editor(i.guild, await S.start(i, { publicationId: id })));
    }
    if (a === "pub-copy") {
        const p = await S.publication(i.guild.id, id);
        return (0, common_1.show)(i, await V.editor(i.guild, await S.start(i, {
            document: (0, document_1.parse)(p.snapshotJson),
            name: p.name + " · Cópia",
        })));
    }
    if (a === "pub-check") {
        await S.verifyPublication(i.guild, id);
        return (0, common_1.show)(i, await V.publicationView(i.guild, id));
    }
    if (a === "pub-delete") {
        const p = await S.publication(i.guild.id, id);
        (0, common_1.assert)(!p.panelId, "Gerencie esse painel em Cargos por reação.");
        const op = await (0, common_1.action)(i, "PUB_DELETE", p.id, {
            name: p.name,
            channelId: p.channelId,
            revision: p.revision,
        });
        return (0, common_1.show)(i, await V.confirmation(i.guild, op));
    }
    if (a === "pub-register") {
        const p = await S.publication(i.guild.id, id);
        (0, common_1.assert)(!p.messageId, "Esta publicação já tem uma mensagem registrada.");
        const op = await (0, common_1.action)(i, "REGISTER", p.id, {});
        return i.showModal((0, common_1.form)("register:" + op.id, "Confirmar mensagem já enviada", [
            { id: "message", label: "ID da mensagem enviada no canal", max: 22 },
        ]));
    }
    if (a === "edit")
        return (0, common_1.show)(i, await V.editor(i.guild, await (0, common_1.session)(i, id), Number(rev)));
    if (a === "preview")
        return (0, common_1.show)(i, await V.editor(i.guild, await (0, common_1.session)(i, id, rev), Number(blockId), true));
    if (a === "add")
        return (0, common_1.show)(i, await V.addTypes(i.guild, await (0, common_1.session)(i, id, rev)));
    if (a === "organize")
        return (0, common_1.show)(i, await V.organize(i.guild, await (0, common_1.session)(i, id, rev), blockId));
    if (a === "appearance") {
        const s = await (0, common_1.session)(i, id, rev), doc = (0, document_1.parse)(s.documentJson);
        return i.showModal((0, common_1.form)("appearance:" + id + ":" + rev, "Nome e cor da mensagem", [
            { id: "name", label: "Nome interno do modelo", value: s.name, max: 80 },
            {
                id: "color",
                label: "Cor hexadecimal — exemplo D71935",
                value: doc.color,
                max: 7,
            },
        ]));
    }
    if (["up", "down", "remove", "duplicate"].includes(a)) {
        const s = await S.change(i, id, rev, (d) => {
            const n = d.blocks.findIndex((b) => b.id === blockId);
            (0, common_1.assert)(n >= 0, "Bloco indisponível.");
            if (a === "remove") {
                (0, common_1.assert)(d.blocks.length > 1, "Mantenha pelo menos um bloco.");
                d.blocks.splice(n, 1);
            }
            if (a === "duplicate") {
                const b = (0, document_1.copy)(d.blocks[n]);
                b.id = (0, document_1.uid)();
                if (b.buttons)
                    b.buttons = b.buttons.map((v) => ({ ...v, id: (0, document_1.uid)() }));
                d.blocks.splice(n + 1, 0, b);
            }
            if (a === "up" || a === "down") {
                const next = n + (a === "up" ? -1 : 1);
                (0, common_1.assert)(next >= 0 && next < d.blocks.length, "O bloco já está no limite.");
                [d.blocks[n], d.blocks[next]] = [d.blocks[next], d.blocks[n]];
            }
        });
        return (0, common_1.show)(i, await V.editor(i.guild, s, 0, false, "Ordem ou conteúdo atualizado. A publicação continua como estava."));
    }
    if (a === "undo") {
        const s = await (0, common_1.session)(i, id, rev);
        (0, common_1.assert)(s.undoJson, "Não há edição anterior para desfazer.");
        const old = JSON.parse(s.undoJson), next = await S.change(i, id, rev, (d, current) => {
            Object.assign(d, (0, document_1.parse)(old.documentJson));
            current.name = old.name;
        });
        await common_1.prisma.makerSession.update({
            where: { id },
            data: { undoJson: null },
        });
        return (0, common_1.show)(i, await V.editor(i.guild, next, 0, false, "Última edição desfeita."));
    }
    if (a === "save") {
        const s = await S.save(i, id, rev);
        return (0, common_1.show)(i, await V.editor(i.guild, s, 0, false, s.panelId
            ? "Rascunho do painel salvo. A publicação não foi alterada."
            : "Modelo salvo. Os envios anteriores foram preservados."));
    }
    if (a === "publish") {
        const s = await (0, common_1.session)(i, id, rev);
        if (s.panelId || s.publicationId)
            return reviewPublish(i, s);
        return (0, common_1.show)(i, await V.destination(i.guild, s));
    }
    if (a === "review")
        return reviewPublish(i, await (0, common_1.session)(i, id, rev));
    if (a === "more") {
        const s = await (0, common_1.session)(i, id, rev);
        return (0, common_1.show)(i, {
            embeds: [
                new common_1.D.EmbedBuilder()
                    .setColor(0xd71935)
                    .setTitle("Mais opções · " + (0, common_1.clean)(s.name, 60))
                    .setDescription("Uma cópia tem conteúdo independente. Excluir um modelo preserva as publicações."),
            ],
            components: [
                (0, common_1.row)((0, common_1.button)("copy:" + id + ":" + rev, "Salvar uma cópia"), (0, common_1.button)("delete-template:" + id + ":" + rev, "Excluir modelo", 4, !s.templateId || !!s.publicationId)),
                (0, common_1.row)((0, common_1.button)("templates:0", "Modelos salvos"), (0, common_1.button)("publications:0", "Mensagens enviadas"), (0, common_1.button)("edit:" + id, "Voltar")),
            ],
        });
    }
    if (a === "copy") {
        const s = await (0, common_1.session)(i, id, rev), t = await common_1.prisma.makerTemplate.create({
            data: {
                id: (0, document_1.uid)(),
                guildId: i.guild.id,
                name: (s.name + " · Cópia").slice(0, 80),
                documentJson: s.documentJson,
                createdById: i.user.id,
            },
        });
        return (0, common_1.show)(i, await V.editor(i.guild, await S.start(i, { templateId: t.id })));
    }
    if (a === "delete-template") {
        const s = await (0, common_1.session)(i, id, rev);
        (0, common_1.assert)(s.templateId && !s.publicationId, "Escolha um modelo salvo.");
        const t = await common_1.prisma.makerTemplate.findFirst({
            where: { id: s.templateId, guildId: i.guild.id, deletedAt: null },
        });
        (0, common_1.assert)(t, "Modelo indisponível.");
        return (0, common_1.show)(i, await V.confirmation(i.guild, await (0, common_1.action)(i, "TEMPLATE_DELETE", t.id, {
            name: t.name,
            revision: t.revision,
        })));
    }
    if (a === "copy-role") {
        const s = await (0, common_1.session)(i, id, rev);
        (0, common_1.assert)(!s.panelId, "Esta mensagem já pertence a um painel.");
        const p = await R.create(i.guild.id, i.user.id, (0, document_1.parse)(s.documentJson), s.name);
        return (0, common_1.show)(i, await V.roleDetail(i.guild, p.id, "Mensagem copiada para um novo painel. O modelo e as publicações anteriores foram preservados."));
    }
    if (a === "link" || a === "button-edit") {
        const s = await (0, common_1.session)(i, id, rev), b = (0, document_1.parse)(s.documentJson).blocks.find((v) => v.id === blockId);
        (0, common_1.assert)(b?.type === "buttons", "Bloco de botões indisponível.");
        const item = b.buttons.find((v) => v.id === itemId);
        if (a === "button-edit")
            (0, common_1.assert)(item, "Botão indisponível.");
        return i.showModal((0, common_1.form)("link:" + id + ":" + rev + ":" + blockId + ":" + (itemId || "new"), "Botão de link", [
            { id: "label", label: "Texto do botão", value: item?.label, max: 80 },
            {
                id: "url",
                label: "Link http:// ou https://",
                value: item?.url,
                max: 1000,
            },
            {
                id: "emoji",
                label: "Emoji opcional — vazio para remover",
                value: item?.emoji,
                max: 60,
                required: false,
            },
        ]));
    }
    if (a === "channel-button") {
        const s = await (0, common_1.session)(i, id, rev);
        return (0, common_1.show)(i, {
            embeds: [
                new common_1.D.EmbedBuilder()
                    .setColor(0xd71935)
                    .setTitle("Botão para canal")
                    .setDescription("Escolha um canal deste servidor. Depois defina o texto do botão."),
            ],
            components: [
                (0, common_1.row)(new common_1.D.ChannelSelectMenuBuilder()
                    .setCustomId("maker-select:button-channel:" + id + ":" + rev + ":" + blockId)
                    .setPlaceholder("Canal do botão")
                    .addChannelTypes(common_1.D.ChannelType.GuildText, common_1.D.ChannelType.GuildAnnouncement, common_1.D.ChannelType.GuildForum, common_1.D.ChannelType.GuildVoice)),
                (0, common_1.row)((0, common_1.button)("edit:" + id, "Voltar ao editor")),
            ],
        });
    }
    if (["button-remove", "button-up", "button-down"].includes(a)) {
        const s = await S.change(i, id, rev, (doc) => {
            const b = doc.blocks.find((v) => v.id === blockId);
            (0, common_1.assert)(b?.buttons, "Bloco indisponível.");
            const n = b.buttons.findIndex((v) => v.id === itemId);
            (0, common_1.assert)(n >= 0, "Botão indisponível.");
            if (a === "button-remove") {
                if (b.buttons.length === 1)
                    doc.blocks.splice(doc.blocks.indexOf(b), 1);
                else
                    b.buttons.splice(n, 1);
            }
            else {
                const next = n + (a === "button-up" ? -1 : 1);
                (0, common_1.assert)(next >= 0 && next < b.buttons.length, "O botão já está no limite.");
                [b.buttons[n], b.buttons[next]] = [b.buttons[next], b.buttons[n]];
            }
        });
        return (0, common_1.show)(i, await V.editor(i.guild, s));
    }
    return false;
}
async function selectAction(i, parts) {
    const [a, id, rev, blockId] = parts, value = i.values[0];
    if (a === "home") {
        if (value === "create")
            return (0, common_1.show)(i, await V.editor(i.guild, await S.start(i)));
        if (value === "templates")
            return (0, common_1.show)(i, await V.templates(i.guild));
        if (value === "publications")
            return (0, common_1.show)(i, await V.publications(i.guild));
    }
    if (a === "template")
        return (0, common_1.show)(i, await V.editor(i.guild, await S.start(i, { templateId: value })));
    if (a === "publication")
        return (0, common_1.show)(i, await V.publicationView(i.guild, value));
    if (a === "block")
        return openBlock(i, await (0, common_1.session)(i, id, rev), value);
    if (a === "organize")
        return (0, common_1.show)(i, await V.organize(i.guild, await (0, common_1.session)(i, id, rev), value));
    if (a === "add") {
        const s = await (0, common_1.session)(i, id, rev);
        if (value === "separator") {
            const next = await S.change(i, id, rev, (d) => d.blocks.push({ id: (0, document_1.uid)(), type: "separator" }));
            return (0, common_1.show)(i, await V.editor(i.guild, next));
        }
        if (value === "buttons")
            return i.showModal((0, common_1.form)("newbutton:" + id + ":" + rev, "Primeiro botão do bloco", [
                { id: "label", label: "Texto do botão", max: 80 },
                { id: "url", label: "Link http:// ou https://", max: 1000 },
            ]));
        if (value === "gallery")
            return i.showModal((0, common_1.form)("addblock:" + id + ":" + rev + ":gallery", "Adicionar galeria", [
                {
                    id: "images",
                    label: "Links das imagens — um por linha",
                    paragraph: true,
                    max: 3500,
                },
            ]));
        (0, common_1.assert)(["text", "heading", "section"].includes(value), "Tipo de bloco inválido.");
        return i.showModal((0, common_1.form)("addblock:" + id + ":" + rev + ":" + value, "Adicionar " + (value === "heading" ? "título" : "texto"), [
            { ...textField(""), max: value === "heading" ? 256 : 3500 },
            ...(value === "section"
                ? [{ id: "thumbnail", label: "Link da miniatura", max: 1000 }]
                : []),
        ]));
    }
    if (a === "button")
        return (0, common_1.show)(i, await V.buttons(i.guild, await (0, common_1.session)(i, id, rev), blockId, value));
    if (a === "button-channel") {
        await (0, common_1.session)(i, id, rev);
        const ch = await i.guild.channels.fetch(value).catch(() => null);
        (0, common_1.assert)(ch?.guildId === i.guild.id, "Escolha um canal deste servidor.");
        const op = await (0, common_1.action)(i, "BUTTON_CHANNEL", id, {
            sessionId: id,
            revision: Number(rev),
            blockId,
            channelId: ch.id,
        });
        return i.showModal((0, common_1.form)("channel-button:" + op.id, "Texto do botão de canal", [
            { id: "label", label: "Texto do botão", value: ch.name, max: 80 },
            { id: "emoji", label: "Emoji opcional", required: false, max: 60 },
        ]));
    }
    if (a === "destination") {
        const s = await (0, common_1.session)(i, id, rev);
        await S.channel(i.guild, value);
        (0, common_1.assert)(!s.publicationId && !s.panelId, "O destino de uma publicação existente permanece fixo. Crie uma cópia para mudar de canal.");
        const r = await common_1.prisma.makerSession.updateMany({
            where: { id, revision: s.revision },
            data: { destinationChannelId: value, revision: { increment: 1 } },
        });
        (0, common_1.assert)(r.count === 1, "A edição mudou. Abra novamente.");
        return (0, common_1.show)(i, await V.destination(i.guild, await (0, common_1.session)(i, id)));
    }
    return false;
}
async function modalAction(i, parts) {
    const [a, id, rev, blockId, itemId] = parts, value = (name) => i.fields.getTextInputValue(name).trim();
    if (a === "appearance") {
        const s = await S.change(i, id, rev, (d, s) => {
            d.color = value("color").replace(/^#/, "").toUpperCase();
            s.name = value("name");
        });
        return (0, common_1.show)(i, await V.editor(i.guild, s));
    }
    if (a === "block" || a === "addblock") {
        const s = await S.change(i, id, rev, (d) => {
            const b = a === "block"
                ? d.blocks.find((b) => b.id === blockId)
                : { id: (0, document_1.uid)(), type: blockId };
            (0, common_1.assert)(b && ["text", "heading", "section", "gallery"].includes(b.type), "Bloco indisponível.");
            if (b.type === "gallery")
                b.images = value("images")
                    .split(/\r?\n/)
                    .map((v) => v.trim())
                    .filter(Boolean);
            else {
                b.text = value("text");
                if (b.type === "section")
                    b.thumbnail = value("thumbnail");
            }
            if (a === "addblock")
                d.blocks.push(b);
        });
        return (0, common_1.show)(i, await V.editor(i.guild, s));
    }
    if (a === "newbutton" || a === "link") {
        const s = await S.change(i, id, rev, (d) => {
            if (a === "newbutton") {
                d.blocks.push({
                    id: (0, document_1.uid)(),
                    type: "buttons",
                    buttons: [{ id: (0, document_1.uid)(), label: value("label"), url: value("url") }],
                });
                return;
            }
            const b = d.blocks.find((b) => b.id === blockId);
            (0, common_1.assert)(b?.type === "buttons", "Bloco indisponível.");
            const data = {
                label: value("label"),
                url: value("url"),
                emoji: value("emoji") || undefined,
            };
            if (itemId === "new") {
                (0, common_1.assert)(b.buttons.length < 5, "O bloco já tem cinco botões.");
                b.buttons.push({ id: (0, document_1.uid)(), ...data });
            }
            else {
                const item = b.buttons.find((v) => v.id === itemId);
                (0, common_1.assert)(item, "Botão indisponível.");
                Object.assign(item, data);
            }
        });
        return (0, common_1.show)(i, await V.editor(i.guild, s));
    }
    if (a === "channel-button") {
        const op = await (0, common_1.getAction)(i, id, true), data = JSON.parse(op.payloadJson);
        (0, common_1.assert)(op.kind === "BUTTON_CHANNEL", "Formulário inválido.");
        const ch = await i.guild.channels.fetch(data.channelId).catch(() => null);
        (0, common_1.assert)(ch?.guildId === i.guild.id, "Canal indisponível.");
        const s = await S.change(i, data.sessionId, data.revision, (d) => {
            const b = d.blocks.find((v) => v.id === data.blockId);
            (0, common_1.assert)(b?.buttons && b.buttons.length < 5, "Bloco de botões indisponível ou cheio.");
            b.buttons.push({
                id: (0, document_1.uid)(),
                label: value("label"),
                url: "https://discord.com/channels/" + i.guild.id + "/" + ch.id,
                emoji: value("emoji") || undefined,
            });
        });
        return (0, common_1.show)(i, await V.editor(i.guild, s));
    }
    return false;
}
