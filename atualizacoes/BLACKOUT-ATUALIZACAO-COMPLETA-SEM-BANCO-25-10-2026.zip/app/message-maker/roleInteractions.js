"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.buttons = buttons;
exports.selects = selects;
exports.modals = modals;
const common_1 = require("./common");
const R = __importStar(require("./roles"));
const S = __importStar(require("./service"));
const V = __importStar(require("./views"));
const document_1 = require("./document");
async function buttons(i, parts) {
    const [a, id, revision] = parts;
    if (a === "r-home")
        return (0, common_1.show)(i, await V.roleHome(i.guild, Number(id)));
    if (a === "r-create") {
        const p = await R.create(i.guild.id, i.user.id);
        return (0, common_1.show)(i, await V.editor(i.guild, await S.start(i, { panelId: p.id })));
    }
    if (a === "r-detail")
        return (0, common_1.show)(i, await V.roleDetail(i.guild, id));
    if (a === "r-copy") {
        const p = await R.panel(i.guild.id, id), next = await R.create(i.guild.id, i.user.id, (0, document_1.parse)(p.documentJson), (p.name + " · Cópia").slice(0, 80));
        for (const b of await R.bindings(i.guild.id, p.id))
            await R.addBinding(i.guild, next.id, b.roleId, b.emojiDisplay);
        return (0, common_1.show)(i, await V.roleDetail(i.guild, next.id, "Cópia independente criada. Escolha o canal e confira antes de publicar."));
    }
    if (a === "r-bindings")
        return (0, common_1.show)(i, await V.roleBindings(i.guild, id));
    if (a === "r-toggle") {
        const p = await R.panel(i.guild.id, id);
        if (p.status === "PAUSED") {
            const check = await R.inspect(i.guild, id);
            (0, common_1.assert)(!check.problems.length, check.problems.join("\n"));
        }
        await R.pause(i.guild.id, id, p.status !== "PAUSED");
        return (0, common_1.show)(i, await V.roleDetail(i.guild, id, "Estado alterado. Os cargos existentes foram preservados."));
    }
    if (a === "r-add") {
        const p = await R.panel(i.guild.id, id);
        (0, common_1.assert)(p.revision === Number(revision), "O painel mudou. Abra novamente a configuração.");
        return (0, common_1.show)(i, {
            embeds: [
                new common_1.D.EmbedBuilder()
                    .setColor(0xd71935)
                    .setTitle("Escolha o cargo da reação")
                    .setDescription("Na próxima etapa, informe o emoji. Cargos com permissões administrativas não são aceitos."),
            ],
            components: [
                (0, common_1.row)(new common_1.D.RoleSelectMenuBuilder()
                    .setCustomId("maker-select:r-role:" + p.id + ":" + p.revision)
                    .setPlaceholder("Cargo oferecido aos membros")
                    .setMinValues(1)
                    .setMaxValues(1)),
                (0, common_1.row)((0, common_1.button)("r-bindings:" + p.id, "Voltar")),
            ],
        });
    }
    if (a === "r-publish") {
        const p = await R.panel(i.guild.id, id);
        (0, common_1.assert)(p.revision === Number(revision), "O painel mudou. Confira a versão atual.");
        (0, common_1.assert)(p.channelId, "Defina o canal do painel.");
        const list = await R.bindings(i.guild.id, id);
        (0, common_1.assert)(list.length > 0, "Adicione pelo menos uma reação.");
        (0, document_1.render)(R.withLegend((0, document_1.parse)(p.documentJson), list, p.removeOnUnreact));
        const op = await (0, common_1.action)(i, "ROLE_PUBLISH", id, {
            panelId: id,
            revision: p.revision,
            channelId: p.channelId,
        });
        return (0, common_1.show)(i, await V.confirmation(i.guild, op));
    }
    if (a === "r-retire-keep" || a === "r-retire-revoke") {
        const b = await common_1.prisma.reactionRoleBinding.findFirst({
            where: { id, guildId: i.guild.id, active: true },
        });
        (0, common_1.assert)(b, "Associação indisponível.");
        const count = await common_1.prisma.reactionRoleGrant.count({
            where: { guildId: i.guild.id, bindingId: id, active: true },
        });
        const op = await (0, common_1.action)(i, a === "r-retire-keep" ? "BINDING_KEEP" : "BINDING_REVOKE", id, { panelId: b.panelId, count });
        return (0, common_1.show)(i, await V.confirmation(i.guild, op));
    }
    if (a === "r-revoke-batch") {
        const b = await common_1.prisma.reactionRoleBinding.findFirst({
            where: { id, guildId: i.guild.id },
        });
        (0, common_1.assert)(b, "Associação indisponível.");
        const result = await R.revokeBatch(i.guild, id);
        return (0, common_1.show)(i, await V.roleDetail(i.guild, b.panelId, "Retiradas processadas: " +
            result.processed +
            " · Falhas: " +
            result.failed +
            " · Pendentes: " +
            result.remaining +
            ". Consulte Reações e cargos para continuar."));
    }
    if (a === "r-inspect")
        return (0, common_1.show)(i, await V.roleInspect(i.guild, id));
    if (a === "r-sync") {
        const plan = await R.planSync(i.guild, id), op = await (0, common_1.action)(i, "SYNC", id, plan);
        return (0, common_1.show)(i, await V.confirmation(i.guild, op));
    }
    return false;
}
async function selects(i, parts) {
    const [a, id, revision] = parts, value = i.values[0];
    if (a === "r-panel")
        return (0, common_1.show)(i, await V.roleDetail(i.guild, value));
    if (a === "r-task") {
        const p = await R.panel(i.guild.id, id);
        if (value === "message")
            return (0, common_1.show)(i, await V.editor(i.guild, await S.start(i, { panelId: id })));
        if (value === "bindings")
            return (0, common_1.show)(i, await V.roleBindings(i.guild, id));
        if (value === "inspect")
            return (0, common_1.show)(i, await V.roleInspect(i.guild, id));
        if (value === "channel")
            return (0, common_1.show)(i, {
                embeds: [
                    new common_1.D.EmbedBuilder()
                        .setColor(0xd71935)
                        .setTitle("Canal do painel")
                        .setDescription(p.publicationId
                        ? "O canal de uma publicação permanece fixo. Use Duplicar painel para escolher outro destino."
                        : "Escolha um canal deste servidor. A mensagem será enviada somente ao publicar."),
                ],
                components: [
                    (0, common_1.row)(new common_1.D.ChannelSelectMenuBuilder()
                        .setCustomId("maker-select:r-channel:" + id + ":" + p.revision)
                        .setPlaceholder("Canal das reações")
                        .addChannelTypes(common_1.D.ChannelType.GuildText, common_1.D.ChannelType.GuildAnnouncement)
                        .setDisabled(!!p.publicationId)),
                    (0, common_1.row)((0, common_1.button)("r-detail:" + id, "Voltar")),
                ],
            });
        if (value === "rule")
            return (0, common_1.show)(i, {
                embeds: [
                    new common_1.D.EmbedBuilder()
                        .setColor(0xd71935)
                        .setTitle("Ao retirar a reação")
                        .setDescription("A regra salva será aplicada após Publicar / atualizar. As concessões anteriores permanecem registradas."),
                ],
                components: [
                    (0, common_1.select)("r-rule:" + id + ":" + p.revision, "Escolha o comportamento", [
                        { value: "remove", label: "Remover a concessão deste painel" },
                        { value: "keep", label: "Preservar o cargo" },
                    ]),
                    (0, common_1.row)((0, common_1.button)("r-detail:" + id, "Voltar")),
                ],
            });
    }
    if (a === "r-channel" || a === "r-rule") {
        const p = await R.panel(i.guild.id, id);
        (0, common_1.assert)(p.revision === Number(revision), "A configuração mudou. Abra novamente.");
        let data;
        if (a === "r-channel") {
            (0, common_1.assert)(!p.publicationId, "O painel já tem um destino publicado. Duplique para mudar de canal.");
            await S.channel(i.guild, value, true);
            data = { channelId: value };
        }
        else {
            (0, common_1.assert)(["remove", "keep"].includes(value), "Escolha uma regra válida.");
            data = { removeOnUnreact: value === "remove" };
        }
        const r = await common_1.prisma.reactionRolePanel.updateMany({
            where: { id, guildId: i.guild.id, revision: p.revision },
            data: { ...data, revision: { increment: 1 } },
        });
        (0, common_1.assert)(r.count === 1, "O painel mudou. Abra novamente.");
        return (0, common_1.show)(i, await V.roleDetail(i.guild, id, "Configuração salva. Publique para aplicar a regra à mensagem."));
    }
    if (a === "r-role") {
        const p = await R.panel(i.guild.id, id);
        (0, common_1.assert)(p.revision === Number(revision), "O painel mudou. Abra novamente.");
        const role = await R.safeRole(i.guild, value), op = await (0, common_1.action)(i, "BINDING_FORM", p.id, {
            roleId: role.id,
            revision: p.revision,
        });
        return i.showModal((0, common_1.form)("binding:" + op.id, "Reação para " + role.name.slice(0, 30), [
            { id: "emoji", label: "Emoji — exemplo 🎮 ou <:nome:id>", max: 80 },
        ]));
    }
    if (a === "r-binding") {
        const p = await R.panel(i.guild.id, id), b = await common_1.prisma.reactionRoleBinding.findFirst({
            where: { id: value, guildId: i.guild.id, panelId: p.id, active: true },
        });
        (0, common_1.assert)(b, "Associação indisponível.");
        const count = await common_1.prisma.reactionRoleGrant.count({
            where: { guildId: i.guild.id, bindingId: b.id, active: true },
        });
        return (0, common_1.show)(i, {
            embeds: [
                new common_1.D.EmbedBuilder()
                    .setColor(0xd71935)
                    .setTitle("Gerenciar associação")
                    .setDescription(b.emojiDisplay +
                    " → <@&" +
                    b.roleId +
                    ">\nConcessões rastreadas: " +
                    count +
                    "\n\nPara trocar o emoji ou o cargo, desative a associação e crie outra. Escolha o que fazer com as concessões anteriores."),
            ],
            components: [
                (0, common_1.row)((0, common_1.button)("r-retire-keep:" + b.id, "Desativar e preservar cargos"), (0, common_1.button)("r-retire-revoke:" + b.id, "Desativar e revisar retiradas", 4)),
                (0, common_1.row)((0, common_1.button)("r-bindings:" + id, "Voltar")),
            ],
        });
    }
    return false;
}
async function modals(i, parts) {
    const [a, id] = parts;
    if (a !== "binding")
        return false;
    const op = await (0, common_1.getAction)(i, id, true);
    (0, common_1.assert)(op.kind === "BINDING_FORM", "Formulário inválido.");
    const data = JSON.parse(op.payloadJson), p = await R.panel(i.guild.id, op.targetId);
    (0, common_1.assert)(p.revision === data.revision, "O painel mudou. Abra novamente a associação.");
    await R.addBinding(i.guild, p.id, data.roleId, i.fields.getTextInputValue("emoji"), data.revision);
    return (0, common_1.show)(i, await V.roleBindings(i.guild, p.id));
}
