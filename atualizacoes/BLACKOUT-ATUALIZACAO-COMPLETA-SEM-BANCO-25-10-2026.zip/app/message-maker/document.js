"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.hash = exports.MakerError = exports.copy = exports.uid = void 0;
exports.assert = assert;
exports.url = url;
exports.blank = blank;
exports.parse = parse;
exports.blockComponents = blockComponents;
exports.countComponents = countComponents;
exports.textLength = textLength;
exports.render = render;
exports.add = add;
exports.pages = pages;
exports.legacy = legacy;
const D = __importStar(require("discord.js"));
const node_crypto_1 = require("node:crypto");
const uid = () => (0, node_crypto_1.randomBytes)(12).toString("hex");
exports.uid = uid;
const copy = (x) => JSON.parse(JSON.stringify(x));
exports.copy = copy;
class MakerError extends Error {
}
exports.MakerError = MakerError;
function assert(ok, message) {
    if (!ok)
        throw new MakerError(message);
}
function url(value) {
    try {
        const u = new URL(value);
        return (["https:", "http:"].includes(u.protocol) &&
            !u.username &&
            !u.password &&
            value.length <= 1000);
    }
    catch {
        return false;
    }
}
function blank() {
    return {
        version: 2,
        color: "D71935",
        blocks: [
            { id: (0, exports.uid)(), type: "heading", text: "Sua próxima mensagem" },
            {
                id: (0, exports.uid)(),
                type: "text",
                text: "Edite este texto e construa a mensagem da sua comunidade.",
            },
        ],
    };
}
function parse(raw) {
    const d = typeof raw === "string" ? JSON.parse(raw) : (0, exports.copy)(raw);
    assert(d?.version === 2 && Array.isArray(d.blocks), "O modelo não está no formato de mensagens V2.");
    assert(/^[A-Fa-f0-9]{6}$/.test(d.color), "Use uma cor hexadecimal com seis caracteres.");
    assert(d.blocks.length >= 1 && d.blocks.length <= 30, "A mensagem excedeu o limite de blocos.");
    const keys = new Set();
    for (const b of d.blocks) {
        assert(typeof b.id === "string" &&
            /^[a-zA-Z0-9_-]{1,32}$/.test(b.id) &&
            !keys.has(b.id), "Um bloco está inconsistente. Reabra o modelo.");
        keys.add(b.id);
        assert([
            "text",
            "heading",
            "section",
            "gallery",
            "separator",
            "buttons",
        ].includes(b.type), "Esse tipo de bloco não é compatível.");
        if (["text", "heading", "section"].includes(b.type))
            assert(typeof b.text === "string" &&
                b.text.trim().length > 0 &&
                b.text.length <= (b.type === "heading" ? 256 : 4000), "Preencha o texto do bloco dentro do limite indicado.");
        if (b.type === "section")
            assert(url(b.thumbnail || ""), "A miniatura precisa de um link http:// ou https:// válido.");
        if (b.type === "gallery")
            assert(Array.isArray(b.images) &&
                b.images.length >= 1 &&
                b.images.length <= 10 &&
                b.images.every(url), "Use de 1 a 10 links válidos na galeria.");
        if (b.type === "buttons") {
            assert(Array.isArray(b.buttons) &&
                b.buttons.length >= 1 &&
                b.buttons.length <= 5, "Cada bloco comporta de 1 a 5 botões.");
            for (const v of b.buttons) {
                assert(v.label?.trim() && v.label.length <= 80 && url(v.url), "Preencha o nome e um link válido para cada botão.");
                if (v.emoji) {
                    try {
                        new D.ButtonBuilder()
                            .setStyle(D.ButtonStyle.Link)
                            .setLabel(v.label)
                            .setURL(v.url)
                            .setEmoji(v.emoji)
                            .toJSON();
                    }
                    catch {
                        throw new MakerError("Um emoji de botão não é válido.");
                    }
                }
            }
        }
    }
    return d;
}
function blockComponents(b, disabled = false) {
    if (b.type === "separator")
        return [
            new D.SeparatorBuilder()
                .setDivider(true)
                .setSpacing(D.SeparatorSpacingSize.Small),
        ];
    if (b.type === "gallery")
        return [
            new D.MediaGalleryBuilder().addItems(...b.images.map((u) => new D.MediaGalleryItemBuilder().setURL(u))),
        ];
    if (b.type === "section")
        return [
            new D.SectionBuilder()
                .addTextDisplayComponents(new D.TextDisplayBuilder().setContent(b.text))
                .setThumbnailAccessory(new D.ThumbnailBuilder().setURL(b.thumbnail)),
        ];
    if (b.type === "buttons")
        return [
            new D.ActionRowBuilder().addComponents(...b.buttons.map((v) => {
                const out = new D.ButtonBuilder()
                    .setStyle(D.ButtonStyle.Link)
                    .setLabel(v.label)
                    .setURL(v.url)
                    .setDisabled(disabled);
                if (v.emoji)
                    out.setEmoji(v.emoji);
                return out;
            })),
        ];
    return [
        new D.TextDisplayBuilder().setContent(b.type === "heading" ? "## " + b.text : b.text),
    ];
}
function countComponents(components) {
    return components.reduce((n, c) => {
        const v = typeof c.toJSON === "function" ? c.toJSON() : c;
        return (n +
            1 +
            (v.components ? countComponents(v.components) : 0) +
            (v.accessory ? countComponents([v.accessory]) : 0));
    }, 0);
}
function textLength(components) {
    return components.reduce((n, c) => {
        const v = typeof c.toJSON === "function" ? c.toJSON() : c;
        return (n +
            (typeof v.content === "string" ? v.content.length : 0) +
            (v.components ? textLength(v.components) : 0));
    }, 0);
}
function render(raw, disabled = false) {
    const doc = parse(raw), parts = doc.blocks.flatMap((b) => blockComponents(b, disabled));
    const container = new D.ContainerBuilder().setAccentColor(parseInt(doc.color, 16));
    for (const c of parts)
        add(container, c);
    const components = [container];
    assert(countComponents(components) <= 40, "Esta mensagem ultrapassa 40 componentes. Remova ou divida alguns blocos.");
    assert(textLength(components) <= 4000, "Esta mensagem ultrapassa 4.000 caracteres. Reduza o texto ou divida em dois modelos.");
    return {
        flags: D.MessageFlags.IsComponentsV2,
        components,
        allowedMentions: { parse: [] },
    };
}
function add(container, c) {
    const type = c.toJSON().type;
    if (type === 10)
        container.addTextDisplayComponents(c);
    else if (type === 9)
        container.addSectionComponents(c);
    else if (type === 12)
        container.addMediaGalleryComponents(c);
    else if (type === 14)
        container.addSeparatorComponents(c);
    else
        container.addActionRowComponents(c);
}
function pages(raw, disabled = true) {
    const doc = parse(raw), out = [];
    let blocks = [], count = 1, chars = 0;
    // Reserve native components and text for editing controls. Do not truncate publication.
    for (const original of doc.blocks) {
        const fragments = ["text", "section"].includes(original.type) &&
            original.text.length > 2400
            ? original.text.match(/[\s\S]{1,2400}/g).map((text, n) => ({
                ...original,
                type: n === 0 ? original.type : "text",
                id: original.id.slice(0, 25) + "_" + n,
                text,
            }))
            : [original];
        for (const b of fragments) {
            const c = blockComponents(b, disabled), nc = countComponents(c), nt = textLength(c);
            if (blocks.length && (count + nc > 20 || chars + nt > 2700)) {
                out.push({ ...doc, blocks });
                blocks = [];
                count = 1;
                chars = 0;
            }
            blocks.push(b);
            count += nc;
            chars += nt;
        }
    }
    if (blocks.length)
        out.push({ ...doc, blocks });
    return out;
}
const hash = (doc) => (0, node_crypto_1.createHash)("sha256")
    .update(JSON.stringify(parse(doc)))
    .digest("hex");
exports.hash = hash;
function legacy(record, guildId) {
    const blocks = [], text = (value, type = "text") => {
        if (value?.trim())
            for (const part of value.match(/[\s\S]{1,1800}/g) || [])
                blocks.push({ id: (0, exports.uid)(), type, text: part });
    };
    text(record.author ? "**" + record.author + "**" : "");
    if (record.title && record.thumbnailUrl && url(record.thumbnailUrl))
        blocks.push({
            id: (0, exports.uid)(),
            type: "section",
            text: "**" + record.title + "**",
            thumbnail: record.thumbnailUrl,
        });
    else {
        text(record.title, "heading");
        if (record.thumbnailUrl && url(record.thumbnailUrl))
            blocks.push({
                id: (0, exports.uid)(),
                type: "gallery",
                images: [record.thumbnailUrl],
            });
    }
    text(record.description);
    if (record.imageUrl && url(record.imageUrl))
        blocks.push({ id: (0, exports.uid)(), type: "gallery", images: [record.imageUrl] });
    text(record.footer ? "-# " + record.footer : "");
    if (record.showTimestamp && record.createdAt)
        text("-# Modelo criado em " +
            new Date(record.createdAt).toLocaleDateString("pt-BR", {
                timeZone: "America/Sao_Paulo",
            }));
    const buttons = (record.buttons || [])
        .map((b) => ({
        id: (0, exports.uid)(),
        label: b.label,
        emoji: b.emoji || undefined,
        url: b.type === "CHANNEL"
            ? "https://discord.com/channels/" + guildId + "/" + b.channelId
            : b.url,
    }))
        .filter((b) => url(b.url || ""));
    for (let n = 0; n < buttons.length; n += 5)
        blocks.push({
            id: (0, exports.uid)(),
            type: "buttons",
            buttons: buttons.slice(n, n + 5),
        });
    if (!blocks.length)
        blocks.push({
            id: (0, exports.uid)(),
            type: "text",
            text: "Edite o conteúdo desta mensagem antes de publicar.",
        });
    return parse({
        version: 2,
        color: /^[a-f0-9]{6}$/i.test(String(record.color).replace("#", ""))
            ? String(record.color).replace("#", "").toUpperCase()
            : "D71935",
        blocks,
    });
}
