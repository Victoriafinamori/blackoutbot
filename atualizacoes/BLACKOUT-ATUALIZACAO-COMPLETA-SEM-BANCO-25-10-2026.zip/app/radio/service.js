"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.MAX_RADIO_TRACKS = void 0;
exports.extractYouTubeVideoId = extractYouTubeVideoId;
exports.getRadioConfig = getRadioConfig;
exports.getRadioTracks = getRadioTracks;
exports.addRadioTracks = addRadioTracks;
exports.removeRadioTrackPositions = removeRadioTrackPositions;
exports.moveRadioTrack = moveRadioTrack;
exports.clearRadioPlaylist = clearRadioPlaylist;
exports.setRadioVoiceChannel = setRadioVoiceChannel;
exports.setRadioMode = setRadioMode;
exports.setRadioVolume = setRadioVolume;
exports.setRadioEnabled = setRadioEnabled;
exports.resetRadioConfig = resetRadioConfig;
exports.getRadioRuntimeStatus = getRadioRuntimeStatus;
exports.startRadio = startRadio;
exports.stopRadio = stopRadio;
exports.restartRadio = restartRadio;
exports.pauseOrResumeRadio = pauseOrResumeRadio;
exports.skipRadioTrack = skipRadioTrack;
exports.previousRadioTrack = previousRadioTrack;
exports.restartCurrentRadioTrack = restartCurrentRadioTrack;
exports.shuffleRadioQueue = shuffleRadioQueue;
exports.refreshRadioQueue = refreshRadioQueue;
exports.restoreEnabledRadios = restoreEnabledRadios;
exports.shutdownRadios = shutdownRadios;
exports.formatRadioDuration = formatRadioDuration;

const { Readable } = require("node:stream");
const { prisma } = require("../database/prisma");
const { getOrCreateGuildConfig } = require("../database/guildConfig");

exports.MAX_RADIO_TRACKS = 500;
const RADIO_RECONNECT_DELAY_MS = 10_000;
const RADIO_FAILURE_RETRY_MS = 60_000;
const MAX_CONSECUTIVE_TRACK_FAILURES = 5;
const runtime = new Map();
let youtubeClientPromise = null;
let voiceLib = null;

function loadVoice() {
    if (voiceLib)
        return voiceLib;
    try {
        // Carregado sob demanda para o painel administrativo continuar utilizável
        // mesmo se a dependência de voz não tiver sido instalada corretamente.
        voiceLib = require("@discordjs/voice");
        return voiceLib;
    }
    catch (error) {
        const wrapped = new Error("A dependência @discordjs/voice não está instalada. Execute npm install antes de iniciar a Rádio 24h.");
        wrapped.cause = error;
        throw wrapped;
    }
}

async function getYoutubeClient() {
    if (!youtubeClientPromise) {
        youtubeClientPromise = import("youtubei.js")
            .then(({ Innertube }) => Innertube.create())
            .catch((error) => {
            youtubeClientPromise = null;
            const wrapped = new Error("A dependência youtubei.js não está disponível para resolver os links do YouTube.");
            wrapped.cause = error;
            throw wrapped;
        });
    }
    return youtubeClientPromise;
}

function extractYouTubeVideoId(raw) {
    const value = String(raw || "").trim();
    if (!value)
        return null;
    if (/^[A-Za-z0-9_-]{11}$/.test(value))
        return value;
    let url;
    try {
        url = new URL(/^https?:\/\//i.test(value) ? value : `https://${value}`);
    }
    catch {
        return null;
    }
    const host = url.hostname.toLowerCase().replace(/^www\./, "").replace(/^m\./, "");
    let candidate = null;
    if (host === "youtu.be") {
        candidate = url.pathname.split("/").filter(Boolean)[0] || null;
    }
    else if (host === "youtube.com" || host.endsWith(".youtube.com")) {
        if (url.pathname === "/watch")
            candidate = url.searchParams.get("v");
        else {
            const parts = url.pathname.split("/").filter(Boolean);
            if (["shorts", "embed", "live"].includes(parts[0]))
                candidate = parts[1] || null;
        }
    }
    return candidate && /^[A-Za-z0-9_-]{11}$/.test(candidate) ? candidate : null;
}

async function getRadioConfig(guildId) {
    await getOrCreateGuildConfig(guildId);
    return prisma.radioConfig.upsert({
        where: { guildId },
        create: { guildId },
        update: {},
    });
}

async function getRadioTracks(guildId) {
    const config = await getRadioConfig(guildId);
    return prisma.radioTrack.findMany({
        where: { configId: config.id },
        orderBy: [{ position: "asc" }, { createdAt: "asc" }],
    });
}

function normalizeTitle(title, videoId) {
    const cleaned = String(title || "").replace(/\s+/g, " ").trim();
    return cleaned ? cleaned.slice(0, 180) : `YouTube • ${videoId}`;
}

function normalizeDuration(value) {
    const number = Number(value);
    return Number.isFinite(number) && number > 0 ? Math.round(number) : null;
}

async function fetchYoutubeInfo(videoId) {
    const client = await getYoutubeClient();
    const info = await client.getInfo(videoId);
    const basic = info?.basic_info || {};
    return {
        info,
        title: normalizeTitle(basic.title, videoId),
        durationSeconds: normalizeDuration(basic.duration),
    };
}

async function hydrateTrackMetadata(track) {
    try {
        const metadata = await fetchYoutubeInfo(track.videoId);
        return await prisma.radioTrack.update({
            where: { id: track.id },
            data: {
                title: metadata.title,
                durationSeconds: metadata.durationSeconds,
                lastError: null,
            },
        });
    }
    catch (error) {
        const message = String(error?.message || error).slice(0, 500);
        await prisma.radioTrack.update({ where: { id: track.id }, data: { lastError: message } }).catch(() => null);
        return track;
    }
}

async function addRadioTracks(guildId, rawUrls, addedById) {
    const config = await getRadioConfig(guildId);
    const currentCount = await prisma.radioTrack.count({ where: { configId: config.id } });
    const remaining = Math.max(0, exports.MAX_RADIO_TRACKS - currentCount);
    const unique = new Map();
    const invalid = [];
    for (const raw of rawUrls) {
        const trimmed = String(raw || "").trim();
        if (!trimmed)
            continue;
        const videoId = extractYouTubeVideoId(trimmed);
        if (!videoId) {
            invalid.push(trimmed);
            continue;
        }
        if (!unique.has(videoId))
            unique.set(videoId, { videoId, url: `https://www.youtube.com/watch?v=${videoId}` });
    }
    const candidates = [...unique.values()].slice(0, remaining);
    let position = currentCount;
    const created = [];
    let duplicates = 0;
    for (const item of candidates) {
        position += 1;
        try {
            const track = await prisma.radioTrack.create({
                data: {
                    guildId,
                    configId: config.id,
                    url: item.url,
                    videoId: item.videoId,
                    position,
                    addedById: addedById || null,
                    title: `YouTube • ${item.videoId}`,
                },
            });
            created.push(track);
            void hydrateTrackMetadata(track).catch(() => null);
        }
        catch (error) {
            if (error?.code === "P2002") {
                duplicates += 1;
                position -= 1;
                continue;
            }
            throw error;
        }
    }
    return {
        added: created.length,
        duplicates,
        invalid: invalid.length,
        ignoredByLimit: Math.max(0, unique.size - candidates.length),
    };
}

async function reindexTracks(configId) {
    const tracks = await prisma.radioTrack.findMany({ where: { configId }, orderBy: [{ position: "asc" }, { createdAt: "asc" }] });
    await prisma.$transaction(tracks.map((track, index) => prisma.radioTrack.update({ where: { id: track.id }, data: { position: index + 1 } })));
}

async function removeRadioTrackPositions(guildId, positions) {
    const config = await getRadioConfig(guildId);
    const tracks = await prisma.radioTrack.findMany({ where: { configId: config.id }, orderBy: [{ position: "asc" }, { createdAt: "asc" }] });
    const wanted = new Set(positions.filter(Number.isInteger));
    const ids = tracks.filter((_, index) => wanted.has(index + 1)).map((track) => track.id);
    if (!ids.length)
        return 0;
    await prisma.radioTrack.deleteMany({ where: { id: { in: ids } } });
    await reindexTracks(config.id);
    return ids.length;
}

async function moveRadioTrack(guildId, fromPosition, toPosition) {
    const config = await getRadioConfig(guildId);
    const tracks = await prisma.radioTrack.findMany({ where: { configId: config.id }, orderBy: [{ position: "asc" }, { createdAt: "asc" }] });
    if (!tracks.length)
        return false;
    const from = Math.max(1, Math.min(tracks.length, Number(fromPosition))) - 1;
    const to = Math.max(1, Math.min(tracks.length, Number(toPosition))) - 1;
    if (!Number.isInteger(from) || !Number.isInteger(to) || !tracks[from])
        return false;
    const [moved] = tracks.splice(from, 1);
    tracks.splice(to, 0, moved);
    await prisma.$transaction(tracks.map((track, index) => prisma.radioTrack.update({ where: { id: track.id }, data: { position: index + 1 } })));
    return true;
}

async function clearRadioPlaylist(guildId) {
    const config = await getRadioConfig(guildId);
    const result = await prisma.radioTrack.deleteMany({ where: { configId: config.id } });
    await prisma.radioConfig.update({ where: { guildId }, data: { currentTrackId: null } });
    const state = runtime.get(guildId);
    if (state) {
        state.queue = [];
        state.history = [];
        state.currentTrack = null;
        state.suppressNextIdle = true;
        state.player?.stop(true);
    }
    return result.count;
}

async function setRadioVoiceChannel(guildId, voiceChannelId) {
    await getRadioConfig(guildId);
    return prisma.radioConfig.update({ where: { guildId }, data: { voiceChannelId: voiceChannelId || null } });
}

async function setRadioMode(guildId, mode) {
    await getRadioConfig(guildId);
    const normalized = mode === "RANDOM" ? "RANDOM" : "SEQUENTIAL";
    const config = await prisma.radioConfig.update({ where: { guildId }, data: { mode: normalized } });
    const state = runtime.get(guildId);
    if (state)
        state.queue = [];
    return config;
}

async function setRadioVolume(guildId, volume) {
    await getRadioConfig(guildId);
    const normalized = Math.max(1, Math.min(100, Math.round(Number(volume) || 50)));
    const config = await prisma.radioConfig.update({ where: { guildId }, data: { volume: normalized } });
    const state = runtime.get(guildId);
    if (state?.resource?.volume)
        state.resource.volume.setVolume(normalized / 100);
    return config;
}

async function setRadioEnabled(guildId, enabled) {
    await getRadioConfig(guildId);
    return prisma.radioConfig.update({ where: { guildId }, data: { enabled: Boolean(enabled), lastError: null } });
}

async function resetRadioConfig(guildId) {
    await stopRadio(guildId, { preserveEnabled: false });
    const config = await getRadioConfig(guildId);
    await prisma.$transaction([
        prisma.radioTrack.deleteMany({ where: { configId: config.id } }),
        prisma.radioConfig.update({
            where: { guildId },
            data: {
                enabled: false,
                voiceChannelId: null,
                mode: "SEQUENTIAL",
                volume: 50,
                currentTrackId: null,
                lastStartedAt: null,
                lastError: null,
            },
        }),
    ]);
}

function stateFor(guildId) {
    let state = runtime.get(guildId);
    if (!state) {
        state = {
            guildId,
            client: null,
            guild: null,
            connection: null,
            player: null,
            resource: null,
            queue: [],
            history: [],
            currentTrack: null,
            paused: false,
            connecting: false,
            advancing: false,
            suppressNextIdle: false,
            reconnectTimer: null,
            retryTimer: null,
            consecutiveFailures: 0,
            stopping: false,
        };
        runtime.set(guildId, state);
    }
    return state;
}

function shuffle(list) {
    const copy = [...list];
    for (let index = copy.length - 1; index > 0; index -= 1) {
        const next = Math.floor(Math.random() * (index + 1));
        [copy[index], copy[next]] = [copy[next], copy[index]];
    }
    return copy;
}

function buildQueue(tracks, mode, currentTrackId) {
    if (!tracks.length)
        return [];
    if (mode === "RANDOM") {
        const randomized = shuffle(tracks);
        if (randomized.length > 1 && randomized[0]?.id === currentTrackId)
            randomized.push(randomized.shift());
        return randomized;
    }
    const currentIndex = currentTrackId ? tracks.findIndex((track) => track.id === currentTrackId) : -1;
    if (currentIndex < 0)
        return [...tracks];
    return [...tracks.slice(currentIndex + 1), ...tracks.slice(0, currentIndex + 1)];
}

async function resolveAudioResource(track, volume) {
    const voice = loadVoice();
    const metadata = await fetchYoutubeInfo(track.videoId);
    const webStream = await metadata.info.download({ type: "audio", quality: "best", format: "webm", codec: "opus" });
    const nodeStream = Readable.fromWeb(webStream);
    const probe = await voice.demuxProbe(nodeStream);
    const resource = voice.createAudioResource(probe.stream, {
        inputType: probe.type,
        inlineVolume: true,
        metadata: { trackId: track.id, videoId: track.videoId, title: metadata.title },
    });
    resource.volume?.setVolume(Math.max(0.01, Math.min(1, volume / 100)));
    return { resource, metadata };
}

async function markTrackFailure(track, error) {
    const message = String(error?.message || error).slice(0, 500);
    if(track.requestId){await require('../social-experience/radio').finish(track,'FAILED',message);return message;}
    await prisma.radioTrack.update({
        where: { id: track.id },
        data: { failureCount: { increment: 1 }, lastError: message },
    }).catch(() => null);
    return message;
}

async function markConfigError(guildId, error) {
    const message = String(error?.message || error).slice(0, 500);
    await prisma.radioConfig.update({ where: { guildId }, data: { lastError: message } }).catch(() => null);
    return message;
}

async function setStageSpeaker(guild) {
    try {
        const me = guild.members.me || await guild.members.fetchMe();
        if (me?.voice?.channel?.type === 13) {
            await me.voice.setSuppressed(false).catch(() => null);
            if (me.voice.suppress)
                await me.voice.setRequestToSpeak(true).catch(() => null);
        }
    }
    catch {
        // Canal normal ou sem permissão de orador: a conexão continua ativa.
    }
}

function clearTimer(state, key) {
    if (state[key]) {
        clearTimeout(state[key]);
        state[key] = null;
    }
}

async function scheduleReconnect(state) {
    if (state.stopping || state.reconnectTimer)
        return;
    const config = await getRadioConfig(state.guildId).catch(() => null);
    if (!config?.enabled)
        return;
    state.reconnectTimer = setTimeout(() => {
        state.reconnectTimer = null;
        if (!state.client)
            return;
        const guild = state.client.guilds.cache.get(state.guildId);
        if (!guild)
            return;
        startRadio(guild, { resumeCurrent: true }).catch((error) => {
            console.error(`[radio:${state.guildId}] Falha na reconexão:`, error);
            void scheduleReconnect(state);
        });
    }, RADIO_RECONNECT_DELAY_MS);
    state.reconnectTimer.unref?.();
}

function attachPlayerListeners(state) {
    const voice = loadVoice();
    state.player.on(voice.AudioPlayerStatus.Playing, () => {
        state.paused = false;
    });
    state.player.on(voice.AudioPlayerStatus.Paused, () => {
        state.paused = true;
    });
    state.player.on(voice.AudioPlayerStatus.Idle, () => {
        if (state.stopping)
            return;
        if (state.suppressNextIdle) {
            state.suppressNextIdle = false;
            return;
        }
        void advanceRadio(state).catch((error) => console.error(`[radio:${state.guildId}] Erro ao avançar:`, error));
    });
    state.player.on("error", (error) => {
        if (state.currentTrack)
            void markTrackFailure(state.currentTrack, error);
        state.suppressNextIdle = true;
        void advanceRadio(state).catch((nextError) => console.error(`[radio:${state.guildId}] Erro após falha do player:`, nextError));
    });
}

function attachConnectionListeners(state) {
    const voice = loadVoice();
    state.connection.on(voice.VoiceConnectionStatus.Ready, () => {
        clearTimer(state, "reconnectTimer");
        void setStageSpeaker(state.guild);
    });
    state.connection.on(voice.VoiceConnectionStatus.Disconnected, async () => {
        if (state.stopping)
            return;
        try {
            await Promise.race([
                voice.entersState(state.connection, voice.VoiceConnectionStatus.Signalling, 5_000),
                voice.entersState(state.connection, voice.VoiceConnectionStatus.Connecting, 5_000),
            ]);
        }
        catch {
            try {
                state.connection.destroy();
            }
            catch { }
            state.connection = null;
            await scheduleReconnect(state);
        }
    });
    state.connection.on(voice.VoiceConnectionStatus.Destroyed, () => {
        state.connection = null;
        if (!state.stopping)
            void scheduleReconnect(state);
    });
}

async function ensureConnection(guild, config, state) {
    const voice = loadVoice();
    const channel = config.voiceChannelId ? await guild.channels.fetch(config.voiceChannelId).catch(() => null) : null;
    if (!channel || ![2, 13].includes(channel.type))
        throw new Error("A call configurada não existe mais ou não é um canal de voz/palco.");
    const currentChannelId = state.connection?.joinConfig?.channelId;
    if (state.connection && currentChannelId === channel.id) {
        state.connection.subscribe(state.player);
        return state.connection;
    }
    if (state.connection) {
        state.stopping = true;
        try {
            state.connection.destroy();
        }
        catch { }
        state.connection = null;
        state.stopping = false;
    }
    state.connection = voice.joinVoiceChannel({
        channelId: channel.id,
        guildId: guild.id,
        adapterCreator: guild.voiceAdapterCreator,
        selfDeaf: true,
        selfMute: false,
    });
    attachConnectionListeners(state);
    state.connection.subscribe(state.player);
    await voice.entersState(state.connection, voice.VoiceConnectionStatus.Ready, 20_000);
    await setStageSpeaker(guild);
    return state.connection;
}

async function playTrack(state, track, options = {}) {
    const config = await getRadioConfig(state.guildId);
    const old = state.currentTrack;
    const { resource, metadata } = await resolveAudioResource(track, config.volume);
    if (options.rememberPrevious !== false && old?.id && !old.requestId && old.id !== track.id) {
        state.history.push(old.id);
        if (state.history.length > 50)
            state.history.shift();
    }
    if(old?.requestId!==track.requestId)await require('../social-experience/radio').finish(old);
    state.playToken=require('node:crypto').randomUUID();
    state.currentTrack = { ...track, title: metadata.title, durationSeconds: metadata.durationSeconds };
    state.resource = resource;
    state.paused = false;
    state.suppressNextIdle = false;
    state.player.play(resource);
    state.consecutiveFailures = 0;
    await prisma.$transaction([
        prisma.radioConfig.update({
            where: { guildId: state.guildId },
            data: { currentTrackId: track.requestId ? null : track.id, lastStartedAt: new Date(), lastError: null },
        }),
        track.requestId ? prisma.socialRadioRequest.update({where:{id:track.requestId},data:{title:metadata.title}}) : prisma.radioTrack.update({
            where: { id: track.id },
            data: {
                title: metadata.title,
                durationSeconds: metadata.durationSeconds,
                lastPlayedAt: new Date(),
                lastError: null,
            },
        }),
    ]);
}

async function advanceRadio(state) {
    if (state.advancing || state.stopping)
        return;
    state.advancing = true;
    clearTimer(state, "retryTimer");
    try {
        const config = await getRadioConfig(state.guildId);
        if (!config.enabled)
            return;
        const requested=await require('../social-experience/radio').claimNext(state.guildId);
        if(requested){try{await playTrack(state,requested,{rememberPrevious:true});return;}catch(error){await markTrackFailure(requested,error);}}
        const tracks = await getRadioTracks(state.guildId);
        if (!tracks.length) {
            state.queue = [];
            state.currentTrack = null;
            state.resource = null;
            await prisma.radioConfig.update({ where: { guildId: state.guildId }, data: { currentTrackId: null, lastError: "A playlist está vazia." } });
            return;
        }
        if (!state.queue.length)
            state.queue = buildQueue(tracks, config.mode, state.currentTrack?.id || config.currentTrackId);
        const maxAttempts = Math.min(tracks.length, MAX_CONSECUTIVE_TRACK_FAILURES);
        for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
            if (!state.queue.length)
                state.queue = buildQueue(tracks, config.mode, state.currentTrack?.id || null);
            const next = state.queue.shift();
            if (!next)
                break;
            try {
                await playTrack(state, next, { rememberPrevious: true });
                return;
            }
            catch (error) {
                state.consecutiveFailures += 1;
                const message = await markTrackFailure(next, error);
                console.error(`[radio:${state.guildId}] Faixa ${next.videoId} indisponível: ${message}`);
            }
        }
        const error = new Error("Várias faixas falharam em sequência. A rádio tentará novamente em 1 minuto.");
        await markConfigError(state.guildId, error);
        state.retryTimer = setTimeout(() => {
            state.retryTimer = null;
            void advanceRadio(state).catch(() => null);
        }, RADIO_FAILURE_RETRY_MS);
        state.retryTimer.unref?.();
    }
    finally {
        state.advancing = false;
    }
}

async function startRadio(guild, options = {}) {
    const config = await getRadioConfig(guild.id);
    if (!config.enabled)
        return { started: false, reason: "disabled" };
    if (!config.voiceChannelId)
        throw new Error("Configure uma call antes de ativar a Rádio 24h.");
    const tracks = await getRadioTracks(guild.id);
    if (!tracks.length)
        throw new Error("Adicione pelo menos uma faixa à playlist antes de ativar a rádio.");
    const state = stateFor(guild.id);
    state.client = guild.client;
    state.guild = guild;
    state.stopping = false;
    clearTimer(state, "reconnectTimer");
    clearTimer(state, "retryTimer");
    const voice = loadVoice();
    if (!state.player) {
        state.player = voice.createAudioPlayer({ behaviors: { noSubscriber: voice.NoSubscriberBehavior.Play } });
        attachPlayerListeners(state);
    }
    await ensureConnection(guild, config, state);
    if (state.player.state.status === voice.AudioPlayerStatus.Playing || state.player.state.status === voice.AudioPlayerStatus.Paused)
        return { started: true, resumed: false };
    if (options.resumeCurrent !== false && config.currentTrackId) {
        const current = tracks.find((track) => track.id === config.currentTrackId);
        if (current) {
            try {
                await playTrack(state, current, { rememberPrevious: false });
                return { started: true, resumed: true };
            }
            catch (error) {
                await markTrackFailure(current, error);
            }
        }
    }
    state.queue = [];
    await advanceRadio(state);
    return { started: true, resumed: false };
}

async function stopRadio(guildId, options = {}) {
    const state = runtime.get(guildId);
    if(state?.currentTrack?.requestId)await require('../social-experience/radio').finish(state.currentTrack,'CANCELLED','Reprodução interrompida pela equipe.');
    if (!options.preserveEnabled)
        await prisma.radioConfig.updateMany({ where: { guildId }, data: { enabled: false, currentTrackId: null } }).catch(() => null);
    if (!state)
        return;
    state.stopping = true;
    clearTimer(state, "reconnectTimer");
    clearTimer(state, "retryTimer");
    state.suppressNextIdle = true;
    try {
        state.player?.stop(true);
    }
    catch { }
    try {
        state.connection?.destroy();
    }
    catch { }
    state.connection = null;
    state.player = null;
    state.resource = null;
    state.queue = [];
    state.history = [];
    state.currentTrack = null;
    runtime.delete(guildId);
}

async function restartRadio(guild) {
    const config = await getRadioConfig(guild.id);
    if (!config.enabled)
        return;
    await stopRadio(guild.id, { preserveEnabled: true });
    await startRadio(guild, { resumeCurrent: true });
}

async function pauseOrResumeRadio(guildId) {
    const state = runtime.get(guildId);
    if (!state?.player)
        return { ok: false, paused: false };
    const voice = loadVoice();
    if (state.player.state.status === voice.AudioPlayerStatus.Paused) {
        const ok = state.player.unpause();
        state.paused = !ok;
        return { ok, paused: false };
    }
    if (state.player.state.status === voice.AudioPlayerStatus.Playing) {
        const ok = state.player.pause();
        state.paused = ok;
        return { ok, paused: ok };
    }
    return { ok: false, paused: false };
}

async function skipRadioTrack(guildId) {
    const state = runtime.get(guildId);
    if (!state?.player)
        return false;
    state.suppressNextIdle = true;
    state.player.stop(true);
    await advanceRadio(state);
    return true;
}

async function previousRadioTrack(guildId) {
    const state = runtime.get(guildId);
    if (!state?.player || !state.history.length)
        return false;
    const previousId = state.history.pop();
    const track = await prisma.radioTrack.findUnique({ where: { id: previousId } });
    if (!track)
        return false;
    state.suppressNextIdle = true;
    state.player.stop(true);
    try {
        await playTrack(state, track, { rememberPrevious: false });
        return true;
    }
    catch (error) {
        await markTrackFailure(track, error);
        return false;
    }
}

async function restartCurrentRadioTrack(guildId) {
    const state = runtime.get(guildId);
    if (!state?.player || !state.currentTrack)
        return false;
    state.suppressNextIdle = true;
    state.player.stop(true);
    try {
        await playTrack(state, state.currentTrack, { rememberPrevious: false });
        return true;
    }
    catch (error) {
        await markTrackFailure(state.currentTrack, error);
        return false;
    }
}

async function shuffleRadioQueue(guildId) {
    const state = runtime.get(guildId);
    if (!state)
        return false;
    const tracks = await getRadioTracks(guildId);
    state.queue = shuffle(tracks.filter((track) => track.id !== state.currentTrack?.id));
    return true;
}

async function refreshRadioQueue(guildId) {
    const state = runtime.get(guildId);
    if (!state)
        return false;
    const [config, tracks] = await Promise.all([getRadioConfig(guildId), getRadioTracks(guildId)]);
    state.queue = buildQueue(tracks, config.mode, state.currentTrack?.id || config.currentTrackId)
        .filter((track) => track.id !== state.currentTrack?.id);
    state.history = state.history.filter((trackId) => tracks.some((track) => track.id === trackId));
    return true;
}

async function getRadioRuntimeStatus(guildId) {
    const state = runtime.get(guildId);
    const config = await getRadioConfig(guildId);
    let voiceStatus = "Desconectada";
    let playerStatus = "Parada";
    if (state?.connection)
        voiceStatus = state.connection.state?.status || "Conectando";
    if (state?.player)
        playerStatus = state.player.state?.status || "Parada";
    const current = state?.currentTrack || (config.currentTrackId ? await prisma.radioTrack.findUnique({ where: { id: config.currentTrackId } }).catch(() => null) : null);
    return {
        enabled: config.enabled,
        connected: Boolean(state?.connection),
        voiceStatus,
        playerStatus,
        paused: Boolean(state?.paused),
        currentTrack: current,
        playToken: state?.playToken || null,
        queueLength: state?.queue?.length || 0,
        lastError: config.lastError,
    };
}

async function restoreEnabledRadios(client) {
    // A request interrupted by a process restart is visibly failed; never replay it twice automatically.
    await prisma.socialRadioRequest.updateMany({where:{status:'PLAYING'},data:{status:'FAILED',error:'Reprodução interrompida pelo reinício da rádio.'}});
    const configs = await prisma.radioConfig.findMany({ where: { enabled: true } }).catch((error) => {
        console.error("[radio] Não foi possível carregar as rádios persistidas:", error);
        return [];
    });
    for (const config of configs) {
        const guild = client.guilds.cache.get(config.guildId) || await client.guilds.fetch(config.guildId).catch(() => null);
        if (!guild)
            continue;
        try {
            await startRadio(guild, { resumeCurrent: true });
            console.log(`[radio:${guild.id}] Rádio 24h restaurada.`);
        }
        catch (error) {
            const message = await markConfigError(guild.id, error);
            console.error(`[radio:${guild.id}] Falha ao restaurar: ${message}`);
            const state = stateFor(guild.id);
            state.client = client;
            state.guild = guild;
            void scheduleReconnect(state);
        }
    }
}

async function shutdownRadios() {
    const ids = [...runtime.keys()];
    for (const guildId of ids)
        await stopRadio(guildId, { preserveEnabled: true }).catch(() => null);
}

function formatRadioDuration(totalSeconds) {
    const value = Math.max(0, Number(totalSeconds) || 0);
    const hours = Math.floor(value / 3600);
    const minutes = Math.floor((value % 3600) / 60);
    const seconds = Math.floor(value % 60);
    if (hours > 0)
        return `${hours}h ${String(minutes).padStart(2, "0")}m`;
    if (minutes > 0)
        return `${minutes}m ${String(seconds).padStart(2, "0")}s`;
    return `${seconds}s`;
}
