"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.emoji = exports.asset = exports.ICONS = void 0;
exports.prepare = prepare;
const node_path_1 = __importDefault(require("node:path"));
exports.ICONS = { voice: "blackout_sec_voice", raid: "blackout_sec_raid", entry: "blackout_sec_entry", team: "blackout_sec_team", chat: "blackout_sec_chat", incidents: "blackout_sec_incidents", settings: "blackout_sec_settings" };
const asset = (key) => node_path_1.default.resolve(__dirname, "../../assets/blackout-ui/security", key + ".png");
exports.asset = asset;
const emoji = (guild, key) => guild.client.application?.emojis?.cache?.find((v) => v.name === exports.ICONS[key])?.id;
exports.emoji = emoji;
const pending = new WeakMap(), retry = new WeakMap();
async function prepare(guild) {
    const app = guild.client.application, m = app?.emojis;
    if (!m)
        return;
    if (Object.values(exports.ICONS).every(n => m.cache.some((e) => e.name === n)))
        return;
    if (pending.has(app))
        return pending.get(app);
    if ((retry.get(app) || 0) > Date.now())
        return;
    const task = (async () => {
        try {
            await m.fetch();
            for (const [key, name] of Object.entries(exports.ICONS))
                if (!m.cache.some((v) => v.name === name))
                    await m.create({ attachment: (0, exports.asset)(key), name });
        }
        catch {
            retry.set(app, Date.now() + 300000);
            console.warn("[blackout-security] PNGs dos seletores indisponíveis; mantendo rótulos e imagem local. Nova tentativa em 5 minutos.");
        }
    })();
    pending.set(app, task);
    try {
        await task;
    }
    finally {
        pending.delete(app);
    }
}
