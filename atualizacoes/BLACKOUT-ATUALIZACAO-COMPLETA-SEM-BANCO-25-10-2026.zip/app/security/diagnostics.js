"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.missingForRule = missingForRule;
exports.diagnose = diagnose;
const discord_js_1 = require("discord.js");
const config_1 = require("./config");
async function missingForRule(guild, key, rule, c) {
    const me = await guild.members.fetchMe(), problems = [], need = (bit, label) => {
        if (!me.permissions.has(bit))
            problems.push(label);
    };
    if (config_1.RULES[key].group === "team" || key === "moves")
        need(discord_js_1.PermissionFlagsBits.ViewAuditLog, "Ver Registro de Auditoria");
    if (rule.action === "KICK")
        need(discord_js_1.PermissionFlagsBits.KickMembers, "Expulsar Membros");
    if (rule.action === "TIMEOUT")
        need(discord_js_1.PermissionFlagsBits.ModerateMembers, "Moderar Membros");
    if (["DELETE", "TIMEOUT", "DELETE_WEBHOOK"].includes(rule.action) && config_1.RULES[key].group === "chat")
        need(discord_js_1.PermissionFlagsBits.ManageMessages, "Gerenciar Mensagens");
    if (rule.action === "DELETE_WEBHOOK")
        need(discord_js_1.PermissionFlagsBits.ManageWebhooks, "Gerenciar Webhooks");
    if (["REVOKE", "REVOKE_UNBAN", "RESTORE_REVOKE"].includes(rule.action) || rule.action === "RESTORE" && key === "roles")
        need(discord_js_1.PermissionFlagsBits.ManageRoles, "Gerenciar Cargos");
    if (rule.action === "REVOKE_UNBAN")
        need(discord_js_1.PermissionFlagsBits.BanMembers, "Banir Membros para reverter este ban");
    if (["RESTORE", "RESTORE_REVOKE"].includes(rule.action) && key === "punishments")
        need(discord_js_1.PermissionFlagsBits.ModerateMembers, "Moderar Membros para restaurar timeout");
    if (key === "honey" && !c.honeyChannel)
        problems.push("Escolher um canal-isca exclusivo");
    return problems;
}
async function diagnose(guild, c) {
    const lines = [];
    for (const [key, r] of Object.entries(c.rules))
        if (r.mode !== "OFF") {
            const missing = await missingForRule(guild, key, r, c);
            if (missing.length)
                lines.push(config_1.RULES[key].label + ": " + missing.join(", "));
        }
    for (const id of [...new Set([...c.trustedRoles, ...c.protectedRoles])])
        if (!await guild.roles.fetch(id).catch(() => null))
            lines.push("Cargo configurado não existe: " + id);
    if (c.honeyChannel) {
        const ch = await guild.channels.fetch(c.honeyChannel).catch(() => null);
        if (!ch)
            lines.push("Canal-isca não existe ou não está acessível.");
        if (c.ignoredChannels.includes(c.honeyChannel) || ch && c.ignoredChannels.includes(ch.parentId))
            lines.push("Canal-isca está nas exceções; a regra não será aplicada nele.");
    }
    return lines;
}
