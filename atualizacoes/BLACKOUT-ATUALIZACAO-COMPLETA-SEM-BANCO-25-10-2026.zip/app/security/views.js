"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.LISTS = exports.limits = exports.button = exports.row = void 0;
exports.select = select;
exports.surface = surface;
exports.home = home;
exports.group = group;
exports.rule = rule;
exports.options = options;
exports.listEditor = listEditor;
exports.reviewView = reviewView;
exports.history = history;
exports.incident = incident;
exports.incidentHome = incidentHome;
exports.denyList = denyList;
exports.diagnostic = diagnostic;
const D = __importStar(require("discord.js"));
const config_1 = require("./config");
const assets_1 = require("./assets");
const diagnostics_1 = require("./diagnostics");
const incidents_1 = require("./incidents");
const row = (...items) => new D.ActionRowBuilder().addComponents(items);
exports.row = row;
const button = (id, label, style = 2, disabled = false) => new D.ButtonBuilder().setCustomId("security:" + id).setLabel(label).setStyle(style).setDisabled(disabled);
exports.button = button;
function select(guild, id, placeholder, items, icon = "raid") { const png = (0, assets_1.emoji)(guild, icon); return (0, exports.row)(new D.StringSelectMenuBuilder().setCustomId("security-select:" + id).setPlaceholder(placeholder).addOptions(items.map(v => ({ ...v, ...(v.emoji ? {} : png ? { emoji: { id: png } } : {}) })))); }
function surface(guild, title, text, components, icon = "raid") {
    const image = (0, assets_1.emoji)(guild, icon), url = image ? `https://cdn.discordapp.com/emojis/${image}.png?size=128&quality=lossless` : "attachment://security-context.png";
    return { flags: D.MessageFlags.IsComponentsV2, content: null, embeds: [], attachments: [], allowedMentions: { parse: [] },
        components: [new D.ContainerBuilder().setAccentColor(0xd71935).addSectionComponents(new D.SectionBuilder().addTextDisplayComponents(new D.TextDisplayBuilder().setContent("## " + (0, incidents_1.clip)(title, 100) + "\n" + text)).setThumbnailAccessory(new D.ThumbnailBuilder().setURL(url))), ...components],
        ...(image ? {} : { files: [new D.AttachmentBuilder((0, assets_1.asset)(icon), { name: "security-context.png" })] }) };
}
const iconFor = (group) => ({ entry: "entry", chat: "chat", team: "team", voice: "voice" }[group] || "raid");
const counts = (c, group) => { const r = Object.entries(c.rules).filter(([k]) => !group || config_1.RULES[k].group === group).map(([, r]) => r); return r.filter(r => r.mode === "ENFORCE").length + " aplicando · " + r.filter(r => r.mode === "OBSERVE").length + " em observação · " + r.filter(r => r.mode === "OFF").length + " desligadas"; };
const limits = (key, rule) => config_1.RULES[key].fields.map(f => f.label + ": **" + rule[f.key] + "**").join("\n");
exports.limits = limits;
async function home(guild, notice = "") {
    const { config } = await (0, config_1.settings)(guild.id), state = await config_1.db.securityState.findUnique({ where: { guildId: guild.id } });
    const active = config.rules.raid.mode === "ENFORCE" && config.rules.raid.action !== "ALERT" && state?.raidUntil && state.raidUntil.getTime() > Date.now();
    const options = Object.entries(config_1.GROUPS).map(([value, label]) => ({ value, label, description: counts(config, value), ...((0, assets_1.emoji)(guild, iconFor(value)) ? { emoji: { id: (0, assets_1.emoji)(guild, iconFor(value)) } } : {}) }));
    options.push(...[{ value: "incidents", label: "Incidentes e contenção", description: "Histórico, resposta e restrição temporária de chats", emoji: { id: (0, assets_1.emoji)(guild, "incidents") } }, { value: "settings", label: "Exceções e diagnóstico", description: "Pessoas, cargos, canais e funcionamento", emoji: { id: (0, assets_1.emoji)(guild, "settings") } }].map(v => v.emoji.id ? v : { value: v.value, label: v.label, description: v.description }));
    return surface(guild, "Central de segurança", "Prepare as regras, observe os sinais e escolha quando aplicar cada proteção.\n\n" + counts(config) + (active ? "\nContenção de entrada até <t:" + Math.floor(state.raidUntil.getTime() / 1000) + ":t>." : "\nNenhuma contenção de entrada em andamento.") + (notice ? "\n\n" + notice : ""), [select(guild, "home", "O que você quer proteger?", options), (0, exports.row)((0, exports.button)("diagnose", "Conferir funcionamento"), (0, exports.button)("logs", "Logs de segurança")), (0, exports.row)((0, exports.button)("area", "Voltar a Equipe e proteção"))]);
}
async function group(guild, key) {
    (0, config_1.assert)(Object.prototype.hasOwnProperty.call(config_1.GROUPS, key), "Categoria desconhecida.");
    const { config } = await (0, config_1.settings)(guild.id);
    return surface(guild, config_1.GROUPS[key], counts(config, key) + "\nEscolha uma regra para conferir limites, resposta e modo de funcionamento.", [select(guild, "rule", "Escolha uma proteção", Object.entries(config_1.RULES).filter(([, s]) => s.group === key).map(([value, spec]) => ({ value, label: spec.label, description: config_1.MODES[config.rules[value].mode] + " · " + spec.description.slice(0, 55) })), iconFor(key)), ...(key === "chat" ? [(0, exports.row)((0, exports.button)("legacy", "Palavras, links e filtros existentes"))] : []), (0, exports.row)((0, exports.button)("home", "Voltar à segurança"))], iconFor(key));
}
async function rule(guild, key, notice = "") {
    const spec = config_1.RULES[key];
    (0, config_1.assert)(spec, "Regra desconhecida.");
    const { config, revision } = await (0, config_1.settings)(guild.id), r = config.rules[key];
    const info = spec.group === "team" || key === "moves" ? "A auditoria confirma o executor depois da ação. Hierarquia pode impedir contenção ou reversão." : key === "voice" ? "O evento não identifica quem moveu o membro. Esta regra registra sem punir a pessoa movida." : key === "raid" ? "A contenção vale para novas entradas; membros anteriores não são expulsos em massa." : key === "honey" ? "Use um canal exclusivo, sinalizado para não receber mensagens normais." : "Pessoas/cargos confiáveis e canais ignorados respeitam as exceções configuradas.";
    return surface(guild, spec.label, spec.description + "\n\nModo: **" + config_1.MODES[r.mode] + "**\n" + (r.mode === "ENFORCE" ? "Resposta" : "Resposta ao ativar") + ": **" + config_1.ACTIONS[r.action] + "**" + ((0, exports.limits)(key, r) ? "\n" + (0, exports.limits)(key, r) : "") + "\n\n" + (notice || info), [
        select(guild, "mode:" + key + ":" + revision, "Escolha o modo", Object.entries(config_1.MODES).map(([value, label]) => ({ value, label, default: value === r.mode })), iconFor(spec.group)),
        select(guild, "action:" + key + ":" + revision, "Escolha a resposta", spec.actions.map(value => ({ value, label: config_1.ACTIONS[value], default: value === r.action })), iconFor(spec.group)),
        (0, exports.row)(...(spec.fields.length ? [(0, exports.button)("limits:" + key + ":" + revision, "Editar limites")] : []), ...(key === "deny" ? [(0, exports.button)("deny:0", "Gerenciar lista bloqueada")] : []), (0, exports.button)("history:0:" + key, "Ver ocorrências")),
        (0, exports.row)((0, exports.button)("settings", "Exceções e canais"), (0, exports.button)("group:" + spec.group, "Voltar à categoria")),
    ], key === "raid" ? "raid" : iconFor(spec.group));
}
exports.LISTS = {
    trustedUsers: { label: "Pessoas e bots confiáveis", text: "Exceções às proteções automáticas. Inclua somente contas autorizadas; um ID de bot pode ser cadastrado antes de adicioná-lo ao servidor.", type: "users" },
    trustedRoles: { label: "Cargos confiáveis", text: "Membros destes cargos ficam fora das proteções automáticas. Todos que conseguem atribuir esses cargos podem conceder esta exceção.", type: "roles" },
    protectedUsers: { label: "Pessoas protegidas", text: "Ban, expulsão e timeout contra estas pessoas acionam as respectivas regras, sem esperar a cota do executor.", type: "users" },
    protectedRoles: { label: "Cargos protegidos", text: "Protege concessões/remoções e membros. Depois de um ban, cargos do alvo só são considerados quando há cache ou snapshot recente confiável.", type: "roles" },
    ignoredChannels: { label: "Canais ignorados", text: "Exceção para chat e movimentação observada em call. Categorias incluem os canais filhos; não desliga auditoria de ações da equipe.", type: "channels" },
    protectedChannels: { label: "Permissões de canais protegidos", text: "A regra Cargos e permissões também revisa alterações de acesso nestes canais e categorias. A reversão exige dados anteriores completos na auditoria e nenhuma alteração posterior.", type: "channels" },
    lockChannels: { label: "Chats para contenção", text: "Até 25 canais de texto. A restrição temporária exige revisão e prazo; permissões anteriores são guardadas para restauração.", type: "channels" },
    honeyChannel: { label: "Canal-isca exclusivo", text: "Escolha um canal que não deva receber mensagens normais e sinalize isso à comunidade. O bot não cria nem esconde o canal automaticamente.", type: "channels" },
};
async function options(guild) {
    return surface(guild, "Exceções e diagnóstico", "Ajuste o alcance das regras. Alterações exigem Administrador do Discord ou o proprietário; cada mudança abre uma revisão antes de salvar.", [select(guild, "settings", "O que deseja configurar?", [...Object.entries(exports.LISTS).map(([value, s]) => ({ value, label: s.label })), { value: "invites", label: "Convites autorizados" }, { value: "diagnose", label: "Conferir funcionamento" }], "settings"), (0, exports.row)((0, exports.button)("export", "Exportar configurações"), (0, exports.button)("home", "Voltar à segurança"))], "settings");
}
async function listEditor(guild, key) {
    const spec = exports.LISTS[key];
    (0, config_1.assert)(spec, "Lista desconhecida.");
    const { config, revision } = await (0, config_1.settings)(guild.id), selected = key === "honeyChannel" ? config.honeyChannel ? [config.honeyChannel] : [] : config[key];
    let menu;
    if (spec.type === "users")
        menu = new D.UserSelectMenuBuilder().setCustomId("security-select:list:" + key + ":" + revision).setPlaceholder("Escolha as pessoas ou bots").setMinValues(0).setMaxValues(25).setDefaultUsers(selected);
    else if (spec.type === "roles")
        menu = new D.RoleSelectMenuBuilder().setCustomId("security-select:list:" + key + ":" + revision).setPlaceholder("Escolha os cargos").setMinValues(0).setMaxValues(25).setDefaultRoles(selected);
    else
        menu = new D.ChannelSelectMenuBuilder().setCustomId("security-select:list:" + key + ":" + revision).setPlaceholder("Escolha os canais").setMinValues(0).setMaxValues(key === "honeyChannel" ? 1 : 25).setDefaultChannels(selected).addChannelTypes(...(["ignoredChannels", "protectedChannels"].includes(key) ? [D.ChannelType.GuildText, D.ChannelType.GuildAnnouncement, D.ChannelType.GuildCategory, D.ChannelType.GuildVoice, D.ChannelType.GuildStageVoice] : [D.ChannelType.GuildText, D.ChannelType.GuildAnnouncement]));
    const mentions = selected.map((id) => spec.type === "roles" ? `<@&${id}>` : spec.type === "channels" ? `<#${id}>` : `<@${id}>`).join(", ");
    return surface(guild, spec.label, spec.text + "\n\nSalvo: " + (mentions || "Nenhum") + "\nSeleção vazia limpa esta lista após confirmação.", [(0, exports.row)(menu), (0, exports.row)(...(spec.type === "users" ? [(0, exports.button)("ids:" + key + ":" + revision, "Informar IDs")] : []), (0, exports.button)("settings", "Voltar às exceções"))], "settings");
}
async function reviewView(guild, item) {
    const p = JSON.parse(item.payloadJson), text = p.summary || "Confira a alteração e confirme para aplicar.";
    return surface(guild, "Conferir alteração", (0, incidents_1.clip)(text, 2800) + "\n\nSomente **Confirmar** aplica a mudança. Esta revisão pertence a você e expira em 20 minutos.", [(0, exports.row)((0, exports.button)("confirm:" + item.id, "Confirmar", ["LOCK", "DENY_ADD"].includes(item.kind) ? 4 : 1), (0, exports.button)(p.returnTo || "home", "Cancelar"))], "settings");
}
const labels = incidents_1.STATUS;
const LOCK_LABELS = { ACTIVE: "Restrição ativa", PREPARING: "Preparando restrição", UNCERTAIN: "Estado a conferir", ERROR: "Falha na restauração", CONFLICT: "Alteração da equipe a revisar" };
async function history(guild, page = 0, key) {
    const where = { guildId: guild.id, ...(key ? { rule: key } : {}) }, total = await config_1.db.securityIncident.count({ where });
    page = Math.max(0, Math.min(page, Math.max(0, Math.ceil(total / 8) - 1)));
    const rows = await config_1.db.securityIncident.findMany({ where, orderBy: { createdAt: "desc" }, skip: page * 8, take: 8 });
    const controls = rows.length ? [select(guild, "incident", "Escolha uma ocorrência", rows.map((r) => ({ value: r.id, label: (0, incidents_1.clip)((config_1.RULES[r.rule]?.label || "Operação da equipe") + " · " + (labels[r.status] || r.status), 100), description: (0, incidents_1.clip)(r.summary, 100) })), "incidents")] : [];
    return surface(guild, key ? "Ocorrências · " + config_1.RULES[key].label : "Histórico de segurança", (rows.length ? rows.map((r) => "**" + (config_1.RULES[r.rule]?.label || "Operação da equipe") + "** · " + (labels[r.status] || r.status) + "\n<t:" + Math.floor(r.createdAt.getTime() / 1000) + ":f> · " + (0, incidents_1.clip)(r.summary, 100)).join("\n\n") : "Nenhuma ocorrência registrada neste histórico.") + "\n\nPágina " + (page + 1), [...controls, (0, exports.row)((0, exports.button)("history:" + (page - 1) + (key ? ":" + key : ""), "Anterior", 2, page === 0), (0, exports.button)("history:" + (page + 1) + (key ? ":" + key : ""), "Próxima", 2, (page + 1) * 8 >= total)), (0, exports.row)((0, exports.button)(key ? "rule:" + key : "incidents", "Voltar"))], "incidents");
}
async function incident(guild, id) {
    const p = await config_1.db.securityIncident.findFirst({ where: { id, guildId: guild.id } });
    (0, config_1.assert)(p, "Ocorrência não pertence a este servidor.");
    const out = JSON.parse(p.resultJson), d = JSON.parse(p.detailsJson);
    return surface(guild, config_1.RULES[p.rule]?.label || "Operação da equipe", (0, incidents_1.clip)(p.summary) + "\n\nEstado: **" + (labels[p.status] || p.status) + "**\nModo: " + (config_1.MODES[p.mode] || p.mode) + "\nResposta: " + (config_1.ACTIONS[p.action] || p.action) + "\nExecutor: " + (p.actorId ? `<@${p.actorId}>` : "Não identificado") + (p.targetId ? "\nAlvo: <@" + p.targetId + ">" : "") + (d.auditId ? "\nAuditoria: `" + d.auditId + "`" : "") + (d.targetId && !p.targetId ? "\nAlvo auditado: " + (0, incidents_1.targetLabel)(d) : "") + ((0, incidents_1.evidence)(d) ? "\n\n" + (0, incidents_1.clip)((0, incidents_1.evidence)(d), 900) : "") + "\n\n" + (0, incidents_1.clip)([...(out.done || []), ...(out.skipped || []), ...(out.errors || [])].join("\n") || "Ação ainda não confirmada; confira o alvo antes de repetir.", 1500) + "\n\nEncaminhamento do log: **" + (incidents_1.DELIVERY[p.deliveryStatus] || p.deliveryStatus) + "**" + (p.deliveryError ? "\n" + p.deliveryError : ""), [(0, exports.row)((0, exports.button)("mirror:" + p.id, "Revisar reenvio do log"), (0, exports.button)("history:0", "Voltar ao histórico"))], "incidents");
}
async function incidentHome(guild, notice = "") {
    const { config } = await (0, config_1.settings)(guild.id), state = await config_1.db.securityState.findUnique({ where: { guildId: guild.id } }), until = config.rules.raid.mode === "ENFORCE" && config.rules.raid.action !== "ALERT" && state?.raidUntil && state.raidUntil.getTime() > Date.now();
    const locks = await config_1.db.securityChannelLock.findMany({ where: { guildId: guild.id, status: { in: ["ACTIVE", "PREPARING", "UNCERTAIN", "ERROR", "CONFLICT"] } }, take: 25 });
    return surface(guild, "Incidentes e contenção", (notice || "Consulte o histórico ou prepare uma restrição temporária dos chats escolhidos. Nenhum canal é alterado ao abrir esta tela.") + "\n\nEntrada: " + (until ? "em contenção até <t:" + Math.floor(state.raidUntil.getTime() / 1000) + ":t>" : "sem contenção ativa") + "\nChats com estado pendente: " + locks.length + (locks.length ? "\n" + locks.slice(0, 8).map((l) => `<#${l.channelId}> · ${LOCK_LABELS[l.status] || l.status}`).join("\n") : ""), [(0, exports.row)((0, exports.button)("history:0", "Histórico de segurança"), (0, exports.button)("lock", "Restringir chats temporariamente", 4)), (0, exports.row)((0, exports.button)("release", locks.length && locks.every((l) => l.status === "CONFLICT") ? "Concluir revisão dos conflitos" : "Revisar liberação dos chats", 2, !locks.length), (0, exports.button)("end-raid", "Encerrar contenção de entrada", 2, !until)), (0, exports.row)((0, exports.button)("list:lockChannels", "Escolher chats"), (0, exports.button)("home", "Voltar à segurança"))], "incidents");
}
async function denyList(guild, page = 0) {
    const where = { guildId: guild.id }, total = await config_1.db.securityDenyEntry.count({ where });
    page = Math.max(0, Math.min(page, Math.max(0, Math.ceil(total / 10) - 1)));
    const rows = await config_1.db.securityDenyEntry.findMany({ where, orderBy: { createdAt: "desc" }, skip: page * 10, take: 10 }), { revision } = await (0, config_1.settings)(guild.id);
    return surface(guild, "Lista de entrada bloqueada", "A regra Lista de entrada bloqueada define se a nova entrada será apenas registrada ou expulsa. Adicionar à lista não expulsa quem já está no servidor.\n\n" + (rows.map((r) => `<@${r.userId}> · ${(0, incidents_1.clip)(r.reason, 80)}`).join("\n") || "Nenhum usuário cadastrado.") + "\nPágina " + (page + 1), [...(rows.length ? [select(guild, "deny-remove:" + revision, "Escolha um cadastro para retirar da lista", rows.map((r) => ({ value: r.id, label: r.userId, description: (0, incidents_1.clip)(r.reason, 100) })), "entry")] : []), (0, exports.row)((0, exports.button)("deny-add:" + revision, "Adicionar ID"), (0, exports.button)("deny:" + (page - 1), "Anterior", 2, page === 0), (0, exports.button)("deny:" + (page + 1), "Próxima", 2, (page + 1) * 10 >= total)), (0, exports.row)((0, exports.button)("rule:deny", "Voltar à regra de entrada"))], "entry");
}
async function diagnostic(guild) {
    const { config } = await (0, config_1.settings)(guild.id, true), issues = await (0, diagnostics_1.diagnose)(guild, config), failed = await config_1.db.securityIncident.count({ where: { guildId: guild.id, status: { in: ["FAILED", "PARTIAL", "UNCERTAIN"] } } });
    return surface(guild, "Conferir funcionamento", (issues.length ? "Pendências encontradas:\n" + issues.slice(0, 12).map(s => "• " + s).join("\n") : "Nenhuma pendência detectada nas permissões gerais das regras configuradas.") + "\n\nOcorrências com resposta parcial ou não confirmada: **" + failed + "**.\n\nA hierarquia e as permissões de cada canal/alvo são revalidadas na ação. Verifique Server Members e Message Content no portal quando exigidos; auditoria exige Ver Registro de Auditoria. O diagnóstico não executa punições.", [(0, exports.row)((0, exports.button)("diagnose", "Atualizar diagnóstico"), (0, exports.button)("history:0", "Ver histórico")), (0, exports.row)((0, exports.button)("logs", "Destinos dos logs"), (0, exports.button)("home", "Voltar à segurança"))], "settings");
}
