"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dangerous = exports.DANGEROUS = void 0;
exports.getMember = getMember;
exports.immutable = immutable;
exports.trusted = trusted;
exports.ignoredChannel = ignoredChannel;
exports.revoke = revoke;
exports.memberAction = memberAction;
exports.merge = merge;
const discord_js_1 = require("discord.js");
const config_1 = require("./config");
const incidents_1 = require("./incidents");
exports.DANGEROUS = [discord_js_1.PermissionFlagsBits.Administrator, discord_js_1.PermissionFlagsBits.ManageGuild, discord_js_1.PermissionFlagsBits.ManageRoles, discord_js_1.PermissionFlagsBits.ManageChannels, discord_js_1.PermissionFlagsBits.BanMembers, discord_js_1.PermissionFlagsBits.KickMembers, discord_js_1.PermissionFlagsBits.ModerateMembers, discord_js_1.PermissionFlagsBits.ManageWebhooks, discord_js_1.PermissionFlagsBits.ManageMessages, discord_js_1.PermissionFlagsBits.MoveMembers, discord_js_1.PermissionFlagsBits.MuteMembers, discord_js_1.PermissionFlagsBits.DeafenMembers];
const dangerous = (role) => exports.DANGEROUS.some(bit => role.permissions?.has(bit));
exports.dangerous = dangerous;
async function getMember(guild, id) {
    try {
        return await guild.members.fetch({ user: id, force: true });
    }
    catch (e) {
        if (e?.code === 10007)
            return null;
        throw e;
    }
}
function immutable(guild, id) { return id === guild.ownerId || id === guild.client.user?.id; }
function trusted(guild, member, c) { return !!member && (immutable(guild, member.id) || c.trustedUsers.includes(member.id) || member.roles?.cache?.some((r) => c.trustedRoles.includes(r.id))); }
function ignoredChannel(channel, c) {
    let ch = channel;
    for (let n = 0; ch && n < 4; n++, ch = ch.parent || ch.guild?.channels?.cache?.get(ch.parentId))
        if (c.ignoredChannels.includes(ch.id))
            return true;
    return false;
}
async function revoke(guild, actorId) {
    const out = (0, incidents_1.result)();
    if (immutable(guild, actorId)) {
        out.skipped.push("Proprietário e próprio bot nunca são contidos automaticamente.");
        return out;
    }
    const m = await getMember(guild, actorId);
    if (!m) {
        out.skipped.push("Executor já saiu do servidor.");
        return out;
    }
    if (!m.manageable) {
        out.errors.push("Executor acima do bot na hierarquia; não foi possível contê-lo.");
        return out;
    }
    const candidates = [...m.roles.cache.values()].filter((r) => r.id !== guild.id && (0, exports.dangerous)(r));
    const roles = candidates.filter(r => !r.managed && r.editable);
    if (roles.length) {
        try {
            await m.roles.remove(roles.map(r => r.id), "BLACKOUT · proteção automática, executor confirmado pela auditoria");
            out.done.push("Cargos perigosos removidos do executor: " + roles.map(r => `<@&${r.id}>`).join(", "));
        }
        catch (e) {
            out.errors.push((0, incidents_1.safeError)(e));
        }
    }
    const blocked = candidates.filter(r => r.managed || !r.editable);
    if (blocked.length)
        out.errors.push("Cargos gerenciados ou acima do bot não puderam ser retirados: " + blocked.map(r => `<@&${r.id}>`).join(", "));
    if (!candidates.length)
        out.skipped.push("Executor sem cargos perigosos removíveis.");
    return out;
}
async function memberAction(guild, userId, action, minutes = 10) {
    const out = (0, incidents_1.result)();
    if (immutable(guild, userId)) {
        out.skipped.push("Proprietário e próprio bot preservados.");
        return out;
    }
    const m = await getMember(guild, userId);
    if (!m) {
        out.skipped.push("Membro já saiu do servidor.");
        return out;
    }
    try {
        if (action === "KICK") {
            (0, config_1.assert)(m.kickable, "Membro fora da hierarquia de expulsão do bot.");
            await m.kick("BLACKOUT · regra de proteção de entrada");
            out.done.push("Membro expulso pela regra de entrada.");
        }
        else if (action === "TIMEOUT") {
            (0, config_1.assert)(!m.user.bot && m.moderatable, "O bot não pode silenciar este membro.");
            const until = Date.now() + minutes * 60000;
            if ((m.communicationDisabledUntilTimestamp || 0) >= until - 1000)
                out.skipped.push("Membro já possui um castigo igual ou mais longo; prazo preservado.");
            else {
                await m.timeout(minutes * 60000, "BLACKOUT · proteção automática configurada");
                out.done.push("Membro silenciado por " + minutes + " minutos.");
            }
        }
    }
    catch (e) {
        out.errors.push(e?.name === "SecurityError" ? e.message : (0, incidents_1.safeError)(e));
    }
    return out;
}
function merge(a, b) { a.done.push(...b.done); a.skipped.push(...b.skipped); a.errors.push(...b.errors); return a; }
