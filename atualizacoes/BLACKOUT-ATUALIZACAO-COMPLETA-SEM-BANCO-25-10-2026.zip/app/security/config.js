"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GROUPS = exports.RULES = exports.ACTIONS = exports.MODES = exports.SecurityError = exports.db = void 0;
exports.assert = assert;
exports.object = object;
exports.ids = ids;
exports.normalize = normalize;
exports.clearConfig = clearConfig;
exports.settings = settings;
exports.save = save;
exports.editRule = editRule;
exports.exclusive = exclusive;
const prisma_1 = require("../database/prisma");
exports.db = prisma_1.prisma;
class SecurityError extends Error {
}
exports.SecurityError = SecurityError;
function assert(value, message) {
    if (!value)
        throw new SecurityError(message);
}
exports.MODES = { OFF: "Desligado", OBSERVE: "Observar e registrar", ENFORCE: "Aplicar proteção" };
exports.ACTIONS = {
    LOCK: "Restringir chats temporariamente", RELEASE: "Restaurar permissões dos chats", ALERT: "Somente registrar", DELETE: "Apagar mensagem", TIMEOUT: "Silenciar temporariamente",
    KICK: "Expulsar da entrada", DELETE_WEBHOOK: "Apagar mensagem e excluir webhook",
    REVOKE: "Retirar cargos perigosos do executor", RESTORE: "Reverter alteração confirmada",
    RESTORE_REVOKE: "Reverter e conter executor", REVOKE_UNBAN: "Conter executor e desbanir o alvo",
};
const number = (key, label, min, max, value) => ({ key, label, min, max, value });
const count = (n = 5) => number("limit", "Quantidade para detectar", 2, 100, n);
const window = (n = 10) => number("windowSeconds", "Janela em segundos", 2, 3600, n);
const duration = () => number("durationMinutes", "Silenciamento em minutos", 1, 1440, 10);
exports.RULES = {
    raid: { label: "Anti-Raid", group: "entry", description: "Detectar entradas em massa e proteger novas entradas durante a contenção", action: "TIMEOUT", actions: ["ALERT", "TIMEOUT", "KICK"], fields: [count(6), window(10), number("activeMinutes", "Contenção em minutos", 1, 60, 10), duration()] },
    bots: { label: "Entrada de bots", group: "entry", description: "Revisar ou expulsar bots que não estejam autorizados nas exceções", action: "KICK", actions: ["ALERT", "KICK"], fields: [] },
    age: { label: "Idade mínima da conta", group: "entry", description: "Proteger a entrada de contas recém-criadas; não comprova identidade", action: "TIMEOUT", actions: ["ALERT", "TIMEOUT", "KICK"], fields: [number("minAgeDays", "Idade mínima em dias", 1, 365, 7), duration()] },
    deny: { label: "Lista de entrada bloqueada", group: "entry", description: "Impedir a permanência dos usuários cadastrados nesta lista", action: "KICK", actions: ["ALERT", "KICK"], fields: [] },
    mentions: { label: "Excesso de menções", group: "chat", description: "Limitar menções a pessoas, cargos e everyone/here", action: "DELETE", actions: ["ALERT", "DELETE", "TIMEOUT"], fields: [number("limit", "Máximo de menções", 1, 100, 8), duration()] },
    text: { label: "Textos e linhas excessivos", group: "chat", description: "Limitar tamanho e quantidade de linhas por mensagem", action: "DELETE", actions: ["ALERT", "DELETE", "TIMEOUT"], fields: [number("limit", "Máximo de caracteres", 100, 4000, 2000), number("lines", "Máximo de linhas", 3, 100, 25), duration()] },
    invites: { label: "Convites do Discord", group: "chat", description: "Detectar convites com ou sem https; códigos autorizados são exceções", action: "DELETE", actions: ["ALERT", "DELETE", "TIMEOUT"], fields: [duration()] },
    flood: { label: "Muitas mensagens em sequência", group: "chat", description: "Limitar volume por membro e canal dentro da janela definida", action: "DELETE", actions: ["ALERT", "DELETE", "TIMEOUT"], fields: [count(6), window(5), duration()] },
    duplicates: { label: "Mensagens repetidas", group: "chat", description: "Detectar repetição do mesmo texto por membro e canal", action: "DELETE", actions: ["ALERT", "DELETE", "TIMEOUT"], fields: [count(3), window(30), duration()] },
    webhooks: { label: "Flood por webhook", group: "chat", description: "Detectar excesso de mensagens do mesmo webhook no canal", action: "DELETE", actions: ["ALERT", "DELETE", "DELETE_WEBHOOK"], fields: [count(5), window(10)] },
    honey: { label: "Canal-isca · HoneyPot", group: "chat", description: "Detectar mensagens de membros num canal exclusivo que não deve ser usado", action: "DELETE", actions: ["ALERT", "DELETE", "TIMEOUT"], fields: [duration()] },
    bans: { label: "Anti Ban", group: "team", description: "Detectar bans de membros protegidos e excesso por executor confirmado", action: "REVOKE", actions: ["ALERT", "REVOKE", "REVOKE_UNBAN"], fields: [count(3), window(60)] },
    kicks: { label: "Limite de expulsões", group: "team", description: "Conter expulsões em massa ou contra membros protegidos", action: "REVOKE", actions: ["ALERT", "REVOKE"], fields: [count(3), window(60)] },
    roles: { label: "Cargos e permissões", group: "team", description: "Revisar concessões sensíveis e alterações de permissões pela auditoria", action: "RESTORE", actions: ["ALERT", "RESTORE", "REVOKE", "RESTORE_REVOKE"], fields: [] },
    punishments: { label: "Castigos de membros protegidos", group: "team", description: "Revisar timeout contra pessoas e cargos protegidos", action: "RESTORE", actions: ["ALERT", "RESTORE", "REVOKE", "RESTORE_REVOKE"], fields: [] },
    destruction: { label: "Alterações destrutivas em massa", group: "team", description: "Detectar exclusões de canais/cargos e criação de webhooks em sequência", action: "REVOKE", actions: ["ALERT", "REVOKE"], fields: [count(3), window(30)] },
    vanity: { label: "Alteração da URL do servidor", group: "team", description: "Registrar alteração confirmada da URL personalizada; não promete recuperá-la", action: "ALERT", actions: ["ALERT"], fields: [] },
    voice: { label: "Movimentação excessiva em call", group: "voice", description: "Registrar movimentação sem punir alguém cujo executor é desconhecido", action: "ALERT", actions: ["ALERT"], fields: [count(6), window(20)] },
    moves: { label: "Abuso de movimentação pela equipe", group: "voice", description: "Conter executor confirmado de muitas movimentações/desconexões", action: "REVOKE", actions: ["ALERT", "REVOKE"], fields: [count(5), window(30)] },
};
exports.GROUPS = { entry: "Entrada e Anti-Raid", chat: "Chat e conteúdo", team: "Anti Ban e ações da equipe", voice: "Proteção de calls" };
function object(raw) {
    try {
        const o = typeof raw === "string" ? JSON.parse(raw) : raw;
        return o && typeof o === "object" && !Array.isArray(o) ? o : {};
    }
    catch {
        return {};
    }
}
function ids(raw) { return Array.isArray(raw) ? [...new Set(raw.filter(v => typeof v === "string" && /^\d{15,25}$/.test(v)))].slice(0, 25) : []; }
function normalize(raw) {
    const o = object(raw), rules = {};
    for (const [key, spec] of Object.entries(exports.RULES)) {
        const r = object(o.rules?.[key]);
        rules[key] = { mode: Object.prototype.hasOwnProperty.call(exports.MODES, r.mode) ? r.mode : "OFF", action: spec.actions.includes(r.action) ? r.action : spec.action };
        for (const f of spec.fields)
            rules[key][f.key] = Number.isInteger(r[f.key]) && r[f.key] >= f.min && r[f.key] <= f.max ? r[f.key] : f.value;
    }
    return { rules, ...Object.fromEntries(["trustedUsers", "trustedRoles", "protectedUsers", "protectedRoles", "ignoredChannels", "protectedChannels", "lockChannels"].map(k => [k, ids(o[k])])), honeyChannel: typeof o.honeyChannel === "string" && /^\d{15,25}$/.test(o.honeyChannel) ? o.honeyChannel : null, allowedInvites: Array.isArray(o.allowedInvites) ? [...new Set(o.allowedInvites.filter((v) => typeof v === "string" && /^[\w-]{2,100}$/.test(v)))].slice(0, 25) : [] };
}
const cache = new Map();
function clearConfig(id) {
    if (id)
        cache.delete(id);
    else
        cache.clear();
}
async function settings(guildId, fresh = false) {
    const c = cache.get(guildId);
    if (!fresh && c && c.until > Date.now())
        return c.value;
    const r = await exports.db.securitySettings.findUnique({ where: { guildId } });
    const value = { config: normalize(r?.configJson), revision: r?.revision ?? 0 };
    if (cache.size >= 500)
        cache.delete(cache.keys().next().value);
    cache.set(guildId, { until: Date.now() + 1500, value });
    return value;
}
async function save(guildId, revision, config) {
    await exports.db.securitySettings.upsert({ where: { guildId }, create: { guildId, configJson: "{}" }, update: {} });
    const n = await exports.db.securitySettings.updateMany({ where: { guildId, revision }, data: { configJson: JSON.stringify(normalize(config)), revision: { increment: 1 } } });
    assert(n.count === 1, "A configuração mudou. Abra a regra e revise novamente.");
    clearConfig(guildId);
    return settings(guildId, true);
}
function editRule(config, key, patch) {
    const spec = exports.RULES[key];
    assert(Object.prototype.hasOwnProperty.call(exports.RULES, key), "Regra desconhecida.");
    const next = normalize(JSON.parse(JSON.stringify(config)));
    for (const [k, v] of Object.entries(patch)) {
        if (k === "mode")
            assert(Object.prototype.hasOwnProperty.call(exports.MODES, String(v)), "Escolha um modo válido.");
        else if (k === "action")
            assert(spec.actions.includes(String(v)), "Escolha uma resposta disponível para esta regra.");
        else {
            const f = spec.fields.find(f => f.key === k);
            assert(f && Number.isInteger(v) && Number(v) >= f.min && Number(v) <= f.max, "Valor fora dos limites permitidos.");
        }
        next.rules[key][k] = v;
    }
    return normalize(next);
}
const queues = new Map();
async function exclusive(key, fn) {
    const p = queues.get(key) ?? Promise.resolve(), work = p.catch(() => null).then(fn);
    queues.set(key, work);
    try {
        return await work;
    }
    finally {
        if (queues.get(key) === work)
            queues.delete(key);
    }
}
