"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.show = show;
exports.guard = guard;
exports.open = open;
exports.execute = execute;
const D = __importStar(require("discord.js"));
const node_crypto_1 = require("node:crypto");
const config_1 = require("./config");
const reviews_1 = require("./reviews");
const diagnostics_1 = require("./diagnostics");
const assets_1 = require("./assets");
const panelInteraction_1 = require("../utils/panelInteraction");
const incidents_1 = require("./incidents");
const V = __importStar(require("./views"));
const L = __importStar(require("./locks"));
async function show(i, p) { return (0, panelInteraction_1.refreshPanel)(i, p); }
async function guard(i, fn) {
    try {
        await (0, reviews_1.authorize)(i);
        return await fn();
    }
    catch (e) {
        if (!(e instanceof config_1.SecurityError))
            console.error("[blackout-security] interação:", e?.code || e?.name || "falha");
        const p = { content: e instanceof config_1.SecurityError ? e.message : "Não foi possível concluir. Confira o estado e o histórico antes de repetir.", flags: D.MessageFlags.Ephemeral };
        return (i.deferred || i.replied ? i.followUp(p) : i.reply(p)).catch(() => null);
    }
}
function form(id, title, fields) {
    return new D.ModalBuilder().setCustomId("security-form:" + id).setTitle(title.slice(0, 45)).addComponents(...fields.map(f => V.row(new D.TextInputBuilder().setCustomId(f.id).setLabel(f.label.slice(0, 45)).setStyle(f.paragraph ? D.TextInputStyle.Paragraph : D.TextInputStyle.Short).setRequired(f.required !== false).setMaxLength(f.max || 100).setValue(f.value || ""))));
}
const integer = (v) => { (0, config_1.assert)(/^\d+$/.test(v.trim()), "Use um número inteiro, sem unidades ou casas decimais."); return Number(v); };
async function configReview(i, next, summary, returnTo, revision, changedRule) {
    const r = await (0, reviews_1.review)(i, "CONFIG", { config: (0, config_1.normalize)(next), summary, returnTo, changedRule }, revision);
    return show(i, await V.reviewView(i.guild, r));
}
async function open(i) { return guard(i, async () => { await (0, panelInteraction_1.deferPanel)(i); await (0, assets_1.prepare)(i.guild); return show(i, await V.home(i.guild)); }); }
async function confirmed(i, id) {
    return (0, config_1.exclusive)("security-config:" + i.guild.id, async () => {
        await (0, reviews_1.authorize)(i, true);
        const pending = await (0, reviews_1.getReview)(i, id), p = JSON.parse(pending.payloadJson), g = i.guild;
        if (pending.kind === "CONFIG") {
            const next = (0, config_1.normalize)(p.config);
            for (const [key, r] of Object.entries(next.rules))
                if ((!p.changedRule || p.changedRule === key) && r.mode === "ENFORCE") {
                    const missing = await (0, diagnostics_1.missingForRule)(g, key, r, next);
                    (0, config_1.assert)(!missing.length, "Antes de aplicar " + config_1.RULES[key].label + ": " + missing.join(", ") + ". Você pode usar observação enquanto corrige as pendências.");
                }
        }
        const r = await (0, reviews_1.consume)(i, id);
        if (r.kind === "CONFIG") {
            const before = await (0, config_1.settings)(g.id, true), next = (0, config_1.normalize)(p.config);
            await (0, config_1.save)(g.id, r.configRevision, next);
            if (before.config.rules.raid.mode !== next.rules.raid.mode || next.rules.raid.mode === "OFF")
                await config_1.db.securityState.upsert({ where: { guildId: g.id }, create: { guildId: g.id }, update: { raidUntil: null } });
            await (0, incidents_1.operation)(g, i.user.id, "Configuração de segurança atualizada após revisão.", { reviewId: r.id, summary: p.summary }).catch(() => console.error("[blackout-security] configuração salva; falha no registro do histórico."));
            return route(i, p.returnTo || "home", "Alteração salva. O estado abaixo já mostra a configuração vigente.");
        }
        if (r.kind === "DENY_ADD") {
            await config_1.db.securityDenyEntry.upsert({ where: { guildId_userId: { guildId: g.id, userId: p.userId } }, create: { id: (0, node_crypto_1.randomUUID)(), guildId: g.id, userId: p.userId, reason: p.reason, createdById: i.user.id }, update: { reason: p.reason, createdById: i.user.id } });
            await (0, incidents_1.operation)(g, i.user.id, "Cadastro adicionado à lista de entrada bloqueada.", { userId: p.userId, reason: p.reason });
            return show(i, await V.denyList(g));
        }
        if (r.kind === "ACK_CONFLICT") {
            const ids = p.lockIds;
            (0, config_1.assert)(Array.isArray(ids) && ids.length <= 25, "Revisão de conflitos inválida.");
            await config_1.db.securityChannelLock.updateMany({ where: { guildId: g.id, id: { in: ids }, status: "CONFLICT" }, data: { status: "RELEASED", lastError: "Equipe confirmou a revisão manual e preservou as permissões atuais." } });
            await (0, incidents_1.operation)(g, i.user.id, "Revisão manual de conflitos concluída; permissões atuais preservadas.", { reviewId: r.id, lockIds: ids });
            return show(i, await V.incidentHome(g, "Registros de conflito encerrados. Nenhuma permissão foi alterada; as regras atuais serão a referência de uma futura contenção."));
        }
        if (r.kind === "DENY_REMOVE") {
            await config_1.db.securityDenyEntry.deleteMany({ where: { id: p.entryId, guildId: g.id } });
            await (0, incidents_1.operation)(g, i.user.id, "Cadastro retirado da lista de entrada bloqueada.", { entryId: p.entryId });
            return show(i, await V.denyList(g));
        }
        if (r.kind === "END_RAID") {
            await config_1.db.securityState.upsert({ where: { guildId: g.id }, create: { guildId: g.id }, update: { raidUntil: null } });
            await (0, incidents_1.operation)(g, i.user.id, "Contenção de novas entradas encerrada pela equipe.");
            return show(i, await V.incidentHome(g, "Contenção encerrada. Silenciamentos anteriores mantêm os prazos que já tinham."));
        }
        if (r.kind === "LOCK" || r.kind === "RELEASE") {
            const incident = await (0, incidents_1.record)(g, { eventKey: "review:" + r.id, rule: "operation", mode: "ENFORCE", action: r.kind, actorId: i.user.id, summary: p.summary, revision: r.configRevision }, () => r.kind === "LOCK" ? L.lock(g, p.channelIds, i.user.id, p.minutes) : L.releaseMany(g, p.channelIds));
            return incident.id ? show(i, await V.incident(g, incident.id)) : show(i, await V.incidentHome(g));
        }
        if (r.kind === "MIRROR") {
            const incident = await config_1.db.securityIncident.findFirst({ where: { id: p.incidentId, guildId: g.id } });
            (0, config_1.assert)(incident && incident.deliveryStatus !== "SENDING", "O envio deste log já está em andamento.");
            await (0, incidents_1.mirror)(g, incident.id, true);
            return show(i, await V.incident(g, incident.id));
        }
        throw new config_1.SecurityError("Revisão desconhecida. Abra a central novamente.");
    });
}
async function route(i, value, notice = "") {
    const [name, a, b] = value.split(":");
    const g = i.guild;
    if (name === "home")
        return show(i, await V.home(g, notice));
    if (name === "group")
        return show(i, await V.group(g, a));
    if (name === "rule")
        return show(i, await V.rule(g, a, notice));
    if (name === "settings")
        return show(i, await V.options(g));
    if (name === "list")
        return show(i, await V.listEditor(g, a));
    if (name === "history") {
        (0, config_1.assert)(!b || !!config_1.RULES[b], "Regra desconhecida.");
        return show(i, await V.history(g, Number(a) || 0, b));
    }
    if (name === "incident")
        return show(i, await V.incident(g, a));
    if (name === "incidents")
        return show(i, await V.incidentHome(g, notice));
    if (name === "deny")
        return show(i, await V.denyList(g, Number(a) || 0));
    if (name === "diagnose")
        return show(i, await V.diagnostic(g));
    if (name === "area")
        return show(i, await require("../utils/admPanel").buildAdmSectionPanel(g, "seguranca"));
    if (name === "logs")
        return require("../components/buttons/admLogsMenu").renderLogsMenu(i);
    if (name === "legacy")
        return require("../components/buttons/admModerationMenu").renderFiltersMenu(i);
    return false;
}
async function execute(i) {
    return guard(i, async () => {
        const [prefix, name, a, b] = i.customId.split(":"), g = i.guild;
        const launchesModal = prefix === "security" && ["limits", "ids", "invites", "deny-add", "lock"].includes(name);
        if (!launchesModal)
            await (0, panelInteraction_1.deferPanel)(i);
        if (prefix === "security") {
            if (name === "confirm")
                return confirmed(i, a);
            const routed = await route(i, [name, a, b].filter(v => v !== undefined).join(":"));
            if (routed !== false)
                return routed;
            if (launchesModal) {
                await (0, reviews_1.authorize)(i, true);
                const { config, revision } = await (0, config_1.settings)(g.id, true);
                if (name === "limits") {
                    const spec = config_1.RULES[a];
                    (0, config_1.assert)(spec && revision === Number(b), "A regra mudou. Abra novamente.");
                    return i.showModal(form("limits:" + a + ":" + revision, spec.label, spec.fields.map(f => ({ id: f.key, label: f.label + " (" + f.min + "–" + f.max + ")", value: String(config.rules[a][f.key]) }))));
                }
                if (name === "ids") {
                    (0, config_1.assert)(["trustedUsers", "protectedUsers"].includes(a) && revision === Number(b), "Esta lista mudou. Abra novamente.");
                    return i.showModal(form("ids:" + a + ":" + revision, V.LISTS[a].label, [{ id: "value", label: "Um ID por linha; vazio limpa a lista", paragraph: true, required: false, max: 1000, value: config[a].join("\n") }]));
                }
                if (name === "invites")
                    return i.showModal(form("invites:" + revision, "Convites autorizados", [{ id: "value", label: "Um código por linha; vazio limpa", paragraph: true, required: false, max: 2600, value: config.allowedInvites.join("\n") }]));
                if (name === "deny-add") {
                    (0, config_1.assert)(revision === Number(a), "A configuração mudou. Abra a lista novamente.");
                    return i.showModal(form("deny:" + revision, "Adicionar à lista bloqueada", [{ id: "user", label: "ID da pessoa ou bot", max: 25 }, { id: "reason", label: "Motivo do bloqueio de entrada", paragraph: true, max: 500 }]));
                }
                if (name === "lock")
                    return i.showModal(form("lock:" + revision, "Restrição temporária de chats", [{ id: "minutes", label: "Duração em minutos (1–60)", value: "10", max: 2 }]));
            }
            if (name === "release" || name === "end-raid") {
                await (0, reviews_1.authorize)(i, true);
                const locks = name === "release" ? await config_1.db.securityChannelLock.findMany({ where: { guildId: g.id, status: { in: ["ACTIVE", "PREPARING", "UNCERTAIN", "ERROR", "CONFLICT"] } }, take: 25 }) : [];
                (0, config_1.assert)(name !== "release" || locks.length, "Nenhum chat com bloqueio pendente.");
                if (name === "release" && locks.length && locks.every((l) => l.status === "CONFLICT")) {
                    const r = await (0, reviews_1.review)(i, "ACK_CONFLICT", { lockIds: locks.map((l) => l.id), summary: "Manter exatamente as permissões atuais e encerrar os registros de conflito destes chats: " + locks.map((l) => `<#${l.channelId}>`).join(", ") + ". Confirme somente depois de conferir manualmente o acesso. Nenhuma permissão será alterada. As regras atuais serão a referência de uma futura contenção.", returnTo: "incidents" });
                    return show(i, await V.reviewView(g, r));
                }
                const r = await (0, reviews_1.review)(i, name === "release" ? "RELEASE" : "END_RAID", { channelIds: locks.map((l) => l.channelId), summary: name === "release" ? "Restaurar as permissões temporárias de até 25 chats: " + locks.map((l) => `<#${l.channelId}>`).join(", ") + ". Alterações posteriores da equipe serão preservadas e conflitos aparecerão no resultado." : "Encerrar este ciclo de contenção de novas entradas. O Anti-Raid continua no modo configurado e poderá detectar outro pico; isso não retira silenciamentos já aplicados.", returnTo: "incidents" });
                return show(i, await V.reviewView(g, r));
            }
            if (name === "mirror") {
                await (0, reviews_1.authorize)(i, true);
                const p = await config_1.db.securityIncident.findFirst({ where: { id: a, guildId: g.id } });
                (0, config_1.assert)(p && p.deliveryStatus !== "SENDING", "Ocorrência indisponível ou log em envio.");
                const r = await (0, reviews_1.review)(i, "MIRROR", { incidentId: p.id, summary: "Reenviar somente o log deste incidente pelo destino atual da central. Se a entrega anterior ficou sem confirmação, o canal pode receber uma cópia. Nenhuma punição será repetida.", returnTo: "incident:" + p.id });
                return show(i, await V.reviewView(g, r));
            }
            if (name === "export") {
                const { config, revision } = await (0, config_1.settings)(g.id, true);
                return i.followUp({ flags: D.MessageFlags.Ephemeral, content: "Cópia das regras e exceções deste servidor. Não contém token, banco, histórico ou um backup completo do servidor.", files: [new D.AttachmentBuilder(Buffer.from(JSON.stringify({ version: 1, guildId: g.id, revision, exportedAt: new Date().toISOString(), config }, null, 2)), { name: "blackout-security-settings.json" })] });
            }
        }
        if (prefix === "security-select") {
            const v = i.values?.[0];
            if (name === "home")
                return route(i, ["incidents", "settings"].includes(v) ? v : "group:" + v);
            if (name === "rule")
                return route(i, "rule:" + v);
            if (name === "settings")
                return v === "invites" ? show(i, V.surface(g, "Convites autorizados", "Cadastre somente códigos de convite permitidos. O filtro Convites do Discord respeita esta lista; filtros antigos de links têm configurações independentes.", [V.row(V.button("invites", "Editar códigos"), V.button("settings", "Voltar às exceções"))], "settings")) : route(i, v === "diagnose" ? v : "list:" + v);
            if (name === "incident")
                return route(i, "incident:" + v);
            if (name === "mode" || name === "action") {
                await (0, reviews_1.authorize)(i, true);
                const { config, revision } = await (0, config_1.settings)(g.id, true);
                (0, config_1.assert)(revision === Number(b) && !!config_1.RULES[a], "A regra mudou. Abra novamente.");
                const next = (0, config_1.editRule)(config, a, { [name]: v }), nr = next.rules[a];
                const summary = "**" + config_1.RULES[a].label + "**\nModo atual: " + config_1.MODES[config.rules[a].mode] + "\nNovo modo: **" + config_1.MODES[nr.mode] + "**\nResposta: **" + config_1.ACTIONS[nr.action] + "**\n" + V.limits(a, nr) + (nr.mode === "ENFORCE" && nr.action !== "ALERT" ? "\n\nAo salvar, esta regra poderá executar a resposta automaticamente em novas ocorrências. Proprietário e o próprio bot são preservados." : "\n\nEsta configuração não aplica punição automática.");
                return configReview(i, next, summary, "rule:" + a, revision, a);
            }
            if (name === "list") {
                await (0, reviews_1.authorize)(i, true);
                (0, config_1.assert)(V.LISTS[a], "Lista desconhecida.");
                const { config, revision } = await (0, config_1.settings)(g.id, true);
                (0, config_1.assert)(revision === Number(b), "A lista mudou. Abra novamente.");
                const values = i.values || [];
                (0, config_1.assert)(values.length <= 25 && (0, config_1.ids)(values).length === values.length, "Seleção inválida.");
                if (V.LISTS[a].type === "roles")
                    for (const id of values) {
                        const role = await g.roles.fetch(id).catch(() => null);
                        (0, config_1.assert)(role && role.id !== g.id, "Escolha cargos existentes deste servidor, sem @everyone.");
                    }
                if (V.LISTS[a].type === "channels")
                    for (const id of values) {
                        const ch = await g.channels.fetch(id).catch(() => null);
                        (0, config_1.assert)(ch?.guildId === g.id && (["ignoredChannels", "protectedChannels"].includes(a) || [D.ChannelType.GuildText, D.ChannelType.GuildAnnouncement].includes(ch.type)), "Escolha canais compatíveis deste servidor.");
                    }
                const next = { ...config, [a]: a === "honeyChannel" ? values[0] || null : values };
                return configReview(i, next, "**" + V.LISTS[a].label + "**\nNova seleção: " + (values.join(", ") || "Nenhuma") + "\n\n" + V.LISTS[a].text, "list:" + a, revision);
            }
            if (name === "deny-remove") {
                const p = await config_1.db.securityDenyEntry.findFirst({ where: { id: v, guildId: g.id } });
                (0, config_1.assert)(p, "Cadastro indisponível.");
                const r = await (0, reviews_1.review)(i, "DENY_REMOVE", { entryId: p.id, summary: "Retirar <@" + p.userId + "> da lista de entrada bloqueada. Isso não altera cargos, castigos ou banimentos existentes.", returnTo: "deny:0" }, Number(a));
                return show(i, await V.reviewView(g, r));
            }
        }
        if (prefix === "security-form") {
            await (0, reviews_1.authorize)(i, true);
            const { config, revision } = await (0, config_1.settings)(g.id, true);
            if (name === "limits") {
                (0, config_1.assert)(config_1.RULES[a] && revision === Number(b), "A regra mudou. Abra novamente.");
                const patch = Object.fromEntries(config_1.RULES[a].fields.map(f => [f.key, integer(i.fields.getTextInputValue(f.key))])), next = (0, config_1.editRule)(config, a, patch);
                return configReview(i, next, "**" + config_1.RULES[a].label + " · novos limites**\n" + V.limits(a, next.rules[a]) + "\nModo: " + config_1.MODES[next.rules[a].mode] + "\nResposta: " + config_1.ACTIONS[next.rules[a].action], "rule:" + a, revision, a);
            }
            if (name === "ids") {
                (0, config_1.assert)(["trustedUsers", "protectedUsers"].includes(a) && revision === Number(b), "A lista mudou. Abra novamente.");
                const values = i.fields.getTextInputValue("value").split(/[\s,]+/).filter(Boolean);
                (0, config_1.assert)(values.length <= 25 && (0, config_1.ids)(values).length === values.length, "Use até 25 IDs válidos e diferentes, separados por linha.");
                return configReview(i, { ...config, [a]: values }, "**" + V.LISTS[a].label + "**\nNova lista: " + (values.join(", ") || "Nenhum") + "\n\n" + V.LISTS[a].text, "list:" + a, revision);
            }
            (0, config_1.assert)(revision === Number(a), "A configuração mudou. Abra novamente.");
            if (name === "invites") {
                const values = i.fields.getTextInputValue("value").split(/[\s,]+/).filter(Boolean);
                (0, config_1.assert)(values.length <= 25 && values.every((v) => /^[\w-]{2,100}$/.test(v)) && new Set(values).size === values.length, "Use até 25 códigos diferentes, sem URL, um por linha.");
                return configReview(i, { ...config, allowedInvites: values }, "Convites autorizados: " + (values.join(", ") || "Nenhum") + ". Filtros antigos de links permanecem independentes.", "settings", revision);
            }
            if (name === "deny") {
                const userId = i.fields.getTextInputValue("user").trim(), reason = i.fields.getTextInputValue("reason").trim();
                (0, config_1.assert)(/^\d{15,25}$/.test(userId) && reason.length >= 3 && reason.length <= 500, "Informe um ID válido e motivo de 3 a 500 caracteres.");
                (0, config_1.assert)(![g.ownerId, g.client.user?.id].includes(userId) && !config.trustedUsers.includes(userId), "Retire a exceção confiável antes de bloquear; proprietário e o próprio bot não entram nesta lista.");
                const r = await (0, reviews_1.review)(i, "DENY_ADD", { userId, reason, summary: "Cadastrar <@" + userId + "> na lista de entrada bloqueada.\nMotivo: " + reason + "\n\nA regra vigente está em **" + config_1.MODES[config.rules.deny.mode] + "**. Este cadastro não expulsa quem já está no servidor.", returnTo: "deny:0" }, revision);
                return show(i, await V.reviewView(g, r));
            }
            if (name === "lock") {
                const minutes = integer(i.fields.getTextInputValue("minutes"));
                (0, config_1.assert)(minutes >= 1 && minutes <= 60 && config.lockChannels.length, "Defina os chats para contenção e uma duração entre 1 e 60 minutos.");
                const r = await (0, reviews_1.review)(i, "LOCK", { channelIds: config.lockChannels, minutes, summary: "Restringir mensagens e criação de tópicos por **" + minutes + " minutos** nestes chats: " + config.lockChannels.map(id => `<#${id}>`).join(", ") + ".\n\nAs permissões de escrita atuais serão guardadas. Administradores mantêm o acesso nativo. O bot tenta restaurar ao vencer; se estiver desligado, retoma ao iniciar. Alterações posteriores da equipe exigem revisão e não serão sobrescritas.", returnTo: "incidents" }, revision);
                return show(i, await V.reviewView(g, r));
            }
        }
        throw new config_1.SecurityError("Opção indisponível. Abra a central com /adm.");
    });
}
