"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.safe = safe;
exports.start = start;
const config_1 = require("./config");
const locks_1 = require("./locks");
const incidents_1 = require("./incidents");
async function safe(label, fn) {
    try {
        return await fn();
    }
    catch (e) {
        console.error("[blackout-security] " + label + ":", e?.code || e?.name || "falha");
    }
}
const started = new WeakSet();
async function start(client) {
    if (started.has(client))
        return;
    started.add(client);
    for (const guild of client.guilds.cache.values())
        await safe("retomada", async () => {
            await config_1.db.securityIncident.updateMany({ where: { guildId: guild.id, status: "CLAIMED" }, data: { status: "UNCERTAIN", resultJson: JSON.stringify({ done: [], skipped: [], errors: ["Processo reiniciado antes da confirmação. Confira o alvo; nenhuma ação será repetida automaticamente."] }) } });
            await config_1.db.securityIncident.updateMany({ where: { guildId: guild.id, deliveryStatus: "SENDING" }, data: { deliveryStatus: "UNCERTAIN", deliveryError: "Processo reiniciado durante o envio do log. Confira o canal antes de reenviar." } });
        });
    let running = false, lastCleanup = 0;
    const tick = async () => {
        if (running)
            return;
        running = true;
        try {
            for (const guild of client.guilds.cache.values())
                await safe("rotina", async () => {
                    await (0, locks_1.due)(guild);
                    const pending = await config_1.db.securityIncident.findMany({ where: { guildId: guild.id, deliveryStatus: "PENDING", status: { not: "CLAIMED" } }, orderBy: { createdAt: "asc" }, take: 20 });
                    for (const incident of pending)
                        await (0, incidents_1.mirror)(guild, incident.id);
                });
            if (Date.now() - lastCleanup > 900000) {
                for (const [model, column, age] of [["securityAuditEntry", "happenedAt", 172800000], ["securityMemberSnapshot", "capturedAt", 86400000], ["securityReview", "expiresAt", 86400000]]) {
                    const expired = await config_1.db[model].findMany({ where: { [column]: { lt: new Date(Date.now() - age) } }, select: { id: true }, take: 250 });
                    if (expired.length)
                        await config_1.db[model].deleteMany({ where: { id: { in: expired.map((x) => x.id) } } });
                }
                lastCleanup = Date.now();
            }
        }
        finally {
            running = false;
        }
    };
    await safe("início", tick);
    const timer = setInterval(() => void safe("rotina", tick), 30000);
    timer.unref?.();
}
