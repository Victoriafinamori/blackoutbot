"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.snapshot = snapshot;
exports.protectedTarget = protectedTarget;
exports.joined = joined;
const config_1 = require("./config");
const actions_1 = require("./actions");
const incidents_1 = require("./incidents");
async function snapshot(member) {
    if (!member?.guild || !member.roles?.cache)
        return;
    const { config } = await (0, config_1.settings)(member.guild.id);
    if (!config.protectedRoles.length)
        return;
    await config_1.db.securityMemberSnapshot.upsert({ where: { guildId_userId: { guildId: member.guild.id, userId: member.id } }, create: { guildId: member.guild.id, userId: member.id, rolesJson: JSON.stringify([...member.roles.cache.keys()]), capturedAt: new Date() }, update: { rolesJson: JSON.stringify([...member.roles.cache.keys()]), capturedAt: new Date() } });
}
async function protectedTarget(guild, userId, config, at = Date.now()) {
    if (config.protectedUsers.includes(userId) || userId === guild.ownerId)
        return true;
    const cached = guild.members.cache.get(userId);
    if (cached?.roles?.cache?.some((r) => config.protectedRoles.includes(r.id)))
        return true;
    const s = await config_1.db.securityMemberSnapshot.findUnique({ where: { guildId_userId: { guildId: guild.id, userId } } });
    // Only a recent removal/update snapshot can establish the target's former roles.
    return !!s && Math.abs(at - s.capturedAt.getTime()) <= 30000 && JSON.parse(s.rolesJson).some((id) => config.protectedRoles.includes(id));
}
async function joined(member) {
    const guild = member.guild;
    if (!guild)
        return false;
    return (0, config_1.exclusive)("security-join:" + guild.id, async () => {
        const { config: c, revision } = await (0, config_1.settings)(guild.id, true);
        if ((0, actions_1.trusted)(guild, member, c))
            return false;
        await snapshot(member);
        const stamp = member.joinedTimestamp || Date.now(), key = member.id + ":" + stamp;
        let raidDetected = false;
        const raid = c.rules.raid;
        if (raid.mode !== "OFF" && !member.user.bot) {
            try {
                await config_1.db.securityAuditEntry.create({ data: { id: guild.id + ":join:" + key, guildId: guild.id, action: "JOIN", targetId: member.id, happenedAt: new Date() } });
            }
            catch (e) {
                if (e?.code !== "P2002" && !/UNIQUE constraint/i.test(e?.message || ""))
                    throw e;
            }
            const count = await config_1.db.securityAuditEntry.count({ where: { guildId: guild.id, action: "JOIN", happenedAt: { gte: new Date(Date.now() - raid.windowSeconds * 1000) } } });
            let state = await config_1.db.securityState.findUnique({ where: { guildId: guild.id } });
            if (count >= raid.limit && raid.mode === "ENFORCE" && raid.action !== "ALERT" && (!state?.raidUntil || state.raidUntil.getTime() <= Date.now())) {
                state = await config_1.db.securityState.upsert({ where: { guildId: guild.id }, create: { guildId: guild.id, raidUntil: new Date(Date.now() + raid.activeMinutes * 60000) }, update: { raidUntil: new Date(Date.now() + raid.activeMinutes * 60000) } });
            }
            raidDetected = count >= raid.limit || !!state?.raidUntil && state.raidUntil.getTime() > Date.now();
        }
        const denied = c.rules.deny.mode !== "OFF" ? await config_1.db.securityDenyEntry.findUnique({ where: { guildId_userId: { guildId: guild.id, userId: member.id } } }) : null;
        const ageDays = Math.max(0, (Date.now() - member.user.createdTimestamp) / 86400000);
        const tests = [
            ["deny", !!denied, "Membro cadastrado na lista de entrada bloqueada."],
            ["bots", !!member.user.bot, "Entrada de bot não autorizado nas exceções."],
            ["age", !member.user.bot && ageDays < c.rules.age.minAgeDays, "Conta com " + Math.floor(ageDays) + " dias; mínimo configurado: " + c.rules.age.minAgeDays + "."],
            ["raid", raidDetected, "Pico de entradas detectado; esta é uma nova entrada durante a proteção."],
        ];
        for (const [rule, detected, summary] of tests) {
            const r = c.rules[rule];
            if (!detected || r.mode === "OFF")
                continue;
            await (0, incidents_1.record)(guild, { eventKey: "join:" + rule + ":" + key, rule, mode: r.mode, action: r.action, targetId: member.id, summary, revision, details: { accountAgeDays: Math.floor(ageDays), joinedAt: stamp } }, () => (0, actions_1.memberAction)(guild, member.id, r.action, r.durationMinutes));
            if (r.mode === "ENFORCE" && r.action !== "ALERT")
                return true;
        }
        return false;
    });
}
