"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.clip = exports.result = exports.DELIVERY = exports.STATUS = void 0;
exports.safeError = safeError;
exports.targetLabel = targetLabel;
exports.evidence = evidence;
exports.mirror = mirror;
exports.record = record;
exports.operation = operation;
const node_crypto_1 = require("node:crypto");
const discord_js_1 = require("discord.js");
const delivery_1 = require("../logging/delivery");
const config_1 = require("./config");
exports.STATUS = { CLAIMED: "Em processamento", DONE: "Resposta aplicada", PARTIAL: "Resposta parcial", FAILED: "Falha na resposta", SKIPPED: "Sem ação possível", OBSERVED: "Registrado", CANCELLED: "Cancelado por mudança de regra", UNCERTAIN: "Resultado não confirmado" };
exports.DELIVERY = { PENDING: "Aguardando envio", SENDING: "Envio em andamento", DELIVERED: "Enviado", PARTIAL: "Envio parcial", FAILED: "Falha no envio", SKIPPED: "Encaminhamento desativado", UNCERTAIN: "Entrega não confirmada" };
const result = () => ({ done: [], skipped: [], errors: [] });
exports.result = result;
const clip = (v, n = 950) => String(v ?? "Não informado").replace(/\x00/g, "").slice(0, n);
exports.clip = clip;
function safeError(e) { return e?.code === 50013 ? "Permissão ou hierarquia insuficiente." : e?.code === 10007 ? "Membro não está no servidor." : "A API não confirmou a ação. Confira o alvo e o diagnóstico antes de repetir."; }
function targetLabel(details) { return !details.targetId ? "Não informado" : details.targetKind === "role" ? `<@&${details.targetId}> · cargo` : details.targetKind === "channel" ? `<#${details.targetId}> · canal` : `<@${details.targetId}>`; }
function evidence(details) {
    const names = { permissions: "Permissões do cargo", allow: "Permissões permitidas", deny: "Permissões negadas", communication_disabled_until: "Timeout", "$add": "Cargos concedidos", "$remove": "Cargos retirados", vanity_url_code: "URL personalizada" };
    const labels = { Administrator: "Administrador", ManageGuild: "Gerenciar servidor", ManageRoles: "Gerenciar cargos", ManageChannels: "Gerenciar canais", BanMembers: "Banir", KickMembers: "Expulsar", ModerateMembers: "Moderar membros", ViewChannel: "Ver canal", SendMessages: "Enviar mensagens", MoveMembers: "Mover membros", ManageMessages: "Gerenciar mensagens", ManageWebhooks: "Gerenciar webhooks" };
    const value = (key, v) => {
        if (v == null)
            return "Não informado";
        if (["permissions", "allow", "deny"].includes(key)) {
            try {
                return new discord_js_1.PermissionsBitField(BigInt(v)).toArray().map(k => labels[k] || k).join(", ") || "Nenhuma";
            }
            catch {
                return "Indisponível";
            }
        }
        if (Array.isArray(v))
            return v.map(x => x.id ? `<@&${x.id}>` : "Cargo indisponível").join(", ");
        return String(v);
    };
    return (details.changes || []).slice(0, 6).map((c) => "**" + (names[c.key] || c.key) + "**: " + value(c.key, c.old) + " → " + value(c.key, c.new)).join("\n");
}
async function mirror(guild, id, retry = false) {
    const p = await config_1.db.securityIncident.findFirst({ where: { id, guildId: guild.id } });
    if (!p)
        return;
    const claim = await config_1.db.securityIncident.updateMany({ where: { id, deliveryStatus: retry ? p.deliveryStatus : "PENDING" }, data: { deliveryStatus: "SENDING", deliveryError: null } });
    if (!claim.count)
        return;
    try {
        const d = JSON.parse(p.detailsJson || "{}"), r = JSON.parse(p.resultJson || "{}"), detail = [...(r.done || []), ...(r.skipped || []), ...(r.errors || [])].join("\n");
        const e = new discord_js_1.EmbedBuilder().setColor(p.status === "DONE" ? 0xd71935 : 0xf0b94b).setTitle("Segurança · " + (config_1.RULES[p.rule]?.label || "Operação da equipe"))
            .setDescription((0, exports.clip)(p.summary)).addFields({ name: "Estado", value: (exports.STATUS[p.status] || p.status) + " · " + (config_1.MODES[p.mode] || p.mode), inline: true }, { name: "Resposta", value: config_1.ACTIONS[p.action] || (0, exports.clip)(p.action), inline: true }, { name: "Executor", value: p.actorId ? `<@${p.actorId}> · ${p.actorId}` : "Não identificado; nenhuma culpa atribuída." }, ...(p.targetId ? [{ name: "Alvo", value: `<@${p.targetId}> · ${p.targetId}` }] : []), ...(p.channelId ? [{ name: "Canal", value: `<#${p.channelId}>` }] : []), ...(d.targetId && !p.targetId ? [{ name: "Alvo auditado", value: targetLabel(d) }] : []), ...(evidence(d) ? [{ name: "Alterações confirmadas", value: (0, exports.clip)(evidence(d)) }] : []), { name: "Resultado", value: (0, exports.clip)(detail || "Ocorrência registrada; sem alteração automática.") }).setFooter({ text: "Incidente " + p.id }).setTimestamp(p.createdAt);
        // Security decisions must not disappear because the offending account is a bot.
        const sent = await (0, delivery_1.deliverLog)(guild, "security.actions", e, { roleIds: [], channelIds: [] });
        await config_1.db.securityIncident.update({ where: { id }, data: { deliveryStatus: sent.sent ? (sent.errors.length ? "PARTIAL" : "DELIVERED") : sent.errors.length ? "FAILED" : "SKIPPED", deliveryError: sent.errors.length ? (0, exports.clip)(sent.errors.join(" "), 400) : null } });
    }
    catch {
        await config_1.db.securityIncident.updateMany({ where: { id, deliveryStatus: "SENDING" }, data: { deliveryStatus: "UNCERTAIN", deliveryError: "Entrega não confirmada. Confira o canal antes de reenviar." } }).catch(() => null);
    }
}
async function record(guild, input, execute) {
    let row;
    try {
        row = await config_1.db.securityIncident.create({ data: { id: (0, node_crypto_1.randomUUID)(), guildId: guild.id, eventKey: guild.id + ":" + input.eventKey, rule: input.rule, mode: input.mode, action: input.action, summary: (0, exports.clip)(input.summary, 1000), actorId: input.actorId || null, targetId: input.targetId || null, channelId: input.channelId || null, detailsJson: JSON.stringify(input.details || {}), status: "CLAIMED" } });
    }
    catch (e) {
        if (e?.code === "P2002" || /UNIQUE constraint/i.test(e?.message || ""))
            return { duplicate: true };
        throw e;
    }
    let out = (0, exports.result)(), status = input.mode === "ENFORCE" && input.action !== "ALERT" ? "DONE" : "OBSERVED";
    try {
        const current = await (0, config_1.settings)(guild.id, true);
        if (input.revision !== undefined && current.revision !== input.revision) {
            status = "CANCELLED";
            out.skipped.push("As regras mudaram durante o processamento. Nenhuma ação automática foi executada.");
        }
        else if (status === "DONE" && execute) {
            out = await execute();
            status = out.errors.length ? out.done.length ? "PARTIAL" : "FAILED" : out.done.length ? "DONE" : "SKIPPED";
        }
        else
            out.skipped.push("Somente registro. Nenhuma ação automática aplicada.");
    }
    catch (e) {
        status = "UNCERTAIN";
        out.errors.push(safeError(e));
    }
    await config_1.db.securityIncident.update({ where: { id: row.id }, data: { status, resultJson: JSON.stringify(out) } });
    await mirror(guild, row.id);
    return { id: row.id, status, result: out };
}
async function operation(guild, actorId, summary, details = {}) {
    return record(guild, { eventKey: "operation:" + (0, node_crypto_1.randomUUID)(), rule: "operation", mode: "OBSERVE", action: "ALERT", actorId, summary, details });
}
