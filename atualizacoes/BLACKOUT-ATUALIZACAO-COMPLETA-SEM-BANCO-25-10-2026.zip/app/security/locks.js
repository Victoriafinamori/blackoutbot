"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.lock = lock;
exports.release = release;
exports.releaseMany = releaseMany;
exports.due = due;
const discord_js_1 = require("discord.js");
const node_crypto_1 = require("node:crypto");
const config_1 = require("./config");
const incidents_1 = require("./incidents");
const MASK = discord_js_1.PermissionFlagsBits.SendMessages | discord_js_1.PermissionFlagsBits.SendMessagesInThreads | discord_js_1.PermissionFlagsBits.CreatePublicThreads | discord_js_1.PermissionFlagsBits.CreatePrivateThreads;
const serial = (p) => ({ id: p.id, type: p.type, allow: String(p.allow?.bitfield ?? p.allow ?? 0), deny: String(p.deny?.bitfield ?? p.deny ?? 0) });
function bits(p) { return { allow: BigInt(p?.allow || 0), deny: BigInt(p?.deny || 0) }; }
const same = (a, b) => { const x = bits(a), y = bits(b); return (x.allow & MASK) === (y.allow & MASK) && (x.deny & MASK) === (y.deny & MASK); };
async function channel(guild, id) {
    const ch = await guild.channels.fetch(id, { force: true });
    (0, config_1.assert)(ch?.guildId === guild.id && [discord_js_1.ChannelType.GuildText, discord_js_1.ChannelType.GuildAnnouncement].includes(ch.type), "Escolha um canal de texto deste servidor.");
    const me = await guild.members.fetchMe();
    (0, config_1.assert)(ch.permissionsFor(me)?.has([discord_js_1.PermissionFlagsBits.ViewChannel, discord_js_1.PermissionFlagsBits.ManageChannels, discord_js_1.PermissionFlagsBits.ManageRoles]), "O bot precisa ver o canal e gerenciar canal/permissões.");
    return ch;
}
async function lock(guild, channelIds, actorId, minutes) {
    (0, config_1.assert)(channelIds.length > 0 && channelIds.length <= 25 && Number.isInteger(minutes) && minutes >= 1 && minutes <= 60, "Escolha até 25 canais e prazo entre 1 e 60 minutos.");
    const out = (0, incidents_1.result)();
    for (const id of [...new Set(channelIds)])
        await (0, config_1.exclusive)("security-lock:" + guild.id + ":" + id, async () => {
            try {
                const old = await config_1.db.securityChannelLock.findUnique({ where: { guildId_channelId: { guildId: guild.id, channelId: id } } });
                if (old && !["RELEASED", "CANCELLED"].includes(old.status)) {
                    out.skipped.push("Canal " + id + " já possui bloqueio ou recuperação pendente; prazo original preservado.");
                    return;
                }
                const ch = await channel(guild, id), before = [...ch.permissionOverwrites.cache.values()].map(serial);
                if (!before.some(p => p.id === guild.id))
                    before.push({ id: guild.id, type: 0, allow: "0", deny: "0" });
                (0, config_1.assert)(before.length <= 100, "Canal sem espaço para a regra temporária de permissões.");
                const applied = before.map(p => { const b = bits(p); return p.id === guild.id || (b.allow & MASK) !== 0n ? { ...p, allow: String(b.allow & ~MASK), deny: String(b.deny | MASK) } : p; });
                const data = { beforeJson: JSON.stringify(before), appliedJson: JSON.stringify(applied), status: "PREPARING", createdById: actorId, expiresAt: new Date(Date.now() + minutes * 60000), lastError: null };
                const saved = await config_1.db.securityChannelLock.upsert({ where: { guildId_channelId: { guildId: guild.id, channelId: id } }, create: { id: (0, node_crypto_1.randomUUID)(), guildId: guild.id, channelId: id, ...data }, update: data });
                await ch.permissionOverwrites.set(applied.map(p => ({ ...p, allow: BigInt(p.allow), deny: BigInt(p.deny) })), "BLACKOUT · contenção temporária solicitada pela equipe");
                await config_1.db.securityChannelLock.update({ where: { id: saved.id }, data: { status: "ACTIVE" } });
                out.done.push("Chat " + id + " restringido por " + minutes + " minutos. Administradores mantêm o acesso nativo.");
            }
            catch (e) {
                await config_1.db.securityChannelLock.updateMany({ where: { guildId: guild.id, channelId: id, status: "PREPARING" }, data: { status: "UNCERTAIN", lastError: (0, incidents_1.safeError)(e) } }).catch(() => null);
                out.errors.push("Canal " + id + ": " + (e?.name === "SecurityError" ? e.message : (0, incidents_1.safeError)(e)));
            }
        });
    return out;
}
async function release(guild, id) {
    return (0, config_1.exclusive)("security-lock:" + guild.id + ":" + id, async () => {
        const out = (0, incidents_1.result)(), item = await config_1.db.securityChannelLock.findUnique({ where: { guildId_channelId: { guildId: guild.id, channelId: id } } });
        if (!item || item.status === "RELEASED") {
            out.skipped.push("Canal " + id + " não possui bloqueio pendente.");
            return out;
        }
        try {
            const ch = await channel(guild, id), before = JSON.parse(item.beforeJson), applied = JSON.parse(item.appliedJson), current = [...ch.permissionOverwrites.cache.values()].map(serial);
            const plan = [...current];
            let conflicts = 0;
            for (const previous of before) {
                const expected = applied.find((p) => p.id === previous.id), pos = plan.findIndex(p => p.id === previous.id), now = pos >= 0 ? plan[pos] : { ...previous, allow: "0", deny: "0" };
                if (same(previous, expected))
                    continue; // This overwrite was never changed by our lock.
                if (!same(now, expected)) {
                    if (!same(now, previous))
                        conflicts++;
                    continue;
                }
                const b = bits(now), restore = bits(previous), next = { ...now, allow: String((b.allow & ~MASK) | (restore.allow & MASK)), deny: String((b.deny & ~MASK) | (restore.deny & MASK)) };
                if (pos >= 0)
                    plan[pos] = next;
                else
                    plan.push(next);
            }
            if (conflicts) {
                out.skipped.push("Canal " + id + ": permissões alteradas por outra pessoa foram preservadas; " + conflicts + " conflito(s) exigem revisão.");
            }
            if (JSON.stringify(current) !== JSON.stringify(plan)) {
                await ch.permissionOverwrites.set(plan.map(p => ({ ...p, allow: BigInt(p.allow), deny: BigInt(p.deny) })), "BLACKOUT · restaurar somente permissões da contenção temporária");
                out.done.push("Permissões temporárias restauradas em " + id + ".");
            }
            else
                out.skipped.push("Canal " + id + " já está restaurado ou não possui alteração segura para aplicar.");
            await config_1.db.securityChannelLock.update({ where: { id: item.id }, data: { status: conflicts ? "CONFLICT" : "RELEASED", lastError: conflicts ? "Alteração externa preservada. Confira as regras do canal; o bot não sobrescreve a decisão posterior." : null } });
        }
        catch (e) {
            await config_1.db.securityChannelLock.update({ where: { id: item.id }, data: { status: "ERROR", lastError: (0, incidents_1.safeError)(e) } });
            out.errors.push("Canal " + id + ": " + (0, incidents_1.safeError)(e));
        }
        return out;
    });
}
async function releaseMany(guild, ids) {
    const out = (0, incidents_1.result)(), list = await config_1.db.securityChannelLock.findMany({ where: { guildId: guild.id, status: { in: ["ACTIVE", "PREPARING", "UNCERTAIN", "ERROR", "CONFLICT"] }, ...(ids ? { channelId: { in: ids } } : {}) }, take: 25 });
    for (const item of list) {
        const r = await release(guild, item.channelId);
        out.done.push(...r.done);
        out.skipped.push(...r.skipped);
        out.errors.push(...r.errors);
    }
    return out;
}
async function due(guild) {
    const list = await config_1.db.securityChannelLock.findMany({ where: { guildId: guild.id, status: { in: ["ACTIVE", "PREPARING", "UNCERTAIN", "ERROR"] }, expiresAt: { lte: new Date() } }, take: 25 });
    for (const row of list)
        await release(guild, row.channelId);
}
