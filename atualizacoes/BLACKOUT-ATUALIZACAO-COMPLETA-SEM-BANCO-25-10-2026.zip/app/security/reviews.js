"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.authorize = authorize;
exports.review = review;
exports.getReview = getReview;
exports.consume = consume;
const node_crypto_1 = require("node:crypto");
const discord_js_1 = require("discord.js");
const permissions_1 = require("../utils/permissions");
const config_1 = require("./config");
async function authorize(i, write = false) {
    (0, config_1.assert)(i.guild && i.message?.id && i.user?.id, "Abra a central de segurança no servidor com /adm.");
    const member = await i.guild.members.fetch({ user: i.user.id, force: true });
    (0, config_1.assert)(await (0, permissions_1.isBotAdmin)(member), "Você não possui acesso administrativo ao bot neste servidor.");
    if (write)
        (0, config_1.assert)(member.id === i.guild.ownerId || member.permissions.has(discord_js_1.PermissionFlagsBits.Administrator), "Alterar proteções e exceções exige Administrador do Discord ou ser proprietário do servidor.");
    return member;
}
async function review(i, kind, payload, revision) {
    await authorize(i, true);
    const current = await (0, config_1.settings)(i.guild.id, true);
    if (revision !== undefined)
        (0, config_1.assert)(revision === current.revision, "A configuração mudou. Abra a opção novamente.");
    return config_1.db.securityReview.create({ data: { id: (0, node_crypto_1.randomUUID)(), guildId: i.guild.id, actorId: i.user.id, messageId: i.message.id, kind, payloadJson: JSON.stringify(payload), configRevision: current.revision, expiresAt: new Date(Date.now() + 1200000) } });
}
async function getReview(i, id) {
    await authorize(i, true);
    const r = await config_1.db.securityReview.findFirst({ where: { id, guildId: i.guild.id, actorId: i.user.id, messageId: i.message.id } });
    (0, config_1.assert)(r && r.status === "PENDING" && r.expiresAt.getTime() > Date.now(), "Esta revisão expirou, já foi usada ou pertence a outra pessoa/mensagem. Abra uma nova revisão.");
    (0, config_1.assert)(r.configRevision === (await (0, config_1.settings)(i.guild.id, true)).revision, "As regras mudaram depois desta revisão. Abra uma nova.");
    return r;
}
async function consume(i, id) { const r = await getReview(i, id), claim = await config_1.db.securityReview.updateMany({ where: { id: r.id, status: "PENDING" }, data: { status: "CONSUMED" } }); (0, config_1.assert)(claim.count === 1, "Esta revisão já foi usada."); return r; }
