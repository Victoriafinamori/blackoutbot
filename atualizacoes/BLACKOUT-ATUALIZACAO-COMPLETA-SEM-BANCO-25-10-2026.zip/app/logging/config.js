"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LOG_EVENTS = exports.LOG_GROUPS = void 0;
exports.objectJson = objectJson;
exports.idList = idList;
exports.normalizeSettings = normalizeSettings;
exports.clearLogSettingsCache = clearLogSettingsCache;
exports.readLogSettings = readLogSettings;
exports.saveLogSettings = saveLogSettings;
const prisma_1 = require("../database/prisma");
exports.LOG_GROUPS = { members: "Membros", voice: "Calls", messages: "Mensagens", moderation: "Moderação", security: "Servidor e segurança", system: "Sistemas do bot", reintegration: "Reintegração" };
exports.LOG_EVENTS = {
    "member.join": { label: "Entrada de membro", group: "members", enabled: true },
    "member.leave": { label: "Saída de membro", group: "members", enabled: true },
    "member.nickname": { label: "Alteração de apelido", group: "members", enabled: false },
    "member.roles": { label: "Alteração de cargos do membro", group: "members", enabled: false },
    "voice.join": { label: "Entrada em call", group: "voice", enabled: false },
    "voice.leave": { label: "Saída de call", group: "voice", enabled: false },
    "voice.move": { label: "Troca de call", group: "voice", enabled: false },
    "voice.state": { label: "Silêncio e áudio em call", group: "voice", enabled: false },
    "message.edit": { label: "Mensagem editada", group: "messages", enabled: false },
    "message.delete": { label: "Mensagem excluída", group: "messages", enabled: false },
    "message.bulk": { label: "Exclusão em massa (um registro)", group: "messages", enabled: false },
    "moderation.actions": { label: "Ações de moderação pelo bot", group: "moderation", enabled: true },
    "moderation.ban": { label: "Banimento fora do bot (auditoria)", group: "moderation", enabled: false },
    "moderation.unban": { label: "Desbanimento fora do bot (auditoria)", group: "moderation", enabled: false },
    "security.actions": { label: "Proteção e segurança pelo bot", group: "security", enabled: true },
    "channel.create": { label: "Canal criado", group: "security", enabled: false },
    "channel.update": { label: "Canal ou permissões alterados", group: "security", enabled: false },
    "channel.delete": { label: "Canal excluído", group: "security", enabled: false },
    "role.create": { label: "Cargo criado", group: "security", enabled: false },
    "role.update": { label: "Cargo ou permissões alterados", group: "security", enabled: false },
    "role.delete": { label: "Cargo excluído", group: "security", enabled: false },
    "guild.update": { label: "Configurações do servidor", group: "security", enabled: false },
    "system.actions": { label: "Configurações e operações do bot", group: "system", enabled: true },
    "reintegration.actions": { label: "Etapas e reintegração", group: "reintegration", enabled: true },
};
function objectJson(raw) { try {
    const v = JSON.parse(raw || "{}");
    return v && typeof v === "object" && !Array.isArray(v) ? v : {};
}
catch {
    return {};
} }
function idList(raw) { try {
    const v = JSON.parse(raw || "[]");
    return Array.isArray(v) ? [...new Set(v.filter((id) => typeof id === "string" && /^\d{15,25}$/.test(id)))].slice(0, 25) : [];
}
catch {
    return [];
} }
function normalizeSettings(row, guildId) {
    const flags = objectJson(row?.eventsJson), events = Object.fromEntries(Object.entries(exports.LOG_EVENTS).map(([key, info]) => [key, typeof flags[key] === "boolean" ? flags[key] : info.enabled]));
    return { guildId, deliveryMode: ["LOCAL", "EXTERNAL", "BOTH"].includes(row?.deliveryMode) ? row.deliveryMode : "LOCAL", events,
        localChannels: objectJson(row?.localChannelsJson), externalChannels: objectJson(row?.externalChannelsJson), externalGuildId: row?.externalGuildId ?? null, externalChannelId: row?.externalChannelId ?? null, externalAuthorizedBy: row?.externalAuthorizedBy ?? null,
        ignoredChannels: idList(row?.ignoredChannelIds), ignoredRoles: idList(row?.ignoredRoleIds), ignoreBots: row?.ignoreBots ?? true, configured: !!row };
}
const cache = new Map();
function clearLogSettingsCache(id) { if (id)
    cache.delete(id);
else
    cache.clear(); }
async function readLogSettings(guildId, fresh = false) {
    const existing = cache.get(guildId);
    if (!fresh && existing && existing.until > Date.now())
        return existing.value;
    const value = normalizeSettings(await prisma_1.prisma.serverLogSettings.findUnique({ where: { guildId } }), guildId);
    if (cache.size >= 500)
        cache.delete(cache.keys().next().value);
    cache.set(guildId, { until: Date.now() + 2000, value });
    return value;
}
async function saveLogSettings(guildId, data) {
    await prisma_1.prisma.serverLogSettings.upsert({ where: { guildId }, create: { guildId, ...data }, update: data });
    clearLogSettingsCache(guildId);
    return readLogSettings(guildId, true);
}
