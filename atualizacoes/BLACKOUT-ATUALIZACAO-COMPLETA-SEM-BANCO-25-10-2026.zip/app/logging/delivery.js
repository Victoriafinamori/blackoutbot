"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.logHealth = logHealth;
exports.usableLogChannel = usableLogChannel;
exports.validateExternal = validateExternal;
exports.ignoredLog = ignoredLog;
exports.resolveLocalLogChannel = resolveLocalLogChannel;
exports.deliverLog = deliverLog;
exports.emitLog = emitLog;
exports.flushLogs = flushLogs;
const discord_js_1 = require("discord.js");
const permissions_1 = require("../utils/permissions");
const guildConfig_1 = require("../database/guildConfig");
const config_1 = require("./config");
const health = new Map();
function logHealth(guildId) { let h = health.get(guildId); if (!h) {
    if (health.size >= 500)
        health.delete(health.keys().next().value);
    h = { sent: 0, failed: 0, skipped: 0, dropped: 0, lastError: null, lastSuccess: null };
    health.set(guildId, h);
} return h; }
const legacyColumns = { moderation: "moderationLogChannelId", security: "securityLogChannelId", system: "systemLogChannelId", reintegration: "reintegrationLogChannelId", members: "securityLogChannelId" };
async function usableLogChannel(guild, id) {
    const ch = await guild.channels.fetch(id).catch(() => null);
    if (!ch || ch.guildId !== guild.id || ![discord_js_1.ChannelType.GuildText, discord_js_1.ChannelType.GuildAnnouncement].includes(ch.type))
        throw Error("Canal de logs excluído, inacessível ou de tipo incompatível.");
    const me = guild.members.me ?? await guild.members.fetchMe();
    if (!ch.permissionsFor(me)?.has([discord_js_1.PermissionFlagsBits.ViewChannel, discord_js_1.PermissionFlagsBits.SendMessages, discord_js_1.PermissionFlagsBits.EmbedLinks]))
        throw Error("O bot precisa ver o canal e enviar mensagens e embeds no destino.");
    return ch;
}
async function validateExternal(source, settings, actorId) {
    if (!settings.externalGuildId || settings.externalGuildId === source.id)
        throw Error("Escolha outro servidor de destino onde o bot esteja presente.");
    const guild = await source.client.guilds.fetch(settings.externalGuildId).catch(() => null);
    if (!guild)
        throw Error("O bot não está no servidor externo ou não conseguiu acessá-lo.");
    const authorizer = actorId ?? settings.externalAuthorizedBy;
    if (!authorizer)
        throw Error("Configure o destino com um administrador autorizado nos dois servidores.");
    const sourceMember = await source.members.fetch({ user: authorizer, force: true }).catch(() => null);
    if (!sourceMember || !await (0, permissions_1.isBotAdmin)(sourceMember))
        throw Error("O responsável perdeu o acesso de administrador do bot no servidor de origem. Um administrador autorizado deve reconfigurar o destino.");
    const member = await guild.members.fetch({ user: authorizer, force: true }).catch(() => null);
    if (!member || !(member.permissions.has(discord_js_1.PermissionFlagsBits.Administrator) || member.permissions.has(discord_js_1.PermissionFlagsBits.ManageGuild)))
        throw Error("O responsável pela configuração precisa de Administrador ou Gerenciar Servidor no destino externo.");
    if (!settings.externalChannelId)
        throw Error("Configure o canal geral do servidor externo.");
    await usableLogChannel(guild, settings.externalChannelId);
    return guild;
}
function ignoredLog(settings, guild, ctx) {
    if (ctx.userId === guild.client.user?.id)
        return true; // Never log this application's own messages/changes recursively.
    if (settings.ignoreBots && ctx.bot)
        return true;
    if (ctx.roleIds?.some(id => settings.ignoredRoles.includes(id)))
        return true;
    if (ctx.channelIds?.some(id => { let current = id; for (let level = 0; current && level < 4; level++) {
        if (settings.ignoredChannels.includes(current))
            return true;
        current = guild.channels.cache.get(current)?.parentId;
    } return false; }))
        return true;
    return false;
}
async function resolveLocalLogChannel(guild, group, settings, override) {
    const config = await (0, guildConfig_1.getOrCreateGuildConfig)(guild.id);
    const id = Object.prototype.hasOwnProperty.call(settings.localChannels, group) ? (settings.localChannels[group] ?? config.logChannelId) : (override ?? config[legacyColumns[group]] ?? config.logChannelId);
    return id ? usableLogChannel(guild, id) : null;
}
function stamped(guild, key, embed) {
    const data = embed.toJSON();
    // Preserve all original fields, trimming the tail only if the Discord 6000-character total is reached.
    const e = new discord_js_1.EmbedBuilder(data).setAuthor({ name: `${guild.name} · ${guild.id}`.slice(0, 256) }).setFooter({ text: `Origem: ${guild.id} · ${config_1.LOG_GROUPS[config_1.LOG_EVENTS[key].group]}` }).setTimestamp(data.timestamp ? new Date(data.timestamp) : new Date());
    while (e.length > 5900 && e.data.fields?.length)
        e.spliceFields(e.data.fields.length - 1, 1);
    if (e.length > 5900)
        e.setDescription((e.data.description ?? "").slice(0, 1500));
    return e;
}
async function deliverLog(guild, key, embed, ctx = {}, test = false, modeOverride) {
    const info = config_1.LOG_EVENTS[key];
    if (!info)
        return { sent: 0, errors: ["Evento de log desconhecido."] };
    const s = await (0, config_1.readLogSettings)(guild.id), h = logHealth(guild.id);
    if (!test && (!s.events[key] || ignoredLog(s, guild, ctx) || (s.ignoredRoles.length > 0 && ctx.roleIds == null && ["members", "voice", "messages"].includes(info.group)))) {
        h.skipped++;
        return { sent: 0, errors: [] };
    }
    const mode = test && ["LOCAL", "EXTERNAL", "BOTH"].includes(modeOverride ?? "") ? modeOverride : s.deliveryMode;
    const jobs = [];
    if (mode !== "EXTERNAL")
        jobs.push(() => resolveLocalLogChannel(guild, info.group, s, ctx.localOverrideId));
    if (mode !== "LOCAL")
        jobs.push(async () => { const target = await validateExternal(guild, s); return usableLogChannel(target, s.externalChannels[info.group] ?? s.externalChannelId); });
    let sent = 0;
    const errors = [];
    const message = stamped(guild, key, embed);
    for (const getChannel of jobs) {
        try {
            const ch = await getChannel();
            if (!ch) {
                errors.push("Nenhum canal local configurado para este evento.");
                continue;
            }
            await ch.send({ embeds: [message], allowedMentions: { parse: [] } });
            sent++;
            h.sent++;
            h.lastSuccess = Date.now();
        }
        catch (error) {
            errors.push(error.message || "Falha ao enviar o registro.");
        }
    }
    if (errors.length) {
        h.failed += errors.length;
        h.lastError = errors.join(" ").slice(0, 400);
    }
    return { sent, errors };
}
const queue = [];
let running = null;
async function drain() {
    while (queue.length) {
        const j = queue.shift();
        try {
            await deliverLog(j.guild, j.key, j.embed, j.ctx);
        }
        catch (error) {
            const h = logHealth(j.guild.id);
            h.failed++;
            h.lastError = "Não foi possível carregar ou enviar os logs. Confira o banco e o destino.";
        }
    }
}
function startWorker() { if (!running)
    running = drain().finally(() => { running = null; if (queue.length)
        startWorker(); }); }
/** Bounded in-process queue. Discord.js handles HTTP rate limits; event handlers never throw on delivery errors. */
function emitLog(guild, key, embed, ctx = {}) {
    if (queue.length >= 300 || queue.filter(j => j.guild.id === guild.id).length >= 100) {
        logHealth(guild.id).dropped++;
        return Promise.resolve();
    }
    queue.push({ guild, key, embed, ctx });
    startWorker();
    return Promise.resolve();
}
async function flushLogs() { while (running)
    await running; }
