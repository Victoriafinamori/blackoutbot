"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.voiceLog = voiceLog;
exports.messageEdited = messageEdited;
exports.messageDeleted = messageDeleted;
exports.messagesDeleted = messagesDeleted;
exports.memberChanged = memberChanged;
exports.channelChanged = channelChanged;
exports.roleChanged = roleChanged;
exports.guildChanged = guildChanged;
exports.auditEntry = auditEntry;
exports.runLogEvent = runLogEvent;
const discord_js_1 = require("discord.js");
const config_1 = require("./config");
const delivery_1 = require("./delivery");
const clip = (s, max = 950) => String(s ?? "Indisponível").slice(0, max) || "(vazio)";
const mention = (id) => id ? `<@${id}> · ${id}` : "Autor indisponível";
const channel = (id) => id ? `<#${id}> · ${id}` : "Fora de call";
function ctx(member, channelIds = []) { return { userId: member?.id, bot: member?.user?.bot, roleIds: member?.roles?.cache?.map((r) => r.id), channelIds }; }
async function enabled(guild, key) { return guild && (await (0, config_1.readLogSettings)(guild.id)).events[key]; }
async function record(guild, key, fields, context = {}) {
    if (!guild || !await enabled(guild, key))
        return;
    const e = new discord_js_1.EmbedBuilder().setColor(0xd71935).setTitle(config_1.LOG_EVENTS[key].label).setTimestamp().addFields(fields.slice(0, 12).map(f => ({ name: f.name.slice(0, 256), value: clip(f.value) })));
    return (0, delivery_1.emitLog)(guild, key, e, context);
}
async function voiceLog(old, next) {
    const guild = next.guild ?? old.guild, member = next.member ?? old.member;
    const channels = [old.channelId, next.channelId, old.channel?.parentId, next.channel?.parentId].filter(Boolean);
    if (old.channelId !== next.channelId) {
        const key = !old.channelId ? "voice.join" : !next.channelId ? "voice.leave" : "voice.move";
        await record(guild, key, [{ name: "Membro", value: mention(next.id ?? old.id) }, { name: "Antes", value: channel(old.channelId) }, { name: "Depois", value: channel(next.channelId) }, { name: "Responsável pela movimentação", value: "Não identificado pelo evento de voz." }], ctx(member, channels));
    }
    const keys = [['selfMute', 'Microfone desligado pelo membro'], ['selfDeaf', 'Áudio desligado pelo membro'], ['serverMute', 'Silêncio pelo servidor'], ['serverDeaf', 'Áudio desativado pelo servidor']];
    const changes = keys.filter(([k]) => old[k] !== next[k]).map(([k, label]) => `${label}: ${old[k] ? "sim" : "não"} → ${next[k] ? "sim" : "não"}`);
    if (old.channelId && next.channelId && changes.length)
        await record(guild, "voice.state", [{ name: "Membro", value: mention(next.id) }, { name: "Canal", value: channel(next.channelId) }, { name: "Alterações", value: changes.join("\n") }, { name: "Responsável", value: "Estados próprios identificados acima; executor de alterações do servidor não identificado." }], ctx(member, channels));
}
function messageContext(m) { return { ...ctx(m.member ?? m.guild?.members?.cache?.get(m.author?.id), [m.channelId, m.channel?.parentId].filter(Boolean)), userId: m.author?.id, bot: m.author?.bot ?? !!m.webhookId }; }
function attachmentList(m) { return m.attachments?.map((a) => `${a.name ?? "Arquivo"}: ${a.url}`).join("\n") || "Nenhum anexo disponível"; }
async function messageEdited(old, next) {
    if (!next.guild || !await enabled(next.guild, "message.edit"))
        return;
    // Fetching a partial cannot recover an old version. Never label fetched content as 'before'.
    const before = old.partial || typeof old.content !== "string" ? "Conteúdo anterior indisponível (fora do cache)." : old.content;
    if (next.partial) {
        try {
            next = await next.fetch();
        }
        catch {
            return;
        }
    }
    if (!old.partial && old.content === next.content && attachmentList(old) === attachmentList(next))
        return;
    return record(next.guild, "message.edit", [{ name: "Autor", value: mention(next.author?.id) }, { name: "Canal", value: channel(next.channelId) }, { name: "Mensagem", value: `${next.id}\nhttps://discord.com/channels/${next.guild.id}/${next.channelId}/${next.id}` }, { name: "Antes", value: before }, { name: "Depois", value: next.content }, { name: "Anexos antes", value: old.partial ? "Indisponíveis" : attachmentList(old) }, { name: "Anexos depois", value: attachmentList(next) }], messageContext(next));
}
async function messageDeleted(m) {
    return record(m.guild, "message.delete", [{ name: "Autor", value: mention(m.author?.id) }, { name: "Canal", value: channel(m.channelId) }, { name: "Mensagem", value: m.id }, { name: "Conteúdo disponível", value: m.partial || typeof m.content !== "string" ? "Indisponível: a mensagem não estava no cache." : m.content }, { name: "Anexos disponíveis", value: attachmentList(m) }, { name: "Responsável pela exclusão", value: "Não identificado. O evento não informa quem excluiu a mensagem." }], messageContext(m));
}
async function messagesDeleted(messages, sourceChannel) {
    const list = [...messages.values()], guild = sourceChannel?.guild ?? list[0]?.guild;
    if (!guild || !await enabled(guild, "message.bulk"))
        return;
    const s = await (0, config_1.readLogSettings)(guild.id);
    const kept = list.filter(m => { const c = messageContext(m); return c.userId !== guild.client.user?.id && !(s.ignoreBots && c.bot) && !(s.ignoredRoles.length > 0 && c.roleIds == null) && !c.roleIds?.some(id => s.ignoredRoles.includes(id)); });
    if (!kept.length)
        return;
    const excerpts = kept.slice(0, 10).map(m => `${m.id} · ${m.author?.id ?? "autor indisponível"}: ${m.partial || typeof m.content !== "string" ? "conteúdo indisponível" : m.content.slice(0, 90)}`);
    return record(guild, "message.bulk", [{ name: "Canal", value: channel(sourceChannel?.id ?? list[0]?.channelId) }, { name: "Mensagens excluídas", value: `${list.length} no evento · ${kept.length} após os filtros.` }, { name: "Amostra do conteúdo disponível", value: excerpts.join("\n") }, { name: "Limite da amostra", value: "Até dez mensagens, com texto resumido. Não é um transcript completo." }, { name: "Responsável pela exclusão", value: "Não identificado pelo evento de exclusão em massa." }], { roleIds: [], channelIds: [sourceChannel?.id, sourceChannel?.parentId, list[0]?.channelId].filter(Boolean) });
}
async function memberChanged(old, next) {
    const context = ctx(next);
    if (!old.partial && old.nickname !== next.nickname)
        await record(next.guild, "member.nickname", [{ name: "Membro", value: mention(next.id) }, { name: "Antes", value: old.nickname ?? "Sem apelido" }, { name: "Depois", value: next.nickname ?? "Sem apelido" }], context);
    if (!old.partial && old.roles?.cache && next.roles?.cache) {
        const added = next.roles.cache.filter((r) => !old.roles.cache.has(r.id)), removed = old.roles.cache.filter((r) => !next.roles.cache.has(r.id));
        if (added.size || removed.size)
            await record(next.guild, "member.roles", [{ name: "Membro", value: mention(next.id) }, { name: "Cargos adicionados", value: added.map((r) => `<@&${r.id}>`).join(", ") || "Nenhum" }, { name: "Cargos removidos", value: removed.map((r) => `<@&${r.id}>`).join(", ") || "Nenhum" }], { ...context, roleIds: [...new Set([...(context.roleIds ?? []), ...old.roles.cache.map((r) => r.id)])] });
    }
}
const permissionLabels = { Administrator: "Administrador", ManageGuild: "Gerenciar servidor", ManageChannels: "Gerenciar canais", ManageRoles: "Gerenciar cargos", ViewChannel: "Ver canal", SendMessages: "Enviar mensagens", ReadMessageHistory: "Ler histórico", KickMembers: "Expulsar membros", BanMembers: "Banir membros", ModerateMembers: "Moderar membros", ViewAuditLog: "Ver auditoria", Connect: "Conectar", Speak: "Falar", MuteMembers: "Silenciar membros", DeafenMembers: "Desativar áudio", MoveMembers: "Mover membros", MentionEveryone: "Marcar everyone", ManageMessages: "Gerenciar mensagens", AttachFiles: "Anexar arquivos", EmbedLinks: "Inserir links", ManageWebhooks: "Gerenciar webhooks", CreateInstantInvite: "Criar convites" };
function permissions(bits) { try {
    return new discord_js_1.PermissionsBitField(bits ?? 0n).toArray().map(key => permissionLabels[key] ?? key.replace(/([a-z])([A-Z])/g, "$1 $2")).join(", ") || "Nenhuma";
}
catch {
    return "Indisponíveis";
} }
function overwriteChanges(old, next) {
    const a = old.permissionOverwrites?.cache, b = next.permissionOverwrites?.cache;
    if (!a || !b)
        return "Permissões do canal alteradas.";
    const ids = [...new Set([...a.keys(), ...b.keys()])];
    return ids.flatMap(id => {
        const before = a.get(id), after = b.get(id);
        if (before?.allow.bitfield === after?.allow.bitfield && before?.deny.bitfield === after?.deny.bitfield)
            return [];
        const target = `${(after ?? before).type === 0 ? "Cargo" : "Membro"} ${id}`;
        if (!after)
            return [`${target}: regra removida.`];
        return [`${target}: permitir ${permissions(after.allow.bitfield)}; negar ${permissions(after.deny.bitfield)}.`];
    }).slice(0, 6).join("\n").slice(0, 650) || "Permissões do canal alteradas.";
}
function overwrites(ch) { return ch.permissionOverwrites?.cache?.map((p) => `${p.id}:${p.type}:${p.allow.bitfield}:${p.deny.bitfield}`).sort().join("|") ?? ""; }
async function channelChanged(kind, old, next) {
    const ch = next ?? old, key = `channel.${kind}`, fields = [{ name: "Canal", value: `${ch.name} · ${ch.id}` }, { name: "Responsável", value: "Não identificado pelo evento. Consulte a auditoria nativa para apurar o executor." }];
    if (kind === "update") {
        const changes = [old.name !== next.name ? `Nome: ${old.name} → ${next.name}` : null, old.parentId !== next.parentId ? `Categoria: ${old.parentId ?? "nenhuma"} → ${next.parentId ?? "nenhuma"}` : null, old.topic !== next.topic ? `Tópico: ${clip(old.topic, 250)} → ${clip(next.topic, 250)}` : null, overwrites(old) !== overwrites(next) ? overwriteChanges(old, next) : null, old.nsfw !== next.nsfw ? `Restrição etária: ${!!old.nsfw} → ${!!next.nsfw}` : null, old.rateLimitPerUser !== next.rateLimitPerUser ? `Modo lento: ${old.rateLimitPerUser ?? 0}s → ${next.rateLimitPerUser ?? 0}s` : null].filter(Boolean);
        if (!changes.length)
            return;
        fields.push({ name: "Alterações", value: changes.join("\n") });
    }
    return record(ch.guild, key, fields, { channelIds: [ch.id, ch.parentId, old.parentId].filter(Boolean) });
}
async function roleChanged(kind, old, next) {
    const r = next ?? old, key = `role.${kind}`, fields = [{ name: "Cargo", value: `${r.name} · ${r.id}` }, { name: "Permissões atuais", value: permissions(r.permissions?.bitfield) }, { name: "Responsável", value: "Não identificado pelo evento. Consulte a auditoria nativa para apurar o executor." }];
    if (kind === "update") {
        const changes = [old.name !== r.name ? `Nome: ${old.name} → ${r.name}` : null, old.permissions?.bitfield !== r.permissions?.bitfield ? `Permissões antes: ${permissions(old.permissions?.bitfield)}\nPermissões depois: ${permissions(r.permissions?.bitfield)}` : null, old.color !== r.color ? `Cor: ${old.hexColor} → ${r.hexColor}` : null, old.hoist !== r.hoist ? `Exibição separada: ${old.hoist} → ${r.hoist}` : null, old.mentionable !== r.mentionable ? `Mencionável: ${old.mentionable} → ${r.mentionable}` : null].filter(Boolean);
        if (!changes.length)
            return;
        fields.push({ name: "Alterações", value: changes.join("\n") });
    }
    return record(r.guild, key, fields, { roleIds: [r.id] });
}
async function guildChanged(old, next) {
    const changes = [old.name !== next.name ? `Nome: ${old.name} → ${next.name}` : null, old.verificationLevel !== next.verificationLevel ? `Nível de verificação: ${old.verificationLevel} → ${next.verificationLevel}` : null, old.explicitContentFilter !== next.explicitContentFilter ? `Filtro de mídia: ${old.explicitContentFilter} → ${next.explicitContentFilter}` : null, old.defaultMessageNotifications !== next.defaultMessageNotifications ? "Padrão de notificações alterado." : null].filter(Boolean);
    if (changes.length)
        return record(next, "guild.update", [{ name: "Alterações", value: changes.join("\n") }, { name: "Responsável", value: "Não identificado pelo evento; consulte a auditoria nativa." }]);
}
async function auditEntry(entry, guild) {
    const key = entry.action === discord_js_1.AuditLogEvent.MemberBanAdd ? "moderation.ban" : entry.action === discord_js_1.AuditLogEvent.MemberBanRemove ? "moderation.unban" : null;
    if (!key || entry.executorId === guild.client.user?.id)
        return; // Bot sanctions already have their own AdminLog record.
    return record(guild, key, [{ name: "Membro", value: mention(entry.targetId) }, { name: "Responsável confirmado pela auditoria", value: mention(entry.executorId) }, { name: "Motivo", value: entry.reason ?? "Não informado" }, { name: "Entrada de auditoria", value: entry.id }], { ...ctx(guild.members.cache?.get(entry.targetId)), userId: entry.targetId, bot: entry.target?.bot });
}
async function runLogEvent(fn) { try {
    await fn();
}
catch (error) {
    console.error("[log-center] Falha ao processar evento de log; verifique a configuração e o banco.");
} }
