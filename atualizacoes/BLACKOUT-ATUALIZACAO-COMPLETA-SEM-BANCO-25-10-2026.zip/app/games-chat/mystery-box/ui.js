"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mysteryView = mysteryView;
const discord_js_1 = require("discord.js");
const common_1 = require("../experience/common");
function mysteryView(event, config, offset = 0) {
    const opened = event.boxes.filter((box) => box.status === "OPENED"), active = event.status === "ACTIVE", rewardByUser = new Map();
    for (const opening of event.openings) {
        try {
            rewardByUser.set(opening.userId, JSON.parse(opening.rewardSnapshot).name || "Recompensa");
        }
        catch {
            rewardByUser.set(opening.userId, "Recompensa");
        }
    }
    const results = opened
        .slice()
        .sort((a, b) => a.number - b.number)
        .slice(0, 5)
        .map((box) => `Caixa ${box.number} · <@${box.openedById}> · ${(0, common_1.clean)(rewardByUser.get(box.openedById) || "Recompensa", 60)}`)
        .join("\n") || "Nenhuma caixa foi aberta.";
    const e = new discord_js_1.EmbedBuilder()
        .setColor(Number.isNaN(parseInt(config.color, 16))
        ? 0xd71935
        : parseInt(config.color, 16))
        .setTitle(config.title)
        .setDescription(config.description)
        .addFields({
        name: "Como participar",
        value: "Escolha uma caixa disponível. Cada pessoa pode abrir uma única caixa neste evento.",
    }, {
        name: "Tempo restante",
        value: active
            ? `<t:${Math.floor(new Date(event.endsAt).getTime() / 1000)}:R>`
            : "Evento encerrado",
        inline: true,
    }, {
        name: "Disponíveis",
        value: String(event.boxes.length - opened.length),
        inline: true,
    }, {
        name: "Aberturas",
        value: `${opened.length}/${event.boxes.length}`,
        inline: true,
    }, {
        name: "Resultados do evento",
        value: results +
            (opened.length > 5 ? "\nVeja a lista completa em Resultados." : ""),
    });
    if (config.image)
        e.setImage(config.image);
    if (config.thumbnail)
        e.setThumbnail(config.thumbnail);
    if (config.footer)
        e.setFooter({ text: config.footer });
    const start = Math.max(0, Math.min(Number(offset) || 0, Math.max(0, event.boxes.length - 1))), boxes = event.boxes.slice(start, start + 20), rows = [];
    for (let n = 0; n < boxes.length; n += 5)
        rows.push(new discord_js_1.ActionRowBuilder().addComponents(...boxes.slice(n, n + 5).map((box) => new discord_js_1.ButtonBuilder()
            .setCustomId(`mystery-open:${event.id}:${box.number}`)
            .setLabel(`${(0, common_1.clean)(config.buttonLabel || "Caixa", 50)} ${String(box.number).padStart(2, "0")}${box.status === "OPENED" ? " · Aberta" : ""}`)
            .setStyle(box.status === "OPENED"
            ? discord_js_1.ButtonStyle.Secondary
            : discord_js_1.ButtonStyle.Primary)
            .setDisabled(!active || box.status === "OPENED"))));
    const controls = [
        new discord_js_1.ButtonBuilder()
            .setCustomId(`mystery-panel:mine:${event.id}`)
            .setLabel("Meu resultado")
            .setStyle(discord_js_1.ButtonStyle.Secondary),
        new discord_js_1.ButtonBuilder()
            .setCustomId(`mystery-panel:results:${event.id}:0`)
            .setLabel("Resultados")
            .setStyle(discord_js_1.ButtonStyle.Secondary),
        new discord_js_1.ButtonBuilder()
            .setCustomId(`mystery-panel:help:${event.id}`)
            .setLabel("Como jogar")
            .setStyle(discord_js_1.ButtonStyle.Secondary),
    ];
    if (start > 0)
        controls.push(new discord_js_1.ButtonBuilder()
            .setCustomId(`mystery-panel:more:${event.id}:0`)
            .setLabel("Caixas anteriores")
            .setStyle(discord_js_1.ButtonStyle.Secondary));
    if (start + 20 < event.boxes.length)
        controls.push(new discord_js_1.ButtonBuilder()
            .setCustomId(`mystery-panel:more:${event.id}:${start + 20}`)
            .setLabel("Mais caixas")
            .setStyle(discord_js_1.ButtonStyle.Secondary));
    rows.push(new discord_js_1.ActionRowBuilder().addComponents(controls));
    return {
        embeds: [e],
        components: rows,
        allowedMentions: { parse: [] },
    };
}
