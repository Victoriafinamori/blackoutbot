"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.execute = execute;
const common_1 = require("../experience/common");
const manager_1 = require("./manager");
const config_1 = require("../core/config");
async function execute(i) {
    return (0, common_1.guard)(i, async () => {
        if (!i.guild)
            return;
        await (0, common_1.member)(i.guild, i.user.id);
        const [, action, id, arg] = i.customId.split(":"), event = await (0, manager_1.getMysteryEvent)(id);
        if (!event || event.guildId !== i.guild.id)
            throw Error("Este evento não pertence a este servidor.");
        const render = async () => {
            if (action === "more")
                return require("./ui").mysteryView(event, await (0, config_1.mysteryConfig)(i.guild.id), Math.max(0, Math.min(Number(arg) || 0, 20)));
            if (action === "help")
                return (0, common_1.payload)((0, common_1.embed)("Como jogar Caixa Misteriosa", "Escolha uma caixa disponível durante o evento. Cada membro pode abrir uma única caixa; caixas já abertas ficam indisponíveis. Seu resultado fica salvo. A entrega externa só é concluída quando a integração ou a equipe a confirma."));
            if (action === "mine") {
                const own = event.openings.find((o) => o.userId === i.user.id);
                if (!own)
                    return (0, common_1.payload)((0, common_1.embed)("Você ainda não abriu uma caixa", "Escolha uma caixa disponível no painel do evento."));
                const snapshot = JSON.parse(own.rewardSnapshot), delivery = await common_1.prisma.mysteryDelivery.findUnique({
                    where: { openingId: own.id },
                }), status = {
                    DELIVERED: "Entregue",
                    PENDING: "Em processamento",
                    PENDING_EXTERNAL: "Aguardando integração ou confirmação externa",
                    FAILED: "Falhou · A equipe pode consultar o registro",
                    EXPIRED: "Recompensa temporária encerrada",
                };
                return (0, common_1.payload)((0, common_1.embed)("Sua Caixa Misteriosa", (0, common_1.clean)(snapshot.name, 100)).addFields({
                    name: "Entrega",
                    value: status[delivery?.status || "PENDING"] || "Consulte a equipe",
                }));
            }
            const page = Math.max(0, Math.min(Number(arg) || 0, Math.max(0, Math.ceil(event.openings.length / 5) - 1))), results = event.openings.slice(page * 5, page * 5 + 5);
            return (0, common_1.payload)((0, common_1.embed)("Resultados da Caixa Misteriosa", results
                .map((o) => `<@${o.userId}> · ${(0, common_1.clean)(JSON.parse(o.rewardSnapshot).name, 100)}`)
                .join("\n") || "Nenhuma caixa foi aberta.").setFooter({
                text: `Página ${page + 1} · ${event.openings.length} aberturas registradas`,
            }), [
                (0, common_1.row)((0, common_1.button)(`mystery-panel:results:${id}:${page - 1}`, "Anterior", 2, page === 0), (0, common_1.button)(`mystery-panel:results:${id}:${page + 1}`, "Próxima", 2, (page + 1) * 5 >= event.openings.length), (0, common_1.button)(`mystery-panel:mine:${id}`, "Meu resultado")),
            ]);
        };
        if (i.message?.flags?.has?.(common_1.D.MessageFlags.Ephemeral)) {
            await i.deferUpdate();
            return i.editReply(await render());
        }
        await i.deferReply({ flags: common_1.D.MessageFlags.Ephemeral });
        return i.editReply(await render());
    });
}
