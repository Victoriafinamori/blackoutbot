"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.publicView = publicView;
exports.adminView = adminView;
exports.publish = publish;
exports.playView = playView;
exports.player = player;
exports.admin = admin;
exports.select = select;
exports.modal = modal;
exports.refreshPublished = refreshPublished;
const common_1 = require("./common");
const adminUi_1 = require("../../utils/adminUi");
const panelInteraction_1 = require("../../utils/panelInteraction");
const config_1 = require("../core/config");
const config = (guildId) => common_1.prisma.gamesHubConfig.upsert({
    where: { guildId },
    create: { guildId },
    update: {},
});
exports.config = config;
async function publicView(guild, preview = false, styleOverride = {}) {
    const [c, g, t, m, b, box, legacy] = await Promise.all([
        (0, exports.config)(guild.id),
        (0, config_1.gamesConfig)(guild.id),
        (0, config_1.termoConfig)(guild.id),
        (0, config_1.mysteryConfig)(guild.id),
        common_1.prisma.bingoExperienceState.findFirst({
            where: {
                guildId: guild.id,
                phase: { in: ["LOBBY", "RUNNING", "PAUSED", "REVIEW"] },
            },
            orderBy: { updatedAt: "desc" },
        }),
        common_1.prisma.mysteryEvent.findFirst({
            where: { guildId: guild.id, status: "ACTIVE" },
        }),
        common_1.prisma.bingoMatch.findFirst({
            where: { guildId: guild.id, status: { in: ["EM_ANDAMENTO", "PAUSADA"] } },
        }),
    ]);
    const style = { ...c, ...styleOverride };
    return (0, common_1.payload)((0, common_1.embed)(style.title, style.description)
        .setColor(Number.isNaN(parseInt(style.color, 16))
        ? 0xd71935
        : parseInt(style.color, 16))
        .addFields({
        name: "Jogar no seu ritmo",
        value: t.enabled && g.enabled
            ? "TERMO diário · Um desafio por dia, com tabuleiro privado."
            : "TERMO diário · Aguardando ativação da equipe.",
    }, {
        name: "Eventos em grupo",
        value: `Bingo: ${b ? (b.phase === "LOBBY" ? "inscrições abertas" : "partida aberta") : legacy ? "partida em andamento" : "aguardando novo evento"}\nCaixa Misteriosa: ${box && m.enabled ? "caixas disponíveis" : "aguardando evento"}\nQuiz em equipes: participe quando a equipe abrir inscrições.`,
    })
        .setFooter(style.footer ? { text: style.footer } : null), [
        (0, common_1.row)((0, common_1.button)("play:termo", "TERMO diário", common_1.D.ButtonStyle.Primary, preview || !g.enabled || !t.enabled), (0, common_1.button)("play:bingo", "Bingo da comunidade", common_1.D.ButtonStyle.Secondary, preview), (0, common_1.button)("play:mystery", "Caixa Misteriosa", common_1.D.ButtonStyle.Secondary, preview || !g.enabled || !m.enabled), (0, common_1.button)("play:quiz", "Quiz em equipes", common_1.D.ButtonStyle.Secondary, preview)),
        (0, common_1.row)((0, common_1.button)("play:ranking", "Rankings do TERMO", common_1.D.ButtonStyle.Secondary, preview || !t.enabled || !g.enabled), (0, common_1.button)("play:help", "Como participar", common_1.D.ButtonStyle.Secondary, preview)),
    ]);
}
async function adminView(guild, appearance = false) {
    const c = await (0, exports.config)(guild.id);
    if (appearance)
        return {
            ...(await publicView(guild, true)),
            content: "**Prévia · Painel de jogos**\nAs alterações salvas aparecem abaixo. Publicar ou atualizar o painel é uma ação separada.",
            components: [
                (0, common_1.row)((0, common_1.button)("games-admin:edit", "Editar mensagem"), (0, common_1.button)("games-admin:publish", "Publicar / atualizar", common_1.D.ButtonStyle.Primary), (0, common_1.button)("games-admin:home", "Voltar")),
            ],
        };
    const select = new common_1.D.ChannelSelectMenuBuilder()
        .setCustomId("games-select:channel")
        .setPlaceholder("Canal do painel de jogos")
        .addChannelTypes(common_1.D.ChannelType.GuildText);
    if (c.channelId)
        select.setDefaultChannels(c.channelId);
    return {
        attachments: [],
        ...(0, common_1.payload)((0, adminUi_1.adminEmbed)(guild, "staff")
            .setTitle("Participação nos jogos")
            .setDescription("Um painel para descobrir os jogos, continuar uma partida e encontrar os eventos abertos.")
            .addFields({
            name: "Painel público",
            value: `Canal: ${c.channelId ? "<#" + c.channelId + ">" : "Não configurado"}\n${c.messageId ? "Já publicado" : "Ainda não publicado"}`,
        }, {
            name: "Caixa Misteriosa",
            value: c.mysteryIndividualAnnouncements
                ? "Além do resumo do evento, cada abertura recebe anúncio no canal."
                : "Resultados reunidos no painel do evento. O membro recebe seu resultado em particular.",
        }), [
            (0, common_1.row)(select),
            (0, common_1.row)((0, common_1.button)("games-admin:appearance", "Mensagem e prévia"), (0, common_1.button)("games-admin:publish", "Publicar / atualizar", common_1.D.ButtonStyle.Primary), (0, common_1.button)("games-admin:announcements", c.mysteryIndividualAnnouncements
                ? "Desativar anúncios por caixa"
                : "Ativar anúncios por caixa")),
            (0, common_1.row)((0, common_1.button)("bg-admin:home", "Bingo comunitário"), (0, common_1.button)("games-admin:war", "Quiz em equipes"), (0, common_1.button)("adm-nav:staff", "Voltar a Jogos e eventos")),
        ]),
    };
}
async function publish(guild) {
    const c = await (0, exports.config)(guild.id), ch = await (0, common_1.textChannel)(guild, c.channelId), view = await publicView(guild), existing = c.messageId
        ? await ch.messages.fetch(c.messageId).catch(() => null)
        : null;
    const message = existing ? await existing.edit(view) : await ch.send(view);
    await common_1.prisma.gamesHubConfig.update({
        where: { guildId: guild.id },
        data: {
            messageId: message.id,
            publishedHash: require("node:crypto")
                .createHash("sha256")
                .update(JSON.stringify(view))
                .digest("hex"),
            publishedStyle: JSON.stringify({
                title: c.title,
                description: c.description,
                color: c.color,
                footer: c.footer,
            }),
        },
    });
    return message;
}
async function playView(guild, userId, action) {
    if (action === "termo")
        return require("../termo/ui").termoPlayerView(guild, userId);
    if (action === "ranking")
        return require("../termo/ui").termoRankingView(guild);
    if (action === "bingo") {
        const state = await common_1.prisma.bingoExperienceState.findFirst({
            where: {
                guildId: guild.id,
                phase: { in: ["LOBBY", "RUNNING", "PAUSED", "REVIEW"] },
            },
            orderBy: { updatedAt: "desc" },
        });
        if (!state) {
            const cards = await require("../../bingo/service").getAllActiveCardsForPlayer(guild.id, userId);
            if (cards.length)
                return require("../../bingo/cardAccess").view(guild, userId);
            return (0, common_1.payload)((0, common_1.embed)("Bingo da comunidade", "Não há inscrições comunitárias abertas agora. A equipe pode preparar o próximo evento."));
        }
        const cards = await common_1.prisma.bingoCard.count({
            where: { guildId: guild.id, matchId: state.matchId, playerId: userId },
        });
        return cards
            ? require("../../bingo/communityViews").cardsView(guild, state.matchId, userId)
            : require("../../bingo/communityViews").publicView(guild, state.matchId);
    }
    if (action === "mystery") {
        const c = await (0, config_1.gamesConfig)(guild.id);
        if (!c.enabled)
            throw Error("Os jogos de chat estão desativados.");
        const event = await common_1.prisma.mysteryEvent.findFirst({
            where: { guildId: guild.id, status: "ACTIVE" },
        });
        if (!event)
            return (0, common_1.payload)((0, common_1.embed)("Caixa Misteriosa", "Aguarde a equipe abrir o próximo evento. Cada participante poderá abrir uma caixa."));
        const full = await require("../mystery-box/manager").getMysteryEvent(event.id), settings = await (0, config_1.mysteryConfig)(guild.id);
        if (!settings.enabled)
            throw Error("A Caixa Misteriosa está desativada.");
        return require("../mystery-box/ui").mysteryView(full, settings);
    }
    if (action === "quiz") {
        const repo = require("../../../app/war/repository"), game = await repo.activeGame(guild.id);
        if (!game)
            return (0, common_1.payload)((0, common_1.embed)("Quiz em equipes", "A equipe ainda não abriu inscrições. Quando abrir, escolha um dos times no painel do evento."));
        const view = await require("../../../app/war/views").gameView(guild, game);
        view.components = view.components
            .map((r) => {
            const json = r.toJSON();
            json.components = json.components.filter((c) => !c.custom_id?.startsWith("war:start:"));
            return json;
        })
            .filter((r) => r.components.length);
        return view;
    }
    return (0, common_1.payload)((0, common_1.embed)("Como participar", "**TERMO:** jogue e continue quando quiser durante o dia.\n**Bingo:** entre antes da rodada e acompanhe sua cartela pelo servidor.\n**Caixa Misteriosa:** abra uma caixa durante o evento.\n**Quiz em equipes:** entre em um time quando as inscrições forem abertas.\n\nTodos os resultados e preferências pertencem a este servidor."));
}
async function player(i) {
    return (0, common_1.guard)(i, async () => {
        if (!i.guild)
            return;
        await (0, common_1.member)(i.guild, i.user.id);
        const action = i.customId.split(":")[1];
        if (i.message?.flags?.has?.(common_1.D.MessageFlags.Ephemeral)) {
            await (0, panelInteraction_1.deferPanel)(i);
            return (0, panelInteraction_1.refreshPanel)(i, await playView(i.guild, i.user.id, action));
        }
        await i.deferReply({ flags: common_1.D.MessageFlags.Ephemeral });
        return i.editReply(await playView(i.guild, i.user.id, action));
    });
}
async function admin(i) {
    return (0, common_1.guard)(i, async () => {
        await (0, common_1.staff)(i);
        const action = i.customId.split(":")[1], c = await (0, exports.config)(i.guild.id);
        if (action === "edit")
            return i.showModal((0, common_1.form)("games-form:appearance", "Painel de jogos", [
                { id: "title", label: "Título", value: c.title, max: 100 },
                {
                    id: "description",
                    label: "Texto",
                    value: c.description,
                    long: true,
                    max: 1000,
                },
                { id: "color", label: "Cor hexadecimal", value: c.color, max: 7 },
                {
                    id: "footer",
                    label: "Rodapé",
                    value: c.footer,
                    max: 150,
                    required: false,
                },
            ]));
        if (action === "war") {
            await require("../../../app/war/interactions").authorized(i);
            await (0, panelInteraction_1.deferPanel)(i);
            return (0, panelInteraction_1.refreshPanel)(i, await require("../../../app/war/admin").adminView(i.guild));
        }
        await (0, panelInteraction_1.deferPanel)(i);
        if (action === "publish")
            await publish(i.guild);
        if (action === "announcements")
            await common_1.prisma.gamesHubConfig.update({
                where: { guildId: i.guild.id },
                data: {
                    mysteryIndividualAnnouncements: !c.mysteryIndividualAnnouncements,
                },
            });
        return (0, panelInteraction_1.refreshPanel)(i, await adminView(i.guild, action === "appearance"));
    });
}
async function select(i) {
    return (0, common_1.guard)(i, async () => {
        await (0, common_1.staff)(i);
        if (i.customId !== "games-select:channel")
            return;
        await (0, common_1.textChannel)(i.guild, i.values[0]);
        await (0, exports.config)(i.guild.id);
        await common_1.prisma.gamesHubConfig.update({
            where: { guildId: i.guild.id },
            data: {
                channelId: i.values[0],
                messageId: null,
                publishedHash: null,
                publishedStyle: null,
            },
        });
        await (0, panelInteraction_1.deferPanel)(i);
        return (0, panelInteraction_1.refreshPanel)(i, await adminView(i.guild));
    });
}
async function modal(i) {
    return (0, common_1.guard)(i, async () => {
        await (0, common_1.staff)(i);
        if (i.customId !== "games-form:appearance")
            return;
        const get = (key) => i.fields.getTextInputValue(key).trim(), color = get("color").replace("#", "");
        if (!get("title") || !get("description") || !/^[0-9a-f]{6}$/i.test(color))
            throw Error("Preencha título e texto e use uma cor hexadecimal de seis caracteres.");
        await (0, exports.config)(i.guild.id);
        await common_1.prisma.gamesHubConfig.update({
            where: { guildId: i.guild.id },
            data: {
                title: get("title"),
                description: get("description"),
                color,
                footer: get("footer"),
            },
        });
        await (0, panelInteraction_1.deferPanel)(i);
        return (0, panelInteraction_1.refreshPanel)(i, await adminView(i.guild, true));
    });
}
let refreshing = false;
async function refreshPublished(client) {
    if (refreshing)
        return;
    refreshing = true;
    try {
        const configs = await common_1.prisma.gamesHubConfig.findMany({
            where: {
                messageId: { not: null },
                channelId: { not: null },
                publishedStyle: { not: null },
            },
        });
        for (const c of configs) {
            const guild = client.guilds.cache.get(c.guildId);
            if (!guild)
                continue;
            try {
                const style = JSON.parse(c.publishedStyle), view = await publicView(guild, false, {
                    title: style.title,
                    description: style.description,
                    color: style.color,
                    footer: style.footer,
                }), hash = require("node:crypto")
                    .createHash("sha256")
                    .update(JSON.stringify(view))
                    .digest("hex");
                if (hash === c.publishedHash)
                    continue;
                const ch = await (0, common_1.textChannel)(guild, c.channelId), message = await ch.messages.fetch(c.messageId).catch(() => null);
                if (!message)
                    continue;
                await message.edit(view);
                await common_1.prisma.gamesHubConfig.update({
                    where: { guildId: c.guildId },
                    data: { publishedHash: hash },
                });
            }
            catch (e) {
                console.error("[games-hub:" + c.guildId + "]", e.message);
            }
        }
    }
    finally {
        refreshing = false;
    }
}
