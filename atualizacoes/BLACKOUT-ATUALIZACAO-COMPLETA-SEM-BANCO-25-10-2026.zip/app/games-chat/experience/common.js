"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.clean = exports.payload = exports.embed = exports.row = exports.button = exports.prisma = exports.D = void 0;
exports.lock = lock;
exports.member = member;
exports.staff = staff;
exports.textChannel = textChannel;
exports.guard = guard;
exports.form = form;
const D = __importStar(require("discord.js"));
exports.D = D;
const prisma_1 = require("../../database/prisma");
Object.defineProperty(exports, "prisma", { enumerable: true, get: function () { return prisma_1.prisma; } });
const permissions_1 = require("../../utils/permissions");
const locks = new Set();
async function lock(key, work) {
    if (locks.has(key)) {
        const error = Error("Uma ação está em andamento. Aguarde alguns segundos.");
        error.code = "GAME_BUSY";
        throw error;
    }
    locks.add(key);
    try {
        return await work();
    }
    finally {
        locks.delete(key);
    }
}
const button = (id, label, style = D.ButtonStyle.Secondary, disabled = false) => new D.ButtonBuilder()
    .setCustomId(id)
    .setLabel(label)
    .setStyle(style)
    .setDisabled(disabled);
exports.button = button;
const row = (...items) => new D.ActionRowBuilder().addComponents(items);
exports.row = row;
const embed = (title, description = "") => new D.EmbedBuilder()
    .setColor(0xd71935)
    .setTitle(title)
    .setDescription(description || null);
exports.embed = embed;
const payload = (e, components = []) => ({
    content: null,
    embeds: [e],
    components,
    allowedMentions: { parse: [] },
});
exports.payload = payload;
const clean = (value, max = 100) => String(value ?? "")
    .replace(/[\[\]`*_~>|]/g, "")
    .trim()
    .slice(0, max);
exports.clean = clean;
async function member(guild, id) {
    const m = await guild.members.fetch(id).catch(() => null);
    if (!m || m.user.bot)
        throw Error("Participe do servidor para jogar.");
    return m;
}
async function staff(i) {
    if (!i.guild)
        throw Error("Abra esta opção no servidor.");
    const m = await member(i.guild, i.user.id);
    if (!(await (0, permissions_1.isBotAdmin)(m)) &&
        !m.permissions.has(D.PermissionFlagsBits.ManageEvents))
        throw Error("Você não tem permissão para conduzir este evento.");
    return m;
}
async function textChannel(guild, id) {
    const ch = id ? await guild.channels.fetch(id).catch(() => null) : null;
    if (!ch || ch.guildId !== guild.id || ch.type !== D.ChannelType.GuildText)
        throw Error("Escolha um canal de texto deste servidor.");
    const me = guild.members.me || (await guild.members.fetchMe());
    if (!ch
        .permissionsFor(me)
        ?.has([
        D.PermissionFlagsBits.ViewChannel,
        D.PermissionFlagsBits.SendMessages,
        D.PermissionFlagsBits.EmbedLinks,
        D.PermissionFlagsBits.ReadMessageHistory,
    ]))
        throw Error("O bot precisa ver o canal, enviar mensagens, inserir links e ler o histórico.");
    return ch;
}
async function guard(i, fn) {
    try {
        return await fn();
    }
    catch (e) {
        const p = {
            content: e.message || "Não foi possível concluir. Tente novamente.",
            allowedMentions: { parse: [] },
        };
        if (i.deferred && !i.replied && i.ephemeral === true)
            return i.editReply(p);
        return i.deferred || i.replied
            ? i.followUp({ ...p, flags: D.MessageFlags.Ephemeral })
            : i.reply({ ...p, flags: D.MessageFlags.Ephemeral });
    }
}
function form(id, title, fields) {
    return new D.ModalBuilder()
        .setCustomId(id)
        .setTitle(title)
        .addComponents(...fields.map((f) => {
        const t = new D.TextInputBuilder()
            .setCustomId(f.id)
            .setLabel(f.label)
            .setStyle(f.long ? D.TextInputStyle.Paragraph : D.TextInputStyle.Short)
            .setRequired(f.required !== false)
            .setMaxLength(f.max || 1000);
        if (f.value !== null && f.value !== undefined && String(f.value))
            t.setValue(String(f.value));
        return (0, exports.row)(t);
    }));
}
