"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.termoPublicView = termoPublicView;
exports.termoPlayerView = termoPlayerView;
exports.termoRankingView = termoRankingView;
const discord_js_1 = require("discord.js");
const embeds_1 = require("../../utils/embeds");
const prisma_1 = require("../../database/prisma");
const config_1 = require("../core/config");
const manager_1 = require("./manager");
const evaluation_1 = require("./evaluation");
const b = (id, label, style = discord_js_1.ButtonStyle.Secondary, disabled = false) => new discord_js_1.ButtonBuilder()
    .setCustomId("termo-game:" + id)
    .setLabel(label)
    .setStyle(style)
    .setDisabled(disabled);
async function termoPublicView(guild) {
    const [round, c, winners] = await Promise.all([
        (0, manager_1.ensureDailyRound)(guild.id),
        (0, config_1.termoConfig)(guild.id),
        (0, manager_1.dailyRanking)(guild.id),
    ]), [players, completed] = await Promise.all([
        prisma_1.prisma.termoGame.count({
            where: { guildId: guild.id, roundId: round.id },
        }),
        prisma_1.prisma.termoGame.count({
            where: { guildId: guild.id, roundId: round.id, status: "WON" },
        }),
    ]), attempts = round.maxAttemptsSnapshot ?? c.maxAttempts;
    const e = (await (0, embeds_1.baseEmbed)(guild))
        .setColor(Number.isNaN(parseInt(c.color, 16)) ? 0xd71935 : parseInt(c.color, 16))
        .setTitle(c.title)
        .setDescription(c.description)
        .addFields({
        name: "Desafio de hoje",
        value: `${round.wordLengthSnapshot ?? round.word.length} letras · ${attempts} tentativas\nSeu tabuleiro é privado e fica salvo para continuar depois.`,
    }, {
        name: "Na comunidade",
        value: `${players} participantes · ${completed} concluíram`,
        inline: true,
    }, {
        name: "Próxima palavra",
        value: `<t:${Math.floor(round.endsAt.getTime() / 1000)}:R>`,
        inline: true,
    }, {
        name: "Melhores de hoje",
        value: winners.length
            ? winners
                .slice(0, 5)
                .map((x, n) => `${n + 1}. <@${x.userId}> · ${x.attemptsUsed}/${attempts}`)
                .join("\n")
            : "Seja a primeira pessoa a concluir.",
    });
    if (c.thumbnail)
        e.setThumbnail(c.thumbnail);
    if (c.image)
        e.setImage(c.image);
    if (c.footer)
        e.setFooter({ text: c.footer });
    return {
        embeds: [e],
        components: [
            new discord_js_1.ActionRowBuilder().addComponents(b("play", "Jogar / continuar", discord_js_1.ButtonStyle.Primary), b("ranking", "Rankings"), b("help", "Como jogar")),
        ],
        allowedMentions: { parse: [] },
    };
}
async function termoPlayerView(guild, userId) {
    const [game, c] = await Promise.all([
        (0, manager_1.getOrCreateGame)(guild.id, userId),
        (0, config_1.termoConfig)(guild.id),
    ]), stat = await prisma_1.prisma.termoStat.findUnique({
        where: { guildId_userId: { guildId: guild.id, userId } },
    }), attempts = game.round.maxAttemptsSnapshot ?? c.maxAttempts, length = game.round.wordLengthSnapshot ?? game.round.word.length, board = game.guesses
        .map((g) => (0, evaluation_1.renderEvaluation)(g.word, JSON.parse(g.evaluation)))
        .join("\n") ||
        `Descubra uma palavra de **${length} letras**.\nComece sua primeira tentativa abaixo.`, answer = game.status === "LOST" && c.revealOnLoss
        ? `\n\nA palavra era **${game.round.word.word.toLocaleUpperCase("pt-BR")}**.`
        : "";
    const previousDay = new Date(game.round.date + "T12:00:00Z");
    previousDay.setUTCDate(previousDay.getUTCDate() - 1);
    const streak = stat?.lastWonDate &&
        [game.round.date, previousDay.toISOString().slice(0, 10)].includes(stat.lastWonDate)
        ? stat.currentStreak
        : 0;
    const e = (await (0, embeds_1.baseEmbed)(guild))
        .setColor(Number.isNaN(parseInt(c.color, 16)) ? 0xd71935 : parseInt(c.color, 16))
        .setTitle("TERMO · Seu tabuleiro")
        .setDescription(board + answer)
        .addFields({
        name: "Progresso",
        value: `${game.attemptsUsed}/${attempts} tentativas · ${game.status === "WON" ? "Concluído" : game.status === "LOST" ? "Tentativas encerradas" : "Em andamento"}`,
    }, {
        name: "Sua sequência",
        value: `${streak} vitória(s) em dias seguidos · Recorde ${stat?.bestStreak || 0}`,
    })
        .setFooter({ text: "Só você vê o tabuleiro · Sua partida fica salva." });
    if (game.status === "PLAYING")
        return {
            embeds: [e],
            components: [
                new discord_js_1.ActionRowBuilder().addComponents(b("guess", "Nova tentativa", discord_js_1.ButtonStyle.Primary), b("help", "Como jogar")),
            ],
            allowedMentions: { parse: [] },
        };
    e.addFields({
        name: "Compartilhar sem spoiler",
        value: `Somente a grade de cores e seu resultado serão enviados ${c.channelId ? "<#" + c.channelId + ">" : "ao canal do TERMO"}. A palavra e as letras não aparecem.`,
    });
    return {
        embeds: [e],
        components: [
            new discord_js_1.ActionRowBuilder().addComponents(b("share", "Compartilhar no TERMO", discord_js_1.ButtonStyle.Primary, Boolean(game.sharedMessageId)), b("ranking", "Rankings")),
        ],
        allowedMentions: { parse: [] },
    };
}
async function termoRankingView(guild) {
    const [daily, weekly, overall] = await Promise.all([
        (0, manager_1.dailyRanking)(guild.id),
        (0, manager_1.weeklyRanking)(guild.id),
        (0, manager_1.overallRanking)(guild.id),
    ]);
    return {
        embeds: [
            (await (0, embeds_1.baseEmbed)(guild))
                .setTitle("TERMO · Rankings")
                .setDescription("O ranking semanal dá espaço para novos participantes. Os resultados diários e o histórico geral continuam disponíveis.")
                .addFields({
                name: "Esta semana",
                value: weekly.length
                    ? weekly
                        .map((x, n) => `${n + 1}. <@${x.userId}> · ${x._sum.pointsEarned || 0} pontos · ${x._count._all} vitória(s)`)
                        .join("\n")
                    : "Ainda sem vitórias nesta semana.",
            }, {
                name: "Hoje",
                value: daily.length
                    ? daily
                        .slice(0, 5)
                        .map((x, n) => `${n + 1}. <@${x.userId}> · ${x.attemptsUsed} tentativas`)
                        .join("\n")
                    : "Ninguém concluiu hoje.",
            }, {
                name: "Geral",
                value: overall.length
                    ? overall
                        .slice(0, 5)
                        .map((x, n) => `${n + 1}. <@${x.userId}> · ${x.points} pontos · ${x.wins} vitórias`)
                        .join("\n")
                    : "Sem pontuações.",
            }),
        ],
        components: [
            new discord_js_1.ActionRowBuilder().addComponents(b("result", "Meu tabuleiro")),
        ],
        allowedMentions: { parse: [] },
    };
}
