"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.appearance = appearance;
const config_1 = require("../core/config");
const common_1 = require("../experience/common");
async function appearance(guild) {
    const c = await (0, config_1.termoConfig)(guild.id), e = (0, common_1.embed)(c.title, c.description).setColor(Number.isNaN(parseInt(c.color, 16)) ? 0xd71935 : parseInt(c.color, 16));
    if (c.image)
        e.setImage(c.image);
    if (c.thumbnail)
        e.setThumbnail(c.thumbnail);
    if (c.footer)
        e.setFooter({ text: c.footer });
    return {
        ...(0, common_1.payload)(e, [
            (0, common_1.row)((0, common_1.button)("adm-games-action:termo-appearance-edit", "Editar mensagem"), (0, common_1.button)("adm-games-action:termo-publish", "Publicar / atualizar", common_1.D.ButtonStyle.Primary, !c.enabled || !c.channelId), (0, common_1.button)("adm-games-action:termo-home", "Voltar")),
        ]),
        content: "**Prévia · Mensagem do TERMO**\nTítulo, texto, imagem e rodapé salvos. Esta prévia não abre rodada nem envia mensagem.",
    };
}
