"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dateInTZ = dateInTZ;
exports.nextMidnight = nextMidnight;
exports.ensureDailyRound = ensureDailyRound;
exports.getOrCreateGame = getOrCreateGame;
exports.submitGuess = submitGuess;
exports.dailyRanking = dailyRanking;
exports.overallRanking = overallRanking;
exports.weeklyRanking = weeklyRanking;
exports.shareResult = shareResult;
const node_crypto_1 = require("node:crypto");
const prisma_1 = require("../../database/prisma");
const guildConfig_1 = require("../../database/guildConfig");
const config_1 = require("../core/config");
const words_1 = require("./words");
const evaluation_1 = require("./evaluation");
const common_1 = require("../experience/common");
function dateInTZ(date, timezone) {
    const parts = new Intl.DateTimeFormat("en-CA", {
        timeZone: timezone,
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
    }).formatToParts(date), get = (type) => parts.find((p) => p.type === type)?.value;
    return `${get("year")}-${get("month")}-${get("day")}`;
}
function nextMidnight(timezone, now = Date.now()) {
    const today = dateInTZ(new Date(now), timezone);
    let low = now, high = now + 36 * 3600000;
    while (high - low > 1000) {
        const mid = Math.floor((low + high) / 2);
        if (dateInTZ(new Date(mid), timezone) === today)
            low = mid;
        else
            high = mid;
    }
    return new Date(Math.ceil(high / 1000) * 1000);
}
async function ensureDailyRound(guildId) {
    await (0, words_1.ensureDefaultWords)();
    const [guild, config] = await Promise.all([
        (0, guildConfig_1.getOrCreateGuildConfig)(guildId),
        (0, config_1.termoConfig)(guildId),
    ]), date = dateInTZ(new Date(), guild.timezone);
    const existing = await prisma_1.prisma.termoRound.findUnique({
        where: { guildId_date: { guildId, date } },
        include: { word: true },
    });
    if (existing) {
        const deadline = nextMidnight(guild.timezone);
        if (existing.maxAttemptsSnapshot === null ||
            existing.wordLengthSnapshot === null ||
            Math.abs(existing.endsAt.getTime() - deadline.getTime()) > 2000)
            return prisma_1.prisma.termoRound.update({
                where: { id: existing.id },
                data: {
                    maxAttemptsSnapshot: existing.maxAttemptsSnapshot ?? config.maxAttempts,
                    wordLengthSnapshot: existing.wordLengthSnapshot ?? existing.word.length,
                    endsAt: deadline,
                },
                include: { word: true },
            });
        return existing;
    }
    const recent = await prisma_1.prisma.termoRound.findMany({
        where: {
            guildId,
            startedAt: {
                gte: new Date(Date.now() - config.repeatAfterDays * 86400000),
            },
        },
        select: { wordId: true },
    }), scope = config.wordSource === "SERVER"
        ? { guildId }
        : config.wordSource === "DEFAULT"
            ? { guildId: null }
            : { OR: [{ guildId: null }, { guildId }] };
    const base = {
        ...scope,
        length: config.wordLength,
        active: true,
        canAnswer: true,
    };
    let words = await prisma_1.prisma.termoWord.findMany({
        where: {
            ...base,
            ...(recent.length ? { id: { notIn: recent.map((r) => r.wordId) } } : {}),
        },
    });
    if (!words.length)
        words = await prisma_1.prisma.termoWord.findMany({ where: base });
    if (!words.length)
        throw Error(`Não há respostas de ${config.wordLength} letras disponíveis. A equipe pode ajustar o tamanho ou cadastrar palavras.`);
    const word = words[(0, node_crypto_1.randomInt)(words.length)];
    try {
        return await prisma_1.prisma.$transaction(async (tx) => {
            const found = await tx.termoRound.findUnique({
                where: { guildId_date: { guildId, date } },
                include: { word: true },
            });
            if (found)
                return found;
            const round = await tx.termoRound.create({
                data: {
                    guildId,
                    date,
                    wordId: word.id,
                    endsAt: nextMidnight(guild.timezone),
                    maxAttemptsSnapshot: config.maxAttempts,
                    wordLengthSnapshot: config.wordLength,
                },
                include: { word: true },
            });
            await tx.termoWord.update({
                where: { id: word.id },
                data: { lastUsedAt: new Date() },
            });
            return round;
        });
    }
    catch (e) {
        if (["P2002", "P2034"].includes(e.code)) {
            const found = await prisma_1.prisma.termoRound.findUnique({
                where: { guildId_date: { guildId, date } },
                include: { word: true },
            });
            if (found)
                return found;
        }
        throw e;
    }
}
async function getOrCreateGame(guildId, userId) {
    const [config, general] = await Promise.all([
        (0, config_1.termoConfig)(guildId),
        (0, config_1.gamesConfig)(guildId),
    ]);
    if (!config.enabled || !general.enabled)
        throw Error("O TERMO está desativado neste servidor.");
    const round = await ensureDailyRound(guildId);
    return prisma_1.prisma.termoGame.upsert({
        where: { roundId_userId: { roundId: round.id, userId } },
        update: {},
        create: { guildId, roundId: round.id, userId },
        include: {
            guesses: { orderBy: { attempt: "asc" } },
            round: { include: { word: true } },
        },
    });
}
async function submitGuess(guildId, userId, input, expectedRoundId) {
    return (0, common_1.lock)(`termo:${guildId}:${userId}`, async () => {
        const [guild, game] = await Promise.all([
            (0, guildConfig_1.getOrCreateGuildConfig)(guildId),
            getOrCreateGame(guildId, userId),
        ]);
        const length = game.round.wordLengthSnapshot ?? game.round.word.length, maxAttempts = game.round.maxAttemptsSnapshot ?? 6;
        if (expectedRoundId && expectedRoundId !== game.roundId)
            throw Error("A palavra do dia mudou. Reabra seu tabuleiro para começar a rodada atual.");
        if (game.round.status !== "ACTIVE" || game.round.endsAt <= new Date())
            throw Error("Esta rodada foi encerrada. Reabra o jogo.");
        if (game.status !== "PLAYING")
            throw Error(game.status === "WON"
                ? "Você já acertou o TERMO de hoje."
                : "Suas tentativas terminaram. Volte na próxima palavra.");
        if (!(0, words_1.validShape)(input, length))
            throw Error(`Digite uma palavra de ${length} letras, sem números ou símbolos.`);
        const normalized = (0, words_1.normalizeWord)(input);
        if (!(await (0, words_1.isAllowedGuess)(guildId, normalized, length)))
            throw Error("Essa palavra não está no dicionário do jogo. Tente outra; nenhuma tentativa foi consumida.");
        const evaluation = (0, evaluation_1.evaluateGuess)(game.round.word.normalized, normalized), attempt = game.attemptsUsed + 1, won = normalized === game.round.word.normalized, lost = !won && attempt >= maxAttempts, now = new Date(), points = won ? Math.max(10, 100 - attempt * 10) : 0;
        return prisma_1.prisma.$transaction(async (tx) => {
            const current = await tx.termoGame.findUnique({ where: { id: game.id } });
            if (!current ||
                current.status !== "PLAYING" ||
                current.attemptsUsed !== game.attemptsUsed ||
                game.round.endsAt <= new Date())
                throw Error("Seu jogo mudou durante o envio. Atualize o tabuleiro.");
            await tx.termoGuess.create({
                data: {
                    gameId: game.id,
                    attempt,
                    word: input.toLocaleUpperCase("pt-BR"),
                    normalized,
                    evaluation: JSON.stringify(evaluation),
                },
            });
            const rankPosition = won
                ? (await tx.termoGame.count({
                    where: { roundId: game.roundId, status: "WON" },
                })) + 1
                : undefined;
            const saved = await tx.termoGame.update({
                where: {
                    id: game.id,
                    attemptsUsed: game.attemptsUsed,
                    status: "PLAYING",
                },
                data: {
                    attemptsUsed: attempt,
                    status: won ? "WON" : lost ? "LOST" : "PLAYING",
                    finishedAt: won || lost ? now : null,
                    rankPosition,
                    pointsEarned: points,
                },
                include: {
                    guesses: { orderBy: { attempt: "asc" } },
                    round: { include: { word: true } },
                },
            });
            const stat = await tx.termoStat.upsert({
                where: { guildId_userId: { guildId, userId } },
                create: { guildId, userId },
                update: {},
            }), yesterday = dateInTZ(new Date(now.getTime() - 86400000), guild.timezone), streak = won
                ? stat.lastWonDate === yesterday
                    ? stat.currentStreak + 1
                    : 1
                : 0;
            await tx.termoStat.update({
                where: { id: stat.id },
                data: {
                    wins: won ? { increment: 1 } : undefined,
                    losses: lost ? { increment: 1 } : undefined,
                    currentStreak: won ? streak : lost ? 0 : undefined,
                    bestStreak: won ? Math.max(stat.bestStreak, streak) : undefined,
                    totalAttempts: won ? { increment: attempt } : undefined,
                    firstTryWins: won && attempt === 1 ? { increment: 1 } : undefined,
                    sixthTryWins: won && attempt === 6 ? { increment: 1 } : undefined,
                    totalSolveSeconds: won
                        ? {
                            increment: Math.floor((now.getTime() - game.startedAt.getTime()) / 1000),
                        }
                        : undefined,
                    points: won ? { increment: points } : undefined,
                    lastPlayedDate: game.round.date,
                    lastWonDate: won ? game.round.date : undefined,
                },
            });
            return saved;
        });
    });
}
async function dailyRanking(guildId) {
    const round = await ensureDailyRound(guildId);
    return prisma_1.prisma.termoGame.findMany({
        where: { roundId: round.id, status: "WON" },
        orderBy: [{ attemptsUsed: "asc" }, { finishedAt: "asc" }],
        take: 20,
    });
}
async function overallRanking(guildId) {
    return prisma_1.prisma.termoStat.findMany({
        where: { guildId },
        orderBy: [{ points: "desc" }, { wins: "desc" }],
        take: 20,
    });
}
async function weeklyRanking(guildId) {
    const guild = await (0, guildConfig_1.getOrCreateGuildConfig)(guildId), today = dateInTZ(new Date(), guild.timezone), day = new Date(today + "T12:00:00Z");
    day.setUTCDate(day.getUTCDate() - ((day.getUTCDay() + 6) % 7));
    const monday = day.toISOString().slice(0, 10);
    return prisma_1.prisma.termoGame.groupBy({
        by: ["userId"],
        where: {
            guildId,
            status: "WON",
            round: { date: { gte: monday, lte: today } },
        },
        _sum: { pointsEarned: true, attemptsUsed: true },
        _count: { _all: true },
        orderBy: [
            { _sum: { pointsEarned: "desc" } },
            { _sum: { attemptsUsed: "asc" } },
            { userId: "asc" },
        ],
        take: 10,
    });
}
async function shareResult(guild, userId) {
    return (0, common_1.lock)(`termo-share:${guild.id}:${userId}`, async () => {
        const game = await getOrCreateGame(guild.id, userId);
        if (game.status === "PLAYING")
            throw Error("Conclua sua partida antes de compartilhar o resultado.");
        if (game.sharedMessageId)
            throw Error("Este resultado já foi compartilhado ou está em processamento.");
        const config = await (0, config_1.termoConfig)(guild.id), channel = await (0, common_1.textChannel)(guild, config.channelId), claim = await prisma_1.prisma.termoGame.updateMany({
            where: { id: game.id, sharedMessageId: null },
            data: { sharedMessageId: "PROCESSING" },
        });
        if (!claim.count)
            throw Error("O compartilhamento já foi solicitado.");
        const { evaluationBlocks } = require("./evaluation");
        let posted;
        try {
            posted = await channel.send({
                content: `<@${userId}> · **TERMO ${game.attemptsUsed}/${game.round.maxAttemptsSnapshot ?? 6}** · ${game.round.date}\n${game.guesses.map((g) => evaluationBlocks(JSON.parse(g.evaluation))).join("\n")}`,
                allowedMentions: { parse: [] },
            });
        }
        catch (e) {
            await prisma_1.prisma.termoGame.update({
                where: { id: game.id },
                data: { sharedMessageId: null },
            });
            throw e;
        }
        await prisma_1.prisma.termoGame.update({
            where: { id: game.id },
            data: { sharedMessageId: posted.id },
        });
        return posted;
    });
}
