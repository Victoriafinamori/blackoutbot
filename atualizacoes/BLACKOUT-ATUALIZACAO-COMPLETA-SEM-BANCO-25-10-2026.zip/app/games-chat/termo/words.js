"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.normalizeWord = normalizeWord;
exports.validShape = validShape;
exports.ensureDefaultWords = ensureDefaultWords;
exports.isAllowedGuess = isAllowedGuess;
const prisma_1 = require("../../database/prisma");
const lexicon_1 = require("./lexicon");
function normalizeWord(value) {
    return value
        .trim()
        .toLocaleLowerCase("pt-BR")
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "");
}
function validShape(value, length) {
    return new RegExp(`^[a-z]{${length}}$`).test(normalizeWord(value));
}
let seeding = null;
async function ensureDefaultWords() {
    if (seeding)
        return seeding;
    seeding = (async () => {
        const existing = await prisma_1.prisma.termoWord.findMany({
            where: { guildId: null },
            select: { normalized: true },
        }), known = new Set(existing.map((w) => w.normalized)), items = new Map();
        for (const word of lexicon_1.ANSWERS)
            if (validShape(word, 5))
                items.set(normalizeWord(word), { word, canAnswer: true });
        for (const word of lexicon_1.EXTRA_GUESSES)
            if (validShape(word, 5) && !items.has(normalizeWord(word)))
                items.set(normalizeWord(word), { word, canAnswer: false });
        const data = [...items]
            .filter(([normalized]) => !known.has(normalized))
            .map(([normalized, item]) => ({
            word: item.word,
            normalized,
            length: 5,
            category: "PADRAO",
            difficulty: "NORMAL",
            canGuess: true,
            canAnswer: item.canAnswer,
        }));
        if (data.length)
            await prisma_1.prisma.termoWord.createMany({ data });
    })();
    try {
        await seeding;
    }
    finally {
        seeding = null;
    }
}
async function isAllowedGuess(guildId, normalized, length) {
    return Boolean(await prisma_1.prisma.termoWord.findFirst({
        where: {
            OR: [{ guildId: null }, { guildId }],
            normalized,
            length,
            active: true,
            canGuess: true,
        },
    }));
}
