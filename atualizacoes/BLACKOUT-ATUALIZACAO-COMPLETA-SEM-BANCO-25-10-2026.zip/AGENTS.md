# AGENTS.md — Guia de contexto do FF BLACKOUT

> **Leia este arquivo primeiro.** Ele existe para impedir que agentes/Codex precisem varrer o repositório inteiro a cada tarefa.

## 1. Regra principal de leitura

Não faça leitura recursiva do projeto inteiro por padrão.

1. Identifique o módulo citado pelo pedido.
2. Use a tabela **Roteamento por tarefa** abaixo.
3. Leia somente os arquivos/pastas indicados e as dependências diretamente importadas por eles.
4. Consulte `docs/TECHNICAL.md` apenas nas seções relevantes à tarefa.
5. Amplie a leitura somente se aparecer uma dependência real entre módulos.

Para tarefas de arquitetura, deploy, banco, migração ou bugs sem módulo identificado, leia primeiro:
- `squarecloud.app`
- `package.json`
- `prisma/schema.prisma` (somente modelos relevantes; não precisa ler tudo)
- `src/index.ts`
- `src/events/interactionCreate.ts`
- `docs/TECHNICAL.md`

## 2. Estado de execução: regra CRÍTICA

O deploy atual da Square Cloud **não inicia `dist/`**.

`squarecloud.app` define:
- `MAIN=app/index.js`
- geração do Prisma Client;
- `prisma migrate deploy`;
- registro dos slash commands via `app/deploy-commands.js`;
- início do bot via `app/index.js`.

Portanto:

- `src/` = fonte TypeScript disponível para desenvolvimento.
- `dist/` = saída do `tsc`; útil localmente, mas **não é o alvo atual da Square Cloud**.
- `app/` = JavaScript que a Square Cloud executa no estado atual.

### Divergência conhecida

`app/` contém funcionalidades que não existem hoje em `src/`, incluindo partes de:
- `war/` / comando `/guerra`;
- `giveaways/` / comando `/sorteio`;
- `family-app/`;
- `insta/` e partes avançadas de `social/`;
- `submundo/` e funcionalidades de fotos/vídeos/mensagens anônimas;
- `radio/` e a Rádio 24h;
- partes do jogo musical;
- editores visuais e alertas adicionais de tickets/registro.

Consequência: **nunca assuma que `src/` sozinho representa produção**.

Para um módulo que existe em `src/` e `app/`, faça a mudança na fonte TypeScript e garanta que o equivalente usado em `app/` seja atualizado antes de considerar a tarefa pronta. Para um módulo que existe apenas em `app/`, não invente uma versão TypeScript sem necessidade: altere somente o escopo pedido e registre a divergência na documentação.

## 3. Roteamento por tarefa

| Pedido / palavras-chave | Ler primeiro | Complementos somente se necessário |
|---|---|---|
| `/adm`, menu administrativo, categorias | `src/commands/adm.ts`, `src/utils/admPanel.ts`, `src/utils/adminUi.ts`, `src/utils/admEmojis.ts`, `src/components/selects/admPanelSelect.ts`, `src/components/selects/admSectionSelect.ts` | conferir `app/utils/admPanel.js` e `app/components/selects/admSectionSelect.js` para módulos exclusivos de produção; depois o componente específico |
| permissões, administradores do bot | `src/utils/permissions.ts`, `src/components/buttons/admAdminMenu.ts` | modelos `BotAdmin`, `PermissionRole`, `SystemRole` no Prisma |
| Anti-Raid, Anti Ban, segurança preventiva, contenção | `src/security/{config,entry,messages,audit,locks,incidents}.ts` | views/interactions/reviews/assets/diagnostics/runtime, eventos security*, três handlers securityCenter; sincronizar app/ e manter filtros legados |
| moderação, warn, mute, filtros | `src/utils/moderation.ts`, `src/utils/filters.ts`, `src/components/buttons/admModerationMenu.ts` | `src/components/modals/modModals.ts`, `src/components/selects/modUserSelects.ts` |
| reintegração | `src/utils/reintegration.ts`, `src/utils/reintegrationOperationalPanel.ts` | comandos `reintegrar.ts`, `etapasreintegracao.ts`; modelos `Stage*`, `ReintegrationMember` |
| tickets | `src/utils/tickets.ts`, `src/components/buttons/admTicketsMenu.ts`, `src/components/buttons/ticketActions.ts` | selects/modals `ticket*`; conferir também `app/` para alertas/editor visual |
| embeds, mensagens enviadas, Maker V2, cargos por reação | `src/message-maker/{document,service,views,interactions}.ts`; para cargos, `roles.ts` e `roleInteractions.ts` | handlers messageMaker, oito eventos maker*, `utils/componentMessages`; models Maker* e ReactionRole*; legado em CustomEmbed e admEmbedV2*; sincronizar app/ |
| auto-cargo, cargo ao entrar, autorole | `src/components/buttons/admConfigMenu.ts`, `src/components/selects/autoRoleSelect.ts`, `src/events/guildMemberAdd.ts` | campos `GuildConfig.autoRoleEnabled` e `autoRoleIds`; sincronizar com `app/` |
| registro | `src/utils/registration.ts`, `src/utils/registrationUi.ts`, `src/components/buttons/admRegistrationMenu.ts` | `registration*`; conferir `app/` para welcome/editor visual |
| MOV CHAT | `src/utils/movStats.ts`, `src/events/messageCreate.ts` | `movChat*` selects; modelos `MovStat`, `MovChatDailyStat` |
| MOV CALL, call, voz, rankingcall | `src/utils/movCallStats.ts`, `src/events/voiceStateUpdate.ts` | `movCall*` selects/modals; modelos `MovVoiceSession`, `MovCall*` |
| subida de membros | `src/memberRise/service.ts`, `src/memberRise/panel.ts` | `memberRise*` buttons/selects/modals; modelos `MemberRise*` |
| famílias, irmandades | `src/utils/families.ts`, `src/components/buttons/admFamiliasMenu.ts` | `family*`/`familia*`; **produção também possui `app/family-app/`** |
| feedback do servidor | `src/utils/serverFeedback.ts`, `src/components/buttons/admServerFeedbackMenu.ts` | `serverFeedback*`; modelos `ServerFeedback*` |
| Games de Chat, Caixa Misteriosa, TERMO, `/jogar` | `src/games-chat/experience/{common,hub}.ts`, `src/components/buttons/admGamesChatMenu.ts` | `src/games-chat/termo/`, `src/games-chat/mystery-box/`; comandos `jogar.ts`, `caixa.ts`, `termo.ts` |
| Verdade ou Desafio / jogos | `src/games/`, `src/commands/verdade.ts` | `truthOrDare*` components |
| Free Fire, inscrições | `src/ff/`, `src/components/buttons/admFreeFireMenu.ts` | `ff*` components; modelos `FFConfig`, `FFDuo`, `FFDuoLog` |
| Bingo | `src/bingo/{community,communityViews,communityInteractions,cardAccess,service}.ts`, `src/components/buttons/admBingoMenu.ts` | `bingo*` selects/modals; modelos `Bingo*`; preservar cartelas e pedidos do fluxo anterior |
| Guerra / AUDAZ EM GUERRA | `app/war/`, `app/commands/guerra.js` | modelos `War*`; componentes `app/components/*/war*` |
| Sorteio / giveaway | `app/giveaways/`, `app/commands/sorteio.js` | componentes `app/components/*/giveaway*`; modelos `Giveaway*` |
| Instagram / Social | `app/social/`, `app/insta/` | componentes `social*`, `insta*`, `aaSocial*`; modelos `Social*`; `README_FIX_CURTIDAS.txt` |
| Submundo, fotos/vídeos anônimos, mensagens anônimas, destaque | `app/submundo/service.js`, `app/components/buttons/admSubmundoMenu.js` | `admAnonymousPhoto*`, `anonymousPhoto*`, `admAnonymousMessage*`, `anonymousMessage*`, `admSubmundoHighlight*`; modelos `AnonymousPhoto*` e `AnonymousMessage*` |
| Rádio 24h, rádio, playlist, YouTube, call musical | `app/radio/service.js`, `app/components/buttons/admRadioMenu.js` | `app/components/selects/radioVoiceChannelSelect.js`, `app/components/modals/admRadioModal.js`; models `RadioConfig` e `RadioTrack` |
| jogo musical | componentes `app/components/*/music*` | modelos `MusicGame*` no Prisma |
| Central de Denúncias, denúncia, atendimento privado | `src/utils/reports.ts`, `src/components/buttons/admDenunciasMenu.ts`, `src/components/buttons/denunciaButtons.ts` | `denunciaModals.ts`, selects `denunciaChannel*`/`denunciaRole*`; models `ReportConfig`, `Report`, `ReportEvent`. O VOTEBAN foi retirado da navegação e não deve ser reintroduzido. |
| banco / Prisma / migration | modelo relevante em `prisma/schema.prisma` + última migration relacionada | `src/database/prisma.ts`; nunca usar reset em produção |
| deploy / Square Cloud | `squarecloud.app`, `package.json`, `app/deploy-commands.js`, `app/index.js` | `docs/TECHNICAL.md` → Deploy |
| novo slash command | `src/structures/types.ts`, `src/handlers/loadCommands.ts`, `src/deploy-commands.ts` | comando semelhante existente; depois sincronizar `app/` |
| novo botão/select/modal | `src/events/interactionCreate.ts`, loader correspondente em `src/handlers/` | componente semelhante; atenção a `customId` exato/prefixo |

## 4. Como as interações são roteadas

- Slash commands: coleção `client.commands`.
- Botões: `client.buttons`.
- Selects: `client.selects`.
- Modals: `client.modals`.
- `src/events/interactionCreate.ts` busca primeiro `customId` exato e depois por **prefixo**.

Ao criar IDs dinâmicos, registre no handler apenas um prefixo estável quando necessário. Antes de criar novo handler, procure somente no diretório do mesmo tipo de componente por colisão de `customId`.

## 5. Banco de dados

- ORM: Prisma 5.x.
- Schema: `prisma/schema.prisma`.
- Há histórico extenso de migrations em `prisma/migrations/`.
- Produção aplica `prisma migrate deploy` durante o START da Square Cloud.

### Regras obrigatórias

- Não usar `prisma migrate reset` em produção.
- Não usar `prisma db push` para substituir migrations de produção.
- Mudança persistente exige schema + migration compatível + atualização do código consumidor.
- Antes de alterar um model, leia **somente o model e as relações diretamente ligadas a ele**.

## 6. Segredos e configuração

Variáveis conhecidas:
- `DISCORD_TOKEN`
- `CLIENT_ID`
- `DATABASE_URL`
- `DEV_GUILD_ID` (opcional para deploy rápido de comandos)
- `NODE_ENV` pode ser consultado pelo código compilado.

Existe `.env` no pacote atual. **Nunca reproduza valores, nunca coloque segredo em documentação e nunca trate `.env` como arquivo compartilhável.**

## 7. Definition of Done para qualquer alteração

Antes de finalizar uma tarefa:

1. Alterar somente o módulo necessário e suas dependências reais.
2. Conferir se a mudança precisa de schema/migration.
3. Conferir se slash commands mudaram e precisam de novo deploy.
4. Garantir que o código que a Square Cloud executa em `app/` ficou coerente com a mudança.
5. Atualizar `docs/TECHNICAL.md` quando houver mudança estrutural, novo módulo, novo fluxo, nova tabela, comando ou integração.
6. Registrar a alteração em `docs/CHANGELOG.md`.
7. Se a mudança alterar a forma de navegar no projeto, atualizar este `AGENTS.md`.

## 8. Documentos canônicos

- **Orientação para agentes:** `AGENTS.md` (este arquivo)
- **Estado técnico atual:** `docs/TECHNICAL.md`
- **Histórico de mudanças:** `docs/CHANGELOG.md`
- **Visão rápida humana:** `README.md`

Documentos antigos são referência histórica, não fonte de verdade quando conflitarem com `squarecloud.app`, o código atualmente executado em `app/`, o schema Prisma ou `docs/TECHNICAL.md`.

## 9. REGRA CRÍTICA — banco de produção / Square Cloud

O banco SQLite de produção é `prisma/dev.db`. **Nunca** substitua esse arquivo por um banco local, vazio, de teste ou por uma cópia antiga ao preparar atualização.

Enquanto o projeto continuar em SQLite, **pacotes de atualização de código não devem incluir `prisma/dev.db`, `dev.db.backup` nem arquivos `.bak`**. O banco vivo da Square Cloud é estado persistente e não deve ser sobrescrito pelo ZIP. Alterações de estrutura devem ir apenas em migrations aditivas e ser aplicadas com `prisma migrate deploy`.

- jamais usar `prisma migrate reset` em produção;
- jamais usar `prisma db push` para "alinhar" produção;
- toda mudança persistente exige migration aditiva/compatível;
- o START da Square Cloud já executa `prisma migrate deploy` antes do bot;
- migrations novas devem ser testadas em uma cópia do banco real quando disponível;
- preserve também uma cópia de segurança do banco antes de qualquer alteração estrutural;
- para eliminar esse acoplamento em definitivo, priorize migração futura para banco externo persistente (PostgreSQL).

### Parcerias
Para tarefas em `/adm → Atendimento → Parcerias`, leia primeiro `src/utils/partnerships.ts` e os componentes `admPartnershipsMenu`, `partnershipButtons`, `partnershipModals` e `partnershipAdminSelect`. A Square Cloud executa `app/`, então mantenha `src/` e `app/` sincronizados para este módulo. O painel público segue o padrão moderno de Tickets: embed editável, botão com texto/emoji/cor, prévia e publicação/atualização. Nunca recrie, limpe, empacote ou substitua `prisma/dev.db` como parte de uma feature; alterações de estrutura devem ser migrations aditivas.

## 10. Interface administrativa BLACKOUT (21/10/2026)

A ordem do `/adm` está em `admPanel`: Personalização do bot → Equipe e proteção → Entrada e evolução → Atendimento → Comunidade e atividade → Jogos e eventos → Social e entretenimento. Registro/reintegração/oficialização retornam para `membros`; Free Fire/Bingo/Sorteios retornam para `staff`. `campeonatos` é um alias legado, não uma oitava área.

Para estética administrativa, leia `src/utils/adminUi.ts`, `src/utils/admEmojis.ts`, `assets/blackout-ui/` e os equivalentes de `app/`. O handler `admNavigation` trata `adm-nav:`. Os PNGs são emojis da aplicação, não do servidor. `baseEmbed` continua sendo o padrão público configurável; não aplique o tema administrativo às mensagens públicas personalizadas.

Validação focada: `node --test tests/admin-ui.test.cjs tests/personalization.test.cjs tests/security.test.cjs tests/log-center.test.cjs`. O build global já tem 38 erros preexistentes; compare com a base antes de atribuí-los à entrega. Nunca copie `dist/` inteiro por cima de `app/`. O ZIP de atualização não deve conter `.env`, banco, backups, `node_modules` ou a antiga cópia `ff/`.

## 11. Personalização local e edição na mesma mensagem

Regra comercial do usuário: perfil, padrão e modelos pertencem ao servidor do comprador. Para nome/avatar/banner, use somente `guild.members.editMe`. Nunca use `ClientUser.setAvatar/setBanner`, nem como fallback. Renderize o GuildMember retornado para mostrar imediatamente a alteração; ao reabrir, busque o perfil local atualizado.

O editor mostra a embed pública real, não uma lista de campos preenchidos. `panelInteraction` atualiza a mensagem de origem, inclusive após modals. `embedPublication` distingue salvamento e publicação por hash do conteúdo. Prévia de links é paginada para respeitar cinco linhas de componentes; não trunque a publicação.

Cargos automáticos ficam em `membros`; logs gerais e por categoria em Logs e auditoria; avisos em Moderação e mensagens de reintegração em Reintegração. `admNotifications`, `configurationChecks`, seletores e serviços correspondentes precisam manter a separação por guildId. Preferências nullable dos módulos usam notifyDm como fallback para preservar a base.

A migração 20261021180000_personalization_module_notifications é aditiva e deve acompanhar a entrega. Não remover as migrations anteriores, não usar db push/reset e não incluir arquivos de banco no pacote. `src/` e `app/` foram atualizados de forma direcionada; não recompilar app inteiro a partir de src.


## 12. Equipe e proteção

Quatro destinos em seguranca: administracao, protecao, moderacao e logs (28 destinos canônicos no total). Para fluxo por membro/revisão leia utils/moderationPanel, buttons/teamModeration, selects/modUserSelects e modals/modModals. Nenhuma ação manual ocorre antes da confirmação; preservar tokens restritos por guildId/actorId/messageId, prazo e consumo único. Os serviços de moderação mantêm a execução e auditoria; reversões aceitam motivo opcional compatível com chamadas anteriores. Para equipe: admAdminMenu, utils/teamRoles e os três handlers iniciais de selects/roleSelects. Este último contém funções exclusivas em app/: nunca substituí-lo integralmente por src. Proteção conserva handlers legados de admModerationMenu; novo select autoModActionSelect escolhe a resposta explicitamente. Logs gerais/categorias/Ações da equipe ficam em admLogsMenu.


## 13. Central de logs

Para logs/eventos/servidor externo leia `src/logging/{config,delivery,events,panel}.ts`, equivalentes app/, `utils/adminLog`, componentes `logCenter` e os novos `events/log*.ts`. ServerLogSettings é independente de GuildConfig, Tickets e Registro; migration20261021220000_server_log_center deve acompanhar o código. Preservar autorização do mesmo configurador na origem/destino em cada envio externo, isolamento de guildId, nenhuma queda automática do externo para local e nenhuma duplicação dos handlers operacionais. Novos eventos começam desligados; decisões administrativas permanecem no SQLite mesmo sem encaminhamento. Família usa seu destino dedicado somente como fallback local. Não prometer recuperação de mensagens apagadas fora do cache, executor desconhecido ou entrega durável da fila em memória. A exclusão em massa filtra autores antes de enviar um resumo com roleIds resolvidos. Testar os quatro arquivos de teste atuais. Não usar este módulo para alterar a configuração externa de Tickets/Registro.


### Navegação refinada dos logs

`logging/panel` expõe quatro tarefas principais; `renderLogOrganization` sem scope redireciona para Onde enviar. LOG_UI_GROUPS tem seis categorias; alias `bot` agrupa os eventos persistidos system/reintegration sem alterar LOG_GROUPS nem os IDs antigos. Use logEventGroups ao tratar esse seletor; não faça migração dos destinos existentes. Detalhes/IDs e diagnóstico são secundários. openModuleLogLink usa controllers reais de app/ por Proxy/adaptador, preservando o reconhecimento da interação e os limites de componentes; não substituir os módulos de produção por seus equivalentes incompletos de src. Contagem atual de validação: 75 testes.


## Refinamento administrativo — pontos de entrada adicionais

Para navegação por tarefas dos módulos restantes, leia `src/utils/adminTasks.ts` e `src/components/selects/adminTaskSelect.ts`, com os equivalentes em `app/`. Para Registro, comece por `src/utils/registrationAdmin.ts`, `registrationSettings.ts` e `registrationPageAdmin.ts`; os editores completos de produção continuam em `app/utils/registrationPanelEditor.js` e `ticketVisualEditor.js`. Para prévias de Parcerias, Denúncias, Feedback e Submundo, consulte `src/utils/adminMessagePreview.ts`. `partnershipSettings.ts` organiza canais e cargos de Parcerias. `tests/admin-refinement.test.cjs` usa fixtures sem conexão externa. As sete áreas e os 28 destinos permanecem; transferência programada fica no acesso Cargos e automações.

## Social e entretenimento — 22/10/2026

Para os novos fluxos, leia app/social-experience/{common,views,interactions}.js e o serviço específico activities/posts/profiles/radio/anonymous/scheduler. Esta extensão existe somente em app/, como os módulos avançados que integra. Contagem atual: sete áreas e 29 destinos; dinamicassociais foi adicionado após o refinamento anterior. Os handlers usam sx:, sx-admin:, sx-select:, sx-form:, sx-inbox: e sx-review:, evitando colisão com social-. Preservar prévias, estados persistentes e edição no painel original.

INSTA usa Container/MediaGallery V2, e não EmbedBuilder para vídeo. Curtir/comentar nunca deve limpar attachments nem reenviar arquivos; ao converter uma mensagem legada, limpar embeds/content. Não deletar o original antes de upload+persistência. Destaques também são V2, inclusive vazios. Recuperação legada é limitada a attachmentId exato na mesma guild e histórico recente; não prometer reconstrução de arquivos apagados.

Schema + migration20261022010000_social_experience devem acompanhar a entrega. Novos recursos começam desligados. Três migrations aditivas no ZIP cumulativo. Rodar as cinco suites anteriores e tests/social-experience.test.cjs (140 casos no total, Node24 para a fixture SQLite). Não executar reset/db push, alterar .env/dev.db, logar o bot nem implantar sem instrução do usuário. docs/TECHNICAL.md contém detalhes dos novos modelos e limites.

## Jogos e eventos — 22/10/2026

`/jogar [jogo]` é o ponto de entrada privado para membros; `Games de Chat → Painel de participação e resultados` configura o hub público. Prefixos novos: play:, games-admin:/games-select:/games-form:, bg:/bg-admin:/bg-select:/bg-form:, bingo-card: e mystery-panel:. Conferir os arquivos reais dos handlers antes de reutilizar prefixos. Quiz em equipes reaproveita app/war e /guerra; Eventos de interação conserva Game Musical exclusivo de produção. Não sobrescrever app/components/buttons/admEventsMenu.js nem app/events/ready.js a partir de src.

Bingo comunitário é gratuito, opcional e separado da geração/pedidos de cartelas anteriores. Configuração é congelada por partida, e a conferência pausa e registra todos os vencedores aptos no mesmo sorteio. Cartelas podem ser vistas em resposta privada no servidor. Timer roda a cada 2s, sem recuperar uma sequência de sorteios atrasados. Hub atualiza somente a mensagem já publicada a cada minuto, usando publishedStyle separado do rascunho.

Migration 20261022140000_games_experience é a quarta migration cumulativa. Cria quatro tabelas e adiciona snapshots/pontos/compartilhamento do TERMO. BingoOrder e os campos de BingoConfig já estavam nas migrations e no banco fornecido: foram reconciliados no schema, sem recriação SQL. Não alterar banco vivo ou .env. Validar as sete suites (185 testes); typecheck atual tem somente o erro preexistente em denunciaSelects.ts:61. As contagens/erros das seções anteriores registram etapas históricas.


## Mensagens V2 e cargos por reação — 23/10/2026

Leia `src/message-maker/` somente nos arquivos do fluxo necessário e os equivalentes `app/`. Fonte/produção sincronizadas; não transpilar index/dispatcher/admPanel inteiros sobre app/ por conterem funcionalidades adicionais. Prefixos maker:, maker-select: e maker-form:. O dispatcher intercepta embedv2* antes dos handlers legados para importação/abertura segura; não reintroduzir publicação clássica por IDs antigos.

Navegação em sete áreas/29 destinos, categorias somente nos seletores e apresentação curta. Maker em Personalização; reação em Entrada e evolução → Cargos e automações. Atalho copia, não vincula painéis. Modelo, sessão, publicação e painel de cargos têm estados independentes; não propagar edições entre envios. Formulários pertencem ao autor/guild/mensagem, são versionados e atualizam a prévia na origem. `componentMessages` garante retorno aos painéis clássicos sem remover o flag V2 da mensagem; respostas privadas independentes permanecem compatíveis.

Migration20261023180000_message_maker_reaction_roles é a quinta cumulativa e cria oito tabelas sem alterar as anteriores. Preservar concessões preexistentes/de outros painéis e consumo único das confirmações. Nenhum fallback de timeout cria mensagem duplicada; registrar mensagem exige conferir autoria/destino/conteúdo. Reações offline/pausadas usam revisão manual, limite2.000 e lotes25, sem remoção em massa ao salvar. Intents/partials de reação em ambos index; oito eventos maker*. Uma instância por SQLite.

Validação atual substitui contagens históricas: oito suítes, 240 testes offline. Rodar os sete arquivos anteriores mais `tests/message-maker.test.cjs`; fixture compartilhada em tests/fixtures/maker-runtime.cjs e social-runtime.cjs, exige Node>=22.13 (usado24). Produção mantém mínimo22.12 e dependências anteriores. Um erro TypeScript preexistente em denunciaSelects.ts:61; nenhum novo. Nunca logar/deployar o bot ou tocar o banco vivo para um teste offline.


## Central de segurança — 24/10/2026

`protecao` abre security/interactions.open; sete áreas/29 destinos preservados.19 regras novas OFF por padrão; filtros anteriores independentes. Não confundir observação da regra nova com desligar automod antigo. Native V2, categorias no select, PNGs blackout_sec_* da aplicação. BotAdmin consulta, mas alterações exigem proprietário/Administrator do Discord e revisão20min vinculada a guild/actor/mensagem/revisão, consumida uma vez.

Fonte e app/security sincronizados. Não sobrescrever app/events/messageCreate, guildMemberAdd, ready ou admSectionSelect a partir de src/: contêm funções exclusivas. Patches nos eventos são aguardados antes de autorole e exclusão de bots. Auditoria é GuildAuditLogEntryCreate, não inferência por último executor. Eventohistórico, desconhecido, proprietário e próprio bot não são punidos. Janelas de mensagem/voz em memória; cotas de entrada/equipe persistidas. Não reexecutar resposta UNCERTAIN após reinício. Não reverter estado que mudou depois da auditoria. Cargos confiáveis concedidos também são sensíveis; autoatribuição não cria sua própria isenção.

Contenção manual guarda permissões antes da API e restaura somente bits correspondentes à intervenção, com conflitos para revisão. Logs via security.actions e entrega externa existente; incidentes persistem independentemente. Mirror PENDING pode retomar; SENDING anterior vira UNCERTAIN e reenvio é explícito. Captcha/OCR/backup integral/prisão/aprovação em dupla não foram implementados; não apresentar como prontos.

Migration20261024180000_security_center é a sexta cumulativa: oito tabelas novas sem alterar anteriores. Verificador startup atualizado; configs/dependências/slash existentes preservados. Nove suítes,319 testes offline: anteriores mais tests/security-center.test.cjs, fixture security-runtime.cjs reaproveita SQLite real isolado. Typecheck continua com um erro anterior em denunciaSelects.ts:61. Não tocar banco vivo, .env, logar bot ou implantar em testes. Guia: SEGURANCA-BLACKOUT.md.
