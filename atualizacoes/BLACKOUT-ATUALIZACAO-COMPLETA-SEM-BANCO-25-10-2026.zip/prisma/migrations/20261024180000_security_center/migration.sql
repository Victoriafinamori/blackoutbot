-- Additive security center. Existing configuration and member data are untouched.
CREATE TABLE "SecuritySettings" ("guildId" TEXT NOT NULL PRIMARY KEY,"configJson" TEXT NOT NULL DEFAULT '{}',"revision" INTEGER NOT NULL DEFAULT 0,"updatedAt" DATETIME NOT NULL);
CREATE TABLE "SecurityState" ("guildId" TEXT NOT NULL PRIMARY KEY,"raidUntil" DATETIME,"updatedAt" DATETIME NOT NULL);
CREATE TABLE "SecurityIncident" ("id" TEXT NOT NULL PRIMARY KEY,"guildId" TEXT NOT NULL,"eventKey" TEXT NOT NULL,"rule" TEXT NOT NULL,"mode" TEXT NOT NULL,"actorId" TEXT,"targetId" TEXT,"channelId" TEXT,"status" TEXT NOT NULL DEFAULT 'CLAIMED',"action" TEXT NOT NULL,"summary" TEXT NOT NULL,"detailsJson" TEXT NOT NULL DEFAULT '{}',"resultJson" TEXT NOT NULL DEFAULT '{}',"deliveryStatus" TEXT NOT NULL DEFAULT 'PENDING',"deliveryError" TEXT,"createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,"updatedAt" DATETIME NOT NULL);
CREATE UNIQUE INDEX "SecurityIncident_eventKey_key" ON "SecurityIncident"("eventKey");
CREATE INDEX "SecurityIncident_guildId_createdAt_idx" ON "SecurityIncident"("guildId","createdAt");
CREATE INDEX "SecurityIncident_guildId_status_idx" ON "SecurityIncident"("guildId","status");
CREATE TABLE "SecurityAuditEntry" ("id" TEXT NOT NULL PRIMARY KEY,"units" INTEGER NOT NULL DEFAULT 1,"guildId" TEXT NOT NULL,"action" TEXT NOT NULL,"actorId" TEXT,"targetId" TEXT,"happenedAt" DATETIME NOT NULL);
CREATE INDEX "SecurityAuditEntry_guildId_actorId_action_happenedAt_idx" ON "SecurityAuditEntry"("guildId","actorId","action","happenedAt");
CREATE TABLE "SecurityDenyEntry" ("id" TEXT NOT NULL PRIMARY KEY,"guildId" TEXT NOT NULL,"userId" TEXT NOT NULL,"reason" TEXT NOT NULL,"createdById" TEXT NOT NULL,"createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE UNIQUE INDEX "SecurityDenyEntry_guildId_userId_key" ON "SecurityDenyEntry"("guildId","userId");
CREATE TABLE "SecurityReview" ("id" TEXT NOT NULL PRIMARY KEY,"guildId" TEXT NOT NULL,"actorId" TEXT NOT NULL,"messageId" TEXT NOT NULL,"kind" TEXT NOT NULL,"payloadJson" TEXT NOT NULL,"configRevision" INTEGER NOT NULL,"expiresAt" DATETIME NOT NULL,"status" TEXT NOT NULL DEFAULT 'PENDING',"createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX "SecurityReview_guildId_actorId_expiresAt_idx" ON "SecurityReview"("guildId","actorId","expiresAt");
CREATE TABLE "SecurityChannelLock" ("id" TEXT NOT NULL PRIMARY KEY,"guildId" TEXT NOT NULL,"channelId" TEXT NOT NULL,"beforeJson" TEXT NOT NULL,"appliedJson" TEXT NOT NULL,"status" TEXT NOT NULL DEFAULT 'PREPARING',"createdById" TEXT NOT NULL,"expiresAt" DATETIME NOT NULL,"lastError" TEXT,"createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,"updatedAt" DATETIME NOT NULL);
CREATE UNIQUE INDEX "SecurityChannelLock_guildId_channelId_key" ON "SecurityChannelLock"("guildId","channelId");
CREATE INDEX "SecurityChannelLock_status_expiresAt_idx" ON "SecurityChannelLock"("status","expiresAt");
CREATE TABLE "SecurityMemberSnapshot" ("id" TEXT NOT NULL PRIMARY KEY,"guildId" TEXT NOT NULL,"userId" TEXT NOT NULL,"rolesJson" TEXT NOT NULL,"capturedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE UNIQUE INDEX "SecurityMemberSnapshot_guildId_userId_key" ON "SecurityMemberSnapshot"("guildId","userId");
