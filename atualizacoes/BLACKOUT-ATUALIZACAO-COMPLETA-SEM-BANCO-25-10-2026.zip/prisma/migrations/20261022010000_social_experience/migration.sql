-- Additive only: existing tables, media and configuration are preserved.

CREATE TABLE "SocialExperienceConfig" (
  "guildId" TEXT NOT NULL PRIMARY KEY,
  "panelChannelId" TEXT,
  "panelMessageId" TEXT,
  "panelHash" TEXT,
  "dynamicsEnabled" BOOLEAN NOT NULL DEFAULT false,
  "dynamicsChannelId" TEXT,
  "dynamicsKinds" TEXT NOT NULL DEFAULT 'QUESTION,PREFER,POLL,CHALLENGE',
  "dynamicsHour" INTEGER NOT NULL DEFAULT 18,
  "dynamicsMinute" INTEGER NOT NULL DEFAULT 0,
  "dynamicsIntervalDays" INTEGER NOT NULL DEFAULT 1,
  "dynamicsLastDate" TEXT,
  "lastError" TEXT,
  "profilesEnabled" BOOLEAN NOT NULL DEFAULT false,
  "requestsEnabled" BOOLEAN NOT NULL DEFAULT false,
  "requestsModerated" BOOLEAN NOT NULL DEFAULT true,
  "requestsLimit" INTEGER NOT NULL DEFAULT 3,
  "requestsCooldown" INTEGER NOT NULL DEFAULT 60,
  "radioPanelChannelId" TEXT,
  "radioPanelMessageId" TEXT,
  "radioPanelHash" TEXT,
  "anonymousModerated" BOOLEAN NOT NULL DEFAULT false,
  "reviewChannelId" TEXT,
  "updatedAt" DATETIME NOT NULL
);


CREATE TABLE "SocialActivityTemplate" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "guildId" TEXT NOT NULL,
  "kind" TEXT NOT NULL,
  "prompt" TEXT NOT NULL,
  "options" TEXT NOT NULL DEFAULT '[]',
  "enabled" BOOLEAN NOT NULL DEFAULT true,
  "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX "SocialActivityTemplate_guildId_enabled_idx" ON "SocialActivityTemplate"("guildId", "enabled");

CREATE TABLE "SocialActivity" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "guildId" TEXT NOT NULL,
  "scheduleKey" TEXT NOT NULL,
  "kind" TEXT NOT NULL,
  "prompt" TEXT NOT NULL,
  "options" TEXT NOT NULL DEFAULT '[]',
  "channelId" TEXT NOT NULL,
  "messageId" TEXT,
  "status" TEXT NOT NULL DEFAULT 'PROCESSING',
  "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX "SocialActivity_guildId_scheduleKey_key" ON "SocialActivity"("guildId", "scheduleKey");
CREATE INDEX "SocialActivity_guildId_status_createdAt_idx" ON "SocialActivity"("guildId", "status", "createdAt");

CREATE TABLE "SocialActivityResponse" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "activityId" TEXT NOT NULL,
  "guildId" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "content" TEXT NOT NULL,
  "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" DATETIME NOT NULL
);
CREATE UNIQUE INDEX "SocialActivityResponse_activityId_userId_key" ON "SocialActivityResponse"("activityId", "userId");
CREATE INDEX "SocialActivityResponse_guildId_activityId_idx" ON "SocialActivityResponse"("guildId", "activityId");

CREATE TABLE "SocialProfile" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "guildId" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "bio" TEXT NOT NULL DEFAULT '',
  "interests" TEXT NOT NULL DEFAULT '',
  "games" TEXT NOT NULL DEFAULT '',
  "visible" BOOLEAN NOT NULL DEFAULT false,
  "updatedAt" DATETIME NOT NULL
);
CREATE UNIQUE INDEX "SocialProfile_guildId_userId_key" ON "SocialProfile"("guildId", "userId");
CREATE INDEX "SocialProfile_guildId_visible_idx" ON "SocialProfile"("guildId", "visible");

CREATE TABLE "SocialRadioRequest" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "guildId" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "videoId" TEXT NOT NULL,
  "url" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'PENDING',
  "reviewerId" TEXT,
  "error" TEXT,
  "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" DATETIME NOT NULL
);
CREATE INDEX "SocialRadioRequest_guildId_status_createdAt_idx" ON "SocialRadioRequest"("guildId", "status", "createdAt");
CREATE INDEX "SocialRadioRequest_guildId_userId_createdAt_idx" ON "SocialRadioRequest"("guildId", "userId", "createdAt");

CREATE TABLE "SocialRadioVote" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "guildId" TEXT NOT NULL,
  "playToken" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX "SocialRadioVote_guildId_playToken_userId_key" ON "SocialRadioVote"("guildId", "playToken", "userId");

CREATE TABLE "SocialSubmission" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "guildId" TEXT NOT NULL,
  "authorId" TEXT NOT NULL,
  "kind" TEXT NOT NULL,
  "content" TEXT NOT NULL DEFAULT '',
  "mediaUrl" TEXT,
  "mediaName" TEXT,
  "mediaType" TEXT,
  "sourceChannelId" TEXT,
  "sourceMessageId" TEXT,
  "reviewChannelId" TEXT,
  "reviewMessageId" TEXT,
  "reviewerId" TEXT,
  "status" TEXT NOT NULL DEFAULT 'DRAFT',
  "resultId" TEXT,
  "error" TEXT,
  "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "expiresAt" DATETIME NOT NULL
);
CREATE INDEX "SocialSubmission_guildId_status_createdAt_idx" ON "SocialSubmission"("guildId", "status", "createdAt");
CREATE INDEX "SocialSubmission_guildId_authorId_createdAt_idx" ON "SocialSubmission"("guildId", "authorId", "createdAt");

CREATE TABLE "SocialAnonymousPreference" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "guildId" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "allowDms" BOOLEAN NOT NULL DEFAULT true,
  "updatedAt" DATETIME NOT NULL
);
CREATE UNIQUE INDEX "SocialAnonymousPreference_guildId_userId_key" ON "SocialAnonymousPreference"("guildId", "userId");

CREATE TABLE "SocialAnonymousBlock" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "guildId" TEXT NOT NULL,
  "blockerId" TEXT NOT NULL,
  "blockedId" TEXT NOT NULL,
  "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX "SocialAnonymousBlock_guildId_blockerId_blockedId_key" ON "SocialAnonymousBlock"("guildId", "blockerId", "blockedId");

CREATE TABLE "SocialAnonymousDelivery" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "guildId" TEXT NOT NULL,
  "senderId" TEXT NOT NULL,
  "recipientId" TEXT NOT NULL,
  "publicId" TEXT NOT NULL,
  "content" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'PROCESSING',
  "reportedAt" DATETIME,
  "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "expiresAt" DATETIME NOT NULL
);
CREATE INDEX "SocialAnonymousDelivery_guildId_senderId_createdAt_idx" ON "SocialAnonymousDelivery"("guildId", "senderId", "createdAt");
