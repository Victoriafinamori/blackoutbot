-- Additive only: existing tables, media and configuration are preserved.

CREATE TABLE "BingoExperienceConfig" (
  "guildId" TEXT NOT NULL PRIMARY KEY,
  "channelId" TEXT,
  "title" TEXT NOT NULL DEFAULT 'Bingo da comunidade',
  "description" TEXT NOT NULL DEFAULT 'Entre, receba sua cartela e acompanhe a rodada aqui no servidor.',
  "color" TEXT NOT NULL DEFAULT 'D71935',
  "footer" TEXT NOT NULL DEFAULT 'Uma cartela por pessoa · Participação gratuita',
  "objective" TEXT NOT NULL DEFAULT 'ANY_LINE',
  "minPlayers" INTEGER NOT NULL DEFAULT 2,
  "maxPlayers" INTEGER NOT NULL DEFAULT 100,
  "automatic" BOOLEAN NOT NULL DEFAULT false,
  "intervalSeconds" INTEGER NOT NULL DEFAULT 15,
  "updatedAt" DATETIME NOT NULL
);


CREATE TABLE "BingoExperienceState" (
  "matchId" TEXT NOT NULL PRIMARY KEY,
  "guildId" TEXT NOT NULL,
  "mode" TEXT NOT NULL DEFAULT 'FREE',
  "phase" TEXT NOT NULL DEFAULT 'LOBBY',
  "objective" TEXT NOT NULL DEFAULT 'ANY_LINE',
  "minPlayers" INTEGER NOT NULL DEFAULT 2,
  "maxPlayers" INTEGER NOT NULL DEFAULT 100,
  "automatic" BOOLEAN NOT NULL DEFAULT false,
  "intervalSeconds" INTEGER NOT NULL DEFAULT 15,
  "nextDrawAt" DATETIME,
  "drawVersion" INTEGER NOT NULL DEFAULT 0,
  "lastError" TEXT,
  "updatedAt" DATETIME NOT NULL
);
CREATE INDEX "BingoExperienceState_guildId_phase_idx" ON "BingoExperienceState"("guildId", "phase");

CREATE TABLE "BingoExperienceClaim" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "guildId" TEXT NOT NULL,
  "matchId" TEXT NOT NULL,
  "cardId" TEXT NOT NULL,
  "playerId" TEXT NOT NULL,
  "drawVersion" INTEGER NOT NULL,
  "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX "BingoExperienceClaim_matchId_cardId_key" ON "BingoExperienceClaim"("matchId", "cardId");
CREATE INDEX "BingoExperienceClaim_guildId_matchId_idx" ON "BingoExperienceClaim"("guildId", "matchId");

CREATE TABLE "GamesHubConfig" (
  "guildId" TEXT NOT NULL PRIMARY KEY,
  "channelId" TEXT,
  "messageId" TEXT,
  "publishedHash" TEXT,
  "publishedStyle" TEXT,
  "title" TEXT NOT NULL DEFAULT 'Escolha seu próximo jogo',
  "description" TEXT NOT NULL DEFAULT 'Jogue no seu ritmo ou participe de um evento com a comunidade.',
  "color" TEXT NOT NULL DEFAULT 'D71935',
  "footer" TEXT NOT NULL DEFAULT 'Seus jogos e resultados valem somente neste servidor.',
  "mysteryIndividualAnnouncements" BOOLEAN NOT NULL DEFAULT true,
  "updatedAt" DATETIME NOT NULL
);


ALTER TABLE "TermoRound" ADD COLUMN "maxAttemptsSnapshot" INTEGER;
ALTER TABLE "TermoRound" ADD COLUMN "wordLengthSnapshot" INTEGER;
ALTER TABLE "TermoGame" ADD COLUMN "pointsEarned" INTEGER NOT NULL DEFAULT 0;
UPDATE "TermoGame" SET "pointsEarned" = MAX(10, 100 - 10 * "attemptsUsed") WHERE "status" = 'WON';

ALTER TABLE "TermoGame" ADD COLUMN "sharedMessageId" TEXT;
