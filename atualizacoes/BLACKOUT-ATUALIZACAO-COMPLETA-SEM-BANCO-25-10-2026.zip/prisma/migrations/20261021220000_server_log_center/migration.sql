CREATE TABLE "ServerLogSettings" (
 "guildId" TEXT NOT NULL PRIMARY KEY,
 "deliveryMode" TEXT NOT NULL DEFAULT 'LOCAL',
 "eventsJson" TEXT NOT NULL DEFAULT '{}',
 "localChannelsJson" TEXT NOT NULL DEFAULT '{}',
 "externalChannelsJson" TEXT NOT NULL DEFAULT '{}',
 "externalGuildId" TEXT,
 "externalChannelId" TEXT,
 "externalAuthorizedBy" TEXT,
 "ignoredChannelIds" TEXT NOT NULL DEFAULT '[]',
 "ignoredRoleIds" TEXT NOT NULL DEFAULT '[]',
 "ignoreBots" BOOLEAN NOT NULL DEFAULT true,
 "updatedAt" DATETIME NOT NULL
);
