-- Additive: no existing table, column, model or published message is replaced.

CREATE TABLE "MakerTemplate" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "guildId" TEXT NOT NULL,
  "legacyId" TEXT,
  "name" TEXT NOT NULL,
  "documentJson" TEXT NOT NULL,
  "revision" INTEGER NOT NULL DEFAULT 0,
  "createdById" TEXT,
  "deletedAt" DATETIME,
  "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" DATETIME NOT NULL
);

CREATE TABLE "MakerPublication" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "guildId" TEXT NOT NULL,
  "templateId" TEXT,
  "panelId" TEXT,
  "channelId" TEXT NOT NULL,
  "messageId" TEXT,
  "name" TEXT NOT NULL,
  "snapshotJson" TEXT NOT NULL,
  "payloadHash" TEXT,
  "status" TEXT NOT NULL DEFAULT 'SENDING',
  "legacy" BOOLEAN NOT NULL DEFAULT false,
  "revision" INTEGER NOT NULL DEFAULT 0,
  "lastError" TEXT,
  "createdById" TEXT,
  "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" DATETIME NOT NULL
);

CREATE TABLE "MakerSession" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "guildId" TEXT NOT NULL,
  "actorId" TEXT NOT NULL,
  "sourceMessageId" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "documentJson" TEXT NOT NULL,
  "undoJson" TEXT,
  "templateId" TEXT,
  "templateRevision" INTEGER,
  "publicationId" TEXT,
  "publicationRevision" INTEGER,
  "panelId" TEXT,
  "panelRevision" INTEGER,
  "destinationChannelId" TEXT,
  "selectedBlockId" TEXT,
  "revision" INTEGER NOT NULL DEFAULT 0,
  "expiresAt" DATETIME NOT NULL,
  "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" DATETIME NOT NULL
);

CREATE TABLE "MakerAction" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "guildId" TEXT NOT NULL,
  "actorId" TEXT NOT NULL,
  "sourceMessageId" TEXT NOT NULL,
  "kind" TEXT NOT NULL,
  "targetId" TEXT,
  "payloadJson" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'READY',
  "cursor" INTEGER NOT NULL DEFAULT 0,
  "usedAt" DATETIME,
  "expiresAt" DATETIME NOT NULL,
  "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" DATETIME NOT NULL
);

CREATE TABLE "ReactionRolePanel" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "guildId" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "documentJson" TEXT NOT NULL,
  "channelId" TEXT,
  "publicationId" TEXT,
  "status" TEXT NOT NULL DEFAULT 'DRAFT',
  "removeOnUnreact" BOOLEAN NOT NULL DEFAULT true,
  "publishedRemoveOnUnreact" BOOLEAN NOT NULL DEFAULT true,
  "revision" INTEGER NOT NULL DEFAULT 0,
  "lastError" TEXT,
  "createdById" TEXT,
  "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" DATETIME NOT NULL
);

CREATE TABLE "ReactionRoleBinding" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "guildId" TEXT NOT NULL,
  "panelId" TEXT NOT NULL,
  "emojiKey" TEXT NOT NULL,
  "emojiDisplay" TEXT NOT NULL,
  "emojiApi" TEXT NOT NULL,
  "roleId" TEXT NOT NULL,
  "active" BOOLEAN NOT NULL DEFAULT true,
  "published" BOOLEAN NOT NULL DEFAULT false,
  "retirement" TEXT,
  "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" DATETIME NOT NULL
);

CREATE TABLE "ReactionRoleGrant" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "guildId" TEXT NOT NULL,
  "panelId" TEXT NOT NULL,
  "bindingId" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "roleId" TEXT NOT NULL,
  "active" BOOLEAN NOT NULL DEFAULT true,
  "status" TEXT NOT NULL DEFAULT 'PENDING',
  "lastError" TEXT,
  "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" DATETIME NOT NULL
);

CREATE TABLE "ReactionRoleOwnership" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "guildId" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "roleId" TEXT NOT NULL,
  "state" TEXT NOT NULL,
  "updatedAt" DATETIME NOT NULL
);

CREATE UNIQUE INDEX "MakerTemplate_legacyId_key" ON "MakerTemplate"("legacyId");

CREATE INDEX "MakerTemplate_guildId_deletedAt_updatedAt_idx" ON "MakerTemplate"("guildId", "deletedAt", "updatedAt");

CREATE UNIQUE INDEX "MakerPublication_panelId_key" ON "MakerPublication"("panelId");

CREATE UNIQUE INDEX "MakerPublication_messageId_key" ON "MakerPublication"("messageId");

CREATE INDEX "MakerPublication_guildId_updatedAt_idx" ON "MakerPublication"("guildId", "updatedAt");

CREATE INDEX "MakerSession_guildId_actorId_expiresAt_idx" ON "MakerSession"("guildId", "actorId", "expiresAt");

CREATE INDEX "MakerAction_guildId_actorId_expiresAt_idx" ON "MakerAction"("guildId", "actorId", "expiresAt");

CREATE UNIQUE INDEX "ReactionRolePanel_publicationId_key" ON "ReactionRolePanel"("publicationId");

CREATE INDEX "ReactionRolePanel_guildId_updatedAt_idx" ON "ReactionRolePanel"("guildId", "updatedAt");

CREATE INDEX "ReactionRoleBinding_guildId_panelId_active_idx" ON "ReactionRoleBinding"("guildId", "panelId", "active");

CREATE UNIQUE INDEX "ReactionRoleGrant_bindingId_userId_key" ON "ReactionRoleGrant"("bindingId", "userId");

CREATE INDEX "ReactionRoleGrant_guildId_userId_roleId_active_idx" ON "ReactionRoleGrant"("guildId", "userId", "roleId", "active");

CREATE INDEX "ReactionRoleGrant_panelId_bindingId_status_idx" ON "ReactionRoleGrant"("panelId", "bindingId", "status");

CREATE UNIQUE INDEX "ReactionRoleOwnership_guildId_userId_roleId_key" ON "ReactionRoleOwnership"("guildId", "userId", "roleId");
