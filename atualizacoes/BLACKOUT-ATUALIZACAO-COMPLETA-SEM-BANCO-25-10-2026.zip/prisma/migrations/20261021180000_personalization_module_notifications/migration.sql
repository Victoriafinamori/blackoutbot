-- NULL preserves the existing shared DM preference until a module is configured.
ALTER TABLE "GuildConfig" ADD COLUMN "moderationNotifyDm" BOOLEAN;
ALTER TABLE "GuildConfig" ADD COLUMN "reintegrationNotifyDm" BOOLEAN;
-- Older publications have no known content fingerprint and are shown as needing review.
ALTER TABLE "CustomEmbed" ADD COLUMN "publishedPayloadHash" TEXT;
