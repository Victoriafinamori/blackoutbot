BLACKOUT SOCIAL — MÍDIA, CURTIDAS E COMENTÁRIOS (22/10/2026)

As publicações novas usam um cartão nativo Components V2 com MediaGallery.
Imagem, GIF e vídeo compartilham o mesmo fluxo, incluindo o player de vídeo.
EmbedBuilder clássico não incorpora esse player de vídeo.

Curtidas/comentários:
- atualizam as contagens e os controles no cartão existente;
- preservam explicitamente os IDs dos anexos;
- não reenviam o arquivo nem recriam a mensagem;
- mantêm attachment:// nas publicações com anexo próprio;
- convertem embeds antigos para V2 limpando os campos legados.

O original só é removido após upload e persistência confirmados.
Falhas preservam o original. Destaques também usam o formato V2.
URLs históricas podem ser renovadas a partir do anexo exato no mesmo servidor,
limitado ao histórico recente. Arquivos antigos indisponíveis exigem reenvio.

Arquivos: app/social/{service,media}.js e app/social-experience/posts.js.
Validação offline: tests/social-experience.test.cjs.
A reprodução real deve ser conferida no Discord após aplicar a atualização.
