# BLACKOUT — Central de segurança

Abra `/adm → Equipe e proteção → Central de segurança`.

As **19 regras novas começam desligadas**. Cada regra permite escolher Desligado, Observar e registrar ou Aplicar proteção. Filtros antigos e suas preferências continuam independentes e podem agir mesmo quando uma regra nova está apenas em observação. A entrada Chat e conteúdo mantém o acesso a Palavras, links e filtros existentes.

## Configurar uma proteção

1. Escolha a categoria e a regra no seletor. A mensagem mostra o modo, a resposta e os limites atuais.
2. Ajuste os limites ou escolha modo/resposta. Confira a proposta na própria mensagem e confirme para salvar. Cancelar preserva a configuração anterior.
3. Em Exceções e diagnóstico, cadastre contas/bots confiáveis, cargos confiáveis, pessoas/cargos protegidos e canais que devem ser ignorados. IDs de bots podem ser informados antes de adicioná-los ao servidor.
4. Use Conferir funcionamento. Comece por observação, confira ocorrências e ajuste as exceções antes de escolher Aplicar proteção. O diagnóstico não executa ações sobre membros.
5. Em Logs de segurança, configure o destino da categoria Servidor e segurança na central de logs existente. O destino pode ser local, externo ou ambos, com as autorizações anteriores preservadas.

Administradores do bot podem consultar os painéis. **Alterar regras, exceções, contenções e confirmações exige Administrador do Discord ou ser proprietário do servidor.** As revisões pertencem ao autor, servidor e mensagem, expiram em 20 minutos e são usadas uma única vez. Mudanças nas regras invalidam revisões anteriores.

## Entrada e Anti-Raid — quatro regras

- **Anti-Raid:** detecta um pico de entradas na janela escolhida. Em Aplicar proteção, a resposta vale para novas entradas durante o período configurado: registrar, silenciar temporariamente ou expulsar. Não expulsa os membros que já estavam no servidor. Os contadores de entrada e o prazo ficam persistidos no banco.
- **Entrada de bots:** registra ou expulsa bots não autorizados nas exceções. Cadastre previamente os IDs dos bots que deseja permitir.
- **Idade mínima da conta:** verifica dias desde a criação, com resposta configurável. Isso não comprova identidade nem identifica com certeza uma pessoa “fake”.
- **Lista de entrada bloqueada:** cadastro próprio de usuário/ID e motivo. Na próxima entrada, observa ou expulsa conforme o modo vigente. Não expulsa retroativamente quem já está dentro. Esta lista não modifica a blacklist específica da reintegração.

O bot consulta as regras antes de atribuir cargos automáticos de chegada. Proprietário, o próprio bot e exceções confiáveis são preservados. Contas que o Discord não permite silenciar/expulsar geram falha no histórico, sem punição alternativa mais forte.

## Chat e conteúdo — sete regras

Excesso de menções; tamanho/linhas de texto; convites do Discord com ou sem https; volume de mensagens por membro/canal; texto repetido; flood por webhook; canal-isca HoneyPot.

As respostas disponíveis dependem da regra: registrar, apagar mensagem, apagar e silenciar, ou excluir o webhook responsável quando essa resposta tiver sido escolhida explicitamente. Webhooks são avaliados antes da exclusão de mensagens de bots no fluxo antigo; bots comuns não entram nos filtros de conteúdo novos. Edições são verificadas por texto, menções, convites e canal-isca, sem contar a edição como uma nova mensagem de flood.

Códigos de convite autorizados ficam nas exceções. O HoneyPot precisa ser um canal exclusivo, sinalizado para não receber mensagens normais; ele não é criado ou ocultado automaticamente. Não o coloque nos canais/categorias ignorados.

Janelas de flood/repetição e movimentação observada em call são limitadas e ficam em memória, reiniciando com o processo. Eventos repetidos não repetem a resposta registrada. A observação de conteúdo limita o ruído de registros por regra/membro/canal; não guarda cópias integrais das mensagens nesses incidentes.

## Anti Ban e ações da equipe — seis regras

- **Anti Ban:** cota por executor/janela e proteção de pessoas/cargos cadastrados. Pode registrar, retirar cargos perigosos editáveis do executor ou conter e desbanir **o alvo daquele incidente**, quando esta última resposta for escolhida. Não desbane todos os bans anteriores nem recoloca alguém no servidor automaticamente.
- **Limite de expulsões:** detecta cota excedida ou alvo protegido; contenção não consegue trazer de volta quem já foi expulso.
- **Cargos e permissões:** revisa concessões sensíveis, remoção de cargos protegidos/confiáveis e alterações de permissões de cargos. Nos canais/categorias cadastrados em Permissões de canais protegidos, também pode restaurar criação/edição/exclusão de exceções de acesso, com dados completos e atuais da auditoria.
- **Castigos de membros protegidos:** revisa timeout de alvo protegido e pode restaurar o estado anterior confirmado.
- **Alterações destrutivas em massa:** detecta sequência de exclusões de canais/cargos e criação de webhooks e pode retirar cargos perigosos do executor. Não recria canais/cargos apagados nem recupera mensagens.
- **Alteração da URL do servidor:** registra a mudança confirmada da URL personalizada. Não oferece promessa de reserva ou recuperação de URL.

A proteção usa **executor confirmado pela auditoria do Discord**, depois que a ação ocorre. Não impede a primeira ação antes de o Discord registrá-la. Histórico antigo não é executado como ataque atual. Ban e cotas da equipe são persistidos, sem depender apenas de janelas em memória.

A hierarquia do bot limita toda contenção. Cargos de integrações, cargos superiores e proprietário não podem ser removidos livremente. As reversões conferem se o alvo ainda corresponde ao evento; alterações posteriores e evidência incompleta levam a revisão manual. Permissões/cargos de confiáveis concedem exceção e devem ser atribuídos somente por pessoas autorizadas. Com a regra de cargos ativa, conceder um cargo confiável também é tratado como sensível; autoatribuir esse cargo não isenta a própria concessão auditada.

Para alvo banido/expulso, o cargo anterior só é considerado quando existe cache ou snapshot recente confiável. Cadastre usuários individualmente quando precisar de proteção explícita que não dependa desse dado.

## Proteção de calls — duas regras

**Movimentação excessiva em call** registra entradas/saídas/trocas repetidas sem atribuir culpa a quem foi movido. O evento comum de voz não informa seu executor; esta regra não pune o membro.

**Abuso de movimentação pela equipe** usa auditoria com executor confirmado e considera a quantidade agregada quando o Discord a informa. Pode conter o executor configurado, respeitando cargos, exceções e hierarquia.

## Incidentes e contenção

O histórico guarda regra, modo, executor conhecido, alvo, auditoria quando disponível, ação planejada, resultado e estado do encaminhamento do log. Resposta aplicada, parcial, falha, cancelamento e resultado não confirmado aparecem separados. O incidente permanece no banco mesmo que o canal de log esteja indisponível ou o encaminhamento esteja desligado. Reenviar log abre revisão e nunca repete uma punição.

**Restringir chats temporariamente** usa somente os canais escolhidos para contenção, prazo de 1 a 60 minutos e confirmação explícita. Guarda permissões anteriores e restringe escrita/criação de tópicos, inclusive exceções de escrita existentes. Administradores mantêm o acesso nativo. Ao vencer, tenta restaurar; se o bot estiver desligado, retoma ao iniciar. Mudanças posteriores observadas da equipe são preservadas; conflitos ficam para revisão manual. Não há garantia de transação atômica com edições simultâneas na API.

Liberar chats processa até 25 canais por revisão. Quando restam somente conflitos, Concluir revisão dos conflitos permite confirmar que o acesso foi conferido manualmente: mantém as permissões atuais e encerra a pendência, sem alterar o canal. Uma futura contenção usa esse estado atual como nova referência. Estados de falha ou não confirmação não são anunciados como sucesso. Encerrar contenção de entrada termina o ciclo atual, preserva castigos anteriores e mantém o Anti-Raid no modo configurado, que pode detectar outro pico.

## Permissões, instalação e limites

- Auditoria: Ver Registro de Auditoria e intent GuildModeration, já solicitado pelo código.
- Entrada: Server Members habilitado/aprovado quando exigido, Expulsar Membros ou Moderar Membros conforme a resposta.
- Chat: Message Content quando exigido, acesso aos canais e Gerenciar Mensagens. Excluir webhook exige Gerenciar Webhooks.
- Contenção/reversão: Gerenciar Cargos, permissões/hierarquia adequadas e Banir Membros ou Moderar Membros conforme a ação. Restrições de chats exigem Gerenciar Canais e Gerenciar Cargos no canal.
- PNGs: seis novos desenhos em preto/branco/vermelho e o ícone aprovado de headset para calls; sete PNGs RGBA 128×128 usados como emojis da aplicação. Não ocupam os slots de emojis do servidor. Sem provisionamento, permanecem rótulos e imagem local nos painéis.
- Produção: uma instância por SQLite. `app/index.js` continua sendo a entrada da Square Cloud. Não copie dist/ inteiro por cima de app/.
- Migration aditiva: `20261024180000_security_center`, oito tabelas independentes. O pacote cumulativo mantém as cinco anteriores. Nunca substituir prisma/dev.db, executar reset/db push ou enviar banco/credenciais junto do patch.

O processo não repete automaticamente punições cujo resultado ficou incerto após reinício. Logs ainda não tentados podem ser retomados; entregas incertas/parciais exigem conferência e reenvio explícito. Não há garantia de entrega exatamente uma vez entre Discord e SQLite. Registros brutos de contagem são limpos gradualmente depois de dois dias; snapshots antigos e revisões expiradas, depois do prazo técnico. O histórico de incidentes não é apagado por essa rotina.

Esta etapa implementa o núcleo preventivo e operacional acima. Captcha, prisão com restrição completa de acesso, OCR, backup/restauração integral de servidor e aprovação de bans por segunda pessoa são expansões separadas. Não são anunciados como entregues. Nenhuma proteção garante identificar selfbots ou consultar todos os servidores de um usuário.
