import { prisma } from "../database/prisma";
export const LOG_GROUPS:Record<string,string>={members:"Membros",voice:"Calls",messages:"Mensagens",moderation:"Moderação",security:"Servidor e segurança",system:"Sistemas do bot",reintegration:"Reintegração"};
export const LOG_EVENTS:Record<string,{label:string;group:string;enabled:boolean}>={
 "member.join":{label:"Entrada de membro",group:"members",enabled:true},
 "member.leave":{label:"Saída de membro",group:"members",enabled:true},
 "member.nickname":{label:"Alteração de apelido",group:"members",enabled:false},
 "member.roles":{label:"Alteração de cargos do membro",group:"members",enabled:false},
 "voice.join":{label:"Entrada em call",group:"voice",enabled:false},
 "voice.leave":{label:"Saída de call",group:"voice",enabled:false},
 "voice.move":{label:"Troca de call",group:"voice",enabled:false},
 "voice.state":{label:"Silêncio e áudio em call",group:"voice",enabled:false},
 "message.edit":{label:"Mensagem editada",group:"messages",enabled:false},
 "message.delete":{label:"Mensagem excluída",group:"messages",enabled:false},
 "message.bulk":{label:"Exclusão em massa (um registro)",group:"messages",enabled:false},
 "moderation.actions":{label:"Ações de moderação pelo bot",group:"moderation",enabled:true},
 "moderation.ban":{label:"Banimento fora do bot (auditoria)",group:"moderation",enabled:false},
 "moderation.unban":{label:"Desbanimento fora do bot (auditoria)",group:"moderation",enabled:false},
 "security.actions":{label:"Proteção e segurança pelo bot",group:"security",enabled:true},
 "channel.create":{label:"Canal criado",group:"security",enabled:false},
 "channel.update":{label:"Canal ou permissões alterados",group:"security",enabled:false},
 "channel.delete":{label:"Canal excluído",group:"security",enabled:false},
 "role.create":{label:"Cargo criado",group:"security",enabled:false},
 "role.update":{label:"Cargo ou permissões alterados",group:"security",enabled:false},
 "role.delete":{label:"Cargo excluído",group:"security",enabled:false},
 "guild.update":{label:"Configurações do servidor",group:"security",enabled:false},
 "system.actions":{label:"Configurações e operações do bot",group:"system",enabled:true},
 "reintegration.actions":{label:"Etapas e reintegração",group:"reintegration",enabled:true},
};
export function objectJson(raw:any):Record<string,any>{try{const v=JSON.parse(raw||"{}");return v&&typeof v==="object"&&!Array.isArray(v)?v:{}}catch{return {}}}
export function idList(raw:any):string[]{try{const v=JSON.parse(raw||"[]");return Array.isArray(v)?[...new Set(v.filter((id:any)=>typeof id==="string"&&/^\d{15,25}$/.test(id)))].slice(0,25):[]}catch{return []}}
export function normalizeSettings(row:any,guildId:string){
 const flags=objectJson(row?.eventsJson),events=Object.fromEntries(Object.entries(LOG_EVENTS).map(([key,info])=>[key,typeof flags[key]==="boolean"?flags[key]:info.enabled]));
 return {guildId,deliveryMode:["LOCAL","EXTERNAL","BOTH"].includes(row?.deliveryMode)?row.deliveryMode:"LOCAL",events,
  localChannels:objectJson(row?.localChannelsJson),externalChannels:objectJson(row?.externalChannelsJson),externalGuildId:row?.externalGuildId??null,externalChannelId:row?.externalChannelId??null,externalAuthorizedBy:row?.externalAuthorizedBy??null,
  ignoredChannels:idList(row?.ignoredChannelIds),ignoredRoles:idList(row?.ignoredRoleIds),ignoreBots:row?.ignoreBots??true,configured:!!row};
}
export type LogSettings=ReturnType<typeof normalizeSettings>;
const cache=new Map<string,{until:number;value:LogSettings}>();
export function clearLogSettingsCache(id?:string){if(id)cache.delete(id);else cache.clear()}
export async function readLogSettings(guildId:string,fresh=false):Promise<LogSettings>{
 const existing=cache.get(guildId);if(!fresh&&existing&&existing.until>Date.now())return existing.value;
 const value=normalizeSettings(await prisma.serverLogSettings.findUnique({where:{guildId}}),guildId);
 if(cache.size>=500)cache.delete(cache.keys().next().value!);cache.set(guildId,{until:Date.now()+2000,value});return value;
}
export async function saveLogSettings(guildId:string,data:any){
 await prisma.serverLogSettings.upsert({where:{guildId},create:{guildId,...data},update:data});clearLogSettingsCache(guildId);return readLogSettings(guildId,true);
}
