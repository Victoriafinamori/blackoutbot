import { ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, ChannelSelectMenuBuilder, RoleSelectMenuBuilder, ChannelType, ModalBuilder, TextInputBuilder, TextInputStyle, PermissionFlagsBits } from "discord.js";
import { adminEmbed } from "../utils/adminUi";
import { admEmoji, adminEmojiImage, AdminArea } from "../utils/admEmojis";
import { refreshPanel, deferPanel } from "../utils/panelInteraction";
import { getOrCreateGuildConfig } from "../database/guildConfig";
import { LOG_EVENTS, LOG_GROUPS, readLogSettings } from "./config";
import { logHealth, validateExternal, usableLogChannel, resolveLocalLogChannel } from "./delivery";
const button=(id:string,label:string,style=ButtonStyle.Secondary)=>new ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style);
const row=(...buttons:ButtonBuilder[])=>new ActionRowBuilder<ButtonBuilder>().addComponents(buttons);
const back=(page="home")=>row(button(`logs-center:${page}`,"Voltar"));
const modeNames:Record<string,string>={LOCAL:"Neste servidor",EXTERNAL:"Somente no servidor externo",BOTH:"Nos dois servidores"};
export const LOG_UI_GROUPS:Record<string,string>={members:"Membros",voice:"Calls",messages:"Mensagens",moderation:"Moderação",security:"Servidor e segurança",bot:"Sistemas do bot"};
export function logEventGroups(group:string){return group==="bot"?["system","reintegration"]:Object.prototype.hasOwnProperty.call(LOG_GROUPS,group)?[group]:[]}
const groupAreas:Record<string,AdminArea>={members:"membros",voice:"atendimento",messages:"entretenimento",moderation:"seguranca",security:"seguranca",bot:"sistema",system:"sistema",reintegration:"membros"};
function options(guild:any,groups:Record<string,string>){return Object.entries(groups).map(([value,label])=>{const id=admEmoji(guild,groupAreas[value]??"seguranca");return {value,label,...(id?{emoji:{id}}:{})}})}
function selector(id:string,placeholder:string,values:any[]){return new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(new StringSelectMenuBuilder().setCustomId(id).setPlaceholder(placeholder).addOptions(values))}
async function show(i:any,title:string,description:string,fields:any[],components:any[],notice?:string,group?:string){
 const e=adminEmbed(i.guild,"seguranca").setTitle(title).setDescription(description);
 if(group)e.setThumbnail(adminEmojiImage(i.guild,groupAreas[group]??"seguranca")??null);
 if(fields.length)e.addFields(fields);if(notice)e.addFields({name:"Resultado",value:notice.slice(0,1024)});
 return refreshPanel(i,{content:null,attachments:[],embeds:[e],components,allowedMentions:{parse:[]}});
}
async function namedChannel(guild:any,id:string|null|undefined){
 if(!id)return "Canal geral não definido";
 try{const ch=await guild.channels.fetch(id);return ch?.guildId===guild.id?`#${ch.name??"canal de logs"}`:"Canal excluído ou inacessível"}catch{return "Canal excluído ou inacessível"}
}
async function externalName(guild:any,id:string|null){if(!id)return null;try{return await guild.client.guilds.fetch(id)}catch{return null}}
async function activeSummary(i:any,s:any){
 const lines:string[]=[],issues:string[]=[];
 if(s.deliveryMode!=="EXTERNAL"){
  const c=await getOrCreateGuildConfig(i.guild.id);lines.push(`${i.guild.name??"Este servidor"} → ${c.logChannelId?await namedChannel(i.guild,c.logChannelId):"canais por categoria"}`);
  const groups=[...new Set(Object.entries(LOG_EVENTS).filter(([id])=>s.events[id]).map(([,v])=>v.group))];
  const missing:string[]=[];
  for(const group of groups){try{if(!await resolveLocalLogChannel(i.guild,group,s))missing.push(LOG_GROUPS[group])}catch(e:any){issues.push(`${LOG_GROUPS[group]}: ${e.message}`)}}
  if(missing.length){issues.push(missing.length===groups.length?"Escolha um canal geral em Onde enviar.":`Defina destinos para: ${missing.join(", ")}.`);if(missing.length===groups.length)lines[lines.length-1]=`${i.guild.name??"Este servidor"} → destino não definido`;}
 }
 if(s.deliveryMode!=="LOCAL"){
  const target=await externalName(i.guild,s.externalGuildId);lines.push(`${target?.name??"Servidor externo indisponível"} → ${target?await namedChannel(target,s.externalChannelId):"revise o destino"}`);
  try{const validated=await validateExternal(i.guild,s);const groups=[...new Set(Object.entries(LOG_EVENTS).filter(([id])=>s.events[id]).map(([,v])=>v.group))];for(const group of groups){const id=s.externalChannels[group];if(id)await usableLogChannel(validated,id)}}catch(e:any){issues.push(e.message)}
 }
 return {text:`${modeNames[s.deliveryMode]}\n${lines.join("\n")}`.slice(0,1024),issues:[...new Set(issues)]};
}
export async function renderLogHome(i:any){
 await deferPanel(i);const s=await readLogSettings(i.guild.id,true),summary=await activeSummary(i,s);
 const fields=[{name:"Envio",value:summary.text},{name:"Eventos",value:`${Object.values(s.events).filter(Boolean).length} de ${Object.keys(LOG_EVENTS).length} ativados`}];
 if(summary.issues.length)fields.push({name:"Pendências",value:summary.issues.join("\n").slice(0,1024)});
 return show(i,"Logs e auditoria","Configure os registros do servidor em quatro passos.",fields,[
 row(button("logs-center:events","O que registrar"),button("logs-center:destination","Onde enviar")),
 row(button("logs-center:filters","O que ignorar"),button("logs-center:diagnostic","Testar envio")),
 row(button("adm-logs:auditoria","Ações da equipe"),button("logs-center:modules","Logs de Tickets e Registro")),
 row(button("adm-nav:seguranca","Voltar"))]);
}
export async function renderLogEvents(i:any,group?:string,notice?:string){
 const s=await readLogSettings(i.guild.id,true),groups=logEventGroups(group??"");
 if(!groups.length)return show(i,"O que registrar","Escolha uma categoria e marque os eventos que deseja acompanhar.",Object.entries(LOG_UI_GROUPS).map(([key,label])=>{const events=Object.entries(LOG_EVENTS).filter(([,v])=>logEventGroups(key).includes(v.group));return {name:label,value:`${events.filter(([id])=>s.events[id]).length}/${events.length} eventos ativados`}}),[selector("logs-center-select:group","Escolha a categoria",options(i.guild,LOG_UI_GROUPS)),back()]);
 const events=Object.entries(LOG_EVENTS).filter(([,v])=>groups.includes(v.group));
 const select=new StringSelectMenuBuilder().setCustomId(`logs-center-select:events:${group}`).setPlaceholder("Marque os eventos que deseja registrar").setMinValues(0).setMaxValues(events.length).addOptions(events.map(([value,v])=>({value,label:v.label,default:s.events[value]})));
 return show(i,LOG_UI_GROUPS[group!]??LOG_GROUPS[group!],"A seleção é salva nesta embed. Deixe vazio para desativar os eventos desta categoria.",events.map(([id,v])=>({name:v.label,value:s.events[id]?"Ativado":"Desativado"})),[new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select),row(button("logs-center:help:events","Sobre os registros"),button("logs-center:events","Voltar"))],notice,group);
}
export async function renderLogDestination(i:any,notice?:string){
 await deferPanel(i);const s=await readLogSettings(i.guild.id,true),c=await getOrCreateGuildConfig(i.guild.id),target=await externalName(i.guild,s.externalGuildId);
 const fields=[{name:"Modo atual",value:modeNames[s.deliveryMode]}],components:any[]=[selector("logs-center-select:mode","Onde os logs serão enviados?",Object.entries(modeNames).map(([value,label])=>({value,label,default:s.deliveryMode===value})))];
 if(s.deliveryMode!=="EXTERNAL"){
  fields.push({name:"Neste servidor",value:`${i.guild.name??"Este servidor"} → ${await namedChannel(i.guild,c.logChannelId)}`});
  components.push(row(button("adm-logs:canal:geral","Escolher canal geral"),button("logs-center:organization:local","Separar por categoria")));
 }
 if(s.externalGuildId)fields.push({name:s.deliveryMode==="LOCAL"?"Externo configurado · inativo":"Servidor externo",value:`${target?.name??"Servidor indisponível"} → ${target?await namedChannel(target,s.externalChannelId):"revise o destino"}`});
 components.push(row(button("logs-center:external",s.externalGuildId?"Alterar servidor externo":"Configurar servidor externo"),button("logs-center:test-external","Testar externo").setDisabled(!s.externalGuildId),button("logs-center:organization:external","Canais externos").setDisabled(!s.externalGuildId)));
 components.push(row(button("logs-center:help:destination","Detalhes e ajuda"),button("logs-center:home","Voltar")));
 return show(i,"Onde enviar","Escolha o destino e o canal geral. Separar os registros por categoria é opcional.",fields,components,notice);
}
export async function externalModal(i:any,group?:string){
 const s=await readLogSettings(i.guild.id),modal=new ModalBuilder().setCustomId(group?`logs-center-modal:channel:${group}`:"logs-center-modal:external").setTitle(group?`Canal externo · ${LOG_GROUPS[group]}`:"Servidor externo de logs");
 const input=(id:string,label:string,value:string|null,required:boolean)=>{const f=new TextInputBuilder().setCustomId(id).setLabel(label).setStyle(TextInputStyle.Short).setRequired(required).setMaxLength(25);if(value)f.setValue(value);return new ActionRowBuilder<TextInputBuilder>().addComponents(f)};
 if(!group)modal.addComponents(input("guild","ID do servidor externo",s.externalGuildId,true));
 modal.addComponents(input("channel",group?"ID do canal — vazio usa o canal geral":"ID do canal geral externo",group?s.externalChannels[group]??null:s.externalChannelId,!group));return i.showModal(modal);
}
export async function renderLogOrganization(i:any,scope?:string,section?:string){
 await deferPanel(i);if(scope!=="local"&&scope!=="external")return renderLogDestination(i);
 const s=await readLogSettings(i.guild.id,true),target=scope==="external"?await externalName(i.guild,s.externalGuildId):i.guild;
 if(scope==="external"&&!s.externalGuildId)return renderLogDestination(i,"Configure primeiro o servidor externo.");
 const groups=section==="bot"?{system:LOG_GROUPS.system,reintegration:LOG_GROUPS.reintegration}:LOG_UI_GROUPS;
 const fields=[];for(const [group,label]of Object.entries(groups)){
  if(group==="bot"){fields.push({name:label,value:"Operações do bot e Reintegração · destinos independentes"});continue}
  let text:string;
  if(scope==="local"){try{const ch=await resolveLocalLogChannel(i.guild,group,s);text=ch?`#${ch.name??"canal de logs"}${s.localChannels[group]?"":" · destino herdado"}`:"Canal não definido"}catch(e:any){text=e.message}}
  else text=target?`${await namedChannel(target,s.externalChannels[group]??s.externalChannelId)}${s.externalChannels[group]?"":" · canal geral"}`:"Servidor externo indisponível";
  fields.push({name:label,value:text});
 }
 return show(i,section==="bot"?"Sistemas do bot":scope==="local"?"Canais por categoria":"Canais externos",`${scope==="local"?i.guild.name??"Este servidor":target?.name??"Destino externo"}. Sem canal próprio, a categoria usa o canal geral.`,fields,[selector(`logs-center-select:channel-group:${scope}`,"Escolha a categoria",options(i.guild,groups)),back(section==="bot"?`organization:${scope}`:"destination")],undefined,section);
}
export async function renderLocalGroup(i:any,group:string,notice?:string){
 const s=await readLogSettings(i.guild.id);if(!Object.prototype.hasOwnProperty.call(LOG_GROUPS,group))return;
 const select=new ChannelSelectMenuBuilder().setCustomId(`logs-center-select:local-channel:${group}`).setPlaceholder("Canal da categoria — vazio usa o geral").addChannelTypes(ChannelType.GuildText,ChannelType.GuildAnnouncement).setMinValues(0).setMaxValues(1);
 const id=s.localChannels[group];if(id&&i.guild.channels.cache.has(id))select.setDefaultChannels([id]);
 let current="Canal não definido";try{const ch=await resolveLocalLogChannel(i.guild,group,s);if(ch)current=`#${ch.name??"canal de logs"}`}catch(e:any){current=e.message}
 return show(i,`Canal · ${LOG_GROUPS[group]}`,"Limpe a seleção para usar o canal geral.",[{name:"Destino atual",value:current}],[new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(select),back(`organization:local${group==="system"||group==="reintegration"?":bot":""}`)],notice,group);
}
export async function renderLogFilters(i:any,notice?:string){
 const s=await readLogSettings(i.guild.id,true);
 const channels=new ChannelSelectMenuBuilder().setCustomId("logs-center-select:ignored-channels").setPlaceholder("Canais e categorias ignorados").addChannelTypes(ChannelType.GuildText,ChannelType.GuildAnnouncement,ChannelType.GuildVoice,ChannelType.GuildStageVoice,ChannelType.GuildCategory,ChannelType.GuildForum).setMinValues(0).setMaxValues(25);
 const roles=new RoleSelectMenuBuilder().setCustomId("logs-center-select:ignored-roles").setPlaceholder("Cargos ignorados").setMinValues(0).setMaxValues(25);
 const channelIds=s.ignoredChannels.filter(id=>i.guild.channels.cache.has(id)),roleIds=s.ignoredRoles.filter(id=>i.guild.roles.cache.has(id));if(channelIds.length)channels.setDefaultChannels(channelIds);if(roleIds.length)roles.setDefaultRoles(roleIds);
 const fields=[{name:"Outros bots",value:s.ignoreBots?"Ignorados":"Incluídos"},{name:"Canais e categorias ignorados",value:s.ignoredChannels.map(id=>`<#${id}>`).join(", ").slice(0,1024)||"Nenhum"},{name:"Cargos ignorados",value:s.ignoredRoles.map(id=>`<@&${id}>`).join(", ").slice(0,1024)||"Nenhum"}];
 if(s.ignoredRoles.length)fields.push({name:"Filtro de cargos ativo",value:"Eventos sem informação dos cargos do membro também serão omitidos."});
 return show(i,"O que ignorar","Escolha o que não precisa aparecer nos logs. As alterações são salvas nesta embed.",fields,[new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(channels),new ActionRowBuilder<RoleSelectMenuBuilder>().addComponents(roles),row(button("logs-center:toggle-bots",s.ignoreBots?"Incluir outros bots":"Ignorar outros bots"),button("logs-center:help:filters","Entender os filtros")),back()],notice);
}
export async function renderLogDiagnostic(i:any,notice?:string){
 await deferPanel(i);const s=await readLogSettings(i.guild.id,true),summary=await activeSummary(i,s),h=logHealth(i.guild.id);
 const fields=[{name:"Destino do teste",value:summary.text}];
 if(summary.issues.length)fields.push({name:"Revisar antes de enviar",value:summary.issues.join("\n").slice(0,1024)});
 if(h.lastError)fields.push({name:"Último problema",value:h.lastError});
 return show(i,"Testar envio","Envie um exemplo ao destino de Sistemas do bot. O teste não ativa eventos nem muda seu modo de envio.",fields,[row(button("logs-center:test","Enviar log de teste",ButtonStyle.Primary),button("logs-center:diagnostic-details","Verificar permissões")),back()],notice);
}
export async function renderLogTechnicalDiagnostic(i:any){
 await deferPanel(i);const s=await readLogSettings(i.guild.id,true),h=logHealth(i.guild.id),me=i.guild.members.me??await i.guild.members.fetchMe();
 return show(i,"Permissões e diagnóstico","Use estas informações quando houver falha ou ausência de registros.",[
 {name:"Envios neste processo",value:`${h.sent} envios · ${h.failed} falhas · ${h.dropped} descartes por limite da fila. Os contadores reiniciam com o bot.`},
 {name:"Auditoria do Discord",value:me.permissions.has(PermissionFlagsBits.ViewAuditLog)?"Ver Registro de Auditoria: presente. Necessária para banimentos fora do bot.":"Falta Ver Registro de Auditoria para receber banimentos fora do bot."},
 {name:"Conteúdo das mensagens",value:"O acesso depende de Message Content Intent no Portal do Discord. Texto anterior fora do cache é informado como indisponível."},
 {name:"Fila de envio",value:"A fila é limitada e não é um arquivo permanente. Reinícios, falhas ou excesso de volume podem causar perda de logs."},
 ...(h.lastError?[{name:"Último problema",value:h.lastError}]:[])],[back("diagnostic")]);
}
export async function renderLogHelp(i:any,topic:string){
 const s=await readLogSettings(i.guild.id,true);
 if(topic==="destination")return show(i,"Detalhes do destino","Os IDs são usados na configuração; os painéis principais mostram os nomes.",[
 {name:"Servidor de origem",value:i.guild.id},{name:"Servidor externo",value:s.externalGuildId??"Não configurado"},{name:"Canal geral externo",value:s.externalChannelId??"Não configurado"},
 {name:"Responsável pela autorização",value:s.externalAuthorizedBy?`<@${s.externalAuthorizedBy}> · ${s.externalAuthorizedBy}`:"Não configurado"},
 {name:"Acesso necessário",value:"O responsável deve administrar o bot aqui e ter Administrador ou Gerenciar Servidor no destino. A autorização é revalidada na origem e no destino a cada envio."},
 {name:"Testar antes de ativar",value:"Testar externo envia somente um exemplo ao destino externo, mesmo no modo local."}],[back("destination")]);
 if(topic==="events")return show(i,"Sobre os registros","Escolha os eventos conforme a rotina da equipe.",[{name:"Novos eventos",value:"Começam desligados para evitar excesso de logs."},{name:"Histórico administrativo",value:"Desativar o envio não apaga as ações administrativas já salvas."},{name:"Sistemas do bot",value:"Inclui operações do bot e Reintegração, com eventos e canais próprios."}],[back("events")]);
 return show(i,"Como os filtros funcionam","Os filtros reduzem o volume enviado aos canais.",[{name:"Canais e categorias",value:"Ignorar uma categoria também ignora seus canais. Em trocas de call, basta um dos canais estar ignorado para omitir o evento."},{name:"Cargos",value:"Eventos de membros com cargos ignorados são omitidos. Quando os cargos não estão disponíveis, o evento também é omitido se houver filtro de cargos ativo."},{name:"Bots",value:"O próprio bot é sempre ignorado para evitar repetição. Você decide se inclui outros bots."},{name:"Exclusões em massa",value:"Um único resumo contém uma amostra das mensagens permitidas pelos filtros, quando disponíveis."}],[back("filters")]);
}
export async function renderModuleLogLinks(i:any){
 return show(i,"Logs de Tickets e Registro","Estes módulos mantêm seus destinos próprios. O modo de envio da central não altera essas configurações.",[{name:"Tickets",value:"Canais de logs e relatórios externos são configurados no módulo de atendimento."},{name:"Registro",value:"Canal de logs e envio externo são configurados no módulo de registro."}],[row(button("logs-center:module:tickets","Canais de Tickets"),button("logs-center:module:ticket-external","Relatórios externos")),row(button("logs-center:module:registration","Logs de Registro")),back()]);
}
export async function openModuleLogLink(i:any,module:string){
 if(!["tickets","ticket-external","registration"].includes(module))return;
 const decorate=(p:any)=>{
  const components=[...(p.components??[])],last=components[components.length-1],data=last?.toJSON?.();
  const shortcut=button("logs-center:modules","Central de logs");
  if(data?.components?.every((c:any)=>c.type===2)&&data.components.length<5)components[components.length-1]=new ActionRowBuilder<ButtonBuilder>().addComponents(...data.components.map((c:any)=>ButtonBuilder.from(c)),shortcut);
  else if(components.length<5)components.push(row(shortcut));
  return refreshPanel(i,{...p,content:null,components,allowedMentions:{parse:[]}});
 };
 const bridge=new Proxy(i,{get(target,key){if(key==="customId")return module==="tickets"?"adm-ticket:settings":"adm-reg:general";if(key==="update"||key==="editReply")return decorate;const value=Reflect.get(target,key,target);return typeof value==="function"?value.bind(target):value}});
 // Use the production controllers, which contain functionality absent from src/.
 if(module==="tickets")return require("../../app/components/buttons/admTicketsMenu").renderTicketChannels(bridge,false);
 if(module==="ticket-external")return require("../../app/components/buttons/admTicketsMenu").renderTicketExternal(bridge);
 return require("../../app/components/buttons/admRegistrationMenu").default.execute(bridge);
}
