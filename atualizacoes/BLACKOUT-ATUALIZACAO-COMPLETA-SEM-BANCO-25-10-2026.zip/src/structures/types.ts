import {
  ChatInputCommandInteraction,
  SlashCommandBuilder,
  SlashCommandSubcommandsOnlyBuilder,
  SlashCommandOptionsOnlyBuilder,
  ButtonInteraction,
  AnySelectMenuInteraction,
  ModalSubmitInteraction,
} from "discord.js";

export interface Command {
  data:
    | SlashCommandBuilder
    | SlashCommandSubcommandsOnlyBuilder
    | SlashCommandOptionsOnlyBuilder;
  execute: (interaction: ChatInputCommandInteraction) => Promise<void>;
}

export interface ButtonComponent {
  // customId exato ou prefixo (ex: "adm-adm:") que este handler trata
  customId: string;
  execute: (interaction: ButtonInteraction) => Promise<void>;
}

// Cobre string select, role select e channel select — todos chegam como
// AnySelectMenuInteraction e o handler decide o que fazer com base no tipo.
export interface SelectMenuComponent {
  // customId exato ou prefixo (ex: "adm-role-select:") que este handler trata
  customId: string;
  execute: (interaction: AnySelectMenuInteraction) => Promise<void>;
}

export interface ModalComponent {
  // customId exato ou prefixo que este handler trata
  customId: string;
  execute: (interaction: ModalSubmitInteraction) => Promise<void>;
}
