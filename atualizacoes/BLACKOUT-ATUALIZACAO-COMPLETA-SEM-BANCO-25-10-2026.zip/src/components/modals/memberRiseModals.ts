import { ModalSubmitInteraction } from "discord.js";
import { ModalComponent } from "../../structures/types";
import { isBotAdmin } from "../../utils/permissions";
import { prisma } from "../../database/prisma";
import { renderMemberRise } from "../../memberRise/panel";
import { stage } from "../../memberRise/service";

const component: ModalComponent = { customId: "member-rise-modal:", async execute(i: ModalSubmitInteraction) {
  if (!i.guild || !await isBotAdmin(await i.guild.members.fetch(i.user.id))) return void await i.reply({ content: "Sem permissão.", ephemeral: true });
  const action = i.customId.split(":")[1], s = await stage(i.guild.id);
  const value = (id: string) => i.fields.getTextInputValue(id).trim();
  const integer = (id: string, max: number) => { const n = Number(value(id)); if (!Number.isInteger(n) || n < 0 || n > max) throw new Error(`${id}: valor inválido (0–${max}).`); return n; };
  const bool = (id: string) => { const x = value(id).toUpperCase(); if (!["SIM", "NÃO", "NAO"].includes(x)) throw new Error(`${id}: use SIM ou NÃO.`); return x === "SIM"; };
  try {
    if (action === "search") { const userId = value("member").replace(/\D/g, ""); if (!userId) throw new Error("Informe um ID ou menção válida."); return renderMemberRise(i, "progress", 0, userId); }
    let data: any = {};
    if (action === "requirements") { const messages = integer("messages", 10000000), hours = integer("hours", 100000), minutes = integer("minutes", 59), mode = value("mode").toUpperCase(); if (!["TODOS", "QUALQUER UM"].includes(mode)) throw new Error("Modo inválido."); if (!messages && !hours && !minutes) throw new Error("Ative ao menos um requisito."); data = { minMessages: messages, messageEnabled: messages > 0, minVoiceSeconds: hours * 3600 + minutes * 60, voiceEnabled: hours + minutes > 0, requirementMode: mode === "TODOS" ? "ALL" : "ANY", messageIntervalSeconds: integer("interval", 3600) }; }
    if (action === "voice") data = { minVoicePeople: Math.max(1, integer("people", 99)), ignoreAfk: bool("afk"), countMuted: bool("muted"), countDeafened: bool("deaf") };
    if (action === "messages") { if (value("public").length > 2000 || value("dm").length > 2000) throw new Error("Mensagem limitada a 2000 caracteres."); data = { publicMessage: value("public"), dmMessage: value("dm") }; }
    await prisma.memberRiseStage.update({ where: { id: s.id }, data });
    return renderMemberRise(i, action === 'messages' ? 'preview' : 'home');
  } catch (error) { return void await i.reply({ content: error instanceof Error ? error.message : "Erro ao salvar.", ephemeral: true }); }
} }; export default component;
