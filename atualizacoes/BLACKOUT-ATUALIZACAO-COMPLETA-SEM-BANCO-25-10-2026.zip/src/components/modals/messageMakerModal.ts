import { execute } from "../../message-maker/interactions";
export default { customId: "maker-form:", execute };
