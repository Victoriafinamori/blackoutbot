import { ModalSubmitInteraction } from "discord.js";
import { ModalComponent } from "../../structures/types";
import { submitGuess } from "../../games-chat/termo/manager";
import { termoPlayerView } from "../../games-chat/termo/ui";
import { publishTermoPanel } from "../../games-chat/termo/publisher";
const component: ModalComponent = {
  customId: "termo-guess:",
  async execute(i: ModalSubmitInteraction) {
    if (!i.guild) return;
    const privateOrigin = i.isFromMessage() && i.message?.flags.has(64);
    if (privateOrigin) await i.deferUpdate();
    else await i.deferReply({ ephemeral: true });
    try {
      await submitGuess(
        i.guild.id,
        i.user.id,
        i.fields.getTextInputValue("word"),
        i.customId.split(":")[1] === "submit"
          ? undefined
          : i.customId.split(":")[1],
      );
      await i.editReply(await termoPlayerView(i.guild, i.user.id));
      await publishTermoPanel(i.guild).catch(() => null);
    } catch (error) {
      if (privateOrigin)
        await i.followUp({
          content: `Não foi possível registrar a tentativa: ${error instanceof Error ? error.message : String(error)}`,
          ephemeral: true,
        });
      else
        await i.editReply(
          `Não foi possível registrar a tentativa: ${error instanceof Error ? error.message : String(error)}`,
        );
    }
  },
};
export default component;
