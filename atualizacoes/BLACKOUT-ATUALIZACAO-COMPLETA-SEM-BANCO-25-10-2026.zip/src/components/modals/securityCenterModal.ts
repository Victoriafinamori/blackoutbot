import { ModalComponent } from "../../structures/types";
import { execute } from "../../security/interactions";
const component: ModalComponent = { customId: "security-form:", execute };
export default component;
