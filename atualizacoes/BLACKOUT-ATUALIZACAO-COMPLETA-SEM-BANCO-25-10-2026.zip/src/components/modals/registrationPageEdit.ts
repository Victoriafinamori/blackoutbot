import { prisma } from '../../database/prisma';
import { isBotAdmin } from '../../utils/permissions';
import { deferPanel, refreshPanel } from '../../utils/panelInteraction';
import { registrationPageManagerPayload } from '../../utils/registrationPageAdmin';
const component={customId:'adm-reg-page:',async execute(i:any){
  if(!i.guild||!await isBotAdmin(await i.guild.members.fetch(i.user.id)))return;
  const page=await prisma.registrationPage.findFirst({where:{id:i.customId.slice('adm-reg-page:'.length),guildId:i.guild.id}});
  if(!page)return i.reply({content:'Esta página não existe mais. Reabra o formulário.',ephemeral:true});
  const value=(key:string)=>i.fields.getTextInputValue(key).trim(),max=Number(value('max')),required=value('required').toUpperCase();
  if(!value('name')||!value('question')||!Number.isInteger(max)||max<1||max>20||!['SIM','NAO','NÃO'].includes(required))return i.reply({content:'Preencha nome e pergunta, use um limite de 1 a 20 e indique SIM ou NÃO para obrigatoriedade.',ephemeral:true});
  await deferPanel(i);await prisma.registrationPage.update({where:{id:page.id},data:{name:value('name').slice(0,100),question:value('question').slice(0,256),description:value('description').slice(0,2000)||null,maxChoices:max,required:required==='SIM'}});
  return refreshPanel(i,await registrationPageManagerPayload(i.guild,page.id));
}};
export default component;
