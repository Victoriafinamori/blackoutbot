import { isBotAdmin } from "../../utils/permissions";
import { deferPanel } from "../../utils/panelInteraction";
import { readLogSettings,saveLogSettings,LOG_GROUPS } from "../../logging/config";
import { validateExternal,usableLogChannel } from "../../logging/delivery";
import { renderLogDestination,renderLogOrganization } from "../../logging/panel";
export default {customId:"logs-center-modal:",async execute(i:any){
 if(!i.guild||!await isBotAdmin(await i.guild.members.fetch(i.user.id)))return i.reply({content:"Você não possui permissão neste servidor.",ephemeral:true});
 const [,action,group]=i.customId.split(":"),channel=i.fields.getTextInputValue("channel").trim();
 if(channel&&!/^\d{15,25}$/.test(channel))return i.reply({content:"Informe um ID de canal válido.",ephemeral:true});
 await deferPanel(i);const s=await readLogSettings(i.guild.id,true);
 try{
 if(action==="external"){
  const guild=i.fields.getTextInputValue("guild").trim();if(!/^\d{15,25}$/.test(guild)||!channel)throw Error("Informe IDs válidos para o servidor e o canal geral.");
  const candidate={...s,externalGuildId:guild,externalChannelId:channel,externalAuthorizedBy:i.user.id};await validateExternal(i.guild,candidate,i.user.id);
  await saveLogSettings(i.guild.id,{externalGuildId:guild,externalChannelId:channel,externalAuthorizedBy:i.user.id,...(guild!==s.externalGuildId?{externalChannelsJson:"{}"}:{})});
  return renderLogDestination(i,"Destino validado e salvo. Você pode enviar um teste e escolher o modo de envio.");
 }
 if(action==="channel"&&LOG_GROUPS[group]){
  const target=await validateExternal(i.guild,s,i.user.id);if(channel)await usableLogChannel(target,channel);
  const channels={...s.externalChannels};if(channel)channels[group]=channel;else delete channels[group];
  await saveLogSettings(i.guild.id,{externalChannelsJson:JSON.stringify(channels),externalAuthorizedBy:i.user.id});return renderLogOrganization(i,"external",group==="system"||group==="reintegration"?"bot":undefined);
 }
 }catch(error:any){return i.followUp({content:error.message||"Não foi possível configurar o destino externo.",ephemeral:true})}
}};
