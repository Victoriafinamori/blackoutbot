import { MessageFlags, ModalSubmitInteraction } from "discord.js";
import { ModalComponent } from "../../structures/types";
import { prisma } from "../../database/prisma";
import { publishReportPanel, reportConfig } from "../../utils/reports";

const component: ModalComponent = { customId: "denuncia-appearance:", async execute(i: ModalSubmitInteraction) {
  if (!i.guild) return;
  const action = i.customId.split(":")[1];

  if (action === "button") {
    const c = await reportConfig(i.guild.id);
    const raw = i.fields.getTextInputValue("style").trim().toUpperCase();
    const styles: Record<string, string> = {
      AZUL: "PRIMARY", PRIMARY: "PRIMARY",
      CINZA: "SECONDARY", SECONDARY: "SECONDARY",
      VERDE: "SUCCESS", SUCCESS: "SUCCESS",
      VERMELHO: "DANGER", DANGER: "DANGER",
    };
    const panelButtonStyle = styles[raw];
    if (!panelButtonStyle) return void await i.reply({ content: "❌ Cor inválida. Use AZUL, CINZA, VERDE ou VERMELHO.", flags: MessageFlags.Ephemeral });
    await prisma.reportConfig.update({
      where: { guildId: i.guild.id },
      data: {
        panelButtonLabel: i.fields.getTextInputValue("label").trim() || "Iniciar denúncia",
        panelButtonEmoji: i.fields.getTextInputValue("emoji").trim() || null,
        panelButtonStyle,
      },
    });
    
    return require('../../utils/adminMessagePreview').showAdminMessagePreview(i,'denuncias');
  }

  const color = i.fields.getTextInputValue("color").replace("#", "").trim();
  if (!/^[0-9a-fA-F]{6}$/.test(color)) return void await i.reply({ content: "Cor inválida. Exemplo: `D20B20`.", flags: MessageFlags.Ephemeral });
  const rawAssets = i.fields.getTextInputValue("assets");
  const asset = (name: string) => rawAssets.split(/\r?\n/).find(line => line.toUpperCase().startsWith(`${name}=`))?.slice(name.length + 1).trim() || null;
  const c = await reportConfig(i.guild.id);
  const data = {
    panelTitle: i.fields.getTextInputValue("title").trim(),
    panelDescription: i.fields.getTextInputValue("description").trim(),
    embedColor: `#${color.toUpperCase()}`,
    embedFooter: i.fields.getTextInputValue("footer").trim() || "Central de Denúncias",
    embedThumbnail: asset("THUMBNAIL"),
    embedImage: asset("IMAGEM"),
  };
  await prisma.reportConfig.update({ where: { guildId: i.guild.id }, data });
  
  return require('../../utils/adminMessagePreview').showAdminMessagePreview(i,'denuncias');
} };
export default component;
