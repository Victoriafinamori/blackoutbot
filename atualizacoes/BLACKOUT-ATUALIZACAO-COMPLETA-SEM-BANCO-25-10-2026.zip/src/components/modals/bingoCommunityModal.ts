import { modal } from "../../bingo/communityInteractions";
export default { customId: "bg-form:", execute: modal };
