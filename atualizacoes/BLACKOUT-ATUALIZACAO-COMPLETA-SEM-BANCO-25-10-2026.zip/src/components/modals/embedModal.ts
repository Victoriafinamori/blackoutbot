import { ModalComponent } from "../../structures/types";
import { isBotAdmin } from "../../utils/permissions";
import { prisma } from "../../database/prisma";
import { deferPanel } from "../../utils/panelInteraction";
import { renderDefaultPattern } from "../buttons/admConfigMenu";
const component:ModalComponent={customId:"adm-modal:embed",async execute(i){
  if(!i.guild||!await isBotAdmin(await i.guild.members.fetch(i.user.id)))return;
  const color=i.fields.getTextInputValue("embedColor").trim().replace(/^#/,"");
  const footer=i.fields.getTextInputValue("embedFooter").trim(),author=i.fields.getTextInputValue("embedAuthor").trim(),thumbnail=i.fields.getTextInputValue("embedThumbnail").trim();
  if(!/^[0-9a-f]{6}$/i.test(color))return void await i.reply({content:"Use uma cor hexadecimal de seis dígitos, como D71935.",ephemeral:true});
  if(thumbnail&&!/^https?:\/\/\S+$/i.test(thumbnail))return void await i.reply({content:"Use uma URL de imagem válida para a miniatura ou deixe o campo vazio.",ephemeral:true});
  await deferPanel(i);
  await prisma.guildConfig.update({where:{guildId:i.guild.id},data:{embedColor:color.toUpperCase(),embedAuthor:author||null,embedFooter:footer||null,embedThumbnail:thumbnail||null}});
  return renderDefaultPattern(i);
}};export default component;
