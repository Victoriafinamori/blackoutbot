import { prisma } from '../../database/prisma';
import { isBotAdmin } from '../../utils/permissions';
import { deferPanel } from '../../utils/panelInteraction';
import { renderRegistrationAdmin } from '../../utils/registrationAdmin';
const component={customId:'registration-embed:',async execute(i:any){
  if(!i.guild||!await isBotAdmin(await i.guild.members.fetch(i.user.id)))return;
  const prefix=i.customId.split(':')[1];if(!['panel','internal'].includes(prefix))return;
  const color=i.fields.getTextInputValue('color').replace('#','').trim();if(!/^[\da-f]{6}$/i.test(color))return i.reply({content:'Cor hexadecimal inválida. Exemplo: D71935.',ephemeral:true});
  const raw=i.fields.getTextInputValue('assets'),asset=(name:string)=>raw.split(/\r?\n/).find((line:string)=>line.toUpperCase().startsWith(name+'='))?.slice(name.length+1).trim()||null;
  const thumbnail=asset('THUMBNAIL'),image=asset('IMAGEM');
  for(const url of [thumbnail,image])if(url){try{if(!['https:','http:'].includes(new URL(url).protocol))throw Error()}catch{return i.reply({content:'Use uma URL HTTP ou HTTPS válida para as imagens.',ephemeral:true})}}
  const data:any={[prefix+'Title']:i.fields.getTextInputValue('title').trim(),[prefix+'Description']:i.fields.getTextInputValue('description').trim(),[prefix+'Color']:color,[prefix+'Thumbnail']:thumbnail,[prefix+'Image']:image,[prefix+'Footer']:asset('RODAPE')};
  if(prefix==='panel')data.panelAuthor=asset('AUTOR');
  await deferPanel(i);await prisma.registrationConfig.update({where:{guildId:i.guild.id},data});
  return renderRegistrationAdmin(i,prefix==='panel'?'preview-panel':'internal');
}};
export default component;
