import { modal } from "../../games-chat/experience/hub";
export default { customId: "games-form:", execute: modal };
