import { reviewModeration } from "../../utils/moderationPanel";
import { deferPanel } from "../../utils/panelInteraction";
import { ModalSubmitInteraction, ActionRowBuilder, ButtonBuilder, ButtonStyle } from "discord.js";
import { ModalComponent } from "../../structures/types";
import { isBotAdmin } from "../../utils/permissions";
import { baseEmbed } from "../../utils/embeds";
import { prisma } from "../../database/prisma";
import { logAdminAction } from "../../utils/adminLog";
import { AdminLogAction, FilterRuleType } from "../../structures/enums";
import { warnMember, muteMember, kickMember, banMember, unbanMember, ModerationError } from "../../utils/moderation";
import { renderFiltersContent, renderFiltersLimits } from "../buttons/admModerationMenu";

function backRow(customId: string) {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(customId).setLabel("Voltar").setStyle(ButtonStyle.Secondary)
  );
}

async function replyOrUpdate(
  interaction: ModalSubmitInteraction,
  embed: Awaited<ReturnType<typeof baseEmbed>>,
  components: ActionRowBuilder<ButtonBuilder>[]
) {
  if (interaction.isFromMessage()) {
    await interaction.update({ embeds: [embed], components });
  } else {
    await interaction.reply({ embeds: [embed], components, ephemeral: true });
  }
}

async function handlePunishment(i: ModalSubmitInteraction,type: string,userId: string){
 const raw=type==="mute"?i.fields.getTextInputValue("duration").trim():"";
 return reviewModeration(i,type,userId,i.fields.getTextInputValue("reason"),type==="mute"?Number(raw):undefined);
}
async function handleUnban(i: ModalSubmitInteraction){
 return reviewModeration(i,"unban",i.fields.getTextInputValue("userId").trim(),i.fields.getTextInputValue("reason")||"");
}

function parseList(raw: string): string[] {
  return raw
    .split(/[,\n]/)
    .map((v) => v.trim().toLowerCase())
    .filter((v) => v.length > 0)
    .filter((v, i, arr) => arr.indexOf(v) === i);
}

async function handleWordsList(interaction: ModalSubmitInteraction) {
  await deferPanel(interaction);
  const values = parseList(interaction.fields.getTextInputValue("words"));

  await prisma.$transaction([
    prisma.filterRule.deleteMany({ where: { guildId: interaction.guild!.id, type: FilterRuleType.WORD } }),
    ...values.map((value) =>
      prisma.filterRule.create({ data: { guildId: interaction.guild!.id, type: FilterRuleType.WORD, value } })
    ),
  ]);

  await logAdminAction({
    guild: interaction.guild!,
    actorId: interaction.user.id,
    action: AdminLogAction.FILTER_RULE_UPDATED,
    details: `Lista de palavras proibidas atualizada (${values.length} termo(s)).`,
  });

  await renderFiltersContent(interaction);
}

async function handleLinksList(interaction: ModalSubmitInteraction) {
  await deferPanel(interaction);
  const values = parseList(interaction.fields.getTextInputValue("domains"));

  await prisma.$transaction([
    prisma.filterRule.deleteMany({ where: { guildId: interaction.guild!.id, type: FilterRuleType.LINK_WHITELIST } }),
    ...values.map((value) =>
      prisma.filterRule.create({ data: { guildId: interaction.guild!.id, type: FilterRuleType.LINK_WHITELIST, value } })
    ),
  ]);

  await logAdminAction({
    guild: interaction.guild!,
    actorId: interaction.user.id,
    action: AdminLogAction.FILTER_RULE_UPDATED,
    details: `Lista de domínios permitidos atualizada (${values.length} domínio(s)).`,
  });

  await renderFiltersContent(interaction);
}

async function handleThresholds1(interaction: ModalSubmitInteraction) {
  await deferPanel(interaction);
  const capsThreshold = Number(interaction.fields.getTextInputValue("capsThreshold").trim());
  const capsMinLength = Number(interaction.fields.getTextInputValue("capsMinLength").trim());
  const floodMaxMessages = Number(interaction.fields.getTextInputValue("floodMaxMessages").trim());
  const floodIntervalSeconds = Number(interaction.fields.getTextInputValue("floodIntervalSeconds").trim());
  const spamMaxDuplicates = Number(interaction.fields.getTextInputValue("spamMaxDuplicates").trim());

  const values = { capsThreshold, capsMinLength, floodMaxMessages, floodIntervalSeconds, spamMaxDuplicates };
  if (Object.values(values).some((v) => !Number.isInteger(v) || v < 0) || capsThreshold>100 || capsMinLength<1 || floodMaxMessages<1 || floodIntervalSeconds<1 || spamMaxDuplicates<1) {
    await interaction.followUp({ content: "Confira os limites: use inteiros, percentuais de 0 a 100, contagens/intervalos positivos e silêncio de 1 a 40320 minutos. Zero desativa os limites de advertências.", ephemeral: true });
    return;
  }

  await prisma.guildConfig.update({ where: { guildId: interaction.guild!.id }, data: values });

  await logAdminAction({
    guild: interaction.guild!,
    actorId: interaction.user.id,
    action: AdminLogAction.MODERATION_CONFIG_CHANGED,
    details: "Limites de conteúdo atualizados.",
  });

  await renderFiltersLimits(interaction);
}

async function handleThresholds2(interaction: ModalSubmitInteraction) {
  await deferPanel(interaction);
  const toxicityThreshold = Number(interaction.fields.getTextInputValue("toxicityThreshold").trim());
  const autoMuteDurationMinutes = Number(interaction.fields.getTextInputValue("autoMuteDurationMinutes").trim());
  const maxWarnsBeforeMute = Number(interaction.fields.getTextInputValue("maxWarnsBeforeMute").trim());
  const maxWarnsBeforeBan = Number(interaction.fields.getTextInputValue("maxWarnsBeforeBan").trim());

  const values = { toxicityThreshold, autoMuteDurationMinutes, maxWarnsBeforeMute, maxWarnsBeforeBan };
  if (Object.values(values).some((v) => !Number.isInteger(v) || v < 0) || toxicityThreshold>100 || autoMuteDurationMinutes<1 || autoMuteDurationMinutes>40320) {
    await interaction.followUp({ content: "Confira os limites: use inteiros, percentuais de 0 a 100, contagens/intervalos positivos e silêncio de 1 a 40320 minutos. Zero desativa os limites de advertências.", ephemeral: true });
    return;
  }

  await prisma.guildConfig.update({ where: { guildId: interaction.guild!.id }, data: values });

  await logAdminAction({
    guild: interaction.guild!,
    actorId: interaction.user.id,
    action: AdminLogAction.MODERATION_CONFIG_CHANGED,
    details: "Limites de ação atualizados.",
  });

  await renderFiltersLimits(interaction);
}

const component: ModalComponent = {
  customId: "adm-modal:mod:",

  async execute(interaction: ModalSubmitInteraction) {
    if (!interaction.guild) return;

    const member = await interaction.guild.members.fetch(interaction.user.id);
    if (!(await isBotAdmin(member))) {
      await interaction.reply({ content: "🚫 Você não tem permissão para realizar esta ação.", ephemeral: true });
      return;
    }

    const parts = interaction.customId.split(":"); // ["adm-modal", "mod", "tipo", "userId?"]
    const type = parts[2];
    const userId = parts[3];

    switch (type) {
      case "warn":
      case "mute":
      case "kick":
      case "ban":
      case "unmute":
      case "clearwarns":
        return handlePunishment(interaction, type, userId);
      case "unban":
        return handleUnban(interaction);
      case "words":
        return handleWordsList(interaction);
      case "links":
        return handleLinksList(interaction);
      case "limites1":
        return handleThresholds1(interaction);
      case "limites2":
        return handleThresholds2(interaction);
    }
  },
};

export default component;
