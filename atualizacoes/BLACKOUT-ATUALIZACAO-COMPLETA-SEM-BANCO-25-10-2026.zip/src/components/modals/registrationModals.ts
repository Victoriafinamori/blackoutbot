import { PermissionFlagsBits } from 'discord.js';
import { prisma } from '../../database/prisma';
import { isBotAdmin } from '../../utils/permissions';
import { deferPanel, refreshPanel } from '../../utils/panelInteraction';
import { registrationPageManagerPayload } from '../../utils/registrationPageAdmin';
import { renderRegistrationAdmin } from '../../utils/registrationAdmin';
const component={customId:'registration-',async execute(i:any){
  if(!i.guild||!await isBotAdmin(await i.guild.members.fetch(i.user.id)))return;
  if(i.customId==='registration-page:create'){
    const value=(key:string)=>i.fields.getTextInputValue(key).trim(),max=Number(value('max'));
    if(!value('name')||!value('question')||!Number.isInteger(max)||max<1||max>20)return i.reply({content:'Preencha nome e pergunta e use um máximo inteiro entre 1 e 20.',ephemeral:true});
    if(await prisma.registrationPage.count({where:{guildId:i.guild.id}})>=5)return i.reply({content:'O formulário aceita até cinco páginas.',ephemeral:true});
    await deferPanel(i);
    const page=await prisma.$transaction(async tx=>{const pages=await tx.registrationPage.findMany({where:{guildId:i.guild.id}});if(pages.length>=5)throw Error('Limite de cinco páginas atingido.');return tx.registrationPage.create({data:{guildId:i.guild.id,name:value('name').slice(0,100),question:value('question').slice(0,256),description:value('description').slice(0,2000)||null,roleIds:'',maxChoices:max,order:Math.max(0,...pages.map(p=>p.order))+1}})});
    return refreshPanel(i,await registrationPageManagerPayload(i.guild,page.id));
  }
  if(i.customId==='registration-external:save'){
    const guildId=i.fields.getTextInputValue('guild').trim(),channelId=i.fields.getTextInputValue('channel').trim();
    await deferPanel(i);
    const g=await i.client.guilds.fetch(guildId).catch(()=>null),ch=g?await g.channels.fetch(channelId).catch(()=>null):null;
    if(!ch?.isTextBased()||ch.isDMBased()||!ch.isSendable())return i.followUp({content:'O bot precisa ter acesso ao servidor e a um canal que aceite mensagens.',ephemeral:true});
    const actor=await g.members.fetch(i.user.id).catch(()=>null),me=g.members.me??await g.members.fetchMe();
    if(!actor?.permissions.has(PermissionFlagsBits.ManageGuild)&&!actor?.permissions.has(PermissionFlagsBits.Administrator))return i.followUp({content:'Você precisa de Gerenciar servidor ou Administrador no servidor de destino.',ephemeral:true});
    if(!ch.permissionsFor(me)?.has([PermissionFlagsBits.ViewChannel,PermissionFlagsBits.SendMessages,PermissionFlagsBits.EmbedLinks,PermissionFlagsBits.AttachFiles]))return i.followUp({content:'No destino, o bot precisa ver o canal, enviar mensagens, inserir links e anexar arquivos.',ephemeral:true});
    await prisma.registrationConfig.update({where:{guildId:i.guild.id},data:{externalGuildId:guildId,externalChannelId:channelId}});
    return renderRegistrationAdmin(i,'logs');
  }
}};
export default component;
