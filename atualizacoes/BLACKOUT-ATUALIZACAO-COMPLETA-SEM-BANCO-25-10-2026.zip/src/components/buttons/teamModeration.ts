import { executeModerationPanel } from "../../utils/moderationPanel";
export default {customId:"team-mod:",execute:executeModerationPanel};
