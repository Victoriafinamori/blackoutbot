import { renderLogHome, renderLogOrganization } from "../../logging/panel";
import {
  ButtonInteraction,
  MessageComponentInteraction,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelSelectMenuBuilder,
  ChannelType,
} from "discord.js";
import { writableChannel } from "../../utils/configurationChecks";
import { refreshPanel } from "../../utils/panelInteraction";
import { ButtonComponent } from "../../structures/types";
import { isBotAdmin } from "../../utils/permissions";
import { adminEmbed } from "../../utils/adminUi";
import { getOrCreateGuildConfig } from "../../database/guildConfig";
import { prisma } from "../../database/prisma";
import { LogCategory, LOG_CATEGORY_LABELS } from "../../structures/enums";

// Mapa de chave curta (usada no customId) -> categoria + coluna no GuildConfig.
export const LOG_CHANNEL_FIELDS: Record<
  string,
  {
    category: LogCategory;
    label?: string;
    column: "logChannelId" | "moderationLogChannelId" | "securityLogChannelId" | "reintegrationLogChannelId" | "systemLogChannelId";
  }
> = {
  geral: { category: LogCategory.SYSTEM, label: "Logs gerais", column: "logChannelId" },
  moderacao: { category: LogCategory.MODERATION, column: "moderationLogChannelId" },
  seguranca: { category: LogCategory.SECURITY, column: "securityLogChannelId" },
  reintegracao: { category: LogCategory.REINTEGRATION, column: "reintegrationLogChannelId" },
  sistema: { category: LogCategory.SYSTEM, column: "systemLogChannelId" },
};

function backRow(customId: string, label = "Voltar") {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(customId).setLabel(label).setStyle(ButtonStyle.Secondary)
  );
}

async function destinationText(guild:any,id:string|null|undefined){
  if(!id)return "Não definido. Escolha um canal de texto acessível ao bot.";
  const check=await writableChannel(guild,id);
  return `<#${id}>${check.issue?` · ${check.issue.startsWith("Escolha")?"Canal excluído ou inacessível; escolha outro destino.":check.issue}`:""}`;
}
export async function renderLogsMenu(i:any){return renderLogHome(i)}
export async function renderLogCategories(i:any){return renderLogOrganization(i)}
export async function renderLogChannelPicker(interaction: any, key: string, notice?: string) {
  const field=LOG_CHANNEL_FIELDS[key];
  if(!field)return renderLogsMenu(interaction);
  const label=field.label||LOG_CATEGORY_LABELS[field.category].label;
  const config=await getOrCreateGuildConfig(interaction.guild.id),current=config[field.column];
  const embed=adminEmbed(interaction.guild,"seguranca").setTitle(label)
    .setDescription(key==="geral"?"Destino dos registros sem canal específico. Prefira um canal privado acessível à equipe.":"Deixe a seleção vazia para usar o canal geral.")
    .addFields({name:"Canal atual",value:current?await destinationText(interaction.guild,current):key!=="geral"?`${await destinationText(interaction.guild,config.logChannelId)} · usa o canal geral`:"Não definido"});
  if(notice)embed.addFields({name:"Resultado",value:notice});
  const select=new ChannelSelectMenuBuilder().setCustomId(`adm-logchannel-select:${key}`).setPlaceholder(`Canal de ${label.toLowerCase()}`).addChannelTypes(ChannelType.GuildText,ChannelType.GuildAnnouncement).setMinValues(0).setMaxValues(1);
  if(current&&interaction.guild.channels.cache.has(current))select.setDefaultChannels([current]);
  return refreshPanel(interaction,{content:null,attachments:[],embeds:[embed],components:[new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(select),backRow("logs-center:destination")]});
}

async function renderRecentAudit(interaction: ButtonInteraction) {
  const logs = await prisma.adminLog.findMany({
    where: { guildId: interaction.guild!.id },
    orderBy: { createdAt: "desc" },
    take: 15,
  });

  const embed = (await adminEmbed(interaction.guild!, "seguranca")).setTitle("Ações da equipe").setDescription(
    logs.length === 0
      ? "Nenhum evento registrado ainda."
      : logs
          .map((log: { action: string; actorId: string; targetId: string | null; details: string | null; createdAt: Date }) => {
            const timestamp = `<t:${Math.floor(log.createdAt.getTime() / 1000)}:R>`;
            const target = log.targetId ? ` → <@${log.targetId}>` : "";
            const details = log.details ? ` — ${log.details}` : "";
            return `**${log.action}** por <@${log.actorId}>${target}${details} (${timestamp})`;
          })
          .join("\n").slice(0,3900)
  ).setFooter({text:"Últimas 15 ações registradas pelo bot · Não inclui toda a auditoria nativa do Discord"});

  await refreshPanel(interaction,{ content:null,attachments: [], embeds: [embed], components: [backRow("adm-logs:menu")] });
}

const component: ButtonComponent = {
  customId: "adm-logs:",

  async execute(interaction: ButtonInteraction) {
    if (!interaction.guild) return;

    const member = await interaction.guild.members.fetch(interaction.user.id);
    if (!(await isBotAdmin(member))) {
      await interaction.reply({
        content: "🚫 Você não tem permissão para acessar esta seção.",
        ephemeral: true,
      });
      return;
    }

    const parts = interaction.customId.split(":");
    const action = parts[1];
    const sub = parts[2];

    switch (action) {
      case "menu":
        return renderLogsMenu(interaction);
      case "categorias":
        return renderLogCategories(interaction);
      case "canal":
        return renderLogChannelPicker(interaction, sub);
      case "auditoria":
        return renderRecentAudit(interaction);
      default:
        return renderLogsMenu(interaction);
    }
  },
};

export default component;
