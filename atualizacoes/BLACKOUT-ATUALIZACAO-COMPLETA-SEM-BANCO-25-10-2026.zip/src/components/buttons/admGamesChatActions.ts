import {
  ActionRowBuilder,
  ButtonInteraction,
  ModalBuilder,
  StringSelectMenuBuilder,
  TextInputBuilder,
  TextInputStyle,
} from "discord.js";
import { ButtonComponent } from "../../structures/types";
import { isBotAdmin } from "../../utils/permissions";
import { mysteryConfig, termoConfig } from "../../games-chat/core/config";
import { prisma } from "../../database/prisma";
import {
  createMysteryEvent,
  endMysteryEvent,
} from "../../games-chat/mystery-box/manager";
import { publishTermoPanel } from "../../games-chat/termo/publisher";
import { mysteryAdminView, termoAdminView } from "./admGamesChatMenu";
import { termoRankingView } from "../../games-chat/termo/ui";

const input = (
  id: string,
  label: string,
  value: string,
  required = true,
  paragraph = false,
) => {
  const field = new TextInputBuilder()
    .setCustomId(id)
    .setLabel(label)
    .setStyle(paragraph ? TextInputStyle.Paragraph : TextInputStyle.Short)
    .setRequired(required);
  if (value) field.setValue(value);
  return new ActionRowBuilder<TextInputBuilder>().addComponents(field);
};
const component: ButtonComponent = {
  customId: "adm-games-action:",
  async execute(i: ButtonInteraction) {
    if (!i.guild || !(await isBotAdmin(await i.guild.members.fetch(i.user.id))))
      return void (await i.reply({
        content: "Você não possui permissão.",
        ephemeral: true,
      }));
    const action = i.customId.split(":")[1];
    if (action === "mystery-settings") {
      const c = await mysteryConfig(i.guild.id);
      return void (await i.showModal(
        new ModalBuilder()
          .setCustomId("adm-games-modal:mystery")
          .setTitle("Caixa Misteriosa — Configuração")
          .addComponents(
            input("boxes", "Quantidade de caixas (1-25)", String(c.boxCount)),
            input(
              "duration",
              "Duração em minutos",
              String(Math.ceil(c.durationSeconds / 60)),
            ),
            input(
              "participants",
              "Máximo de participantes (0 = ilimitado)",
              String(c.maxParticipants ?? 0),
            ),
            input("title", "Título da embed", c.title),
            input("color", "Cor hexadecimal", c.color),
          ),
      ));
    }
    if (action === "termo-home")
      return void (await i.update(await termoAdminView(i.guild)));
    if (action === "termo-appearance")
      return void (await i.update(
        await require("../../games-chat/termo/admin").appearance(i.guild),
      ));
    if (action === "termo-appearance-edit") {
      const c = await termoConfig(i.guild.id);
      return void (await i.showModal(
        new ModalBuilder()
          .setCustomId("adm-games-modal:termo-appearance")
          .setTitle("Mensagem do TERMO")
          .addComponents(
            input("title", "Título", c.title),
            input("description", "Texto do painel", c.description, true, true),
            input("color", "Cor hexadecimal", c.color),
            input("image", "URL da imagem (opcional)", c.image || "", false),
            input("footer", "Rodapé (opcional)", c.footer || "", false),
          ),
      ));
    }
    if (action === "termo-settings") {
      const c = await termoConfig(i.guild.id);
      return void (await i.showModal(
        new ModalBuilder()
          .setCustomId("adm-games-modal:termo")
          .setTitle("TERMO — Configuração")
          .addComponents(
            input("length", "Quantidade de letras", String(c.wordLength)),
            input("attempts", "Máximo de tentativas", String(c.maxAttempts)),
            input(
              "repeat",
              "Dias antes de repetir palavra",
              String(c.repeatAfterDays),
            ),
            input("title", "Título da embed", c.title),
            input("color", "Cor hexadecimal", c.color),
          ),
      ));
    }
    if (action === "mystery-reward-add")
      return void (await i.showModal(
        new ModalBuilder()
          .setCustomId("adm-games-modal:reward")
          .setTitle("Cadastrar recompensa")
          .addComponents(
            input("name", "Nome da recompensa", ""),
            input("type", "Tipo: NADA, CARGO, TEMP, VIP, XP...", "NADA"),
            input("weight", "Peso no sorteio", "1"),
            input("stock", "Estoque (0 = ilimitado)", "0"),
            input(
              "details",
              "Quantidade | cargo ID | duração em min",
              "1",
              false,
            ),
          ),
      ));
    if (action === "mystery-winner") {
      const c = await mysteryConfig(i.guild.id);
      return void (await i.showModal(
        new ModalBuilder()
          .setCustomId("adm-games-modal:winner")
          .setTitle("Embed do ganhador")
          .addComponents(
            input("title", "Título", c.winnerTitle),
            input(
              "description",
              "Mensagem: {membro} {premio} {caixa}",
              c.winnerDescription,
            ),
            input("color", "Cor hexadecimal", c.winnerColor),
            input(
              "image",
              "URL da imagem (opcional)",
              c.winnerImage || "",
              false,
            ),
            input("footer", "Rodapé (opcional)", c.winnerFooter || "", false),
          ),
      ));
    }
    if (action === "mystery-reward-delete") {
      const rewards = await prisma.mysteryReward.findMany({
        where: { guildId: i.guild.id, active: true },
        orderBy: { createdAt: "desc" },
        take: 25,
      });
      if (!rewards.length)
        return void (await i.reply({
          content: "Não existem recompensas ativas para excluir.",
          ephemeral: true,
        }));
      const select = new StringSelectMenuBuilder()
        .setCustomId("adm-games-reward-delete:select")
        .setPlaceholder("Escolha a recompensa que será excluída")
        .addOptions(
          rewards.map((reward) => ({
            label: reward.name.slice(0, 100),
            value: reward.id,
            description: `${reward.type} · peso ${reward.weight}`.slice(0, 100),
          })),
        );
      return void (await i.reply({
        content:
          "Selecione uma recompensa. Itens já usados serão desativados para preservar o histórico.",
        components: [
          new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select),
        ],
        ephemeral: true,
      }));
    }
    if (action === "termo-word-add")
      return void (await i.showModal(
        new ModalBuilder()
          .setCustomId("adm-games-modal:word")
          .setTitle("Adicionar palavra ao TERMO")
          .addComponents(
            input("word", "Palavra (4 a 12 letras)", ""),
            input("answer", "Pode ser resposta? SIM ou NAO", "SIM"),
          ),
      ));
    if (action === "mystery-rewards") {
      const rewards = await prisma.mysteryReward.findMany({
        where: { guildId: i.guild.id },
        orderBy: { createdAt: "desc" },
        take: 25,
      });
      return void (await i.reply({
        content: rewards.length
          ? rewards
              .map(
                (r, n) =>
                  `**${n + 1}. ${r.name}** · ${r.type} · peso ${r.weight} · estoque ${r.stock ?? "∞"} · ${r.active ? "ativa" : "inativa"}`,
              )
              .join("\n")
          : "Nenhuma recompensa cadastrada.",
        ephemeral: true,
      }));
    }
    if (action === "termo-words") {
      const words = await prisma.termoWord.findMany({
        where: {
          OR: [{ guildId: null }, { guildId: i.guild.id }],
          active: true,
        },
        orderBy: { word: "asc" },
        take: 50,
      });
      return void (await i.reply({
        content: words.length
          ? `**Banco de palavras (${words.length} exibidas):**\n${words.map((w) => `\`${w.word.toLocaleUpperCase("pt-BR")}\`${w.canAnswer ? "" : " (somente tentativa)"}`).join(", ")}`
          : "O banco está vazio.",
        ephemeral: true,
      }));
    }
    if (action === "termo-ranking")
      return void (await i.reply({
        ...(await termoRankingView(i.guild)),
        ephemeral: true,
      }));
    await i.deferUpdate();
    try {
      if (action === "mystery-toggle") {
        const c = await mysteryConfig(i.guild.id);
        await prisma.mysteryBoxConfig.update({
          where: { guildId: i.guild.id },
          data: { enabled: !c.enabled },
        });
      }
      if (action === "termo-toggle") {
        const c = await termoConfig(i.guild.id);
        await prisma.termoConfig.update({
          where: { guildId: i.guild.id },
          data: { enabled: !c.enabled },
        });
      }
      if (action === "mystery-start")
        await createMysteryEvent(i.guild, i.user.id);
      if (action === "mystery-end") {
        const event = await prisma.mysteryEvent.findFirst({
          where: { guildId: i.guild.id, status: "ACTIVE" },
        });
        if (event) await endMysteryEvent(i.guild, event.id);
      }
      if (action === "termo-publish") await publishTermoPanel(i.guild);
      await i.editReply(
        action.startsWith("termo")
          ? await termoAdminView(i.guild)
          : await mysteryAdminView(i.guild),
      );
    } catch (error) {
      await i.followUp({
        content: `Erro: ${error instanceof Error ? error.message : String(error)}`,
        ephemeral: true,
      });
    }
  },
};
export default component;
