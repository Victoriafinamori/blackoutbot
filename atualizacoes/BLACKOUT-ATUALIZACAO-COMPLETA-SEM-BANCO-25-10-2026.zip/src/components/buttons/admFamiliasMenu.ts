const { prepareAdminPanel } = require("../../utils/adminTasks");
import {
  ButtonInteraction,
  MessageComponentInteraction,
  ModalSubmitInteraction,
  AnySelectMenuInteraction,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  RoleSelectMenuBuilder,
  ChannelSelectMenuBuilder,
  ChannelType,
  UserSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  EmbedBuilder,
} from "discord.js";
import { ButtonComponent } from "../../structures/types";
import { isBotAdmin } from "../../utils/permissions";
import { adminEmbed } from "../../utils/adminUi";
import {
  listFamilies,
  getFamily,
  deleteFamily,
  updateFamily,
  getFamilyMembers,
  getFamilyMonitoredChannelIds,
  MAX_FAMILY_MONITORED_CHANNELS,
  FamilyError,
} from "../../utils/families";

function backRow(customId: string, label = "Voltar") {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(customId).setLabel(label).setStyle(ButtonStyle.Secondary)
  );
}

type AnyInteraction = ButtonInteraction | ModalSubmitInteraction | AnySelectMenuInteraction;

async function replyOrUpdate(
  interaction: AnyInteraction,
  payload: { attachments: [], embeds: EmbedBuilder[]; components: ActionRowBuilder<any>[] }
) {
  if (interaction.isButton() || interaction.isAnySelectMenu()) {
    await interaction.update(payload);
    return;
  }
  if (interaction.isFromMessage()) {
    await interaction.update(payload);
  } else {
    await interaction.reply({ ...payload, ephemeral: true });
  }
}

export async function renderFamiliasMenu(interaction: MessageComponentInteraction) {
  const embed = (await adminEmbed(interaction.guild!, "servidor"))
    .setTitle("👨‍👩‍👧‍👦 VIP Família/Irmandade")
    .setDescription(
      "Esta categoria é destinada à configuração e gerenciamento das Famílias/Irmandades do servidor.\n\n" +
        "➕ **Criar** — cria uma nova Família/Irmandade\n" +
        "✏️ **Editar** — altera as configurações de uma Família já cadastrada\n" +
        "🗑️ **Excluir** — remove completamente uma Família (com confirmação)\n" +
        "📋 **Listar** — exibe todas as Famílias cadastradas\n" +
        "👑 **Definir Líder** — altera quem é o Dono de uma Família\n" +
        "📊 **Visualizar Informações** — resumo completo de uma Família"
    );

  const row1 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("adm-familias:criar").setLabel("Criar Família").setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId("adm-familias:pick:detail").setLabel("Editar Família").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("adm-familias:pick:excluir").setLabel("Excluir Família").setStyle(ButtonStyle.Danger)
  );

  const row2 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("adm-familias:listar").setLabel("Listar Famílias").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("adm-familias:pick:lider").setLabel("Definir Líder").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("adm-familias:pick:info").setLabel("Visualizar Informações").setStyle(ButtonStyle.Secondary)
  );

  await interaction.update(prepareAdminPanel(interaction.guild, 'familias', { attachments: [], embeds: [embed], components: [row1, row2, backRow("adm-nav:servidor")] }));
}

async function openCreateFamilyModal(interaction: ButtonInteraction) {
  const modal = new ModalBuilder().setCustomId("adm-modal:familia:criar").setTitle("Criar Família/Irmandade");

  const nameInput = new TextInputBuilder()
    .setCustomId("name")
    .setLabel("Nome da Família/Irmandade")
    .setStyle(TextInputStyle.Short)
    .setPlaceholder("Ex: Black Dragons")
    .setRequired(true)
    .setMaxLength(60);

  modal.addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(nameInput));
  await interaction.showModal(modal);
}

async function renderFamilyPicker(interaction: ButtonInteraction, action: string) {
  const families = await listFamilies(interaction.guild!.id);

  const titles: Record<string, string> = {
    detail: "✏️ Editar Família",
    excluir: "🗑️ Excluir Família",
    lider: "👑 Definir Líder",
    info: "📊 Visualizar Informações",
  };

  const embed = (await adminEmbed(interaction.guild!, "servidor"))
    .setTitle(titles[action] ?? "Famílias")
    .setDescription(
      families.length === 0
        ? "Nenhuma Família/Irmandade cadastrada ainda. Use **Criar Família** primeiro."
        : "Selecione a Família abaixo."
    );

  const components: ActionRowBuilder<any>[] = [];

  if (families.length > 0) {
    const select = new StringSelectMenuBuilder()
      .setCustomId(`adm-familia-picker:${action}`)
      .setPlaceholder("Selecione uma Família...")
      .addOptions(
        families.slice(0, 25).map((f: { id: string; name: string; active: boolean }) => ({
          value: f.id,
          label: f.name,
          description: f.active ? "Ativa" : "Inativa",
          emoji: f.active ? "✅" : "⏸️",
        }))
      );
    components.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select));
  }

  components.push(backRow("adm-familias:menu"));
  await interaction.update({ attachments: [], embeds: [embed], components });
}

async function renderFamiliesList(interaction: ButtonInteraction) {
  const families = await listFamilies(interaction.guild!.id);

  const embed = (await adminEmbed(interaction.guild!, "servidor"))
    .setTitle("📋 Famílias Cadastradas")
    .setDescription(
      families.length === 0
        ? "Nenhuma Família/Irmandade cadastrada ainda."
        : families
            .map((f: { name: string; active: boolean }) => `${f.active ? "✅" : "⏸️"} **${f.name}**`)
            .join("\n")
    );

  const components: ActionRowBuilder<any>[] = [];

  if (families.length > 0) {
    const select = new StringSelectMenuBuilder()
      .setCustomId("adm-familia-picker:detail")
      .setPlaceholder("Selecione uma Família para ver/editar...")
      .addOptions(
        families.slice(0, 25).map((f: { id: string; name: string; active: boolean }) => ({
          value: f.id,
          label: f.name,
          description: f.active ? "Ativa" : "Inativa",
          emoji: f.active ? "✅" : "⏸️",
        }))
      );
    components.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select));
  }

  components.push(backRow("adm-familias:menu"));
  await interaction.update({ attachments: [], embeds: [embed], components });
}

export async function renderFamilyDetail(interaction: AnyInteraction, familyId: string) {
  const family = await getFamily(interaction.guild!.id, familyId);
  if (!family) {
    await interaction.reply({ content: "❌ Família não encontrada (pode ter sido excluída).", ephemeral: true });
    return;
  }

  const monitored = getFamilyMonitoredChannelIds(family);

  const embed = (await adminEmbed(interaction.guild!, "servidor"))
    .setTitle(`👨‍👩‍👧‍👦 ${family.name}`)
    .setDescription(
      `**Status:** ${family.active ? "✅ Ativa" : "⏸️ Inativa"}\n` +
        `**Cargo de Membros:** ${family.memberRoleId ? `<@&${family.memberRoleId}>` : "*não definido*"}\n` +
        `**Cargo do Líder:** ${family.leaderRoleId ? `<@&${family.leaderRoleId}>` : "*não definido*"}\n` +
        `**Dono atual:** ${family.leaderUserId ? `<@${family.leaderUserId}>` : "*não definido*"}\n` +
        `**Canal de Voz:** ${family.voiceChannelId ? `<#${family.voiceChannelId}>` : "*não definido*"}\n` +
        `**Canais Monitorados (Mov Chat):** ${monitored.length ? monitored.map((id) => `<#${id}>`).join(", ") : "*nenhum*"}`
    );

  const row1 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(`adm-familias:nome:${family.id}`).setLabel("Editar Nome").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(`adm-familias:toggle:${family.id}`)
      .setLabel(family.active ? "Desativar" : "Ativar")
      
      .setStyle(family.active ? ButtonStyle.Secondary : ButtonStyle.Success)
  );

  const row2 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(`adm-familias:cargomembro:${family.id}`).setLabel("Cargo de Membros").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`adm-familias:cargolider:${family.id}`).setLabel("Cargo do Líder").setStyle(ButtonStyle.Secondary)
  );

  const row3 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(`adm-familias:canalvoz:${family.id}`).setLabel("Canal de Voz").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`adm-familias:canaismonitor:${family.id}`).setLabel("Canais Monitorados").setStyle(ButtonStyle.Secondary)
  );

  const row4 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(`adm-familias:excluirconfirm:${family.id}`).setLabel("Excluir Família").setStyle(ButtonStyle.Danger)
  );

  await replyOrUpdate(interaction, { attachments: [], embeds: [embed], components: [row1, row2, row3, row4, backRow("adm-familias:menu")] });
}

export async function renderFamilyInfo(interaction: AnyInteraction, familyId: string) {
  const family = await getFamily(interaction.guild!.id, familyId);
  if (!family) {
    await interaction.reply({ content: "❌ Família não encontrada (pode ter sido excluída).", ephemeral: true });
    return;
  }

  const members = await getFamilyMembers(interaction.guild!, family);
  const monitored = getFamilyMonitoredChannelIds(family);

  const embed = (await adminEmbed(interaction.guild!, "servidor"))
    .setTitle(`📊 ${family.name}`)
    .setDescription(
      `**Líder atual:** ${family.leaderUserId ? `<@${family.leaderUserId}>` : "*não definido*"}\n` +
        `**Quantidade de membros:** ${members.length}\n` +
        `**Cargo dos Membros:** ${family.memberRoleId ? `<@&${family.memberRoleId}>` : "*não definido*"}\n` +
        `**Cargo do Líder:** ${family.leaderRoleId ? `<@&${family.leaderRoleId}>` : "*não definido*"}\n` +
        `**Canal de Voz:** ${family.voiceChannelId ? `<#${family.voiceChannelId}>` : "*não definido*"}\n` +
        `**Canais Monitorados:** ${monitored.length ? monitored.map((id) => `<#${id}>`).join(", ") : "*nenhum*"}\n` +
        `**Status do Sistema:** ${family.active ? "✅ Ativo" : "⏸️ Inativo"}`
    );

  await replyOrUpdate(interaction, { attachments: [], embeds: [embed], components: [backRow("adm-familias:pick:info")] });
}

export async function renderExcluirConfirm(interaction: ButtonInteraction | AnySelectMenuInteraction, familyId: string) {
  const family = await getFamily(interaction.guild!.id, familyId);
  if (!family) {
    await interaction.reply({ content: "❌ Família não encontrada.", ephemeral: true });
    return;
  }

  const embed = (await adminEmbed(interaction.guild!, "servidor"))
    .setTitle("🗑️ Confirmar Exclusão")
    .setDescription(
      `Tem certeza que deseja excluir a Família **${family.name}**?\n\n` +
        "⚠️ Essa ação é **irreversível** e apaga também todo o histórico de Mov Chat dela."
    );

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(`adm-familias:excluirok:${family.id}`).setLabel("Sim, excluir").setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId(`adm-familias:detail:${family.id}`).setLabel("Cancelar").setStyle(ButtonStyle.Secondary)
  );

  await interaction.update({ attachments: [], embeds: [embed], components: [row] });
}

async function handleExcluirOk(interaction: ButtonInteraction, familyId: string) {
  try {
    await deleteFamily(interaction.guild!, interaction.user.id, familyId);
  } catch (err) {
    if (err instanceof FamilyError) {
      await interaction.reply({ content: `❌ ${err.message}`, ephemeral: true });
      return;
    }
    throw err;
  }

  const embed = (await adminEmbed(interaction.guild!, "servidor"))
    .setTitle("🗑️ Família Excluída")
    .setDescription("✅ A Família foi removida do sistema.");

  await interaction.update({ attachments: [], embeds: [embed], components: [backRow("adm-familias:menu")] });
}

async function handleToggleActive(interaction: ButtonInteraction, familyId: string) {
  const family = await getFamily(interaction.guild!.id, familyId);
  if (!family) {
    await interaction.reply({ content: "❌ Família não encontrada.", ephemeral: true });
    return;
  }

  try {
    await updateFamily(interaction.guild!, interaction.user.id, familyId, { active: !family.active });
  } catch (err) {
    if (err instanceof FamilyError) {
      await interaction.reply({ content: `❌ ${err.message}`, ephemeral: true });
      return;
    }
    throw err;
  }

  await renderFamilyDetail(interaction, familyId);
}

function openEditNameModal(interaction: ButtonInteraction, familyId: string) {
  const modal = new ModalBuilder().setCustomId(`adm-modal:familia:nome:${familyId}`).setTitle("Editar Nome");

  const nameInput = new TextInputBuilder()
    .setCustomId("name")
    .setLabel("Nome da Família/Irmandade")
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setMaxLength(60);

  modal.addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(nameInput));
  return interaction.showModal(modal);
}

async function renderRolePickerScreen(interaction: ButtonInteraction, familyId: string, kind: "membro" | "lider") {
  const family = await getFamily(interaction.guild!.id, familyId);
  if (!family) {
    await interaction.reply({ content: "❌ Família não encontrada.", ephemeral: true });
    return;
  }

  const isMembro = kind === "membro";
  const embed = (await adminEmbed(interaction.guild!, "servidor"))
    .setTitle(isMembro ? `🎫 Cargo de Membros — ${family.name}` : `👑 Cargo do Líder — ${family.name}`)
    .setDescription(
      isMembro
        ? "Selecione o cargo que define quem é membro dessa Família."
        : "Selecione o cargo que o Dono da Família precisa possuir."
    );

  const select = new RoleSelectMenuBuilder()
    .setCustomId(`adm-role-select:${isMembro ? "familymember" : "familyleader"}:${familyId}`)
    .setPlaceholder("Selecione o cargo")
    .setMinValues(1)
    .setMaxValues(1);

  const selectRow = new ActionRowBuilder<RoleSelectMenuBuilder>().addComponents(select);
  await interaction.update({ attachments: [], embeds: [embed], components: [selectRow, backRow(`adm-familias:detail:${familyId}`)] });
}

async function renderVoiceChannelPicker(interaction: ButtonInteraction, familyId: string) {
  const family = await getFamily(interaction.guild!.id, familyId);
  if (!family) {
    await interaction.reply({ content: "❌ Família não encontrada.", ephemeral: true });
    return;
  }

  const embed = (await adminEmbed(interaction.guild!, "servidor"))
    .setTitle(`🔊 Canal de Voz — ${family.name}`)
    .setDescription("Selecione o canal de voz oficial dessa Família (usado em Gerenciar Call, no /grupo).");

  const select = new ChannelSelectMenuBuilder()
    .setCustomId(`adm-familychannel-select:voice:${familyId}`)
    .setPlaceholder("Selecione o canal de voz")
    .addChannelTypes(ChannelType.GuildVoice)
    .setMinValues(1)
    .setMaxValues(1);

  const selectRow = new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(select);
  await interaction.update({ attachments: [], embeds: [embed], components: [selectRow, backRow(`adm-familias:detail:${familyId}`)] });
}

async function renderMonitorChannelsPicker(interaction: ButtonInteraction, familyId: string) {
  const family = await getFamily(interaction.guild!.id, familyId);
  if (!family) {
    await interaction.reply({ content: "❌ Família não encontrada.", ephemeral: true });
    return;
  }

  const current = getFamilyMonitoredChannelIds(family);

  const embed = (await adminEmbed(interaction.guild!, "servidor"))
    .setTitle(`💬 Canais Monitorados (Mov Chat) — ${family.name}`)
    .setDescription(
      `Selecione até ${MAX_FAMILY_MONITORED_CHANNELS} canais de texto que serão contados no Mov Chat exclusivo dessa Família.\n\n` +
        `**Atuais:** ${current.length ? current.map((id) => `<#${id}>`).join(", ") : "*nenhum*"}`
    );

  const select = new ChannelSelectMenuBuilder()
    .setCustomId(`adm-familychannel-select:monitor:${familyId}`)
    .setPlaceholder(`Selecione até ${MAX_FAMILY_MONITORED_CHANNELS} canais`)
    .addChannelTypes(ChannelType.GuildText)
    .setMinValues(0)
    .setMaxValues(MAX_FAMILY_MONITORED_CHANNELS);
  if (current.length) select.setDefaultChannels(current);

  const selectRow = new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(select);
  await interaction.update({ attachments: [], embeds: [embed], components: [selectRow, backRow(`adm-familias:detail:${familyId}`)] });
}

export async function renderLeaderUserPicker(interaction: AnyInteraction, familyId: string) {
  const family = await getFamily(interaction.guild!.id, familyId);
  if (!family) {
    await interaction.reply({ content: "❌ Família não encontrada.", ephemeral: true });
    return;
  }

  if (!family.leaderRoleId) {
    await replyOrUpdate(interaction, { attachments: [], embeds: [
        (await adminEmbed(interaction.guild!, "servidor"))
          .setTitle("👑 Definir Líder")
          .setDescription(
            `Configure primeiro o **Cargo do Líder** da Família **${family.name}** (em Editar Família) antes de definir o Dono.`
          ),
      ],
      components: [backRow(`adm-familias:detail:${familyId}`)],
    });
    return;
  }

  const embed = (await adminEmbed(interaction.guild!, "servidor"))
    .setTitle(`👑 Definir Líder — ${family.name}`)
    .setDescription(
      `Selecione o usuário que será o Dono dessa Família. Ele precisa já possuir o cargo <@&${family.leaderRoleId}>.\n\n` +
        `**Dono atual:** ${family.leaderUserId ? `<@${family.leaderUserId}>` : "*não definido*"}`
    );

  const select = new UserSelectMenuBuilder()
    .setCustomId(`adm-familyuser-select:${familyId}`)
    .setPlaceholder("Selecione o novo Dono da Família")
    .setMinValues(1)
    .setMaxValues(1);

  const selectRow = new ActionRowBuilder<UserSelectMenuBuilder>().addComponents(select);
  await replyOrUpdate(interaction, { attachments: [], embeds: [embed], components: [selectRow, backRow(`adm-familias:detail:${familyId}`)] });
}

export { renderFamilyPicker as renderFamiliaPicker };

const component: ButtonComponent = {
  customId: "adm-familias:",

  async execute(interaction: ButtonInteraction) {
    if (!interaction.guild) return;

    const member = await interaction.guild.members.fetch(interaction.user.id);
    if (!(await isBotAdmin(member))) {
      await interaction.reply({
        content: "🚫 Você não tem permissão para acessar esta seção.",
        ephemeral: true,
      });
      return;
    }

    const parts = interaction.customId.split(":"); // ["adm-familias", "acao", "sub?"]
    const action = parts[1];
    const sub = parts[2];

    switch (action) {
      case "menu":
        return renderFamiliasMenu(interaction);
      case "criar":
        return openCreateFamilyModal(interaction);
      case "listar":
        return renderFamiliesList(interaction);
      case "pick":
        return renderFamilyPicker(interaction, sub);
      case "detail":
        return renderFamilyDetail(interaction, sub);
      case "info":
        return renderFamilyInfo(interaction, sub);
      case "nome":
        return openEditNameModal(interaction, sub);
      case "toggle":
        return handleToggleActive(interaction, sub);
      case "excluirconfirm":
        return renderExcluirConfirm(interaction, sub);
      case "excluirok":
        return handleExcluirOk(interaction, sub);
      case "cargomembro":
        return renderRolePickerScreen(interaction, sub, "membro");
      case "cargolider":
        return renderRolePickerScreen(interaction, sub, "lider");
      case "canalvoz":
        return renderVoiceChannelPicker(interaction, sub);
      case "canaismonitor":
        return renderMonitorChannelsPicker(interaction, sub);
      // "cargomembro", "cargolider", "canalvoz", "canaismonitor" abrem
      // seletores tratados em outros arquivos (roleSelects.ts / familySelects.ts),
      // então aqui só precisamos renderizar a tela quando o customId bate
      // exatamente com o prefixo — o roteamento de fato acontece nos selects.
      default:
        return renderFamiliasMenu(interaction);
    }
  },
};

export default component;
