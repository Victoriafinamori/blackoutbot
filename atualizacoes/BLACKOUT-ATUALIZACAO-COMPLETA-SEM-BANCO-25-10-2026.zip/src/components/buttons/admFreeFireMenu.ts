const { prepareAdminPanel } = require("../../utils/adminTasks");
import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonInteraction,
  ButtonStyle,
  ChannelSelectMenuBuilder,
  ChannelType,
  MessageComponentInteraction,
  ModalBuilder,
  StringSelectMenuBuilder,
  TextInputBuilder,
  TextInputStyle,
} from "discord.js";
import { ButtonComponent } from "../../structures/types";
import { adminEmbed } from "../../utils/adminUi";
import { isBotAdmin } from "../../utils/permissions";
import { admEmoji } from "../../utils/admEmojis";
import { buildAdmSectionPanel } from "../../utils/admPanel";
import { countActiveDuos, getFFConfig, listDuos, resetTournament, updateFFConfig } from "../../ff/service";
import { refreshFFPanels, statusLabel } from "../../ff/views";

const RED = 0xd71935;
const yesNo = (value: boolean) => (value ? "Sim" : "Não");
const button = (customId: string, label: string, style = ButtonStyle.Secondary) =>
  new ButtonBuilder().setCustomId(customId).setLabel(label).setStyle(style);

function nav(customId: string, placeholder: string, options: { label: string; value: string; description?: string; emoji?: string }[]) {
  return new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder().setCustomId(customId).setPlaceholder(placeholder).addOptions(options)
  );
}

// -----------------------------------------------------------------------
// Tela principal — "Configurações do Free Fire"
// -----------------------------------------------------------------------

export async function renderFreeFireMenu(interaction: MessageComponentInteraction) {
  const icon = admEmoji(interaction.guild!, "campeonatos");
  const c = await getFFConfig(interaction.guild!.id);
  const active = await countActiveDuos(interaction.guild!.id);

  const dataHorario = c.eventDate || c.eventTime ? `${c.eventDate ?? "A definir"} às ${c.eventTime ?? "A definir"}` : "A definir";

  const embed = (await adminEmbed(interaction.guild!, "staff"))
    .setColor(RED)
    .setTitle("Configurações do Free Fire")
    .addFields(
      {
        name: "ℹ️ Informações",
        value:
          `Inscrições: **${c.enabled ? "Abertas" : "Fechadas"}**\n` +
          `Duplas: **${active}/${c.maxDuos}**\n` +
          `Tamanho máx. do nick: **${c.nickMaxLength} caracteres**\n` +
          `Data e horário: **${dataHorario}**\n` +
          `Canal de staff: **${c.staffChannelId ? `<#${c.staffChannelId}>` : "N/A"}**\n` +
          `Canal de logs: **${c.logChannelId ? `<#${c.logChannelId}>` : "N/A"}**\n` +
          `Painel de inscrição: **${c.panelChannelId ? `<#${c.panelChannelId}>` : "N/A"}**\n` +
          `Painel de duplas: **${c.listChannelId ? `<#${c.listChannelId}>` : "N/A"}**`,
      },
      {
        name: "Observações",
        value:
          "1. Abra as inscrições só depois de configurar os canais.\n" +
          "2. O painel de inscrição precisa ser publicado para os membros participarem.\n" +
          "3. Novas inscrições chegam pendentes no canal de staff para aprovação.\n" +
          "4. Resetar apaga todas as duplas e reinicia a numeração (#01, #02…).",
      }
    );

  await interaction.update(prepareAdminPanel(interaction.guild, 'freefire', { attachments: [], embeds: [embed],
    components: [
      nav("ff-admin-nav", "O que deseja configurar?", [
        { label: "Voltar", value: "back", description: "Retornar para Jogos e eventos", emoji: "↩️" },
        { label: "Abrir/Fechar inscrições", value: "status", description: "Controla se membros podem se inscrever", emoji: icon },
        { label: "Canais", value: "channels", description: "Canal de staff e de logs", emoji: icon },
        { label: "Vagas, nick e evento", value: "rules", description: "Limite de duplas, tamanho do nick, data e horário", emoji: icon },
        { label: "Painéis", value: "panels", description: "Publicar o painel de inscrição e a lista de duplas", emoji: icon },
        { label: "Duplas inscritas", value: "list", description: "Ver todas as inscrições e seus status", emoji: icon },
        { label: "Resetar tudo", value: "reset", description: "Apagar todas as duplas e reiniciar a numeração", emoji: icon },
      ]),
    ],
  }));
}

// -----------------------------------------------------------------------
// Status (abrir/fechar)
// -----------------------------------------------------------------------

export async function renderFreeFireStatus(interaction: MessageComponentInteraction) {
  const c = await getFFConfig(interaction.guild!.id);
  const embed = (await adminEmbed(interaction.guild!, "staff"))
    .setColor(RED)
    .setTitle("Status das Inscrições")
    .setDescription("Controle se os membros podem se inscrever agora. A mudança é refletida automaticamente nos painéis publicados.")
    .addFields({ name: "Estado atual", value: `Inscrições: **${c.enabled ? "Abertas" : "Fechadas"}**` });

  await interaction.update({ attachments: [], embeds: [embed],
    components: [
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        button("adm-ff:toggle-status", c.enabled ? "Fechar inscrições" : "Abrir inscrições", c.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
        button("adm-ff:menu", "Voltar")
      ),
    ],
  });
}

// -----------------------------------------------------------------------
// Canais (staff e logs)
// -----------------------------------------------------------------------

export async function renderFreeFireChannels(interaction: MessageComponentInteraction) {
  const c = await getFFConfig(interaction.guild!.id);
  const embed = (await adminEmbed(interaction.guild!, "staff"))
    .setColor(RED)
    .setTitle("Canais do Free Fire")
    .setDescription("Selecione abaixo. Uma seleção vazia remove a configuração.")
    .addFields({
      name: "Canais atuais",
      value: `Canal de staff: **${c.staffChannelId ? `<#${c.staffChannelId}>` : "N/A"}**\nCanal de logs: **${c.logChannelId ? `<#${c.logChannelId}>` : "N/A"}**`,
    });

  const staffSelect = new ChannelSelectMenuBuilder().setCustomId("ff-channel:staffChannelId").setPlaceholder("Canal de staff (novas inscrições)").addChannelTypes(ChannelType.GuildText).setMinValues(0).setMaxValues(1);
  const logsSelect = new ChannelSelectMenuBuilder().setCustomId("ff-channel:logChannelId").setPlaceholder("Canal de logs de ações").addChannelTypes(ChannelType.GuildText).setMinValues(0).setMaxValues(1);

  await interaction.update({ attachments: [], embeds: [embed],
    components: [
      new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(staffSelect),
      new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(logsSelect),
      new ActionRowBuilder<ButtonBuilder>().addComponents(button("adm-ff:menu", "Voltar")),
    ],
  });
}

// -----------------------------------------------------------------------
// Painéis (inscrição e lista de duplas)
// -----------------------------------------------------------------------

export async function renderFreeFirePanels(interaction: MessageComponentInteraction) {
  const c = await getFFConfig(interaction.guild!.id);
  const embed = (await adminEmbed(interaction.guild!, "staff"))
    .setColor(RED)
    .setTitle("Painéis do Free Fire")
    .setDescription("Selecione um canal para publicar (ou mover) cada painel.")
    .addFields({
      name: "Painéis atuais",
      value: `Inscrição: **${c.panelChannelId ? `<#${c.panelChannelId}>` : "N/A"}**\nLista de duplas: **${c.listChannelId ? `<#${c.listChannelId}>` : "N/A"}**`,
    });

  const registerSelect = new ChannelSelectMenuBuilder().setCustomId("ff-panel-channel:register").setPlaceholder("Publicar painel de inscrição em...").addChannelTypes(ChannelType.GuildText).setMinValues(1).setMaxValues(1);
  const listSelect = new ChannelSelectMenuBuilder().setCustomId("ff-panel-channel:list").setPlaceholder("Publicar lista de duplas em...").addChannelTypes(ChannelType.GuildText).setMinValues(1).setMaxValues(1);

  await interaction.update({ attachments: [], embeds: [embed],
    components: [
      new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(registerSelect),
      new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(listSelect),
      new ActionRowBuilder<ButtonBuilder>().addComponents(button("adm-ff:menu", "Voltar")),
    ],
  });
}

// -----------------------------------------------------------------------
// Lista de duplas
// -----------------------------------------------------------------------

export async function renderFreeFireList(interaction: MessageComponentInteraction) {
  const duos = await listDuos(interaction.guild!.id);
  const embed = (await adminEmbed(interaction.guild!, "staff")).setColor(RED).setTitle("Duplas Inscritas");

  if (duos.length === 0) {
    embed.setDescription("Nenhuma inscrição registrada ainda.");
  } else {
    const lines = duos.map(
      (d) => `**DUO #${String(d.number).padStart(2, "0")}** — ${d.player1Nick} (${d.player1GameId}) + ${d.player2Nick} (${d.player2GameId}) — ${statusLabel(d.status)}`
    );
    embed.setDescription(lines.join("\n").slice(0, 3900));
  }

  await interaction.update({ attachments: [], embeds: [embed], components: [new ActionRowBuilder<ButtonBuilder>().addComponents(button("adm-ff:menu", "Voltar"))] });
}

// -----------------------------------------------------------------------
// Modal — vagas, tamanho do nick, data e horário do evento
// -----------------------------------------------------------------------

export function buildFreeFireRulesModal(c: { maxDuos: number; nickMaxLength: number; eventDate: string | null; eventTime: string | null }) {
  const field = (id: string, label: string, value: string, required = true) =>
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder().setCustomId(id).setLabel(label).setStyle(TextInputStyle.Short).setRequired(required).setValue(value)
    );

  return new ModalBuilder()
    .setCustomId("ff-admin-modal:rules")
    .setTitle("Vagas, nick e evento")
    .addComponents(
      field("maxDuos", "Limite de duplas (número)", String(c.maxDuos)),
      field("nickMaxLength", "Tamanho máx. do nick (número)", String(c.nickMaxLength)),
      field("eventDate", "Data do evento (ex: 20/09/2026)", c.eventDate ?? "", false),
      field("eventTime", "Horário do evento (ex: 20:00)", c.eventTime ?? "", false)
    );
}

// -----------------------------------------------------------------------
// Botões: adm-ff:<ação>
// -----------------------------------------------------------------------

const component: ButtonComponent = {
  customId: "adm-ff:",
  async execute(interaction: ButtonInteraction) {
    if (!interaction.guild || !(await isBotAdmin(await interaction.guild.members.fetch(interaction.user.id)))) {
      await interaction.reply({ content: "🚫 Sem permissão.", ephemeral: true });
      return;
    }

    const [, action] = interaction.customId.split(":");

    if (action === "menu") return renderFreeFireMenu(interaction);
    if (action === "status") return renderFreeFireStatus(interaction);

    if (action === "toggle-status") {
      const c = await getFFConfig(interaction.guild.id);
      await updateFFConfig(interaction.guild.id, { enabled: !c.enabled });
      await refreshFFPanels(interaction.guild);
      return renderFreeFireStatus(interaction);
    }

    if (action === "reset-confirm") {
      await resetTournament(interaction.guild.id);
      await refreshFFPanels(interaction.guild);
      return renderFreeFireMenu(interaction);
    }
  },
};

export default component;
