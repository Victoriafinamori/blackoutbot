import { execute } from "../../bingo/cardAccess";
export default { customId: "bingo-card-view:", execute };
