import { execute } from "../../message-maker/interactions";
export default { customId: "maker:", execute };
