import { execute } from "../../games-chat/mystery-box/interactions";
export default { customId: "mystery-panel:", execute };
