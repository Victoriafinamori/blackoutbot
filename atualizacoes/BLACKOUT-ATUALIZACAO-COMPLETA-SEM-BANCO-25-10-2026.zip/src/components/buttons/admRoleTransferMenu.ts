import {
  ButtonInteraction,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  RoleSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} from "discord.js";
import { ButtonComponent } from "../../structures/types";
import { hasPermission } from "../../utils/permissions";
import { baseEmbed } from "../../utils/embeds";
import { PermissionType, TransferMode } from "../../structures/enums";
import {
  getRoleTransferConfig,
  isRoleTransferReady,
  updateRoleTransferConfig,
  runRoleTransfer,
  weekdayLabel,
} from "../../utils/roleTransfer";
import { formatDuration } from "../../utils/movStats";

function backRow(customId: string, label = "Voltar") {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(customId).setLabel(label).setStyle(ButtonStyle.Secondary)
  );
}

// Chamado por botões, selects de cargo e pelo submit dos modais — mesmo
// padrão "any" já usado em renderMovMenu/renderStageChatPanel.
export async function renderRoleTransferMenu(interaction: any) {
  const config = await getRoleTransferConfig(interaction.guild!.id);
  const ready = isRoleTransferReady(config);

  const requisitos: string[] = [];
  if (config.minCallSeconds) requisitos.push(`⏱️ Mínimo em call: **${formatDuration(config.minCallSeconds)}**`);
  if (config.minChatMessages) requisitos.push(`💬 Mínimo de mensagens: **${config.minChatMessages}**`);
  if (!requisitos.length) requisitos.push("*Nenhum requisito configurado — todos com o cargo de origem seriam movidos.*");

  const embed = (await baseEmbed(interaction.guild!))
    .setTitle("🔁 Transferência Automática de Cargo")
    .setDescription(
      "Move membros de um cargo para outro (ex: `Perdido` → `Membro`) assim que cumprem os requisitos.\n\n" +
        `**Cargo de origem:** ${config.sourceRoleId ? `<@&${config.sourceRoleId}>` : "*não definido*"}\n` +
        `**Cargo de destino:** ${config.targetRoleId ? `<@&${config.targetRoleId}>` : "*não definido*"}\n\n` +
        `**Requisitos:**\n${requisitos.join("\n")}\n\n` +
        `**Modo:** ${config.mode === TransferMode.AUTOMATIC ? "🤖 Automático" : "🖐️ Manual"}\n` +
        (config.mode === TransferMode.AUTOMATIC
          ? `**Agendamento:** toda(o) ${weekdayLabel(config.weekday)}, às ${String(config.hour).padStart(2, "0")}:${String(config.minute).padStart(2, "0")}\n`
          : "") +
        `**Última execução:** ${config.lastRunAt ? `<t:${Math.floor(new Date(config.lastRunAt).getTime() / 1000)}:R>` : "*nunca*"}\n\n` +
        (ready ? "" : "⚠️ *Defina o cargo de origem e o cargo de destino para poder rodar a transferência.*")
    );

  const row1 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("adm-roletransfer:sourcerole").setLabel("Cargo de Origem").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("adm-roletransfer:targetrole").setLabel("Cargo de Destino").setStyle(ButtonStyle.Secondary)
  );

  const row2 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("adm-roletransfer:requisitos").setLabel("Requisitos").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("adm-roletransfer:togglemode").setLabel(config.mode === TransferMode.AUTOMATIC ? "Modo: Automático" : "Modo: Manual").setStyle(ButtonStyle.Secondary)
  );

  const row3Components = [];
  if (config.mode === TransferMode.AUTOMATIC) {
    row3Components.push(
      new ButtonBuilder().setCustomId("adm-roletransfer:schedule").setLabel("Agendamento").setStyle(ButtonStyle.Secondary)
    );
  }
  row3Components.push(
    new ButtonBuilder()
      .setCustomId("adm-roletransfer:runnow")
      .setLabel("Rodar Agora")
      
      .setStyle(ButtonStyle.Success)
      .setDisabled(!ready)
  );
  const row3 = new ActionRowBuilder<ButtonBuilder>().addComponents(...row3Components);

  const payload = { embeds: [embed], components: [row1, row2, row3, backRow("adm-cfg:autocargo")] };
  if (interaction.deferred || interaction.replied) {
    await interaction.editReply(payload);
  } else {
    await interaction.update(payload);
  }
}

async function openRolePicker(interaction: ButtonInteraction, kind: "sourcerole" | "targetrole") {
  const config = await getRoleTransferConfig(interaction.guild!.id);
  const currentId = kind === "sourcerole" ? config.sourceRoleId : config.targetRoleId;
  const label = kind === "sourcerole" ? "cargo de ORIGEM (ex: Perdido)" : "cargo de DESTINO (ex: AUDAZ)";

  const embed = (await baseEmbed(interaction.guild!))
    .setTitle("🔁 Transferência Automática de Cargo")
    .setDescription(`Selecione o ${label}.`);

  const select = new RoleSelectMenuBuilder()
    .setCustomId(`adm-role-select:${kind}`)
    .setPlaceholder(`Selecione o ${label}`)
    .setMinValues(0)
    .setMaxValues(1);
  if (currentId) select.setDefaultRoles([currentId]);

  const selectRow = new ActionRowBuilder<RoleSelectMenuBuilder>().addComponents(select);
  await interaction.update({ embeds: [embed], components: [selectRow, backRow("adm-roletransfer:menu")] });
}

async function openRequisitosModal(interaction: ButtonInteraction) {
  const config = await getRoleTransferConfig(interaction.guild!.id);

  const modal = new ModalBuilder().setCustomId("adm-modal:roletransferreqs").setTitle("Requisitos para Transferência");

  const callHoursInput = new TextInputBuilder()
    .setCustomId("minCallHours")
    .setLabel("Mínimo de horas em call")
    .setPlaceholder("Vazio = sem requisito de call")
    .setStyle(TextInputStyle.Short)
    .setValue(config.minCallSeconds ? String(config.minCallSeconds / 3600) : "")
    .setRequired(false)
    .setMaxLength(6);

  const chatMessagesInput = new TextInputBuilder()
    .setCustomId("minChatMessages")
    .setLabel("Mínimo de mensagens (MOV CHAT)")
    .setPlaceholder("Vazio = sem requisito de mensagens")
    .setStyle(TextInputStyle.Short)
    .setValue(config.minChatMessages ? String(config.minChatMessages) : "")
    .setRequired(false)
    .setMaxLength(6);

  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(callHoursInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(chatMessagesInput)
  );

  await interaction.showModal(modal);
}

async function openScheduleModal(interaction: ButtonInteraction) {
  const config = await getRoleTransferConfig(interaction.guild!.id);

  const modal = new ModalBuilder().setCustomId("adm-modal:roletransferschedule").setTitle("Agendamento Semanal");

  const weekdayInput = new TextInputBuilder()
    .setCustomId("weekday")
    .setLabel("Dia da semana (0=Dom, 1=Seg ... 6=Sáb)")
    .setPlaceholder("Ex: 6 para sábado")
    .setStyle(TextInputStyle.Short)
    .setValue(String(config.weekday))
    .setRequired(true)
    .setMaxLength(1);

  const hourInput = new TextInputBuilder()
    .setCustomId("hour")
    .setLabel("Horário — hora (0-23)")
    .setPlaceholder("Ex: 12")
    .setStyle(TextInputStyle.Short)
    .setValue(String(config.hour))
    .setRequired(true)
    .setMaxLength(2);

  const minuteInput = new TextInputBuilder()
    .setCustomId("minute")
    .setLabel("Horário — minuto (0-59)")
    .setPlaceholder("Ex: 0")
    .setStyle(TextInputStyle.Short)
    .setValue(String(config.minute))
    .setRequired(true)
    .setMaxLength(2);

  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(weekdayInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(hourInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(minuteInput)
  );

  await interaction.showModal(modal);
}

async function handleToggleMode(interaction: ButtonInteraction) {
  const config = await getRoleTransferConfig(interaction.guild!.id);
  const nextMode = config.mode === TransferMode.AUTOMATIC ? TransferMode.MANUAL : TransferMode.AUTOMATIC;

  await updateRoleTransferConfig(
    interaction.guild!,
    interaction.user.id,
    { mode: nextMode },
    `Modo alterado para ${nextMode === TransferMode.AUTOMATIC ? "Automático" : "Manual"}.`
  );

  await renderRoleTransferMenu(interaction);
}

async function handleRunNow(interaction: ButtonInteraction) {
  // A verificação de todos os membros pode levar mais de 3s em servidores
  // grandes, então confirmamos a interação (sem alterar a mensagem ainda)
  // antes de rodar, e só depois atualizamos o painel via editReply.
  await interaction.deferUpdate();

  const result = await runRoleTransfer(interaction.guild!, interaction.user.id);

  await renderRoleTransferMenu(interaction);

  if (!result.ok) {
    await interaction.followUp({ content: `❌ ${result.error}`, ephemeral: true });
    return;
  }

  await interaction.followUp({
    content:
      `✅ Verificação concluída: **${result.checked}** membro(s) verificado(s), ` +
      `**${result.transferredUserIds.length}** transferido(s).`,
    ephemeral: true,
  });
}

const component: ButtonComponent = {
  customId: "adm-roletransfer:",

  async execute(interaction: ButtonInteraction) {
    if (!interaction.guild) return;

    const member = await interaction.guild.members.fetch(interaction.user.id);
    const authorized =
      (await hasPermission(member, PermissionType.STAGE_MANAGER)) ||
      (await hasPermission(member, PermissionType.REINTEGRATION_GRANTER));

    if (!authorized) {
      await interaction.reply({ content: "🚫 Você não tem permissão para acessar esta seção.", ephemeral: true });
      return;
    }

    const parts = interaction.customId.split(":"); // ["adm-roletransfer", "acao"]
    const action = parts[1];

    switch (action) {
      case "menu":
        return renderRoleTransferMenu(interaction);
      case "sourcerole":
        return openRolePicker(interaction, "sourcerole");
      case "targetrole":
        return openRolePicker(interaction, "targetrole");
      case "requisitos":
        return openRequisitosModal(interaction);
      case "schedule":
        return openScheduleModal(interaction);
      case "togglemode":
        return handleToggleMode(interaction);
      case "runnow":
        return handleRunNow(interaction);
      default:
        return renderRoleTransferMenu(interaction);
    }
  },
};

export default component;
