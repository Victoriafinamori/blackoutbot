// @ts-nocheck
import { ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } from "discord.js";
import { deferPanel } from "../../utils/panelInteraction";
import { isBotAdmin } from "../../utils/permissions";
import { prisma } from "../../database/prisma";
import { renderEmbedButtons } from "./admEmbedV2Menu";
import { fetchCustomEmbed } from "../../utils/customEmbeds";
async function normalizePositions(embedId) {
  const items = await prisma.customEmbedButton.findMany({ where: { embedId }, orderBy: { position: "asc" } });
  await prisma.$transaction(items.map((item, i) => prisma.customEmbedButton.update({ where: { id: item.id }, data: { position: i } })));
}
export default {
  customId: "embedv2-btn:",
  async execute(interaction) {
    if (!interaction.guild) return;
    const member = await interaction.guild.members.fetch(interaction.user.id);
    if (!(await isBotAdmin(member))) return interaction.reply({ content: "🚫 Sem permissão.", ephemeral: true });
    const [, action, embedId, buttonId] = interaction.customId.split(":");
    const record = await fetchCustomEmbed(embedId, interaction.guild.id);
    const item = record?.buttons.find((b) => b.id === buttonId);
    if (!record || !item) return interaction.reply({ content: "❌ Botão não encontrado.", ephemeral: true });
    if (action === "delete") {
      await deferPanel(interaction);
      await prisma.customEmbedButton.delete({ where: { id: buttonId } });
      await normalizePositions(embedId);
      return renderEmbedButtons(interaction, embedId);
    }
    if (action === "left" || action === "right") {
      const index = record.buttons.findIndex((b) => b.id === buttonId);
      const targetIndex = action === "left" ? index - 1 : index + 1;
      if (targetIndex < 0 || targetIndex >= record.buttons.length) return renderEmbedButtons(interaction, embedId);
      const target = record.buttons[targetIndex];
      await deferPanel(interaction);
      await prisma.$transaction([
        prisma.customEmbedButton.update({ where: { id: item.id }, data: { position: target.position } }),
        prisma.customEmbedButton.update({ where: { id: target.id }, data: { position: item.position } }),
      ]);
      return renderEmbedButtons(interaction, embedId);
    }
    if (action === "edit") {
      const modal = new ModalBuilder().setCustomId(`embedv2-modal:edit-button:${embedId}:${buttonId}`).setTitle("Editar botão").addComponents(
        new ActionRowBuilder<TextInputBuilder>().addComponents(new TextInputBuilder().setCustomId("label").setLabel("Texto do botão").setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(80).setValue(item.label)),
        new ActionRowBuilder<TextInputBuilder>().addComponents(new TextInputBuilder().setCustomId("emoji").setLabel("Emoji (opcional)").setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(50).setValue(item.emoji || "")),
      );
      if (item.type === "LINK") modal.addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(new TextInputBuilder().setCustomId("url").setLabel("Link (https://...)").setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(500).setValue(item.url || "")));
      return interaction.showModal(modal);
    }
  },
};
