import { isBotAdmin } from '../../utils/permissions';
import { showAdminMessagePreview } from '../../utils/adminMessagePreview';
const component={customId:'admin-preview:',async execute(i:any){
  if(!i.guild||!await isBotAdmin(await i.guild.members.fetch(i.user.id)))return;
  const value=i.customId.slice('admin-preview:'.length),editing=value.startsWith('edit-'),key=editing?value.slice(5):value;if(!['parcerias','denuncias','feedback','anonymous-photo','anonymous-message'].includes(key))return;
  await i.deferUpdate();return showAdminMessagePreview(i,key,!editing);
}};
export default component;
