import { ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelSelectMenuBuilder, ChannelType } from "discord.js";
import { ButtonComponent } from "../../structures/types";
import { getOrCreateGuildConfig } from "../../database/guildConfig";
import { prisma } from "../../database/prisma";
import { isBotAdmin } from "../../utils/permissions";
import { adminEmbed } from "../../utils/adminUi";
import { writableChannel } from "../../utils/configurationChecks";
import { deferPanel, refreshPanel } from "../../utils/panelInteraction";
export type NotificationModule = "moderacao" | "reintegracao";
export function moduleDm(config: { notifyDm: boolean; moderationNotifyDm?: boolean | null; reintegrationNotifyDm?: boolean | null }, module: NotificationModule) {
  return (module === "moderacao" ? config.moderationNotifyDm : config.reintegrationNotifyDm) ?? config.notifyDm;
}
export async function renderNotificationPanel(i: any, module: NotificationModule, notice?: string) {
  const c = await getOrCreateGuildConfig(i.guild.id), mod = module === "moderacao";
  const embed = adminEmbed(i.guild, mod ? "seguranca" : "membros").setTitle(mod ? "Avisos de moderação" : "Mensagens de reintegração")
    .setDescription(mod ? "Defina as mensagens enviadas aos membros e o destino dos avisos públicos de moderação." : "Defina se os participantes recebem as mensagens de reintegração por DM.")
    .addFields({ name: "DMs deste módulo", value: `${moduleDm(c,module) ? "Ativadas" : "Desativadas"}\nO envio depende de o membro permitir mensagens diretas.` });
  if (mod) embed.addFields({ name: "Avisos públicos de moderação", value: `${c.notifyPublicWarns ? "Ativados" : "Desativados"}\nDestino: ${c.reportsChannelId ? `<#${c.reportsChannelId}>` : "Não definido. Escolha um canal antes de ativar."}` });
  if (notice) embed.addFields({ name: "Resultado", value: notice.slice(0,1024) });
  const buttons = [new ButtonBuilder().setCustomId(`adm-notify:${module}:dm`).setLabel(moduleDm(c,module) ? "Desativar DMs" : "Ativar DMs").setStyle(ButtonStyle.Secondary)];
  const rows: any[] = [];
  if (mod) {
    const select = new ChannelSelectMenuBuilder().setCustomId("notice-channel-select:moderacao").setPlaceholder("Canal dos avisos públicos").addChannelTypes(ChannelType.GuildText,ChannelType.GuildAnnouncement).setMinValues(0).setMaxValues(1);
    if (c.reportsChannelId && i.guild.channels.cache.has(c.reportsChannelId)) select.setDefaultChannels([c.reportsChannelId]);
    rows.push(new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(select));
    buttons.push(new ButtonBuilder().setCustomId("adm-notify:moderacao:public").setLabel(c.notifyPublicWarns ? "Desativar avisos públicos" : "Ativar avisos públicos").setStyle(ButtonStyle.Secondary).setDisabled(!c.notifyPublicWarns && !c.reportsChannelId));
  }
  rows.push(new ActionRowBuilder<ButtonBuilder>().addComponents(buttons));
  rows.push(new ActionRowBuilder<ButtonBuilder>().addComponents(new ButtonBuilder().setCustomId(mod ? "adm-mod:menu" : "adm-reint:menu").setLabel("Voltar").setStyle(ButtonStyle.Secondary)));
  return refreshPanel(i,{content:null,attachments:[],embeds:[embed],components:rows});
}
const component: ButtonComponent = {customId:"adm-notify:",async execute(i){
  if(!i.guild || !await isBotAdmin(await i.guild.members.fetch(i.user.id))) return;
  const [,module,action]=i.customId.split(":");
  if(module!=="moderacao"&&module!=="reintegracao")return;
  if(!action)return renderNotificationPanel(i,module);
  const c=await getOrCreateGuildConfig(i.guild.id);
  if(action!=="dm" && !(action==="public"&&module==="moderacao"))return;
  if(action==="public"&&!c.notifyPublicWarns){
    if(!c.reportsChannelId)return renderNotificationPanel(i,module,"Escolha um canal para os avisos públicos.");
    const check=await writableChannel(i.guild,c.reportsChannelId,false);
    if(check.issue)return renderNotificationPanel(i,module,check.issue);
  }
  await deferPanel(i);
  const data=action==="public"?{notifyPublicWarns:!c.notifyPublicWarns}:module==="moderacao"?{moderationNotifyDm:!moduleDm(c,module)}:{reintegrationNotifyDm:!moduleDm(c,module)};
  await prisma.guildConfig.update({where:{guildId:i.guild.id},data});
  return renderNotificationPanel(i,module,"Alteração salva neste servidor.");
}};
export default component;
