const { prepareAdminPanel } = require("../../utils/adminTasks");
import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonInteraction,
  ButtonStyle,
  ChannelSelectMenuBuilder,
  ChannelType,
  MessageComponentInteraction,
  MessageFlags,
  ModalBuilder,
  RoleSelectMenuBuilder,
  TextInputBuilder,
  TextInputStyle,
} from "discord.js";
import { ButtonComponent } from "../../structures/types";
import { adminEmbed } from "../../utils/adminUi";
import { isBotAdmin } from "../../utils/permissions";
import { ids } from "../../utils/tickets";
import { prisma } from "../../database/prisma";
import { buildAdmSectionPanel } from "../../utils/admPanel";
import { buildReportAppearanceModal, publishReportPanel, reportConfig, reportOpeningPanel } from "../../utils/reports";

const RED = 0xd71935;
const roleText = (value: string | null) => ids(value).map(id => `<@&${id}>`).join(", ") || "Não configurado";
const styleName = (value?: string | null) => ({ PRIMARY: "Azul", SECONDARY: "Cinza", SUCCESS: "Verde", DANGER: "Vermelho" }[String(value || "DANGER").toUpperCase()] || "Vermelho");
const button = (customId: string, label: string, style = ButtonStyle.Secondary, emoji?: string) => {
  const b = new ButtonBuilder().setCustomId(customId).setLabel(label).setStyle(style);
  if (emoji) b.setEmoji(emoji);
  return b;
};

async function showPanelEditor(i:any){return require('../../utils/adminMessagePreview').showAdminMessagePreview(i,'denuncias');}

export async function renderDenunciasMenu(interaction: MessageComponentInteraction) {
  const c = await reportConfig(interaction.guild!.id);
  const open = await prisma.report.count({ where: { guildId: interaction.guild!.id, status: { in: ["RECEIVED", "ANALYSIS", "INVESTIGATION"] } } });
  const embed = (await adminEmbed(interaction.guild!, "atendimento")).setColor(RED).setTitle("🚨 Configurações — Central de Denúncias")
    .addFields(
      { name: "ℹ️ Informações", value: `Status: **${c.enabled ? "✅ Ativada" : "❌ Desativada"}**\nDenúncias abertas: **${open}**\nCargos responsáveis: **${roleText(c.staffRoleIds)}**` },
      { name: "📍 Canais", value: `Painel: **${c.panelChannelId ? `<#${c.panelChannelId}>` : "Não configurado"}**\nCategoria: **${c.categoryId ? `<#${c.categoryId}>` : "Não configurada"}**\nLogs: **${c.logChannelId ? `<#${c.logChannelId}>` : "Não configurado"}**` },
      { name: "🎨 Painel", value: `Título: **${c.panelTitle}**\nBotão: ${c.panelButtonEmoji || ""} **${c.panelButtonLabel}** • ${styleName(c.panelButtonStyle)}` },
      { name: "📨 Atendimento", value: "O membro inicia pelo botão do painel, informa denunciado, motivo e relato. Um canal privado é criado para o denunciante e os cargos responsáveis." },
    );

  await interaction.update(prepareAdminPanel(interaction.guild, 'denuncias', { attachments: [], embeds: [embed], components: [
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      button("adm-denuncia:back", "Voltar", ButtonStyle.Secondary, "↩️"),
      button("adm-denuncia:toggle", c.enabled ? "Desativar" : "Ativar", c.enabled ? ButtonStyle.Danger : ButtonStyle.Success, c.enabled ? "⛔" : "✅"),
      button("adm-denuncia:publish", "Publicar/Atualizar", ButtonStyle.Primary, "📨"),
    ),
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      button("adm-denuncia:appearance", "Painel", ButtonStyle.Secondary, "🎨"),
      button("adm-denuncia:channels", "Canais e Logs", ButtonStyle.Secondary, "📍"),
      button("adm-denuncia:roles", "Cargos", ButtonStyle.Secondary, "👮"),
    ),
  ] }));
}

export async function renderDenunciasSettings(interaction: MessageComponentInteraction) { return renderDenunciasMenu(interaction); }

export async function renderDenunciasChannels(interaction: MessageComponentInteraction) {
  const c = await reportConfig(interaction.guild!.id);
  const embed = (await adminEmbed(interaction.guild!, "atendimento")).setColor(RED).setTitle("📍 Canais e Logs — Denúncias")
    .setDescription("Selecione onde o painel será publicado, em qual categoria os atendimentos serão criados e onde os logs/transcripts serão enviados.")
    .addFields({ name: "Estado atual", value: `Painel: **${c.panelChannelId ? `<#${c.panelChannelId}>` : "Não configurado"}**\nCategoria: **${c.categoryId ? `<#${c.categoryId}>` : "Não configurada"}**\nLogs: **${c.logChannelId ? `<#${c.logChannelId}>` : "Não configurado"}**` });
  const fields = [
    ["panelChannelId", "Canal do painel de denúncias", [ChannelType.GuildText]],
    ["categoryId", "Categoria dos atendimentos", [ChannelType.GuildCategory]],
    ["logChannelId", "Canal de logs e transcripts", [ChannelType.GuildText]],
  ] as const;
  const rows = fields.map(([key, label, types]) => new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(
    new ChannelSelectMenuBuilder().setCustomId(`denuncia-channel:${key}`).setPlaceholder(label).addChannelTypes(...types).setMinValues(0).setMaxValues(1),
  ));
  await interaction.update({ attachments: [], embeds: [embed], components: [...rows, new ActionRowBuilder<ButtonBuilder>().addComponents(button("adm-denuncia:menu", "Voltar", ButtonStyle.Secondary, "↩️"))] });
}

export async function renderDenunciasRoles(interaction: MessageComponentInteraction) {
  const c = await reportConfig(interaction.guild!.id);
  const embed = (await adminEmbed(interaction.guild!, "atendimento")).setColor(RED).setTitle("👮 Cargos Responsáveis — Denúncias")
    .setDescription("Esses cargos poderão visualizar, assumir e encerrar denúncias.")
    .addFields({ name: "Cargos atuais", value: roleText(c.staffRoleIds) });
  const row = new ActionRowBuilder<RoleSelectMenuBuilder>().addComponents(
    new RoleSelectMenuBuilder().setCustomId("denuncia-role:staffRoleIds").setPlaceholder("Selecione os cargos responsáveis").setMinValues(0).setMaxValues(10),
  );
  await interaction.update({ attachments: [], embeds: [embed], components: [row, new ActionRowBuilder<ButtonBuilder>().addComponents(button("adm-denuncia:menu", "Voltar", ButtonStyle.Secondary, "↩️"))] });
}

const component: ButtonComponent = { customId: "adm-denuncia:", async execute(interaction: ButtonInteraction) {
  if (!interaction.guild || !(await isBotAdmin(await interaction.guild.members.fetch(interaction.user.id)))) return void await interaction.reply({ content: "Sem permissão.", flags: MessageFlags.Ephemeral });
  const [, action] = interaction.customId.split(":");
  if (action === "back") return void await interaction.update(await buildAdmSectionPanel(interaction.guild, "atendimento"));
  if (action === "menu") return renderDenunciasMenu(interaction);
  if (action === "channels") return renderDenunciasChannels(interaction);
  if (action === "roles") return renderDenunciasRoles(interaction);
  if (action === "appearance") return void await showPanelEditor(interaction);
  if (action === "edit-embed") return void await interaction.showModal(await buildReportAppearanceModal(interaction.guild.id));
  if (action === "edit-button") {
    const c = await reportConfig(interaction.guild.id);
    const modal = new ModalBuilder().setCustomId("denuncia-appearance:button").setTitle("Botão da Central de Denúncias").addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(new TextInputBuilder().setCustomId("label").setLabel("Texto do botão").setStyle(TextInputStyle.Short).setMaxLength(80).setValue(c.panelButtonLabel || "Iniciar denúncia").setRequired(true)),
      new ActionRowBuilder<TextInputBuilder>().addComponents(new TextInputBuilder().setCustomId("emoji").setLabel("Emoji (opcional)").setStyle(TextInputStyle.Short).setMaxLength(50).setValue(c.panelButtonEmoji || "").setRequired(false)),
      new ActionRowBuilder<TextInputBuilder>().addComponents(new TextInputBuilder().setCustomId("style").setLabel("Cor: AZUL, CINZA, VERDE ou VERMELHO").setStyle(TextInputStyle.Short).setValue(styleName(c.panelButtonStyle).toUpperCase()).setRequired(true)),
    );
    return void await interaction.showModal(modal);
  }
  if (action === "toggle") {
    const c = await reportConfig(interaction.guild.id);
    await prisma.reportConfig.update({ where: { guildId: interaction.guild.id }, data: { enabled: !c.enabled } });
    return renderDenunciasMenu(interaction);
  }
  if (action === "publish") {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    try {
      const message = await publishReportPanel(interaction.guild);
      await interaction.editReply(`✅ Painel de denúncias publicado/atualizado: ${message.url}`);
    } catch (error) {
      await interaction.editReply(error instanceof Error ? `❌ ${error.message}` : "❌ Não foi possível publicar o painel.");
    }
  }
} };
export default component;
