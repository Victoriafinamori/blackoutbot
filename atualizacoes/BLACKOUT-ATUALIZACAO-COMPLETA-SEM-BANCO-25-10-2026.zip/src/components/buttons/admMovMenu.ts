const { prepareAdminPanel } = require("../../utils/adminTasks");
import {
  ButtonInteraction,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelSelectMenuBuilder,
  ChannelType,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} from "discord.js";
import { ButtonComponent } from "../../structures/types";
import { isBotAdmin } from "../../utils/permissions";
import { adminEmbed } from "../../utils/adminUi";
import { logAdminAction } from "../../utils/adminLog";
import { AdminLogAction, MovStatType } from "../../structures/enums";
import {
  getGuildConfigForMov,
  getMovChatChannelIds,
  computeNextResetAt,
  resetMovStats,
  getRanking,
  MAX_MOV_CHAT_CHANNELS,
} from "../../utils/movStats";

function backRow(customId: string, label = "Voltar") {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(customId).setLabel(label).setStyle(ButtonStyle.Secondary)
  );
}

// Estas telas são chamadas tanto por botões quanto por selects de canal e,
// no caso do intervalo de reset, pelo submit do modal — por isso o tipo
// "any" aqui, igual ao padrão já usado em renderStageChatPanel.
//
// Este menu cuida só do MOV CHAT (mensagens). O tempo em call agora é o
// sistema Mov.Call, separado — ver /adm > Mov.Call e admMovCallMenu.ts.
export async function renderMovMenu(interaction: any) {
  const config = await getGuildConfigForMov(interaction.guild!.id);
  const chatChannels = getMovChatChannelIds(config);
  const nextReset = computeNextResetAt(config);

  const embed = (await adminEmbed(interaction.guild!, "servidor"))
    .setTitle("💬 Ranking de Atividade (MOV CHAT)")
    .setDescription(
      "Conta mensagens enviadas nos canais de texto escolhidos.\n\n" +
        `**Canais contados:** ${chatChannels.length ? chatChannels.map((id: string) => `<#${id}>`).join(", ") : "*nenhum selecionado*"}\n` +
        `**Reset automático:** ${
          config.movResetIntervalDays
            ? `a cada ${config.movResetIntervalDays} dia(s) — próximo em <t:${Math.floor((nextReset as Date).getTime() / 1000)}:R>`
            : "desativado (apenas manual)"
        }`
    );

  const row1 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("adm-mov:chatchannels").setLabel("Canais Contados").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("adm-mov:interval").setLabel("Intervalo de Reset").setStyle(ButtonStyle.Secondary)
  );

  const row2 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("adm-mov:resetnow").setLabel("Resetar Agora").setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId("adm-mov:ranking:CHAT").setLabel("Ver Ranking").setStyle(ButtonStyle.Secondary)
  );

  await interaction.update(prepareAdminPanel(interaction.guild, 'movchat', { attachments: [], embeds: [embed], components: [row1, row2, backRow("adm-nav:servidor", "Voltar")] }));
}

async function renderChatChannelsPicker(interaction: any) {
  const config = await getGuildConfigForMov(interaction.guild!.id);
  const current = getMovChatChannelIds(config);

  const embed = (await adminEmbed(interaction.guild!, "servidor"))
    .setTitle("💬 MOV CHAT — Canais Contados")
    .setDescription(`Selecione até ${MAX_MOV_CHAT_CHANNELS} canais de texto que contam mensagens no ranking.`);

  const select = new ChannelSelectMenuBuilder()
    .setCustomId("adm-movchatchannel-select")
    .setPlaceholder(`Selecione até ${MAX_MOV_CHAT_CHANNELS} canais`)
    .addChannelTypes(ChannelType.GuildText)
    .setMinValues(0)
    .setMaxValues(MAX_MOV_CHAT_CHANNELS);
  if (current.length) select.setDefaultChannels(current);

  const selectRow = new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(select);

  await interaction.update({ attachments: [], embeds: [embed], components: [selectRow, backRow("adm-mov:menu")] });
}

async function openResetIntervalModal(interaction: ButtonInteraction) {
  const config = await getGuildConfigForMov(interaction.guild!.id);

  const modal = new ModalBuilder().setCustomId("adm-modal:movinterval").setTitle("Intervalo de Reset do Ranking");

  const daysInput = new TextInputBuilder()
    .setCustomId("days")
    .setLabel("Reseta a cada quantos dias?")
    .setPlaceholder("Vazio = só reseto manualmente")
    .setStyle(TextInputStyle.Short)
    .setValue(config.movResetIntervalDays ? String(config.movResetIntervalDays) : "")
    .setRequired(false)
    .setMaxLength(4);

  modal.addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(daysInput));
  await interaction.showModal(modal);
}

async function handleResetNow(interaction: ButtonInteraction) {
  await resetMovStats(interaction.guild!.id);
  await logAdminAction({
    guild: interaction.guild!,
    actorId: interaction.user.id,
    action: AdminLogAction.MOV_RESET,
    details: "Reset manual do ranking de atividade (MOV CHAT).",
  });
  await renderMovMenu(interaction);
}

async function renderRanking(interaction: ButtonInteraction, type: MovStatType) {
  const rows = await getRanking(interaction.guild!.id, type, 10);

  const lines = rows.length
    ? rows
        .map((r: { userId: string; value: number }, i: number) => `**${i + 1}.** <@${r.userId}> — ${r.value} mensagem(ns)`)
        .join("\n")
    : "*Ninguém pontuou ainda.*";

  const embed = (await adminEmbed(interaction.guild!, "servidor")).setTitle("📈 Ranking — MOV CHAT").setDescription(lines);

  await interaction.update({ attachments: [], embeds: [embed], components: [backRow("adm-mov:menu")] });
}

const component: ButtonComponent = {
  customId: "adm-mov:",

  async execute(interaction: ButtonInteraction) {
    if (!interaction.guild) return;

    const member = await interaction.guild.members.fetch(interaction.user.id);
    if (!(await isBotAdmin(member))) {
      await interaction.reply({ content: "🚫 Você não tem permissão para acessar esta seção.", ephemeral: true });
      return;
    }

    const parts = interaction.customId.split(":"); // ["adm-mov", "acao", "sub?"]
    const action = parts[1];
    const sub = parts[2];

    switch (action) {
      case "menu":
        return renderMovMenu(interaction);
      case "chatchannels":
        return renderChatChannelsPicker(interaction);
      case "interval":
        return openResetIntervalModal(interaction);
      case "resetnow":
        return handleResetNow(interaction);
      case "ranking":
        return renderRanking(interaction, sub as MovStatType);
      default:
        return renderMovMenu(interaction);
    }
  },
};

export default component;
