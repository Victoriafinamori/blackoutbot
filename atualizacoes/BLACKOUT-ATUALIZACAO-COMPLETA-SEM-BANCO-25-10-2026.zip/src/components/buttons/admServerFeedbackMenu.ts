const { prepareAdminPanel } = require("../../utils/adminTasks");
import { ActionRowBuilder, ButtonBuilder, ButtonInteraction, ButtonStyle, ChannelSelectMenuBuilder, ChannelType, Guild, MessageComponentInteraction, ModalBuilder, TextInputBuilder, TextInputStyle } from "discord.js";
import { ButtonComponent } from "../../structures/types";
import { adminEmbed } from "../../utils/adminUi";
import { getServerFeedbackConfig, publishServerFeedbackPanel } from "../../utils/serverFeedback";
import { prisma } from "../../database/prisma";
import { buildAdmSectionPanel } from "../../utils/admPanel";
import { isBotAdmin } from "../../utils/permissions";

export async function buildServerFeedbackAdminView(guild: Guild) {
  const config = await getServerFeedbackConfig(guild.id), count = await prisma.serverFeedback.count({ where: { guildId: guild.id } });
  const embed = (await adminEmbed(guild, "servidor")).setTitle("Feedback do Servidor").setDescription("Painel público de sugestões anônimas com votação por reações.").addFields(
    { name: "Configurações", value: `Sistema: **${config.enabled ? "Ativo" : "Desativado"}**\nCanal do painel: ${config.panelChannelId ? `<#${config.panelChannelId}>` : "Não configurado"}\nCanal das sugestões: ${config.destinationChannelId ? `<#${config.destinationChannelId}>` : "Não configurado"}\nFeedbacks recebidos: **${count}**` },
    { name: "Privacidade", value: "O nome do autor nunca aparece na publicação pública. A identidade fica disponível somente no histórico administrativo." });
  const panelChannel = new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(new ChannelSelectMenuBuilder().setCustomId("adm-feedback-channel:panel").setPlaceholder("Escolher canal do painel público").setChannelTypes(ChannelType.GuildText));
  const destination = new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(new ChannelSelectMenuBuilder().setCustomId("adm-feedback-channel:destination").setPlaceholder("Escolher canal das sugestões").setChannelTypes(ChannelType.GuildText));
  const actions = new ActionRowBuilder<ButtonBuilder>().addComponents(new ButtonBuilder().setCustomId("adm-feedback:toggle").setLabel(config.enabled ? "Desativar" : "Ativar").setStyle(config.enabled ? ButtonStyle.Secondary : ButtonStyle.Success), new ButtonBuilder().setCustomId("adm-feedback:appearance").setLabel("Editar painel").setStyle(ButtonStyle.Primary), new ButtonBuilder().setCustomId("adm-feedback:publish").setLabel("Publicar/Atualizar").setStyle(ButtonStyle.Success).setDisabled(!config.enabled || !config.panelChannelId || !config.destinationChannelId), new ButtonBuilder().setCustomId("adm-feedback:history").setLabel("Histórico privado").setStyle(ButtonStyle.Secondary));
  const back = new ActionRowBuilder<ButtonBuilder>().addComponents(new ButtonBuilder().setCustomId("adm-feedback:back").setLabel("Voltar").setStyle(ButtonStyle.Secondary));
  return { attachments: [], embeds: [embed], components: [panelChannel, destination, actions, back] };
}
export async function renderServerFeedbackMenu(i: MessageComponentInteraction) { await i.update(prepareAdminPanel(i.guild, 'feedback', await buildServerFeedbackAdminView(i.guild!))); }
const field = (id: string, label: string, value: string, style = TextInputStyle.Short, required = true) => { const input = new TextInputBuilder().setCustomId(id).setLabel(label).setStyle(style).setRequired(required); if (value) input.setValue(value); return new ActionRowBuilder<TextInputBuilder>().addComponents(input); };
const component: ButtonComponent = { customId: "adm-feedback:", async execute(i: ButtonInteraction) {
  if (!i.guild) return; if (!(await isBotAdmin(await i.guild.members.fetch(i.user.id)))) return void await i.reply({ content: "Você não possui permissão.", ephemeral: true }); const action = i.customId.split(":")[1], config = await getServerFeedbackConfig(i.guild.id);
  if (action === "appearance") return void await i.showModal(new ModalBuilder().setCustomId("adm-feedback-modal:appearance").setTitle("Painel de Feedback").addComponents(field("title", "Título", config.title), field("description", "Descrição", config.description, TextInputStyle.Paragraph), field("color", "Cor hexadecimal", config.color), field("image", "URL da imagem (opcional)", config.image || "", TextInputStyle.Short, false), field("button", "Texto do botão", config.buttonLabel)));
  if (action === "history") { const rows = await prisma.serverFeedback.findMany({ where: { guildId: i.guild.id }, orderBy: { createdAt: "desc" }, take: 10 }); const history = rows.map(row => `**${row.id}** · Autor: <@${row.authorId}> · <t:${Math.floor(row.createdAt.getTime() / 1000)}:R>\n${row.content.slice(0, 150)}${row.content.length > 150 ? "…" : ""}`).join("\n\n").slice(0, 1900); return void await i.reply({ content: history || "Nenhum feedback recebido.", ephemeral: true }); }
  if (action === "back") return void await i.update(await buildAdmSectionPanel(i.guild, "servidor"));
  await i.deferUpdate(); try { if (action === "toggle") await prisma.serverFeedbackConfig.update({ where: { guildId: i.guild.id }, data: { enabled: !config.enabled } }); if (action === "publish") await publishServerFeedbackPanel(i.guild); await i.editReply(await buildServerFeedbackAdminView(i.guild)); } catch (error) { await i.followUp({ content: `Erro: ${error instanceof Error ? error.message : String(error)}`, ephemeral: true }); }
} }; export default component;
