const { prepareAdminPanel } = require("../../utils/adminTasks");
import { ButtonInteraction, MessageComponentInteraction, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } from "discord.js";
import { ButtonComponent } from "../../structures/types";
import { isBotAdmin } from "../../utils/permissions";
import { adminEmbed } from "../../utils/adminUi";
import { prisma } from "../../database/prisma";
import { AdminLogAction, MemberStatus, ModerationActionType } from "../../structures/enums";

function backRow(customId: string, label = "Voltar") {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(customId).setLabel(label).setStyle(ButtonStyle.Secondary)
  );
}

const DAY_MS = 24 * 60 * 60 * 1000;

const STATS_CATEGORIES = [
  { value: "reintegracao", label: "Reintegração", emoji: "👥", description: "Membros ativos, concluídos, por etapa" },
  { value: "moderacao", label: "Moderação", emoji: "⚖️", description: "Advertências, mutes, kicks, bans" },
  { value: "seguranca", label: "Segurança", emoji: "🛡️", description: "Entradas, saídas e ocorrências de auto-mod" },
  { value: "staff", label: "Staff", emoji: "🎖️", description: "Cargos configurados e atividade da equipe" },
  { value: "servidor", label: "Servidor", emoji: "🌐", description: "Membros, canais, cargos e boosts" },
  { value: "ranking", label: "Ranking (Chat)", emoji: "💬", description: "Atividade de mensagens, com reset configurável" },
] as const;

export async function renderStatsMenu(interaction: MessageComponentInteraction) {
  const embed = (await adminEmbed(interaction.guild!, "servidor"))
    .setTitle("📊 Estatísticas")
    .setDescription(
      "Selecione um painel abaixo para ver os números atualizados do servidor.\n\n" +
        "O tempo em voz pode ser consultado em **Comunidade e atividade → Atividade em call**."
    )
    .addFields({
      name: "📋 Painéis",
      value: STATS_CATEGORIES.map((c) => `${c.emoji} \`${c.label}\` — ${c.description}`).join("\n"),
    });

  const select = new StringSelectMenuBuilder()
    .setCustomId("adm-stats-select")
    .setPlaceholder("Selecione um painel...")
    .addOptions(
      STATS_CATEGORIES.map((c) => ({
        value: c.value,
        label: c.label,
        emoji: c.emoji,
        description: c.description,
      }))
    );

  const selectRow = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select);

  await interaction.update(prepareAdminPanel(interaction.guild, 'estatisticas', { attachments: [], embeds: [embed], components: [selectRow, backRow("adm-nav:servidor")] }));
}

// -----------------------------
// Reintegração
// -----------------------------
async function renderReintegrationStats(interaction: ButtonInteraction) {
  const guildId = interaction.guild!.id;

  const [active, completed, removed, blacklisted, evaluations, stages, byStage] = await Promise.all([
    prisma.reintegrationMember.count({ where: { guildId, status: MemberStatus.ACTIVE } }),
    prisma.reintegrationMember.count({ where: { guildId, status: MemberStatus.COMPLETED } }),
    prisma.reintegrationMember.count({ where: { guildId, status: MemberStatus.REMOVED } }),
    prisma.blacklist.count({ where: { guildId } }),
    prisma.evaluation.groupBy({ by: ["approved"], where: { guildId }, _count: { _all: true } }),
    prisma.stage.findMany({ where: { guildId }, orderBy: { order: "asc" } }),
    prisma.reintegrationMember.groupBy({
      by: ["currentStageId"],
      where: { guildId, status: MemberStatus.ACTIVE },
      _count: { _all: true },
    }),
  ]);

  const approved = evaluations.find((e: { approved: boolean }) => e.approved)?._count._all ?? 0;
  const reproved = evaluations.find((e: { approved: boolean }) => !e.approved)?._count._all ?? 0;

  const stageCounts = new Map(byStage.map((b: { currentStageId: string | null; _count: { _all: number } }) => [b.currentStageId, b._count._all]));
  const stageLines = stages.length
    ? stages
        .map((s: { id: string; name: string }) => `**${s.name}** — ${stageCounts.get(s.id) ?? 0} membro(s)`)
        .join("\n")
    : "*Nenhuma etapa cadastrada.*";

  const embed = (await adminEmbed(interaction.guild!, "servidor"))
    .setTitle("👥 Estatísticas — Reintegração")
    .addFields(
      { name: "Ativos", value: String(active), inline: true },
      { name: "Concluídos", value: String(completed), inline: true },
      { name: "Removidos", value: String(removed), inline: true },
      { name: "Na blacklist", value: String(blacklisted), inline: true },
      { name: "Avaliações aprovadas", value: String(approved), inline: true },
      { name: "Avaliações reprovadas", value: String(reproved), inline: true },
      { name: "Distribuição por etapa (ativos)", value: stageLines }
    );

  await interaction.update({ attachments: [], embeds: [embed], components: [backRow("adm-stats:menu")] });
}

// -----------------------------
// Moderação
// -----------------------------
async function renderModerationStats(interaction: ButtonInteraction) {
  const guildId = interaction.guild!.id;

  const [warnsActive, warnsTotal, mutesActive, mutesTotal, kicks, bans, unbans, automodTotal, automod7d] =
    await Promise.all([
      prisma.warn.count({ where: { guildId, active: true } }),
      prisma.warn.count({ where: { guildId } }),
      prisma.mute.count({ where: { guildId, active: true } }),
      prisma.mute.count({ where: { guildId } }),
      prisma.moderationAction.count({ where: { guildId, type: ModerationActionType.KICK } }),
      prisma.moderationAction.count({ where: { guildId, type: ModerationActionType.BAN } }),
      prisma.moderationAction.count({ where: { guildId, type: ModerationActionType.UNBAN } }),
      prisma.adminLog.count({ where: { guildId, action: AdminLogAction.AUTO_MOD_TRIGGERED } }),
      prisma.adminLog.count({
        where: {
          guildId,
          action: AdminLogAction.AUTO_MOD_TRIGGERED,
          createdAt: { gte: new Date(Date.now() - 7 * DAY_MS) },
        },
      }),
    ]);

  const embed = (await adminEmbed(interaction.guild!, "servidor"))
    .setTitle("⚖️ Estatísticas — Moderação")
    .addFields(
      { name: "Advertências ativas", value: String(warnsActive), inline: true },
      { name: "Advertências (histórico)", value: String(warnsTotal), inline: true },
      { name: "Mutes ativos", value: String(mutesActive), inline: true },
      { name: "Mutes (histórico)", value: String(mutesTotal), inline: true },
      { name: "Expulsões (kick)", value: String(kicks), inline: true },
      { name: "Banimentos", value: String(bans), inline: true },
      { name: "Desbanimentos", value: String(unbans), inline: true },
      { name: "Violações de filtro (auto-mod)", value: String(automodTotal), inline: true },
      { name: "Violações nos últimos 7 dias", value: String(automod7d), inline: true }
    );

  await interaction.update({ attachments: [], embeds: [embed], components: [backRow("adm-stats:menu")] });
}

// -----------------------------
// Segurança
// -----------------------------
async function renderSecurityStats(interaction: ButtonInteraction) {
  const guildId = interaction.guild!.id;
  const since7d = new Date(Date.now() - 7 * DAY_MS);
  const since30d = new Date(Date.now() - 30 * DAY_MS);

  const [joins7d, joins30d, leaves7d, leaves30d, automodTotal, banExternalTotal] = await Promise.all([
    prisma.adminLog.count({ where: { guildId, action: AdminLogAction.MEMBER_JOINED, createdAt: { gte: since7d } } }),
    prisma.adminLog.count({ where: { guildId, action: AdminLogAction.MEMBER_JOINED, createdAt: { gte: since30d } } }),
    prisma.adminLog.count({ where: { guildId, action: AdminLogAction.MEMBER_LEFT, createdAt: { gte: since7d } } }),
    prisma.adminLog.count({ where: { guildId, action: AdminLogAction.MEMBER_LEFT, createdAt: { gte: since30d } } }),
    prisma.adminLog.count({ where: { guildId, action: AdminLogAction.AUTO_MOD_TRIGGERED, createdAt: { gte: since30d } } }),
    prisma.adminLog.count({
      where: {
        guildId,
        action: { in: [AdminLogAction.MEMBER_BANNED_EXTERNAL, AdminLogAction.MEMBER_UNBANNED_EXTERNAL] },
        createdAt: { gte: since30d },
      },
    }),
  ]);

  const net30d = joins30d - leaves30d;

  const embed = (await adminEmbed(interaction.guild!, "servidor"))
    .setTitle("🛡️ Estatísticas — Segurança")
    .addFields(
      { name: "Entradas (7 dias)", value: String(joins7d), inline: true },
      { name: "Saídas (7 dias)", value: String(leaves7d), inline: true },
      { name: "Saldo (7 dias)", value: String(joins7d - leaves7d), inline: true },
      { name: "Entradas (30 dias)", value: String(joins30d), inline: true },
      { name: "Saídas (30 dias)", value: String(leaves30d), inline: true },
      { name: "Saldo (30 dias)", value: String(net30d), inline: true },
      { name: "Ocorrências de auto-mod (30 dias)", value: String(automodTotal), inline: true }
    );

  if (banExternalTotal > 0) {
    embed.addFields({ name: "Bans/unbans externos (30 dias)", value: String(banExternalTotal), inline: true });
  }

  await interaction.update({ attachments: [], embeds: [embed], components: [backRow("adm-stats:menu")] });
}

// -----------------------------
// Staff
// -----------------------------
async function renderStaffStats(interaction: ButtonInteraction) {
  const guildId = interaction.guild!.id;

  const [botAdmins, permissionRoles, topActors] = await Promise.all([
    prisma.botAdmin.count({ where: { guildId } }),
    prisma.permissionRole.count({ where: { guildId } }),
    prisma.adminLog.groupBy({
      by: ["actorId"],
      where: {
        guildId,
        action: { notIn: [AdminLogAction.MEMBER_JOINED, AdminLogAction.MEMBER_LEFT, AdminLogAction.BOT_STARTED] },
      },
      _count: { _all: true },
      orderBy: { _count: { actorId: "desc" } },
      take: 5,
    }),
  ]);

  const ranking = topActors.length
    ? topActors
        .map((t: { actorId: string; _count: { _all: number } }, i: number) => `**${i + 1}.** <@${t.actorId}> — ${t._count._all} ação(ões)`)
        .join("\n")
    : "*Nenhuma ação administrativa registrada ainda.*";

  const embed = (await adminEmbed(interaction.guild!, "servidor"))
    .setTitle("🎖️ Estatísticas — Staff")
    .addFields(
      { name: "Cargos de Administrador do BOT", value: String(botAdmins), inline: true },
      { name: "Cargos de permissão configurados", value: String(permissionRoles), inline: true },
      { name: "Staff mais ativa (todas as ações)", value: ranking }
    );

  await interaction.update({ attachments: [], embeds: [embed], components: [backRow("adm-stats:menu")] });
}

// -----------------------------
// Servidor
// -----------------------------
async function renderServerStats(interaction: ButtonInteraction) {
  const guild = interaction.guild!;
  await guild.members.fetch().catch(() => null);

  const humans = guild.members.cache.filter((m) => !m.user.bot).size;
  const bots = guild.members.cache.filter((m) => m.user.bot).size;

  const embed = (await adminEmbed(guild, "servidor"))
    .setTitle("🌐 Estatísticas — Servidor")
    .addFields(
      { name: "Membros (total)", value: String(guild.memberCount), inline: true },
      { name: "Humanos", value: String(humans), inline: true },
      { name: "Bots", value: String(bots), inline: true },
      { name: "Canais", value: String(guild.channels.cache.size), inline: true },
      { name: "Cargos", value: String(guild.roles.cache.size), inline: true },
      { name: "Boosts", value: `${guild.premiumSubscriptionCount ?? 0} (nível ${guild.premiumTier})`, inline: true },
      { name: "Servidor criado em", value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:D>`, inline: true }
    );

  await interaction.update({ attachments: [], embeds: [embed], components: [backRow("adm-stats:menu")] });
}

export { renderReintegrationStats, renderModerationStats, renderSecurityStats, renderStaffStats, renderServerStats };

const component: ButtonComponent = {
  customId: "adm-stats:",

  async execute(interaction: ButtonInteraction) {
    if (!interaction.guild) return;

    const member = await interaction.guild.members.fetch(interaction.user.id);
    if (!(await isBotAdmin(member))) {
      await interaction.reply({
        content: "🚫 Você não tem permissão para acessar esta seção.",
        ephemeral: true,
      });
      return;
    }

    const action = interaction.customId.split(":")[1];

    switch (action) {
      case "menu":
        return renderStatsMenu(interaction);
      case "reintegracao":
        return renderReintegrationStats(interaction);
      case "moderacao":
        return renderModerationStats(interaction);
      case "seguranca":
        return renderSecurityStats(interaction);
      case "staff":
        return renderStaffStats(interaction);
      case "servidor":
        return renderServerStats(interaction);
      default:
        return renderStatsMenu(interaction);
    }
  },
};

export default component;
