import { renderMemberModeration } from "../../utils/moderationPanel";
import { refreshPanel, deferPanel } from "../../utils/panelInteraction";
import {
  ButtonInteraction,
  MessageComponentInteraction,
  ModalSubmitInteraction,
  AnySelectMenuInteraction,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  EmbedBuilder,
  UserSelectMenuBuilder,
  ChannelSelectMenuBuilder,
  ChannelType,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} from "discord.js";
import { ButtonComponent } from "../../structures/types";
import { isBotAdmin } from "../../utils/permissions";
import { adminEmbed } from "../../utils/adminUi";
import { getOrCreateGuildConfig } from "../../database/guildConfig";
import { prisma } from "../../database/prisma";
import { logAdminAction } from "../../utils/adminLog";
import { AdminLogAction, AutoModAction, FilterRuleType } from "../../structures/enums";
import { getWordWatchChannelIds, MAX_WORD_WATCH_CHANNELS } from "../../utils/wordWatch";

const FILTER_FIELDS: Record<
  string,
  {
    label: string;
    column:
      | "filterWordsEnabled"
      | "filterLinksEnabled"
      | "filterFloodEnabled"
      | "filterCapsEnabled"
      | "filterSpamEnabled"
      | "filterToxicityEnabled";
  }
> = {
  palavras: { label: "Palavras", column: "filterWordsEnabled" },
  links: { label: "Links", column: "filterLinksEnabled" },
  flood: { label: "Flood", column: "filterFloodEnabled" },
  caps: { label: "Caps Lock", column: "filterCapsEnabled" },
  spam: { label: "Spam", column: "filterSpamEnabled" },
  toxicidade: { label: "Toxicidade", column: "filterToxicityEnabled" },
};

// Cada categoria vira sua própria tela — nada de warn/mute/kick/ban
// misturados num único menu "Aplicar Ação".
const MOD_CATEGORIES = [
  { value: "warn", label: "Advertências", emoji: "⚠️", description: "Advertir e limpar advertências" },
  { value: "mute", label: "Mute", emoji: "🔇", description: "Mutar e desmutar membros" },
  { value: "kick", label: "Expulsão", emoji: "👢", description: "Expulsar um membro do servidor" },
  { value: "ban", label: "Banimento", emoji: "🔨", description: "Banir e desbanir membros" },
  { value: "historico", label: "Histórico", emoji: "📜", description: "Ver histórico de moderação de um membro" },
  { value: "filtros", label: "Filtros", emoji: "🧹", description: "Palavras, links, flood, caps, spam e toxicidade" },
] as const;

// Para onde o botão "Voltar" leva depois de escolher um membro (ou aplicar
// a ação), de acordo com o tipo — cada ação volta pra sua própria categoria.
const BACK_TARGETS: Record<string, string> = {
  warn: "adm-mod:cat:warn",
  clearwarns: "adm-mod:cat:warn",
  mute: "adm-mod:cat:mute",
  unmute: "adm-mod:cat:mute",
  kick: "adm-mod:cat:kick",
  ban: "adm-mod:cat:ban",
  historico: "adm-mod:menu",
};

const ACTION_LABELS: Record<string, string> = {
  warn: "Advertir",
  mute: "Mutar",
  kick: "Expulsar",
  ban: "Banir",
  unmute: "Desmutar",
  clearwarns: "Limpar Advertências",
  historico: "Ver Histórico",
};

function backRow(customId: string, label = "Voltar") {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(customId).setLabel(label).setStyle(ButtonStyle.Secondary)
  );
}

async function replyOrUpdate(
  interaction: ButtonInteraction | ModalSubmitInteraction | AnySelectMenuInteraction,
  payload: { attachments: [], embeds: EmbedBuilder[]; components: ActionRowBuilder<any>[] }
) {
  return refreshPanel(interaction,{content:null,...payload,allowedMentions:{parse:[]}});
}

export async function renderModerationMenu(interaction: any) {return renderMemberModeration(interaction);}

export async function renderWarnCategory(interaction: MessageComponentInteraction) {
  const embed = (await adminEmbed(interaction.guild!, "seguranca"))
    .setTitle("⚠️ Advertências")
    .setDescription("Aplique uma advertência ou limpe o histórico de advertências de um membro.");

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("adm-mod:pick:warn").setLabel("Advertir").setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId("adm-mod:pick:clearwarns").setLabel("Limpar Advertências").setStyle(ButtonStyle.Success)
  );

  await interaction.update({ attachments: [], embeds: [embed], components: [row, backRow("adm-mod:menu")] });
}

export async function renderMuteCategory(interaction: MessageComponentInteraction) {
  const embed = (await adminEmbed(interaction.guild!, "seguranca"))
    .setTitle("🔇 Mute")
    .setDescription("Mute ou desmute um membro do servidor.");

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("adm-mod:pick:mute").setLabel("Mutar").setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId("adm-mod:pick:unmute").setLabel("Desmutar").setStyle(ButtonStyle.Success)
  );

  await interaction.update({ attachments: [], embeds: [embed], components: [row, backRow("adm-mod:menu")] });
}

export async function renderKickCategory(interaction: MessageComponentInteraction) {
  const embed = (await adminEmbed(interaction.guild!, "seguranca"))
    .setTitle("👢 Expulsão")
    .setDescription("Expulsa um membro do servidor. Ele pode entrar novamente com um novo convite.");

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("adm-mod:pick:kick").setLabel("Expulsar").setStyle(ButtonStyle.Danger)
  );

  await interaction.update({ attachments: [], embeds: [embed], components: [row, backRow("adm-mod:menu")] });
}

export async function renderBanCategory(interaction: MessageComponentInteraction) {
  const embed = (await adminEmbed(interaction.guild!, "seguranca"))
    .setTitle("🔨 Banimento")
    .setDescription("Banir impede o retorno ao servidor até que o membro seja desbanido manualmente.");

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("adm-mod:pick:ban").setLabel("Banir").setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId("adm-mod:unban").setLabel("Desbanir").setStyle(ButtonStyle.Success)
  );

  await interaction.update({ attachments: [], embeds: [embed], components: [row, backRow("adm-mod:menu")] });
}

async function renderUserPicker(interaction: MessageComponentInteraction, type: string) {
  const label = ACTION_LABELS[type] ?? type;

  const embed = (await adminEmbed(interaction.guild!, "seguranca"))
    .setTitle(`⚖️ ${label}`)
    .setDescription("Selecione o membro abaixo.");

  const select = new UserSelectMenuBuilder()
    .setCustomId(`adm-mod-user-select:${type}`)
    .setPlaceholder(`Selecione o membro para: ${label}`)
    .setMinValues(1)
    .setMaxValues(1);

  const selectRow = new ActionRowBuilder<UserSelectMenuBuilder>().addComponents(select);

  await interaction.update({ attachments: [], embeds: [embed], components: [selectRow, backRow(BACK_TARGETS[type] ?? "adm-mod:menu")] });
}

async function openUnbanModal(interaction: ButtonInteraction) {
  const modal = new ModalBuilder().setCustomId("adm-modal:mod:unban").setTitle("Desbanir Membro");

  const userIdInput = new TextInputBuilder()
    .setCustomId("userId")
    .setLabel("ID do usuário")
    .setStyle(TextInputStyle.Short)
    .setPlaceholder("Ex: 123456789012345678")
    .setRequired(true)
    .setMinLength(15)
    .setMaxLength(25);

  const reasonInput = new TextInputBuilder()
    .setCustomId("reason")
    .setLabel("Motivo (opcional)")
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(false)
    .setMaxLength(300);

  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(userIdInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(reasonInput)
  );

  await interaction.showModal(modal);
}

// -----------------------------
// Filtros — hub + sub-seções
// -----------------------------
// Antes era uma única tela lotada (status + limites + monitoramento + 5
// fileiras de botão). Agora é um hub com 4 seções focadas, cada uma com
// seu próprio embed e botões relevantes só àquele assunto.
function filtersBackRow() {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("adm-mod:filtros").setLabel("Voltar aos Filtros").setStyle(ButtonStyle.Secondary)
  );
}

export async function renderFiltersMenu(
  interaction: ButtonInteraction | ModalSubmitInteraction | AnySelectMenuInteraction
) {
  const config = await getOrCreateGuildConfig(interaction.guild!.id);

  const activeCount = Object.values(FILTER_FIELDS).filter((v) => config[v.column]).length;
  const totalCount = Object.values(FILTER_FIELDS).length;
  const wordRules = await prisma.filterRule.count({ where: { guildId: interaction.guild!.id, type: FilterRuleType.WORD } });
  const linkRules = await prisma.filterRule.count({
    where: { guildId: interaction.guild!.id, type: FilterRuleType.LINK_WHITELIST },
  });

  const embed=adminEmbed(interaction.guild!,"seguranca").setTitle("Proteção automática")
    .setDescription("Configure na ordem: filtros → regras e limites → resposta às violações.")
    .addFields({name:"Filtros ativos",value:`${activeCount}/${totalCount} · ${Object.values(FILTER_FIELDS).filter(f=>config[f.column]).map(f=>f.label).join(", ")||"Nenhum"}`},
    {name:"Regras de conteúdo",value:`${wordRules} palavras bloqueadas · ${linkRules} domínios permitidos`},
    {name:"Resposta às violações",value:({DELETE_ONLY:"Apagar mensagem",WARN:"Apagar e advertir",MUTE:"Apagar e silenciar"} as Record<string,string>)[config.autoModAction]||config.autoModAction},
    {name:"Monitoramento de reintegração",value:`${config.wordWatchEnabled?"Ativado":"Desativado"} · observa e registra, sem punir.`});
  const me=interaction.guild!.members.me;
  if(me&&!me.permissions.has("ManageMessages"))embed.addFields({name:"Permissão pendente",value:"O bot precisa de Gerenciar Mensagens para apagar conteúdo. Ajuste a permissão do cargo e dos canais protegidos."});
  const row1 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("adm-mod:filtros:secao:toggles").setLabel("1. Escolher filtros").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("adm-mod:filtros:secao:conteudo").setLabel("2. Palavras e links").setStyle(ButtonStyle.Secondary)
  );

  const row2 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("adm-mod:filtros:secao:limites").setLabel("3. Limites e resposta").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("adm-mod:filtros:secao:wordwatch").setLabel("Monitoramento").setStyle(ButtonStyle.Secondary)
  );

  await replyOrUpdate(interaction, { attachments: [], embeds: [embed], components: [row1, row2, new ActionRowBuilder<ButtonBuilder>().addComponents(new ButtonBuilder().setCustomId("security:home").setLabel("Central de segurança").setStyle(ButtonStyle.Secondary)), backRow("adm-nav:seguranca")] });
}

// --- Seção 1: Filtros Automáticos (liga/desliga cada filtro) ---
async function renderFiltersToggles(
  interaction: ButtonInteraction | ModalSubmitInteraction | AnySelectMenuInteraction
) {
  const config = await getOrCreateGuildConfig(interaction.guild!.id);

  const statusLines = Object.entries(FILTER_FIELDS)
    .map(([, v]) => `**${v.label}:** ${config[v.column] ? "Ativado" : "Desativado"}`)
    .join("\n");

  const embed = (await adminEmbed(interaction.guild!, "seguranca"))
    .setTitle("🧩 Filtros Automáticos")
    .setDescription(`Altere um filtro para atualizar o estado nesta embed.\n\n${statusLines}\n\nPalavras: termos bloqueados. Links: endereços externos. Flood: muitas mensagens em sequência. Caps: excesso de maiúsculas. Spam: mensagens repetidas. Toxicidade: pontuação pelas regras do bot.`);

  const row1 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("adm-mod:filtros:toggle:palavras")
      .setLabel(`${config.filterWordsEnabled?"Desativar":"Ativar"} Palavras`)
      .setStyle(config.filterWordsEnabled ? ButtonStyle.Success : ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId("adm-mod:filtros:toggle:links")
      .setLabel(`${config.filterLinksEnabled?"Desativar":"Ativar"} Links`)
      .setStyle(config.filterLinksEnabled ? ButtonStyle.Success : ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId("adm-mod:filtros:toggle:flood")
      .setLabel(`${config.filterFloodEnabled?"Desativar":"Ativar"} Flood`)
      .setStyle(config.filterFloodEnabled ? ButtonStyle.Success : ButtonStyle.Danger)
  );

  const row2 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("adm-mod:filtros:toggle:caps")
      .setLabel(`${config.filterCapsEnabled?"Desativar":"Ativar"} Caps Lock`)
      .setStyle(config.filterCapsEnabled ? ButtonStyle.Success : ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId("adm-mod:filtros:toggle:spam")
      .setLabel(`${config.filterSpamEnabled?"Desativar":"Ativar"} Spam`)
      .setStyle(config.filterSpamEnabled ? ButtonStyle.Success : ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId("adm-mod:filtros:toggle:toxicidade")
      .setLabel(`${config.filterToxicityEnabled?"Desativar":"Ativar"} Toxicidade`)
      .setStyle(config.filterToxicityEnabled ? ButtonStyle.Success : ButtonStyle.Danger)
  );

  await replyOrUpdate(interaction, { attachments: [], embeds: [embed], components: [row1, row2, filtersBackRow()] });
}

// --- Seção 2: Palavras & Links (listas e modo de link) ---
async function renderFiltersContent(
  interaction: ButtonInteraction | ModalSubmitInteraction | AnySelectMenuInteraction
) {
  const config = await getOrCreateGuildConfig(interaction.guild!.id);
  const wordRules = await prisma.filterRule.findMany({
    where: { guildId: interaction.guild!.id, type: FilterRuleType.WORD },
  });
  const linkRules = await prisma.filterRule.findMany({
    where: { guildId: interaction.guild!.id, type: FilterRuleType.LINK_WHITELIST },
  });

  const embed = (await adminEmbed(interaction.guild!, "seguranca"))
    .setTitle("📝 Palavras & Links")
    .setDescription(
      `**Palavras proibidas (${wordRules.length}):** ${wordRules.length ? wordRules.map((r: { value: string }) => `\`${r.value}\``).join(", ") : "*nenhuma*"}\n\n` +
        `**Modo de links:** ${config.filterLinksMode === "WHITELIST" ? "Somente lista permitida" : "Bloquear todos"}\n` +
        `**Domínios permitidos (${linkRules.length}):** ${linkRules.length ? linkRules.map((r: { value: string }) => `\`${r.value}\``).join(", ") : "*nenhum*"}`
    );

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("adm-mod:filtros:palavras").setLabel("Editar Palavras").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("adm-mod:filtros:links").setLabel("Editar Links Permitidos").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("adm-mod:filtros:linkmode").setLabel("Alternar Modo de Links").setStyle(ButtonStyle.Secondary)
  );

  await replyOrUpdate(interaction, { attachments: [], embeds: [embed], components: [row, filtersBackRow()] });
}

// --- Seção 3: Limites & Ação (sensibilidade + ação automática) ---
async function renderFiltersLimits(
  interaction: ButtonInteraction | ModalSubmitInteraction | AnySelectMenuInteraction
) {
  const config = await getOrCreateGuildConfig(interaction.guild!.id);

  const embed = (await adminEmbed(interaction.guild!, "seguranca"))
    .setTitle("📐 Limites & Ação")
    .setDescription(
      `**Resposta ao violar um filtro:** ${{DELETE_ONLY:"Apagar mensagem",WARN:"Apagar e advertir",MUTE:"Apagar e silenciar"}[config.autoModAction]||config.autoModAction}\n\n` +
        "**Limites de conteúdo**\n" +
        `Caps: ${config.capsThreshold}% (mín. ${config.capsMinLength} caracteres)\n` +
        `Flood: ${config.floodMaxMessages} msgs / ${config.floodIntervalSeconds}s\n` +
        `Spam: ${config.spamMaxDuplicates} mensagens repetidas\n\n` +
        "**Limites de ação**\n" +
        `Toxicidade: score ≥ ${config.toxicityThreshold}\n` +
        `Mute automático: ${config.autoMuteDurationMinutes} min\n` +
        `Advertências p/ mute automático: ${config.maxWarnsBeforeMute || "desativado"}\n` +
        `Advertências p/ ban automático: ${config.maxWarnsBeforeBan || "desativado"}`
    );

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("adm-mod:filtros:limites1").setLabel("Limites de Conteúdo").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("adm-mod:filtros:limites2").setLabel("Limites de Ação").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("adm-mod:filtros:automod").setLabel("Escolher resposta").setStyle(ButtonStyle.Secondary)
  );

  await replyOrUpdate(interaction, { attachments: [], embeds: [embed], components: [row, filtersBackRow()] });
}

// --- Seção 4: Monitoramento de Palavras ---
async function renderFiltersWordWatch(
  interaction: ButtonInteraction | ModalSubmitInteraction | AnySelectMenuInteraction
) {
  const config = await getOrCreateGuildConfig(interaction.guild!.id);
  const watchChannels = getWordWatchChannelIds(config);
  const watchChannelsText = watchChannels.length
    ? watchChannels.map((id) => `<#${id}>`).join(", ")
    : "*nenhum canal selecionado*";

  const embed = (await adminEmbed(interaction.guild!, "seguranca"))
    .setTitle("🔎 Monitoramento de Palavras")
    .setDescription(
      `**Status:** ${config.wordWatchEnabled ? "✅ ativado" : "❌ desativado"}\n\n` +
        "Observa (sem apagar nem punir) apenas membros em reintegração ativa, " +
        "usando a mesma lista de Palavras Proibidas, e registra ocorrências no " +
        "histórico do membro.\n\n" +
        `**Canais observados (até ${MAX_WORD_WATCH_CHANNELS}):** ${watchChannelsText}`
    );

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("adm-mod:filtros:toggle:wordwatch")
      .setLabel(config.wordWatchEnabled ? "Desativar" : "Ativar")
      
      .setStyle(config.wordWatchEnabled ? ButtonStyle.Success : ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId("adm-mod:filtros:wordwatchchannels")
      .setLabel("Canais Monitorados")
      
      .setStyle(ButtonStyle.Secondary)
  );

  await replyOrUpdate(interaction, { attachments: [], embeds: [embed], components: [row, filtersBackRow()] });
}

async function toggleFilter(interaction: ButtonInteraction, key: string) {
  const field = FILTER_FIELDS[key];
  if (!field) return;

  await deferPanel(interaction);
  const config = await getOrCreateGuildConfig(interaction.guild!.id);
  const newValue = !config[field.column];

  await prisma.guildConfig.update({
    where: { guildId: interaction.guild!.id },
    data: { [field.column]: newValue } as Record<string, boolean>,
  });

  await logAdminAction({
    guild: interaction.guild!,
    actorId: interaction.user.id,
    action: AdminLogAction.MODERATION_CONFIG_CHANGED,
    details: `Filtro de ${field.label}: ${newValue ? "ativado" : "desativado"}`,
  });

  await renderFiltersToggles(interaction);
}

async function toggleWordWatch(interaction: ButtonInteraction) {
  await deferPanel(interaction);
  const config = await getOrCreateGuildConfig(interaction.guild!.id);
  const newValue = !config.wordWatchEnabled;

  await prisma.guildConfig.update({
    where: { guildId: interaction.guild!.id },
    data: { wordWatchEnabled: newValue },
  });

  await logAdminAction({
    guild: interaction.guild!,
    actorId: interaction.user.id,
    action: AdminLogAction.MODERATION_CONFIG_CHANGED,
    details: `Monitoramento de Palavras: ${newValue ? "ativado" : "desativado"}`,
  });

  await renderFiltersWordWatch(interaction);
}

export async function renderWordWatchChannelPicker(
  interaction: ButtonInteraction | ModalSubmitInteraction | AnySelectMenuInteraction
) {
  const config = await getOrCreateGuildConfig(interaction.guild!.id);
  const current = getWordWatchChannelIds(config);

  const embed = (await adminEmbed(interaction.guild!, "seguranca"))
    .setTitle("📡 Canais Monitorados")
    .setDescription(
      `Selecione até ${MAX_WORD_WATCH_CHANNELS} canais de texto para o Monitoramento de Palavras. ` +
        "Apenas mensagens enviadas nesses canais, por membros em reintegração ativa, são observadas.\n\n" +
        `**Atuais:** ${current.length ? current.map((id) => `<#${id}>`).join(", ") : "*nenhum*"}`
    );

  const select = new ChannelSelectMenuBuilder()
    .setCustomId("adm-watchchannel-select")
    .setPlaceholder(`Selecione até ${MAX_WORD_WATCH_CHANNELS} canais`)
    .addChannelTypes(ChannelType.GuildText)
    .setMinValues(0)
    .setMaxValues(MAX_WORD_WATCH_CHANNELS);
  const existing=current.filter(id=>interaction.guild!.channels.cache.has(id));
  if (existing.length) select.setDefaultChannels(existing);

  const selectRow = new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(select);

  await replyOrUpdate(interaction, { attachments: [], embeds: [embed], components: [selectRow, filtersBackRow()] });
}

async function toggleLinkMode(interaction: ButtonInteraction) {
  await deferPanel(interaction);
  const config = await getOrCreateGuildConfig(interaction.guild!.id);
  const newMode = config.filterLinksMode === "WHITELIST" ? "BLOCK_ALL" : "WHITELIST";

  await prisma.guildConfig.update({
    where: { guildId: interaction.guild!.id },
    data: { filterLinksMode: newMode },
  });

  await logAdminAction({
    guild: interaction.guild!,
    actorId: interaction.user.id,
    action: AdminLogAction.MODERATION_CONFIG_CHANGED,
    details: `Modo de links: ${newMode}`,
  });

  await renderFiltersContent(interaction);
}

async function cycleAutoModAction(interaction: any) {
  const config=await getOrCreateGuildConfig(interaction.guild.id);
  const select=new StringSelectMenuBuilder().setCustomId("adm-automod-select").setPlaceholder("Escolha a resposta às violações").addOptions(
    {label:"Apagar mensagem",value:AutoModAction.DELETE_ONLY,default:config.autoModAction===AutoModAction.DELETE_ONLY},
    {label:"Apagar e advertir",value:AutoModAction.WARN,default:config.autoModAction===AutoModAction.WARN},
    {label:"Apagar e silenciar",value:AutoModAction.MUTE,default:config.autoModAction===AutoModAction.MUTE});
  return refreshPanel(interaction,{content:null,attachments:[],embeds:[adminEmbed(interaction.guild,"seguranca").setTitle("Resposta às violações").setDescription("A escolha será salva automaticamente. Advertências podem acionar os limites de silêncio ou banimento configurados.")],components:[new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select),filtersBackRow()]});
}

async function openWordsModal(interaction: ButtonInteraction) {
  const rules = await prisma.filterRule.findMany({
    where: { guildId: interaction.guild!.id, type: FilterRuleType.WORD },
  });

  const modal = new ModalBuilder().setCustomId("adm-modal:mod:words").setTitle("Palavras Proibidas");

  const wordsInput = new TextInputBuilder()
    .setCustomId("words")
    .setLabel("Palavras (separadas por vírgula)")
    .setStyle(TextInputStyle.Paragraph)
    .setPlaceholder("palavrão1, palavrão2, palavrão3")
    .setValue(rules.length?rules.map((r: { value: string }) => r.value).join(", ").slice(0,1000):" ")
    .setRequired(false)
    .setMaxLength(1000);

  modal.addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(wordsInput));
  await interaction.showModal(modal);
}

async function openLinksModal(interaction: ButtonInteraction) {
  const rules = await prisma.filterRule.findMany({
    where: { guildId: interaction.guild!.id, type: FilterRuleType.LINK_WHITELIST },
  });

  const modal = new ModalBuilder().setCustomId("adm-modal:mod:links").setTitle("Domínios Permitidos");

  const domainsInput = new TextInputBuilder()
    .setCustomId("domains")
    .setLabel("Domínios (separados por vírgula)")
    .setStyle(TextInputStyle.Paragraph)
    .setPlaceholder("discord.com, youtube.com, tenor.com")
    .setValue(rules.length?rules.map((r: { value: string }) => r.value).join(", ").slice(0,1000):" ")
    .setRequired(false)
    .setMaxLength(1000);

  modal.addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(domainsInput));
  await interaction.showModal(modal);
}

async function openThresholds1Modal(interaction: ButtonInteraction) {
  const config = await getOrCreateGuildConfig(interaction.guild!.id);
  const modal = new ModalBuilder().setCustomId("adm-modal:mod:limites1").setTitle("Limites de Conteúdo");

  const fields: [string, string, string][] = [
    ["capsThreshold", "% de caixa alta para acionar", String(config.capsThreshold)],
    ["capsMinLength", "Tamanho mínimo p/ avaliar caps", String(config.capsMinLength)],
    ["floodMaxMessages", "Máx. mensagens (flood)", String(config.floodMaxMessages)],
    ["floodIntervalSeconds", "Intervalo do flood (segundos)", String(config.floodIntervalSeconds)],
    ["spamMaxDuplicates", "Mensagens repetidas = spam", String(config.spamMaxDuplicates)],
  ];

  modal.addComponents(
    ...fields.map(([id, label, value]) =>
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId(id)
          .setLabel(label)
          .setStyle(TextInputStyle.Short)
          .setValue(value)
          .setRequired(true)
          .setMaxLength(5)
      )
    )
  );

  await interaction.showModal(modal);
}

async function openThresholds2Modal(interaction: ButtonInteraction) {
  const config = await getOrCreateGuildConfig(interaction.guild!.id);
  const modal = new ModalBuilder().setCustomId("adm-modal:mod:limites2").setTitle("Limites de Ação");

  const fields: [string, string, string][] = [
    ["toxicityThreshold", "Score mínimo de toxicidade (0-100)", String(config.toxicityThreshold)],
    ["autoMuteDurationMinutes", "Duração do mute automático (min)", String(config.autoMuteDurationMinutes)],
    ["maxWarnsBeforeMute", "Advertências p/ mute automático (0=off)", String(config.maxWarnsBeforeMute)],
    ["maxWarnsBeforeBan", "Advertências p/ ban automático (0=off)", String(config.maxWarnsBeforeBan)],
  ];

  modal.addComponents(
    ...fields.map(([id, label, value]) =>
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId(id)
          .setLabel(label)
          .setStyle(TextInputStyle.Short)
          .setValue(value)
          .setRequired(true)
          .setMaxLength(6)
      )
    )
  );

  await interaction.showModal(modal);
}

export { renderUserPicker, renderFiltersToggles, renderFiltersContent, renderFiltersLimits, renderFiltersWordWatch };

const component: ButtonComponent = {
  customId: "adm-mod:",

  async execute(interaction: ButtonInteraction) {
    if (!interaction.guild) return;

    const member = await interaction.guild.members.fetch(interaction.user.id);
    if (!(await isBotAdmin(member))) {
      await interaction.reply({ content: "🚫 Você não tem permissão para acessar esta seção.", ephemeral: true });
      return;
    }

    const parts = interaction.customId.split(":"); // ["adm-mod", "acao", "sub?"]
    const action = parts[1];
    const sub = parts[2];

    switch (action) {
      case "menu":
        return renderModerationMenu(interaction);
      case "cat": {
        if (sub === "warn") return renderWarnCategory(interaction);
        if (sub === "mute") return renderMuteCategory(interaction);
        if (sub === "kick") return renderKickCategory(interaction);
        if (sub === "ban") return renderBanCategory(interaction);
        return renderModerationMenu(interaction);
      }
      case "unban":
        return openUnbanModal(interaction);
      case "pick":
        return renderUserPicker(interaction, sub);
      case "filtros": {
        if (!sub) return renderFiltersMenu(interaction);
        if (sub === "secao") {
          const section = parts[3];
          if (section === "toggles") return renderFiltersToggles(interaction);
          if (section === "conteudo") return renderFiltersContent(interaction);
          if (section === "limites") return renderFiltersLimits(interaction);
          if (section === "wordwatch") return renderFiltersWordWatch(interaction);
          return renderFiltersMenu(interaction);
        }
        if (sub === "toggle") {
          if (parts[3] === "wordwatch") return toggleWordWatch(interaction);
          return toggleFilter(interaction, parts[3]);
        }
        if (sub === "linkmode") return toggleLinkMode(interaction);
        if (sub === "automod") return cycleAutoModAction(interaction);
        if (sub === "palavras") return openWordsModal(interaction);
        if (sub === "links") return openLinksModal(interaction);
        if (sub === "limites1") return openThresholds1Modal(interaction);
        if (sub === "limites2") return openThresholds2Modal(interaction);
        if (sub === "wordwatchchannels") return renderWordWatchChannelPicker(interaction);
        return renderFiltersMenu(interaction);
      }
      default:
        return renderModerationMenu(interaction);
    }
  },
};

export default component;