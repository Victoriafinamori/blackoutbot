const { prepareAdminPanel } = require("../../utils/adminTasks");
import { ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageComponentInteraction } from "discord.js";
import { adminEmbed } from "../../utils/adminUi";

export async function renderEventsMenu(i: MessageComponentInteraction) {
  const embed = (await adminEmbed(i.guild!, "staff")).setColor(0xd71935).setTitle("Eventos de interação")
    .setDescription("Módulos para organizar eventos de interação sem substituir a brincadeira entre os membros.")
    .addFields(
      { name: "GAMES", value: "Base reutilizável para jogos em call e eventos sociais." },
      { name: "🍾 Verdade ou Desafio • Modo Híbrido", value: "Use `/verdade` no canal do evento. O bot controla participantes, sorteio, fontes das rodadas e atualiza sempre a mesma embed." },
      { name: "Game Musical", value: "Participação por botão, sorteio do participante e roleta de gênero musical." },
      { name: "Quiz em equipes", value: "Inscrições por time, perguntas e placar. Configuração acessível pelo botão abaixo." },
      { name: "Permissão para iniciar", value: "Administradores do bot ou membros com permissão **Gerenciar Eventos**." },
      { name: "Organização", value: "Prepare o jogo musical, Verdade ou Desafio ou o quiz em equipes." },
    );
  await i.update(prepareAdminPanel(i.guild, 'eventos', { attachments: [], embeds: [embed], components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("adm-event-info:truth").setLabel("Como usar").setEmoji("🍾").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("music-admin:menu").setLabel("Game Musical").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("games-admin:war").setLabel("Quiz em equipes").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("adm-event-info:back").setLabel("Voltar").setStyle(ButtonStyle.Secondary),
  )] }));
}
