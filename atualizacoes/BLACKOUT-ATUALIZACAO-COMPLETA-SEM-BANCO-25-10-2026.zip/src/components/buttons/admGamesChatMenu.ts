const { prepareAdminPanel } = require("../../utils/adminTasks");
import {
  ActionRowBuilder,
  AnySelectMenuInteraction,
  ButtonBuilder,
  ButtonStyle,
  ChannelSelectMenuBuilder,
  ChannelType,
  Guild,
  StringSelectMenuBuilder,
} from "discord.js";
import { adminEmbed } from "../../utils/adminUi";
import {
  gamesConfig,
  mysteryConfig,
  termoConfig,
} from "../../games-chat/core/config";
import { prisma } from "../../database/prisma";

const navigation = (selected?: string) =>
  new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId("adm-games-select:navigation")
      .setPlaceholder("Selecione um jogo para configurar")
      .addOptions(
        {
          label: "Voltar",
          value: "back",
          description: "Voltar para a categoria STAFF",
        },
        {
          label: "Visão geral",
          value: "home",
          description: "Resumo dos Games de Chat",
          default: selected === "home",
        },
        {
          label: "Caixa Misteriosa",
          value: "mystery",
          description: "Evento, caixas e recompensas",
          default: selected === "mystery",
        },
        {
          label: "TERMO Diário",
          value: "termo",
          description: "Palavras, painel e ranking",
          default: selected === "termo",
        },
      ),
  );

export async function gamesChatHome(guild: Guild) {
  const [general, mystery, termo, rewards, words] = await Promise.all([
    gamesConfig(guild.id),
    mysteryConfig(guild.id),
    termoConfig(guild.id),
    prisma.mysteryReward.count({ where: { guildId: guild.id, active: true } }),
    prisma.termoWord.count({
      where: { OR: [{ guildId: null }, { guildId: guild.id }], active: true },
    }),
  ]);
  const embed = (await adminEmbed(guild, "staff"))
    .setTitle("Games de Chat")
    .setDescription(
      "Cada jogo possui sua própria página. Selecione abaixo o que deseja configurar.",
    )
    .addFields(
      {
        name: "Configurações gerais",
        value: `Sistema: **${general.enabled ? "Ativo" : "Inativo"}**\nCanal de logs: ${general.logChannelId ? `<#${general.logChannelId}>` : "Não configurado"}`,
      },
      {
        name: "Caixa Misteriosa",
        value: `${mystery.enabled ? "Ativa" : "Desativada"} · ${rewards} recompensa(s) ativa(s)`,
        inline: true,
      },
      {
        name: "TERMO Diário",
        value: `${termo.enabled ? "Ativo" : "Desativado"} · ${words} palavra(s)`,
        inline: true,
      },
    );
  const logs = new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(
    new ChannelSelectMenuBuilder()
      .setCustomId("adm-games-channel:logs")
      .setPlaceholder("Definir canal de logs dos jogos")
      .setChannelTypes(ChannelType.GuildText),
  );
  return {
    attachments: [],
    embeds: [embed],
    components: [
      navigation("home"),
      logs,
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder()
          .setCustomId("games-admin:home")
          .setLabel("Painel de participação e resultados")
          .setStyle(ButtonStyle.Primary),
      ),
    ],
  };
}

export async function mysteryAdminView(guild: Guild) {
  const [config, rewards, active] = await Promise.all([
    mysteryConfig(guild.id),
    prisma.mysteryReward.count({ where: { guildId: guild.id, active: true } }),
    prisma.mysteryEvent.findFirst({
      where: { guildId: guild.id, status: "ACTIVE" },
    }),
  ]);
  const embed = (await adminEmbed(guild, "staff"))
    .setTitle("Games de Chat — Caixa Misteriosa")
    .setDescription("Configure o painel, as regras e depois inicie o evento.")
    .addFields(
      {
        name: "Estado",
        value: `Sistema: **${config.enabled ? "Ativo" : "Desativado"}**\nEvento atual: **${active ? "Em andamento" : "Nenhum"}**\nCanal: ${config.eventChannelId ? `<#${config.eventChannelId}>` : "Não configurado"}`,
      },
      {
        name: "Regras",
        value: `Caixas: **${config.boxCount}**\nDuração: **${Math.ceil(config.durationSeconds / 60)} min**\nParticipantes: **${config.maxParticipants ?? "Sem limite"}**\nDistribuição: **${config.distributionMode === "PREASSIGNED" ? "Pré-definida" : "Por peso ao abrir"}**`,
      },
      {
        name: "Recompensas",
        value: `**${rewards}** recompensa(s) ativa(s). Use os botões abaixo para cadastrar ou consultar.`,
      },
    );
  const channel =
    new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(
      new ChannelSelectMenuBuilder()
        .setCustomId("adm-games-channel:mystery")
        .setPlaceholder("Definir canal da Caixa Misteriosa")
        .setChannelTypes(ChannelType.GuildText),
    );
  const buttons = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("adm-games-action:mystery-toggle")
      .setLabel(config.enabled ? "Desativar" : "Ativar")
      .setStyle(config.enabled ? ButtonStyle.Secondary : ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId("adm-games-action:mystery-settings")
      .setLabel("Regras do jogo")
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId("adm-games-action:mystery-start")
      .setLabel("Iniciar evento")
      .setStyle(ButtonStyle.Success)
      .setDisabled(!config.enabled || !config.eventChannelId || !!active),
    new ButtonBuilder()
      .setCustomId("adm-games-action:mystery-end")
      .setLabel("Encerrar evento")
      .setStyle(ButtonStyle.Danger)
      .setDisabled(!active),
  );
  const rewardsRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("adm-games-action:mystery-reward-add")
      .setLabel("Cadastrar recompensa")
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId("adm-games-action:mystery-rewards")
      .setLabel("Ver recompensas")
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId("adm-games-action:mystery-reward-delete")
      .setLabel("Excluir recompensa")
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId("adm-games-action:mystery-winner")
      .setLabel("Mensagem do ganhador")
      .setStyle(ButtonStyle.Primary),
  );
  return {
    attachments: [],
    embeds: [embed],
    components: [navigation("mystery"), channel, buttons, rewardsRow],
  };
}

export async function termoAdminView(guild: Guild) {
  const [config, words, round] = await Promise.all([
    termoConfig(guild.id),
    prisma.termoWord.count({
      where: { OR: [{ guildId: null }, { guildId: guild.id }], active: true },
    }),
    prisma.termoRound.findFirst({
      where: { guildId: guild.id, status: "ACTIVE" },
      orderBy: { startedAt: "desc" },
    }),
  ]);
  const embed = (await adminEmbed(guild, "staff"))
    .setTitle("Games de Chat — TERMO Diário")
    .setDescription(
      "Configure o jogo diário sem expor a palavra atual. Mudanças de tamanho e tentativas valem para a próxima palavra.",
    )
    .addFields(
      {
        name: "Estado",
        value: `Sistema: **${config.enabled ? "Ativo" : "Desativado"}**\nCanal: ${config.channelId ? `<#${config.channelId}>` : "Não configurado"}\nPainel publicado: **${config.messageId ? "Sim" : "Não"}**`,
      },
      {
        name: "Regras",
        value: `Tamanho: **${config.wordLength} letras**\nTentativas: **${config.maxAttempts}**\nRepetição após: **${config.repeatAfterDays} dias**\nPalavras disponíveis: **${words}**`,
      },
      {
        name: "Rodada",
        value: round
          ? `Ativa até <t:${Math.floor(round.endsAt.getTime() / 1000)}:R>`
          : "Será criada ao publicar o painel.",
      },
      {
        name: "Banco de palavras",
        value:
          "Use os botões abaixo para adicionar ou consultar palavras. O painel nunca mostra a resposta vigente.",
      },
    );
  const channel =
    new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(
      new ChannelSelectMenuBuilder()
        .setCustomId("adm-games-channel:termo")
        .setPlaceholder("Definir canal do TERMO")
        .setChannelTypes(ChannelType.GuildText),
    );
  const buttons = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("adm-games-action:termo-toggle")
      .setLabel(config.enabled ? "Desativar" : "Ativar")
      .setStyle(config.enabled ? ButtonStyle.Secondary : ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId("adm-games-action:termo-settings")
      .setLabel("Regras do jogo")
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId("adm-games-action:termo-publish")
      .setLabel("Publicar/Atualizar painel")
      .setStyle(ButtonStyle.Success)
      .setDisabled(!config.enabled || !config.channelId),
  );
  const wordsRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("adm-games-action:termo-word-add")
      .setLabel("Adicionar palavra")
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId("adm-games-action:termo-words")
      .setLabel("Ver banco de palavras")
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId("adm-games-action:termo-ranking")
      .setLabel("Ver ranking")
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId("adm-games-action:termo-appearance")
      .setLabel("Mensagem e prévia")
      .setStyle(ButtonStyle.Secondary),
  );
  return {
    attachments: [],
    embeds: [embed],
    components: [navigation("termo"), channel, buttons, wordsRow],
  };
}

export async function renderGamesChatMenu(i: AnySelectMenuInteraction) {
  if (i.guild)
    await i.update(
      prepareAdminPanel(i.guild, "gameschat", await gamesChatHome(i.guild)),
    );
}
