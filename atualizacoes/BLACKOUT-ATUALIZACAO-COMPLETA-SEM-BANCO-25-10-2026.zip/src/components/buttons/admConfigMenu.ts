import { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, MessageComponentInteraction, ModalBuilder, PermissionFlagsBits, RoleSelectMenuBuilder, TextInputBuilder, TextInputStyle } from "discord.js";
import { ButtonComponent } from "../../structures/types";
import { isBotAdmin } from "../../utils/permissions";
import { adminEmbed } from "../../utils/adminUi";
import { getOrCreateGuildConfig } from "../../database/guildConfig";
import { prisma } from "../../database/prisma";
import { logAdminAction } from "../../utils/adminLog";
import { AdminLogAction } from "../../structures/enums";
import { buildAdmSectionPanel } from "../../utils/admPanel";
import { autoRoleIssues } from "../../utils/configurationChecks";
import { deferPanel, refreshPanel } from "../../utils/panelInteraction";
import { normalizeHex } from "../../utils/customEmbeds";
import { renderEmbedHub } from "./admEmbedV2Menu";
import { renderLogsMenu, renderLogChannelPicker } from "./admLogsMenu";
import { renderNotificationPanel } from "./admNotifications";

const button = (id: string, label: string, style = ButtonStyle.Secondary) => new ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style);
const row = (...items: ButtonBuilder[]) => new ActionRowBuilder<ButtonBuilder>().addComponents(items);
export async function renderConfigMenu(interaction: any) {
  return refreshPanel(interaction, await buildAdmSectionPanel(interaction.guild, "sistema"));
}
export async function renderConfigDestination(interaction: any, action: string) {
  switch (action) {
    case "aparencia": return renderAppearanceMenu(interaction);
    case "padrao": return renderDefaultPattern(interaction);
    case "embeds": return renderEmbedHub(interaction);
    case "autocargo": return require("../../message-maker/navigation").automations(interaction);
    // Existing messages still resolve to the new owners of these settings.
    case "canais": return renderLogsMenu(interaction);
    case "notificacoes": return renderNotificationPanel(interaction, "moderacao");
    default: return renderConfigMenu(interaction);
  }
}
export async function buildAppearancePayload(guild: NonNullable<MessageComponentInteraction["guild"]>, _requesterId?: string, updatedMember?: any) {
  const me = updatedMember ?? await guild.members.fetchMe({ force: true });
  const bot = guild.client.user;
  const name = me?.displayName || bot?.username || "Bot";
  const avatar = me?.displayAvatarURL?.({ size: 256 }) || bot?.displayAvatarURL({ size: 256 });
  const banner = me?.displayBannerURL?.({ size: 1024 }) || null;
  const embed = new EmbedBuilder().setColor(0xd71935).setTitle(name.slice(0, 256))
    .setDescription(`Perfil do bot em **${guild.name}**.\nNome, avatar e banner são personalizados somente nesta comunidade.`)
    .setFooter({ text: "Perfil neste servidor · Atualizado ao salvar" });
  embed.setAuthor({ name: name.slice(0, 256), ...(avatar ? { iconURL: avatar } : {}) });
  if (avatar) embed.setThumbnail(avatar);
  if (banner) embed.setImage(banner);
  return { content: "**Personalização do bot · Perfil neste servidor**", attachments: [], embeds: [embed],
    components: [row(button("appearance-edit:nickname", "Editar nome"), button("appearance-edit:avatar", "Editar avatar"), button("appearance-edit:banner", "Editar banner")), row(button("adm-cfg:menu", "Voltar"))], allowedMentions: { parse: [] as never[] } };
}
export async function renderAppearanceMenu(interaction: any) {
  await deferPanel(interaction);
  return refreshPanel(interaction, await buildAppearancePayload(interaction.guild, interaction.user.id));
}
export async function buildDefaultPatternPayload(guild: NonNullable<MessageComponentInteraction["guild"]>) {
  const config = await getOrCreateGuildConfig(guild.id);
  const embed = new EmbedBuilder().setColor(`#${normalizeHex(config.embedColor, "D71935")}` as `#${string}`)
    .setTitle("Prévia do padrão das mensagens").setDescription("As mensagens que usam o padrão deste servidor seguem esta cor, autor, miniatura e rodapé.\n\nOs modelos personalizados podem ter seu próprio visual.");
  if (config.embedAuthor) embed.setAuthor({ name: config.embedAuthor });
  if (config.embedFooter) embed.setFooter({ text: config.embedFooter });
  if (config.embedThumbnail) embed.setThumbnail(config.embedThumbnail);
  return { content: "**Personalização do bot · Padrão das mensagens**\nAs alterações salvas aparecem nesta mesma embed. Os menus administrativos mantêm a identidade BLACKOUT.", attachments: [], embeds: [embed],
    components: [row(button("adm-cfg:embeds-default", "Editar padrão", ButtonStyle.Primary)), row(button("adm-cfg:menu", "Voltar"))], allowedMentions: { parse: [] as never[] } };
}
export async function renderDefaultPattern(interaction: any) {
  return refreshPanel(interaction, await buildDefaultPatternPayload(interaction.guild));
}
async function openEmbedModal(interaction: any) {
  const config = await getOrCreateGuildConfig(interaction.guild.id);
  const input = (id: string, label: string, value: string | null, max: number, required = false) => {
    const field = new TextInputBuilder().setCustomId(id).setLabel(label).setStyle(TextInputStyle.Short).setRequired(required).setMaxLength(max);
    if (value) field.setValue(value);
    return new ActionRowBuilder<TextInputBuilder>().addComponents(field);
  };
  await interaction.showModal(new ModalBuilder().setCustomId("adm-modal:embed").setTitle("Padrão das mensagens").addComponents(
    input("embedColor", "Cor hexadecimal", normalizeHex(config.embedColor, "D71935"), 7, true),
    input("embedAuthor", "Autor — vazio para remover", config.embedAuthor, 256),
    input("embedFooter", "Rodapé — vazio para remover", config.embedFooter, 1000),
    input("embedThumbnail", "URL da miniatura — vazio para remover", config.embedThumbnail, 500)));
}
export async function renderAutoRoleMenu(interaction: any, notice?: string) {
  const guild = interaction.guild;
  const config = await getOrCreateGuildConfig(guild.id);
  const ids = (config.autoRoleIds ?? "").split(",").map((id: string) => id.trim()).filter(Boolean);
  const issues = autoRoleIssues(guild, ids);
  const me = guild.members.me ?? await guild.members.fetchMe();
  const canManage = me?.permissions?.has(PermissionFlagsBits.ManageRoles) ?? false;
  const embed = adminEmbed(guild, "membros").setTitle("Cargos e automações")
    .setDescription("Escolha os cargos atribuídos aos novos membros. Alterar a lista não modifica quem já está no servidor.")
    .addFields({ name: "Estado atual", value: config.autoRoleEnabled ? "Ativado" : "Desativado", inline: true },
      { name: "Cargos selecionados", value: ids.map((id: string) => guild.roles.cache.has(id) ? `<@&${id}>` : "Cargo removido").join(", ") || "Nenhum cargo selecionado." });
  if (issues.length || !canManage) embed.addFields({ name: "Ajustes necessários", value: [...(!canManage ? ["O bot precisa da permissão Gerenciar Cargos."] : []), ...issues].join("\n").slice(0,1024) });
  if (notice) embed.addFields({ name: "Resultado", value: notice.slice(0,1024) });
  const select = new RoleSelectMenuBuilder().setCustomId("auto-role-select:roles").setPlaceholder("Selecionar cargos de entrada").setMinValues(0).setMaxValues(10);
  const existing = ids.filter((id: string) => guild.roles.cache.has(id));
  if (existing.length) select.setDefaultRoles(existing);
  return refreshPanel(interaction, { content: null, attachments: [], embeds: [embed], components: [new ActionRowBuilder<RoleSelectMenuBuilder>().addComponents(select),
    row(button("adm-cfg:autocargo-toggle", config.autoRoleEnabled ? "Desativar" : "Ativar cargos automáticos", config.autoRoleEnabled ? ButtonStyle.Secondary : ButtonStyle.Primary).setDisabled(!config.autoRoleEnabled && (!ids.length || !!issues.length || !canManage)), button("adm-cfg:autocargo-clear", "Limpar seleção").setDisabled(!ids.length)),
    row(button("adm-roletransfer:menu", "Transferência programada"), button("maker:r-home:0", "Cargos por reação")), row(button("adm-nav:membros", "Voltar"))] });
}
async function updateAutoRole(interaction: any, action: "toggle" | "clear") {
  const config = await getOrCreateGuildConfig(interaction.guild.id);
  const ids = (config.autoRoleIds ?? "").split(",").filter(Boolean);
  if (action === "toggle" && !config.autoRoleEnabled) {
    const me = interaction.guild.members.me ?? await interaction.guild.members.fetchMe();
    if (!ids.length || autoRoleIssues(interaction.guild, ids).length || !me.permissions.has(PermissionFlagsBits.ManageRoles)) return renderAutoRoleMenu(interaction, "Revise os cargos e as permissões antes de ativar.");
  }
  await deferPanel(interaction);
  await prisma.guildConfig.update({ where: { guildId: interaction.guild.id }, data: action === "clear" ? { autoRoleIds: null, autoRoleEnabled: false } : { autoRoleEnabled: !config.autoRoleEnabled } });
  await logAdminAction({ guild: interaction.guild, actorId: interaction.user.id, action: AdminLogAction.CONFIG_CHANGED, details: action === "clear" ? "Cargos automáticos: seleção limpa e sistema desativado" : `Cargos automáticos: ${config.autoRoleEnabled ? "desativado" : "ativado"}` });
  return renderAutoRoleMenu(interaction, "Alteração salva neste servidor.");
}
const component: ButtonComponent = { customId: "adm-cfg:", async execute(i) {
  if (!i.guild) return;
  if (!await isBotAdmin(await i.guild.members.fetch(i.user.id))) return void await i.reply({ content: "Você não possui permissão para alterar estas configurações.", ephemeral: true });
  const [, action, sub] = i.customId.split(":");
  if (action === "embeds-default") return openEmbedModal(i);
  if (action === "autocargo-toggle") return updateAutoRole(i, "toggle");
  if (action === "autocargo-clear") return updateAutoRole(i, "clear");
  if (action === "canal") return sub === "reports" ? renderNotificationPanel(i, "moderacao") : renderLogChannelPicker(i, sub === "log" ? "geral" : sub);
  return renderConfigDestination(i, action);
} };
export default component;
