import { ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } from 'discord.js';
import { prisma } from '../../database/prisma';
import { regConfig } from '../../utils/registration';
import { registrationAdminPayload, registrationIssues, renderRegistrationAdmin } from '../../utils/registrationAdmin';
import { isBotAdmin } from '../../utils/permissions';
import { deferPanel, refreshPanel } from '../../utils/panelInteraction';
const component={customId:'registration-ui:',async execute(i:any){
  if(!i.guild||!await isBotAdmin(await i.guild.members.fetch(i.user.id)))return;
  const action=i.customId.slice('registration-ui:'.length),c=await regConfig(i.guild.id);
  if(action.startsWith('page-edit:')){
    const p=await prisma.registrationPage.findFirst({where:{id:action.slice(10),guildId:i.guild.id}});if(!p)return;
    const input=(id:string,label:string,value:string,required=true)=>new ActionRowBuilder<TextInputBuilder>().addComponents(new TextInputBuilder().setCustomId(id).setLabel(label).setValue(value).setMaxLength(id==='description'?2000:256).setStyle(id==='description'?TextInputStyle.Paragraph:TextInputStyle.Short).setRequired(required));
    return i.showModal(new ModalBuilder().setCustomId(`adm-reg-page:${p.id}`).setTitle('Editar pergunta').addComponents(input('name','Nome da página',p.name),input('question','Pergunta',p.question),input('description','Descrição opcional',p.description||'',false),input('max','Máximo de escolhas · 1 a 20',String(p.maxChoices)),input('required','Resposta obrigatória? SIM ou NÃO',p.required?'SIM':'NÃO')));
  }
  if(action.startsWith('page-up:')||action.startsWith('page-down:')){
    const [direction,id]=action.split(':'),pages=await prisma.registrationPage.findMany({where:{guildId:i.guild.id},orderBy:{order:'asc'}}),index=pages.findIndex(p=>p.id===id),target=index+(direction==='page-up'?-1:1);
    if(index<0||target<0||target>=pages.length)return;
    await deferPanel(i);const p=pages[index],other=pages[target],sourceOrder=p.order,targetOrder=other.order,temporary=Math.max(...pages.map(x=>x.order))+1;
    await prisma.$transaction(async tx=>{await tx.registrationPage.update({where:{id:p.id},data:{order:temporary}});await tx.registrationPage.update({where:{id:other.id},data:{order:sourceOrder}});await tx.registrationPage.update({where:{id:p.id},data:{order:targetOrder}})});
    return refreshPanel(i,await require('../../utils/registrationPageAdmin').registrationPageManagerPayload(i.guild,p.id));
  }
  if(action==='toggle'){
    const pages=await prisma.registrationPage.findMany({where:{guildId:i.guild.id}});
    if(!c.enabled&&registrationIssues(c,pages).length)return i.reply({content:'Revise as pendências antes de ativar. Use Resolver pendências na visão geral.',ephemeral:true});
    await deferPanel(i);await prisma.registrationConfig.update({where:{guildId:i.guild.id},data:{enabled:!c.enabled}});return renderRegistrationAdmin(i);
  }
  if(action==='external'){
    if(!c.externalEnabled&&(!c.externalGuildId||!c.externalChannelId))return i.reply({content:'Configure o servidor e o canal externo antes de ativar o envio.',ephemeral:true});
    await deferPanel(i);await prisma.registrationConfig.update({where:{guildId:i.guild.id},data:{externalEnabled:!c.externalEnabled}});return renderRegistrationAdmin(i,'logs');
  }
  const views=['home','pending','messages','team','logs','roles','tools','publication','internal','preview-panel','preview-internal','welcome'];
  if(views.includes(action)){await deferPanel(i);return renderRegistrationAdmin(i,action)}
}};
export default component;
