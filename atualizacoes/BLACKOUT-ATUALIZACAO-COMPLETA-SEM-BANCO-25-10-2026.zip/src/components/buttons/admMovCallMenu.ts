const { prepareAdminPanel } = require("../../utils/adminTasks");
import { adminBackRow } from "../../utils/admPanel";
import {
  ButtonInteraction,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelSelectMenuBuilder,
  ChannelType,
  RoleSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} from "discord.js";
import { ButtonComponent } from "../../structures/types";
import { isBotAdmin } from "../../utils/permissions";
import { adminEmbed } from "../../utils/adminUi";
import { logAdminAction } from "../../utils/adminLog";
import { AdminLogAction, MovStatType, PermissionType } from "../../structures/enums";
import { getRanking, formatDuration } from "../../utils/movStats";
import { prisma } from "../../database/prisma";
import {
  getGuildConfigForMovCall,
  getMovCallCategoryIds,
  MAX_MOV_CALL_CATEGORIES,
  toggleMovCallSystem,
  toggleMovCallCountMuted,
  toggleMovCallRanking,
  computeNextMovCallResetAt,
  resetMovCallStats,
  getMovCallRewards,
  recoverActiveCallSessions,
  clearActiveCallSessions,
  refreshCallRankingMessage,
} from "../../utils/movCallStats";

function backRow(customId: string, label = "Voltar") {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(customId).setLabel(label).setStyle(ButtonStyle.Secondary)
  );
}

// Várias telas aqui são chamadas tanto por botões quanto por selects de canal
// e cargo (e, no caso do intervalo/recompensas, por submits de modal) — por
// isso o tipo "any", igual ao padrão já usado em admMovMenu.ts.

// -----------------------------
// 📞 Raiz do Mov.Call
// -----------------------------
export async function renderMovCallRoot(interaction: any) {
  const config = await getGuildConfigForMovCall(interaction.guild!.id);

  const embed = (await adminEmbed(interaction.guild!, "servidor"))
    .setTitle("📞 Mov.Call")
    .setDescription(
      "Sistema completo de monitoramento de atividade em canais de voz.\n\n" +
        `**Status do sistema:** ${config.movCallSystemEnabled ? "✅ Ativado" : "❌ Desativado"}\n\n` +
        "⚙️ **Configurações** — status, tempo mutado, categorias e cargos com permissão\n" +
        "🏆 **Top Call** — ranking, canal, cargo do 1º lugar e recompensas por tempo\n" +
        "📊 **Estatísticas** — acompanhe a atividade dos membros em call"
    );

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("adm-movcall:config").setLabel("Configurações").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("adm-movcall:topcall").setLabel("Top Call").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("adm-movcall:stats").setLabel("Estatísticas").setStyle(ButtonStyle.Secondary)
  );

  await interaction.update(prepareAdminPanel(interaction.guild, 'movcall', { attachments: [], embeds: [embed], components: [row, backRow("adm-nav:servidor")] }));
}

// -----------------------------
// ⚙️ Configurações
// -----------------------------
export async function renderMovCallConfigMenu(interaction: any) {
  const config = await getGuildConfigForMovCall(interaction.guild!.id);
  const categories = getMovCallCategoryIds(config);

  const embed = (await adminEmbed(interaction.guild!, "servidor"))
    .setTitle("⚙️ Mov.Call — Configurações")
    .setDescription("ℹ️ **Informações**")
    .addFields(
      { name: "Status", value: config.movCallSystemEnabled ? "🟢 `Ativado`" : "🔴 `Desativado`", inline: true },
      { name: "Contar Tempo Mutado", value: config.movCallCountMuted ? "🟢 `Ativado`" : "🔴 `Desativado`", inline: true },
      {
        name: "📂 Categorias Monitoradas",
        value: categories.length ? categories.map((id: string) => `<#${id}>`).join(", ") : "*nenhuma selecionada*",
      },
      {
        name: "👮 Observações",
        value: "Defina os **cargos com permissão** para usar `/tempocall`, `/rankingcall` e `/callinfo` em outros membros.",
      }
    );

  const row1 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("adm-movcall:togglesystem")
      .setLabel(config.movCallSystemEnabled ? "Desativar Sistema" : "Ativar Sistema")
      
      .setStyle(config.movCallSystemEnabled ? ButtonStyle.Danger : ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId("adm-movcall:togglemuted")
      .setLabel(config.movCallCountMuted ? "Não Contar Mutado" : "Contar Mutado")
      
      .setStyle(config.movCallCountMuted ? ButtonStyle.Danger : ButtonStyle.Success)
  );

  const row2 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("adm-movcall:categories").setLabel("Categorias Monitoradas").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("adm-movcall:permroles").setLabel("Cargos com Permissão").setStyle(ButtonStyle.Secondary)
  );

  await interaction.update({ attachments: [], embeds: [embed], components: [row1, row2, backRow("adm-movcall:root")] });
}

async function toggleSystem(interaction: ButtonInteraction) {
  const next = await toggleMovCallSystem(interaction.guild!.id);
  if (next) await recoverActiveCallSessions(interaction.guild!);
  else await clearActiveCallSessions(interaction.guild!.id);
  await logAdminAction({
    guild: interaction.guild!,
    actorId: interaction.user.id,
    action: AdminLogAction.MOVCALL_CONFIG_CHANGED,
    details: `Status do Sistema: ${next ? "ativado" : "desativado"}`,
  });
  await renderMovCallConfigMenu(interaction);
}

async function toggleCountMuted(interaction: ButtonInteraction) {
  const next = await toggleMovCallCountMuted(interaction.guild!.id);
  await logAdminAction({
    guild: interaction.guild!,
    actorId: interaction.user.id,
    action: AdminLogAction.MOVCALL_CONFIG_CHANGED,
    details: `Contabilizar Tempo Mutado: ${next ? "ativado" : "desativado"}`,
  });
  await renderMovCallConfigMenu(interaction);
}

async function renderCategoriesPicker(interaction: ButtonInteraction) {
  const config = await getGuildConfigForMovCall(interaction.guild!.id);
  const current = getMovCallCategoryIds(config);

  const embed = (await adminEmbed(interaction.guild!, "servidor"))
    .setTitle("📂 Categorias Monitoradas")
    .setDescription(
      `Selecione até ${MAX_MOV_CALL_CATEGORIES} categorias do Discord. Qualquer canal de voz dentro delas conta tempo no Mov.Call.`
    );

  const select = new ChannelSelectMenuBuilder()
    .setCustomId("adm-movcallcategory-select")
    .setPlaceholder(`Selecione até ${MAX_MOV_CALL_CATEGORIES} categorias`)
    .addChannelTypes(ChannelType.GuildCategory)
    .setMinValues(0)
    .setMaxValues(MAX_MOV_CALL_CATEGORIES);
  if (current.length) select.setDefaultChannels(current);

  const selectRow = new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(select);
  await interaction.update({ attachments: [], embeds: [embed], components: [selectRow, backRow("adm-movcall:config")] });
}

async function renderPermRolesPicker(interaction: ButtonInteraction) {
  const roles = await prisma.permissionRole.findMany({
    where: { guildId: interaction.guild!.id, type: PermissionType.MOVCALL_COMMANDS },
    select: { roleId: true },
  });

  const embed = (await adminEmbed(interaction.guild!, "servidor"))
    .setTitle("👮 Cargos com Permissão")
    .setDescription(
      "Cargos que poderão usar `/tempocall @membro`, `/rankingcall` e `/callinfo @membro`.\n\n" +
        `**Atuais:** ${roles.length ? roles.map((r: { roleId: string }) => `<@&${r.roleId}>`).join(", ") : "*nenhum cadastrado*"}`
    );

  const select = new RoleSelectMenuBuilder()
    .setCustomId("adm-role-select:movcallperm")
    .setPlaceholder("Selecione os cargos autorizados")
    .setMinValues(0)
    .setMaxValues(10);
  if (roles.length) select.setDefaultRoles(roles.map((r: { roleId: string }) => r.roleId));

  const selectRow = new ActionRowBuilder<RoleSelectMenuBuilder>().addComponents(select);
  await interaction.update({ attachments: [], embeds: [embed], components: [selectRow, backRow("adm-movcall:config")] });
}

// -----------------------------
// 🏆 Top Call
// -----------------------------
export async function renderMovCallTopCallMenu(interaction: any) {
  const config = await getGuildConfigForMovCall(interaction.guild!.id);
  const nextReset = computeNextMovCallResetAt(config);
  const rewards = await getMovCallRewards(interaction.guild!.id);

  const embed = (await adminEmbed(interaction.guild!, "servidor"))
    .setTitle("🏆 Top Call")
    .setDescription(
      `**🟢 Status do Ranking:** ${config.movCallRankingEnabled ? "✅ Ativado" : "❌ Desativado"}\n` +
        `**🔄 Período de Reset:** ${
          config.movCallResetIntervalDays
            ? `a cada ${config.movCallResetIntervalDays} dia(s) — próximo em <t:${Math.floor(
                (nextReset as Date).getTime() / 1000
              )}:R>`
            : "desativado (apenas manual)"
        }\n` +
        `**🏅 Canal do Ranking:** ${config.movCallRankingChannelId ? `<#${config.movCallRankingChannelId}>` : "*não definido*"}\n` +
        `**📜 Canal de Logs:** ${config.movCallLogChannelId ? `<#${config.movCallLogChannelId}>` : "*usa o canal de logs geral*"}\n` +
        `**👑 Cargo do Top 1:** ${config.movCallTop1RoleId ? `<@&${config.movCallTop1RoleId}>` : "*não definido*"}\n` +
        `**🎖️ Recompensas por tempo:** ${rewards.length} cadastrada(s)`
    );

  const row1 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("adm-movcall:toggleranking")
      .setLabel(config.movCallRankingEnabled ? "Desativar Ranking" : "Ativar Ranking")
      
      .setStyle(config.movCallRankingEnabled ? ButtonStyle.Danger : ButtonStyle.Success),
    new ButtonBuilder().setCustomId("adm-movcall:interval").setLabel("Período de Reset").setStyle(ButtonStyle.Secondary)
  );

  const row2 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("adm-movcall:rankingchannel").setLabel("Canal do Ranking").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("adm-movcall:logchannel").setLabel("Canal de Logs").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("adm-movcall:top1role").setLabel("Cargo do Top 1").setStyle(ButtonStyle.Secondary)
  );

  const row3 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("adm-movcall:rewards").setLabel("Recompensas por Tempo").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("adm-movcall:resetnow").setLabel("Limpar Ranking").setStyle(ButtonStyle.Danger)
  );

  await interaction.update({ attachments: [], embeds: [embed], components: [row1, row2, row3, backRow("adm-movcall:root")] });
}

async function toggleRanking(interaction: ButtonInteraction) {
  const next = await toggleMovCallRanking(interaction.guild!.id);
  await logAdminAction({
    guild: interaction.guild!,
    actorId: interaction.user.id,
    action: AdminLogAction.MOVCALL_CONFIG_CHANGED,
    details: `Status do Ranking (Top Call): ${next ? "ativado" : "desativado"}`,
  });
  await renderMovCallTopCallMenu(interaction);
}

async function openIntervalModal(interaction: ButtonInteraction) {
  const config = await getGuildConfigForMovCall(interaction.guild!.id);

  const modal = new ModalBuilder().setCustomId("adm-modal:movcallinterval").setTitle("Período de Reset — Top Call");

  const daysInput = new TextInputBuilder()
    .setCustomId("days")
    .setLabel("Reseta a cada quantos dias? (1 a 90)")
    .setPlaceholder("Vazio = só reseto manualmente")
    .setStyle(TextInputStyle.Short)
    .setValue(config.movCallResetIntervalDays ? String(config.movCallResetIntervalDays) : "")
    .setRequired(false)
    .setMaxLength(2);

  modal.addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(daysInput));
  await interaction.showModal(modal);
}

async function renderChannelPicker(interaction: ButtonInteraction, kind: "ranking" | "logs") {
  const config = await getGuildConfigForMovCall(interaction.guild!.id);
  const current = kind === "ranking" ? config.movCallRankingChannelId : config.movCallLogChannelId;
  const label = kind === "ranking" ? "Canal do Ranking" : "Canal de Logs";
  const emoji = kind === "ranking" ? "🏅" : "📜";

  const embed = (await adminEmbed(interaction.guild!, "servidor"))
    .setTitle(`${emoji} ${label}`)
    .setDescription(`**Atual:** ${current ? `<#${current}>` : "*não definido*"}\n\nSelecione um canal de texto abaixo.`);

  const select = new ChannelSelectMenuBuilder()
    .setCustomId(`adm-movcallchannel-select:${kind}`)
    .setPlaceholder(`Selecione o ${label.toLowerCase()}`)
    .addChannelTypes(ChannelType.GuildText)
    .setMinValues(0)
    .setMaxValues(1);
  if (current) select.setDefaultChannels([current]);

  const selectRow = new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(select);
  await interaction.update({ attachments: [], embeds: [embed], components: [selectRow, backRow("adm-movcall:topcall")] });
}

async function renderTop1RolePicker(interaction: ButtonInteraction) {
  const config = await getGuildConfigForMovCall(interaction.guild!.id);

  const embed = (await adminEmbed(interaction.guild!, "servidor"))
    .setTitle("👑 Cargo do Top 1")
    .setDescription(
      `**Atual:** ${config.movCallTop1RoleId ? `<@&${config.movCallTop1RoleId}>` : "*não definido*"}\n\n` +
        "Cargo concedido automaticamente ao membro que estiver na 1ª posição do Top Call. É removido de quem perder a posição."
    );

  const select = new RoleSelectMenuBuilder().setCustomId("adm-role-select:movcalltop1").setPlaceholder("Selecione o cargo").setMinValues(0).setMaxValues(1);
  if (config.movCallTop1RoleId) select.setDefaultRoles([config.movCallTop1RoleId]);

  const selectRow = new ActionRowBuilder<RoleSelectMenuBuilder>().addComponents(select);
  await interaction.update({ attachments: [], embeds: [embed], components: [selectRow, backRow("adm-movcall:topcall")] });
}

async function handleResetNow(interaction: ButtonInteraction) {
  await resetMovCallStats(interaction.guild!.id);
  await logAdminAction({
    guild: interaction.guild!,
    actorId: interaction.user.id,
    action: AdminLogAction.MOVCALL_RESET,
    details: "Reset manual do Top Call.",
  });
  await refreshCallRankingMessage(interaction.guild!).catch(() => null);
  await renderMovCallTopCallMenu(interaction);
}

// -----------------------------
// 🎖️ Recompensas por Tempo
// -----------------------------
export async function renderRewardsMenu(interaction: any) {
  const rewards = await getMovCallRewards(interaction.guild!.id);

  const lines = rewards.length
    ? rewards
        .map((r: { roleId: string; minHours: number }) => `**${r.minHours}h** → <@&${r.roleId}>`)
        .join("\n")
    : "*Nenhuma recompensa cadastrada ainda.*";

  const embed = (await adminEmbed(interaction.guild!, "servidor"))
    .setTitle("🎖️ Recompensas por Tempo")
    .setDescription(
      "Cargos automáticos conforme o tempo acumulado em call. Todos os limiares atingidos são concedidos " +
        "(cargos anteriores não são removidos).\n\n" +
        lines
    );

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("adm-movcall:rewardadd").setLabel("Adicionar / Editar").setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId("adm-movcall:rewardremove").setLabel("Remover").setStyle(ButtonStyle.Danger)
  );

  await interaction.update({ attachments: [], embeds: [embed], components: [row, backRow("adm-movcall:topcall")] });
}

async function openRewardRoleAdd(interaction: ButtonInteraction) {
  const embed = (await adminEmbed(interaction.guild!, "servidor"))
    .setTitle("➕ Adicionar / Editar Recompensa")
    .setDescription("Selecione o cargo que será concedido. Em seguida, informe o tempo mínimo (em horas).");

  const select = new RoleSelectMenuBuilder().setCustomId("adm-role-select:movcallrewardadd").setPlaceholder("Selecione o cargo").setMinValues(1).setMaxValues(1);
  const selectRow = new ActionRowBuilder<RoleSelectMenuBuilder>().addComponents(select);
  await interaction.update({ attachments: [], embeds: [embed], components: [selectRow, backRow("adm-movcall:rewards")] });
}

async function openRewardRoleRemove(interaction: ButtonInteraction) {
  const embed = (await adminEmbed(interaction.guild!, "servidor"))
    .setTitle("🗑️ Remover Recompensa")
    .setDescription("Selecione o cargo da recompensa que deseja remover.");

  const select = new RoleSelectMenuBuilder().setCustomId("adm-role-select:movcallrewardremove").setPlaceholder("Selecione o cargo").setMinValues(1).setMaxValues(1);
  const selectRow = new ActionRowBuilder<RoleSelectMenuBuilder>().addComponents(select);
  await interaction.update({ attachments: [], embeds: [embed], components: [selectRow, backRow("adm-movcall:rewards")] });
}

// -----------------------------
// 📊 Estatísticas
// -----------------------------
export async function renderMovCallStatsMenu(interaction: any) {
  const rows = await getRanking(interaction.guild!.id, MovStatType.CALL, 10);

  const lines = rows.length
    ? rows
        .map((r: { userId: string; value: number }, i: number) => `**${i + 1}.** <@${r.userId}> — ${formatDuration(r.value)}`)
        .join("\n")
    : "*Ninguém pontuou ainda.*";

  const embed = (await adminEmbed(interaction.guild!, "servidor"))
    .setTitle("📊 Mov.Call — Estatísticas")
    .setDescription(
      "**Top 10 — Tempo em Call**\n" +
        lines +
        "\n\n" +
        "Cada membro pode consultar os próprios números com:\n" +
        "`/tempocall` — tempo em call (hoje, semana, mês, total)\n" +
        "`/callinfo` — estatísticas completas (tempo, sequência e companhia)\n" +
        "`/topcall` — Top 10 do servidor\n" +
        "`/rankingcall` — ranking completo (requer permissão, se configurada)"
    );

  await interaction.update({ attachments: [], embeds: [embed], components: [backRow("adm-movcall:root")] });
}

const component: ButtonComponent = {
  customId: "adm-movcall:",

  async execute(interaction: ButtonInteraction) {
    if (!interaction.guild) return;

    const member = await interaction.guild.members.fetch(interaction.user.id);
    if (!(await isBotAdmin(member))) {
      await interaction.reply({ content: "🚫 Você não tem permissão para acessar esta seção.", ephemeral: true });
      return;
    }

    const parts = interaction.customId.split(":"); // ["adm-movcall", "acao"]
    const action = parts[1];

    switch (action) {
      case "root":
        return renderMovCallRoot(interaction);
      case "config":
        return renderMovCallConfigMenu(interaction);
      case "togglesystem":
        return toggleSystem(interaction);
      case "togglemuted":
        return toggleCountMuted(interaction);
      case "categories":
        return renderCategoriesPicker(interaction);
      case "permroles":
        return renderPermRolesPicker(interaction);
      case "topcall":
        return renderMovCallTopCallMenu(interaction);
      case "toggleranking":
        return toggleRanking(interaction);
      case "interval":
        return openIntervalModal(interaction);
      case "rankingchannel":
        return renderChannelPicker(interaction, "ranking");
      case "logchannel":
        return renderChannelPicker(interaction, "logs");
      case "top1role":
        return renderTop1RolePicker(interaction);
      case "resetnow":
        return handleResetNow(interaction);
      case "rewards":
        return renderRewardsMenu(interaction);
      case "rewardadd":
        return openRewardRoleAdd(interaction);
      case "rewardremove":
        return openRewardRoleRemove(interaction);
      case "stats":
        return renderMovCallStatsMenu(interaction);
      default:
        return renderMovCallRoot(interaction);
    }
  },
};

export default component;
