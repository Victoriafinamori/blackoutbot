import { isBotAdmin } from '../../utils/permissions';
const component={customId:'admin-task-home:',async execute(i:any){
  if(!i.guild||!await isBotAdmin(await i.guild.members.fetch(i.user.id)))return;
  if(i.customId==='admin-task-home:parcerias')return require('./admPartnershipsMenu').renderPartnershipsMenu(i);
}};
export default component;
