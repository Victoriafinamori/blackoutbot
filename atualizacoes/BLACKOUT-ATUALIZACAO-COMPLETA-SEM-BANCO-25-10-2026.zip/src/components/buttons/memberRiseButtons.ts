import { ActionRowBuilder, ButtonInteraction, ModalBuilder, TextInputBuilder, TextInputStyle } from "discord.js";
import { ButtonComponent } from "../../structures/types";
import { isBotAdmin } from "../../utils/permissions";
import { prisma } from "../../database/prisma";
import { promote, roleProblem, stage } from "../../memberRise/service";
import { renderMemberRise } from "../../memberRise/panel";
import { buildAdmSectionPanel } from "../../utils/admPanel";

const field = (id: string, label: string, value: string, style = TextInputStyle.Short) => new ActionRowBuilder<TextInputBuilder>().addComponents(new TextInputBuilder().setCustomId(id).setLabel(label).setStyle(style).setValue(value.slice(0, style === TextInputStyle.Paragraph ? 4000 : 100)).setRequired(true));
const component: ButtonComponent = { customId: "member-rise:", async execute(i: ButtonInteraction) {
  if (!i.guild || !await isBotAdmin(await i.guild.members.fetch(i.user.id))) return void await i.reply({ content: "Sem permissão.", ephemeral: true });
  const [, action, arg] = i.customId.split(":");
  if (action === "back") return void await i.update(await buildAdmSectionPanel(i.guild, "membros"));
  const s = await stage(i.guild.id);
  if (action === "toggle") {
    if (!s.enabled) { const issue = roleProblem(i.guild, s); if (issue) return void await i.reply({ content: issue, ephemeral: true }); if (!s.messageEnabled && !s.voiceEnabled) return void await i.reply({ content: "Ative ao menos um requisito.", ephemeral: true }); }
    await prisma.memberRiseStage.update({ where: { id: s.id }, data: { enabled: !s.enabled } });
    if (s.enabled) await prisma.memberRiseProgress.updateMany({ where: { stageId: s.id, status: "ACTIVE" }, data: { voiceChannelId: null, voiceCheckedAt: null } });
    return renderMemberRise(i);
  }
  if (action === "roles") return renderMemberRise(i,"roles");
        if (action === "requirements") return void await i.showModal(new ModalBuilder().setCustomId("member-rise-modal:requirements").setTitle("Requisitos").addComponents(field("messages", "Mensagens (0 desativa)", s.messageEnabled ? String(s.minMessages) : "0"), field("hours", "Horas de call (0 desativa)", s.voiceEnabled ? String(Math.floor(s.minVoiceSeconds / 3600)) : "0"), field("minutes", "Minutos adicionais", String(Math.floor(s.minVoiceSeconds % 3600 / 60))), field("mode", "Modo: TODOS ou QUALQUER UM", s.requirementMode === "ALL" ? "TODOS" : "QUALQUER UM"), field("interval", "Intervalo entre mensagens (segundos)", String(s.messageIntervalSeconds))));
  if (action === "voice") return void await i.showModal(new ModalBuilder().setCustomId("member-rise-modal:voice").setTitle("Regras de call").addComponents(field("people", "Mínimo de pessoas", String(s.minVoicePeople)), field("afk", "Ignorar AFK? SIM ou NÃO", s.ignoreAfk ? "SIM" : "NÃO"), field("muted", "Contar mutado? SIM ou NÃO", s.countMuted ? "SIM" : "NÃO"), field("deaf", "Contar ensurdecido? SIM ou NÃO", s.countDeafened ? "SIM" : "NÃO")));
  if (action === "messages") return void await i.showModal(new ModalBuilder().setCustomId("member-rise-modal:messages").setTitle("Mensagens e automação").addComponents(field("public", "Mensagem pública", s.publicMessage, TextInputStyle.Paragraph), field("dm", "Mensagem privada", s.dmMessage, TextInputStyle.Paragraph)));
  if (action === "search") return void await i.showModal(new ModalBuilder().setCustomId("member-rise-modal:search").setTitle("Buscar membro").addComponents(field("member", "ID ou menção do membro", " ")));
  if (action === "progress") return renderMemberRise(i, "progress", Number(arg) || 0);
  if (action === "history") return renderMemberRise(i, "history", Number(arg) || 0);
  if (action === "home") return renderMemberRise(i);
  if (action === "preview") return renderMemberRise(i, "preview");
  if (action === "detail") return renderMemberRise(i, "detail", 0, arg);
  if (action === "confirm-promote" || action === "confirm-reset") return renderMemberRise(i, "confirm", 0, `${action.slice(8)}:${arg}`);
  if (action === "promote" && arg) { await i.deferUpdate(); await promote(i.guild, arg, "MANUAL", i.user.id); return renderMemberRise(i, "detail", 0, arg); }
  if (action === "reset" && arg) { await prisma.memberRiseProgress.updateMany({ where: { stageId: s.id, userId: arg }, data: { generation: { increment: 1 }, messages: 0, voiceSeconds: 0, lastMessageAt: null, voiceChannelId: null, voiceCheckedAt: null, status: "ACTIVE", promotedAt: null } }); return renderMemberRise(i, "detail", 0, arg); }
} }; export default component;
