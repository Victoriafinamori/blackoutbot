import { ButtonComponent } from "../../structures/types";
import { isBotAdmin } from "../../utils/permissions";
import { buildAdmRootPanel, buildAdmSectionPanel, resolveAdmSection } from "../../utils/admPanel";
import { ensureAdmEmojis } from "../../utils/admEmojis";
const component: ButtonComponent = {
  customId: "adm-nav:",
  async execute(i) {
    if (!i.guild) return;
    if (!await isBotAdmin(await i.guild.members.fetch(i.user.id))) {
      await i.reply({ content: "Você não possui permissão para acessar o painel administrativo.", ephemeral: true });
      return;
    }
    const target = i.customId.slice("adm-nav:".length);
    const area = resolveAdmSection(target);
    if (target !== "root" && !area) return;
    await i.deferUpdate();
    if (target === "root") await ensureAdmEmojis(i.guild);
    await i.editReply(area ? await buildAdmSectionPanel(i.guild, area) : await buildAdmRootPanel(i.guild, i.user));
  },
};
export default component;
