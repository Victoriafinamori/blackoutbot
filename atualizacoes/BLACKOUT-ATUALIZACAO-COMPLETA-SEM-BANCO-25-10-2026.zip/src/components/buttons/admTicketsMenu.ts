const { prepareAdminPanel } = require("../../utils/adminTasks");
import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonInteraction,
  ButtonStyle,
  ChannelSelectMenuBuilder,
  ChannelType,
  MessageComponentInteraction,
  ModalBuilder,
  RoleSelectMenuBuilder,
  StringSelectMenuBuilder,
  TextInputBuilder,
  TextInputStyle,
} from "discord.js";
import { ButtonComponent } from "../../structures/types";
import { adminEmbed } from "../../utils/adminUi";
import { isBotAdmin } from "../../utils/permissions";
import { ids, publishTicketPanel, ticketConfig } from "../../utils/tickets";
import { prisma } from "../../database/prisma";
import { admEmoji } from "../../utils/admEmojis";

const RED = 0xd71935;
const yesNo = (value: boolean) => (value ? "Sim" : "Não");
const roles = (value: string | null) => ids(value).map(id => `<@&${id}>`).join(", ") || "N/A";
const button = (customId: string, label: string, style = ButtonStyle.Secondary) =>
  new ButtonBuilder().setCustomId(customId).setLabel(label).setStyle(style);

function nav(customId: string, placeholder: string, options: { label: string; value: string; description?: string; emoji?: string }[]) {
  return new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder().setCustomId(customId).setPlaceholder(placeholder).addOptions(options)
  );
}

export async function renderTicketsMenu(interaction: MessageComponentInteraction) {
  const icon = admEmoji(interaction.guild!, "tickets");
  const embed = (await adminEmbed(interaction.guild!, "atendimento"))
    .setColor(RED)
    .setTitle("Central de Tickets")
    .setDescription("Configure e gerencie o atendimento do servidor por uma área de cada vez. Selecione uma opção abaixo para continuar.")
    .addFields(
      { name: "Configurações", value: "Logs, marcações, trava, motivos e relatórios externos.", inline: true },
      { name: "Cadastrar ticket", value: "Escolha o canal e publique o painel de atendimento.", inline: true },
      { name: "Gerenciar tickets", value: "Categoria, responsáveis, aparência e funcionamento.", inline: true },
      { name: "Avaliação e ranking", value: "Feedback no chat do ticket e desempenho da equipe.", inline: true },
    );

  await interaction.update(prepareAdminPanel(interaction.guild, 'tickets', { attachments: [], embeds: [embed], components: [nav("ticket-admin-nav", "Selecione uma área dos tickets", [
    { label: "Voltar", value: "back", description: "Retornar para Atendimento", emoji: "↩️" },
    { label: "Configurações", value: "settings", description: "Logs, permissões e comportamento", emoji: icon },
    { label: "Cadastrar ticket", value: "register", description: "Definir onde o painel será enviado", emoji: icon },
    { label: "Gerenciar tickets", value: "manage", description: "Editar painel, categoria e responsáveis", emoji: icon },
    { label: "Avaliação e ranking", value: "ratings", description: "Feedback e desempenho dos atendimentos", emoji: icon },
  ])] }));
}

export async function renderTicketSettings(interaction: MessageComponentInteraction) {
  const c = await ticketConfig(interaction.guild!.id);
  const total = await prisma.ticket.count({ where: { guildId: interaction.guild!.id } });
  const embed = (await adminEmbed(interaction.guild!, "atendimento")).setColor(RED).setTitle("Configurações dos Tickets").addFields(
    { name: "ℹ️ Informações", value: `Canal de Logs: **${c.logChannelId ? `<#${c.logChannelId}>` : "N/A"}**\nMarcar membro/staff: **${yesNo(c.pingMember)} / ${yesNo(c.pingStaff)}**\nMotivo Obrigatório: **Abrir: Não | Fechar: ${yesNo(c.closeReasonRequired)}**\nTickets Configurados: **${total} tickets**\nTrava Ticket: **${c.lockToClaimer ? "Somente quem assumiu" : "N/A"}**` },
    { name: "Observações", value: "1. Defina se membro e staff serão marcados ao abrir.\n2. Torne obrigatório informar o motivo ao fechar.\n3. Restrinja o fechamento a quem assumiu, mantendo cargos imunes.\n4. Relatórios podem continuar sendo enviados para outro servidor." },
  );
  await interaction.update({ attachments: [], embeds: [embed], components: [nav("ticket-admin-settings-nav", "O que deseja configurar?", [
    { label: "Voltar", value: "back" },
    { label: "Canais", value: "channels", description: "Logs, feedback e relatórios" },
    { label: "Cargos e permissões", value: "roles", description: "Responsáveis, imunes e relatórios" },
    { label: "Marcações e regras", value: "behavior", description: "Pings, motivo e trava do ticket" },
    { label: "Relatórios externos", value: "external", description: "Envio dos quatro tipos para outro servidor" },
    { label: "Resetar tudo", value: "reset", description: "Restaurar as configurações padrão" },
  ])] });
}

export async function renderTicketRegister(interaction: MessageComponentInteraction) {
  const c = await ticketConfig(interaction.guild!.id);
  const embed = (await adminEmbed(interaction.guild!, "atendimento")).setColor(RED).setTitle("Cadastrar Ticket")
    .setDescription("Selecione o canal em que será enviado o painel deste ticket.")
    .addFields({ name: "Canal selecionado", value: c.panelChannelId ? `<#${c.panelChannelId}>` : "N/A" });
  const channel = new ChannelSelectMenuBuilder().setCustomId("ticket-admin-panel-channel").setPlaceholder("Selecione um canal...").addChannelTypes(ChannelType.GuildText).setMinValues(1).setMaxValues(1);
  await interaction.update({ attachments: [], embeds: [embed], components: [new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(channel), new ActionRowBuilder<ButtonBuilder>().addComponents(button("adm-ticket:menu", "Voltar"))] });
}

export async function renderTicketManager(interaction: MessageComponentInteraction) {
  const c = await ticketConfig(interaction.guild!.id);
  const embed = (await adminEmbed(interaction.guild!, "atendimento")).setColor(RED).setTitle("Gerenciador de Tickets")
    .addFields(
      { name: "ℹ️ Informações", value: `Canal Painel: **${c.panelChannelId ? `<#${c.panelChannelId}>` : "N/A"}**\nCategoria: **${c.categoryId ? `<#${c.categoryId}>` : "N/A"}**\nCargos Responsáveis: **${roles(c.staffRoleIds)}**` },
      { name: "🛠️ Personalizar", value: `Usar Tópico: **${yesNo(c.useThreads)}**\nUsar botão: **${yesNo(c.useButton)}**\nMenus de Seleção: **N/A**` },
      { name: "Observações", value: "Você pode usar tópicos ou canal de texto para o ticket, além de botão ou menu de seleção. As opções atuais do bot foram preservadas." },
    );
  await interaction.update({ attachments: [], embeds: [embed], components: [nav("ticket-admin-manager-nav", "Selecione uma ação para gerenciar", [
    { label: "Voltar", value: "back" },
    { label: "Canal e categoria", value: "channels", description: "Local do painel e categoria dos tickets" },
    { label: "Cargos responsáveis", value: "roles", description: "Equipe autorizada e cargos imunes" },
    { label: "Formato de abertura", value: "mode", description: "Tópico/canal e botão/menu" },
    { label: "Embed do painel", value: "panelAppearance", description: "Textos, botão, HEX, thumbnail, imagem e rodapé" },
    { label: "Embed interna", value: "internalAppearance", description: "Textos, HEX, thumbnail, imagem e rodapé" },
    { label: "Publicar/Atualizar painel", value: "publish", description: "Enviar o painel no canal configurado" },
  ])] });
}

export async function renderTicketRatings(interaction: MessageComponentInteraction) {
  const c = await ticketConfig(interaction.guild!.id);
  const ratings = await prisma.ticketRating.findMany({ where: { guildId: interaction.guild!.id } });
  const average = ratings.length ? (ratings.reduce((sum, item) => sum + item.stars, 0) / ratings.length).toFixed(1) : "N/A";
  const embed = (await adminEmbed(interaction.guild!, "atendimento")).setColor(RED).setTitle("Avaliação e Ranking — Tickets")
    .setDescription("Ative ou desative o sistema de avaliações dos atendimentos nos tickets.")
    .addFields(
      { name: "Como funciona?", value: "Ao finalizar o atendimento, o feedback aparece **no chat do ticket**. O membro escolhe as estrelas e digita sua avaliação; o resultado segue para o canal configurado." },
      { name: "Status", value: `Sistema: **${c.ratingsEnabled ? "Ativado" : "Desativado"}**\nCanal de feedback: **${c.feedbackChannelId ? `<#${c.feedbackChannelId}>` : "N/A"}**\nAvaliações recebidas: **${ratings.length}**\nMédia geral: **${average}${ratings.length ? "/5" : ""}**` },
      { name: "Configuração", value: "Esta configuração é aplicada a todos os tickets criados por este painel." },
    );
  await interaction.update({ attachments: [], embeds: [embed], components: [nav("ticket-admin-ratings-nav", "Configure avaliação e ranking", [
    { label: "Voltar", value: "back" },
    { label: c.ratingsEnabled ? "Desativar avaliações" : "Ativar avaliações", value: "toggle" },
    { label: "Canal de feedback", value: "channel", description: "Escolher onde as avaliações serão enviadas" },
    { label: "Atualizar ranking", value: "refresh", description: "Recalcular os números exibidos" },
  ])] });
}

export async function renderTicketChannels(interaction: MessageComponentInteraction, manager = false) {
  const fields = manager
    ? [["panelChannelId", "Canal do painel", [ChannelType.GuildText]], ["categoryId", "Categoria dos tickets", [ChannelType.GuildCategory]]] as const
    : [["logChannelId", "Canal de logs", [ChannelType.GuildText]], ["feedbackChannelId", "Canal de feedback", [ChannelType.GuildText]], ["reportChannelId", "Canal de relatórios", [ChannelType.GuildText]]] as const;
  const rows = fields.map(([key, label, types]) => new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(new ChannelSelectMenuBuilder().setCustomId(`ticket-channel:${key}`).setPlaceholder(label).addChannelTypes(...types).setMinValues(0).setMaxValues(1)));
  await interaction.update({ attachments: [], embeds: [(await adminEmbed(interaction.guild!, "atendimento")).setColor(RED).setTitle(manager ? "Canal e Categoria" : "Canais dos Tickets").setDescription("Escolha os canais abaixo. Uma seleção vazia remove a configuração.")], components: [...rows, new ActionRowBuilder<ButtonBuilder>().addComponents(button(manager ? "adm-ticket:manager" : "adm-ticket:settings", "Voltar"))] });
}

export async function renderTicketRoles(interaction: MessageComponentInteraction, manager = false) {
  const definitions = manager ? [["staffRoleIds", "Cargos responsáveis"], ["immuneRoleIds", "Cargos imunes à trava"]] : [["staffRoleIds", "Cargos responsáveis"], ["immuneRoleIds", "Cargos imunes à trava"], ["reportRoleIds", "Cargos que geram relatórios"]];
  const rows = definitions.map(([key, label]) => new ActionRowBuilder<RoleSelectMenuBuilder>().addComponents(new RoleSelectMenuBuilder().setCustomId(`ticket-role:${key}`).setPlaceholder(label).setMinValues(0).setMaxValues(10)));
  await interaction.update({ attachments: [], embeds: [(await adminEmbed(interaction.guild!, "atendimento")).setColor(RED).setTitle("Cargos e Permissões")], components: [...rows, new ActionRowBuilder<ButtonBuilder>().addComponents(button(manager ? "adm-ticket:manager" : "adm-ticket:settings", "Voltar"))] });
}

export async function renderTicketBehavior(interaction: MessageComponentInteraction) {
  const c = await ticketConfig(interaction.guild!.id);
  const embed = (await adminEmbed(interaction.guild!, "atendimento")).setColor(RED).setTitle("Marcações e Regras")
    .setDescription("Altere as regras abaixo sem sair desta página.")
    .addFields({ name: "Estado atual", value: `Marcar membro: **${yesNo(c.pingMember)}**\nMarcar staff: **${yesNo(c.pingStaff)}**\nMotivo ao fechar: **${yesNo(c.closeReasonRequired)}**\nTrava do ticket: **${yesNo(c.lockToClaimer)}**` });
  await interaction.update({ attachments: [], embeds: [embed], components: [
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      button("adm-ticket:toggle-behavior:pingMember", `Membro: ${yesNo(c.pingMember)}`, c.pingMember ? ButtonStyle.Success : ButtonStyle.Secondary),
      button("adm-ticket:toggle-behavior:pingStaff", `Staff: ${yesNo(c.pingStaff)}`, c.pingStaff ? ButtonStyle.Success : ButtonStyle.Secondary),
      button("adm-ticket:toggle-behavior:closeReasonRequired", `Motivo: ${yesNo(c.closeReasonRequired)}`, c.closeReasonRequired ? ButtonStyle.Success : ButtonStyle.Secondary),
      button("adm-ticket:toggle-behavior:lockToClaimer", `Trava: ${yesNo(c.lockToClaimer)}`, c.lockToClaimer ? ButtonStyle.Success : ButtonStyle.Secondary),
    ),
    new ActionRowBuilder<ButtonBuilder>().addComponents(button("adm-ticket:settings", "Voltar")),
  ] });
}

export async function renderTicketExternal(interaction: MessageComponentInteraction) {
  const c = await ticketConfig(interaction.guild!.id);
  const embed = (await adminEmbed(interaction.guild!, "atendimento")).setColor(RED).setTitle("Relatórios Externos")
    .setDescription("Envie cada tipo de relatório para um canal específico em outro servidor.")
    .addFields({ name: "Destino", value: `Envio externo: **${yesNo(c.externalReportsEnabled)}**\nServidor: **${c.reportTargetGuildId || "N/A"}**\nJustificativa: **${c.reportJustificationChannelId || "N/A"}**\nTroca de conta: **${c.reportAccountChangeChannelId || "N/A"}**\nTroca de nome: **${c.reportNameChangeChannelId || "N/A"}**\nOutros: **${c.reportOtherChannelId || "N/A"}**` });
  await interaction.update({ attachments: [], embeds: [embed], components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
    button("adm-ticket:toggle-external:externalReportsEnabled", c.externalReportsEnabled ? "Desativar envio" : "Ativar envio", c.externalReportsEnabled ? ButtonStyle.Danger : ButtonStyle.Success),
    button("adm-ticket-external:configure", "Configurar destinos", ButtonStyle.Primary),
    button("adm-ticket:settings", "Voltar"),
  )] });
}

export async function renderTicketMode(interaction: MessageComponentInteraction) {
  const c = await ticketConfig(interaction.guild!.id);
  const embed = (await adminEmbed(interaction.guild!, "atendimento")).setColor(RED).setTitle("Formato de Abertura")
    .setDescription("Escolha como os atendimentos serão criados. As alterações permanecem nesta página.")
    .addFields({ name: "Estado atual", value: `Usar tópico: **${yesNo(c.useThreads)}**\nUsar botão: **${yesNo(c.useButton)}**\nMenu de seleção: **N/A**` });
  await interaction.update({ attachments: [], embeds: [embed], components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
    button("adm-ticket:toggle-manager:useThreads", `Usar tópico: ${yesNo(c.useThreads)}`, c.useThreads ? ButtonStyle.Success : ButtonStyle.Secondary),
    button("adm-ticket:toggle-manager:useButton", `Usar botão: ${yesNo(c.useButton)}`, c.useButton ? ButtonStyle.Success : ButtonStyle.Secondary),
    button("adm-ticket:manager", "Voltar"),
  )] });
}

const component: ButtonComponent = { customId: "adm-ticket:", async execute(interaction: ButtonInteraction) {
  if (!interaction.guild || !(await isBotAdmin(await interaction.guild.members.fetch(interaction.user.id)))) return void await interaction.reply({ content: "Sem permissão.", ephemeral: true });
  const [, action, arg] = interaction.customId.split(":");
  if (action === "menu") return renderTicketsMenu(interaction);
  if (action === "settings") return renderTicketSettings(interaction);
  if (action === "manager") return renderTicketManager(interaction);
  if (action === "ratings") return renderTicketRatings(interaction);
  if (action === "toggle") { const c = await ticketConfig(interaction.guild.id) as any; await prisma.ticketConfig.update({ where: { guildId: interaction.guild.id }, data: { [arg]: !c[arg] } }); return renderTicketSettings(interaction); }
  if (action === "toggle-behavior") { const c = await ticketConfig(interaction.guild.id) as any; await prisma.ticketConfig.update({ where: { guildId: interaction.guild.id }, data: { [arg]: !c[arg] } }); return renderTicketBehavior(interaction); }
  if (action === "toggle-external") { const c = await ticketConfig(interaction.guild.id) as any; await prisma.ticketConfig.update({ where: { guildId: interaction.guild.id }, data: { [arg]: !c[arg] } }); return renderTicketExternal(interaction); }
  if (action === "toggle-manager") { const c = await ticketConfig(interaction.guild.id) as any; await prisma.ticketConfig.update({ where: { guildId: interaction.guild.id }, data: { [arg]: !c[arg] } }); return renderTicketMode(interaction); }
  if (action === "reset-confirm") {
    await prisma.ticketConfig.delete({ where: { guildId: interaction.guild.id } }).catch(() => null);
    await ticketConfig(interaction.guild.id);
    return renderTicketSettings(interaction);
  }
  if (action === "publish") { await interaction.deferReply({ ephemeral: true }); await publishTicketPanel(interaction.guild); await interaction.editReply("Painel de tickets publicado/atualizado."); return; }
  if (action === "customize") {
    const c = await ticketConfig(interaction.guild.id);
    const modal = new ModalBuilder().setCustomId("ticket-modal:customize").setTitle("Personalizar painel e ticket");
    const values = [["panelTitle", "Título do painel", c.panelTitle], ["panelDescription", "Descrição do painel", c.panelDescription], ["panelButtonLabel", "Texto do botão", c.panelButtonLabel], ["internalTitle", "Título interno", c.internalTitle], ["internalDescription", "Descrição interna", c.internalDescription]];
    modal.addComponents(...values.map(([id, label, value]) => new ActionRowBuilder<TextInputBuilder>().addComponents(new TextInputBuilder().setCustomId(id).setLabel(label).setStyle(id.includes("Description") ? TextInputStyle.Paragraph : TextInputStyle.Short).setValue(value).setRequired(true))));
    await interaction.showModal(modal);
  }
}};
export default component;
