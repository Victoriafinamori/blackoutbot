import { ButtonComponent } from "../../structures/types";
import { execute } from "../../security/interactions";
const component: ButtonComponent = { customId: "security:", execute };
export default component;
