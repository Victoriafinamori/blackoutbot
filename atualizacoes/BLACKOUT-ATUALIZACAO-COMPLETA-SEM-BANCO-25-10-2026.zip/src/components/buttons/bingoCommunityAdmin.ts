import { admin } from "../../bingo/communityInteractions";
export default { customId: "bg-admin:", execute: admin };
