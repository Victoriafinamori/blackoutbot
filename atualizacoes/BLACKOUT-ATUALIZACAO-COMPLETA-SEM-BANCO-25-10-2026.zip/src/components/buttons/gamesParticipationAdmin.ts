import { admin } from "../../games-chat/experience/hub";
export default { customId: "games-admin:", execute: admin };
