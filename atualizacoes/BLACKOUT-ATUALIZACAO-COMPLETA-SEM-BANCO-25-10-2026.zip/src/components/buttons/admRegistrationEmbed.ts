import { ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } from 'discord.js';
import { isBotAdmin } from '../../utils/permissions';
import { regConfig } from '../../utils/registration';
import { prisma } from '../../database/prisma';
import { deferPanel, refreshPanel } from '../../utils/panelInteraction';
import { renderRegistrationAdmin, registrationAdminPayload } from '../../utils/registrationAdmin';
const editor=require('../../../app/utils/registrationPanelEditor');
const input=(id:string,label:string,value:string,paragraph=false)=>new ActionRowBuilder<TextInputBuilder>().addComponents(new TextInputBuilder().setCustomId(id).setLabel(label).setValue(value||'').setStyle(paragraph?TextInputStyle.Paragraph:TextInputStyle.Short).setRequired(id!=='assets'));
const component={customId:'adm-reg-embed:',async execute(i:any){
  if(!i.guild||!await isBotAdmin(await i.guild.members.fetch(i.user.id)))return;
  const action=i.customId.split(':')[1],c=await regConfig(i.guild.id);
  if(action==='panel')return refreshPanel(i,await editor.registrationPanelEditor(i.guild));
  if(action==='publish')return renderRegistrationAdmin(i,'publication');
  if(action==='internal')return i.showModal(new ModalBuilder().setCustomId('registration-embed:internal').setTitle('Mensagem do chat de registro').addComponents(input('title','Título',c.internalTitle),input('description','Descrição',c.internalDescription,true),input('color','Cor hexadecimal',c.internalColor),input('assets','Thumbnail, imagem e rodapé',`THUMBNAIL=${c.internalThumbnail||''}\nIMAGEM=${c.internalImage||''}\nRODAPE=${c.internalFooter||''}`,true)));
  if(action==='send'){
    await deferPanel(i);
    try{
      const fresh=await regConfig(i.guild.id);
      if(!fresh.panelChannelId||!fresh.registrationCategoryId)return refreshPanel(i,{...await registrationAdminPayload(i.guild,'publication'),content:'Escolha o canal público e a categoria dos chats privados antes de publicar.'});
      const ch=await i.guild.channels.fetch(fresh.panelChannelId);
      if(!ch?.isTextBased()||ch.isDMBased()||!ch.isSendable())throw Error('O canal do painel não aceita mensagens. Revise o destino.');
      let message=null;
      if(fresh.panelMessageId){try{message=await ch.messages.fetch(fresh.panelMessageId)}catch(error:any){if(error.code!==10008)throw error}}
      const payload={...editor.registrationPanelPayload(fresh),allowedMentions:{parse:[]}};
      if(message)await message.edit(payload);else{message=await ch.send(payload);await prisma.registrationConfig.update({where:{guildId:i.guild.id},data:{panelMessageId:message.id}})}
      return refreshPanel(i,{...await registrationAdminPayload(i.guild,'publication'),content:`Painel publicado/atualizado em <#${fresh.panelChannelId}>.`});
    }catch(error:any){return i.followUp({content:`Não foi possível publicar: ${error.message}. Revise o canal e as permissões antes de repetir.`,ephemeral:true})}
  }
}};
export default component;
