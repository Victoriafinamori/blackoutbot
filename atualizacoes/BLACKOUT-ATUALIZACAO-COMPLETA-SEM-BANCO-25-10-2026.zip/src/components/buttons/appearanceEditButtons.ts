import { ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } from "discord.js";
import { ButtonComponent } from "../../structures/types";
import { isBotAdmin } from "../../utils/permissions";
import { getOrCreateGuildConfig } from "../../database/guildConfig";
const component: ButtonComponent = { customId: "appearance-edit:", async execute(i) {
  if (!i.guild || !await isBotAdmin(await i.guild.members.fetch(i.user.id))) return;
  const action = i.customId.split(":")[1];
  const labels: Record<string,string> = { nickname: "Nome do bot neste servidor", avatar: "URL do avatar neste servidor", banner: "URL do banner neste servidor", color: "Cor hexadecimal das mensagens" };
  if (!labels[action]) return void await i.reply({ content: "Use as opções atuais em Personalização do bot.", ephemeral: true });
  const me = await i.guild.members.fetchMe({ force: true });
  const value = action === "nickname" ? me.displayName : action === "avatar" ? me.avatarURL() : action === "banner" ? me.bannerURL() : (await getOrCreateGuildConfig(i.guild.id)).embedColor;
  const input = new TextInputBuilder().setCustomId("value").setLabel(labels[action]).setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(action === "nickname" ? 32 : action === "color" ? 7 : 500);
  if (value) input.setValue(value);
  await i.showModal(new ModalBuilder().setCustomId(`appearance-modal:${action}`).setTitle(action === "nickname" ? "Nome neste servidor" : action === "avatar" ? "Avatar neste servidor" : action === "banner" ? "Banner neste servidor" : "Cor das mensagens").addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(input)));
} };
export default component;
