import { ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, RoleSelectMenuBuilder } from "discord.js";
import { prisma } from "../../database/prisma";
import { isBotAdmin } from "../../utils/permissions";
import { adminEmbed } from "../../utils/adminUi";
import { refreshPanel, deferPanel } from "../../utils/panelInteraction";
import { roleSummary } from "../../utils/teamRoles";
import { PermissionType, SystemRoleType } from "../../structures/enums";
import { buildAdmRootPanel } from "../../utils/admPanel";
export const PERMISSION_LABELS: Record<PermissionType,{label:string;description:string}>={
 STAGE_MANAGER:{label:"Gerenciar etapas",description:"Passar ou regredir membros de etapa"},
 REINTEGRATION_GRANTER:{label:"Conceder reintegração",description:"Conceder o cargo de reintegração"},
 MOVCALL_COMMANDS:{label:"Consultas de call",description:"Consultar tempo, informações e ranking de call de outros membros"}
};
export const SYSTEM_ROLE_LABELS:Record<SystemRoleType,string>={STAGE_1:"Etapa 1",STAGE_2:"Etapa 2",STAGE_3:"Etapa 3",BLACKLIST:"Blacklist",MUTED:"Mutado",SUSPENDED:"Suspenso",STAFF:"Staff",OBSERVATION:"Observação"};
const back=(id:string)=>new ActionRowBuilder<ButtonBuilder>().addComponents(new ButtonBuilder().setCustomId(id).setLabel("Voltar").setStyle(ButtonStyle.Secondary));
async function show(i:any,embed:any,components:any[]){return refreshPanel(i,{content:null,attachments:[],embeds:[embed],components,allowedMentions:{parse:[]}})}
export async function renderAdminMenu(i:any){
 const [admins,permissions,roles]=await Promise.all([prisma.botAdmin.findMany({where:{guildId:i.guild.id}}),prisma.permissionRole.findMany({where:{guildId:i.guild.id}}),prisma.systemRole.findMany({where:{guildId:i.guild.id}})]);
 const modules=[{value:"botadmin",label:"Administradores do bot",description:"Cargos com acesso total ao painel /adm"},{value:"permroles",label:"Permissões por função",description:"Ações específicas de etapas, reintegração e call"},{value:"sysroles",label:"Cargos usados pelo bot",description:"Associações de etapas, restrições e equipe"}];
 const embed=adminEmbed(i.guild,"seguranca").setTitle("Equipe e permissões").setDescription("Defina quem administra o bot e os cargos usados no funcionamento. Associar um cargo do sistema não concede acesso ao painel.")
 .addFields({name:"Administradores do bot",value:roleSummary(i.guild,admins.map(r=>r.roleId))},{name:"Permissões por função",value:`${permissions.length} associações de acesso específico.`},{name:"Cargos usados pelo bot",value:`${roles.length}/8 funções configuradas.`});
 return show(i,embed,[new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(new StringSelectMenuBuilder().setCustomId("adm-admin-select").setPlaceholder("Escolha o tipo de configuração").addOptions(modules)),back("adm-nav:seguranca")]);
}
async function rolePicker(i:any,title:string,description:string,ids:string[],customId:string,backId:string,single=false,notice?:string){
 const embed=adminEmbed(i.guild,"seguranca").setTitle(title).setDescription(description).addFields({name:"Cargos atuais",value:roleSummary(i.guild,ids,single)});
 if(notice)embed.addFields({name:"Resultado",value:notice});
 const select=new RoleSelectMenuBuilder().setCustomId(customId).setPlaceholder("Selecione os cargos; vazio para remover").setMinValues(0).setMaxValues(single?1:25);
 const existing=ids.filter(id=>i.guild.roles.cache.has(id)).slice(0,single?1:25);if(existing.length)select.setDefaultRoles(existing);
 return show(i,embed,[new ActionRowBuilder<RoleSelectMenuBuilder>().addComponents(select),back(backId)]);
}
export async function renderBotAdmin(i:any,notice?:string){
 const current=await prisma.botAdmin.findMany({where:{guildId:i.guild.id}});
 return rolePicker(i,"Administradores do bot","Acesso total ao /adm neste servidor. A seleção é salva automaticamente. Membros com Administrador no Discord continuam com acesso.",current.map(r=>r.roleId),"adm-role-select:botadmin","adm-adm:menu",false,notice);
}
export async function renderPermRolesMenu(i:any){
 const current=await prisma.permissionRole.findMany({where:{guildId:i.guild.id}});
 const embed=adminEmbed(i.guild,"seguranca").setTitle("Permissões por função").setDescription("Selecione a ação e depois os cargos autorizados. Administradores do bot já têm acesso a essas ações.")
 .addFields(Object.entries(PERMISSION_LABELS).map(([type,v])=>({name:v.label,value:`${v.description}\n${roleSummary(i.guild,current.filter(r=>r.type===type).map(r=>r.roleId))}`.slice(0,1024)})));
 return show(i,embed,[new ActionRowBuilder<ButtonBuilder>().addComponents(Object.entries(PERMISSION_LABELS).map(([type,v])=>new ButtonBuilder().setCustomId(`adm-adm:permroles:${type}`).setLabel(v.label).setStyle(ButtonStyle.Secondary))),back("adm-adm:menu")]);
}
export async function renderPermRoleType(i:any,type:PermissionType,notice?:string){
 const info=PERMISSION_LABELS[type];if(!info)return renderPermRolesMenu(i);
 const current=await prisma.permissionRole.findMany({where:{guildId:i.guild.id,type}});
 return rolePicker(i,info.label,`${info.description}. A seleção é salva automaticamente; não concede acesso total ao painel.`,current.map(r=>r.roleId),`adm-role-select:permrole:${type}`,"adm-adm:permroles",false,notice);
}
export async function renderSysRolesMenu(i:any){
 const current=await prisma.systemRole.findMany({where:{guildId:i.guild.id}});
 const embed=adminEmbed(i.guild,"seguranca").setTitle("Cargos usados pelo bot").setDescription("Cada função utiliza um cargo do servidor. Essa associação não concede acesso ao /adm.")
 .addFields(Object.entries(SYSTEM_ROLE_LABELS).map(([type,label])=>({name:label,value:roleSummary(i.guild,current.filter(r=>r.type===type).map(r=>r.roleId),true)})));
 const select=new StringSelectMenuBuilder().setCustomId("adm-sysrole-select").setPlaceholder("Escolha uma função do sistema").addOptions(Object.entries(SYSTEM_ROLE_LABELS).map(([value,label])=>({value,label})));
 return show(i,embed,[new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select),back("adm-adm:menu")]);
}
export async function renderSysRoleType(i:any,type:SystemRoleType,notice?:string){
 if(!SYSTEM_ROLE_LABELS[type])return renderSysRolesMenu(i);
 const current=await prisma.systemRole.findUnique({where:{guildId_type:{guildId:i.guild.id,type}}});
 return rolePicker(i,SYSTEM_ROLE_LABELS[type],"Escolha um cargo que o bot possa atribuir. Vazio remove a associação. A seleção é salva automaticamente.",current?[current.roleId]:[],`adm-role-select:sysrole:${type}`,"adm-adm:sysroles",true,notice);
}
export default {customId:"adm-adm:",async execute(i:any){
 if(!i.guild)return;if(!await isBotAdmin(await i.guild.members.fetch(i.user.id)))return i.reply({content:"Você não possui permissão neste servidor.",ephemeral:true});
 const [,action,sub]=i.customId.split(":");await deferPanel(i);
 if(action==="root")return refreshPanel(i,await buildAdmRootPanel(i.guild,i.user));
 if(action==="botadmin")return renderBotAdmin(i);
 if(action==="permroles")return sub?renderPermRoleType(i,sub):renderPermRolesMenu(i);
 if(action==="sysroles")return sub?renderSysRoleType(i,sub):renderSysRolesMenu(i);
 return renderAdminMenu(i);
}};
