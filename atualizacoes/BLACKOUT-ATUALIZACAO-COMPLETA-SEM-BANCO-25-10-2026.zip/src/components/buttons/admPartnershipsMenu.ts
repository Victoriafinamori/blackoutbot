const { prepareAdminPanel } = require("../../utils/adminTasks");
import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonInteraction,
  ButtonStyle,
  ChannelSelectMenuBuilder,
  ChannelType,
  MessageComponentInteraction,
  ModalBuilder,
  RoleSelectMenuBuilder,
  TextInputBuilder,
  TextInputStyle,
} from "discord.js";
import { ButtonComponent } from "../../structures/types";
import { adminEmbed } from "../../utils/adminUi";
import { buildAdmSectionPanel } from "../../utils/admPanel";
import { isBotAdmin } from "../../utils/permissions";
import { ids, openingPanel, partnershipConfig, publishPartnershipPanel } from "../../utils/partnerships";
import { prisma } from "../../database/prisma";

const styleName = (value?: string | null) => ({ PRIMARY: "Azul", SECONDARY: "Cinza", SUCCESS: "Verde", DANGER: "Vermelho" }[String(value || "SUCCESS").toUpperCase()] || "Verde");

async function showPanelEditor(i:any){return require('../../utils/adminMessagePreview').showAdminMessagePreview(i,'parcerias');}

export async function renderPartnershipsMenu(i: MessageComponentInteraction) {
  const c = await partnershipConfig(i.guild!.id);
  const e = (await adminEmbed(i.guild!, "atendimento")).setColor(0xd71935).setTitle("🤝 Configurações — Parcerias").setDescription("Painel privado para receber, analisar e concluir propostas de parceria.")
    .addFields(
      { name: "ℹ️ Informações", value: `Status: ${c.enabled ? "✅ Ativado" : "❌ Desativado"}\nCanal do painel: ${c.panelChannelId ? `<#${c.panelChannelId}>` : "Não configurado"}\nCategoria: ${c.categoryId ? `<#${c.categoryId}>` : "Não configurada"}\nLogs: ${c.logChannelId ? `<#${c.logChannelId}>` : "Não configurado"}` },
      { name: "👮 Atendimento", value: `Cargos responsáveis: ${ids(c.staffRoleIds).map(x => `<@&${x}>`).join(", ") || "Não configurado"}\nCargo ao aprovar: ${c.partnerRoleId ? `<@&${c.partnerRoleId}>` : "Não configurado"}\nDivulgação: ${c.publishChannelId ? `<#${c.publishChannelId}>` : "Não configurada"}` },
      { name: "🎨 Painel", value: `Título: **${c.panelTitle}**\nBotão: ${c.panelButtonEmoji || ""} **${c.panelButtonLabel}** • ${styleName(c.panelButtonStyle)}` },
      { name: "📋 Requisitos", value: `Mínimo de membros: **${c.minMembers}**\nCooldown após recusa: **${c.cooldownDays} dia(s)**` },
    );
  const rows = [
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId("parceria-admin:toggle").setLabel(c.enabled ? "Desativar" : "Ativar").setStyle(c.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
      new ButtonBuilder().setCustomId("parceria-admin:channels").setLabel("Canais").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId("parceria-admin:roles").setLabel("Cargos").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId("parceria-admin:appearance").setLabel("Painel").setEmoji("🎨").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId("parceria-admin:requirements").setLabel("Requisitos").setStyle(ButtonStyle.Secondary),
    ),
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId("parceria-admin:publish").setLabel("Publicar/Atualizar").setEmoji("📨").setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId("parceria-admin:back").setLabel("Voltar").setStyle(ButtonStyle.Secondary),
    ),
  ];
  await i.update(prepareAdminPanel(i.guild, 'parcerias', { attachments: [], embeds: [e], components: rows }));
}

const component: ButtonComponent = { customId: "parceria-admin:", async execute(i: ButtonInteraction) {
  if (!i.guild) return;
  if (!(await isBotAdmin(await i.guild.members.fetch(i.user.id)))) return void await i.reply({ content: "Sem permissão.", ephemeral: true });
  const a = i.customId.split(":")[1];
        if (a === "channels" || a === "roles") return require("../../utils/panelInteraction").refreshPanel(i, await require("../../utils/partnershipSettings").partnershipSettingsPayload(i.guild,a));
  const c = await partnershipConfig(i.guild.id);
  if (a === "back") return void await i.update(await buildAdmSectionPanel(i.guild, "atendimento"));
  if (a === "toggle") { await prisma.partnershipConfig.update({ where: { guildId: i.guild.id }, data: { enabled: !c.enabled } }); return renderPartnershipsMenu(i); }
  if (a === "publish") { try { await publishPartnershipPanel(i.guild); await i.reply({ content: "✅ Painel publicado/atualizado.", ephemeral: true }); } catch (e) { await i.reply({ content: `❌ ${e instanceof Error ? e.message : "Erro ao publicar."}`, ephemeral: true }); } return; }
  if (a === "appearance") return void await showPanelEditor(i);
  if (a === "edit-embed") {
    const m = new ModalBuilder().setCustomId("parceria:appearance").setTitle("Embed de Parcerias").addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(new TextInputBuilder().setCustomId("title").setLabel("Título").setStyle(TextInputStyle.Short).setValue(c.panelTitle).setRequired(true)),
      new ActionRowBuilder<TextInputBuilder>().addComponents(new TextInputBuilder().setCustomId("description").setLabel("Descrição").setStyle(TextInputStyle.Paragraph).setValue(c.panelDescription).setMaxLength(2000).setRequired(true)),
      new ActionRowBuilder<TextInputBuilder>().addComponents(new TextInputBuilder().setCustomId("color").setLabel("Cor HEX").setStyle(TextInputStyle.Short).setValue(c.embedColor.replace("#", "")).setRequired(true)),
      new ActionRowBuilder<TextInputBuilder>().addComponents(new TextInputBuilder().setCustomId("footer").setLabel("Rodapé").setStyle(TextInputStyle.Short).setValue(c.embedFooter).setRequired(false)),
      new ActionRowBuilder<TextInputBuilder>().addComponents(new TextInputBuilder().setCustomId("assets").setLabel("THUMBNAIL=URL / IMAGEM=URL").setStyle(TextInputStyle.Paragraph).setValue(`THUMBNAIL=${c.embedThumbnail || ""}\nIMAGEM=${c.embedImage || ""}`).setRequired(false)),
    );
    return void await i.showModal(m);
  }
  if (a === "edit-button") {
    const m = new ModalBuilder().setCustomId("parceria:button").setTitle("Botão do Painel").addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(new TextInputBuilder().setCustomId("label").setLabel("Texto do botão").setStyle(TextInputStyle.Short).setMaxLength(80).setValue(c.panelButtonLabel || "Solicitar parceria").setRequired(true)),
      new ActionRowBuilder<TextInputBuilder>().addComponents(new TextInputBuilder().setCustomId("emoji").setLabel("Emoji (opcional)").setStyle(TextInputStyle.Short).setMaxLength(50).setValue(c.panelButtonEmoji || "").setRequired(false)),
      new ActionRowBuilder<TextInputBuilder>().addComponents(new TextInputBuilder().setCustomId("style").setLabel("Cor: AZUL, CINZA, VERDE ou VERMELHO").setStyle(TextInputStyle.Short).setValue(styleName(c.panelButtonStyle).toUpperCase()).setRequired(true)),
    );
    return void await i.showModal(m);
  }
  if (a === "channels") {
    const rows = [
      new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(new ChannelSelectMenuBuilder().setCustomId("parceria-admin-select:panel").setPlaceholder("Canal do painel").addChannelTypes(ChannelType.GuildText)),
      new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(new ChannelSelectMenuBuilder().setCustomId("parceria-admin-select:category").setPlaceholder("Categoria dos atendimentos").addChannelTypes(ChannelType.GuildCategory)),
      new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(new ChannelSelectMenuBuilder().setCustomId("parceria-admin-select:logs").setPlaceholder("Canal de logs").addChannelTypes(ChannelType.GuildText)),
      new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(new ChannelSelectMenuBuilder().setCustomId("parceria-admin-select:publish").setPlaceholder("Canal de divulgação").addChannelTypes(ChannelType.GuildText)),
    ];
    return void await i.reply({ content: "Configure os canais da Central de Parcerias:", components: rows, ephemeral: true });
  }
  if (a === "roles") {
    const rows = [
      new ActionRowBuilder<RoleSelectMenuBuilder>().addComponents(new RoleSelectMenuBuilder().setCustomId("parceria-admin-select:staff").setPlaceholder("Cargos responsáveis").setMinValues(1).setMaxValues(10)),
      new ActionRowBuilder<RoleSelectMenuBuilder>().addComponents(new RoleSelectMenuBuilder().setCustomId("parceria-admin-select:partner").setPlaceholder("Cargo concedido ao aprovar").setMinValues(1).setMaxValues(1)),
    ];
    return void await i.reply({ content: "Configure os cargos:", components: rows, ephemeral: true });
  }
  if (a === "requirements") {
    const m = new ModalBuilder().setCustomId("parceria:requirements").setTitle("Requisitos de Parceria").addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(new TextInputBuilder().setCustomId("minMembers").setLabel("Mínimo de membros (0 = sem mínimo)").setStyle(TextInputStyle.Short).setValue(String(c.minMembers)).setRequired(true)),
      new ActionRowBuilder<TextInputBuilder>().addComponents(new TextInputBuilder().setCustomId("cooldownDays").setLabel("Cooldown após recusa (dias)").setStyle(TextInputStyle.Short).setValue(String(c.cooldownDays)).setRequired(true)),
    );
    return void await i.showModal(m);
  }
} };
export default component;
