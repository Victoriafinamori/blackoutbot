import { ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelSelectMenuBuilder, ChannelType, ModalBuilder, StringSelectMenuBuilder, TextInputBuilder, TextInputStyle } from "discord.js";
import { adminEmbed } from "../../utils/adminUi";
import { isBotAdmin } from "../../utils/permissions";
import { prisma } from "../../database/prisma";
import { getOrCreateGuildConfig } from "../../database/guildConfig";
import { buildCustomEmbedMessage, fetchCustomEmbed, normalizeHex } from "../../utils/customEmbeds";
import { publicationHash, publicationState, hasMessageContent } from "../../utils/embedPublication";
import { writableChannel } from "../../utils/configurationChecks";
import { deferPanel, refreshPanel } from "../../utils/panelInteraction";
const button=(id:string,label:string,style=ButtonStyle.Secondary)=>new ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style);
const row=(...items:ButtonBuilder[])=>new ActionRowBuilder<ButtonBuilder>().addComponents(items);
const input=(id:string,label:string,value:string|null,max:number,paragraph=false,required=false)=>{
  const f=new TextInputBuilder().setCustomId(id).setLabel(label).setStyle(paragraph?TextInputStyle.Paragraph:TextInputStyle.Short).setRequired(required).setMaxLength(max);
  if(value)f.setValue(value);return new ActionRowBuilder<TextInputBuilder>().addComponents(f);
};
export async function renderEmbedHub(i:any){ return require("../../message-maker/interactions").openHome(i); }
export async function renderEmbedList(i:any,page=0){
  page=Math.max(0,Math.floor(Number(page)||0));
  const total=await prisma.customEmbed.count({where:{guildId:i.guild.id}});
  page=Math.min(page,Math.max(0,Math.ceil(total/25)-1));
  const records=await prisma.customEmbed.findMany({where:{guildId:i.guild.id},orderBy:{updatedAt:"desc"},skip:page*25,take:25});
  const rows:any[]=[];
  if(records.length)rows.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(new StringSelectMenuBuilder().setCustomId("embedv2-select:open").setPlaceholder("Escolha a mensagem para editar").addOptions(records.map(r=>({label:r.name.slice(0,100),value:r.id,description:(r.title||"Sem título").slice(0,100)})))));
  rows.push(row(button(`embedv2:list:${page-1}`,"Anterior").setDisabled(page===0),button(`embedv2:list:${page+1}`,"Próxima").setDisabled((page+1)*25>=total),button("embedv2:create","Nova mensagem",ButtonStyle.Primary)),row(button("embedv2:hub","Voltar")));
  return refreshPanel(i,{content:null,attachments:[],embeds:[adminEmbed(i.guild,"sistema").setTitle("Mensagens salvas").setDescription(total?"Escolha uma mensagem. As alterações ficam salvas no modelo antes da publicação.":"Você ainda não criou mensagens. Use Nova mensagem para começar.").setFooter({text:`Página ${page+1}/${Math.max(1,Math.ceil(total/25))} · ${total} mensagens`})],components:rows});
}
export async function buildEmbedEditorPayload(guild:any,record:any,requestedPage=0){
  const preview=buildCustomEmbedMessage(record,guild.id);
  const pages=Math.max(1,Math.ceil(preview.components.length/2));
  const page=Math.min(Math.max(0,Math.floor(Number(requestedPage)||0)),pages-1);
  const check=record.destinationChannelId?await writableChannel(guild,record.destinationChannelId):{issue:"Escolha um canal de destino."};
  const ready=hasMessageContent(record)&&!check.issue;
  const edit=new StringSelectMenuBuilder().setCustomId(`embedv2-edit-select:${record.id}`).setPlaceholder("Escolha uma parte da mensagem").addOptions(
    {label:"1. Conteúdo",value:"text",description:"Título, descrição, autor e rodapé"},
    {label:"2. Imagens e cor",value:"visual",description:"Imagem, miniatura, cor e data da mensagem"},
    {label:"3. Botões",value:"buttons",description:"Links e atalhos para canais"},
    {label:"4. Canal de destino",value:"destination",description:"Onde a mensagem será publicada"});
  const controls=[];
  if(pages>1)controls.push(button(`embedv2:editor:${record.id}:${page-1}`,"Botões anteriores").setDisabled(page===0),button(`embedv2:editor:${record.id}:${page+1}`,"Mais botões").setDisabled(page===pages-1));
  controls.push(button(`embedv2:publish:${record.id}`,record.publishedMessageId&&record.publishedChannelId===record.destinationChannelId?"Atualizar publicação":"Publicar",ButtonStyle.Primary).setDisabled(!ready),button(`embedv2:more:${record.id}`,"Mais opções"),button("embedv2:hub","Voltar"));
  const issues=[!hasMessageContent(record)?"Adicione um título, texto ou imagem antes de publicar.":null,check.issue].filter(Boolean);
  const destination=record.destinationChannelId?`<#${record.destinationChannelId}>`:"não definido";
  const buttonsNote=record.buttons.length>10?`\nBotões: página ${page+1}/${pages}. A publicação inclui todos os ${record.buttons.length}.`:"";
  const changeDestination=record.publishedMessageId&&record.publishedChannelId!==record.destinationChannelId?"\nO novo destino criará uma publicação lá; a mensagem anterior será preservada.":"";
  return {content:`**Editar · ${record.name}**\n${publicationState(record)} · Destino: ${destination}${buttonsNote}${changeDestination}${issues.length?"\n"+issues.join(" "):""}`.slice(0,1800),attachments:[],embeds:preview.embeds,
    components:[...preview.components.slice(page*2,page*2+2),new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(edit),row(button(`embedv2:preview:${record.id}`,"Ver prévia")),row(...controls)],allowedMentions:{parse:[]}};
}
export function buildEmbedPreviewPayload(guild:any,record:any,requestedPage=0){
  const preview=buildCustomEmbedMessage(record,guild.id);
  const pages=Math.max(1,Math.ceil(preview.components.length/2));
  const page=Math.min(Math.max(0,Math.floor(Number(requestedPage)||0)),pages-1);
  const controls=[];
  if(pages>1)controls.push(button(`embedv2:preview:${record.id}:${page-1}`,"Botões anteriores").setDisabled(page===0),button(`embedv2:preview:${record.id}:${page+1}`,"Mais botões").setDisabled(page===pages-1));
  controls.push(button(`embedv2:editor:${record.id}`,"Voltar ao editor"));
  return {content:`**Prévia · ${record.name}**${pages>1?`\nBotões: página ${page+1}/${pages}.`:""}`,attachments:[],embeds:preview.embeds,
    components:[...preview.components.slice(page*2,page*2+2),row(...controls)],allowedMentions:{parse:[]}};
}
export async function renderEmbedEditor(i:any,id:string,page=0){
  await deferPanel(i);
  const record=await fetchCustomEmbed(id,i.guild.id);
  if(!record)return renderEmbedHub(i);
  return refreshPanel(i,await buildEmbedEditorPayload(i.guild,record,page));
}
export async function renderEmbedButtons(i:any,id:string){
  const record=await fetchCustomEmbed(id,i.guild.id);if(!record)return renderEmbedHub(i);
  const preview=buildCustomEmbedMessage(record,i.guild.id),rows:any[]=[...preview.components.slice(0,2)];
  if(record.buttons.length)rows.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(new StringSelectMenuBuilder().setCustomId(`embedv2-btn-select:${id}`).setPlaceholder("Editar, mover ou remover um botão").addOptions(record.buttons.slice(0,25).map((b,n)=>({label:`${n+1}. ${b.label}`.slice(0,100),value:b.id,description:b.type==="CHANNEL"?"Canal do Discord":"Link externo"})))));
  rows.push(row(button(`embedv2:add-link:${id}`,"Adicionar link",ButtonStyle.Primary).setDisabled(record.buttons.length>=25),button(`embedv2:add-channel:${id}`,"Adicionar canal").setDisabled(record.buttons.length>=25),button(`embedv2:editor:${id}`,"Voltar")));
  return refreshPanel(i,{content:`**Botões · ${record.name}**\n${publicationState(record)} · ${record.buttons.length}/25 botões salvos.${record.buttons.length>10?" Os primeiros dez aparecem aqui; todos serão publicados.":""}`,attachments:[],embeds:preview.embeds,components:rows,allowedMentions:{parse:[]}});
}
export async function openEmbedPart(i:any,record:any,action:string){
  const id=record.id;
  if(action==="text")return i.showModal(new ModalBuilder().setCustomId(`embedv2-modal:text:${id}`).setTitle("Conteúdo da mensagem").addComponents(input("title","Título",record.title,256),input("description","Descrição",record.description,4000,true),input("author","Autor — vazio para remover",record.author,256),input("footer","Rodapé — vazio para remover",record.footer,1000)));
  if(action==="visual")return i.showModal(new ModalBuilder().setCustomId(`embedv2-modal:visual:${id}`).setTitle("Imagens e cor").addComponents(input("color","Cor hexadecimal",normalizeHex(record.color),7,false,true),input("image","URL da imagem — vazio para remover",record.imageUrl,500),input("thumbnail","URL da miniatura — vazio para remover",record.thumbnailUrl,500),input("timestamp","Mostrar data/hora? sim ou não",record.showTimestamp?"sim":"não",3,false,true)));
  if(action==="buttons")return renderEmbedButtons(i,id);
  if(action==="destination"){
    const select=new ChannelSelectMenuBuilder().setCustomId(`embedv2-channel:destination:${id}`).setPlaceholder("Canal onde a mensagem será publicada").addChannelTypes(ChannelType.GuildText,ChannelType.GuildAnnouncement).setMinValues(1).setMaxValues(1);
    if(record.destinationChannelId&&i.guild.channels.cache.has(record.destinationChannelId))select.setDefaultChannels([record.destinationChannelId]);
    return refreshPanel(i,{content:`**Canal de destino · ${record.name}**\nA escolha será conferida antes de salvar.`,attachments:[],embeds:buildCustomEmbedMessage(record,i.guild.id).embeds,components:[new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(select),row(button(`embedv2:editor:${id}`,"Voltar"))],allowedMentions:{parse:[]}});
  }
}
export default {customId:"embedv2:",async execute(i:any){
  if(!i.guild||!await isBotAdmin(await i.guild.members.fetch(i.user.id)))return i.reply({content:"Você não possui permissão neste servidor.",ephemeral:true});
  const [,action,id,extra]=i.customId.split(":");
  if(action==="hub")return renderEmbedHub(i);
  if(action==="list")return renderEmbedList(i,Number(id)||0);
  if(action==="create"){
    await deferPanel(i);await getOrCreateGuildConfig(i.guild.id);
    const record=await prisma.customEmbed.create({data:{guildId:i.guild.id,createdById:i.user.id,name:"Nova mensagem",color:"D71935"}});
    return renderEmbedEditor(i,record.id);
  }
  const record=id?await fetchCustomEmbed(id,i.guild.id):null;if(!record)return renderEmbedHub(i);
  if(action==="editor")return renderEmbedEditor(i,id,Number(extra)||0);
  if(action==="preview"){await deferPanel(i);return refreshPanel(i,buildEmbedPreviewPayload(i.guild,record,Number(extra)||0));}
  if(["text","visual","buttons","destination"].includes(action))return openEmbedPart(i,record,action);
  if(action==="publish"){
    if(!hasMessageContent(record))return i.reply({content:"Adicione um título, texto ou imagem antes de publicar.",ephemeral:true});
    if(!record.destinationChannelId)return i.reply({content:"Escolha primeiro o canal de destino.",ephemeral:true});
    await deferPanel(i);
    const check=await writableChannel(i.guild,record.destinationChannelId);if(check.issue)return refreshPanel(i,await buildEmbedEditorPayload(i.guild,record));
    const channel=check.channel!;const payload=buildCustomEmbedMessage(record,i.guild.id);let message:any=null;
    try{
      if(record.publishedMessageId&&record.publishedChannelId===record.destinationChannelId){
        try{message=await channel.messages.fetch(record.publishedMessageId);}catch(error:any){if(error.code!==10008)throw error;}
        if(message)await message.edit(payload);
      }
      if(!message)message=await channel.send(payload);
      await prisma.customEmbed.update({where:{id},data:{publishedChannelId:channel.id,publishedMessageId:message.id,publishedPayloadHash:publicationHash(record)}});
      return renderEmbedEditor(i,id);
    }catch{
      return i.followUp({content:"Não foi possível concluir a publicação. Confira o canal e tente novamente; o modelo continua salvo.",ephemeral:true});
    }
  }
  if(action==="more")return refreshPanel(i,{content:`**Mais opções · ${record.name}**`,attachments:[],embeds:buildCustomEmbedMessage(record,i.guild.id).embeds,components:[row(button(`embedv2:rename:${id}`,"Renomear"),button(`embedv2:clone:${id}`,"Duplicar"),button(`embedv2:delete:${id}`,"Excluir",ButtonStyle.Danger)),row(button(`embedv2:editor:${id}`,"Voltar"))],allowedMentions:{parse:[]}});
  if(action==="rename")return i.showModal(new ModalBuilder().setCustomId(`embedv2-modal:rename:${id}`).setTitle("Nome da mensagem").addComponents(input("name","Nome interno",record.name,80,false,true)));
  if(action==="clone"){
    await deferPanel(i);
    const clone=await prisma.customEmbed.create({data:{guildId:record.guildId,createdById:i.user.id,name:`${record.name} — Cópia`.slice(0,80),title:record.title,description:record.description,author:record.author,footer:record.footer,color:record.color,imageUrl:record.imageUrl,thumbnailUrl:record.thumbnailUrl,showTimestamp:record.showTimestamp,buttons:{create:record.buttons.map((b,n)=>({type:b.type,label:b.label,emoji:b.emoji,url:b.url,channelId:b.channelId,position:n}))}}});
    return renderEmbedEditor(i,clone.id);
  }
  if(action==="delete")return refreshPanel(i,{content:null,attachments:[],embeds:[adminEmbed(i.guild,"sistema").setTitle("Excluir mensagem salva?").setDescription(`O modelo **${record.name}** será excluído. A mensagem já publicada no servidor será preservada.`)],components:[row(button(`embedv2:delete-confirm:${id}`,"Excluir modelo",ButtonStyle.Danger),button(`embedv2:editor:${id}`,"Cancelar"))]});
  if(action==="delete-confirm"){await deferPanel(i);await prisma.customEmbed.delete({where:{id}});return renderEmbedHub(i);}
  if(action==="add-link")return i.showModal(new ModalBuilder().setCustomId(`embedv2-modal:add-link:${id}`).setTitle("Botão de link").addComponents(input("label","Texto do botão",null,80,false,true),input("emoji","Emoji opcional",null,50),input("url","Link https://...",null,500,false,true)));
  if(action==="add-channel")return refreshPanel(i,{content:`**Adicionar botão de canal · ${record.name}**`,attachments:[],embeds:buildCustomEmbedMessage(record,i.guild.id).embeds,components:[new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(new ChannelSelectMenuBuilder().setCustomId(`embedv2-channel:addbutton:${id}`).setPlaceholder("Escolha o canal do botão").addChannelTypes(ChannelType.GuildText,ChannelType.GuildAnnouncement,ChannelType.GuildForum,ChannelType.GuildVoice,ChannelType.GuildStageVoice).setMinValues(1).setMaxValues(1)),row(button(`embedv2:buttons:${id}`,"Voltar"))],allowedMentions:{parse:[]}});
}};
