import { player } from "../../bingo/communityInteractions";
export default { customId: "bg:", execute: player };
