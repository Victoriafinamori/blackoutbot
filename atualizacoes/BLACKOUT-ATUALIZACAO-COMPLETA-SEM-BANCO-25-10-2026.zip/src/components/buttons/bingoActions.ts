import { ButtonInteraction } from "discord.js";
import { ButtonComponent } from "../../structures/types";
import { isBotAdmin } from "../../utils/permissions";
import {
  checkWinningCard,
  drawNumber,
  endMatch,
  getAllActiveCardsForPlayer,
  getCurrentMatch,
  getDraws,
  getPlayerCards,
  pauseMatch,
  recordWinnerAttempt,
  resumeMatch,
} from "../../bingo/service";
import {
  buildAnimationFrame,
  buildBingoPanel,
  buildBingoValidEmbed,
  buildCardsDeliveryDM,
  buildDrawResultFrame,
  buildEncerrarConfirm,
  buildHistoryEmbed,
} from "../../bingo/views";
import { BINGO_IDS } from "../../bingo/types";

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

async function requireStaff(interaction: ButtonInteraction) {
  const member = await interaction.guild!.members.fetch(interaction.user.id);
  const ok = await isBotAdmin(member);
  if (!ok)
    await interaction.reply({
      content: "🚫 Apenas a staff pode controlar a partida.",
      ephemeral: true,
    });
  return ok;
}

const component: ButtonComponent = {
  customId: "bingo:",

  async execute(interaction: ButtonInteraction) {
    if (!interaction.guild) return;
    const guildId = interaction.guild.id;

    // A compra de cartelas agora é feita pelo select "bingo:comprar-select"
    // (ver src/components/selects/bingoCardsSelect.ts) — não é mais um botão.

    // --- REENVIAR CARTELAS (qualquer pessoa; funciona com ou sem partida) ---
    if (interaction.customId === BINGO_IDS.reenviarCartelas) {
      const cards = await getAllActiveCardsForPlayer(
        guildId,
        interaction.user.id,
      );
      if (!cards.length) {
        await interaction.reply({
          content: "❌ Você ainda não possui cartelas para a próxima partida.",
          ephemeral: true,
        });
        return;
      }

      const dmSent = await interaction.user
        .send({
          content: `🎫 Suas cartelas do Bingo (${cards.length}):`,
          embeds: buildCardsDeliveryDM(cards),
        })
        .then(() => true)
        .catch(() => false);

      await interaction.reply({
        content: dmSent
          ? `✅ Reenviei suas ${cards.length} cartela${cards.length > 1 ? "s" : ""} na sua DM.`
          : "Não consegui enviar a DM. Consulte suas cartelas aqui no servidor pelo botão abaixo.",
        ephemeral: true,
        components: !dmSent
          ? [
              require("../../games-chat/experience/common").row(
                require("../../games-chat/experience/common").button(
                  "bingo-card-view:0",
                  "Ver minhas cartelas aqui",
                ),
              ),
            ]
          : [],
      });
      return;
    }

    const match = await getCurrentMatch(guildId);
    if (!match) {
      await interaction.reply({
        content:
          "❌ Não há nenhuma partida em andamento. Use `/bingo iniciar`.",
        ephemeral: true,
      });
      return;
    }

    if (
      interaction.message.id !== match.messageId ||
      interaction.channelId !== match.channelId
    ) {
      await interaction.reply({
        content:
          "Este painel pertence a outra partida. Abra a mensagem da partida atual.",
        ephemeral: true,
      });
      return;
    }
    // --- HISTÓRICO (qualquer pessoa) ---
    if (interaction.customId === BINGO_IDS.historico) {
      const draws = await getDraws(match.id);
      await interaction.reply({
        embeds: [buildHistoryEmbed(draws)],
        ephemeral: true,
      });
      return;
    }

    // --- BINGO (qualquer jogador) ---
    // CRÍTICO: um jogador pode ter várias cartelas na mesma partida (1, 3,
    // 10...). É preciso checar TODAS as cartelas dele, não só a primeira
    // encontrada — basta UMA delas ter uma combinação vencedora.
    if (interaction.customId === BINGO_IDS.jogarBingo) {
      const cards = await getPlayerCards(
        guildId,
        match.id,
        interaction.user.id,
      );
      if (!cards.length) {
        await interaction.reply({
          content:
            "❌ Você não possui nenhuma cartela cadastrada para esta partida.",
          ephemeral: true,
        });
        return;
      }

      const draws = await getDraws(match.id);
      const drawnNumbers = new Set<number>(
        draws.map((d: { number: number }) => d.number),
      );

      // Fonte de verdade: os números salvos no banco de cada cartela — a
      // imagem/embed nunca é consultada aqui.
      const winningCards = cards.filter((c) =>
        checkWinningCard(
          JSON.parse(c.numbers) as (number | null)[],
          drawnNumbers,
        ),
      );

      for (const c of cards) {
        await recordWinnerAttempt(
          match.id,
          c.id,
          interaction.user.id,
          winningCards.includes(c),
        );
      }

      if (!winningCards.length) {
        await interaction.reply({
          content:
            cards.length > 1
              ? `❌ BINGO inválido.\nNenhuma das suas ${cards.length} cartelas possui uma combinação vencedora neste momento.`
              : "❌ BINGO inválido.\nSua cartela ainda não possui uma combinação vencedora.",
          ephemeral: true,
        });
        return;
      }

      const paused = await pauseMatch(match.id);
      await interaction.update(buildBingoPanel(paused, draws));
      await interaction.followUp({
        embeds: [
          buildBingoValidEmbed(
            interaction.user.id,
            winningCards.map((c) => c.cardNumber),
          ),
        ],
      });
      return;
    }

    // --- Ações restritas à staff ---
    if (!(await requireStaff(interaction))) return;

    if (interaction.customId === BINGO_IDS.pausar) {
      const updated = await pauseMatch(match.id);
      const draws = await getDraws(match.id);
      await interaction.update(buildBingoPanel(updated, draws));
      return;
    }

    if (interaction.customId === BINGO_IDS.retomar) {
      const updated = await resumeMatch(match.id);
      const draws = await getDraws(match.id);
      await interaction.update(buildBingoPanel(updated, draws));
      return;
    }

    if (interaction.customId === BINGO_IDS.encerrar) {
      await interaction.update(buildEncerrarConfirm());
      return;
    }

    if (interaction.customId === BINGO_IDS.encerrarCancelar) {
      const draws = await getDraws(match.id);
      await interaction.update(buildBingoPanel(match, draws));
      return;
    }

    if (interaction.customId === BINGO_IDS.encerrarConfirmar) {
      const ended = await endMatch(match.id);
      const draws = await getDraws(match.id);
      await interaction.update(buildBingoPanel(ended, draws));
      return;
    }

    if (interaction.customId === BINGO_IDS.sortear) {
      if (match.status !== "EM_ANDAMENTO") {
        await interaction.reply({
          content: "❌ A partida precisa estar em andamento para sortear.",
          ephemeral: true,
        });
        return;
      }

      let draw;
      try {
        draw = await drawNumber(match.id);
      } catch (error) {
        await interaction.reply({
          content: `❌ ${error instanceof Error ? error.message : "Não foi possível sortear."}`,
          ephemeral: true,
        });
        return;
      }

      await interaction.deferUpdate();
      await interaction.editReply(buildAnimationFrame("**Sorteando...**"));
      await sleep(500);
      await interaction.editReply(buildAnimationFrame(`**${draw.letter}...**`));
      await sleep(500);

      const draws = await getDraws(match.id);
      await interaction.editReply(
        buildDrawResultFrame(draw.letter as any, draw.number, draws.length),
      );
      await sleep(900);

      await interaction.editReply(buildBingoPanel(match, draws));
      return;
    }
  },
};

export default component;
