import { isBotAdmin } from "../../utils/permissions";
import { deferPanel } from "../../utils/panelInteraction";
import { adminEmbed } from "../../utils/adminUi";
import { readLogSettings, saveLogSettings } from "../../logging/config";
import { deliverLog } from "../../logging/delivery";
import { renderLogHome,renderLogEvents,renderLogDestination,externalModal,renderLogOrganization,renderLogFilters,renderLogDiagnostic,renderLogTechnicalDiagnostic,renderLogHelp,renderModuleLogLinks,openModuleLogLink } from "../../logging/panel";
export default {customId:"logs-center:",async execute(i:any){
 if(!i.guild||!await isBotAdmin(await i.guild.members.fetch(i.user.id)))return i.reply({content:"Você não possui permissão neste servidor.",ephemeral:true});
 const [,action,scope,section]=i.customId.split(":");
 if(action==="external")return externalModal(i);
 await deferPanel(i);
 if(action==="events")return renderLogEvents(i,scope);
 if(action==="destination")return renderLogDestination(i);
 if(action==="organization")return renderLogOrganization(i,scope,section);
 if(action==="diagnostic")return renderLogDiagnostic(i);
 if(action==="diagnostic-details")return renderLogTechnicalDiagnostic(i);
 if(action==="help")return renderLogHelp(i,scope);
 if(action==="modules")return renderModuleLogLinks(i);
 if(action==="module")return openModuleLogLink(i,scope);
 if(action==="filters")return renderLogFilters(i);
 if(action==="toggle-bots"){const s=await readLogSettings(i.guild.id,true);await saveLogSettings(i.guild.id,{ignoreBots:!s.ignoreBots});return renderLogFilters(i,"Filtro salvo neste servidor.")}
 if(action==="test"||action==="test-external"){
  const result=await deliverLog(i.guild,"system.actions",adminEmbed(i.guild,"seguranca").setTitle("Teste da central de logs").setDescription(`Solicitado por ${i.user.id}. Este é um evento de teste.`),{},true,action==="test-external"?"EXTERNAL":undefined);
  const notice=`${result.sent} destinos receberam o teste.${result.errors.length?" "+result.errors.join(" "):""}`;
  return action==="test-external"?renderLogDestination(i,notice):renderLogDiagnostic(i,notice);
 }
 return renderLogHome(i);
}};
