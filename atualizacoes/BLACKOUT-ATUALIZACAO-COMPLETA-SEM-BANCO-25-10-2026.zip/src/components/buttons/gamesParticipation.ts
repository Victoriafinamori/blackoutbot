import { player } from "../../games-chat/experience/hub";
export default { customId: "play:", execute: player };
