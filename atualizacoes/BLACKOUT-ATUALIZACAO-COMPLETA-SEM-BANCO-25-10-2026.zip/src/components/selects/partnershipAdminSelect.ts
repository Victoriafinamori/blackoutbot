import { ChannelType, PermissionFlagsBits } from 'discord.js';
import { prisma } from '../../database/prisma';
import { isBotAdmin } from '../../utils/permissions';
import { registrationRoleError } from '../../utils/registrationSettings';
import { partnershipSettingsPayload } from '../../utils/partnershipSettings';
import { deferPanel, refreshPanel } from '../../utils/panelInteraction';
const component={customId:'parceria-admin-select:',async execute(i:any){
  if(!i.guild||!await isBotAdmin(await i.guild.members.fetch(i.user.id)))return;
  const a=i.customId.split(':')[1],keys:Record<string,string>={panel:'panelChannelId',category:'categoryId',logs:'logChannelId',publish:'publishChannelId',staff:'staffRoleIds',partner:'partnerRoleId'};
  if(!keys[a])return;
  if(['staff','partner'].includes(a)){const error=await registrationRoleError(i.guild,i.values,a==='partner');if(error)return i.reply({content:error,ephemeral:true})}
  else if(i.values[0]){const c=await i.guild.channels.fetch(i.values[0]).catch(()=>null);if(!c||c.guild.id!==i.guild.id||c.type!==(a==='category'?ChannelType.GuildCategory:ChannelType.GuildText))return i.reply({content:'Escolha um canal válido deste servidor.',ephemeral:true});if(a!=='category'&&!c.permissionsFor(i.guild.members.me)?.has([PermissionFlagsBits.ViewChannel,PermissionFlagsBits.SendMessages,PermissionFlagsBits.EmbedLinks]))return i.reply({content:'O bot precisa ver o canal, enviar mensagens e inserir links/embeds.',ephemeral:true})}
  await deferPanel(i);await prisma.partnershipConfig.update({where:{guildId:i.guild.id},data:{[keys[a]]:a==='staff'?JSON.stringify(i.values):i.values[0]||null}});
  return refreshPanel(i,await partnershipSettingsPayload(i.guild,['staff','partner'].includes(a)?'roles':'channels'));
}};
export default component;
