import { dispatchAdminTask } from '../../utils/adminTasks';
import { SelectMenuComponent } from '../../structures/types';
const component:SelectMenuComponent={customId:'admin-task:',async execute(i:any){
  if(!i.isStringSelectMenu())return;
  await dispatchAdminTask(i,i.customId.slice('admin-task:'.length),i.values[0]);
}};
export default component;
