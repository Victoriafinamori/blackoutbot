import { AnySelectMenuInteraction, ChannelType } from "discord.js";
import { SelectMenuComponent } from "../../structures/types";
import { isBotAdmin } from "../../utils/permissions";
import { buildAdmSectionPanel } from "../../utils/admPanel";
import { createMatch, getCurrentMatch, getDraws, pauseMatch, resumeMatch, setMatchMessage, updateBingoConfig } from "../../bingo/service";
import { buildBingoPanel, publishCardPanel, refreshMatchPanel } from "../../bingo/views";
import { renderBingoCardsChannel, renderBingoEndConfirm, renderBingoMenu, renderBingoStart } from "../buttons/admBingoMenu";

const nav: SelectMenuComponent = {
  customId: "bingo-admin-nav",
  async execute(i: AnySelectMenuInteraction) {
    if (!i.guild || !i.isStringSelectMenu()) return;
    if (!(await isBotAdmin(await i.guild.members.fetch(i.user.id)))) {
      await i.reply({ content: "🚫 Sem permissão.", ephemeral: true });
      return;
    }

    const value = i.values[0];

    if (value === "back") return void (await i.update(await buildAdmSectionPanel(i.guild, "staff")));
    if (value === "start") return renderBingoStart(i);
    if (value === "cards") return renderBingoCardsChannel(i);
    if (value === "end") return renderBingoEndConfirm(i);

    if (value === "toggle") {
      const match = await getCurrentMatch(i.guild.id);
      if (!match) return renderBingoMenu(i);
      if (match.status === "PAUSADA") await resumeMatch(match.id);
      else await pauseMatch(match.id);
      await refreshMatchPanel(i.guild);
      return renderBingoMenu(i);
    }
  },
};

const startChannel: SelectMenuComponent = {
  customId: "bingo-admin-start-channel",
  async execute(i: AnySelectMenuInteraction) {
    if (!i.guild || !i.isChannelSelectMenu()) return;
    if (!(await isBotAdmin(await i.guild.members.fetch(i.user.id)))) {
      await i.reply({ content: "🚫 Sem permissão.", ephemeral: true });
      return;
    }

    const existing = await getCurrentMatch(i.guild.id);
    if (existing) {
      await i.reply({ content: `❌ Já existe uma partida em andamento (**PARTIDA #${String(existing.number).padStart(3, "0")}**). Encerre-a antes de iniciar outra.`, ephemeral: true });
      return;
    }

    const channelId = i.values[0];
    const channel = await i.guild.channels.fetch(channelId).catch(() => null);
    if (!channel?.isTextBased() || channel.isDMBased()) {
      await i.reply({ content: "❌ Canal inválido.", ephemeral: true });
      return;
    }

    const match = await createMatch(i.guild.id, channelId, i.user.id);
    const draws = await getDraws(match.id);
    const message = await channel.send(buildBingoPanel(match, draws));
    await setMatchMessage(match.id, message.id);

    await renderBingoMenu(i);
  },
};

const cardsChannel: SelectMenuComponent = {
  customId: "bingo-admin-cards-channel",
  async execute(i: AnySelectMenuInteraction) {
    if (!i.guild || !i.isChannelSelectMenu()) return;
    if (!(await isBotAdmin(await i.guild.members.fetch(i.user.id)))) {
      await i.reply({ content: "🚫 Sem permissão.", ephemeral: true });
      return;
    }

    try {
      await publishCardPanel(i.guild, i.values[0]);
    } catch (error) {
      await i.reply({ content: `❌ ${error instanceof Error ? error.message : "Não foi possível publicar o painel."}`, ephemeral: true });
      return;
    }

    await renderBingoMenu(i);
  },
};

const cardsCategory: SelectMenuComponent = {
  customId: "bingo-admin-cards-category",
  async execute(i: AnySelectMenuInteraction) {
    if (!i.guild || !i.isChannelSelectMenu()) return;
    if (!(await isBotAdmin(await i.guild.members.fetch(i.user.id)))) {
      await i.reply({ content: "🚫 Sem permissão.", ephemeral: true });
      return;
    }

    const categoryId = i.values[0];
    const category = await i.guild.channels.fetch(categoryId).catch(() => null);
    if (!category || category.type !== ChannelType.GuildCategory) {
      await i.reply({ content: "❌ Selecione uma categoria válida.", ephemeral: true });
      return;
    }

    await updateBingoConfig(i.guild.id, { cardTicketCategoryId: categoryId });
    await renderBingoCardsChannel(i);
  },
};

const handlers: Record<string, SelectMenuComponent> = {
  "bingo-admin-nav": nav,
  "bingo-admin-start-channel": startChannel,
  "bingo-admin-cards-channel": cardsChannel,
  "bingo-admin-cards-category": cardsCategory,
};

const component: SelectMenuComponent = {
  customId: "bingo-admin-",
  async execute(i: AnySelectMenuInteraction) {
    const handler = handlers[i.customId];
    if (handler) await handler.execute(i);
  },
};

export default component;
