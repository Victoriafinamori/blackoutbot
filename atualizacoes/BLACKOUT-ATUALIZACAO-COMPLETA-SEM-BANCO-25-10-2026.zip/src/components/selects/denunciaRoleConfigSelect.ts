import { AnySelectMenuInteraction, MessageFlags } from "discord.js";
import { SelectMenuComponent } from "../../structures/types";
import { prisma } from "../../database/prisma";
import { isBotAdmin } from "../../utils/permissions";
const component: SelectMenuComponent = { customId: "denuncia-role:", async execute(i: AnySelectMenuInteraction) {
  if (!i.guild || !(await isBotAdmin(await i.guild.members.fetch(i.user.id)))) return;
  const key = i.customId.split(":")[1];
  if (key !== "staffRoleIds") return void await i.reply({ content: "Configuração de cargo inválida.", flags: MessageFlags.Ephemeral });
  await prisma.reportConfig.upsert({ where: { guildId: i.guild.id }, create: { guildId: i.guild.id, staffRoleIds: i.values.join(",") || null }, update: { staffRoleIds: i.values.join(",") || null } });
  return require("../buttons/admDenunciasMenu").renderDenunciasRoles(i);
} };
export default component;
