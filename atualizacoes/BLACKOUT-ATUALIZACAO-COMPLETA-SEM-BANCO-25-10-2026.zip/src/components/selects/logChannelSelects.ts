import { readLogSettings,saveLogSettings } from "../../logging/config";
import { SelectMenuComponent } from "../../structures/types";
import { isBotAdmin } from "../../utils/permissions";
import { prisma } from "../../database/prisma";
import { writableChannel } from "../../utils/configurationChecks";
import { deferPanel } from "../../utils/panelInteraction";
import { LOG_CHANNEL_FIELDS, renderLogChannelPicker } from "../buttons/admLogsMenu";
const component:SelectMenuComponent={customId:"adm-logchannel-select:",async execute(i){
  if(!i.guild||!i.isChannelSelectMenu()||!await isBotAdmin(await i.guild.members.fetch(i.user.id)))return;
  const key=i.customId.split(":")[1],field=LOG_CHANNEL_FIELDS[key];if(!field)return;
  const id=i.values[0]??null;
  if(id){const check=await writableChannel(i.guild,id);if(check.issue)return void await i.reply({content:check.issue,ephemeral:true});}
  await deferPanel(i);
  await prisma.guildConfig.update({where:{guildId:i.guild.id},data:{[field.column]:id}});
  if(key!=="geral"){
    const groups:Record<string,string>={moderacao:"moderation",seguranca:"security",reintegracao:"reintegration",sistema:"system"};
    const settings=await readLogSettings(i.guild.id,true);await saveLogSettings(i.guild.id,{localChannelsJson:JSON.stringify({...settings.localChannels,[groups[key]]:id})});
  }
  return renderLogChannelPicker(i,key,"Canal salvo neste servidor.");
}};export default component;
