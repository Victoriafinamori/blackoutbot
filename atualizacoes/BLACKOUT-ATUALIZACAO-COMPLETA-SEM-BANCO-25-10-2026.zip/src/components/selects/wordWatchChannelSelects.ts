import { deferPanel } from "../../utils/panelInteraction";
import { AnySelectMenuInteraction } from "discord.js";
import { SelectMenuComponent } from "../../structures/types";
import { isBotAdmin } from "../../utils/permissions";
import { logAdminAction } from "../../utils/adminLog";
import { AdminLogAction } from "../../structures/enums";
import { setWordWatchChannelIds, MAX_WORD_WATCH_CHANNELS } from "../../utils/wordWatch";
import { renderFiltersWordWatch } from "../buttons/admModerationMenu";

const component: SelectMenuComponent = {
  customId: "adm-watchchannel-select",

  async execute(interaction: AnySelectMenuInteraction) {
    if (!interaction.guild || !interaction.isChannelSelectMenu()) return;

    const member = await interaction.guild.members.fetch(interaction.user.id);
    if (!(await isBotAdmin(member))) {
      await interaction.reply({ content: "🚫 Você não tem permissão para realizar esta ação.", ephemeral: true });
      return;
    }

    const channelIds = interaction.values.slice(0, MAX_WORD_WATCH_CHANNELS);
    for(const id of channelIds){
      const channel=await interaction.guild.channels.fetch(id).catch(()=>null);
      if(!channel||channel.guildId!==interaction.guild.id||channel.type!==0){await interaction.reply({content:"Escolha canais de texto deste servidor.",ephemeral:true});return;}
    }
    await deferPanel(interaction);
    await setWordWatchChannelIds(interaction.guild.id, channelIds);

    await logAdminAction({
      guild: interaction.guild,
      actorId: interaction.user.id,
      action: AdminLogAction.MODERATION_CONFIG_CHANGED,
      details: channelIds.length
        ? `Canais monitorados (Monitoramento de Palavras): ${channelIds.map((id) => `<#${id}>`).join(", ")}`
        : "Canais monitorados (Monitoramento de Palavras) limpos.",
    });

    await renderFiltersWordWatch(interaction);
  },
};

export default component;
