import { isBotAdmin } from '../../utils/permissions';
const component={customId:'radio-mode-select',async execute(i:any){
  if(!i.guild||!i.isStringSelectMenu()||!await isBotAdmin(await i.guild.members.fetch(i.user.id)))return;
  if(!['SEQUENTIAL','RANDOM'].includes(i.values[0]))return;
  await i.deferUpdate();await require('../../../app/radio/service').setRadioMode(i.guild.id,i.values[0]);
  await i.editReply(await require('../../../app/components/buttons/admRadioMenu').buildRadioMainView(i.guild));
}};
export default component;
