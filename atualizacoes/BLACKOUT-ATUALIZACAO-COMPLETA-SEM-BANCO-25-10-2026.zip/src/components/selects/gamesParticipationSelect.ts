import { select } from "../../games-chat/experience/hub";
export default { customId: "games-select:", execute: select };
