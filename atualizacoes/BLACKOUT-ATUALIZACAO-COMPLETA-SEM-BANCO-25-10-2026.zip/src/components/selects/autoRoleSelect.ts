import { SelectMenuComponent } from "../../structures/types";
import { prisma } from "../../database/prisma";
import { getOrCreateGuildConfig } from "../../database/guildConfig";
import { isBotAdmin } from "../../utils/permissions";
import { autoRoleIssues } from "../../utils/configurationChecks";
import { deferPanel } from "../../utils/panelInteraction";
import { renderAutoRoleMenu } from "../buttons/admConfigMenu";
const component:SelectMenuComponent={customId:"auto-role-select:",async execute(i){
  if(!i.guild||!i.isRoleSelectMenu()||!await isBotAdmin(await i.guild.members.fetch(i.user.id)))return;
  const ids=[...new Set(i.values)];
  const issues=autoRoleIssues(i.guild,ids);
  if(issues.length)return renderAutoRoleMenu(i,"A seleção não foi salva. "+issues.join(" "));
  await deferPanel(i);await getOrCreateGuildConfig(i.guild.id);
  await prisma.guildConfig.update({where:{guildId:i.guild.id},data:{autoRoleIds:ids.length?ids.join(","):null,...(!ids.length?{autoRoleEnabled:false}:{})}});
  return renderAutoRoleMenu(i,"Cargos salvos. A seleção atual já aparece neste painel.");
}};export default component;
