import { SelectMenuComponent } from "../../structures/types";
import { isBotAdmin } from "../../utils/permissions";
import { fetchCustomEmbed } from "../../utils/customEmbeds";
import { openEmbedPart } from "../buttons/admEmbedV2Menu";
const component:SelectMenuComponent={customId:"embedv2-edit-select:",async execute(i){
  if(!i.guild||!i.isStringSelectMenu()||!await isBotAdmin(await i.guild.members.fetch(i.user.id)))return;
  if(!["text","visual","buttons","destination"].includes(i.values[0]))return;
  const record=await fetchCustomEmbed(i.customId.split(":")[1],i.guild.id);
  if(!record)return void await i.reply({content:"Mensagem não encontrada neste servidor.",ephemeral:true});
  return openEmbedPart(i,record,i.values[0]);
}};export default component;
