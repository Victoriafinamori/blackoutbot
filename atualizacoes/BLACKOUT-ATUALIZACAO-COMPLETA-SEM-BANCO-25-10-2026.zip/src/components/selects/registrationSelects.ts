import { prisma } from '../../database/prisma';
import { isBotAdmin } from '../../utils/permissions';
import { registrationPageManagerPayload } from '../../utils/registrationPageAdmin';
import { registrationRoleError, updateRegistrationSelection } from '../../utils/registrationSettings';
import { regConfig } from '../../utils/registration';
import { ids } from '../../utils/tickets';
import { deferPanel, refreshPanel } from '../../utils/panelInteraction';
const component={customId:'registration-',async execute(i:any){
  if(!i.guild||!await isBotAdmin(await i.guild.members.fetch(i.user.id)))return;
  if(i.customId==='registration-manage-page'){
    await deferPanel(i);return refreshPanel(i,await registrationPageManagerPayload(i.guild,i.values[0]));
  }
  if(/^registration-page-(roles|addroles|removeroles):/.test(i.customId)){
    const page=await prisma.registrationPage.findFirst({where:{id:i.customId.split(':')[1],guildId:i.guild.id}});
    if(!page)return i.reply({content:'Página não encontrada neste servidor.',ephemeral:true});
    const mode=i.customId.split(':')[0],current=ids(page.roleIds),values=mode==='registration-page-removeroles'?current.filter(id=>!i.values.includes(id)):mode==='registration-page-addroles'?[...new Set<string>([...current,...i.values])]:i.values;
    const error=await registrationRoleError(i.guild,values,true);if(error)return i.reply({content:error,ephemeral:true});
    const c=await regConfig(i.guild.id);if(values.some((id:string)=>ids(c.unregisteredRoleIds).includes(id)))return i.reply({content:'Estes cargos seriam removidos na conclusão. Revise Cargos após registro antes de adicioná-los ao formulário.',ephemeral:true});
    await deferPanel(i);await prisma.registrationPage.update({where:{id:page.id},data:{roleIds:values.join(',')}});
    return refreshPanel(i,await registrationPageManagerPayload(i.guild,page.id));
  }
  if(i.customId.startsWith('registration-role:')||i.customId.startsWith('registration-channel:'))return updateRegistrationSelection(i);
}};
export default component;
