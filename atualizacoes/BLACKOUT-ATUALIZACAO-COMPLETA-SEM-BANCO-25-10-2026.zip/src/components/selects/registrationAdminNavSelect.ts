import { isBotAdmin } from '../../utils/permissions';
import { buildAdmSectionPanel } from '../../utils/admPanel';
import { deferPanel, refreshPanel } from '../../utils/panelInteraction';
import { renderRegistrationAdmin } from '../../utils/registrationAdmin';
export async function renderRegistrationGeneral(i:any){return renderRegistrationAdmin(i,'logs')}
const component={customId:'registration-admin-nav',async execute(i:any){
  if(!i.guild||!i.isStringSelectMenu()||!await isBotAdmin(await i.guild.members.fetch(i.user.id)))return;
  const value=i.values[0];
  if(value==='back')return refreshPanel(i,await buildAdmSectionPanel(i.guild,'membros'));
  if(!['general','pages','embed','auto','welcome','tools','team','logs','publication','home'].includes(value))return;
  await deferPanel(i);return renderRegistrationAdmin(i,value);
}};
export default component;
