import { selectedRoleIssue } from "../../utils/teamRoles";
import { deferPanel } from "../../utils/panelInteraction";
import { renderBotAdmin, renderPermRoleType, renderSysRoleType, PERMISSION_LABELS, SYSTEM_ROLE_LABELS } from "../buttons/admAdminMenu";
import { AnySelectMenuInteraction, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } from "discord.js";
import { SelectMenuComponent } from "../../structures/types";
import { isBotAdmin, hasPermission } from "../../utils/permissions";
import { baseEmbed } from "../../utils/embeds";
import { syncBotAdminRoles, syncPermissionRoles, setSystemRole } from "../../utils/roleSync";
import { setStageRole } from "../../utils/reintegration";
import { PermissionType, SystemRoleType, AdminLogAction } from "../../structures/enums";
import { renderStageDetail } from "../buttons/admReintegrationMenu";
import { setMovCallTop1Role, getMovCallRewards, removeMovCallReward } from "../../utils/movCallStats";
import { renderMovCallConfigMenu, renderMovCallTopCallMenu, renderRewardsMenu } from "../buttons/admMovCallMenu";
import { logAdminAction } from "../../utils/adminLog";
import { updateFamily, FamilyError } from "../../utils/families";
import { renderFamilyDetail } from "../buttons/admFamiliasMenu";
import { updateRoleTransferConfig } from "../../utils/roleTransfer";
import { renderRoleTransferMenu } from "../buttons/admRoleTransferMenu";

async function handleBotAdmin(i: AnySelectMenuInteraction) {
  const issue=selectedRoleIssue(i.guild!,i.values);if(issue)return void await i.reply({content:issue,ephemeral:true});
  await deferPanel(i);await syncBotAdminRoles(i.guild!,i.user.id,i.values);await renderBotAdmin(i,"Cargos salvos neste servidor.");
}
async function handlePermRole(i: AnySelectMenuInteraction,type: PermissionType) {
  if(!PERMISSION_LABELS[type])return;
  const issue=selectedRoleIssue(i.guild!,i.values);if(issue)return void await i.reply({content:issue,ephemeral:true});
  await deferPanel(i);await syncPermissionRoles(i.guild!,i.user.id,type,i.values);await renderPermRoleType(i,type,"Permissão salva neste servidor.");
}
async function handleSysRole(i: AnySelectMenuInteraction,type: SystemRoleType) {
  if(!SYSTEM_ROLE_LABELS[type])return;
  const issue=selectedRoleIssue(i.guild!,i.values,true);if(issue)return void await i.reply({content:issue,ephemeral:true});
  await deferPanel(i);await setSystemRole(i.guild!,i.user.id,type,i.values[0]??null);await renderSysRoleType(i,type,"Associação salva neste servidor.");
}

async function handleStageRole(interaction: AnySelectMenuInteraction, stageId: string) {
  const newRoleId = interaction.values[0] ?? null;
  await setStageRole(interaction.guild!, interaction.user.id, stageId, newRoleId);
  await renderStageDetail(interaction, stageId);
}

async function handleMovCallPermRole(interaction: AnySelectMenuInteraction) {
  await syncPermissionRoles(interaction.guild!, interaction.user.id, PermissionType.MOVCALL_COMMANDS, interaction.values);
  await renderMovCallConfigMenu(interaction);
}

async function handleMovCallTop1Role(interaction: AnySelectMenuInteraction) {
  const newRoleId = interaction.values[0] ?? null;
  await setMovCallTop1Role(interaction.guild!, interaction.user.id, newRoleId);
  await renderMovCallTopCallMenu(interaction);
}

async function handleMovCallRewardAdd(interaction: AnySelectMenuInteraction) {
  const roleId = interaction.values[0];
  if (!roleId) return;

  const modal = new ModalBuilder()
    .setCustomId(`adm-modal:movcallreward:${roleId}`)
    .setTitle("Recompensa por Tempo");

  const hoursInput = new TextInputBuilder()
    .setCustomId("minHours")
    .setLabel("Tempo mínimo em call (horas)")
    .setPlaceholder("Ex: 10")
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setMaxLength(5);

  modal.addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(hoursInput));
  await interaction.showModal(modal);
}

async function handleMovCallRewardRemove(interaction: AnySelectMenuInteraction) {
  const roleId = interaction.values[0];
  if (!roleId) return;

  const rewards = await getMovCallRewards(interaction.guild!.id);
  const existing = rewards.find((r: { roleId: string }) => r.roleId === roleId);

  if (!existing) {
    await interaction.reply({ content: "⚠️ Esse cargo não tem nenhuma recompensa cadastrada.", ephemeral: true });
    return;
  }

  await removeMovCallReward(interaction.guild!.id, roleId);
  await logAdminAction({
    guild: interaction.guild!,
    actorId: interaction.user.id,
    action: AdminLogAction.MOVCALL_REWARD_REMOVED,
    details: `Recompensa removida: <@&${roleId}> (${existing.minHours}h)`,
  });

  await renderRewardsMenu(interaction);
}

async function handleAvisosRole(interaction: AnySelectMenuInteraction) {
  const roleId = interaction.values[0];
  if (!roleId) return;

  const modal = new ModalBuilder()
    .setCustomId(`adm-modal:aviso:${roleId}`)
    .setTitle("Enviar Aviso por Cargo");

  const messageInput = new TextInputBuilder()
    .setCustomId("message")
    .setLabel("Mensagem do aviso")
    .setStyle(TextInputStyle.Paragraph)
    .setPlaceholder("Digite aqui o que será enviado na DM de cada membro com esse cargo...")
    .setRequired(true)
    .setMaxLength(1800);

  modal.addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(messageInput));
  await interaction.showModal(modal);
}

async function handleFamilyRole(interaction: AnySelectMenuInteraction, kind: "familymember" | "familyleader", familyId: string) {
  const roleId = interaction.values[0];
  if (!roleId) return;

  try {
    await updateFamily(interaction.guild!, interaction.user.id, familyId, {
      [kind === "familymember" ? "memberRoleId" : "leaderRoleId"]: roleId,
    });
  } catch (err) {
    if (err instanceof FamilyError) {
      await interaction.reply({ content: `❌ ${err.message}`, ephemeral: true });
      return;
    }
    throw err;
  }

  await renderFamilyDetail(interaction, familyId);
}

async function handleRoleTransferRole(interaction: AnySelectMenuInteraction, kind: "sourcerole" | "targetrole") {
  const roleId = interaction.values[0] ?? null;
  const field = kind === "sourcerole" ? "sourceRoleId" : "targetRoleId";
  const label = kind === "sourcerole" ? "Cargo de origem" : "Cargo de destino";

  await updateRoleTransferConfig(
    interaction.guild!,
    interaction.user.id,
    { [field]: roleId },
    `${label}: ${roleId ? `<@&${roleId}>` : "removido"}.`
  );

  await renderRoleTransferMenu(interaction);
}

const component: SelectMenuComponent = {
  customId: "adm-role-select:",

  async execute(interaction: AnySelectMenuInteraction) {
    if (!interaction.guild) return;

    const member = await interaction.guild.members.fetch(interaction.user.id);
    const parts = interaction.customId.split(":"); // ["adm-role-select", "kind", "type?"]
    const kind = parts[1];
    const type = parts[2];

    // O gerenciamento de cargo de etapa usa a permissão STAGE_MANAGER,
    // as demais seções (administração) exigem isBotAdmin.
    const authorized =
      kind === "stage"
        ? await hasPermission(member, PermissionType.STAGE_MANAGER)
        : kind === "sourcerole" || kind === "targetrole"
        ? (await hasPermission(member, PermissionType.STAGE_MANAGER)) ||
          (await hasPermission(member, PermissionType.REINTEGRATION_GRANTER))
        : await isBotAdmin(member);

    if (!authorized) {
      await interaction.reply({
        content: "🚫 Você não tem permissão para realizar esta ação.",
        ephemeral: true,
      });
      return;
    }

    if (kind === "botadmin") return handleBotAdmin(interaction);
    if (kind === "permrole") return handlePermRole(interaction, type as PermissionType);
    if (kind === "sysrole") return handleSysRole(interaction, type as SystemRoleType);
    if (kind === "stage") return handleStageRole(interaction, type);
    if (kind === "movcallperm") return handleMovCallPermRole(interaction);
    if (kind === "movcalltop1") return handleMovCallTop1Role(interaction);
    if (kind === "movcallrewardadd") return handleMovCallRewardAdd(interaction);
    if (kind === "movcallrewardremove") return handleMovCallRewardRemove(interaction);
    if (kind === "avisos") return handleAvisosRole(interaction);
    if (kind === "familymember") return handleFamilyRole(interaction, "familymember", type);
    if (kind === "familyleader") return handleFamilyRole(interaction, "familyleader", type);
    if (kind === "sourcerole") return handleRoleTransferRole(interaction, "sourcerole");
    if (kind === "targetrole") return handleRoleTransferRole(interaction, "targetrole");
  },
};

export default component;
