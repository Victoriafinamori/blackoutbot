import { SelectMenuComponent } from "../../structures/types";
import { isBotAdmin } from "../../utils/permissions";
import { prisma } from "../../database/prisma";
import { writableChannel } from "../../utils/configurationChecks";
import { deferPanel } from "../../utils/panelInteraction";
import { renderLogChannelPicker } from "../buttons/admLogsMenu";
import { renderNotificationPanel } from "../buttons/admNotifications";
const component:SelectMenuComponent={customId:"adm-channel-select:",async execute(i){
  if(!i.guild||!i.isChannelSelectMenu()||!await isBotAdmin(await i.guild.members.fetch(i.user.id)))return;
  const key=i.customId.split(":")[1];
  if(key!=="log"&&key!=="reports")return void await i.reply({content:"Abra a área de configuração correspondente no painel atual.",ephemeral:true});
  const id=i.values[0]??null;
  if(id){const check=await writableChannel(i.guild,id,key==="log");if(check.issue)return void await i.reply({content:check.issue,ephemeral:true});}
  await deferPanel(i);
  await prisma.guildConfig.update({where:{guildId:i.guild.id},data:key==="log"?{logChannelId:id}:{reportsChannelId:id,...(!id?{notifyPublicWarns:false}:{})}});
  return key==="log"?renderLogChannelPicker(i,"geral","Canal salvo."):renderNotificationPanel(i,"moderacao","Canal salvo.");
}};export default component;
