import { select } from "../../bingo/communityInteractions";
export default { customId: "bg-select:", execute: select };
