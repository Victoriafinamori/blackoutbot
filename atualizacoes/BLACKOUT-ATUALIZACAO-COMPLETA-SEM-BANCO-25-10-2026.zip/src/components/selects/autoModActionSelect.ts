import { isBotAdmin } from "../../utils/permissions";
import { prisma } from "../../database/prisma";
import { deferPanel } from "../../utils/panelInteraction";
import { logAdminAction } from "../../utils/adminLog";
import { AutoModAction, AdminLogAction } from "../../structures/enums";
import { renderFiltersLimits } from "../buttons/admModerationMenu";
export default {customId:"adm-automod-select",async execute(i:any){
 if(!i.guild||!i.isStringSelectMenu()||!await isBotAdmin(await i.guild.members.fetch(i.user.id)))return;
 const action=i.values[0];if(!Object.values(AutoModAction).includes(action))return;
 await deferPanel(i);await prisma.guildConfig.update({where:{guildId:i.guild.id},data:{autoModAction:action}});
 await logAdminAction({guild:i.guild,actorId:i.user.id,action:AdminLogAction.MODERATION_CONFIG_CHANGED,details:`Resposta automática: ${action}`});
 return renderFiltersLimits(i);
}};
