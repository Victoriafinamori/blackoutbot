import { ActionRowBuilder, AnySelectMenuInteraction, ButtonBuilder, ButtonStyle } from "discord.js";
import { SelectMenuComponent } from "../../structures/types";
import { isBotAdmin } from "../../utils/permissions";
import { buildAdmSectionPanel } from "../../utils/admPanel";
import { getFFConfig } from "../../ff/service";
import {
  buildFreeFireRulesModal,
  renderFreeFireChannels,
  renderFreeFireList,
  renderFreeFireMenu,
  renderFreeFirePanels,
  renderFreeFireStatus,
} from "../buttons/admFreeFireMenu";

const component: SelectMenuComponent = {
  customId: "ff-admin-nav",
  async execute(i: AnySelectMenuInteraction) {
    if (!i.guild || !i.isStringSelectMenu()) return;
    if (!(await isBotAdmin(await i.guild.members.fetch(i.user.id)))) {
      await i.reply({ content: "🚫 Sem permissão.", ephemeral: true });
      return;
    }

    const value = i.values[0];

    if (value === "back") return void (await i.update(await buildAdmSectionPanel(i.guild, "staff")));
    if (value === "status") return renderFreeFireStatus(i);
    if (value === "channels") return renderFreeFireChannels(i);
    if (value === "panels") return renderFreeFirePanels(i);
    if (value === "list") return renderFreeFireList(i);

    if (value === "rules") {
      const c = await getFFConfig(i.guild.id);
      await i.showModal(buildFreeFireRulesModal(c));
      return;
    }

    if (value === "reset") {
      return void (await i.update({
        embeds: [],
        components: [
          new ActionRowBuilder<ButtonBuilder>().addComponents(
            new ButtonBuilder().setCustomId("adm-ff:reset-confirm").setLabel("Confirmar reset das inscrições").setStyle(ButtonStyle.Danger),
            new ButtonBuilder().setCustomId("adm-ff:menu").setLabel("Cancelar").setStyle(ButtonStyle.Secondary)
          ),
        ],
      }));
    }
  },
};

export default component;
