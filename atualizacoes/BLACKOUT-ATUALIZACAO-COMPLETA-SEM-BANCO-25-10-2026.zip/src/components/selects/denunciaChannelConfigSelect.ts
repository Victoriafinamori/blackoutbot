import { AnySelectMenuInteraction, MessageFlags } from "discord.js";
import { SelectMenuComponent } from "../../structures/types";
import { prisma } from "../../database/prisma";
import { isBotAdmin } from "../../utils/permissions";
const allowed = new Set(["categoryId", "panelChannelId", "logChannelId"]);
const component: SelectMenuComponent = { customId: "denuncia-channel:", async execute(i: AnySelectMenuInteraction) {
  if (!i.guild || !(await isBotAdmin(await i.guild.members.fetch(i.user.id)))) return;
  const key = i.customId.split(":")[1];
  if (!allowed.has(key)) return void await i.reply({ content: "Configuração de canal inválida.", flags: MessageFlags.Ephemeral });
  await prisma.reportConfig.upsert({ where: { guildId: i.guild.id }, create: { guildId: i.guild.id, [key]: i.values[0] || null }, update: { [key]: i.values[0] || null } });
  return require("../buttons/admDenunciasMenu").renderDenunciasChannels(i);
} };
export default component;
