import { isBotAdmin } from "../../utils/permissions";
import { renderModerationMember, openModerationReason } from "../../utils/moderationPanel";
export default {customId:"adm-mod-user-select:",async execute(i:any){
 if(!i.guild||!i.isUserSelectMenu())return;
 if(!await isBotAdmin(await i.guild.members.fetch(i.user.id)))return i.reply({content:"Você não possui permissão neste servidor.",ephemeral:true});
 const type=i.customId.split(":")[1],id=i.values[0];if(!id)return;
 if(type==="member"||type==="historico")return renderModerationMember(i,id);
 return openModerationReason(i,type,id);
}};
