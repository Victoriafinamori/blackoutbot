import { SelectMenuComponent } from "../../structures/types";
import { isBotAdmin } from "../../utils/permissions";
import { prisma } from "../../database/prisma";
import { writableChannel } from "../../utils/configurationChecks";
import { deferPanel } from "../../utils/panelInteraction";
import { renderNotificationPanel } from "../buttons/admNotifications";
const component: SelectMenuComponent={customId:"notice-channel-select:",async execute(i){
  if(!i.guild||!i.isChannelSelectMenu()||i.customId!=="notice-channel-select:moderacao")return;
  if(!await isBotAdmin(await i.guild.members.fetch(i.user.id)))return;
  const id=i.values[0]??null;
  if(id){const check=await writableChannel(i.guild,id,false);if(check.issue)return void await i.reply({content:check.issue,ephemeral:true});}
  await deferPanel(i);
  await prisma.guildConfig.update({where:{guildId:i.guild.id},data:{reportsChannelId:id,...(!id?{notifyPublicWarns:false}:{})}});
  return renderNotificationPanel(i,"moderacao","Canal atualizado neste painel.");
}};
export default component;
