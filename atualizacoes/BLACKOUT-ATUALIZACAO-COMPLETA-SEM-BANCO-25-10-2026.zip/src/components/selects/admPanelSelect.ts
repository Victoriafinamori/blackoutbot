import { SelectMenuComponent } from "../../structures/types";
import { isBotAdmin } from "../../utils/permissions";
import { buildAdmSectionPanel, resolveAdmSection } from "../../utils/admPanel";
const component: SelectMenuComponent = {
  customId: "adm-panel-select",
  async execute(i) {
    if (!i.guild || !i.isStringSelectMenu()) return;
    if (!await isBotAdmin(await i.guild.members.fetch(i.user.id))) {
      await i.reply({ content: "Você não possui permissão para acessar o painel administrativo.", ephemeral: true });
      return;
    }
    const section = resolveAdmSection(i.values[0]);
    if (!section) return;
    await i.update(await buildAdmSectionPanel(i.guild, section));
  },
};
export default component;
