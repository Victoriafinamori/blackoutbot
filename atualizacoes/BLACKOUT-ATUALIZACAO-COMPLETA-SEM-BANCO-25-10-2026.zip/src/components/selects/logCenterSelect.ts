import { isBotAdmin } from "../../utils/permissions";
import { deferPanel } from "../../utils/panelInteraction";
import { readLogSettings,saveLogSettings,LOG_EVENTS,LOG_GROUPS } from "../../logging/config";
import { usableLogChannel,validateExternal } from "../../logging/delivery";
import { renderLogEvents,renderLogDestination,renderLogOrganization,renderLocalGroup,externalModal,renderLogFilters,logEventGroups } from "../../logging/panel";
export default {customId:"logs-center-select:",async execute(i:any){
 if(!i.guild||!await isBotAdmin(await i.guild.members.fetch(i.user.id)))return i.reply({content:"Você não possui permissão neste servidor.",ephemeral:true});
 const [,action,arg]=i.customId.split(":"),values:string[]=i.values??[];
 if(action==="channel-group"&&values[0]==="bot"&&(arg==="local"||arg==="external")){await deferPanel(i);return renderLogOrganization(i,arg,"bot")}
 if(action==="channel-group"&&arg==="external"){
  if(!LOG_GROUPS[values[0]])return;const s=await readLogSettings(i.guild.id);if(!s.externalGuildId)return i.reply({content:"Configure primeiro o servidor externo em Onde enviar.",ephemeral:true});return externalModal(i,values[0]);
 }
 await deferPanel(i);
 const s=await readLogSettings(i.guild.id,true);
 try{
 if(action==="group")return renderLogEvents(i,values[0]);
 if(action==="events"){
  const groups=logEventGroups(arg);if(!groups.length||values.some(id=>!LOG_EVENTS[id]||!groups.includes(LOG_EVENTS[id].group)))return;
  const events={...s.events};for(const [key,v]of Object.entries(LOG_EVENTS))if(groups.includes(v.group))events[key]=values.includes(key);
  await saveLogSettings(i.guild.id,{eventsJson:JSON.stringify(events)});return renderLogEvents(i,arg,"Eventos salvos neste servidor.");
 }
 if(action==="mode"){
  const mode=values[0];if(!["LOCAL","EXTERNAL","BOTH"].includes(mode))return;
  if(mode!=="LOCAL"){await validateExternal(i.guild,s,i.user.id);await saveLogSettings(i.guild.id,{deliveryMode:mode,externalAuthorizedBy:i.user.id})}else await saveLogSettings(i.guild.id,{deliveryMode:mode});
  return renderLogDestination(i,"Modo de envio salvo. As mensagens antigas permanecem nos destinos anteriores.");
 }
 if(action==="channel-group"&&arg==="local")return renderLocalGroup(i,values[0]);
 if(action==="local-channel"){
  if(!LOG_GROUPS[arg])return;if(values[0])await usableLogChannel(i.guild,values[0]);
  await saveLogSettings(i.guild.id,{localChannelsJson:JSON.stringify({...s.localChannels,[arg]:values[0]??null})});return renderLocalGroup(i,arg,"Canal salvo neste servidor.");
 }
 if(action==="ignored-channels"){
  if(values.length>25)throw Error("Selecione até 25 canais.");
  for(const id of values){const ch=await i.guild.channels.fetch(id).catch(()=>null);if(!ch||ch.guildId!==i.guild.id)throw Error("Escolha canais ou categorias deste servidor.")}
  await saveLogSettings(i.guild.id,{ignoredChannelIds:JSON.stringify(values)});return renderLogFilters(i,"Canais ignorados atualizados.");
 }
 if(action==="ignored-roles"){
  if(values.length>25||values.some(id=>id===i.guild.id||!i.guild.roles.cache.has(id)))throw Error("Escolha até 25 cargos específicos deste servidor.");
  await saveLogSettings(i.guild.id,{ignoredRoleIds:JSON.stringify(values)});return renderLogFilters(i,"Cargos ignorados atualizados.");
 }
 }catch(error:any){return i.followUp({content:error.message||"Não foi possível salvar. Confira os destinos e tente novamente.",ephemeral:true})}
}};
