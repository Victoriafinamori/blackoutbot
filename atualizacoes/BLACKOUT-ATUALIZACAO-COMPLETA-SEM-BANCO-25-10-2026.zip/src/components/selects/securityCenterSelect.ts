import { SelectMenuComponent } from "../../structures/types";
import { execute } from "../../security/interactions";
const component: SelectMenuComponent = { customId: "security-select:", execute };
export default component;
