import { ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } from "discord.js";
import { SelectMenuComponent } from "../../structures/types";
import { isBotAdmin } from "../../utils/permissions";
import { prisma } from "../../database/prisma";
import { fetchCustomEmbed } from "../../utils/customEmbeds";
import { writableChannel } from "../../utils/configurationChecks";
import { deferPanel } from "../../utils/panelInteraction";
import { renderEmbedEditor } from "../buttons/admEmbedV2Menu";
const component:SelectMenuComponent={customId:"embedv2-channel:",async execute(i){
  if(!i.guild||!i.isChannelSelectMenu()||!await isBotAdmin(await i.guild.members.fetch(i.user.id)))return;
  const [,action,id]=i.customId.split(":");
  const record=await fetchCustomEmbed(id,i.guild.id);
  if(!record)return void await i.reply({content:"Mensagem não encontrada neste servidor.",ephemeral:true});
  const channelId=i.values[0];
  if(action==="destination"){
    const check=await writableChannel(i.guild,channelId);
    if(check.issue)return void await i.reply({content:check.issue,ephemeral:true});
    await deferPanel(i);
    await prisma.customEmbed.update({where:{id},data:{destinationChannelId:channelId}});
    return renderEmbedEditor(i,id);
  }
  if(action==="addbutton"){
    const channel=await i.guild.channels.fetch(channelId).catch(()=>null);
    if(!channel||channel.guildId!==i.guild.id)return void await i.reply({content:"Escolha um canal deste servidor.",ephemeral:true});
    const label=new TextInputBuilder().setCustomId("label").setLabel("Texto do botão").setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(80).setValue(`Ir para #${channel.name}`.slice(0,80));
    const emoji=new TextInputBuilder().setCustomId("emoji").setLabel("Emoji opcional").setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(50);
    return void await i.showModal(new ModalBuilder().setCustomId(`embedv2-modal:add-channel:${id}:${channelId}`).setTitle("Botão para canal").addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(label),new ActionRowBuilder<TextInputBuilder>().addComponents(emoji)));
  }
}};export default component;
