import { prisma } from "../database/prisma";
import { letterFor } from "./types";

// -----------------------------------------------------------------------
// Configuração (painel de cartelas)
// -----------------------------------------------------------------------

export async function getBingoConfig(guildId: string) {
  return prisma.bingoConfig.upsert({
    where: { guildId },
    update: {},
    create: { guildId },
  });
}

export async function updateBingoConfig(
  guildId: string,
  data: Partial<{
    cardPanelChannelId: string | null;
    cardPanelMessageId: string | null;
    cardTicketCategoryId: string | null;
    cardEmbedTitle: string | null;
    cardEmbedDescription: string | null;
    cardEmbedImage: string | null;
    cardEmbedThumbnail: string | null;
    cardEmbedColor: string | null;
    price1Qty: number;
    price1Text: string;
    price3Qty: number;
    price3Text: string;
    price10Qty: number;
    price10Text: string;
    paymentInstructions: string | null;
  }>,
) {
  await getBingoConfig(guildId);
  return prisma.bingoConfig.update({ where: { guildId }, data });
}

// -----------------------------------------------------------------------
// Partida
// -----------------------------------------------------------------------

// Só existe uma partida "em jogo" (não encerrada) por servidor.
export async function getCurrentMatch(guildId: string) {
  return prisma.bingoMatch.findFirst({
    where: { guildId, status: { in: ["EM_ANDAMENTO", "PAUSADA"] } },
    orderBy: { createdAt: "desc" },
  });
}

export async function getMatchById(matchId: string) {
  return prisma.bingoMatch.findUnique({ where: { id: matchId } });
}

export async function createMatch(
  guildId: string,
  channelId: string,
  startedById: string,
) {
  return require("../games-chat/experience/common").lock(
    "bingo:" + guildId,
    () =>
      prisma.$transaction(async (tx) => {
        if (
          await tx.bingoMatch.findFirst({
            where: { guildId, status: { in: ["EM_ANDAMENTO", "PAUSADA"] } },
          })
        )
          throw Error("Já existe uma partida em andamento.");
        const last = await tx.bingoMatch.findFirst({
            where: { guildId },
            orderBy: { number: "desc" },
          }),
          match = await tx.bingoMatch.create({
            data: {
              guildId,
              channelId,
              number: (last?.number || 0) + 1,
              startedById,
              status: "EM_ANDAMENTO",
            },
          });
        await tx.bingoCard.updateMany({
          where: { guildId, matchId: null },
          data: { matchId: match.id },
        });
        return match;
      }),
  );
}

export async function setMatchMessage(matchId: string, messageId: string) {
  return prisma.bingoMatch.update({
    where: { id: matchId },
    data: { messageId },
  });
}

export async function pauseMatch(matchId: string) {
  const community = await prisma.bingoExperienceState.findUnique({
    where: { matchId },
  });
  if (community) {
    await require("./community").pause(community.guildId, matchId);
    return prisma.bingoMatch.findUniqueOrThrow({ where: { id: matchId } });
  }

  return prisma.bingoMatch.update({
    where: { id: matchId },
    data: { status: "PAUSADA" },
  });
}

export async function resumeMatch(matchId: string) {
  const community = await prisma.bingoExperienceState.findUnique({
    where: { matchId },
  });
  if (community) {
    await require("./community").resume(community.guildId, matchId);
    return prisma.bingoMatch.findUniqueOrThrow({ where: { id: matchId } });
  }

  return prisma.bingoMatch.update({
    where: { id: matchId },
    data: { status: "EM_ANDAMENTO" },
  });
}

export async function endMatch(matchId: string) {
  const community = await prisma.bingoExperienceState.findUnique({
    where: { matchId },
  });
  if (community) {
    await require("./community").end(community.guildId, matchId);
    return prisma.bingoMatch.findUniqueOrThrow({ where: { id: matchId } });
  }

  return prisma.bingoMatch.update({
    where: { id: matchId },
    data: { status: "ENCERRADA", endedAt: new Date() },
  });
}

// -----------------------------------------------------------------------
// Sorteio
// -----------------------------------------------------------------------

export async function getDraws(matchId: string) {
  return prisma.bingoDraw.findMany({
    where: { matchId },
    orderBy: { order: "asc" },
  });
}

export async function drawNumber(matchId: string) {
  const community = await prisma.bingoExperienceState.findUnique({
    where: { matchId },
  });
  if (community) return require("./community").draw(community.guildId, matchId);
  return require("../games-chat/experience/common").lock(
    "bingo-draw:" + matchId,
    () =>
      prisma.$transaction(async (tx) => {
        const match = await tx.bingoMatch.findUnique({
          where: { id: matchId },
        });
        if (!match || match.status !== "EM_ANDAMENTO")
          throw Error("A partida precisa estar em andamento para sortear.");
        const existing = await tx.bingoDraw.findMany({
            where: { matchId },
            select: { number: true },
          }),
          used = new Set(existing.map((d) => d.number)),
          remaining = Array.from({ length: 75 }, (_, i) => i + 1).filter(
            (n) => !used.has(n),
          );
        if (!remaining.length)
          throw Error("Todos os 75 números já foram sorteados nesta partida.");
        const number =
          remaining[require("node:crypto").randomInt(remaining.length)];
        return tx.bingoDraw.create({
          data: {
            matchId,
            number,
            letter: letterFor(number),
            order: existing.length + 1,
          },
        });
      }),
  );
}

// -----------------------------------------------------------------------
// Cartelas (a criação é feita pelo bot de inscrição — aqui só consultamos)
// -----------------------------------------------------------------------

export async function getPlayerCard(
  guildId: string,
  matchId: string,
  playerId: string,
) {
  return prisma.bingoCard.findFirst({ where: { guildId, matchId, playerId } });
}

// Todas as cartelas de um jogador em uma partida específica. Um jogador
// pode ter comprado várias (1, 3, 10...) — a validação de BINGO precisa
// checar TODAS, nunca só a primeira encontrada.
export async function getPlayerCards(
  guildId: string,
  matchId: string,
  playerId: string,
) {
  return prisma.bingoCard.findMany({
    where: { guildId, matchId, playerId },
    orderBy: { cardNumber: "asc" },
  });
}

// Todas as cartelas "ativas" de um jogador: vinculadas à partida atual ou
// ainda soltas (compradas durante a semana, antes da próxima partida
// começar). Usado pelo reenvio de cartelas, que funciona a qualquer
// momento, com ou sem partida em andamento.
export async function getAllActiveCardsForPlayer(
  guildId: string,
  playerId: string,
) {
  const match = await getCurrentMatch(guildId);
  return prisma.bingoCard.findMany({
    where: {
      guildId,
      playerId,
      OR: [{ matchId: null }, ...(match ? [{ matchId: match.id }] : [])],
    },
    orderBy: { cardNumber: "asc" },
  });
}

// Cartela "ativa" de um jogador: tanto uma já vinculada à partida atual
// quanto uma retirada durante a semana e ainda não vinculada (matchId
// nulo). Usado pelo painel de retirada, que funciona com ou sem partida
// em andamento.
export async function getActiveCardForPlayer(
  guildId: string,
  playerId: string,
) {
  const match = await getCurrentMatch(guildId);
  return prisma.bingoCard.findFirst({
    where: {
      guildId,
      playerId,
      OR: [{ matchId: null }, ...(match ? [{ matchId: match.id }] : [])],
    },
  });
}

// Sorteia uma cartela clássica: cada coluna (B/I/N/G/O) recebe 5 números
// únicos dentro da sua faixa; o centro (índice 12) fica livre.
function randomUniqueInRange(
  min: number,
  max: number,
  count: number,
): number[] {
  const pool: number[] = [];
  for (let n = min; n <= max; n++) pool.push(n);
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  return pool.slice(0, count);
}

export function generateCardNumbers(): (number | null)[] {
  const columns = [
    randomUniqueInRange(1, 15, 5),
    randomUniqueInRange(16, 30, 5),
    randomUniqueInRange(31, 45, 5),
    randomUniqueInRange(46, 60, 5),
    randomUniqueInRange(61, 75, 5),
  ];
  const grid: (number | null)[] = new Array(25).fill(null);
  for (let row = 0; row < 5; row++) {
    for (let col = 0; col < 5; col++) {
      grid[row * 5 + col] = row * 5 + col === 12 ? null : columns[col][row];
    }
  }
  return grid;
}

// Gera e salva uma cartela nova para o jogador. Funciona com ou sem
// partida em andamento — se ainda não existe partida (ou ela ainda não
// começou a sortear), a cartela fica "solta" (matchId nulo) e é
// automaticamente vinculada assim que a próxima partida for iniciada
// (ver createMatch). Se a partida atual já estiver sorteando, bloqueia.
export async function createCardForPlayer(guildId: string, playerId: string) {
  const match = await getCurrentMatch(guildId);
  if (match) {
    const drawCount = await prisma.bingoDraw.count({
      where: { matchId: match.id },
    });
    if (drawCount > 0)
      throw new Error(
        "As cartelas já não podem mais ser retiradas: o sorteio da partida atual já começou.",
      );
  }

  const count = await prisma.bingoCard.count({ where: { guildId } });
  const numbers = generateCardNumbers();
  return registerCard(
    guildId,
    match ? match.id : null,
    count + 1,
    playerId,
    numbers,
  );
}

// Recebe uma cartela pronta (número, jogador e os 25 números da grade) e
// vincula à partida — ponto de integração para o bot de inscrição.
export async function registerCard(
  guildId: string,
  matchId: string | null,
  cardNumber: number,
  playerId: string,
  numbers: (number | null)[],
) {
  return prisma.bingoCard.create({
    data: {
      guildId,
      matchId,
      cardNumber,
      playerId,
      numbers: JSON.stringify(numbers),
    },
  });
}

// Gera N cartelas pagas de uma vez (sem o limite de 1-por-jogador da
// retirada gratuita — é usado depois que o pagamento é confirmado).
export async function createPaidCards(
  guildId: string,
  playerId: string,
  quantity: number,
) {
  const community = await prisma.bingoExperienceState.findFirst({
    where: { guildId, phase: { in: ["LOBBY", "RUNNING", "PAUSED", "REVIEW"] } },
  });
  if (community)
    throw new Error(
      "O Bingo comunitário está aberto. Este evento tem participação gratuita e não recebe cartelas de outros pedidos.",
    );

  const match = await getCurrentMatch(guildId);
  if (match) {
    const drawCount = await prisma.bingoDraw.count({
      where: { matchId: match.id },
    });
    if (drawCount > 0)
      throw new Error(
        "O sorteio da partida atual já começou — não é mais possível entregar cartelas para ela.",
      );
  }

  const cards = [];
  for (let i = 0; i < quantity; i++) {
    const count = await prisma.bingoCard.count({ where: { guildId } });
    const numbers = generateCardNumbers();
    cards.push(
      await registerCard(
        guildId,
        match ? match.id : null,
        count + 1,
        playerId,
        numbers,
      ),
    );
  }
  return cards;
}

// -----------------------------------------------------------------------
// Pedidos de compra (ticket de atendimento até a entrega)
// -----------------------------------------------------------------------

export async function createOrder(
  guildId: string,
  buyerId: string,
  channelId: string,
  quantity: number,
  price: string,
) {
  return prisma.bingoOrder.create({
    data: { guildId, buyerId, channelId, quantity, price },
  });
}

export async function getOrder(orderId: string) {
  return prisma.bingoOrder.findUnique({ where: { id: orderId } });
}

export async function getOrderByChannel(channelId: string) {
  return prisma.bingoOrder.findFirst({
    where: { channelId },
    orderBy: { createdAt: "desc" },
  });
}

export async function markOrderDelivered(orderId: string, staffId: string) {
  return prisma.bingoOrder.update({
    where: { id: orderId },
    data: {
      status: "ENTREGUE",
      deliveredAt: new Date(),
      deliveredById: staffId,
    },
  });
}

export async function markOrderCancelled(orderId: string, staffId: string) {
  return prisma.bingoOrder.update({
    where: { id: orderId },
    data: { status: "CANCELADO", cancelledById: staffId },
  });
}

// Cartela 5x5 clássica, índice 12 (centro) é o espaço livre. Vitória =
// qualquer linha, coluna ou uma das duas diagonais totalmente sorteada.
export function checkWinningCard(
  numbers: (number | null)[],
  drawnNumbers: Set<number>,
): boolean {
  const marked = numbers.map((n) => n === null || drawnNumbers.has(n));

  const lines: number[][] = [];
  for (let row = 0; row < 5; row++)
    lines.push([0, 1, 2, 3, 4].map((col) => row * 5 + col));
  for (let col = 0; col < 5; col++)
    lines.push([0, 1, 2, 3, 4].map((row) => row * 5 + col));
  lines.push([0, 6, 12, 18, 24]);
  lines.push([4, 8, 12, 16, 20]);

  return lines.some((line) => line.every((index) => marked[index]));
}

export async function recordWinnerAttempt(
  matchId: string,
  cardId: string,
  playerId: string,
  valid: boolean,
) {
  return prisma.bingoWinner.create({
    data: { matchId, cardId, playerId, valid },
  });
}
