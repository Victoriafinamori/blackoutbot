import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  EmbedBuilder,
  Guild,
  PermissionFlagsBits,
  StringSelectMenuBuilder,
} from "discord.js";
import { BINGO_IDS, BingoLetter, BingoMatchStatus } from "./types";
import {
  createOrder,
  getBingoConfig,
  getCurrentMatch,
  getMatchById,
  getDraws,
  updateBingoConfig,
} from "./service";
import { ids, ticketConfig } from "../utils/tickets";

const COLOR = 0xd20b20;

function statusLine(status: string) {
  if (status === "EM_ANDAMENTO") return "🟢 Em andamento";
  if (status === "PAUSADA") return "🟡 Partida pausada";
  return "🔴 Encerrada";
}

function matchLabel(number: number) {
  return `PARTIDA #${String(number).padStart(3, "0")}`;
}

interface DrawLike {
  number: number;
  letter: string;
}

// -----------------------------------------------------------------------
// Painel principal
// -----------------------------------------------------------------------

export function buildBingoPanel(
  match: { number: number; status: string },
  draws: DrawLike[],
) {
  const last = draws[draws.length - 1];
  const lastLine = last
    ? `# ${last.letter} — ${String(last.number).padStart(2, "0")}`
    : "Nenhum número sorteado ainda.";
  const recent =
    draws
      .slice(-5)
      .map((d) => `${d.letter}-${String(d.number).padStart(2, "0")}`)
      .join(" · ") || "—";

  const embed = new EmbedBuilder()
    .setColor(COLOR)
    .setDescription(
      "🎱 **BINGO AUDAZ**\n\n" +
        `**${matchLabel(match.number)}**\n\n` +
        `**Último número sorteado**\n\n${lastLine}\n\n` +
        `**Números sorteados:** ${draws.length}/75\n\n` +
        `**Últimos sorteios:**\n${recent}\n\n` +
        `**Status:** ${statusLine(match.status)}`,
    );

  const ended = match.status === "ENCERRADA";
  const paused = match.status === "PAUSADA";

  const row1 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(BINGO_IDS.sortear)
      .setLabel("SORTEAR NÚMERO")
      .setStyle(ButtonStyle.Success)
      .setDisabled(ended || paused || draws.length >= 75),
    paused
      ? new ButtonBuilder()
          .setCustomId(BINGO_IDS.retomar)
          .setLabel("RETOMAR")
          .setStyle(ButtonStyle.Primary)
          .setDisabled(ended)
      : new ButtonBuilder()
          .setCustomId(BINGO_IDS.pausar)
          .setLabel("PAUSAR")
          .setStyle(ButtonStyle.Secondary)
          .setDisabled(ended),
    new ButtonBuilder()
      .setCustomId(BINGO_IDS.historico)
      .setLabel("HISTÓRICO")
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(BINGO_IDS.encerrar)
      .setLabel("ENCERRAR")
      .setStyle(ButtonStyle.Danger)
      .setDisabled(ended),
  );

  const row2 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(BINGO_IDS.jogarBingo)
      .setLabel("BINGO")
      .setStyle(ButtonStyle.Primary)
      .setDisabled(ended),
  );

  return { embeds: [embed], components: ended ? [] : [row1, row2] };
}

// -----------------------------------------------------------------------
// Animação do sorteio — quadros exibidos em sequência antes do painel final
// -----------------------------------------------------------------------

export function buildAnimationFrame(text: string) {
  return {
    embeds: [
      new EmbedBuilder()
        .setColor(COLOR)
        .setDescription(`🎱 **BINGO AUDAZ**\n\n${text}`),
    ],
    components: [],
  };
}

export function buildDrawResultFrame(
  letter: BingoLetter,
  number: number,
  total: number,
) {
  const embed = new EmbedBuilder()
    .setColor(COLOR)
    .setDescription(
      `🎱 **NÚMERO SORTEADO**\n\n# ${letter} — ${String(number).padStart(2, "0")}\n\n**Sorteados:** ${total}/75`,
    );
  return { embeds: [embed], components: [] };
}

// -----------------------------------------------------------------------
// Histórico
// -----------------------------------------------------------------------

export function buildHistoryEmbed(draws: DrawLike[]) {
  const byLetter: Record<string, number[]> = {
    B: [],
    I: [],
    N: [],
    G: [],
    O: [],
  };
  for (const d of draws) byLetter[d.letter]?.push(d.number);
  for (const letter of Object.keys(byLetter))
    byLetter[letter].sort((a, b) => a - b);

  const embed = new EmbedBuilder()
    .setColor(COLOR)
    .setTitle("Histórico da Partida")
    .setDescription(
      (["B", "I", "N", "G", "O"] as const)
        .map(
          (letter) =>
            `**${letter}:** ${byLetter[letter].length ? byLetter[letter].map((n) => String(n).padStart(2, "0")).join(" · ") : "—"}`,
        )
        .join("\n"),
    )
    .addFields({
      name: "Total",
      value: `${draws.length}/75 números sorteados.`,
    });

  return embed;
}

// -----------------------------------------------------------------------
// Confirmação de encerramento
// -----------------------------------------------------------------------

export function buildEncerrarConfirm() {
  const embed = new EmbedBuilder()
    .setColor(COLOR)
    .setDescription("**Deseja realmente encerrar esta partida?**");
  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(BINGO_IDS.encerrarConfirmar)
      .setLabel("CONFIRMAR")
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId(BINGO_IDS.encerrarCancelar)
      .setLabel("CANCELAR")
      .setStyle(ButtonStyle.Secondary),
  );
  return { embeds: [embed], components: [row] };
}

// -----------------------------------------------------------------------
// Resultado do BINGO
// -----------------------------------------------------------------------

// Recebe TODAS as cartelas vencedoras encontradas (um jogador pode ter
// mais de uma cartela e mais de uma bater ao mesmo tempo).
export function buildBingoValidEmbed(playerId: string, cardNumbers: number[]) {
  const list = cardNumbers
    .map((n) => `#${String(n).padStart(4, "0")}`)
    .join(", ");
  const label =
    cardNumbers.length > 1 ? "Cartelas vencedoras" : "Cartela vencedora";
  return new EmbedBuilder()
    .setColor(0x2ecc71)
    .setDescription(
      "━━━━━━━━━━━━━━━━━━━━\n**BINGO!**\n━━━━━━━━━━━━━━━━━━━━\n\n" +
        `**Jogador:** <@${playerId}>\n**${label}:** ${list}\n\n**BINGO VÁLIDO**`,
    );
}

// -----------------------------------------------------------------------
// Usado pelo painel administrativo (/adm) para refletir mudanças feitas
// por lá (pausar/retomar/encerrar) na mensagem pública da partida.
// -----------------------------------------------------------------------

export async function refreshMatchPanel(guild: Guild, matchId?: string) {
  const match = matchId
    ? await getMatchById(matchId)
    : await getCurrentMatch(guild.id);
  if (!match || match.guildId !== guild.id || !match.messageId) return;
  if (
    await require("../database/prisma").prisma.bingoExperienceState.findUnique({
      where: { matchId: match.id },
    })
  )
    return require("./community").refresh(guild, match.id);

  const channel = await guild.channels.fetch(match.channelId).catch(() => null);
  if (!channel?.isTextBased() || channel.isDMBased()) return;

  const message = await channel.messages
    .fetch(match.messageId)
    .catch(() => null);
  if (!message) return;

  const draws = await getDraws(match.id);
  await message.edit(buildBingoPanel(match, draws)).catch(() => null);
}

// -----------------------------------------------------------------------
// Painel de retirada de cartelas
// -----------------------------------------------------------------------

export function buildCardPanelMessage(config?: {
  cardEmbedTitle?: string | null;
  cardEmbedDescription?: string | null;
  cardEmbedImage?: string | null;
  cardEmbedThumbnail?: string | null;
  cardEmbedColor?: string | null;
  price1Qty?: number;
  price1Text?: string;
  price3Qty?: number;
  price3Text?: string;
  price10Qty?: number;
  price10Text?: string;
}) {
  const p1q = config?.price1Qty ?? 1;
  const p1t = config?.price1Text ?? "R$ 2,00";
  const p3q = config?.price3Qty ?? 3;
  const p3t = config?.price3Text ?? "R$ 5,00";
  const p10q = config?.price10Qty ?? 10;
  const p10t = config?.price10Text ?? "R$ 10,00";

  const embed = new EmbedBuilder()
    .setColor(
      (config?.cardEmbedColor
        ? (`#${config.cardEmbedColor}` as `#${string}`)
        : COLOR) as any,
    )
    .setTitle(config?.cardEmbedTitle || "🎫 CARTELAS DO BINGO")
    .setDescription(
      config?.cardEmbedDescription ||
        "Selecione abaixo o pacote que deseja comprar.\n\n" +
          `**${p1q} cartela** — ${p1t}\n**${p3q} cartelas** — ${p3t}\n**${p10q} cartelas** — ${p10t}\n\n` +
          "Ao selecionar, um canal privado é aberto para você combinar o pagamento com a staff. Assim que confirmado, suas cartelas chegam na sua DM.",
    );

  if (config?.cardEmbedImage) embed.setImage(config.cardEmbedImage);
  if (config?.cardEmbedThumbnail) embed.setThumbnail(config.cardEmbedThumbnail);

  const select = new StringSelectMenuBuilder()
    .setCustomId(BINGO_IDS.comprarSelect)
    .setPlaceholder("🎟️ Selecione a quantidade de cartelas...")
    .addOptions(
      { label: `${p1q} CARTELA — ${p1t}`, value: "1", emoji: "🎫" },
      { label: `${p3q} CARTELAS — ${p3t}`, value: "3", emoji: "🎫" },
      { label: `${p10q} CARTELAS — ${p10t}`, value: "10", emoji: "🎫" },
    );

  const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    select,
  );

  const row2 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(BINGO_IDS.reenviarCartelas)
      .setLabel("Reenviar por DM")
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId("bingo-card-view:0")
      .setLabel("Ver minhas cartelas aqui")
      .setStyle(ButtonStyle.Primary),
  );

  return { embeds: [embed], components: [row, row2] };
}

// Grade 5x5 em formato de tabela (monoespaçado) para exibir a cartela do
// jogador, com os números já sorteados marcados.
export function buildCardEmbed(
  card: { cardNumber: number; numbers: string },
  drawnNumbers: Set<number> = new Set(),
) {
  const numbers = JSON.parse(card.numbers) as (number | null)[];
  const header = " B    I    N    G    O ";
  const rows: string[] = [header, "-".repeat(header.length)];

  for (let row = 0; row < 5; row++) {
    const cells = [0, 1, 2, 3, 4].map((col) => {
      const value = numbers[row * 5 + col];
      if (value === null) return " ** ";
      const marked = drawnNumbers.has(value);
      const text = String(value).padStart(2, "0");
      return marked ? `[${text}]` : ` ${text} `;
    });
    rows.push(cells.join(" "));
  }

  return new EmbedBuilder()
    .setColor(COLOR)
    .setTitle(`Cartela #${String(card.cardNumber).padStart(4, "0")}`)
    .setDescription("```\n" + rows.join("\n") + "\n```");
}

// Publica (ou move) o painel de retirada de cartelas no canal informado.
export async function publishCardPanel(guild: Guild, channelId: string) {
  const config = await getBingoConfig(guild.id);
  if (config.cardPanelChannelId && config.cardPanelMessageId) {
    const oldChannel = await guild.channels
      .fetch(config.cardPanelChannelId)
      .catch(() => null);
    if (oldChannel?.isTextBased() && !oldChannel.isDMBased()) {
      const oldMessage = await oldChannel.messages
        .fetch(config.cardPanelMessageId)
        .catch(() => null);
      await oldMessage?.delete().catch(() => null);
    }
  }
  const channel = await guild.channels.fetch(channelId);
  if (!channel?.isTextBased() || channel.isDMBased())
    throw new Error("Canal inválido para o painel de cartelas.");
  const message = await channel.send(buildCardPanelMessage(config));
  await updateBingoConfig(guild.id, {
    cardPanelChannelId: channelId,
    cardPanelMessageId: message.id,
  });
  return message;
}

// Reaplica a personalização atual no painel de cartelas já publicado
// (chamado depois de editar título/descrição/banner/thumbnail/cor).
export async function refreshCardPanel(guild: Guild) {
  const config = await getBingoConfig(guild.id);
  if (!config.cardPanelChannelId || !config.cardPanelMessageId) return;
  const channel = await guild.channels
    .fetch(config.cardPanelChannelId)
    .catch(() => null);
  if (!channel?.isTextBased() || channel.isDMBased()) return;
  const message = await channel.messages
    .fetch(config.cardPanelMessageId)
    .catch(() => null);
  if (!message) return;
  await message.edit(buildCardPanelMessage(config)).catch(() => null);
}

// -----------------------------------------------------------------------
// Ticket de compra
// -----------------------------------------------------------------------

export function buildOrderTicketMessage(
  order: {
    id: string;
    buyerId: string;
    quantity: number;
    price: string;
    status: string;
  },
  paymentInstructions?: string | null,
) {
  const embed = new EmbedBuilder()
    .setColor(COLOR)
    .setTitle("🎫 Pedido de Cartelas")
    .addFields(
      { name: "Comprador", value: `<@${order.buyerId}>`, inline: true },
      {
        name: "Pacote",
        value: `${order.quantity} cartela${order.quantity > 1 ? "s" : ""} — ${order.price}`,
        inline: true,
      },
      {
        name: "Status",
        value:
          order.status === "AGUARDANDO_PAGAMENTO"
            ? "**Aguardando pagamento**"
            : order.status === "ENTREGUE"
              ? "**Entregue**"
              : "**Cancelado**",
        inline: false,
      },
    );

  if (paymentInstructions)
    embed.addFields({ name: "Como pagar", value: paymentInstructions });

  const deliverButton = new ButtonBuilder()
    .setCustomId(`${BINGO_IDS.orderDeliverPrefix}${order.id}`)
    .setLabel("ENTREGAR CARTELAS")
    .setStyle(ButtonStyle.Success)
    .setDisabled(order.status !== "AGUARDANDO_PAGAMENTO");

  const cancelButton = new ButtonBuilder()
    .setCustomId(`${BINGO_IDS.orderCancelPrefix}${order.id}`)
    .setLabel("CANCELAR PEDIDO")
    .setStyle(ButtonStyle.Danger)
    .setDisabled(order.status !== "AGUARDANDO_PAGAMENTO");

  return {
    embeds: [embed],
    components:
      order.status === "AGUARDANDO_PAGAMENTO"
        ? [
            new ActionRowBuilder<ButtonBuilder>().addComponents(
              deliverButton,
              cancelButton,
            ),
          ]
        : [],
  };
}

// Abre o canal privado ("ticket") do pedido, reaproveitando a categoria e
// os cargos de staff já configurados no sistema de Tickets do bot.
export async function createOrderTicket(
  guild: Guild,
  buyerId: string,
  quantity: number,
  priceText: string,
) {
  const tConfig = await ticketConfig(guild.id);
  const bConfig = await getBingoConfig(guild.id);
  const buyer = await guild.members.fetch(buyerId);

  const overwrites: any[] = [
    { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
    {
      id: buyerId,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
      ],
    },
    ...ids(tConfig.staffRoleIds).map((id) => ({
      id,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
      ],
    })),
  ];

  const channel = await guild.channels.create({
    name: `cartela-${buyer.user.username}`
      .toLowerCase()
      .replace(/[^a-z0-9-]/g, "")
      .slice(0, 90),
    type: ChannelType.GuildText,
    // Categoria própria do Bingo, se configurada; senão cai na categoria
    // do sistema de Tickets, igual antes.
    parent: bConfig.cardTicketCategoryId || tConfig.categoryId || undefined,
    permissionOverwrites: overwrites,
  });

  const order = await createOrder(
    guild.id,
    buyerId,
    channel.id,
    quantity,
    priceText,
  );
  await channel.send({
    content: `<@${buyerId}>`,
    ...buildOrderTicketMessage(order, bConfig.paymentInstructions),
  });

  return { channel, order };
}

// Monta as embeds das cartelas entregues para enviar na DM do comprador.
export function buildCardsDeliveryDM(
  cards: { cardNumber: number; numbers: string }[],
) {
  return cards.map((card) => buildCardEmbed(card));
}
