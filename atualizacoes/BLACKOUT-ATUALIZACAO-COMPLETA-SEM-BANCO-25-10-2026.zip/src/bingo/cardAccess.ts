import {
  D,
  prisma,
  embed,
  payload,
  row,
  button,
  guard,
  member,
} from "../games-chat/experience/common";
import {
  getAllActiveCardsForPlayer,
  getCurrentMatch,
  getDraws,
} from "./service";
import { buildCardEmbed } from "./views";
export async function view(guild: any, userId: string, page = 0) {
  const cards = await getAllActiveCardsForPlayer(guild.id, userId),
    match = await getCurrentMatch(guild.id);
  if (!cards.length)
    return payload(
      embed(
        "Suas cartelas do Bingo",
        "Você ainda não possui cartelas registradas para a partida atual ou a próxima partida. Consulte o painel de inscrições da comunidade.",
      ),
    );
  const n = Math.max(0, Math.min(Number(page) || 0, cards.length - 1)),
    card = cards[n],
    draws =
      card.matchId && card.matchId === match?.id
        ? await getDraws(card.matchId)
        : [],
    e = buildCardEmbed(card, new Set(draws.map((d) => d.number))).setFooter({
      text: `Só você vê · ${n + 1}/${cards.length} · ${card.matchId ? "Cartela da partida" : "Aguardando a próxima partida"}`,
    });
  return payload(e, [
    row(
      button(`bingo-card-view:${n}`, "Atualizar"),
      button(`bingo-card-view:${n - 1}`, "Anterior", 2, n === 0),
      button(`bingo-card-view:${n + 1}`, "Próxima", 2, n === cards.length - 1),
    ),
  ]);
}
export async function execute(i: any) {
  return guard(i, async () => {
    if (!i.guild) return;
    await member(i.guild, i.user.id);
    const page = Number(i.customId.split(":")[1]) || 0;
    if (i.message?.flags?.has?.(D.MessageFlags.Ephemeral)) {
      await i.deferUpdate();
      return i.editReply(await view(i.guild, i.user.id, page));
    }
    await i.deferReply({ flags: D.MessageFlags.Ephemeral });
    return i.editReply(await view(i.guild, i.user.id, page));
  });
}
