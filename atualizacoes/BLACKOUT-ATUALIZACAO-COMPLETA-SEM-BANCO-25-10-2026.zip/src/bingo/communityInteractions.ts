import * as B from "./community";
import * as V from "./communityViews";
import {
  D,
  prisma,
  button,
  row,
  payload,
  embed,
  guard,
  staff,
  member,
  textChannel,
  form,
} from "../games-chat/experience/common";
import { deferPanel, refreshPanel } from "../utils/panelInteraction";
const ephemeral = D.MessageFlags.Ephemeral;
async function privateView(i: any, render: () => Promise<any>) {
  if (i.message?.flags?.has?.(ephemeral)) {
    await deferPanel(i);
    return refreshPanel(i, await render());
  }
  await i.deferReply({ flags: ephemeral });
  return i.editReply(await render());
}
export async function player(i: any) {
  return guard(i, async () => {
    if (!i.guild) return;
    await member(i.guild, i.user.id);
    const [, action, id, page] = i.customId.split(":");
    await B.load(i.guild.id, id);
    if (action === "cards")
      return privateView(i, () =>
        V.cardsView(i.guild, id, i.user.id, Number(page) || 0),
      );
    if (action === "rules")
      return privateView(i, () => V.rulesView(i.guild, id));
    if (action === "history")
      return privateView(i, () => V.historyView(i.guild, id));
    if (action === "join") {
      await i.deferReply({ flags: ephemeral });
      await B.join(i.guild, id, i.user.id);
      await B.refresh(i.guild, id).catch(() => null);
      return i.editReply(await V.cardsView(i.guild, id, i.user.id));
    }
    if (action === "leave-confirm")
      return privateView(i, async () =>
        payload(
          embed(
            "Sair das inscrições?",
            "Sua cartela desta partida será removida. Você pode entrar novamente enquanto houver vagas e as inscrições estiverem abertas.",
          ),
          [
            row(
              button(`bg:leave:${id}`, "Confirmar saída", D.ButtonStyle.Danger),
              button(`bg:cards:${id}:0`, "Continuar no Bingo"),
            ),
          ],
        ),
      );
    if (action === "leave") {
      await deferPanel(i);
      await B.leave(i.guild, id, i.user.id);
      await B.refresh(i.guild, id).catch(() => null);
      return refreshPanel(
        i,
        payload(
          embed(
            "Você saiu das inscrições",
            "Sua cartela foi removida desta partida.",
          ),
          [row(button(`bg:join:${id}`, "Participar novamente"))],
        ),
      );
    }
    if (action === "check") {
      await i.deferReply({ flags: ephemeral });
      const result = await B.check(i.guild, id, i.user.id);
      await B.refresh(i.guild, id).catch(() => null);
      return i.editReply(
        payload(
          embed(
            result.won ? "Bingo conferido!" : "Sua cartela continua em jogo",
            result.won
              ? "O sorteio foi pausado. Todas as cartelas aptas neste mesmo sorteio foram registradas para a equipe."
              : `Faltam ${result.missing.length} números na sua melhor combinação: ${result.missing.join(", ")}.`,
          ),
          [row(button(`bg:cards:${id}:0`, "Minha cartela"))],
        ),
      );
    }
    throw Error("Ação não encontrada.");
  });
}
export async function admin(i: any) {
  return guard(i, async () => {
    await staff(i);
    const [, action, id, page] = i.customId.split(":"),
      c = await B.config(i.guild.id);
    if (action === "home") {
      await deferPanel(i);
      return refreshPanel(i, await V.adminView(i.guild));
    }
    if (action === "appearance")
      return refreshPanel(i, await V.appearanceView(i.guild));
    if (action === "appearance-edit")
      return i.showModal(
        form("bg-form:appearance", "Mensagem do Bingo", [
          { id: "title", label: "Título", value: c.title, max: 100 },
          {
            id: "description",
            label: "Texto",
            value: c.description,
            max: 1000,
            long: true,
          },
          { id: "color", label: "Cor hexadecimal", value: c.color, max: 7 },
          {
            id: "footer",
            label: "Rodapé",
            value: c.footer,
            max: 150,
            required: false,
          },
        ]),
      );
    if (action === "rules")
      return i.showModal(
        form("bg-form:rules", "Regras do Bingo", [
          {
            id: "minimum",
            label: "Mínimo de participantes (1 a 200)",
            value: c.minPlayers,
            max: 3,
          },
          {
            id: "maximum",
            label: "Máximo de participantes (1 a 200)",
            value: c.maxPlayers,
            max: 3,
          },
          {
            id: "automatic",
            label: "Modo de sorteio: manual ou automático",
            value: c.automatic ? "AUTOMATICO" : "MANUAL",
            max: 10,
          },
          {
            id: "interval",
            label: "Intervalo dos números: 10 a 120 segundos",
            value: c.intervalSeconds,
            max: 3,
          },
        ]),
      );
    if (action === "create-confirm")
      return refreshPanel(
        i,
        payload(
          embed(
            "Abrir inscrições do Bingo?",
            `Uma mensagem de participação gratuita será publicada em ${c.channelId ? "<#" + c.channelId + ">" : "um canal ainda não configurado"}.\nObjetivo: ${B.OBJECTIVES[c.objective]}.\nCartelas antigas sem partida não serão consumidas por este evento.`,
          ),
          [
            row(
              button(
                "bg-admin:create",
                "Publicar inscrições",
                D.ButtonStyle.Primary,
              ),
              button("bg-admin:home", "Cancelar"),
            ),
          ],
        ),
      );
    if (action === "create") {
      await deferPanel(i);
      await B.create(i.guild, i.user.id);
      return refreshPanel(i, await V.adminView(i.guild));
    }
    if (action === "publish-update") {
      await deferPanel(i);
      const m = await prisma.bingoMatch.findFirst({
        where: {
          guildId: i.guild.id,
          status: { in: ["EM_ANDAMENTO", "PAUSADA"] },
        },
      });
      if (!m)
        throw Error(
          "Não há um Bingo comunitário aberto. Abra as inscrições primeiro.",
        );
      await B.refresh(i.guild, m.id);
      return refreshPanel(i, await V.appearanceView(i.guild));
    }
    if (action === "winners") {
      await deferPanel(i);
      return refreshPanel(
        i,
        await V.winnersView(i.guild, id, Number(page) || 0),
      );
    }
    if (action === "end-confirm") {
      await B.load(i.guild.id, id);
      return refreshPanel(
        i,
        payload(
          embed(
            "Encerrar esta partida?",
            "Os sorteios serão interrompidos. Cartelas, números e resultados permanecem no histórico.",
          ),
          [
            row(
              button(
                `bg-admin:end:${id}`,
                "Confirmar encerramento",
                D.ButtonStyle.Danger,
              ),
              button("bg-admin:home", "Cancelar"),
            ),
          ],
        ),
      );
    }
    if (["start", "pause", "resume", "end", "draw"].includes(action)) {
      await deferPanel(i);
      await B.load(i.guild.id, id);
      if (action === "start") await B.start(i.guild.id, id);
      if (action === "pause") await B.pause(i.guild.id, id);
      if (action === "resume") await B.resume(i.guild.id, id);
      if (action === "end") await B.end(i.guild.id, id);
      if (action === "draw") await B.draw(i.guild.id, id);
      await B.refresh(i.guild, id);
      return refreshPanel(i, await V.adminView(i.guild));
    }
    throw Error("Ação não encontrada.");
  });
}
export async function select(i: any) {
  return guard(i, async () => {
    await staff(i);
    await B.config(i.guild.id);
    if (i.customId === "bg-select:channel") {
      await textChannel(i.guild, i.values[0]);
      await prisma.bingoExperienceConfig.update({
        where: { guildId: i.guild.id },
        data: { channelId: i.values[0] },
      });
    } else if (i.customId === "bg-select:objective") {
      if (!B.OBJECTIVES[i.values[0]])
        throw Error("Escolha um dos objetivos da lista.");
      await prisma.bingoExperienceConfig.update({
        where: { guildId: i.guild.id },
        data: { objective: i.values[0] },
      });
    } else return;
    await deferPanel(i);
    return refreshPanel(i, await V.adminView(i.guild));
  });
}
export async function modal(i: any) {
  return guard(i, async () => {
    await staff(i);
    const action = i.customId.split(":")[1],
      get = (key: string) => i.fields.getTextInputValue(key).trim();
    await B.config(i.guild.id);
    if (action === "appearance") {
      const color = get("color").replace("#", "");
      if (!get("title") || !get("description") || !/^[0-9a-f]{6}$/i.test(color))
        throw Error("Informe uma cor hexadecimal com seis caracteres.");
      await prisma.bingoExperienceConfig.update({
        where: { guildId: i.guild.id },
        data: {
          title: get("title"),
          description: get("description"),
          color,
          footer: get("footer"),
        },
      });
      await deferPanel(i);
      return refreshPanel(i, await V.appearanceView(i.guild));
    }
    if (action === "rules") {
      const minimum = Number(get("minimum")),
        maximum = Number(get("maximum")),
        automatic = get("automatic")
          .normalize("NFD")
          .replace(/[\u0300-\u036f]/g, "")
          .toUpperCase(),
        interval = Number(get("interval"));
      if (
        !Number.isInteger(minimum) ||
        !Number.isInteger(maximum) ||
        minimum < 1 ||
        maximum > 200 ||
        minimum > maximum ||
        !["MANUAL", "AUTOMATICO"].includes(automatic) ||
        !Number.isInteger(interval) ||
        interval < 10 ||
        interval > 120
      )
        throw Error(
          "Use de 1 a 200 participantes, modo manual ou automático e intervalo de 10 a 120 segundos.",
        );
      await prisma.bingoExperienceConfig.update({
        where: { guildId: i.guild.id },
        data: {
          minPlayers: minimum,
          maxPlayers: maximum,
          automatic: automatic === "AUTOMATICO",
          intervalSeconds: interval,
        },
      });
      await deferPanel(i);
      return refreshPanel(i, await V.adminView(i.guild));
    }
    throw Error("Formulário não encontrado.");
  });
}
