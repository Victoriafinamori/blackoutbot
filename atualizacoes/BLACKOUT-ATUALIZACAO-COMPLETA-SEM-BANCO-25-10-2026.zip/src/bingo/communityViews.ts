import {
  D,
  prisma,
  embed,
  payload,
  row,
  button,
  clean,
} from "../games-chat/experience/common";
import { config, load, progress, OBJECTIVES } from "./community";
import { adminEmbed } from "../utils/adminUi";
export async function publicView(guild: any, matchId: string) {
  const { state, match } = await load(guild.id, matchId),
    c = await config(guild.id),
    [draws, count, claims] = await Promise.all([
      prisma.bingoDraw.findMany({
        where: { matchId },
        orderBy: { order: "asc" },
      }),
      prisma.bingoCard.count({ where: { guildId: guild.id, matchId } }),
      prisma.bingoExperienceClaim.findMany({
        where: { guildId: guild.id, matchId },
        orderBy: { createdAt: "asc" },
        take: 10,
      }),
    ]);
  const e = embed(c.title, c.description)
      .setColor(
        Number.isNaN(parseInt(c.color, 16)) ? 0xd71935 : parseInt(c.color, 16),
      )
      .setFooter(c.footer ? { text: c.footer } : null),
    status: Record<string, string> = {
      LOBBY: "Inscrições abertas",
      RUNNING: "Em andamento",
      PAUSED: "Pausada pela equipe",
      REVIEW: "Vitória conferida · Sorteio pausado",
      ENDED: "Encerrada",
    };
  e.addFields(
    {
      name: "Como participar",
      value: `Gratuito · 1 cartela por pessoa\nParticipantes: ${count}/${state.maxPlayers}`,
    },
    {
      name: "Objetivo desta partida",
      value: OBJECTIVES[state.objective] || state.objective,
    },
    { name: "Estado", value: status[state.phase] || state.phase },
  );
  if (draws.length) {
    const last = draws[draws.length - 1];
    e.addFields(
      {
        name: "Último número",
        value: `**${last.letter} — ${String(last.number).padStart(2, "0")}**`,
      },
      {
        name: "Andamento",
        value: `${draws.length}/75 números\n${draws
          .slice(-5)
          .map((d) => `${d.letter}–${String(d.number).padStart(2, "0")}`)
          .join(" · ")}`,
      },
    );
  }
  if (state.phase === "LOBBY")
    e.addFields({
      name: "Próximo passo",
      value: `Entre antes do início. A equipe abre a rodada quando houver ao menos ${state.minPlayers} participantes.`,
    });
  if (state.phase === "RUNNING")
    e.addFields({
      name: "Ritmo",
      value: state.automatic
        ? state.nextDrawAt
          ? `Próximo número <t:${Math.floor(state.nextDrawAt.getTime() / 1000)}:R> · intervalo ${state.intervalSeconds}s`
          : "Sorteios concluídos. Confira sua cartela."
        : "Sorteios conduzidos pela equipe.",
    });
  if (claims.length)
    e.addFields({
      name: "Vencedores conferidos",
      value:
        claims.map((c) => `<@${c.playerId}> · Cartela registrada`).join("\n") +
        (claims.length === 10
          ? "\nA equipe pode consultar a lista completa."
          : ""),
    });
  return payload(e, [
    row(
      button(
        `bg:join:${matchId}`,
        "Participar",
        D.ButtonStyle.Primary,
        state.phase !== "LOBBY",
      ),
      button(`bg:cards:${matchId}:0`, "Minha cartela"),
      button(
        `bg:check:${matchId}`,
        "Conferir bingo",
        D.ButtonStyle.Secondary,
        !["RUNNING", "PAUSED", "REVIEW"].includes(state.phase),
      ),
    ),
    row(
      button(`bg:history:${matchId}`, "Números sorteados"),
      button(`bg:rules:${matchId}`, "Como jogar"),
    ),
  ]);
}
export async function cardsView(
  guild: any,
  matchId: string,
  userId: string,
  page = 0,
) {
  const { state } = await load(guild.id, matchId),
    cards = await prisma.bingoCard.findMany({
      where: { guildId: guild.id, matchId, playerId: userId },
      orderBy: { cardNumber: "asc" },
    });
  if (!cards.length)
    return payload(
      embed(
        "Você ainda não entrou nesta partida",
        state.phase === "LOBBY"
          ? "Participe para receber uma cartela gratuita."
          : "As inscrições terminaram. Você poderá entrar na próxima partida.",
      ),
      [
        row(
          button(
            `bg:join:${matchId}`,
            "Participar",
            D.ButtonStyle.Primary,
            state.phase !== "LOBBY",
          ),
        ),
      ],
    );
  const n = Math.max(0, Math.min(Number(page) || 0, cards.length - 1)),
    card = cards[n],
    draws = await prisma.bingoDraw.findMany({
      where: { matchId },
      orderBy: { order: "asc" },
    }),
    drawn = new Set(draws.map((d) => d.number)),
    numbers = JSON.parse(card.numbers),
    p = progress(numbers, drawn, state.objective),
    lines = [" B    I    N    G    O"];
  for (let r = 0; r < 5; r++)
    lines.push(
      Array.from({ length: 5 }, (_, c) => {
        const value = numbers[r * 5 + c];
        return value === null
          ? " ** "
          : drawn.has(value)
            ? `[${String(value).padStart(2, "0")}]`
            : ` ${String(value).padStart(2, "0")} `;
      }).join(" "),
    );
  const last = draws[draws.length - 1],
    e = embed(
      `Sua cartela #${String(card.cardNumber).padStart(4, "0")}`,
      "```\n" + lines.join("\n") + "\n```",
    )
      .addFields(
        { name: "Objetivo", value: OBJECTIVES[state.objective] },
        {
          name: "Seu progresso",
          value: p.won
            ? "Você completou o objetivo. Use Conferir bingo."
            : `Faltam ${p.missing.length} números na melhor combinação: ${p.missing.map((x) => String(x).padStart(2, "0")).join(", ")}.`,
        },
        {
          name: "Última consulta",
          value: `${last ? `${last.letter}–${String(last.number).padStart(2, "0")}` : "Nenhum número sorteado"}\n[ ] = sorteado · ** = centro livre\nUse Atualizar para acompanhar novos números.`,
        },
      )
      .setFooter({
        text: `Só você vê esta cartela · ${n + 1}/${cards.length}`,
      });
  const actions = [
    row(
      button(`bg:cards:${matchId}:${n}`, "Atualizar"),
      button(
        `bg:check:${matchId}`,
        "Conferir bingo",
        D.ButtonStyle.Primary,
        !["RUNNING", "PAUSED", "REVIEW"].includes(state.phase),
      ),
      button(`bg:rules:${matchId}`, "Como jogar"),
    ),
  ];
  if (cards.length > 1)
    actions.push(
      row(
        button(`bg:cards:${matchId}:${n - 1}`, "Anterior", 2, n === 0),
        button(
          `bg:cards:${matchId}:${n + 1}`,
          "Próxima",
          2,
          n === cards.length - 1,
        ),
      ),
    );
  if (state.phase === "LOBBY")
    actions.push(
      row(button(`bg:leave-confirm:${matchId}`, "Sair antes de começar")),
    );
  return payload(e, actions);
}
export async function rulesView(guild: any, matchId: string) {
  const { state } = await load(guild.id, matchId);
  return payload(
    embed(
      "Como jogar Bingo",
      `1. Participe enquanto as inscrições estiverem abertas.\n2. Consulte Minha cartela: os números sorteados aparecem marcados.\n3. Complete o objetivo: **${OBJECTIVES[state.objective]}**.\n4. Use Conferir bingo. A validação usa os números registrados da partida.\n\nAs cartelas aptas no mesmo sorteio são conferidas juntas. Você pode acessar a sua cartela pelo servidor, sem depender de DM.`,
    ),
    [
      row(
        button(`bg:cards:${matchId}:0`, "Minha cartela", D.ButtonStyle.Primary),
      ),
    ],
  );
}
export async function historyView(guild: any, matchId: string) {
  await load(guild.id, matchId);
  const draws = await prisma.bingoDraw.findMany({
    where: { matchId },
    orderBy: { order: "asc" },
  });
  const e = embed(
    "Números sorteados",
    `${draws.length}/75 números registrados.`,
  );
  for (const letter of ["B", "I", "N", "G", "O"])
    e.addFields({
      name: letter,
      value:
        draws
          .filter((d) => d.letter === letter)
          .map((d) => String(d.number).padStart(2, "0"))
          .join(" · ") || "Ainda não sorteado.",
    });
  return payload(e, [row(button(`bg:cards:${matchId}:0`, "Minha cartela"))]);
}
export async function winnersView(guild: any, matchId: string, page = 0) {
  await load(guild.id, matchId);
  const where = { guildId: guild.id, matchId },
    count = await prisma.bingoExperienceClaim.count({ where }),
    n = Math.max(
      0,
      Math.min(Number(page) || 0, Math.max(0, Math.ceil(count / 10) - 1)),
    ),
    claims = await prisma.bingoExperienceClaim.findMany({
      where,
      orderBy: { createdAt: "asc" },
      skip: n * 10,
      take: 10,
    });
  return payload(
    embed(
      "Conferência de vencedores",
      claims.length
        ? claims
            .map(
              (c, k) =>
                `${n * 10 + k + 1}. <@${c.playerId}> · Registro ${clean(c.cardId, 35)}`,
            )
            .join("\n")
        : "Nenhuma vitória conferida nesta partida.",
    ).setFooter({ text: `${count} cartelas aptas · Página ${n + 1}` }),
    [
      row(
        button(`bg-admin:winners:${matchId}:${n - 1}`, "Anterior", 2, n === 0),
        button(
          `bg-admin:winners:${matchId}:${n + 1}`,
          "Próxima",
          2,
          (n + 1) * 10 >= count,
        ),
        button("bg-admin:home", "Voltar"),
      ),
    ],
  );
}
export async function appearanceView(guild: any) {
  const c = await config(guild.id);
  return {
    content:
      "**Prévia · Bingo da comunidade**\nO visual salvo aparece abaixo. Aplicar ao painel publicado é uma ação separada.",
    embeds: [
      embed(c.title, c.description)
        .setColor(
          Number.isNaN(parseInt(c.color, 16))
            ? 0xd71935
            : parseInt(c.color, 16),
        )
        .setFooter(c.footer ? { text: c.footer } : null),
    ],
    components: [
      row(
        button("bg-admin:appearance-edit", "Editar mensagem"),
        button(
          "bg-admin:publish-update",
          "Atualizar painel publicado",
          D.ButtonStyle.Primary,
        ),
        button("bg-admin:home", "Voltar"),
      ),
    ],
    allowedMentions: { parse: [] },
  };
}
export async function adminView(guild: any) {
  const c = await config(guild.id),
    match = await prisma.bingoMatch.findFirst({
      where: { guildId: guild.id, status: { in: ["EM_ANDAMENTO", "PAUSADA"] } },
    }),
    state = match
      ? await prisma.bingoExperienceState.findUnique({
          where: { matchId: match.id },
        })
      : null;
  const e = adminEmbed(guild, "staff")
    .setTitle("Bingo da comunidade")
    .setDescription(
      "Inscrições gratuitas, uma cartela por participante e acesso pelo próprio servidor. As regras salvas são usadas na próxima partida.",
    )
    .addFields(
      {
        name: "Próximo evento",
        value: `Canal: ${c.channelId ? "<#" + c.channelId + ">" : "Não configurado"}\nObjetivo: ${OBJECTIVES[c.objective]}`,
      },
      {
        name: "Participação e ritmo",
        value: `De ${c.minPlayers} a ${c.maxPlayers} participantes\n${c.automatic ? "Automático · " + c.intervalSeconds + " segundos entre números" : "Sorteio manual pela equipe"}`,
      },
      {
        name: "Partida atual",
        value: state
          ? `#${match!.number} · ${state.phase === "LOBBY" ? "Inscrições abertas" : state.phase === "RUNNING" ? "Em andamento" : state.phase === "PAUSED" ? "Pausada" : "Conferência de vencedores"}\n${await prisma.bingoCard.count({ where: { guildId: guild.id, matchId: state.matchId } })} participantes`
          : match
            ? "Há uma partida do fluxo anterior aberta. Finalize-a antes de abrir um Bingo comunitário."
            : "Nenhum Bingo aberto.",
      },
    );
  if (state?.lastError)
    e.addFields({
      name: "Aviso da partida",
      value: clean(state.lastError, 500),
    });
  const rows: any[] = [
    row(
      new D.StringSelectMenuBuilder()
        .setCustomId("bg-select:objective")
        .setPlaceholder("Objetivo da próxima partida")
        .addOptions(
          Object.entries(OBJECTIVES).map(([value, label]) => ({
            value,
            label,
            default: c.objective === value,
          })),
        ),
    ),
    row(
      new D.ChannelSelectMenuBuilder()
        .setCustomId("bg-select:channel")
        .setPlaceholder("Canal das inscrições")
        .addChannelTypes(D.ChannelType.GuildText)
        .setDefaultChannels(...(c.channelId ? [c.channelId] : [])),
    ),
    row(
      button("bg-admin:rules", "Regras e ritmo"),
      button("bg-admin:appearance", "Mensagem e prévia"),
      button(
        "bg-admin:create-confirm",
        "Abrir inscrições",
        D.ButtonStyle.Primary,
        Boolean(match) || !c.channelId,
      ),
    ),
  ];
  if (state) {
    rows.push(
      row(
        button(
          `bg-admin:start:${state.matchId}`,
          "Iniciar rodada",
          D.ButtonStyle.Primary,
          state.phase !== "LOBBY",
        ),
        button(
          `bg-admin:${state.phase === "PAUSED" ? "resume" : "pause"}:${state.matchId}`,
          state.phase === "PAUSED" ? "Retomar" : "Pausar",
          2,
          !["RUNNING", "PAUSED"].includes(state.phase),
        ),
        button(
          `bg-admin:draw:${state.matchId}`,
          "Sortear número",
          2,
          state.phase !== "RUNNING",
        ),
        button(`bg-admin:winners:${state.matchId}:0`, "Vencedores"),
        button(
          `bg-admin:end-confirm:${state.matchId}`,
          "Encerrar",
          D.ButtonStyle.Danger,
        ),
      ),
    );
  }
  rows.push(
    row(
      button("bg-admin:home", "Atualizar"),
      button("adm-bingo:menu", "Bingo geral"),
      button("adm-nav:staff", "Voltar a Jogos e eventos"),
    ),
  );
  return { attachments: [], ...payload(e, rows) };
}
