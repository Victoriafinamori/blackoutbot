import { randomInt } from "node:crypto";
import {
  D,
  prisma,
  lock,
  member,
  textChannel,
} from "../games-chat/experience/common";
export const OBJECTIVES: Record<string, string> = {
  ANY_LINE: "Uma linha, coluna ou diagonal",
  FULL_CARD: "Cartela cheia",
  FOUR_CORNERS: "Os quatro cantos",
};
export const config = (guildId: string) =>
  prisma.bingoExperienceConfig.upsert({
    where: { guildId },
    create: { guildId },
    update: {},
  });
export function patterns(objective: string): number[][] {
  if (objective === "FULL_CARD")
    return [Array.from({ length: 25 }, (_, i) => i)];
  if (objective === "FOUR_CORNERS") return [[0, 4, 20, 24]];
  if (objective !== "ANY_LINE") throw Error("Objetivo inválido.");
  return [
    ...Array.from({ length: 5 }, (_, r) =>
      Array.from({ length: 5 }, (_, c) => r * 5 + c),
    ),
    ...Array.from({ length: 5 }, (_, c) =>
      Array.from({ length: 5 }, (_, r) => r * 5 + c),
    ),
    [0, 6, 12, 18, 24],
    [4, 8, 12, 16, 20],
  ];
}
export function progress(
  numbers: (number | null)[],
  drawn: Set<number>,
  objective: string,
) {
  if (
    !Array.isArray(numbers) ||
    numbers.length !== 25 ||
    numbers.some((n, i) =>
      i === 12
        ? n !== null
        : !Number.isInteger(n) || Number(n) < 1 || Number(n) > 75,
    )
  )
    throw Error("A cartela está inconsistente. Avise a equipe.");
  if (
    new Set(numbers.filter((n) => n !== null)).size !== 24 ||
    numbers.some(
      (n, i) =>
        n !== null &&
        (n < Math.floor((i % 5) * 15) + 1 || n > ((i % 5) + 1) * 15),
    )
  )
    throw Error("A cartela está inconsistente. Avise a equipe.");
  const missing = patterns(objective).map((indices) =>
    indices
      .map((i) => numbers[i])
      .filter((n): n is number => n !== null && !drawn.has(n)),
  );
  missing.sort((a, b) => a.length - b.length);
  return { won: missing[0].length === 0, missing: missing[0] };
}
export async function load(guildId: string, matchId: string) {
  const [state, match] = await Promise.all([
    prisma.bingoExperienceState.findUnique({ where: { matchId } }),
    prisma.bingoMatch.findUnique({ where: { id: matchId } }),
  ]);
  if (
    !state ||
    !match ||
    state.guildId !== guildId ||
    match.guildId !== guildId
  )
    throw Error(
      "Esta partida não pertence a este servidor ou não está disponível.",
    );
  return { state, match };
}
async function nextCard(tx: any, guildId: string) {
  return (
    (
      await tx.bingoCard.findFirst({
        where: { guildId },
        orderBy: { cardNumber: "desc" },
      })
    )?.cardNumber + 1 || 1
  );
}
export async function create(guild: any, actorId: string) {
  return lock("bingo:" + guild.id, async () => {
    const c = await config(guild.id),
      ch = await textChannel(guild, c.channelId);
    if (!OBJECTIVES[c.objective]) throw Error("Escolha um objetivo válido.");
    const { match, state } = await prisma.$transaction(async (tx) => {
      if (
        await tx.bingoMatch.findFirst({
          where: {
            guildId: guild.id,
            status: { in: ["EM_ANDAMENTO", "PAUSADA"] },
          },
        })
      )
        throw Error(
          "Já existe um Bingo aberto. Acompanhe ou encerre a partida atual.",
        );
      const last = await tx.bingoMatch.findFirst({
          where: { guildId: guild.id },
          orderBy: { number: "desc" },
        }),
        match = await tx.bingoMatch.create({
          data: {
            guildId: guild.id,
            channelId: ch.id,
            number: (last?.number || 0) + 1,
            startedById: actorId,
            status: "PAUSADA",
          },
        });
      const state = await tx.bingoExperienceState.create({
        data: {
          guildId: guild.id,
          matchId: match.id,
          objective: c.objective,
          minPlayers: c.minPlayers,
          maxPlayers: c.maxPlayers,
          automatic: c.automatic,
          intervalSeconds: c.intervalSeconds,
        },
      });
      return { match, state };
    });
    let message: any;
    try {
      message = await ch.send(
        await require("./communityViews").publicView(guild, match.id),
      );
      await prisma.bingoMatch.update({
        where: { id: match.id },
        data: { messageId: message.id },
      });
      return { match: { ...match, messageId: message.id }, state };
    } catch (e) {
      if (message) await message.delete().catch(() => null);
      await prisma.bingoExperienceState.update({
        where: { matchId: match.id },
        data: {
          phase: "ENDED",
          lastError: "Não foi possível publicar as inscrições.",
        },
      });
      await prisma.bingoMatch.update({
        where: { id: match.id },
        data: { status: "ENCERRADA", endedAt: new Date() },
      });
      throw e;
    }
  });
}
export async function join(guild: any, matchId: string, userId: string) {
  await member(guild, userId);
  return lock("bingo:" + guild.id, async () => {
    const { state } = await load(guild.id, matchId);
    if (state.phase !== "LOBBY")
      throw Error(
        "As inscrições foram encerradas. Acompanhe esta partida e entre na próxima.",
      );
    return prisma.$transaction(async (tx) => {
      const existing = await tx.bingoCard.findFirst({
        where: { guildId: guild.id, matchId, playerId: userId },
      });
      if (existing) return existing;
      if (
        (await tx.bingoCard.count({ where: { guildId: guild.id, matchId } })) >=
        state.maxPlayers
      )
        throw Error("As vagas desta partida foram preenchidas.");
      const numbers = require("./service").generateCardNumbers();
      return tx.bingoCard.create({
        data: {
          guildId: guild.id,
          matchId,
          playerId: userId,
          cardNumber: await nextCard(tx, guild.id),
          numbers: JSON.stringify(numbers),
        },
      });
    });
  });
}
export async function leave(guild: any, matchId: string, userId: string) {
  return lock("bingo:" + guild.id, async () => {
    const { state } = await load(guild.id, matchId);
    if (state.phase !== "LOBBY")
      throw Error("A partida já começou. Sua cartela permanece registrada.");
    await prisma.bingoCard.deleteMany({
      where: { guildId: guild.id, matchId, playerId: userId },
    });
  });
}
export async function start(guildId: string, matchId: string) {
  return lock("bingo:" + guildId, async () => {
    const { state } = await load(guildId, matchId);
    if (state.phase !== "LOBBY") throw Error("Esta partida já começou.");
    if (
      (await prisma.bingoCard.count({ where: { guildId, matchId } })) <
      state.minPlayers
    )
      throw Error(
        `Aguarde ao menos ${state.minPlayers} participantes para começar.`,
      );
    await prisma.$transaction([
      prisma.bingoMatch.update({
        where: { id: matchId },
        data: { status: "EM_ANDAMENTO" },
      }),
      prisma.bingoExperienceState.update({
        where: { matchId },
        data: {
          phase: "RUNNING",
          nextDrawAt: state.automatic
            ? new Date(Date.now() + state.intervalSeconds * 1000)
            : null,
          lastError: null,
        },
      }),
    ]);
  });
}
export async function pause(guildId: string, matchId: string) {
  return lock("bingo:" + guildId, async () => {
    const { state } = await load(guildId, matchId);
    if (state.phase !== "RUNNING")
      throw Error("Esta rodada não está em andamento.");
    await prisma.$transaction([
      prisma.bingoMatch.update({
        where: { id: matchId },
        data: { status: "PAUSADA" },
      }),
      prisma.bingoExperienceState.update({
        where: { matchId },
        data: { phase: "PAUSED", nextDrawAt: null },
      }),
    ]);
  });
}
export async function resume(guildId: string, matchId: string) {
  return lock("bingo:" + guildId, async () => {
    const { state } = await load(guildId, matchId);
    if (state.phase !== "PAUSED")
      throw Error("Conclua as inscrições ou a conferência antes de retomar.");
    await prisma.$transaction([
      prisma.bingoMatch.update({
        where: { id: matchId },
        data: { status: "EM_ANDAMENTO" },
      }),
      prisma.bingoExperienceState.update({
        where: { matchId },
        data: {
          phase: "RUNNING",
          nextDrawAt: state.automatic
            ? new Date(Date.now() + state.intervalSeconds * 1000)
            : null,
        },
      }),
    ]);
  });
}
export async function end(guildId: string, matchId: string) {
  return lock("bingo:" + guildId, async () => {
    await load(guildId, matchId);
    await prisma.$transaction([
      prisma.bingoMatch.update({
        where: { id: matchId },
        data: { status: "ENCERRADA", endedAt: new Date() },
      }),
      prisma.bingoExperienceState.update({
        where: { matchId },
        data: { phase: "ENDED", nextDrawAt: null },
      }),
    ]);
  });
}
export async function draw(
  guildId: string,
  matchId: string,
  scheduled = false,
) {
  return lock("bingo:" + guildId, async () => {
    const { state, match } = await load(guildId, matchId);
    if (state.phase !== "RUNNING" || match.status !== "EM_ANDAMENTO")
      throw Error("A partida precisa estar em andamento para sortear.");
    if (
      scheduled &&
      (!state.automatic || !state.nextDrawAt || state.nextDrawAt > new Date())
    )
      return null;
    return prisma.$transaction(async (tx) => {
      const draws = await tx.bingoDraw.findMany({
          where: { matchId },
          orderBy: { order: "asc" },
        }),
        used = new Set(draws.map((d) => d.number)),
        remaining = Array.from({ length: 75 }, (_, i) => i + 1).filter(
          (n) => !used.has(n),
        );
      if (!remaining.length)
        throw Error(
          "Os 75 números já foram sorteados. Confira os vencedores ou encerre a partida.",
        );
      const claim = await tx.bingoExperienceState.updateMany({
        where: { matchId, phase: "RUNNING", drawVersion: state.drawVersion },
        data: {
          drawVersion: { increment: 1 },
          nextDrawAt:
            state.automatic && remaining.length > 1
              ? new Date(Date.now() + state.intervalSeconds * 1000)
              : null,
          lastError: null,
        },
      });
      if (!claim.count)
        throw Error(
          "O sorteio foi atualizado por outra ação. Atualize o painel.",
        );
      const number = remaining[randomInt(remaining.length)];
      return tx.bingoDraw.create({
        data: {
          matchId,
          number,
          letter: require("./types").letterFor(number),
          order: draws.length + 1,
        },
      });
    });
  });
}
export async function check(guild: any, matchId: string, userId: string) {
  await member(guild, userId);
  return lock("bingo:" + guild.id, async () => {
    const { state } = await load(guild.id, matchId);
    if (!["RUNNING", "PAUSED", "REVIEW"].includes(state.phase))
      throw Error("Aguarde o início da partida para conferir sua cartela.");
    const mine = await prisma.bingoCard.findMany({
      where: { guildId: guild.id, matchId, playerId: userId },
    });
    if (!mine.length) throw Error("Você não tem uma cartela nesta partida.");
    const draws = await prisma.bingoDraw.findMany({ where: { matchId } }),
      drawn = new Set(draws.map((d) => d.number)),
      own = mine.map((c) => ({
        card: c,
        ...progress(JSON.parse(c.numbers), drawn, state.objective),
      }));
    if (!own.some((c) => c.won))
      return {
        won: false,
        missing: own.sort((a, b) => a.missing.length - b.missing.length)[0]
          .missing,
        winners: [],
      };
    // Evaluate all registered cards against the same frozen draw: equal results count together.
    const all = await prisma.bingoCard.findMany({
        where: { guildId: guild.id, matchId },
      }),
      winners = all.filter(
        (c) => progress(JSON.parse(c.numbers), drawn, state.objective).won,
      );
    await prisma.$transaction(async (tx) => {
      await tx.bingoMatch.update({
        where: { id: matchId },
        data: { status: "PAUSADA" },
      });
      await tx.bingoExperienceState.update({
        where: { matchId },
        data: { phase: "REVIEW", nextDrawAt: null },
      });
      for (const c of winners) {
        const existing = await tx.bingoExperienceClaim.findUnique({
          where: { matchId_cardId: { matchId, cardId: c.id } },
        });
        if (existing) continue;
        await tx.bingoExperienceClaim.create({
          data: {
            guildId: guild.id,
            matchId,
            cardId: c.id,
            playerId: c.playerId,
            drawVersion: state.drawVersion,
          },
        });
        await tx.bingoWinner.create({
          data: { matchId, cardId: c.id, playerId: c.playerId, valid: true },
        });
      }
    });
    return { won: true, missing: [], winners };
  });
}
export async function refresh(guild: any, matchId: string) {
  const { match } = await load(guild.id, matchId);
  if (!match.messageId) return;
  const ch = await textChannel(guild, match.channelId),
    message = await ch.messages.fetch(match.messageId).catch(() => null);
  if (message)
    await message.edit(
      await require("./communityViews").publicView(guild, matchId),
    );
}
let ticking = false;
export async function tick(client: any) {
  if (ticking) return;
  ticking = true;
  try {
    const states = await prisma.bingoExperienceState.findMany({
      where: {
        phase: "RUNNING",
        automatic: true,
        nextDrawAt: { lte: new Date() },
      },
    });
    for (const state of states) {
      const guild = client.guilds.cache.get(state.guildId);
      if (!guild) continue;
      try {
        await draw(guild.id, state.matchId, true);
        await refresh(guild, state.matchId);
      } catch (e: any) {
        if (e.code === "GAME_BUSY") continue;
        await prisma.bingoExperienceState
          .update({
            where: { matchId: state.matchId },
            data: {
              phase: "PAUSED",
              nextDrawAt: null,
              lastError: String(e.message).slice(0, 500),
            },
          })
          .catch(() => null);
        await prisma.bingoMatch
          .updateMany({
            where: { id: state.matchId, status: "EM_ANDAMENTO" },
            data: { status: "PAUSADA" },
          })
          .catch(() => null);
        await refresh(guild, state.matchId).catch(() => null);
      }
    }
  } finally {
    ticking = false;
  }
}
