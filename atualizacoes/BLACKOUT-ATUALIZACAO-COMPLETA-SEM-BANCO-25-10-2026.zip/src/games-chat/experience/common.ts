import * as D from "discord.js";
import { prisma } from "../../database/prisma";
import { isBotAdmin } from "../../utils/permissions";
export { D, prisma };
const locks = new Set<string>();
export async function lock<T>(key: string, work: () => Promise<T>): Promise<T> {
  if (locks.has(key)) {
    const error: any = Error(
      "Uma ação está em andamento. Aguarde alguns segundos.",
    );
    error.code = "GAME_BUSY";
    throw error;
  }
  locks.add(key);
  try {
    return await work();
  } finally {
    locks.delete(key);
  }
}
export const button = (
  id: string,
  label: string,
  style: D.ButtonStyle = D.ButtonStyle.Secondary,
  disabled = false,
) =>
  new D.ButtonBuilder()
    .setCustomId(id)
    .setLabel(label)
    .setStyle(style)
    .setDisabled(disabled);
export const row = (...items: any[]) =>
  new D.ActionRowBuilder<any>().addComponents(items);
export const embed = (title: string, description = "") =>
  new D.EmbedBuilder()
    .setColor(0xd71935)
    .setTitle(title)
    .setDescription(description || null);
export const payload = (e: D.EmbedBuilder, components: any[] = []) => ({
  content: null,
  embeds: [e],
  components,
  allowedMentions: { parse: [] as any[] },
});
export const clean = (value: any, max = 100) =>
  String(value ?? "")
    .replace(/[\[\]`*_~>|]/g, "")
    .trim()
    .slice(0, max);
export async function member(guild: any, id: string) {
  const m = await guild.members.fetch(id).catch(() => null);
  if (!m || m.user.bot) throw Error("Participe do servidor para jogar.");
  return m;
}
export async function staff(i: any) {
  if (!i.guild) throw Error("Abra esta opção no servidor.");
  const m = await member(i.guild, i.user.id);
  if (
    !(await isBotAdmin(m)) &&
    !m.permissions.has(D.PermissionFlagsBits.ManageEvents)
  )
    throw Error("Você não tem permissão para conduzir este evento.");
  return m;
}
export async function textChannel(guild: any, id: string | null) {
  const ch = id ? await guild.channels.fetch(id).catch(() => null) : null;
  if (!ch || ch.guildId !== guild.id || ch.type !== D.ChannelType.GuildText)
    throw Error("Escolha um canal de texto deste servidor.");
  const me = guild.members.me || (await guild.members.fetchMe());
  if (
    !ch
      .permissionsFor(me)
      ?.has([
        D.PermissionFlagsBits.ViewChannel,
        D.PermissionFlagsBits.SendMessages,
        D.PermissionFlagsBits.EmbedLinks,
        D.PermissionFlagsBits.ReadMessageHistory,
      ])
  )
    throw Error(
      "O bot precisa ver o canal, enviar mensagens, inserir links e ler o histórico.",
    );
  return ch;
}
export async function guard(i: any, fn: () => Promise<any>) {
  try {
    return await fn();
  } catch (e: any) {
    const p = {
      content: e.message || "Não foi possível concluir. Tente novamente.",
      allowedMentions: { parse: [] },
    };
    if (i.deferred && !i.replied && i.ephemeral === true) return i.editReply(p);
    return i.deferred || i.replied
      ? i.followUp({ ...p, flags: D.MessageFlags.Ephemeral })
      : i.reply({ ...p, flags: D.MessageFlags.Ephemeral });
  }
}
export function form(
  id: string,
  title: string,
  fields: {
    id: string;
    label: string;
    value?: any;
    max?: number;
    required?: boolean;
    long?: boolean;
  }[],
) {
  return new D.ModalBuilder()
    .setCustomId(id)
    .setTitle(title)
    .addComponents(
      ...fields.map((f) => {
        const t = new D.TextInputBuilder()
          .setCustomId(f.id)
          .setLabel(f.label)
          .setStyle(
            f.long ? D.TextInputStyle.Paragraph : D.TextInputStyle.Short,
          )
          .setRequired(f.required !== false)
          .setMaxLength(f.max || 1000);
        if (f.value !== null && f.value !== undefined && String(f.value))
          t.setValue(String(f.value));
        return row(t);
      }),
    );
}
