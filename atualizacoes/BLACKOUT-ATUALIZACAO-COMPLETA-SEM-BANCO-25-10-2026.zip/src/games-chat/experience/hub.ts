import {
  D,
  prisma,
  button,
  row,
  payload,
  embed,
  clean,
  guard,
  staff,
  member,
  textChannel,
  form,
} from "./common";
import { adminEmbed } from "../../utils/adminUi";
import { deferPanel, refreshPanel } from "../../utils/panelInteraction";
import { gamesConfig, termoConfig, mysteryConfig } from "../core/config";
export const config = (guildId: string) =>
  prisma.gamesHubConfig.upsert({
    where: { guildId },
    create: { guildId },
    update: {},
  });
export async function publicView(
  guild: any,
  preview = false,
  styleOverride: any = {},
) {
  const [c, g, t, m, b, box, legacy] = await Promise.all([
    config(guild.id),
    gamesConfig(guild.id),
    termoConfig(guild.id),
    mysteryConfig(guild.id),
    prisma.bingoExperienceState.findFirst({
      where: {
        guildId: guild.id,
        phase: { in: ["LOBBY", "RUNNING", "PAUSED", "REVIEW"] },
      },
      orderBy: { updatedAt: "desc" },
    }),
    prisma.mysteryEvent.findFirst({
      where: { guildId: guild.id, status: "ACTIVE" },
    }),
    prisma.bingoMatch.findFirst({
      where: { guildId: guild.id, status: { in: ["EM_ANDAMENTO", "PAUSADA"] } },
    }),
  ]);
  const style = { ...c, ...styleOverride };
  return payload(
    embed(style.title, style.description)
      .setColor(
        Number.isNaN(parseInt(style.color, 16))
          ? 0xd71935
          : parseInt(style.color, 16),
      )
      .addFields(
        {
          name: "Jogar no seu ritmo",
          value:
            t.enabled && g.enabled
              ? "TERMO diário · Um desafio por dia, com tabuleiro privado."
              : "TERMO diário · Aguardando ativação da equipe.",
        },
        {
          name: "Eventos em grupo",
          value: `Bingo: ${b ? (b.phase === "LOBBY" ? "inscrições abertas" : "partida aberta") : legacy ? "partida em andamento" : "aguardando novo evento"}\nCaixa Misteriosa: ${box && m.enabled ? "caixas disponíveis" : "aguardando evento"}\nQuiz em equipes: participe quando a equipe abrir inscrições.`,
        },
      )
      .setFooter(style.footer ? { text: style.footer } : null),
    [
      row(
        button(
          "play:termo",
          "TERMO diário",
          D.ButtonStyle.Primary,
          preview || !g.enabled || !t.enabled,
        ),
        button(
          "play:bingo",
          "Bingo da comunidade",
          D.ButtonStyle.Secondary,
          preview,
        ),
        button(
          "play:mystery",
          "Caixa Misteriosa",
          D.ButtonStyle.Secondary,
          preview || !g.enabled || !m.enabled,
        ),
        button(
          "play:quiz",
          "Quiz em equipes",
          D.ButtonStyle.Secondary,
          preview,
        ),
      ),
      row(
        button(
          "play:ranking",
          "Rankings do TERMO",
          D.ButtonStyle.Secondary,
          preview || !t.enabled || !g.enabled,
        ),
        button(
          "play:help",
          "Como participar",
          D.ButtonStyle.Secondary,
          preview,
        ),
      ),
    ],
  );
}
export async function adminView(guild: any, appearance = false) {
  const c = await config(guild.id);
  if (appearance)
    return {
      ...(await publicView(guild, true)),
      content:
        "**Prévia · Painel de jogos**\nAs alterações salvas aparecem abaixo. Publicar ou atualizar o painel é uma ação separada.",
      components: [
        row(
          button("games-admin:edit", "Editar mensagem"),
          button(
            "games-admin:publish",
            "Publicar / atualizar",
            D.ButtonStyle.Primary,
          ),
          button("games-admin:home", "Voltar"),
        ),
      ],
    };
  const select = new D.ChannelSelectMenuBuilder()
    .setCustomId("games-select:channel")
    .setPlaceholder("Canal do painel de jogos")
    .addChannelTypes(D.ChannelType.GuildText);
  if (c.channelId) select.setDefaultChannels(c.channelId);
  return {
    attachments: [],
    ...payload(
      adminEmbed(guild, "staff")
        .setTitle("Participação nos jogos")
        .setDescription(
          "Um painel para descobrir os jogos, continuar uma partida e encontrar os eventos abertos.",
        )
        .addFields(
          {
            name: "Painel público",
            value: `Canal: ${c.channelId ? "<#" + c.channelId + ">" : "Não configurado"}\n${c.messageId ? "Já publicado" : "Ainda não publicado"}`,
          },
          {
            name: "Caixa Misteriosa",
            value: c.mysteryIndividualAnnouncements
              ? "Além do resumo do evento, cada abertura recebe anúncio no canal."
              : "Resultados reunidos no painel do evento. O membro recebe seu resultado em particular.",
          },
        ),
      [
        row(select),
        row(
          button("games-admin:appearance", "Mensagem e prévia"),
          button(
            "games-admin:publish",
            "Publicar / atualizar",
            D.ButtonStyle.Primary,
          ),
          button(
            "games-admin:announcements",
            c.mysteryIndividualAnnouncements
              ? "Desativar anúncios por caixa"
              : "Ativar anúncios por caixa",
          ),
        ),
        row(
          button("bg-admin:home", "Bingo comunitário"),
          button("games-admin:war", "Quiz em equipes"),
          button("adm-nav:staff", "Voltar a Jogos e eventos"),
        ),
      ],
    ),
  };
}
export async function publish(guild: any) {
  const c = await config(guild.id),
    ch = await textChannel(guild, c.channelId),
    view = await publicView(guild),
    existing = c.messageId
      ? await ch.messages.fetch(c.messageId).catch(() => null)
      : null;
  const message = existing ? await existing.edit(view) : await ch.send(view);
  await prisma.gamesHubConfig.update({
    where: { guildId: guild.id },
    data: {
      messageId: message.id,
      publishedHash: require("node:crypto")
        .createHash("sha256")
        .update(JSON.stringify(view))
        .digest("hex"),
      publishedStyle: JSON.stringify({
        title: c.title,
        description: c.description,
        color: c.color,
        footer: c.footer,
      }),
    },
  });
  return message;
}
export async function playView(guild: any, userId: string, action: string) {
  if (action === "termo")
    return require("../termo/ui").termoPlayerView(guild, userId);
  if (action === "ranking")
    return require("../termo/ui").termoRankingView(guild);
  if (action === "bingo") {
    const state = await prisma.bingoExperienceState.findFirst({
      where: {
        guildId: guild.id,
        phase: { in: ["LOBBY", "RUNNING", "PAUSED", "REVIEW"] },
      },
      orderBy: { updatedAt: "desc" },
    });
    if (!state) {
      const cards =
        await require("../../bingo/service").getAllActiveCardsForPlayer(
          guild.id,
          userId,
        );
      if (cards.length)
        return require("../../bingo/cardAccess").view(guild, userId);
      return payload(
        embed(
          "Bingo da comunidade",
          "Não há inscrições comunitárias abertas agora. A equipe pode preparar o próximo evento.",
        ),
      );
    }
    const cards = await prisma.bingoCard.count({
      where: { guildId: guild.id, matchId: state.matchId, playerId: userId },
    });
    return cards
      ? require("../../bingo/communityViews").cardsView(
          guild,
          state.matchId,
          userId,
        )
      : require("../../bingo/communityViews").publicView(guild, state.matchId);
  }
  if (action === "mystery") {
    const c = await gamesConfig(guild.id);
    if (!c.enabled) throw Error("Os jogos de chat estão desativados.");
    const event = await prisma.mysteryEvent.findFirst({
      where: { guildId: guild.id, status: "ACTIVE" },
    });
    if (!event)
      return payload(
        embed(
          "Caixa Misteriosa",
          "Aguarde a equipe abrir o próximo evento. Cada participante poderá abrir uma caixa.",
        ),
      );
    const full = await require("../mystery-box/manager").getMysteryEvent(
        event.id,
      ),
      settings = await mysteryConfig(guild.id);
    if (!settings.enabled) throw Error("A Caixa Misteriosa está desativada.");
    return require("../mystery-box/ui").mysteryView(full, settings);
  }
  if (action === "quiz") {
    const repo = require("../../../app/war/repository"),
      game = await repo.activeGame(guild.id);
    if (!game)
      return payload(
        embed(
          "Quiz em equipes",
          "A equipe ainda não abriu inscrições. Quando abrir, escolha um dos times no painel do evento.",
        ),
      );
    const view = await require("../../../app/war/views").gameView(guild, game);
    view.components = view.components
      .map((r: any) => {
        const json = r.toJSON();
        json.components = json.components.filter(
          (c: any) => !c.custom_id?.startsWith("war:start:"),
        );
        return json;
      })
      .filter((r: any) => r.components.length);
    return view;
  }
  return payload(
    embed(
      "Como participar",
      "**TERMO:** jogue e continue quando quiser durante o dia.\n**Bingo:** entre antes da rodada e acompanhe sua cartela pelo servidor.\n**Caixa Misteriosa:** abra uma caixa durante o evento.\n**Quiz em equipes:** entre em um time quando as inscrições forem abertas.\n\nTodos os resultados e preferências pertencem a este servidor.",
    ),
  );
}
export async function player(i: any) {
  return guard(i, async () => {
    if (!i.guild) return;
    await member(i.guild, i.user.id);
    const action = i.customId.split(":")[1];
    if (i.message?.flags?.has?.(D.MessageFlags.Ephemeral)) {
      await deferPanel(i);
      return refreshPanel(i, await playView(i.guild, i.user.id, action));
    }
    await i.deferReply({ flags: D.MessageFlags.Ephemeral });
    return i.editReply(await playView(i.guild, i.user.id, action));
  });
}
export async function admin(i: any) {
  return guard(i, async () => {
    await staff(i);
    const action = i.customId.split(":")[1],
      c = await config(i.guild.id);
    if (action === "edit")
      return i.showModal(
        form("games-form:appearance", "Painel de jogos", [
          { id: "title", label: "Título", value: c.title, max: 100 },
          {
            id: "description",
            label: "Texto",
            value: c.description,
            long: true,
            max: 1000,
          },
          { id: "color", label: "Cor hexadecimal", value: c.color, max: 7 },
          {
            id: "footer",
            label: "Rodapé",
            value: c.footer,
            max: 150,
            required: false,
          },
        ]),
      );
    if (action === "war") {
      await require("../../../app/war/interactions").authorized(i);
      await deferPanel(i);
      return refreshPanel(
        i,
        await require("../../../app/war/admin").adminView(i.guild),
      );
    }
    await deferPanel(i);
    if (action === "publish") await publish(i.guild);
    if (action === "announcements")
      await prisma.gamesHubConfig.update({
        where: { guildId: i.guild.id },
        data: {
          mysteryIndividualAnnouncements: !c.mysteryIndividualAnnouncements,
        },
      });
    return refreshPanel(i, await adminView(i.guild, action === "appearance"));
  });
}
export async function select(i: any) {
  return guard(i, async () => {
    await staff(i);
    if (i.customId !== "games-select:channel") return;
    await textChannel(i.guild, i.values[0]);
    await config(i.guild.id);
    await prisma.gamesHubConfig.update({
      where: { guildId: i.guild.id },
      data: {
        channelId: i.values[0],
        messageId: null,
        publishedHash: null,
        publishedStyle: null,
      },
    });
    await deferPanel(i);
    return refreshPanel(i, await adminView(i.guild));
  });
}
export async function modal(i: any) {
  return guard(i, async () => {
    await staff(i);
    if (i.customId !== "games-form:appearance") return;
    const get = (key: string) => i.fields.getTextInputValue(key).trim(),
      color = get("color").replace("#", "");
    if (!get("title") || !get("description") || !/^[0-9a-f]{6}$/i.test(color))
      throw Error(
        "Preencha título e texto e use uma cor hexadecimal de seis caracteres.",
      );
    await config(i.guild.id);
    await prisma.gamesHubConfig.update({
      where: { guildId: i.guild.id },
      data: {
        title: get("title"),
        description: get("description"),
        color,
        footer: get("footer"),
      },
    });
    await deferPanel(i);
    return refreshPanel(i, await adminView(i.guild, true));
  });
}

let refreshing = false;
export async function refreshPublished(client: any) {
  if (refreshing) return;
  refreshing = true;
  try {
    const configs = await prisma.gamesHubConfig.findMany({
      where: {
        messageId: { not: null },
        channelId: { not: null },
        publishedStyle: { not: null },
      },
    });
    for (const c of configs) {
      const guild = client.guilds.cache.get(c.guildId);
      if (!guild) continue;
      try {
        const style = JSON.parse(c.publishedStyle!),
          view = await publicView(guild, false, {
            title: style.title,
            description: style.description,
            color: style.color,
            footer: style.footer,
          }),
          hash = require("node:crypto")
            .createHash("sha256")
            .update(JSON.stringify(view))
            .digest("hex");
        if (hash === c.publishedHash) continue;
        const ch = await textChannel(guild, c.channelId),
          message = await ch.messages.fetch(c.messageId).catch(() => null);
        if (!message) continue;
        await message.edit(view);
        await prisma.gamesHubConfig.update({
          where: { guildId: c.guildId },
          data: { publishedHash: hash },
        });
      } catch (e: any) {
        console.error("[games-hub:" + c.guildId + "]", e.message);
      }
    }
  } finally {
    refreshing = false;
  }
}
