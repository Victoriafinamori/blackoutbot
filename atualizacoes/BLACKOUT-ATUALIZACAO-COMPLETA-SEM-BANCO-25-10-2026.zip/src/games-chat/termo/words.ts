import { prisma } from "../../database/prisma";
import { ANSWERS, EXTRA_GUESSES } from "./lexicon";
export function normalizeWord(value: string) {
  return value
    .trim()
    .toLocaleLowerCase("pt-BR")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}
export function validShape(value: string, length: number) {
  return new RegExp(`^[a-z]{${length}}$`).test(normalizeWord(value));
}
let seeding: Promise<void> | null = null;
export async function ensureDefaultWords() {
  if (seeding) return seeding;
  seeding = (async () => {
    const existing = await prisma.termoWord.findMany({
        where: { guildId: null },
        select: { normalized: true },
      }),
      known = new Set(existing.map((w) => w.normalized)),
      items = new Map<string, { word: string; canAnswer: boolean }>();
    for (const word of ANSWERS)
      if (validShape(word, 5))
        items.set(normalizeWord(word), { word, canAnswer: true });
    for (const word of EXTRA_GUESSES)
      if (validShape(word, 5) && !items.has(normalizeWord(word)))
        items.set(normalizeWord(word), { word, canAnswer: false });
    const data = [...items]
      .filter(([normalized]) => !known.has(normalized))
      .map(([normalized, item]) => ({
        word: item.word,
        normalized,
        length: 5,
        category: "PADRAO",
        difficulty: "NORMAL",
        canGuess: true,
        canAnswer: item.canAnswer,
      }));
    if (data.length) await prisma.termoWord.createMany({ data });
  })();
  try {
    await seeding;
  } finally {
    seeding = null;
  }
}
export async function isAllowedGuess(
  guildId: string,
  normalized: string,
  length: number,
) {
  return Boolean(
    await prisma.termoWord.findFirst({
      where: {
        OR: [{ guildId: null }, { guildId }],
        normalized,
        length,
        active: true,
        canGuess: true,
      },
    }),
  );
}
