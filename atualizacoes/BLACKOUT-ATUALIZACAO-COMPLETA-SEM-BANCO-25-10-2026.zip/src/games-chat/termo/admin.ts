import { termoConfig } from "../core/config";
import { D, embed, payload, row, button } from "../experience/common";
export async function appearance(guild: any) {
  const c = await termoConfig(guild.id),
    e = embed(c.title, c.description).setColor(
      Number.isNaN(parseInt(c.color, 16)) ? 0xd71935 : parseInt(c.color, 16),
    );
  if (c.image) e.setImage(c.image);
  if (c.thumbnail) e.setThumbnail(c.thumbnail);
  if (c.footer) e.setFooter({ text: c.footer });
  return {
    ...payload(e, [
      row(
        button("adm-games-action:termo-appearance-edit", "Editar mensagem"),
        button(
          "adm-games-action:termo-publish",
          "Publicar / atualizar",
          D.ButtonStyle.Primary,
          !c.enabled || !c.channelId,
        ),
        button("adm-games-action:termo-home", "Voltar"),
      ),
    ]),
    content:
      "**Prévia · Mensagem do TERMO**\nTítulo, texto, imagem e rodapé salvos. Esta prévia não abre rodada nem envia mensagem.",
  };
}
