import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
} from "discord.js";
import { clean } from "../experience/common";
export function mysteryView(event: any, config: any, offset = 0) {
  const opened = event.boxes.filter((box: any) => box.status === "OPENED"),
    active = event.status === "ACTIVE",
    rewardByUser = new Map<string, string>();
  for (const opening of event.openings) {
    try {
      rewardByUser.set(
        opening.userId,
        JSON.parse(opening.rewardSnapshot).name || "Recompensa",
      );
    } catch {
      rewardByUser.set(opening.userId, "Recompensa");
    }
  }
  const results =
    opened
      .slice()
      .sort((a: any, b: any) => a.number - b.number)
      .slice(0, 5)
      .map(
        (box: any) =>
          `Caixa ${box.number} · <@${box.openedById}> · ${clean(rewardByUser.get(box.openedById) || "Recompensa", 60)}`,
      )
      .join("\n") || "Nenhuma caixa foi aberta.";
  const e = new EmbedBuilder()
    .setColor(
      Number.isNaN(parseInt(config.color, 16))
        ? 0xd71935
        : parseInt(config.color, 16),
    )
    .setTitle(config.title)
    .setDescription(config.description)
    .addFields(
      {
        name: "Como participar",
        value:
          "Escolha uma caixa disponível. Cada pessoa pode abrir uma única caixa neste evento.",
      },
      {
        name: "Tempo restante",
        value: active
          ? `<t:${Math.floor(new Date(event.endsAt).getTime() / 1000)}:R>`
          : "Evento encerrado",
        inline: true,
      },
      {
        name: "Disponíveis",
        value: String(event.boxes.length - opened.length),
        inline: true,
      },
      {
        name: "Aberturas",
        value: `${opened.length}/${event.boxes.length}`,
        inline: true,
      },
      {
        name: "Resultados do evento",
        value:
          results +
          (opened.length > 5 ? "\nVeja a lista completa em Resultados." : ""),
      },
    );
  if (config.image) e.setImage(config.image);
  if (config.thumbnail) e.setThumbnail(config.thumbnail);
  if (config.footer) e.setFooter({ text: config.footer });
  const start = Math.max(
      0,
      Math.min(Number(offset) || 0, Math.max(0, event.boxes.length - 1)),
    ),
    boxes = event.boxes.slice(start, start + 20),
    rows: ActionRowBuilder<ButtonBuilder>[] = [];
  for (let n = 0; n < boxes.length; n += 5)
    rows.push(
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        ...boxes.slice(n, n + 5).map((box: any) =>
          new ButtonBuilder()
            .setCustomId(`mystery-open:${event.id}:${box.number}`)
            .setLabel(
              `${clean(config.buttonLabel || "Caixa", 50)} ${String(box.number).padStart(2, "0")}${box.status === "OPENED" ? " · Aberta" : ""}`,
            )
            .setStyle(
              box.status === "OPENED"
                ? ButtonStyle.Secondary
                : ButtonStyle.Primary,
            )
            .setDisabled(!active || box.status === "OPENED"),
        ),
      ),
    );
  const controls = [
    new ButtonBuilder()
      .setCustomId(`mystery-panel:mine:${event.id}`)
      .setLabel("Meu resultado")
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(`mystery-panel:results:${event.id}:0`)
      .setLabel("Resultados")
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(`mystery-panel:help:${event.id}`)
      .setLabel("Como jogar")
      .setStyle(ButtonStyle.Secondary),
  ];
  if (start > 0)
    controls.push(
      new ButtonBuilder()
        .setCustomId(`mystery-panel:more:${event.id}:0`)
        .setLabel("Caixas anteriores")
        .setStyle(ButtonStyle.Secondary),
    );
  if (start + 20 < event.boxes.length)
    controls.push(
      new ButtonBuilder()
        .setCustomId(`mystery-panel:more:${event.id}:${start + 20}`)
        .setLabel("Mais caixas")
        .setStyle(ButtonStyle.Secondary),
    );
  rows.push(new ActionRowBuilder<ButtonBuilder>().addComponents(controls));
  return {
    embeds: [e],
    components: rows,
    allowedMentions: { parse: [] as any[] },
  };
}
