import {
  D,
  prisma,
  embed,
  payload,
  row,
  button,
  guard,
  clean,
  member,
} from "../experience/common";
import { getMysteryEvent } from "./manager";
import { mysteryConfig } from "../core/config";
export async function execute(i: any) {
  return guard(i, async () => {
    if (!i.guild) return;
    await member(i.guild, i.user.id);
    const [, action, id, arg] = i.customId.split(":"),
      event = await getMysteryEvent(id);
    if (!event || event.guildId !== i.guild.id)
      throw Error("Este evento não pertence a este servidor.");
    const render = async () => {
      if (action === "more")
        return require("./ui").mysteryView(
          event,
          await mysteryConfig(i.guild.id),
          Math.max(0, Math.min(Number(arg) || 0, 20)),
        );
      if (action === "help")
        return payload(
          embed(
            "Como jogar Caixa Misteriosa",
            "Escolha uma caixa disponível durante o evento. Cada membro pode abrir uma única caixa; caixas já abertas ficam indisponíveis. Seu resultado fica salvo. A entrega externa só é concluída quando a integração ou a equipe a confirma.",
          ),
        );
      if (action === "mine") {
        const own = event.openings.find((o) => o.userId === i.user.id);
        if (!own)
          return payload(
            embed(
              "Você ainda não abriu uma caixa",
              "Escolha uma caixa disponível no painel do evento.",
            ),
          );
        const snapshot = JSON.parse(own.rewardSnapshot),
          delivery = await prisma.mysteryDelivery.findUnique({
            where: { openingId: own.id },
          }),
          status: Record<string, string> = {
            DELIVERED: "Entregue",
            PENDING: "Em processamento",
            PENDING_EXTERNAL: "Aguardando integração ou confirmação externa",
            FAILED: "Falhou · A equipe pode consultar o registro",
            EXPIRED: "Recompensa temporária encerrada",
          };
        return payload(
          embed("Sua Caixa Misteriosa", clean(snapshot.name, 100)).addFields({
            name: "Entrega",
            value: status[delivery?.status || "PENDING"] || "Consulte a equipe",
          }),
        );
      }
      const page = Math.max(
          0,
          Math.min(
            Number(arg) || 0,
            Math.max(0, Math.ceil(event.openings.length / 5) - 1),
          ),
        ),
        results = event.openings.slice(page * 5, page * 5 + 5);
      return payload(
        embed(
          "Resultados da Caixa Misteriosa",
          results
            .map(
              (o) =>
                `<@${o.userId}> · ${clean(JSON.parse(o.rewardSnapshot).name, 100)}`,
            )
            .join("\n") || "Nenhuma caixa foi aberta.",
        ).setFooter({
          text: `Página ${page + 1} · ${event.openings.length} aberturas registradas`,
        }),
        [
          row(
            button(
              `mystery-panel:results:${id}:${page - 1}`,
              "Anterior",
              2,
              page === 0,
            ),
            button(
              `mystery-panel:results:${id}:${page + 1}`,
              "Próxima",
              2,
              (page + 1) * 5 >= event.openings.length,
            ),
            button(`mystery-panel:mine:${id}`, "Meu resultado"),
          ),
        ],
      );
    };
    if (i.message?.flags?.has?.(D.MessageFlags.Ephemeral)) {
      await i.deferUpdate();
      return i.editReply(await render());
    }
    await i.deferReply({ flags: D.MessageFlags.Ephemeral });
    return i.editReply(await render());
  });
}
