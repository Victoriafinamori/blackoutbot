import { Events } from "discord.js";
import { guildChanged, runLogEvent } from "../logging/events";
export default {name:Events.GuildUpdate,once:false,async execute(oldGuild: any, newGuild: any){await runLogEvent(()=>guildChanged(oldGuild,newGuild))}};
