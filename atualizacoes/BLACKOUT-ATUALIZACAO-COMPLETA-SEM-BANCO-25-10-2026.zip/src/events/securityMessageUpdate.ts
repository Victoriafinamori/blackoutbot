import { Events } from "discord.js";
import { check } from "../security/messages";
import { safe } from "../security/runtime";
export default { name: Events.MessageUpdate, async execute(_old: any, message: any) { await safe("edição de mensagem", () => check(message, true)); } };
