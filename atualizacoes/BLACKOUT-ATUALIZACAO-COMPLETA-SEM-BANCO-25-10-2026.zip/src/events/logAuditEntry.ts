import { Events } from "discord.js";
import { auditEntry, runLogEvent } from "../logging/events";
export default {name:Events.GuildAuditLogEntryCreate,once:false,async execute(entry: any, guild: any){await runLogEvent(()=>auditEntry(entry,guild))}};
