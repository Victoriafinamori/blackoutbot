import { Events, GuildMember } from "discord.js";
import { logAdminAction } from "../utils/adminLog";
import { AdminLogAction } from "../structures/enums";
import { prisma } from "../database/prisma";
import { getOrCreateGuildConfig } from "../database/guildConfig";

// Contas criadas há menos de 7 dias são destacadas no log de segurança,
// pois costumam ser um sinal de alerta (possível conta alt/suspeita).
const NEW_ACCOUNT_THRESHOLD_MS = 7 * 24 * 60 * 60 * 1000;

export default {
  name: Events.GuildMemberAdd,
  once: false,
  async execute(member: GuildMember) {
    try {
            if (await require("../security/entry").joined(member)) return;
      const config = await getOrCreateGuildConfig(member.guild.id);
      if (config.autoRoleEnabled && config.autoRoleIds) {
        const roleIds = config.autoRoleIds.split(",").map((id) => id.trim()).filter(Boolean);
        const assignable = roleIds
          .map((id) => member.guild.roles.cache.get(id))
          .filter((role): role is NonNullable<typeof role> => Boolean(role && role.id !== member.guild.id && !role.managed && role.editable));
        if (assignable.length) {
          try {
            await member.roles.add(assignable, "Auto-Cargo configurado no /adm");
          } catch (error) {
            console.error(`[guildMemberAdd] Falha ao aplicar Auto-Cargo em ${member.guild.id}/${member.id}:`, error);
          }
        }
      }

      await prisma.memberPresenceStat.upsert({ where: { guildId_userId: { guildId: member.guild.id, userId: member.id } }, create: { guildId: member.guild.id, userId: member.id, joins: 1, lastJoinedAt: new Date() }, update: { joins: { increment: 1 }, lastJoinedAt: new Date() } });
      const accountAgeMs = Date.now() - member.user.createdTimestamp;
      const isNewAccount = accountAgeMs < NEW_ACCOUNT_THRESHOLD_MS;

      const details =
        `Conta criada <t:${Math.floor(member.user.createdTimestamp / 1000)}:R>` +
        (isNewAccount ? " — ⚠️ conta criada há menos de 7 dias" : "") +
        `. Membros no servidor: ${member.guild.memberCount}.`;

      await logAdminAction({
        guild: member.guild,
        actorId: member.id,
        action: AdminLogAction.MEMBER_JOINED,
        details,
        context: {userId:member.id,bot:member.user?.bot,roleIds:member.roles.cache.map(role=>role.id)},
      });
    } catch (error) {
      console.error("[guildMemberAdd] Erro ao registrar log de segurança:", error);
    }
  },
};
