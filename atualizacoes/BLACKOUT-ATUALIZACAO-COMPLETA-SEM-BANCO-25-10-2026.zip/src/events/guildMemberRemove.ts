import { Events, GuildMember, PartialGuildMember } from "discord.js";
import { logAdminAction } from "../utils/adminLog";
import { AdminLogAction } from "../structures/enums";
import { prisma } from "../database/prisma";

export default {
  name: Events.GuildMemberRemove,
  once: false,
  async execute(member: GuildMember | PartialGuildMember) {
    try {
      await prisma.memberPresenceStat.upsert({ where: { guildId_userId: { guildId: member.guild.id, userId: member.id } }, create: { guildId: member.guild.id, userId: member.id, leaves: 1, lastLeftAt: new Date() }, update: { leaves: { increment: 1 }, lastLeftAt: new Date() } });
      const roles = member.roles.cache
        .filter((role) => role.id !== member.guild.id)
        .map((role) => `<@&${role.id}>`)
        .slice(0, 10)
        .join(", ");

      const details = `Membros no servidor: ${member.guild.memberCount}. Cargos que possuía: ${roles || "nenhum"}.`;

      await logAdminAction({
        guild: member.guild,
        actorId: member.id,
        action: AdminLogAction.MEMBER_LEFT,
        details,
        context: {userId:member.id,bot:member.user?.bot,roleIds:member.roles.cache.map(role=>role.id)},
      });
    } catch (error) {
      console.error("[guildMemberRemove] Erro ao registrar log de segurança:", error);
    }
  },
};
