import { Events } from "discord.js";
import { reactionsCleared } from "../message-maker/roles";
export default { name: Events.MessageReactionRemoveEmoji, async execute(reaction: any) { try { await reactionsCleared(reaction.message); } catch (e: any) { console.error("[maker-reaction-cleared]", e?.code || e?.name); } } };
