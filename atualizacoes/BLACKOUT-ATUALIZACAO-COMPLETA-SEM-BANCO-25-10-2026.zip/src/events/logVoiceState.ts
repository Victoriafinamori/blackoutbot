import { Events } from "discord.js";
import { voiceLog, runLogEvent } from "../logging/events";
export default {name:Events.VoiceStateUpdate,once:false,async execute(oldState: any, newState: any){await runLogEvent(()=>voiceLog(oldState,newState))}};
