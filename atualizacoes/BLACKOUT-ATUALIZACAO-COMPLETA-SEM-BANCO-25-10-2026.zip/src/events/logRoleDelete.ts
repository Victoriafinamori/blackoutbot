import { Events } from "discord.js";
import { roleChanged, runLogEvent } from "../logging/events";
export default {name:Events.GuildRoleDelete,once:false,async execute(role: any){await runLogEvent(()=>roleChanged("delete",role))}};
