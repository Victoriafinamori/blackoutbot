import { Events } from "discord.js";
import { reactionsCleared } from "../message-maker/roles";
export default { name: Events.MessageReactionRemoveAll, async execute(message: any) { try { await reactionsCleared(message); } catch (e: any) { console.error("[maker-reactions-cleared]", e?.code || e?.name); } } };
