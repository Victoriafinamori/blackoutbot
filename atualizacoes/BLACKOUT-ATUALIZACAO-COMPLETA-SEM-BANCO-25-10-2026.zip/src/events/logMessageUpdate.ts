import { Events } from "discord.js";
import { messageEdited, runLogEvent } from "../logging/events";
export default {name:Events.MessageUpdate,once:false,async execute(oldMessage: any, newMessage: any){await runLogEvent(()=>messageEdited(oldMessage,newMessage))}};
