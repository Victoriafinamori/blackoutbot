import { Events } from "discord.js";
import { roleChanged, runLogEvent } from "../logging/events";
export default {name:Events.GuildRoleUpdate,once:false,async execute(oldRole: any, newRole: any){await runLogEvent(()=>roleChanged("update",oldRole,newRole))}};
