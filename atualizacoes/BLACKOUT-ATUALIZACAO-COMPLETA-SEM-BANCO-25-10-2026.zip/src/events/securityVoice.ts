import { Events } from "discord.js";
import { voice } from "../security/messages";
import { safe } from "../security/runtime";
export default { name: Events.VoiceStateUpdate, async execute(old: any, next: any) { await safe("voz", () => voice(old, next)); } };
