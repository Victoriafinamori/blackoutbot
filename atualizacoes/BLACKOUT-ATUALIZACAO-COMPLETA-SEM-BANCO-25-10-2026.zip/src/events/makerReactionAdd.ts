import { Events } from "discord.js";
import { onReaction } from "../message-maker/roles";
export default { name: Events.MessageReactionAdd, async execute(reaction: any, user: any) { try { await onReaction(reaction, user); } catch (e: any) { console.error("[maker-reaction-add]", e?.code || e?.name); } } };
