import { Events } from "discord.js";
import { messageDeleted } from "../message-maker/roles";
export default { name: Events.MessageDelete, async execute(message: any) { try { await messageDeleted(message); } catch (e: any) { console.error("[maker-message-delete]", e?.code || e?.name); } } };
