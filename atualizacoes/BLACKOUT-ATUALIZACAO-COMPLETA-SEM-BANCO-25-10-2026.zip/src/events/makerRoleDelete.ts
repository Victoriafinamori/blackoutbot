import { Events } from "discord.js";
import { prisma } from "../message-maker/common";
export default { name: Events.GuildRoleDelete, async execute(role: any) {
  try {
    const list = await prisma.reactionRoleBinding.findMany({ where: { guildId: role.guild.id, roleId: role.id, active: true } });
    for (const b of list) await prisma.reactionRolePanel.update({ where: { id: b.panelId }, data: { status: "PAUSED", lastError: "Um cargo oferecido foi apagado. Revise a associação antes de retomar o painel." } });
  } catch (e: any) { console.error("[maker-role-delete]", e?.code || e?.name); }
} };
