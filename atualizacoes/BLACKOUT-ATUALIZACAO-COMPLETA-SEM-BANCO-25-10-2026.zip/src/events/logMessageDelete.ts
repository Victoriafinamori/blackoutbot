import { Events } from "discord.js";
import { messageDeleted, runLogEvent } from "../logging/events";
export default {name:Events.MessageDelete,once:false,async execute(message: any){await runLogEvent(()=>messageDeleted(message))}};
