import { Events } from "discord.js";
import { messageDeleted } from "../message-maker/roles";
export default { name: Events.MessageBulkDelete, async execute(messages: any) { for (const m of messages.values()) try { await messageDeleted(m); } catch (e: any) { console.error("[maker-message-delete]", e?.code || e?.name); } } };
