import { Events } from "discord.js";
import { onReaction } from "../message-maker/roles";
export default { name: Events.MessageReactionRemove, async execute(reaction: any, user: any) { try { await onReaction(reaction, user, true); } catch (e: any) { console.error("[maker-reaction-remove]", e?.code || e?.name); } } };
