import { Events } from "discord.js";
import { memberChanged, runLogEvent } from "../logging/events";
export default {name:Events.GuildMemberUpdate,once:false,async execute(oldMember: any, newMember: any){await runLogEvent(()=>memberChanged(oldMember,newMember))}};
