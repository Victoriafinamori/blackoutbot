import { Events, Message, PermissionFlagsBits } from "discord.js";
import { checkMessage } from "../utils/filters";
import { checkWordWatch } from "../utils/wordWatch";
import { checkStageChatRestriction } from "../utils/stageChat";
import { getOrCreateGuildConfig } from "../database/guildConfig";
import { warnMember, muteMember, ModerationError } from "../utils/moderation";
import { logAdminAction } from "../utils/adminLog";
import { AdminLogAction, AutoModAction } from "../structures/enums";
import { isBotAdmin } from "../utils/permissions";
import { getMovChatChannelIds, incrementChatCount } from "../utils/movStats";
import { getActiveFamiliesMonitoringChannel, incrementFamilyChatToday } from "../utils/familyStats";
import { prisma } from "../database/prisma";
import { ids, ticketConfig } from "../utils/tickets";
import { regConfig } from "../utils/registration";
import { claimRegistrationChannel } from "../utils/registrationClaim";
import { countMessage } from "../memberRise/service";

export default {
  name: Events.MessageCreate,
  once: false,
  async execute(message: Message) {
    try {
            if (await require("../security/messages").check(message)) return;
      if (!message.guild || message.author.bot || !message.member) return;
      await countMessage(message).catch(error => console.error("[member-rise] mensagem:", error));

      if (message.channel.isTextBased() && !message.channel.isDMBased() && "topic" in message.channel && message.channel.topic?.startsWith("registration:") && !message.channel.topic.split(":")[2]) {
        const rc = await regConfig(message.guild.id);
        const canRegister = ids(rc.registrarRoleIds).some(id => message.member!.roles.cache.has(id)) || message.member.permissions.has(PermissionFlagsBits.Administrator);
        if (canRegister) await claimRegistrationChannel(message.channel as any, message.author.id).catch(() => null);
      }

      const activeTicket = await prisma.ticket.findUnique({ where: { channelId: message.channelId } });
      if (activeTicket?.status === "OPEN") {
        const tc = await ticketConfig(message.guild.id);
        if (tc.lockToClaimer && activeTicket.claimedById && message.author.id !== activeTicket.openerId && message.author.id !== activeTicket.claimedById) {
          const immune = ids(tc.immuneRoleIds).some(roleId => message.member!.roles.cache.has(roleId));
          if (!immune) { await message.delete().catch(() => null); return; }
        }
      }

      // MOV CHAT: conta a mensagem se o canal estiver entre os configurados
      // pela staff. Roda para todo mundo (inclusive staff/admin), já que a
      // ideia é medir atividade real, não só de quem é filtrado.
      const movConfig = await getOrCreateGuildConfig(message.guild.id);
      const movChatChannels = getMovChatChannelIds(movConfig);
      if (movChatChannels.includes(message.channel.id)) {
        await incrementChatCount(message.guild.id, message.author.id).catch((err) =>
          console.error("[mov-chat] Erro ao contar mensagem:", err)
        );
      }

      // VIP Família/Irmandade — Mov Chat: conta a mensagem para cada Família
      // ativa que monitora este canal, desde que o autor possua o cargo de
      // membro daquela Família. Totalmente independente do MOV CHAT global.
      const monitoringFamilies = await getActiveFamiliesMonitoringChannel(message.guild.id, message.channel.id);
      if (monitoringFamilies.length) {
        for (const family of monitoringFamilies) {
          if (family.memberRoleId && message.member.roles.cache.has(family.memberRoleId)) {
            await incrementFamilyChatToday(message.guild.id, family.id, message.author.id, movConfig.timezone).catch(
              (err) => console.error("[family-chat] Erro ao contar mensagem:", err)
            );
          }
        }
      }

      // Monitoramento de Palavras: observação silenciosa (não apaga, não pune),
      // roda antes de qualquer possível exclusão pelo filtro abaixo, e não
      // é afetado pela isenção de staff/admin — a ideia é registrar o que o
      // membro em reintegração fala, ponto.
      await checkWordWatch(message).catch((err) => console.error("[word-watch] Erro:", err));

      // Staff (Gerenciar Mensagens) e Administradores do BOT não são filtrados.
      if (message.member.permissions.has(PermissionFlagsBits.ManageMessages)) return;
      if (await isBotAdmin(message.member)) return;

      // Restrição de chat da etapa de reintegração (Bloqueado / Limitado),
      // roda antes dos filtros de conteúdo: se a etapa travar a mensagem,
      // nem faz sentido avaliar palavra/link/flood/etc.
      const stageChat = await checkStageChatRestriction(message);
      if (stageChat.violated) {
        const botId = message.client.user?.id ?? message.author.id;
        await message.delete().catch(() => null);

        const channel = message.channel;
        const notice =
          channel.isTextBased() && "send" in channel
            ? await channel
                .send({ content: `🔒 <@${message.author.id}>, ${stageChat.reason}` })
                .catch(() => null)
            : null;
        if (notice) setTimeout(() => notice.delete().catch(() => null), 6000);

        await logAdminAction({
          guild: message.guild,
          actorId: botId,
          action: AdminLogAction.STAGE_CHAT_RESTRICTED,
          targetId: message.author.id,
          details: stageChat.reason,
        });
        return;
      }

      const result = await checkMessage(message);
      if (!result.violated) return;

      const config = movConfig;
      const botId = message.client.user?.id ?? message.author.id;

      await message.delete().catch(() => null);

      const channel = message.channel;
      const notice =
        channel.isTextBased() && "send" in channel
          ? await channel
              .send({
                content: `🧹 <@${message.author.id}>, sua mensagem foi removida.\n**Motivo:** ${result.reason}`,
              })
              .catch(() => null)
          : null;
      if (notice) setTimeout(() => notice.delete().catch(() => null), 6000);

      await logAdminAction({
        guild: message.guild,
        actorId: botId,
        action: AdminLogAction.AUTO_MOD_TRIGGERED,
        targetId: message.author.id,
        details: `[${result.category}] ${result.reason}`,
      });

      if (config.autoModAction === AutoModAction.WARN) {
        await warnMember(message.guild, botId, message.author.id, `Automático: ${result.reason}`).catch(
          () => null
        );
      } else if (config.autoModAction === AutoModAction.MUTE) {
        await muteMember(
          message.guild,
          botId,
          message.author.id,
          `Automático: ${result.reason}`,
          config.autoMuteDurationMinutes,
          true
        ).catch((err) => {
          if (!(err instanceof ModerationError)) console.error("[auto-mod] Erro ao mutar:", err);
        });
      }
      // "DELETE_ONLY" só apaga a mensagem, sem punição adicional.
    } catch (error) {
      console.error("[messageCreate] Erro no filtro de moderação:", error);
    }
  },
};
