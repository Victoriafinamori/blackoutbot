import { Events } from "discord.js";
import { messagesDeleted, runLogEvent } from "../logging/events";
export default {name:Events.MessageBulkDelete,once:false,async execute(messages: any, channel: any){await runLogEvent(()=>messagesDeleted(messages,channel))}};
