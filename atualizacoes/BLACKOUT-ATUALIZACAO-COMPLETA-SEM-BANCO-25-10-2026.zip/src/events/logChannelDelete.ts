import { Events } from "discord.js";
import { channelChanged, runLogEvent } from "../logging/events";
export default {name:Events.ChannelDelete,once:false,async execute(channel: any){await runLogEvent(()=>channelChanged("delete",channel))}};
