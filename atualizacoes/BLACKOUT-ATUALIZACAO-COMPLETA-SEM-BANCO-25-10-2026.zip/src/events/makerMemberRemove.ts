import { Events } from "discord.js";
import { prisma } from "../message-maker/common";
export default { name: Events.GuildMemberRemove, async execute(member: any) {
  try { await prisma.$transaction(async (tx: any) => {
    await tx.reactionRoleGrant.updateMany({ where: { guildId: member.guild.id, userId: member.id }, data: { active: false, status: "MEMBER_LEFT" } });
    await tx.reactionRoleOwnership.deleteMany({ where: { guildId: member.guild.id, userId: member.id } });
  }); } catch (e: any) { console.error("[maker-member-remove]", e?.code || e?.name); }
} };
