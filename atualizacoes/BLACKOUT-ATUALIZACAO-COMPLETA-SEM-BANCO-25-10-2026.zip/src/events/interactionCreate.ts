import { Client, Collection, Events, Interaction } from "discord.js";
import { Command, ButtonComponent, SelectMenuComponent, ModalComponent } from "../structures/types";

type BotClient = Client & {
  commands: Collection<string, Command>;
  buttons: Collection<string, ButtonComponent>;
  selects: Collection<string, SelectMenuComponent>;
  modals: Collection<string, ModalComponent>;
};

// Encontra handler exato ou por prefixo (ex: "adm-adm:reintegracao" -> "adm-adm:")
function findHandler<T extends { customId: string }>(
  collection: Collection<string, T>,
  customId: string
): T | undefined {
  const exact = collection.get(customId);
  if (exact) return exact;
  return [...collection.values()].find(
    (c) => c.customId !== customId && customId.startsWith(c.customId)
  );
}

export default {
  name: Events.InteractionCreate,
  once: false,
  async execute(interaction: Interaction, client: BotClient) {
    try {
      interaction = require("../utils/componentMessages").compatibleInteraction(interaction);
      const legacyId = (interaction as any).customId;
      if (typeof legacyId === "string" && legacyId.startsWith("embedv2")) {
        const parts = legacyId.split(":");
        const oldId = parts[0] === "embedv2-select" ? (interaction as any).values?.[0] : ["embedv2-edit-select", "embedv2-btn-select"].includes(parts[0]) ? parts[1] : parts[2];
        return require("../message-maker/interactions").legacyEntry(interaction, oldId);
      }

      if (interaction.isChatInputCommand()) {
        const command = client.commands.get(interaction.commandName);
        if (!command) return;
        await command.execute(interaction);
        return;
      }

      if (interaction.isButton()) {
        const handler = findHandler(client.buttons, interaction.customId);
        if (!handler) return;
        await handler.execute(interaction);
        return;
      }

      if (interaction.isAnySelectMenu()) {
        const handler = findHandler(client.selects, interaction.customId);
        if (!handler) return;
        await handler.execute(interaction);
        return;
      }

      if (interaction.isModalSubmit()) {
        const handler = findHandler(client.modals, interaction.customId);
        if (!handler) return;
        await handler.execute(interaction);
        return;
      }
    } catch (error) {
      console.error("[interactionCreate] Erro ao processar interação:", error);
      const errorMessage = {
        content: "❌ Ocorreu um erro ao processar essa ação.",
        ephemeral: true,
      };
      if (interaction.isRepliable()) {
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp(errorMessage).catch(() => null);
        } else {
          await interaction.reply(errorMessage).catch(() => null);
        }
      }
    }
  },
};
