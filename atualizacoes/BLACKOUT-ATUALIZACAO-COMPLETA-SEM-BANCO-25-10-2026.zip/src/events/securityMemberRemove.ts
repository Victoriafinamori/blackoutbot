import { Events } from "discord.js";
import { snapshot } from "../security/entry";
import { safe } from "../security/runtime";
export default { name: Events.GuildMemberRemove, async execute(member: any) { await safe("snapshot de saída", () => snapshot(member)); } };
