import { Events } from "discord.js";
import { channelChanged, runLogEvent } from "../logging/events";
export default {name:Events.ChannelUpdate,once:false,async execute(oldChannel: any, newChannel: any){await runLogEvent(()=>channelChanged("update",oldChannel,newChannel))}};
