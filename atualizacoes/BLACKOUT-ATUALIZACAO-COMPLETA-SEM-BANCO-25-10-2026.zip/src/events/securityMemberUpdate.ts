import { Events } from "discord.js";
import { snapshot } from "../security/entry";
import { safe } from "../security/runtime";
export default { name: Events.GuildMemberUpdate, async execute(_old: any, member: any) { await safe("snapshot de cargos", () => snapshot(member)); } };
