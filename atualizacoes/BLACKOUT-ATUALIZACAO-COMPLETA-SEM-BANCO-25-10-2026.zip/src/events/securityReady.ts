import { Events } from "discord.js";
import { start, safe } from "../security/runtime";
export default { name: Events.ClientReady, once: true, async execute(client: any) { await safe("retomada", () => start(client)); } };
