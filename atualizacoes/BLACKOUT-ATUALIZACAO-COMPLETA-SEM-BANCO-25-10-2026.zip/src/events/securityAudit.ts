import { Events } from "discord.js";
import { audit } from "../security/audit";
import { safe } from "../security/runtime";
export default { name: Events.GuildAuditLogEntryCreate, async execute(entry: any, guild: any) { await safe("auditoria", () => audit(entry, guild)); } };
