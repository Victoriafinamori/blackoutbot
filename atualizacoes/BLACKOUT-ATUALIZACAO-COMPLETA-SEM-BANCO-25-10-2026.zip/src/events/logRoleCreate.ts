import { Events } from "discord.js";
import { roleChanged, runLogEvent } from "../logging/events";
export default {name:Events.GuildRoleCreate,once:false,async execute(role: any){await runLogEvent(()=>roleChanged("create",role))}};
