import { Client, Events } from "discord.js";
import { sendCategoryLog } from "../utils/adminLog";
import { baseEmbed } from "../utils/embeds";
import { LogCategory } from "../structures/enums";
import { getOrCreateGuildConfig } from "../database/guildConfig";
import { ensureAdmEmojis } from "../utils/admEmojis";
import { checkAllGuildsMovReset } from "../utils/movStats";
import {
  getMovCallCategoryIds,
  startCallVoiceSession,
  registerCallStreak,
  checkAllGuildsMovCallReset,
  refreshCallRankingMessage,
} from "../utils/movCallStats";
import { runMysteryScheduler } from "../games-chat/mystery-box/manager";
import { runTermoScheduler } from "../games-chat/termo/publisher";
import { runVoteBanScheduler } from "../voteban/scheduler";
import { reconcileVoice } from "../memberRise/service";

const MOV_RESET_CHECK_INTERVAL_MS = 15 * 60 * 1000; // checa reset automático a cada 15 minutos
const MOVCALL_RANKING_REFRESH_INTERVAL_MS = 10 * 60 * 1000; // atualiza a mensagem do Top Call a cada 10 minutos

export default {
  name: Events.ClientReady,
  once: true,
  async execute(client: Client) {
    console.log(`✅ Bot online como ${client.user?.tag}`);
    console.log(`📡 Presente em ${client.guilds.cache.size} servidor(es)`);

    for (const guild of client.guilds.cache.values()) {
      await reconcileVoice(guild).catch(error => console.error("[member-rise] retomada:", error));
      try {
        await ensureAdmEmojis(guild);
        const embed = (await baseEmbed(guild))
          .setTitle("⚙️ Bot Iniciado")
          .setDescription(`${client.user?.tag} está online e pronto.`)
          .setTimestamp();
        await sendCategoryLog(guild, LogCategory.SYSTEM, embed);
      } catch (error) {
        console.error(`[ready] Erro ao enviar log de sistema em ${guild.id}:`, error);
      }

      // Mov.Call: quem já estava conectado a um canal de voz contado antes do
      // bot (re)iniciar não geraria evento de entrada — então começamos a
      // sessão manualmente pra não perder o tempo que passar conectado.
      try {
        const config = await getOrCreateGuildConfig(guild.id);
        if (config.movCallSystemEnabled) {
          const trackedCategories = getMovCallCategoryIds(config);
          if (trackedCategories.length) {
            for (const [, voiceState] of guild.voiceStates.cache) {
              const channel = voiceState.channel;
              if (!channel || voiceState.member?.user.bot) continue;
              if (trackedCategories.includes(channel.parentId ?? "")) {
                await startCallVoiceSession(guild.id, voiceState.id, channel.id, !!voiceState.mute);
                await registerCallStreak(guild.id, voiceState.id, config.timezone);
              }
            }
          }
          if (config.movCallRankingEnabled) {
            await refreshCallRankingMessage(guild);
          }
        }
      } catch (error) {
        console.error(`[ready] Erro ao recuperar sessões de voz (Mov.Call) em ${guild.id}:`, error);
      }
    }
    setInterval(() => { for (const guild of client.guilds.cache.values()) void reconcileVoice(guild).catch(error => console.error("[member-rise] tick:", error)); }, 60_000);

    // Reset automático do ranking MOV CHAT
    const runMovResetCheck = () => {
      checkAllGuildsMovReset((guildId) => client.guilds.cache.get(guildId)).catch((err) =>
        console.error("[mov-reset] Erro ao checar resets automáticos (MOV CHAT):", err)
      );
    };
    runMovResetCheck();
    setInterval(runMovResetCheck, MOV_RESET_CHECK_INTERVAL_MS);

    // Reset automático do Top Call (Mov.Call)
    const runMovCallResetCheck = () => {
      checkAllGuildsMovCallReset((guildId) => client.guilds.cache.get(guildId)).catch((err) =>
        console.error("[movcall-reset] Erro ao checar resets automáticos (Mov.Call):", err)
      );
    };
    runMovCallResetCheck();
    setInterval(runMovCallResetCheck, MOV_RESET_CHECK_INTERVAL_MS);

    // Atualização periódica da mensagem fixa do ranking do Top Call
    const runMovCallRankingRefresh = async () => {
      for (const guild of client.guilds.cache.values()) {
        try {
          const config = await getOrCreateGuildConfig(guild.id);
          if (config.movCallSystemEnabled && config.movCallRankingEnabled && config.movCallRankingChannelId) {
            await refreshCallRankingMessage(guild);
          }
        } catch (err) {
          console.error(`[movcall-ranking] Erro ao atualizar ranking em ${guild.id}:`, err);
        }
      }
    };
    setInterval(() => {
      runMovCallRankingRefresh().catch((err) => console.error("[movcall-ranking] Erro:", err));
    }, MOVCALL_RANKING_REFRESH_INTERVAL_MS);

    const runCommunityBingo=()=>require('../bingo/community').tick(client).catch((error:any)=>console.error('[community-bingo]',error.message));
    void runCommunityBingo();setInterval(runCommunityBingo,2000);
    const refreshGamesHub=()=>require('../games-chat/experience/hub').refreshPublished(client).catch((error:any)=>console.error('[games-hub]',error.message));
    void refreshGamesHub();setInterval(refreshGamesHub,60000);
    const runGamesChat = () => Promise.all([runMysteryScheduler(client), runTermoScheduler(client)]).catch(error => console.error("[games-chat] Erro no agendador:", error));
    void runGamesChat();
    setInterval(runGamesChat, 60 * 1000);

    const runVoteBan = () => runVoteBanScheduler(client).catch(error =>
      console.error("[voteban] Erro no agendador:", error)
    );
    void runVoteBan();
    setInterval(runVoteBan, 5 * 60 * 1000);
  },
};
