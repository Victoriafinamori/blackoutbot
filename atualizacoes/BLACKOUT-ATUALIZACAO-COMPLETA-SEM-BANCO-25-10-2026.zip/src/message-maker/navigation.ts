import { D, row, button, show, guard, deferPanel } from "./common";
import { header } from "./views";
import { admEmoji } from "../utils/admEmojis";
export async function automations(i: any) {
  return guard(i, async () => {
    await deferPanel(i);
    const icon = admEmoji(i.guild, "membros");
    return show(i, {
      flags: D.MessageFlags.IsComponentsV2,
      components: [
        header(
          i.guild,
          "Cargos e automações",
          "Defina quando e como os membros recebem cargos. Escolha uma função no menu abaixo.",
          "membros",
        ),
        row(
          new D.StringSelectMenuBuilder()
            .setCustomId("maker-select:automation")
            .setPlaceholder("Escolha como atribuir os cargos")
            .addOptions(
              ...[
                {
                  value: "arrival",
                  label: "Cargos ao entrar",
                  description: "Atribuição automática para novos membros",
                },
                {
                  value: "transfer",
                  label: "Transferência programada",
                  description: "Mudanças de cargos pelas regras do servidor",
                },
                {
                  value: "reactions",
                  label: "Cargos por reação",
                  description:
                    "O membro escolhe seus cargos reagindo à mensagem",
                },
              ].map((o) => ({
                ...o,
                ...(icon ? { emoji: { id: icon } } : {}),
              })),
            ),
        ),
        row(button("area:membros", "Voltar a Entrada e evolução")),
      ],
    });
  });
}
