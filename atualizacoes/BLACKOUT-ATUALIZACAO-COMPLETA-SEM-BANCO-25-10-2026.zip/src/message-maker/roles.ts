import { prisma, assert, exclusive, uid, D } from "./common";
import {
  Document,
  blank,
  copy,
  parse,
  render,
  hash,
  MakerError,
} from "./document";
import { channel, fetchMessage, publication } from "./service";
const dangerous = [
  D.PermissionFlagsBits.Administrator,
  D.PermissionFlagsBits.ManageGuild,
  D.PermissionFlagsBits.ManageRoles,
  D.PermissionFlagsBits.ManageChannels,
  D.PermissionFlagsBits.BanMembers,
  D.PermissionFlagsBits.KickMembers,
  D.PermissionFlagsBits.ModerateMembers,
  D.PermissionFlagsBits.ManageWebhooks,
  D.PermissionFlagsBits.ManageMessages,
  D.PermissionFlagsBits.MentionEveryone,
];
export async function panel(guildId: string, id: string) {
  const p = await prisma.reactionRolePanel.findFirst({
    where: { id, guildId },
  });
  assert(p, "Este painel de cargos não pertence a este servidor.");
  return p;
}
export async function create(
  guildId: string,
  actorId: string,
  document: Document = blank(),
  name = "Novo painel de cargos",
) {
  return prisma.reactionRolePanel.create({
    data: {
      id: uid(),
      guildId,
      createdById: actorId,
      name,
      documentJson: JSON.stringify(parse(document)),
    },
  });
}
export async function bindings(
  guildId: string,
  panelId: string,
  published = false,
) {
  return prisma.reactionRoleBinding.findMany({
    where: {
      guildId,
      panelId,
      active: true,
      ...(published ? { published: true } : {}),
    },
    orderBy: { createdAt: "asc" },
  });
}
export function emoji(value: string) {
  const custom = value
    .trim()
    .match(/^<(a?):([A-Za-z0-9_]{2,32}):([0-9]{17,22})>$/);
  if (custom)
    return {
      emojiKey: "c:" + custom[3],
      emojiApi: custom[3],
      emojiDisplay: value.trim(),
    };
  const text = value.trim().normalize("NFC");
  const parts = [
    ...new (Intl as any).Segmenter("pt-BR", {
      granularity: "grapheme",
    }).segment(text),
  ];
  assert(
    parts.length === 1 &&
      /\p{Extended_Pictographic}|\p{Regional_Indicator}|\p{Emoji_Presentation}/u.test(
        text,
      ) &&
      text.length <= 20,
    "Use uma única reação, como 🎮, ou um emoji personalizado no formato <:nome:id>.",
  );
  return {
    emojiKey: "u:" + text.replace(/\uFE0F/g, ""),
    emojiApi: text,
    emojiDisplay: text,
  };
}
export async function safeRole(guild: any, id: string) {
  const role = await guild.roles.fetch(id).catch(() => null);
  assert(
    role && role.id !== guild.id && !role.managed && role.editable,
    "O cargo não existe ou não pode ser atribuído pelo bot. Confira a hierarquia e Gerenciar Cargos.",
  );
  assert(
    !dangerous.some((p) => role.permissions?.has(p)),
    "Cargos com permissões de administração ou moderação não podem ser oferecidos por reação.",
  );
  return role;
}
export async function addBinding(
  guild: any,
  panelId: string,
  roleId: string,
  value: string,
  expectedRevision?: number,
) {
  return exclusive("reaction-panel:" + panelId, async () => {
    const p = await panel(guild.id, panelId),
      e = emoji(value),
      list = await bindings(guild.id, p.id);
    if (expectedRevision !== undefined)
      assert(
        p.revision === expectedRevision,
        "O painel mudou. Abra novamente a associação.",
      );
    await safeRole(guild, roleId);
    assert(list.length < 20, "Cada painel aceita até 20 reações diferentes.");
    assert(
      !list.some((b: any) => b.emojiKey === e.emojiKey),
      "Essa reação já está associada a um cargo neste painel.",
    );
    if (e.emojiKey.startsWith("c:")) {
      const available =
        guild.emojis?.cache?.get(e.emojiApi) ||
        guild.client.emojis?.cache?.get(e.emojiApi) ||
        guild.client.application?.emojis?.cache?.get(e.emojiApi);
      assert(
        available && available.available !== false,
        "O bot não tem acesso a esse emoji personalizado. Escolha um emoji disponível para ele.",
      );
    }
    const b = await prisma.reactionRoleBinding.create({
      data: { id: uid(), guildId: guild.id, panelId: p.id, roleId, ...e },
    });
    await prisma.reactionRolePanel.update({
      where: { id: p.id },
      data: { revision: { increment: 1 } },
    });
    return b;
  });
}
export function withLegend(
  doc: Document,
  list: any[],
  remove: boolean,
  preparing = false,
): Document {
  const d = copy(parse(doc));
  d.blocks.push({
    id: "role-legend",
    type: "text",
    text:
      (preparing
        ? "**Painel em preparação. Aguarde a ativação pela equipe.**\n\n"
        : "**Escolha seus cargos pelas reações:**\n") +
      list.map((b) => b.emojiDisplay + " → <@&" + b.roleId + ">").join("\n") +
      "\n\n" +
      (remove
        ? "Retirar a reação remove somente a concessão feita por este painel."
        : "O cargo permanece depois de retirar a reação."),
  });
  return d;
}
export async function publish(
  guild: any,
  id: string,
  expectedRevision: number,
) {
  return exclusive("reaction-panel:" + id, async () => {
    let p = await panel(guild.id, id);
    assert(
      p.revision === expectedRevision,
      "O painel mudou. Confira novamente antes de publicar.",
    );
    const list = await bindings(guild.id, p.id);
    assert(list.length > 0, "Associe pelo menos uma reação a um cargo.");
    for (const b of list) await safeRole(guild, b.roleId);
    const ch = await channel(guild, p.channelId, true),
      doc = withLegend(parse(p.documentJson), list, p.removeOnUnreact),
      payload = render(doc),
      preparation = render(
        withLegend(parse(p.documentJson), list, p.removeOnUnreact, true),
      );
    let pub = p.publicationId
        ? await publication(guild.id, p.publicationId)
        : null,
      message: any = null;
    if (pub) message = await fetchMessage(guild, pub);
    else {
      pub = await prisma.makerPublication.create({
        data: {
          id: uid(),
          guildId: guild.id,
          panelId: p.id,
          channelId: ch.id,
          name: p.name,
          snapshotJson: JSON.stringify(doc),
          createdById: p.createdById,
        },
      });
      await prisma.reactionRolePanel.update({
        where: { id: p.id },
        data: { publicationId: pub.id },
      });
    }
    assert(
      pub.channelId === ch.id,
      "O painel já foi publicado em outro canal. Crie uma cópia para mudar o destino.",
    );
    await prisma.reactionRolePanel.update({
      where: { id: p.id },
      data: { status: "ACTIVATING", lastError: null },
    });
    try {
      if (message)
        await message.edit({
          ...preparation,
          content: null,
          embeds: [],
          attachments: [],
        });
      else {
        message = await ch.send(preparation);
        await prisma.makerPublication.update({
          where: { id: pub.id },
          data: { messageId: message.id, status: "ACTIVATING" },
        });
      }
      // Seed the active bindings without clearing members' existing reactions.
      for (const b of list) await message.react(b.emojiApi);
      await message.edit({
        ...payload,
        content: null,
        embeds: [],
        attachments: [],
      });
      await prisma.$transaction(async (tx: any) => {
        await tx.reactionRoleBinding.updateMany({
          where: { guildId: guild.id, panelId: p.id, active: true },
          data: { published: true },
        });
        await tx.makerPublication.update({
          where: { id: pub.id },
          data: {
            messageId: message.id,
            name: p.name,
            snapshotJson: JSON.stringify(doc),
            payloadHash: hash(doc),
            status: "ACTIVE",
            lastError: null,
            revision: { increment: 1 },
          },
        });
        await tx.reactionRolePanel.update({
          where: { id: p.id },
          data: {
            status: "ACTIVE",
            publishedRemoveOnUnreact: p.removeOnUnreact,
            lastError: null,
            revision: { increment: 1 },
          },
        });
      });
    } catch (error: any) {
      await prisma.reactionRolePanel.update({
        where: { id: p.id },
        data: {
          status: "ERROR",
          lastError:
            "Ativação não concluída. Confira a mensagem e use Publicar / atualizar para concluir.",
        },
      });
      await prisma.makerPublication
        .update({
          where: { id: pub.id },
          data: {
            messageId: message?.id || pub.messageId,
            status: message ? "UNAVAILABLE" : "UNCERTAIN",
            lastError:
              "Painel em preparação; novas concessões estão suspensas.",
          },
        })
        .catch(() => null);
      throw new MakerError(
        "A ativação não terminou. O painel foi suspenso. Confira o canal e as permissões antes de concluir a ativação.",
      );
    }
    return panel(guild.id, id);
  });
}
async function freshMember(guild: any, userId: string) {
  try {
    return await guild.members.fetch({ user: userId, force: true });
  } catch (error: any) {
    if (error?.code === 10007) return null;
    throw new MakerError(
      "Não foi possível consultar o membro. Confira o diagnóstico e tente sincronizar novamente.",
    );
  }
}
const ownershipWhere = (guildId: string, userId: string, roleId: string) => ({
  guildId_userId_roleId: { guildId, userId, roleId },
});
export async function grant(guild: any, bindingId: string, userId: string) {
  const b = await prisma.reactionRoleBinding.findFirst({
    where: { id: bindingId, guildId: guild.id },
  });
  if (!b) return;
  return exclusive(
    "reaction-role:" + guild.id + ":" + userId + ":" + b.roleId,
    async () => {
      const current = await prisma.reactionRoleBinding.findFirst({
          where: { id: b.id, guildId: guild.id, active: true, published: true },
        }),
        p = await panel(guild.id, b.panelId);
      if (!current || p.status !== "ACTIVE") return;
      const member = await freshMember(guild, userId);
      if (!member || member.user.bot) return;
      await safeRole(guild, b.roleId);
      const where = { bindingId_userId: { bindingId: b.id, userId } };
      const g = await prisma.reactionRoleGrant.upsert({
        where,
        create: {
          id: uid(),
          guildId: guild.id,
          panelId: p.id,
          bindingId: b.id,
          userId,
          roleId: b.roleId,
        },
        update: {},
      });
      const owns = member.roles.cache.has(b.roleId),
        key = ownershipWhere(guild.id, userId, b.roleId);
      let owner = await prisma.reactionRoleOwnership.findUnique({ where: key });
      if (!owner)
        owner = await prisma.reactionRoleOwnership.create({
          data: {
            id: uid(),
            guildId: guild.id,
            userId,
            roleId: b.roleId,
            state: owns ? "PREEXISTING" : "PENDING",
          },
        });
      if (owns && ["PENDING", "REMOVING"].includes(owner.state)) {
        // A previous process may have stopped between API success and database write.
        owner = await prisma.reactionRoleOwnership.update({
          where: { id: owner.id },
          data: { state: "UNCERTAIN" },
        });
      }
      await prisma.reactionRoleGrant.update({
        where: { id: g.id },
        data: { active: true, status: "PENDING", lastError: null },
      });
      if (!owns) {
        await prisma.reactionRoleOwnership.update({
          where: { id: owner.id },
          data: { state: "PENDING" },
        });
        try {
          await member.roles.add(
            b.roleId,
            "BLACKOUT · Cargo escolhido por reação",
          );
        } catch {
          await prisma.reactionRoleGrant.update({
            where: { id: g.id },
            data: {
              status: "FAILED",
              lastError:
                "Concessão não confirmada. Confira permissões e sincronize o painel.",
            },
          });
          throw new MakerError(
            "Não foi possível confirmar a concessão do cargo.",
          );
        }
        await prisma.reactionRoleOwnership.update({
          where: { id: owner.id },
          data: { state: "OWNED" },
        });
      }
      return prisma.reactionRoleGrant.update({
        where: { id: g.id },
        data: { active: true, status: "ACTIVE", lastError: null },
      });
    },
  );
}
export async function release(
  guild: any,
  bindingId: string,
  userId: string,
  keep = false,
) {
  const g = await prisma.reactionRoleGrant.findUnique({
    where: { bindingId_userId: { bindingId, userId } },
  });
  if (!g || g.guildId !== guild.id) return;
  return exclusive(
    "reaction-role:" + guild.id + ":" + userId + ":" + g.roleId,
    async () => {
      const current = await prisma.reactionRoleGrant.findUnique({
        where: { id: g.id },
      });
      if (!current.active && current.status !== "REVOKE_PENDING") return;
      await prisma.reactionRoleGrant.update({
        where: { id: g.id },
        data: { active: false, status: keep ? "RETAINED" : "REVOKE_PENDING" },
      });
      const key = ownershipWhere(guild.id, userId, g.roleId),
        owner = await prisma.reactionRoleOwnership.findUnique({ where: key });
      if (keep) {
        if (owner)
          await prisma.reactionRoleOwnership.update({
            where: { id: owner.id },
            data: { state: "PREEXISTING" },
          });
        return;
      }
      if (
        await prisma.reactionRoleGrant.count({
          where: { guildId: guild.id, userId, roleId: g.roleId, active: true },
        })
      )
        return prisma.reactionRoleGrant.update({
          where: { id: g.id },
          data: { status: "RELEASED", lastError: null },
        });
      const member = await freshMember(guild, userId);
      if (member?.roles.cache.has(g.roleId) && owner?.state === "OWNED") {
        await safeRole(guild, g.roleId);
        const claimed = await prisma.reactionRoleOwnership.updateMany({
          where: { id: owner.id, state: "OWNED" },
          data: { state: "REMOVING" },
        });
        if (claimed.count) {
          try {
            await member.roles.remove(
              g.roleId,
              "BLACKOUT · Concessão por reação retirada",
            );
          } catch {
            await prisma.reactionRoleGrant.update({
              where: { id: g.id },
              data: {
                status: "REVOKE_PENDING",
                lastError:
                  "Retirada não confirmada. Confira o membro e repita a revisão.",
              },
            });
            throw new MakerError(
              "Não foi possível confirmar a retirada do cargo.",
            );
          }
          await prisma.reactionRoleOwnership.update({
            where: { id: owner.id },
            data: { state: "EMPTY" },
          });
        }
      } else if (owner && ["PENDING", "REMOVING"].includes(owner.state))
        await prisma.reactionRoleOwnership.update({
          where: { id: owner.id },
          data: {
            state: member?.roles.cache.has(g.roleId) ? "UNCERTAIN" : "EMPTY",
          },
        });
      return prisma.reactionRoleGrant.update({
        where: { id: g.id },
        data: {
          status: owner?.state === "UNCERTAIN" ? "RETAINED" : "RELEASED",
          lastError: null,
        },
      });
    },
  );
}
export async function onReaction(reaction: any, user: any, removing = false) {
  if (user?.bot || !user?.id) return;
  const messageId = reaction.message?.id;
  const pub = await prisma.makerPublication.findUnique({
    where: { messageId },
  });
  if (!pub?.panelId) return;
  const guild =
    reaction.message?.guild ||
    (await reaction.client?.guilds?.fetch(pub.guildId).catch(() => null));
  if (
    !guild ||
    guild.id !== pub.guildId ||
    reaction.message?.channelId !== pub.channelId
  )
    return;
  const p = await panel(guild.id, pub.panelId);
  if (p.status !== "ACTIVE") return;
  const key = reaction.emoji?.id
    ? "c:" + reaction.emoji.id
    : "u:" +
      String(reaction.emoji?.name || "")
        .normalize("NFC")
        .replace(/\uFE0F/g, "");
  const b = await prisma.reactionRoleBinding.findFirst({
    where: {
      guildId: guild.id,
      panelId: p.id,
      active: true,
      published: true,
      emojiKey: key,
    },
  });
  if (!b) return;
  try {
    if (removing)
      await release(guild, b.id, user.id, !p.publishedRemoveOnUnreact);
    else await grant(guild, b.id, user.id);
  } catch (error: any) {
    await prisma.reactionRolePanel.update({
      where: { id: p.id },
      data: {
        lastError:
          error instanceof MakerError
            ? error.message
            : "Falha ao processar uma reação. Use Conferir funcionamento.",
      },
    });
  }
}
export async function pause(guildId: string, id: string, paused: boolean) {
  const p = await panel(guildId, id);
  assert(
    ["ACTIVE", "PAUSED"].includes(p.status),
    "Conclua a publicação antes de pausar ou retomar.",
  );
  return prisma.reactionRolePanel.update({
    where: { id },
    data: { status: paused ? "PAUSED" : "ACTIVE", revision: { increment: 1 } },
  });
}
export async function disable(guild: any, bindingId: string, keep: boolean) {
  const b = await prisma.reactionRoleBinding.findFirst({
    where: { id: bindingId, guildId: guild.id },
  });
  assert(b, "Associação indisponível.");
  await prisma.reactionRoleBinding.update({
    where: { id: b.id },
    data: { active: false, retirement: keep ? "KEEP" : "REVOKE" },
  });
  await prisma.reactionRolePanel.update({
    where: { id: b.panelId },
    data: {
      revision: { increment: 1 },
      lastError:
        "Uma associação foi desativada. Atualize a mensagem para ajustar a legenda.",
    },
  });
  if (keep) {
    const users = await prisma.reactionRoleGrant.findMany({
      where: { guildId: guild.id, bindingId, active: true },
    });
    // No Discord mutation: retaining all tracked grants can be done in SQL.
    for (const g of users)
      await exclusive(
        "reaction-role:" + guild.id + ":" + g.userId + ":" + g.roleId,
        async () => {
          await prisma.reactionRoleGrant.update({
            where: { id: g.id },
            data: { active: false, status: "RETAINED" },
          });
          const owner = await prisma.reactionRoleOwnership.findUnique({
            where: ownershipWhere(guild.id, g.userId, g.roleId),
          });
          if (owner)
            await prisma.reactionRoleOwnership.update({
              where: { id: owner.id },
              data: { state: "PREEXISTING" },
            });
        },
      );
  }
  return b;
}
export async function revokeBatch(guild: any, bindingId: string) {
  const b = await prisma.reactionRoleBinding.findFirst({
    where: {
      id: bindingId,
      guildId: guild.id,
      active: false,
      retirement: "REVOKE",
    },
  });
  assert(b, "A remoção não foi autorizada para esta associação.");
  const list = await prisma.reactionRoleGrant.findMany({
    where: {
      guildId: guild.id,
      bindingId,
      OR: [{ active: true }, { status: "REVOKE_PENDING" }],
    },
    take: 25,
    orderBy: { createdAt: "asc" },
  });
  let failed = 0;
  for (const g of list)
    try {
      await release(guild, b.id, g.userId);
    } catch {
      failed++;
    }
  return {
    processed: list.length,
    failed,
    remaining: await prisma.reactionRoleGrant.count({
      where: {
        guildId: guild.id,
        bindingId,
        OR: [{ active: true }, { status: "REVOKE_PENDING" }],
      },
    }),
  };
}
export async function inspect(guild: any, id: string) {
  const p = await panel(guild.id, id),
    list = await bindings(guild.id, id, true);
  const problems: string[] = [];
  if (!p.publicationId) problems.push("O painel ainda não foi publicado.");
  else {
    const pub = await publication(guild.id, p.publicationId);
    try {
      const message = await fetchMessage(guild, pub);
      if (
        list.some(
          (b: any) =>
            !message.reactions.cache.some(
              (r: any) =>
                (r.emoji.id
                  ? "c:" + r.emoji.id
                  : "u:" +
                    String(r.emoji.name)
                      .normalize("NFC")
                      .replace(/\uFE0F/g, "")) === b.emojiKey,
            ),
        )
      ) {
        problems.push(
          "Faltam reações configuradas na mensagem. Use Publicar / atualizar para repô-las antes de sincronizar.",
        );
      }
    } catch (e: any) {
      problems.push(e.message);
    }
  }
  for (const b of list)
    try {
      await safeRole(guild, b.roleId);
    } catch {
      problems.push("Cargo indisponível: <@&" + b.roleId + ">.");
    }
  return { p, list, problems };
}
export async function planSync(guild: any, id: string) {
  const { p, list, problems } = await inspect(guild, id);
  assert(
    !problems.length && p.status === "ACTIVE",
    problems.join("\n") || "Retome o painel antes de sincronizar.",
  );
  const pub = await publication(guild.id, p.publicationId),
    message = await fetchMessage(guild, pub),
    items: any[] = [];
  const all = await message.reactions.cache;
  for (const b of list) {
    const r: any = all.find(
      (v: any) =>
        (v.emoji.id
          ? "c:" + v.emoji.id
          : "u:" +
            String(v.emoji.name)
              .normalize("NFC")
              .replace(/\uFE0F/g, "")) === b.emojiKey,
    );
    const reacted = new Set<string>();
    let after: string | undefined;
    if (r)
      for (let n = 0; n < 100; n++) {
        const batch = await r.users.fetch({
          limit: 100,
          ...(after ? { after } : {}),
        });
        for (const u of batch.values()) if (!u.bot) reacted.add(u.id);
        if (batch.size < 100) break;
        after = batch.last().id;
        assert(
          n < 99,
          "O painel excede o limite desta revisão. Nenhum cargo foi alterado.",
        );
      }
    const grants = await prisma.reactionRoleGrant.findMany({
      where: {
        guildId: guild.id,
        bindingId: b.id,
        OR: [{ active: true }, { status: "REVOKE_PENDING" }],
      },
    });
    const byUser = new Map<string, any>(grants.map((g: any) => [g.userId, g]));
    for (const userId of reacted) {
      const g = byUser.get(userId);
      // Validate current membership/roles in the processing batch rather than querying the entire guild here.
      items.push({ type: "ADD", bindingId: b.id, userId });
    }
    for (const g of grants)
      if (!reacted.has(g.userId))
        items.push({
          type: p.publishedRemoveOnUnreact ? "REMOVE" : "KEEP",
          bindingId: b.id,
          userId: g.userId,
        });
    assert(
      items.length <= 2000,
      "A revisão ultrapassa 2.000 participações. Nenhum cargo foi alterado. Divida os interesses em mais painéis.",
    );
  }
  return { panelId: p.id, revision: p.revision, items, errors: [] };
}
export async function syncItem(guild: any, id: string, item: any) {
  const p = await panel(guild.id, id);
  assert(
    p.status === "ACTIVE",
    "O painel foi pausado. Gere outra revisão depois de retomá-lo.",
  );
  const b = await prisma.reactionRoleBinding.findFirst({
    where: {
      id: item.bindingId,
      guildId: guild.id,
      panelId: p.id,
      active: true,
      published: true,
    },
  });
  if (!b) return;
  const pub = await publication(guild.id, p.publicationId),
    message = await fetchMessage(guild, pub);
  const r: any = message.reactions.cache.find(
    (r: any) =>
      (r.emoji.id
        ? "c:" + r.emoji.id
        : "u:" +
          String(r.emoji.name)
            .normalize("NFC")
            .replace(/\uFE0F/g, "")) === b.emojiKey,
  );
  const batch = r
    ? await r.users.fetch({
        limit: 1,
        after: (BigInt(item.userId) - 1n).toString(),
      })
    : null;
  const present = batch?.has(item.userId) || false;
  if (item.type === "ADD" && present) await grant(guild, b.id, item.userId);
  if (item.type === "REMOVE" && !present)
    await release(guild, b.id, item.userId);
  if (item.type === "KEEP" && !present)
    await release(guild, b.id, item.userId, true);
}
export async function messageDeleted(message: any) {
  const p = await prisma.makerPublication.findUnique({
    where: { messageId: message.id },
  });
  if (!p || (message.guildId && p.guildId !== message.guildId)) return;
  await prisma.makerPublication.update({
    where: { id: p.id },
    data: {
      status: "MISSING",
      lastError: "A mensagem foi apagada. Nenhuma cópia foi criada.",
    },
  });
  if (p.panelId)
    await prisma.reactionRolePanel.update({
      where: { id: p.panelId },
      data: {
        status: "PAUSED",
        lastError:
          "A mensagem foi apagada. Os cargos existentes foram preservados.",
      },
    });
}
export async function reactionsCleared(message: any) {
  const p = await prisma.makerPublication.findUnique({
    where: { messageId: message.id },
  });
  if (p?.panelId)
    await prisma.reactionRolePanel.update({
      where: { id: p.panelId },
      data: {
        status: "PAUSED",
        lastError:
          "Reações removidas da mensagem. Use Publicar / atualizar para repô-las; depois revise as participações.",
      },
    });
}
