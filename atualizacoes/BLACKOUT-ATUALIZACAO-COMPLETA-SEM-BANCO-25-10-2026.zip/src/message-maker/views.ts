import { prisma, D, row, button, select, v2, clean } from "./common";
import {
  Document,
  parse,
  pages,
  render,
  Block,
  countComponents,
  textLength,
} from "./document";
import { adminEmojiImage, admEmoji } from "../utils/admEmojis";
import * as S from "./service";
import * as R from "./roles";
const TYPES: Record<string, string> = {
  heading: "Título",
  text: "Texto",
  section: "Texto com miniatura",
  gallery: "Galeria de imagens",
  separator: "Separador",
  buttons: "Botões de links e canais",
};
export const typeName = (b: Block) => TYPES[b.type];
export const label = (b: Block, n: number) =>
  n +
  1 +
  ". " +
  TYPES[b.type] +
  (b.text ? " · " + clean(b.text.replace(/\*/g, ""), 45) : "");
export function header(
  guild: any,
  title: string,
  text: string,
  area: any = "sistema",
) {
  const c = new D.ContainerBuilder().setAccentColor(0xd71935),
    content = "## " + title + "\n" + text,
    image = adminEmojiImage(guild, area);
  if (image)
    c.addSectionComponents(
      new D.SectionBuilder()
        .addTextDisplayComponents(
          new D.TextDisplayBuilder().setContent(content),
        )
        .setThumbnailAccessory(new D.ThumbnailBuilder().setURL(image)),
    );
  else
    c.addTextDisplayComponents(new D.TextDisplayBuilder().setContent(content));
  return c;
}
function payload(components: any[]) {
  if (countComponents(components) > 40 || textLength(components) > 4000)
    throw new Error("Maker view exceeds native component budget");
  return {
    flags: D.MessageFlags.IsComponentsV2,
    components,
    allowedMentions: { parse: [] },
  };
}
function nav(
  guild: any,
  id: string,
  placeholder: string,
  options: any[],
  area = "sistema",
) {
  const icon = admEmoji(guild, area);
  return select(
    id,
    placeholder,
    options.map((o) => ({ ...o, ...(icon ? { emoji: { id: icon } } : {}) })),
  );
}
export async function home(guild: any) {
  await S.importLegacy(guild.id);
  const [models, sent] = await Promise.all([
    prisma.makerTemplate.count({
      where: { guildId: guild.id, deletedAt: null },
    }),
    prisma.makerPublication.count({
      where: { guildId: guild.id, panelId: null },
    }),
  ]);
  return payload([
    header(
      guild,
      "Mensagens Personalizadas / Embeds",
      "Crie mensagens V2 com prévia durante a edição. Cada envio é gerenciado separadamente.\n\nModelos salvos: **" +
        models +
        "** · Publicações registradas: **" +
        sent +
        "**",
    ),
    nav(guild, "home", "O que você quer fazer?", [
      {
        label: "Criar mensagem",
        value: "create",
        description: "Começar um rascunho V2",
      },
      {
        label: "Modelos salvos",
        value: "templates",
        description: "Editar, duplicar e reutilizar",
      },
      {
        label: "Mensagens enviadas",
        value: "publications",
        description: "Consultar e atualizar cada envio",
      },
    ]),
    row(button("area:sistema", "Voltar a Personalização do bot")),
  ]);
}
export async function templates(guild: any, page = 0) {
  await S.importLegacy(guild.id);
  const total = await prisma.makerTemplate.count({
    where: { guildId: guild.id, deletedAt: null },
  });
  page = Math.max(
    0,
    Math.min(Number(page) || 0, Math.max(0, Math.ceil(total / 10) - 1)),
  );
  const list = await prisma.makerTemplate.findMany({
    where: { guildId: guild.id, deletedAt: null },
    orderBy: { updatedAt: "desc" },
    skip: page * 10,
    take: 10,
  });
  const components: any[] = [
    header(
      guild,
      "Modelos salvos",
      list.length
        ? list
            .map(
              (t: any, n: number) =>
                "**" +
                (n + 1) +
                ". " +
                clean(t.name, 80) +
                "**" +
                (t.legacyId ? " · Importado" : ""),
            )
            .join("\n") +
            "\n\nPágina " +
            (page + 1) +
            " · " +
            total +
            " modelos"
        : "Você ainda não tem modelos. Crie uma mensagem para começar.",
    ),
  ];
  if (list.length)
    components.push(
      select(
        "template",
        "Escolha um modelo para editar",
        list.map((t: any) => ({
          value: t.id,
          label: clean(t.name),
          description: t.legacyId
            ? "Prévia de conversão para V2"
            : "Abrir rascunho de edição",
        })),
      ),
    );
  components.push(
    row(
      button("templates:" + (page - 1), "Anterior", 2, page === 0),
      button("templates:" + (page + 1), "Próxima", 2, (page + 1) * 10 >= total),
      button("create", "Criar mensagem", 1),
    ),
    row(button("home", "Voltar")),
  );
  return payload(components);
}
export async function editor(
  guild: any,
  s: any,
  requestedPage = 0,
  pure = false,
  notice = "",
) {
  const doc = parse(s.documentJson);
  const panel = s.panelId ? await R.panel(guild.id, s.panelId) : null;
  const previewDocument = panel
    ? R.withLegend(
        doc,
        await R.bindings(guild.id, panel.id),
        panel.removeOnUnreact,
      )
    : doc;
  const chunks = pages(previewDocument),
    page = Math.max(0, Math.min(Number(requestedPage) || 0, chunks.length - 1));
  const context =
    "**" +
    (s.panelId
      ? "Painel de cargos"
      : s.publicationId
        ? "Edição deste envio"
        : "Modelo") +
    " · " +
    clean(s.name, 80) +
    "**\n" +
    (notice ||
      (s.publicationId
        ? "Salvar o rascunho não altera a mensagem publicada. A atualização será confirmada separadamente."
        : "As alterações salvas aparecem abaixo. Publicar é uma ação separada.")) +
    (chunks.length > 1
      ? "\nPrévia · página " +
        (page + 1) +
        "/" +
        chunks.length +
        ". A publicação inclui todos os blocos."
      : "");
  const components: any[] = [
      new D.TextDisplayBuilder().setContent(context),
      ...render(chunks[page], true).components,
    ],
    id = s.id + ":" + s.revision;
  if (!pure) {
    components.push(
      select(
        "block:" + id,
        "Escolha um bloco para editar",
        doc.blocks
          .slice(0, 25)
          .map((b, n) => ({ value: b.id, label: clean(label(b, n)) })),
      ),
    );
    components.push(
      row(
        button("add:" + id, "Adicionar bloco"),
        button("organize:" + id, "Reorganizar / remover"),
        button("appearance:" + id, "Nome e cor"),
        button("undo:" + id, "Desfazer", 2, !s.undoJson),
      ),
    );
    components.push(
      row(
        button(
          "save:" + id,
          s.panelId
            ? "Salvar painel"
            : s.publicationId
              ? "Salvar como modelo"
              : "Salvar modelo",
        ),
        button(
          "publish:" + id,
          s.panelId
            ? "Configurar publicação"
            : s.publicationId
              ? "Atualizar este envio"
              : "Publicar",
          1,
        ),
        button("preview:" + id + ":" + page, "Ver prévia"),
      ),
    );
    if (!s.panelId)
      components.push(
        row(
          button("more:" + id, "Mais opções"),
          button("copy-role:" + id, "Usar em painel de cargos"),
        ),
      );
    else
      components.push(
        row(button("r-detail:" + s.panelId, "Voltar ao painel de cargos")),
      );
  } else
    components.push(
      row(button("edit:" + s.id + ":" + page, "Voltar ao editor")),
    );
  if (chunks.length > 1)
    components.push(
      row(
        button(
          (pure ? "preview:" + id : "edit:" + s.id) + ":" + (page - 1),
          "Anterior",
          2,
          page === 0,
        ),
        button(
          (pure ? "preview:" + id : "edit:" + s.id) + ":" + (page + 1),
          "Próxima",
          2,
          page === chunks.length - 1,
        ),
      ),
    );
  return payload(components);
}
export async function addTypes(guild: any, s: any) {
  return payload([
    header(
      guild,
      "Adicionar bloco",
      "Escolha o conteúdo. O bloco será inserido ao final; depois você pode reorganizar.",
    ),
    select(
      "add:" + s.id + ":" + s.revision,
      "Tipo de bloco",
      Object.entries(TYPES).map(([value, label]) => ({ value, label })),
    ),
    row(button("edit:" + s.id, "Voltar ao editor")),
  ]);
}
export async function organize(guild: any, s: any, selected?: string) {
  const doc = parse(s.documentJson),
    b = doc.blocks.find((v) => v.id === selected) || doc.blocks[0],
    n = doc.blocks.indexOf(b),
    id = s.id + ":" + s.revision + ":" + b.id;
  return payload([
    header(
      guild,
      "Organizar blocos",
      doc.blocks
        .map(
          (v, i) =>
            (v.id === b.id ? "**" : "") +
            label(v, i) +
            (v.id === b.id ? "**" : ""),
        )
        .join("\n"),
    ),
    select(
      "organize:" + s.id + ":" + s.revision,
      "Escolha o bloco",
      doc.blocks
        .slice(0, 25)
        .map((v, i) => ({ value: v.id, label: clean(label(v, i)) })),
    ),
    row(
      button("up:" + id, "Subir", 2, n === 0),
      button("down:" + id, "Descer", 2, n === doc.blocks.length - 1),
      button("duplicate:" + id, "Duplicar"),
      button("remove:" + id, "Remover", 4, doc.blocks.length === 1),
    ),
    row(button("edit:" + s.id, "Voltar ao editor")),
  ]);
}
export async function buttons(
  guild: any,
  s: any,
  blockId: string,
  selected?: string,
) {
  const b = parse(s.documentJson).blocks.find((v) => v.id === blockId),
    values = b?.buttons || [],
    chosen = values.find((v) => v.id === selected),
    id = s.id + ":" + s.revision + ":" + blockId;
  const components: any[] = [
    header(
      guild,
      "Botões da mensagem",
      values
        .map(
          (v, n) => "**" + (n + 1) + ". " + clean(v.label, 80) + "**\n" + v.url,
        )
        .join("\n\n") || "Adicione links ou atalhos para canais.",
    ),
  ];
  if (values.length)
    components.push(
      select(
        "button:" + id,
        "Escolha um botão",
        values.map((v) => ({ value: v.id, label: clean(v.label) })),
      ),
    );
  components.push(
    row(
      button("link:" + id, "Adicionar link", 2, values.length >= 5),
      button("channel-button:" + id, "Adicionar canal", 2, values.length >= 5),
    ),
  );
  if (chosen) {
    const pos = values.indexOf(chosen),
      full = id + ":" + chosen.id;
    components.push(
      row(
        button("button-edit:" + full, "Editar"),
        button("button-up:" + full, "Mover antes", 2, pos === 0),
        button(
          "button-down:" + full,
          "Mover depois",
          2,
          pos === values.length - 1,
        ),
        button("button-remove:" + full, "Remover", 4),
      ),
    );
  }
  components.push(row(button("edit:" + s.id, "Voltar ao editor")));
  return payload(components);
}
export async function publications(guild: any, page = 0) {
  await S.importLegacy(guild.id);
  const where = { guildId: guild.id, panelId: null },
    total = await prisma.makerPublication.count({ where });
  page = Math.max(
    0,
    Math.min(Number(page) || 0, Math.max(0, Math.ceil(total / 10) - 1)),
  );
  const list = await prisma.makerPublication.findMany({
    where,
    orderBy: { updatedAt: "desc" },
    skip: page * 10,
    take: 10,
  });
  const components: any[] = [
    header(
      guild,
      "Mensagens enviadas",
      list.length
        ? list
            .map(
              (p: any, n: number) =>
                "**" +
                (n + 1) +
                ". " +
                clean(p.name, 80) +
                "** · <#" +
                p.channelId +
                ">\n" +
                stateLabel(p.status) +
                " · <t:" +
                Math.floor(p.createdAt.getTime() / 1000) +
                ":d>",
            )
            .join("\n\n") +
            "\n\nPágina " +
            (page + 1)
        : "Nenhum envio registrado por este editor. Publicações antigas só aparecem quando seu ID já estava salvo.",
    ),
  ];
  if (list.length)
    components.push(
      select(
        "publication",
        "Escolha uma publicação",
        list.map((p: any) => ({
          value: p.id,
          label: clean(p.name),
          description: stateLabel(p.status),
        })),
      ),
    );
  components.push(
    row(
      button("publications:" + (page - 1), "Anterior", 2, page === 0),
      button(
        "publications:" + (page + 1),
        "Próxima",
        2,
        (page + 1) * 10 >= total,
      ),
    ),
    row(button("home", "Voltar")),
  );
  return payload(components);
}
export function stateLabel(state: string) {
  return (
    (
      {
        ACTIVE: "Publicada",
        LEGACY: "Publicação antiga · confira o original",
        SENDING: "Envio em preparação",
        UPDATING: "Atualização em preparação",
        UNCERTAIN: "Entrega não confirmada · confira o canal",
        UNAVAILABLE: "Acesso indisponível",
        MISSING: "Mensagem apagada",
        DELETED: "Mensagem excluída",
        DRAFT: "Rascunho",
        PAUSED: "Pausado",
        ACTIVATING: "Em preparação",
        ERROR: "Ativação pendente",
      } as any
    )[state] || "Confira o estado"
  );
}
export async function publicationView(guild: any, id: string, page = 0) {
  const p = await S.publication(guild.id, id),
    chunks = pages(p.snapshotJson);
  page = Math.max(0, Math.min(Number(page) || 0, chunks.length - 1));
  const components: any[] = [
    new D.TextDisplayBuilder().setContent(
      "**" +
        clean(p.name, 80) +
        "** · <#" +
        p.channelId +
        ">\n" +
        stateLabel(p.status) +
        (p.legacy
          ? "\nPrévia de conversão do modelo antigo; a mensagem original pode ter conteúdo diferente."
          : "\nPrévia do conteúdo registrado neste envio.") +
        (p.lastError ? "\n" + clean(p.lastError, 240) : "") +
        (chunks.length > 1
          ? "\nPágina " + (page + 1) + "/" + chunks.length
          : ""),
    ),
    ...render(chunks[page], true).components,
  ];
  const actions: any[] = [
    button(
      p.panelId ? "r-detail:" + p.panelId : "pub-edit:" + p.id,
      p.panelId ? "Gerenciar cargos" : "Editar este envio",
      2,
      !p.messageId,
    ),
    button("pub-copy:" + p.id, "Publicar uma cópia"),
    button("pub-check:" + p.id, "Verificar acesso", 2, !p.messageId),
  ];
  if (!p.messageId)
    actions.push(
      button("pub-register:" + p.id, "Registrar mensagem existente"),
    );
  if (p.messageId)
    actions.push(
      new D.ButtonBuilder()
        .setStyle(D.ButtonStyle.Link)
        .setLabel("Ir para mensagem")
        .setURL(
          "https://discord.com/channels/" +
            guild.id +
            "/" +
            p.channelId +
            "/" +
            p.messageId,
        ),
    );
  components.push(row(...actions));
  components.push(
    row(
      button(
        "pub-delete:" + p.id,
        "Excluir publicação",
        4,
        !p.messageId || !!p.panelId,
      ),
      button("publications:0", "Voltar aos envios"),
    ),
  );
  if (chunks.length > 1)
    components.push(
      row(
        button("pub:" + p.id + ":" + (page - 1), "Anterior", 2, page === 0),
        button(
          "pub:" + p.id + ":" + (page + 1),
          "Próxima",
          2,
          page === chunks.length - 1,
        ),
      ),
    );
  return payload(components);
}
export async function destination(guild: any, s: any) {
  const choose = new D.ChannelSelectMenuBuilder()
    .setCustomId("maker-select:destination:" + s.id + ":" + s.revision)
    .setPlaceholder("Canal de destino")
    .addChannelTypes(D.ChannelType.GuildText, D.ChannelType.GuildAnnouncement);
  if (s.destinationChannelId) choose.setDefaultChannels(s.destinationChannelId);
  return payload([
    header(
      guild,
      "Canal de publicação",
      "Escolha onde enviar. O rascunho continua salvo e nenhum envio é feito nesta escolha.\n\nCanal: " +
        (s.destinationChannelId
          ? "<#" + s.destinationChannelId + ">"
          : "Não definido"),
    ),
    row(choose),
    row(
      button(
        "review:" + s.id + ":" + s.revision,
        "Conferir publicação",
        1,
        !s.destinationChannelId,
      ),
      button("edit:" + s.id, "Voltar ao editor"),
    ),
  ]);
}
export async function confirmation(guild: any, a: any, page = 0) {
  const data = JSON.parse(a.payloadJson),
    components: any[] = [];
  if (a.kind === "PUBLISH") {
    const chunks = pages(data.documentJson);
    page = Math.max(0, Math.min(Number(page) || 0, chunks.length - 1));
    components.push(
      new D.TextDisplayBuilder().setContent(
        "**Conferir " +
          (data.publicationId ? "atualização deste envio" : "nova publicação") +
          "**\nCanal: <#" +
          data.channelId +
          ">\n" +
          (data.publicationId
            ? "Somente esta mensagem será atualizada."
            : "Uma nova mensagem será criada. Os envios anteriores serão preservados.") +
          "\nPrévia " +
          (page + 1) +
          "/" +
          chunks.length,
      ),
      ...render(chunks[page], true).components,
    );
    if (chunks.length > 1)
      components.push(
        row(
          button(
            "confirm-view:" + a.id + ":" + (page - 1),
            "Anterior",
            2,
            page === 0,
          ),
          button(
            "confirm-view:" + a.id + ":" + (page + 1),
            "Próxima",
            2,
            page === chunks.length - 1,
          ),
        ),
      );
  } else {
    const texts: any = {
      TEMPLATE_DELETE: [
        "Excluir modelo salvo?",
        "O modelo **" +
          clean(data.name, 80) +
          "** será retirado da lista. As publicações serão preservadas.",
      ],
      PUB_DELETE: [
        "Excluir esta publicação?",
        "Será apagada somente a mensagem **" +
          clean(data.name, 80) +
          "** em <#" +
          data.channelId +
          ">. O modelo e os outros envios serão preservados.",
      ],
      BINDING_KEEP: [
        "Desativar associação e preservar cargos?",
        "A reação deixará de conceder cargos. " +
          data.count +
          " concessões rastreadas serão preservadas.",
      ],
      BINDING_REVOKE: [
        "Desativar e revisar retirada dos cargos?",
        "A reação deixará de conceder cargos. Serão processadas até 25 concessões por etapa, respeitando cargos preexistentes e outras concessões. Vínculos atuais: " +
          data.count +
          ".",
      ],
      ROLE_PUBLISH: [
        "Publicar / atualizar painel de cargos?",
        "Canal: <#" +
          data.channelId +
          ">. A mensagem e as reações serão preparadas; os cargos existentes serão preservados.",
      ],
      SYNC: [
        "Conferir participações do painel",
        "Serão verificadas **" +
          (data.items?.length || 0) +
          "** participações em etapas de 25. Cada reação será conferida novamente antes de conceder ou retirar um cargo. Nada foi alterado nesta revisão.",
      ],
    };
    const info = texts[a.kind] || [
      "Conferir ação",
      "Revise antes de confirmar.",
    ];
    components.push(
      header(
        guild,
        info[0],
        info[1],
        a.kind.startsWith("BINDING") ||
          a.kind === "SYNC" ||
          a.kind === "ROLE_PUBLISH"
          ? "membros"
          : "sistema",
      ),
    );
  }
  components.push(
    row(
      button(
        "confirm:" + a.id,
        "Confirmar",
        a.kind.endsWith("DELETE") || a.kind === "BINDING_REVOKE" ? 4 : 1,
      ),
      button(
        data.sessionId
          ? "edit:" + data.sessionId
          : data.panelId
            ? "r-detail:" + data.panelId
            : a.kind === "TEMPLATE_DELETE"
              ? "templates:0"
              : "publications:0",
        "Cancelar",
      ),
    ),
  );
  return payload(components);
}
export async function roleHome(guild: any, page = 0) {
  const total = await prisma.reactionRolePanel.count({
    where: { guildId: guild.id },
  });
  page = Math.max(
    0,
    Math.min(Number(page) || 0, Math.max(0, Math.ceil(total / 10) - 1)),
  );
  const list = await prisma.reactionRolePanel.findMany({
    where: { guildId: guild.id },
    orderBy: { updatedAt: "desc" },
    skip: page * 10,
    take: 10,
  });
  const components: any[] = [
    header(
      guild,
      "Cargos por reação",
      list.length
        ? list
            .map(
              (p: any, n: number) =>
                "**" +
                (n + 1) +
                ". " +
                clean(p.name, 80) +
                "**\n" +
                stateLabel(p.status) +
                (p.channelId
                  ? " · <#" + p.channelId + ">"
                  : " · Canal não definido"),
            )
            .join("\n\n")
        : "Crie um painel para que os membros escolham jogos, interesses e notificações reagindo à mensagem.",
      "membros",
    ),
  ];
  if (list.length)
    components.push(
      nav(
        guild,
        "r-panel",
        "Escolha um painel",
        list.map((p: any) => ({
          value: p.id,
          label: clean(p.name),
          description: stateLabel(p.status),
        })),
        "membros",
      ),
    );
  components.push(
    row(
      button("r-create", "Criar painel", 1),
      button("r-home:" + (page - 1), "Anterior", 2, page === 0),
      button("r-home:" + (page + 1), "Próxima", 2, (page + 1) * 10 >= total),
    ),
    row(button("automations", "Voltar a Cargos e automações")),
  );
  return payload(components);
}
export async function roleDetail(guild: any, id: string, notice = "") {
  const p = await R.panel(guild.id, id),
    list = await R.bindings(guild.id, id),
    pending = list.filter((b: any) => !b.published).length;
  const publication = p.publicationId
    ? await S.publication(guild.id, p.publicationId)
    : null;
  return payload([
    header(
      guild,
      p.name,
      "Estado: **" +
        stateLabel(p.status) +
        "**\nCanal: " +
        (p.channelId ? "<#" + p.channelId + ">" : "Não definido") +
        "\nAssociações ativas: " +
        list.length +
        (pending ? " · " + pending + " aguardando publicação" : "") +
        "\nAo retirar a reação: **" +
        (p.removeOnUnreact
          ? "remover a concessão deste painel"
          : "preservar o cargo") +
        "**\n\n" +
        (notice ||
          p.lastError ||
          "Editar e salvar não publica. As novas regras valem após Publicar / atualizar."),
      "membros",
    ),
    nav(
      guild,
      "r-task:" + p.id,
      "Escolha o que configurar",
      [
        {
          label: "Mensagem e prévia",
          value: "message",
          description: "Editar o conteúdo com o editor V2",
        },
        {
          label: "Reações e cargos",
          value: "bindings",
          description: "Associar emojis e cargos permitidos",
        },
        {
          label: "Canal do painel",
          value: "channel",
          description: "Escolher onde publicar",
        },
        {
          label: "Ao retirar a reação",
          value: "rule",
          description: "Escolher se a concessão será removida",
        },
        {
          label: "Conferir funcionamento",
          value: "inspect",
          description: "Permissões, mensagem e sincronização",
        },
      ],
      "membros",
    ),
    row(
      button("r-publish:" + p.id + ":" + p.revision, "Publicar / atualizar", 1),
      button(
        "r-toggle:" + p.id,
        p.status === "PAUSED" ? "Retomar painel" : "Pausar painel",
        2,
        !["ACTIVE", "PAUSED"].includes(p.status),
      ),
    ),
    row(
      button("r-copy:" + p.id, "Duplicar painel"),
      button("r-home:0", "Voltar aos painéis"),
    ),
    ...(publication && !publication.messageId
      ? [
          row(
            button(
              "pub-register:" + publication.id,
              "Registrar mensagem existente",
            ),
          ),
        ]
      : []),
  ]);
}
export async function roleBindings(guild: any, id: string) {
  const p = await R.panel(guild.id, id),
    list = await R.bindings(guild.id, id);
  const components: any[] = [
    header(
      guild,
      "Reações e cargos · " + clean(p.name, 50),
      list.length
        ? list
            .map(
              (b: any) =>
                b.emojiDisplay +
                " → <@&" +
                b.roleId +
                "> · " +
                (b.published ? "Publicada" : "Rascunho"),
            )
            .join("\n")
        : "Associe a primeira reação a um cargo. Cargos administrativos não podem ser oferecidos aqui.",
      "membros",
    ),
  ];
  if (list.length)
    components.push(
      select(
        "r-binding:" + id,
        "Escolha uma associação para gerenciar",
        list.map((b: any, n: number) => ({
          value: b.id,
          label: clean(
            n +
              1 +
              ". " +
              b.emojiDisplay +
              " · " +
              (guild.roles.cache.get(b.roleId)?.name || "Cargo indisponível"),
          ),
        })),
      ),
    );
  components.push(
    row(
      button(
        "r-add:" + id + ":" + p.revision,
        "Adicionar associação",
        1,
        list.length >= 20,
      ),
      button("r-detail:" + id, "Voltar ao painel"),
    ),
  );
  const pending = await prisma.reactionRoleBinding.findMany({
    where: {
      guildId: guild.id,
      panelId: id,
      active: false,
      retirement: "REVOKE",
    },
    take: 5,
  });
  for (const b of pending)
    if (
      await prisma.reactionRoleGrant.count({
        where: {
          guildId: guild.id,
          bindingId: b.id,
          OR: [{ active: true }, { status: "REVOKE_PENDING" }],
        },
      })
    )
      components.push(
        row(
          button(
            "r-revoke-batch:" + b.id,
            "Continuar remoções · " + clean(b.emojiDisplay, 20),
          ),
        ),
      );
  return payload(components);
}
export async function roleInspect(guild: any, id: string) {
  const { p, problems } = await R.inspect(guild, id),
    failed = await prisma.reactionRoleGrant.count({
      where: {
        guildId: guild.id,
        panelId: id,
        status: { in: ["FAILED", "REVOKE_PENDING"] },
      },
    });
  return payload([
    header(
      guild,
      "Conferir funcionamento",
      (problems.length
        ? problems.join("\n")
        : "Mensagem acessível e cargos publicados disponíveis.") +
        "\nConcessões com falha ou retirada pendente: " +
        failed +
        "\n\nO Discord não reenvia todos os eventos ocorridos durante uma desconexão. Revisar participações compara as reações atuais com os registros antes de aplicar mudanças.",
      "membros",
    ),
    row(
      button(
        "r-sync:" + id,
        "Revisar participações",
        1,
        problems.length > 0 || p.status !== "ACTIVE",
      ),
      button("r-detail:" + id, "Voltar ao painel"),
    ),
  ]);
}
export async function syncProgress(guild: any, a: any) {
  const data = JSON.parse(a.payloadJson),
    done = a.cursor >= data.items.length;
  return payload([
    header(
      guild,
      "Sincronização do painel",
      "Participações processadas: **" +
        a.cursor +
        "/" +
        data.items.length +
        "**\nFalhas registradas: **" +
        (data.errors?.length || 0) +
        "**\n" +
        (done
          ? "Revisão concluída. As mudanças foram limitadas às reações confirmadas."
          : a.status === "RUNNING"
            ? "Esta etapa não teve conclusão confirmada. Gere uma nova revisão para conferir o estado atual."
            : "Continue para processar as próximas 25 participações."),
      "membros",
    ),
    row(
      button(
        "sync-next:" + a.id,
        "Continuar",
        1,
        done || a.status === "RUNNING",
      ),
      button("r-inspect:" + data.panelId, "Voltar ao diagnóstico"),
    ),
  ]);
}
