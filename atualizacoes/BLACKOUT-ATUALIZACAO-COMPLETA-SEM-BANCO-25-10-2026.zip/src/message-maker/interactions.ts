import {
  guard,
  prisma,
  assert,
  deferPanel,
  show,
  session,
  getAction,
  row,
  button,
  D,
  exclusive,
} from "./common";
import * as E from "./editorInteractions";
import * as RI from "./roleInteractions";
import * as R from "./roles";
import * as S from "./service";
import * as V from "./views";
import { parse, render, copy, MakerError } from "./document";
import { buildAdmRootPanel, buildAdmSectionPanel } from "../utils/admPanel";
export async function runSync(i: any, id: string, first = false) {
  let a = await getAction(i, id, first);
  assert(a.kind === "SYNC", "Revisão inválida.");
  if (!first && a.status !== "MORE")
    return show(i, await V.syncProgress(i.guild, a));
  const data = JSON.parse(a.payloadJson),
    p = await R.panel(i.guild.id, data.panelId);
  assert(
    p.status === "ACTIVE" && p.revision === data.revision,
    "O painel mudou. Gere uma nova revisão de participações.",
  );
  if (!first) {
    const claimed = await prisma.makerAction.updateMany({
      where: { id, status: "MORE", cursor: a.cursor },
      data: { status: "RUNNING" },
    });
    if (!claimed.count)
      return show(i, await V.syncProgress(i.guild, await getAction(i, id)));
  }
  const end = Math.min(a.cursor + 25, data.items.length);
  for (let n = a.cursor; n < end; n++) {
    try {
      await R.syncItem(i.guild, data.panelId, data.items[n]);
    } catch (e: any) {
      data.errors.push({
        index: n,
        message: e instanceof MakerError ? e.message : "Falha de processamento",
      });
    }
  }
  a = await prisma.makerAction.update({
    where: { id },
    data: {
      cursor: end,
      payloadJson: JSON.stringify(data),
      status: end >= data.items.length ? "DONE" : "MORE",
    },
  });
  return show(i, await V.syncProgress(i.guild, a));
}
async function confirm(i: any, id: string) {
  const preview = await getAction(i, id),
    data = JSON.parse(preview.payloadJson);
  if (preview.kind === "SYNC") return runSync(i, id, true);
  const op = await getAction(i, id, true);
  if (op.kind === "PUBLISH") {
    const s = await session(i, data.sessionId, data.revision);
    assert(
      s.documentJson === data.documentJson &&
        s.destinationChannelId === data.channelId &&
        s.publicationId === data.publicationId,
      "A revisão mudou. Confira novamente.",
    );
    const p = await S.publishSession(i, s);
    await prisma.makerAction.update({
      where: { id },
      data: { status: "DONE" },
    });
    return show(i, await V.publicationView(i.guild, p.id));
  }
  if (op.kind === "ROLE_PUBLISH") {
    await R.publish(i.guild, op.targetId, data.revision);
    await prisma.makerAction.update({
      where: { id },
      data: { status: "DONE" },
    });
    return show(
      i,
      await V.roleDetail(
        i.guild,
        op.targetId,
        "Painel publicado e reações preparadas.",
      ),
    );
  }
  if (op.kind === "TEMPLATE_DELETE") {
    const r = await prisma.makerTemplate.updateMany({
      where: {
        id: op.targetId,
        guildId: i.guild.id,
        deletedAt: null,
        revision: data.revision,
      },
      data: { deletedAt: new Date(), revision: { increment: 1 } },
    });
    assert(r.count === 1, "O modelo mudou. Abra uma nova revisão.");
    return show(i, await V.templates(i.guild));
  }
  if (op.kind === "PUB_DELETE") {
    const p = await S.publication(i.guild.id, op.targetId);
    assert(
      p.revision === data.revision && !p.panelId,
      "A publicação mudou. Abra uma nova revisão.",
    );
    const message = await S.fetchMessage(i.guild, p);
    try {
      await message.delete();
    } catch {
      throw new MakerError(
        "Não foi possível confirmar a exclusão. Confira a mensagem original antes de repetir.",
      );
    }
    await prisma.makerPublication.update({
      where: { id: p.id },
      data: { status: "DELETED", lastError: null, revision: { increment: 1 } },
    });
    return show(i, await V.publications(i.guild));
  }
  if (op.kind === "BINDING_KEEP" || op.kind === "BINDING_REVOKE") {
    const current = await prisma.reactionRoleGrant.count({
      where: { guildId: i.guild.id, bindingId: op.targetId, active: true },
    });
    assert(
      current === data.count,
      "A quantidade de participações mudou. Confira uma nova revisão.",
    );
    const b = await R.disable(i.guild, op.targetId, op.kind === "BINDING_KEEP");
    if (op.kind === "BINDING_REVOKE") await R.revokeBatch(i.guild, op.targetId);
    return show(i, await V.roleBindings(i.guild, b.panelId));
  }
  throw new MakerError("Esta ação não está disponível.");
}
function matches(expected: any, actual: any): boolean {
  if (Array.isArray(expected))
    return (
      Array.isArray(actual) &&
      expected.length === actual.length &&
      expected.every((v, n) => matches(v, actual[n]))
    );
  if (expected && typeof expected === "object")
    return (
      actual &&
      Object.keys(expected)
        .filter((k) => k !== "id")
        .every((k) => matches(expected[k], actual[k]))
    );
  if (expected === false && actual === undefined) return true;
  return expected === actual;
}
async function register(i: any, id: string) {
  const a = await getAction(i, id, true);
  assert(a.kind === "REGISTER", "Formulário inválido.");
  const p = await S.publication(i.guild.id, a.targetId);
  assert(!p.messageId, "Esta publicação já tem uma mensagem registrada.");
  const messageId = i.fields.getTextInputValue("message").trim();
  assert(
    /^[0-9]{17,22}$/.test(messageId),
    "Informe o ID numérico da mensagem.",
  );
  const ch = await S.channel(i.guild, p.channelId),
    m = await ch.messages.fetch(messageId).catch(() => null);
  assert(
    m?.author?.id === i.guild.client.user.id && m.channelId === p.channelId,
    "A mensagem precisa ter sido enviada por este bot no canal registrado.",
  );
  const actual = m.components.map((c: any) => (c.toJSON ? c.toJSON() : c));
  let valid = matches(
    render(p.snapshotJson).components.map((c) => c.toJSON()),
    actual,
  );
  if (!valid && p.panelId) {
    const panel = await R.panel(i.guild.id, p.panelId);
    valid = matches(
      render(
        R.withLegend(
          parse(panel.documentJson),
          await R.bindings(i.guild.id, panel.id),
          panel.removeOnUnreact,
          true,
        ),
      ).components.map((c) => c.toJSON()),
      actual,
    );
  }
  assert(
    valid,
    "O conteúdo da mensagem não corresponde a este envio. Nenhuma outra mensagem do bot foi vinculada.",
  );
  const r = await prisma.makerPublication.updateMany({
    where: { id: p.id, guildId: i.guild.id, messageId: null },
    data: {
      messageId,
      status: p.panelId ? "ACTIVATING" : "ACTIVE",
      legacy: false,
      lastError: null,
    },
  });
  assert(r.count === 1, "Esta publicação mudou. Abra novamente.");
  return show(
    i,
    p.panelId
      ? await V.roleDetail(
          i.guild,
          p.panelId,
          "Mensagem registrada. Use Publicar / atualizar para concluir a ativação.",
        )
      : await V.publicationView(i.guild, p.id),
  );
}
export async function execute(i: any) {
  return guard(i, async () => {
    const [prefix, ...parts] = i.customId.split(":"),
      name = parts[0];
    const modalLaunch =
      (prefix === "maker" &&
        ["appearance", "link", "button-edit", "pub-register"].includes(name)) ||
      (prefix === "maker-select" &&
        ["block", "add", "button-channel", "r-role"].includes(name));
    if (!modalLaunch) await deferPanel(i);
    if (prefix === "maker") {
      if (name === "confirm") return confirm(i, parts[1]);
      if (name === "confirm-view")
        return show(
          i,
          await V.confirmation(
            i.guild,
            await getAction(i, parts[1]),
            Number(parts[2]),
          ),
        );
      if (name === "sync-next") return runSync(i, parts[1]);
      if (name === "area")
        return show(i, await buildAdmSectionPanel(i.guild, parts[1]));
      if (name === "root")
        return show(i, await buildAdmRootPanel(i.guild, i.user));
      if (name === "automations") return require("./navigation").automations(i);
      if (name.startsWith("r-")) return RI.buttons(i, parts);
      const result = await E.buttonAction(i, parts);
      if (result !== false) return result;
    }
    if (prefix === "maker-select") {
      if (name === "automation") {
        const choice = i.values[0];
        if (choice === "arrival")
          return require("../components/buttons/admConfigMenu").renderAutoRoleMenu(
            i,
          );
        if (choice === "transfer")
          return require("../components/buttons/admRoleTransferMenu").renderRoleTransferMenu(
            i,
          );
        if (choice === "reactions") return show(i, await V.roleHome(i.guild));
      }
      const result = name.startsWith("r-")
        ? await RI.selects(i, parts)
        : await E.selectAction(i, parts);
      if (result !== false) return result;
    }
    if (prefix === "maker-form") {
      if (name === "register") return register(i, parts[1]);
      const result =
        name === "binding"
          ? await RI.modals(i, parts)
          : await E.modalAction(i, parts);
      if (result !== false) return result;
    }
    throw new MakerError(
      "Esta opção não está disponível. Reabra o painel com /adm.",
    );
  });
}
export async function openHome(i: any) {
  return guard(i, async () => {
    await deferPanel(i);
    return show(i, await V.home(i.guild));
  });
}
export async function openRoles(i: any) {
  return guard(i, async () => {
    await deferPanel(i);
    return show(i, await V.roleHome(i.guild));
  });
}
export async function legacyEntry(i: any, legacyId?: string) {
  return guard(i, async () => {
    await deferPanel(i);
    await S.importLegacy(i.guild.id);
    if (legacyId) {
      const t = await prisma.makerTemplate.findFirst({
        where: { guildId: i.guild.id, legacyId, deletedAt: null },
      });
      if (t)
        return show(
          i,
          await V.editor(i.guild, await S.start(i, { templateId: t.id })),
        );
    }
    return show(i, await V.home(i.guild));
  });
}
