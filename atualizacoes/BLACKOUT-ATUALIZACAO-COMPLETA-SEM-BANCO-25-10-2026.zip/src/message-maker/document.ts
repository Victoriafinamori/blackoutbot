import * as D from "discord.js";
import { randomBytes, createHash } from "node:crypto";

export type Block = {
  id: string;
  type: "text" | "heading" | "section" | "gallery" | "separator" | "buttons";
  text?: string;
  thumbnail?: string;
  images?: string[];
  buttons?: { id: string; label: string; url: string; emoji?: string }[];
};
export type Document = { version: 2; color: string; blocks: Block[] };
export const uid = () => randomBytes(12).toString("hex");
export const copy = <T>(x: T): T => JSON.parse(JSON.stringify(x));
export class MakerError extends Error {}
export function assert(ok: any, message: string): asserts ok {
  if (!ok) throw new MakerError(message);
}
export function url(value: string) {
  try {
    const u = new URL(value);
    return (
      ["https:", "http:"].includes(u.protocol) &&
      !u.username &&
      !u.password &&
      value.length <= 1000
    );
  } catch {
    return false;
  }
}
export function blank(): Document {
  return {
    version: 2,
    color: "D71935",
    blocks: [
      { id: uid(), type: "heading", text: "Sua próxima mensagem" },
      {
        id: uid(),
        type: "text",
        text: "Edite este texto e construa a mensagem da sua comunidade.",
      },
    ],
  };
}
export function parse(raw: string | Document): Document {
  const d = typeof raw === "string" ? JSON.parse(raw) : copy(raw);
  assert(
    d?.version === 2 && Array.isArray(d.blocks),
    "O modelo não está no formato de mensagens V2.",
  );
  assert(
    /^[A-Fa-f0-9]{6}$/.test(d.color),
    "Use uma cor hexadecimal com seis caracteres.",
  );
  assert(
    d.blocks.length >= 1 && d.blocks.length <= 30,
    "A mensagem excedeu o limite de blocos.",
  );
  const keys = new Set<string>();
  for (const b of d.blocks) {
    assert(
      typeof b.id === "string" &&
        /^[a-zA-Z0-9_-]{1,32}$/.test(b.id) &&
        !keys.has(b.id),
      "Um bloco está inconsistente. Reabra o modelo.",
    );
    keys.add(b.id);
    assert(
      [
        "text",
        "heading",
        "section",
        "gallery",
        "separator",
        "buttons",
      ].includes(b.type),
      "Esse tipo de bloco não é compatível.",
    );
    if (["text", "heading", "section"].includes(b.type))
      assert(
        typeof b.text === "string" &&
          b.text.trim().length > 0 &&
          b.text.length <= (b.type === "heading" ? 256 : 4000),
        "Preencha o texto do bloco dentro do limite indicado.",
      );
    if (b.type === "section")
      assert(
        url(b.thumbnail || ""),
        "A miniatura precisa de um link http:// ou https:// válido.",
      );
    if (b.type === "gallery")
      assert(
        Array.isArray(b.images) &&
          b.images.length >= 1 &&
          b.images.length <= 10 &&
          b.images.every(url),
        "Use de 1 a 10 links válidos na galeria.",
      );
    if (b.type === "buttons") {
      assert(
        Array.isArray(b.buttons) &&
          b.buttons.length >= 1 &&
          b.buttons.length <= 5,
        "Cada bloco comporta de 1 a 5 botões.",
      );
      for (const v of b.buttons) {
        assert(
          v.label?.trim() && v.label.length <= 80 && url(v.url),
          "Preencha o nome e um link válido para cada botão.",
        );
        if (v.emoji) {
          try {
            new D.ButtonBuilder()
              .setStyle(D.ButtonStyle.Link)
              .setLabel(v.label)
              .setURL(v.url)
              .setEmoji(v.emoji)
              .toJSON();
          } catch {
            throw new MakerError("Um emoji de botão não é válido.");
          }
        }
      }
    }
  }
  return d;
}
export function blockComponents(b: Block, disabled = false): any[] {
  if (b.type === "separator")
    return [
      new D.SeparatorBuilder()
        .setDivider(true)
        .setSpacing(D.SeparatorSpacingSize.Small),
    ];
  if (b.type === "gallery")
    return [
      new D.MediaGalleryBuilder().addItems(
        ...b.images!.map((u) => new D.MediaGalleryItemBuilder().setURL(u)),
      ),
    ];
  if (b.type === "section")
    return [
      new D.SectionBuilder()
        .addTextDisplayComponents(
          new D.TextDisplayBuilder().setContent(b.text!),
        )
        .setThumbnailAccessory(new D.ThumbnailBuilder().setURL(b.thumbnail!)),
    ];
  if (b.type === "buttons")
    return [
      new D.ActionRowBuilder<D.ButtonBuilder>().addComponents(
        ...b.buttons!.map((v) => {
          const out = new D.ButtonBuilder()
            .setStyle(D.ButtonStyle.Link)
            .setLabel(v.label)
            .setURL(v.url)
            .setDisabled(disabled);
          if (v.emoji) out.setEmoji(v.emoji);
          return out;
        }),
      ),
    ];
  return [
    new D.TextDisplayBuilder().setContent(
      b.type === "heading" ? "## " + b.text : b.text!,
    ),
  ];
}
export function countComponents(components: any[]): number {
  return components.reduce((n, c) => {
    const v = typeof c.toJSON === "function" ? c.toJSON() : c;
    return (
      n +
      1 +
      (v.components ? countComponents(v.components) : 0) +
      (v.accessory ? countComponents([v.accessory]) : 0)
    );
  }, 0);
}
export function textLength(components: any[]): number {
  return components.reduce((n, c) => {
    const v = typeof c.toJSON === "function" ? c.toJSON() : c;
    return (
      n +
      (typeof v.content === "string" ? v.content.length : 0) +
      (v.components ? textLength(v.components) : 0)
    );
  }, 0);
}
export function render(raw: Document | string, disabled = false) {
  const doc = parse(raw),
    parts = doc.blocks.flatMap((b) => blockComponents(b, disabled));
  const container = new D.ContainerBuilder().setAccentColor(
    parseInt(doc.color, 16),
  );
  for (const c of parts) add(container, c);
  const components = [container];
  assert(
    countComponents(components) <= 40,
    "Esta mensagem ultrapassa 40 componentes. Remova ou divida alguns blocos.",
  );
  assert(
    textLength(components) <= 4000,
    "Esta mensagem ultrapassa 4.000 caracteres. Reduza o texto ou divida em dois modelos.",
  );
  return {
    flags: D.MessageFlags.IsComponentsV2,
    components,
    allowedMentions: { parse: [] as any[] },
  };
}
export function add(container: D.ContainerBuilder, c: any) {
  const type = c.toJSON().type;
  if (type === 10) container.addTextDisplayComponents(c);
  else if (type === 9) container.addSectionComponents(c);
  else if (type === 12) container.addMediaGalleryComponents(c);
  else if (type === 14) container.addSeparatorComponents(c);
  else container.addActionRowComponents(c);
}
export function pages(raw: Document | string, disabled = true): Document[] {
  const doc = parse(raw),
    out: Document[] = [];
  let blocks: Block[] = [],
    count = 1,
    chars = 0;
  // Reserve native components and text for editing controls. Do not truncate publication.
  for (const original of doc.blocks) {
    const fragments =
      ["text", "section"].includes(original.type) &&
      original.text!.length > 2400
        ? original.text!.match(/[\s\S]{1,2400}/g)!.map(
            (text, n) =>
              ({
                ...original,
                type: n === 0 ? original.type : "text",
                id: original.id.slice(0, 25) + "_" + n,
                text,
              }) as Block,
          )
        : [original];
    for (const b of fragments) {
      const c = blockComponents(b, disabled),
        nc = countComponents(c),
        nt = textLength(c);
      if (blocks.length && (count + nc > 20 || chars + nt > 2700)) {
        out.push({ ...doc, blocks });
        blocks = [];
        count = 1;
        chars = 0;
      }
      blocks.push(b);
      count += nc;
      chars += nt;
    }
  }
  if (blocks.length) out.push({ ...doc, blocks });
  return out;
}
export const hash = (doc: Document | string) =>
  createHash("sha256")
    .update(JSON.stringify(parse(doc)))
    .digest("hex");
export function legacy(record: any, guildId: string): Document {
  const blocks: Block[] = [],
    text = (value: string, type: Block["type"] = "text") => {
      if (value?.trim())
        for (const part of value.match(/[\s\S]{1,1800}/g) || [])
          blocks.push({ id: uid(), type, text: part });
    };
  text(record.author ? "**" + record.author + "**" : "");
  if (record.title && record.thumbnailUrl && url(record.thumbnailUrl))
    blocks.push({
      id: uid(),
      type: "section",
      text: "**" + record.title + "**",
      thumbnail: record.thumbnailUrl,
    });
  else {
    text(record.title, "heading");
    if (record.thumbnailUrl && url(record.thumbnailUrl))
      blocks.push({
        id: uid(),
        type: "gallery",
        images: [record.thumbnailUrl],
      });
  }
  text(record.description);
  if (record.imageUrl && url(record.imageUrl))
    blocks.push({ id: uid(), type: "gallery", images: [record.imageUrl] });
  text(record.footer ? "-# " + record.footer : "");
  if (record.showTimestamp && record.createdAt)
    text(
      "-# Modelo criado em " +
        new Date(record.createdAt).toLocaleDateString("pt-BR", {
          timeZone: "America/Sao_Paulo",
        }),
    );
  const buttons = (record.buttons || [])
    .map((b: any) => ({
      id: uid(),
      label: b.label,
      emoji: b.emoji || undefined,
      url:
        b.type === "CHANNEL"
          ? "https://discord.com/channels/" + guildId + "/" + b.channelId
          : b.url,
    }))
    .filter((b: any) => url(b.url || ""));
  for (let n = 0; n < buttons.length; n += 5)
    blocks.push({
      id: uid(),
      type: "buttons",
      buttons: buttons.slice(n, n + 5),
    });
  if (!blocks.length)
    blocks.push({
      id: uid(),
      type: "text",
      text: "Edite o conteúdo desta mensagem antes de publicar.",
    });
  return parse({
    version: 2,
    color: /^[a-f0-9]{6}$/i.test(String(record.color).replace("#", ""))
      ? String(record.color).replace("#", "").toUpperCase()
      : "D71935",
    blocks,
  });
}
