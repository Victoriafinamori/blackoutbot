import {
  D,
  prisma,
  assert,
  row,
  button,
  select,
  form,
  show,
  action,
  getAction,
} from "./common";
import * as R from "./roles";
import * as S from "./service";
import * as V from "./views";
import { parse, copy, uid, render } from "./document";
export async function buttons(i: any, parts: string[]) {
  const [a, id, revision] = parts;
  if (a === "r-home") return show(i, await V.roleHome(i.guild, Number(id)));
  if (a === "r-create") {
    const p = await R.create(i.guild.id, i.user.id);
    return show(
      i,
      await V.editor(i.guild, await S.start(i, { panelId: p.id })),
    );
  }
  if (a === "r-detail") return show(i, await V.roleDetail(i.guild, id));
  if (a === "r-copy") {
    const p = await R.panel(i.guild.id, id),
      next = await R.create(
        i.guild.id,
        i.user.id,
        parse(p.documentJson),
        (p.name + " · Cópia").slice(0, 80),
      );
    for (const b of await R.bindings(i.guild.id, p.id))
      await R.addBinding(i.guild, next.id, b.roleId, b.emojiDisplay);
    return show(
      i,
      await V.roleDetail(
        i.guild,
        next.id,
        "Cópia independente criada. Escolha o canal e confira antes de publicar.",
      ),
    );
  }
  if (a === "r-bindings") return show(i, await V.roleBindings(i.guild, id));
  if (a === "r-toggle") {
    const p = await R.panel(i.guild.id, id);
    if (p.status === "PAUSED") {
      const check = await R.inspect(i.guild, id);
      assert(!check.problems.length, check.problems.join("\n"));
    }
    await R.pause(i.guild.id, id, p.status !== "PAUSED");
    return show(
      i,
      await V.roleDetail(
        i.guild,
        id,
        "Estado alterado. Os cargos existentes foram preservados.",
      ),
    );
  }
  if (a === "r-add") {
    const p = await R.panel(i.guild.id, id);
    assert(
      p.revision === Number(revision),
      "O painel mudou. Abra novamente a configuração.",
    );
    return show(i, {
      embeds: [
        new D.EmbedBuilder()
          .setColor(0xd71935)
          .setTitle("Escolha o cargo da reação")
          .setDescription(
            "Na próxima etapa, informe o emoji. Cargos com permissões administrativas não são aceitos.",
          ),
      ],
      components: [
        row(
          new D.RoleSelectMenuBuilder()
            .setCustomId("maker-select:r-role:" + p.id + ":" + p.revision)
            .setPlaceholder("Cargo oferecido aos membros")
            .setMinValues(1)
            .setMaxValues(1),
        ),
        row(button("r-bindings:" + p.id, "Voltar")),
      ],
    });
  }
  if (a === "r-publish") {
    const p = await R.panel(i.guild.id, id);
    assert(
      p.revision === Number(revision),
      "O painel mudou. Confira a versão atual.",
    );
    assert(p.channelId, "Defina o canal do painel.");
    const list = await R.bindings(i.guild.id, id);
    assert(list.length > 0, "Adicione pelo menos uma reação.");
    render(R.withLegend(parse(p.documentJson), list, p.removeOnUnreact));
    const op = await action(i, "ROLE_PUBLISH", id, {
      panelId: id,
      revision: p.revision,
      channelId: p.channelId,
    });
    return show(i, await V.confirmation(i.guild, op));
  }
  if (a === "r-retire-keep" || a === "r-retire-revoke") {
    const b = await prisma.reactionRoleBinding.findFirst({
      where: { id, guildId: i.guild.id, active: true },
    });
    assert(b, "Associação indisponível.");
    const count = await prisma.reactionRoleGrant.count({
      where: { guildId: i.guild.id, bindingId: id, active: true },
    });
    const op = await action(
      i,
      a === "r-retire-keep" ? "BINDING_KEEP" : "BINDING_REVOKE",
      id,
      { panelId: b.panelId, count },
    );
    return show(i, await V.confirmation(i.guild, op));
  }
  if (a === "r-revoke-batch") {
    const b = await prisma.reactionRoleBinding.findFirst({
      where: { id, guildId: i.guild.id },
    });
    assert(b, "Associação indisponível.");
    const result = await R.revokeBatch(i.guild, id);
    return show(
      i,
      await V.roleDetail(
        i.guild,
        b.panelId,
        "Retiradas processadas: " +
          result.processed +
          " · Falhas: " +
          result.failed +
          " · Pendentes: " +
          result.remaining +
          ". Consulte Reações e cargos para continuar.",
      ),
    );
  }
  if (a === "r-inspect") return show(i, await V.roleInspect(i.guild, id));
  if (a === "r-sync") {
    const plan = await R.planSync(i.guild, id),
      op = await action(i, "SYNC", id, plan);
    return show(i, await V.confirmation(i.guild, op));
  }
  return false;
}
export async function selects(i: any, parts: string[]) {
  const [a, id, revision] = parts,
    value = i.values[0];
  if (a === "r-panel") return show(i, await V.roleDetail(i.guild, value));
  if (a === "r-task") {
    const p = await R.panel(i.guild.id, id);
    if (value === "message")
      return show(
        i,
        await V.editor(i.guild, await S.start(i, { panelId: id })),
      );
    if (value === "bindings") return show(i, await V.roleBindings(i.guild, id));
    if (value === "inspect") return show(i, await V.roleInspect(i.guild, id));
    if (value === "channel")
      return show(i, {
        embeds: [
          new D.EmbedBuilder()
            .setColor(0xd71935)
            .setTitle("Canal do painel")
            .setDescription(
              p.publicationId
                ? "O canal de uma publicação permanece fixo. Use Duplicar painel para escolher outro destino."
                : "Escolha um canal deste servidor. A mensagem será enviada somente ao publicar.",
            ),
        ],
        components: [
          row(
            new D.ChannelSelectMenuBuilder()
              .setCustomId("maker-select:r-channel:" + id + ":" + p.revision)
              .setPlaceholder("Canal das reações")
              .addChannelTypes(
                D.ChannelType.GuildText,
                D.ChannelType.GuildAnnouncement,
              )
              .setDisabled(!!p.publicationId),
          ),
          row(button("r-detail:" + id, "Voltar")),
        ],
      });
    if (value === "rule")
      return show(i, {
        embeds: [
          new D.EmbedBuilder()
            .setColor(0xd71935)
            .setTitle("Ao retirar a reação")
            .setDescription(
              "A regra salva será aplicada após Publicar / atualizar. As concessões anteriores permanecem registradas.",
            ),
        ],
        components: [
          select("r-rule:" + id + ":" + p.revision, "Escolha o comportamento", [
            { value: "remove", label: "Remover a concessão deste painel" },
            { value: "keep", label: "Preservar o cargo" },
          ]),
          row(button("r-detail:" + id, "Voltar")),
        ],
      });
  }
  if (a === "r-channel" || a === "r-rule") {
    const p = await R.panel(i.guild.id, id);
    assert(
      p.revision === Number(revision),
      "A configuração mudou. Abra novamente.",
    );
    let data: any;
    if (a === "r-channel") {
      assert(
        !p.publicationId,
        "O painel já tem um destino publicado. Duplique para mudar de canal.",
      );
      await S.channel(i.guild, value, true);
      data = { channelId: value };
    } else {
      assert(["remove", "keep"].includes(value), "Escolha uma regra válida.");
      data = { removeOnUnreact: value === "remove" };
    }
    const r = await prisma.reactionRolePanel.updateMany({
      where: { id, guildId: i.guild.id, revision: p.revision },
      data: { ...data, revision: { increment: 1 } },
    });
    assert(r.count === 1, "O painel mudou. Abra novamente.");
    return show(
      i,
      await V.roleDetail(
        i.guild,
        id,
        "Configuração salva. Publique para aplicar a regra à mensagem.",
      ),
    );
  }
  if (a === "r-role") {
    const p = await R.panel(i.guild.id, id);
    assert(p.revision === Number(revision), "O painel mudou. Abra novamente.");
    const role = await R.safeRole(i.guild, value),
      op = await action(i, "BINDING_FORM", p.id, {
        roleId: role.id,
        revision: p.revision,
      });
    return i.showModal(
      form("binding:" + op.id, "Reação para " + role.name.slice(0, 30), [
        { id: "emoji", label: "Emoji — exemplo 🎮 ou <:nome:id>", max: 80 },
      ]),
    );
  }
  if (a === "r-binding") {
    const p = await R.panel(i.guild.id, id),
      b = await prisma.reactionRoleBinding.findFirst({
        where: { id: value, guildId: i.guild.id, panelId: p.id, active: true },
      });
    assert(b, "Associação indisponível.");
    const count = await prisma.reactionRoleGrant.count({
      where: { guildId: i.guild.id, bindingId: b.id, active: true },
    });
    return show(i, {
      embeds: [
        new D.EmbedBuilder()
          .setColor(0xd71935)
          .setTitle("Gerenciar associação")
          .setDescription(
            b.emojiDisplay +
              " → <@&" +
              b.roleId +
              ">\nConcessões rastreadas: " +
              count +
              "\n\nPara trocar o emoji ou o cargo, desative a associação e crie outra. Escolha o que fazer com as concessões anteriores.",
          ),
      ],
      components: [
        row(
          button("r-retire-keep:" + b.id, "Desativar e preservar cargos"),
          button("r-retire-revoke:" + b.id, "Desativar e revisar retiradas", 4),
        ),
        row(button("r-bindings:" + id, "Voltar")),
      ],
    });
  }
  return false;
}
export async function modals(i: any, parts: string[]) {
  const [a, id] = parts;
  if (a !== "binding") return false;
  const op = await getAction(i, id, true);
  assert(op.kind === "BINDING_FORM", "Formulário inválido.");
  const data = JSON.parse(op.payloadJson),
    p = await R.panel(i.guild.id, op.targetId);
  assert(
    p.revision === data.revision,
    "O painel mudou. Abra novamente a associação.",
  );
  await R.addBinding(
    i.guild,
    p.id,
    data.roleId,
    i.fields.getTextInputValue("emoji"),
    data.revision,
  );
  return show(i, await V.roleBindings(i.guild, p.id));
}
