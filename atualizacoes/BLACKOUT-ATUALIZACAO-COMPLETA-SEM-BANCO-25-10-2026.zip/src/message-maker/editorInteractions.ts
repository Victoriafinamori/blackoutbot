import {
  D,
  prisma,
  assert,
  row,
  button,
  select,
  form,
  session,
  show,
  action,
  getAction,
  clean,
} from "./common";
import {
  Block,
  Document,
  uid,
  copy,
  parse,
  render,
  MakerError,
} from "./document";
import * as S from "./service";
import * as V from "./views";
import * as R from "./roles";
const textField = (text: string) => ({
  id: "text",
  label: "Conteúdo",
  value: text,
  max: 3500,
  paragraph: true,
});
export async function openBlock(i: any, s: any, blockId: string) {
  const b = parse(s.documentJson).blocks.find((b) => b.id === blockId);
  assert(b, "O bloco não está disponível.");
  const id = "block:" + s.id + ":" + s.revision + ":" + b.id;
  if (b.type === "separator")
    return show(i, await V.organize(i.guild, s, b.id));
  if (b.type === "buttons") return show(i, await V.buttons(i.guild, s, b.id));
  if (b.type === "gallery")
    return i.showModal(
      form(id, "Editar galeria", [
        {
          id: "images",
          label: "Links das imagens — um por linha",
          value: b.images!.join("\n"),
          max: 3500,
          paragraph: true,
        },
      ]),
    );
  if (b.type === "section")
    return i.showModal(
      form(id, "Texto e miniatura", [
        textField(b.text!),
        {
          id: "thumbnail",
          label: "Link da miniatura",
          value: b.thumbnail,
          max: 1000,
        },
      ]),
    );
  return i.showModal(
    form(id, b.type === "heading" ? "Editar título" : "Editar texto", [
      {
        ...textField(b.text!),
        label:
          b.type === "heading"
            ? "Título"
            : "Texto — use **texto** para destacar",
        max: b.type === "heading" ? 256 : 3500,
        paragraph: b.type !== "heading",
      },
    ]),
  );
}
export async function reviewPublish(i: any, s: any) {
  render(s.documentJson);
  if (s.panelId) {
    await S.save(i, s.id, s.revision);
    return show(
      i,
      await V.roleDetail(
        i.guild,
        s.panelId,
        "Rascunho salvo. Confira as associações e escolha Publicar / atualizar.",
      ),
    );
  }
  assert(s.destinationChannelId, "Escolha o canal de destino.");
  await S.channel(i.guild, s.destinationChannelId);
  const a = await action(i, "PUBLISH", s.publicationId, {
    sessionId: s.id,
    revision: s.revision,
    documentJson: s.documentJson,
    name: s.name,
    channelId: s.destinationChannelId,
    publicationId: s.publicationId,
  });
  return show(i, await V.confirmation(i.guild, a));
}
export async function buttonAction(i: any, parts: string[]) {
  const [a, id, rev, blockId, itemId] = parts;
  if (a === "home") return show(i, await V.home(i.guild));
  if (a === "templates") return show(i, await V.templates(i.guild, Number(id)));
  if (a === "publications")
    return show(i, await V.publications(i.guild, Number(id)));
  if (a === "create") return show(i, await V.editor(i.guild, await S.start(i)));
  if (a === "pub")
    return show(i, await V.publicationView(i.guild, id, Number(rev)));
  if (a === "pub-edit") {
    const p = await S.publication(i.guild.id, id);
    if (p.panelId) return show(i, await V.roleDetail(i.guild, p.panelId));
    return show(
      i,
      await V.editor(i.guild, await S.start(i, { publicationId: id })),
    );
  }
  if (a === "pub-copy") {
    const p = await S.publication(i.guild.id, id);
    return show(
      i,
      await V.editor(
        i.guild,
        await S.start(i, {
          document: parse(p.snapshotJson),
          name: p.name + " · Cópia",
        }),
      ),
    );
  }
  if (a === "pub-check") {
    await S.verifyPublication(i.guild, id);
    return show(i, await V.publicationView(i.guild, id));
  }
  if (a === "pub-delete") {
    const p = await S.publication(i.guild.id, id);
    assert(!p.panelId, "Gerencie esse painel em Cargos por reação.");
    const op = await action(i, "PUB_DELETE", p.id, {
      name: p.name,
      channelId: p.channelId,
      revision: p.revision,
    });
    return show(i, await V.confirmation(i.guild, op));
  }
  if (a === "pub-register") {
    const p = await S.publication(i.guild.id, id);
    assert(!p.messageId, "Esta publicação já tem uma mensagem registrada.");
    const op = await action(i, "REGISTER", p.id, {});
    return i.showModal(
      form("register:" + op.id, "Confirmar mensagem já enviada", [
        { id: "message", label: "ID da mensagem enviada no canal", max: 22 },
      ]),
    );
  }
  if (a === "edit")
    return show(i, await V.editor(i.guild, await session(i, id), Number(rev)));
  if (a === "preview")
    return show(
      i,
      await V.editor(i.guild, await session(i, id, rev), Number(blockId), true),
    );
  if (a === "add")
    return show(i, await V.addTypes(i.guild, await session(i, id, rev)));
  if (a === "organize")
    return show(
      i,
      await V.organize(i.guild, await session(i, id, rev), blockId),
    );
  if (a === "appearance") {
    const s = await session(i, id, rev),
      doc = parse(s.documentJson);
    return i.showModal(
      form("appearance:" + id + ":" + rev, "Nome e cor da mensagem", [
        { id: "name", label: "Nome interno do modelo", value: s.name, max: 80 },
        {
          id: "color",
          label: "Cor hexadecimal — exemplo D71935",
          value: doc.color,
          max: 7,
        },
      ]),
    );
  }
  if (["up", "down", "remove", "duplicate"].includes(a)) {
    const s = await S.change(i, id, rev, (d) => {
      const n = d.blocks.findIndex((b) => b.id === blockId);
      assert(n >= 0, "Bloco indisponível.");
      if (a === "remove") {
        assert(d.blocks.length > 1, "Mantenha pelo menos um bloco.");
        d.blocks.splice(n, 1);
      }
      if (a === "duplicate") {
        const b = copy(d.blocks[n]);
        b.id = uid();
        if (b.buttons) b.buttons = b.buttons.map((v) => ({ ...v, id: uid() }));
        d.blocks.splice(n + 1, 0, b);
      }
      if (a === "up" || a === "down") {
        const next = n + (a === "up" ? -1 : 1);
        assert(
          next >= 0 && next < d.blocks.length,
          "O bloco já está no limite.",
        );
        [d.blocks[n], d.blocks[next]] = [d.blocks[next], d.blocks[n]];
      }
    });
    return show(
      i,
      await V.editor(
        i.guild,
        s,
        0,
        false,
        "Ordem ou conteúdo atualizado. A publicação continua como estava.",
      ),
    );
  }
  if (a === "undo") {
    const s = await session(i, id, rev);
    assert(s.undoJson, "Não há edição anterior para desfazer.");
    const old = JSON.parse(s.undoJson),
      next = await S.change(i, id, rev, (d, current) => {
        Object.assign(d, parse(old.documentJson));
        current.name = old.name;
      });
    await prisma.makerSession.update({
      where: { id },
      data: { undoJson: null },
    });
    return show(
      i,
      await V.editor(i.guild, next, 0, false, "Última edição desfeita."),
    );
  }
  if (a === "save") {
    const s = await S.save(i, id, rev);
    return show(
      i,
      await V.editor(
        i.guild,
        s,
        0,
        false,
        s.panelId
          ? "Rascunho do painel salvo. A publicação não foi alterada."
          : "Modelo salvo. Os envios anteriores foram preservados.",
      ),
    );
  }
  if (a === "publish") {
    const s = await session(i, id, rev);
    if (s.panelId || s.publicationId) return reviewPublish(i, s);
    return show(i, await V.destination(i.guild, s));
  }
  if (a === "review") return reviewPublish(i, await session(i, id, rev));
  if (a === "more") {
    const s = await session(i, id, rev);
    return show(i, {
      embeds: [
        new D.EmbedBuilder()
          .setColor(0xd71935)
          .setTitle("Mais opções · " + clean(s.name, 60))
          .setDescription(
            "Uma cópia tem conteúdo independente. Excluir um modelo preserva as publicações.",
          ),
      ],
      components: [
        row(
          button("copy:" + id + ":" + rev, "Salvar uma cópia"),
          button(
            "delete-template:" + id + ":" + rev,
            "Excluir modelo",
            4,
            !s.templateId || !!s.publicationId,
          ),
        ),
        row(
          button("templates:0", "Modelos salvos"),
          button("publications:0", "Mensagens enviadas"),
          button("edit:" + id, "Voltar"),
        ),
      ],
    });
  }
  if (a === "copy") {
    const s = await session(i, id, rev),
      t = await prisma.makerTemplate.create({
        data: {
          id: uid(),
          guildId: i.guild.id,
          name: (s.name + " · Cópia").slice(0, 80),
          documentJson: s.documentJson,
          createdById: i.user.id,
        },
      });
    return show(
      i,
      await V.editor(i.guild, await S.start(i, { templateId: t.id })),
    );
  }
  if (a === "delete-template") {
    const s = await session(i, id, rev);
    assert(s.templateId && !s.publicationId, "Escolha um modelo salvo.");
    const t = await prisma.makerTemplate.findFirst({
      where: { id: s.templateId, guildId: i.guild.id, deletedAt: null },
    });
    assert(t, "Modelo indisponível.");
    return show(
      i,
      await V.confirmation(
        i.guild,
        await action(i, "TEMPLATE_DELETE", t.id, {
          name: t.name,
          revision: t.revision,
        }),
      ),
    );
  }
  if (a === "copy-role") {
    const s = await session(i, id, rev);
    assert(!s.panelId, "Esta mensagem já pertence a um painel.");
    const p = await R.create(
      i.guild.id,
      i.user.id,
      parse(s.documentJson),
      s.name,
    );
    return show(
      i,
      await V.roleDetail(
        i.guild,
        p.id,
        "Mensagem copiada para um novo painel. O modelo e as publicações anteriores foram preservados.",
      ),
    );
  }
  if (a === "link" || a === "button-edit") {
    const s = await session(i, id, rev),
      b = parse(s.documentJson).blocks.find((v) => v.id === blockId);
    assert(b?.type === "buttons", "Bloco de botões indisponível.");
    const item = b.buttons!.find((v) => v.id === itemId);
    if (a === "button-edit") assert(item, "Botão indisponível.");
    return i.showModal(
      form(
        "link:" + id + ":" + rev + ":" + blockId + ":" + (itemId || "new"),
        "Botão de link",
        [
          { id: "label", label: "Texto do botão", value: item?.label, max: 80 },
          {
            id: "url",
            label: "Link http:// ou https://",
            value: item?.url,
            max: 1000,
          },
          {
            id: "emoji",
            label: "Emoji opcional — vazio para remover",
            value: item?.emoji,
            max: 60,
            required: false,
          },
        ],
      ),
    );
  }
  if (a === "channel-button") {
    const s = await session(i, id, rev);
    return show(i, {
      embeds: [
        new D.EmbedBuilder()
          .setColor(0xd71935)
          .setTitle("Botão para canal")
          .setDescription(
            "Escolha um canal deste servidor. Depois defina o texto do botão.",
          ),
      ],
      components: [
        row(
          new D.ChannelSelectMenuBuilder()
            .setCustomId(
              "maker-select:button-channel:" + id + ":" + rev + ":" + blockId,
            )
            .setPlaceholder("Canal do botão")
            .addChannelTypes(
              D.ChannelType.GuildText,
              D.ChannelType.GuildAnnouncement,
              D.ChannelType.GuildForum,
              D.ChannelType.GuildVoice,
            ),
        ),
        row(button("edit:" + id, "Voltar ao editor")),
      ],
    });
  }
  if (["button-remove", "button-up", "button-down"].includes(a)) {
    const s = await S.change(i, id, rev, (doc) => {
      const b = doc.blocks.find((v) => v.id === blockId);
      assert(b?.buttons, "Bloco indisponível.");
      const n = b.buttons.findIndex((v) => v.id === itemId);
      assert(n >= 0, "Botão indisponível.");
      if (a === "button-remove") {
        if (b.buttons.length === 1) doc.blocks.splice(doc.blocks.indexOf(b), 1);
        else b.buttons.splice(n, 1);
      } else {
        const next = n + (a === "button-up" ? -1 : 1);
        assert(
          next >= 0 && next < b.buttons.length,
          "O botão já está no limite.",
        );
        [b.buttons[n], b.buttons[next]] = [b.buttons[next], b.buttons[n]];
      }
    });
    return show(i, await V.editor(i.guild, s));
  }
  return false;
}
export async function selectAction(i: any, parts: string[]) {
  const [a, id, rev, blockId] = parts,
    value = i.values[0];
  if (a === "home") {
    if (value === "create")
      return show(i, await V.editor(i.guild, await S.start(i)));
    if (value === "templates") return show(i, await V.templates(i.guild));
    if (value === "publications") return show(i, await V.publications(i.guild));
  }
  if (a === "template")
    return show(
      i,
      await V.editor(i.guild, await S.start(i, { templateId: value })),
    );
  if (a === "publication")
    return show(i, await V.publicationView(i.guild, value));
  if (a === "block") return openBlock(i, await session(i, id, rev), value);
  if (a === "organize")
    return show(i, await V.organize(i.guild, await session(i, id, rev), value));
  if (a === "add") {
    const s = await session(i, id, rev);
    if (value === "separator") {
      const next = await S.change(i, id, rev, (d) =>
        d.blocks.push({ id: uid(), type: "separator" }),
      );
      return show(i, await V.editor(i.guild, next));
    }
    if (value === "buttons")
      return i.showModal(
        form("newbutton:" + id + ":" + rev, "Primeiro botão do bloco", [
          { id: "label", label: "Texto do botão", max: 80 },
          { id: "url", label: "Link http:// ou https://", max: 1000 },
        ]),
      );
    if (value === "gallery")
      return i.showModal(
        form("addblock:" + id + ":" + rev + ":gallery", "Adicionar galeria", [
          {
            id: "images",
            label: "Links das imagens — um por linha",
            paragraph: true,
            max: 3500,
          },
        ]),
      );
    assert(
      ["text", "heading", "section"].includes(value),
      "Tipo de bloco inválido.",
    );
    return i.showModal(
      form(
        "addblock:" + id + ":" + rev + ":" + value,
        "Adicionar " + (value === "heading" ? "título" : "texto"),
        [
          { ...textField(""), max: value === "heading" ? 256 : 3500 },
          ...(value === "section"
            ? [{ id: "thumbnail", label: "Link da miniatura", max: 1000 }]
            : []),
        ],
      ),
    );
  }
  if (a === "button")
    return show(
      i,
      await V.buttons(i.guild, await session(i, id, rev), blockId, value),
    );
  if (a === "button-channel") {
    await session(i, id, rev);
    const ch = await i.guild.channels.fetch(value).catch(() => null);
    assert(ch?.guildId === i.guild.id, "Escolha um canal deste servidor.");
    const op = await action(i, "BUTTON_CHANNEL", id, {
      sessionId: id,
      revision: Number(rev),
      blockId,
      channelId: ch.id,
    });
    return i.showModal(
      form("channel-button:" + op.id, "Texto do botão de canal", [
        { id: "label", label: "Texto do botão", value: ch.name, max: 80 },
        { id: "emoji", label: "Emoji opcional", required: false, max: 60 },
      ]),
    );
  }
  if (a === "destination") {
    const s = await session(i, id, rev);
    await S.channel(i.guild, value);
    assert(
      !s.publicationId && !s.panelId,
      "O destino de uma publicação existente permanece fixo. Crie uma cópia para mudar de canal.",
    );
    const r = await prisma.makerSession.updateMany({
      where: { id, revision: s.revision },
      data: { destinationChannelId: value, revision: { increment: 1 } },
    });
    assert(r.count === 1, "A edição mudou. Abra novamente.");
    return show(i, await V.destination(i.guild, await session(i, id)));
  }
  return false;
}
export async function modalAction(i: any, parts: string[]) {
  const [a, id, rev, blockId, itemId] = parts,
    value = (name: string) => i.fields.getTextInputValue(name).trim();
  if (a === "appearance") {
    const s = await S.change(i, id, rev, (d, s) => {
      d.color = value("color").replace(/^#/, "").toUpperCase();
      s.name = value("name");
    });
    return show(i, await V.editor(i.guild, s));
  }
  if (a === "block" || a === "addblock") {
    const s = await S.change(i, id, rev, (d) => {
      const b =
        a === "block"
          ? d.blocks.find((b) => b.id === blockId)
          : ({ id: uid(), type: blockId } as Block);
      assert(
        b && ["text", "heading", "section", "gallery"].includes(b.type),
        "Bloco indisponível.",
      );
      if (b.type === "gallery")
        b.images = value("images")
          .split(/\r?\n/)
          .map((v: string) => v.trim())
          .filter(Boolean);
      else {
        b.text = value("text");
        if (b.type === "section") b.thumbnail = value("thumbnail");
      }
      if (a === "addblock") d.blocks.push(b);
    });
    return show(i, await V.editor(i.guild, s));
  }
  if (a === "newbutton" || a === "link") {
    const s = await S.change(i, id, rev, (d) => {
      if (a === "newbutton") {
        d.blocks.push({
          id: uid(),
          type: "buttons",
          buttons: [{ id: uid(), label: value("label"), url: value("url") }],
        });
        return;
      }
      const b = d.blocks.find((b) => b.id === blockId);
      assert(b?.type === "buttons", "Bloco indisponível.");
      const data = {
        label: value("label"),
        url: value("url"),
        emoji: value("emoji") || undefined,
      };
      if (itemId === "new") {
        assert(b.buttons!.length < 5, "O bloco já tem cinco botões.");
        b.buttons!.push({ id: uid(), ...data });
      } else {
        const item = b.buttons!.find((v) => v.id === itemId);
        assert(item, "Botão indisponível.");
        Object.assign(item, data);
      }
    });
    return show(i, await V.editor(i.guild, s));
  }
  if (a === "channel-button") {
    const op = await getAction(i, id, true),
      data = JSON.parse(op.payloadJson);
    assert(op.kind === "BUTTON_CHANNEL", "Formulário inválido.");
    const ch = await i.guild.channels.fetch(data.channelId).catch(() => null);
    assert(ch?.guildId === i.guild.id, "Canal indisponível.");
    const s = await S.change(i, data.sessionId, data.revision, (d) => {
      const b = d.blocks.find((v) => v.id === data.blockId);
      assert(
        b?.buttons && b.buttons.length < 5,
        "Bloco de botões indisponível ou cheio.",
      );
      b.buttons.push({
        id: uid(),
        label: value("label"),
        url: "https://discord.com/channels/" + i.guild.id + "/" + ch.id,
        emoji: value("emoji") || undefined,
      });
    });
    return show(i, await V.editor(i.guild, s));
  }
  return false;
}
