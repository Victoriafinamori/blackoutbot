import { prisma, assert, exclusive, session, uid, D } from "./common";
import {
  Document,
  blank,
  copy,
  parse,
  render,
  legacy,
  hash,
  MakerError,
} from "./document";
import { writableChannel } from "../utils/configurationChecks";
export async function importLegacy(guildId: string) {
  return exclusive("maker-import:" + guildId, async () => {
    const records = await prisma.customEmbed.findMany({
      where: { guildId },
      include: { buttons: { orderBy: { position: "asc" } } },
    });
    for (const r of records) {
      const documentJson = JSON.stringify(legacy(r, guildId));
      const t = await prisma.makerTemplate.upsert({
        where: { legacyId: r.id },
        create: {
          id: uid(),
          guildId,
          legacyId: r.id,
          name: r.name,
          documentJson,
          createdById: r.createdById,
        },
        update: {},
      });
      if (r.publishedMessageId && r.publishedChannelId)
        await prisma.makerPublication.upsert({
          where: { messageId: r.publishedMessageId },
          create: {
            id: uid(),
            guildId,
            templateId: t.id,
            channelId: r.publishedChannelId,
            messageId: r.publishedMessageId,
            name: r.name,
            snapshotJson: documentJson,
            status: "LEGACY",
            legacy: true,
            createdById: r.createdById,
            lastError:
              "Prévia de conversão do modelo antigo. Confira a mensagem original antes de atualizar.",
          },
          update: {},
        });
    }
  });
}
export async function start(
  i: any,
  options: {
    templateId?: string;
    publicationId?: string;
    panelId?: string;
    document?: Document;
    name?: string;
    fresh?: boolean;
  } = {},
) {
  let doc = options.document || blank(),
    name = options.name || "Nova mensagem",
    t: any = null,
    p: any = null,
    panel: any = null;
  if (options.templateId) {
    t = await prisma.makerTemplate.findFirst({
      where: { id: options.templateId, guildId: i.guild.id, deletedAt: null },
    });
    assert(t, "Este modelo não está disponível neste servidor.");
    doc = parse(t.documentJson);
    name = t.name;
  }
  if (options.publicationId) {
    p = await publication(i.guild.id, options.publicationId);
    assert(
      p.messageId,
      "O envio ainda não possui mensagem confirmada. Confira o canal antes de criar outro.",
    );
    doc = parse(p.snapshotJson);
    name = p.name;
    if (p.panelId) options.panelId = p.panelId;
  }
  if (options.panelId) {
    panel = await prisma.reactionRolePanel.findFirst({
      where: { id: options.panelId, guildId: i.guild.id },
    });
    assert(panel, "O painel de cargos não pertence a este servidor.");
    doc = parse(panel.documentJson);
    name = panel.name;
  }
  if (!options.fresh && (t || p || panel)) {
    const existing = await prisma.makerSession.findFirst({
      where: {
        guildId: i.guild.id,
        actorId: i.user.id,
        sourceMessageId: i.message.id,
        expiresAt: { gt: new Date() },
        ...(panel
          ? { panelId: panel.id, panelRevision: panel.revision }
          : p
            ? {
                publicationId: p.id,
                publicationRevision: p.revision,
                panelId: null,
              }
            : {
                templateId: t.id,
                templateRevision: t.revision,
                publicationId: null,
                panelId: null,
              }),
      },
      orderBy: { updatedAt: "desc" },
    });
    if (existing) return existing;
  }
  await prisma.makerSession.deleteMany({
    where: {
      guildId: i.guild.id,
      actorId: i.user.id,
      expiresAt: { lt: new Date() },
    },
  });
  return prisma.makerSession.create({
    data: {
      id: uid(),
      guildId: i.guild.id,
      actorId: i.user.id,
      sourceMessageId: i.message.id,
      name: name.slice(0, 80),
      documentJson: JSON.stringify(doc),
      templateId: t?.id || null,
      templateRevision: t?.revision ?? null,
      publicationId: panel ? null : p?.id || null,
      publicationRevision: panel ? null : (p?.revision ?? null),
      panelId: panel?.id || null,
      panelRevision: panel?.revision ?? null,
      destinationChannelId: panel?.channelId || p?.channelId || null,
      expiresAt: new Date(Date.now() + 86400000),
    },
  });
}
export async function change(
  i: any,
  id: string,
  revision: number | string,
  fn: (doc: Document, s: any) => void,
) {
  return exclusive("maker-session:" + id, async () => {
    const s = await session(i, id, revision),
      doc = parse(s.documentJson),
      old = JSON.stringify({ documentJson: s.documentJson, name: s.name });
    fn(doc, s);
    parse(doc);
    assert(
      doc.blocks.length <= 25,
      "Use até 25 blocos editáveis; remova um bloco antes de adicionar outro.",
    );
    assert(
      s.name?.trim() && s.name.length <= 80,
      "O nome interno precisa ter de 1 a 80 caracteres.",
    );
    const r = await prisma.makerSession.updateMany({
      where: { id, revision: s.revision },
      data: {
        documentJson: JSON.stringify(doc),
        name: s.name,
        undoJson: old,
        revision: { increment: 1 },
        expiresAt: new Date(Date.now() + 86400000),
      },
    });
    assert(r.count === 1, "O rascunho mudou. Abra novamente o editor.");
    return session(i, id);
  });
}
export async function save(i: any, id: string, rev: string | number) {
  return exclusive("maker-session:" + id, async () => {
    const s = await session(i, id, rev);
    if (s.panelId) {
      const panel = await prisma.reactionRolePanel.findFirst({
        where: { id: s.panelId, guildId: i.guild.id },
      });
      assert(panel, "Painel indisponível.");
      const changed = await prisma.reactionRolePanel.updateMany({
        where: { id: panel.id, guildId: i.guild.id, revision: s.panelRevision },
        data: {
          name: s.name,
          documentJson: s.documentJson,
          revision: { increment: 1 },
        },
      });
      assert(
        changed.count === 1,
        "O painel mudou em outra edição. Reabra a mensagem pelo painel para conferir.",
      );
      await prisma.makerSession.update({
        where: { id },
        data: { panelRevision: s.panelRevision + 1 },
      });
      return session(i, id);
    }
    if (s.templateId && !s.publicationId) {
      const r = await prisma.makerTemplate.updateMany({
        where: {
          id: s.templateId,
          guildId: i.guild.id,
          deletedAt: null,
          revision: s.templateRevision,
        },
        data: {
          name: s.name,
          documentJson: s.documentJson,
          revision: { increment: 1 },
        },
      });
      assert(
        r.count === 1,
        "O modelo foi alterado em outra edição. Salve uma cópia para preservar este rascunho.",
      );
      await prisma.makerSession.update({
        where: { id },
        data: { templateRevision: s.templateRevision + 1 },
      });
    } else {
      const t = await prisma.makerTemplate.create({
        data: {
          id: uid(),
          guildId: i.guild.id,
          name: s.name,
          documentJson: s.documentJson,
          createdById: i.user.id,
        },
      });
      if (!s.publicationId)
        await prisma.makerSession.update({
          where: { id },
          data: { templateId: t.id, templateRevision: t.revision },
        });
    }
    return session(i, id);
  });
}
export async function publication(guildId: string, id: string) {
  const p = await prisma.makerPublication.findFirst({ where: { id, guildId } });
  assert(p, "Esta publicação não pertence a este servidor.");
  return p;
}
export async function channel(guild: any, id: string, reactions = false) {
  const result = await writableChannel(guild, id, false);
  assert(!result.issue, result.issue || "Canal indisponível.");
  const ch: any = result.channel,
    me = guild.members.me || (await guild.members.fetchMe());
  assert(
    ch.permissionsFor(me)?.has(D.PermissionFlagsBits.ReadMessageHistory),
    "O bot precisa da permissão Ler histórico de mensagens para gerenciar a publicação.",
  );
  if (reactions)
    assert(
      ch
        .permissionsFor(me)
        ?.has([
          D.PermissionFlagsBits.AddReactions,
          D.PermissionFlagsBits.ManageRoles,
        ]),
      "O bot precisa de Adicionar reações e Gerenciar cargos para ativar este painel.",
    );
  return ch;
}
export async function fetchMessage(guild: any, p: any) {
  const ch = await channel(guild, p.channelId);
  assert(
    p.messageId,
    "A entrega não foi confirmada. Confira o canal antes de publicar novamente.",
  );
  let message: any;
  try {
    message = await ch.messages.fetch(p.messageId);
  } catch (error: any) {
    if (error?.code === 10008) {
      await prisma.makerPublication.update({
        where: { id: p.id },
        data: { status: "MISSING", lastError: "Mensagem apagada." },
      });
      throw new MakerError(
        "A mensagem foi apagada. Use Publicar uma cópia para criar outro envio.",
      );
    }
    await prisma.makerPublication.update({
      where: { id: p.id },
      data: {
        status: "UNAVAILABLE",
        lastError:
          "Não foi possível acessar a mensagem. Confira as permissões.",
      },
    });
    throw new MakerError(
      "Não foi possível acessar esta mensagem. Confira as permissões; nenhum envio foi recriado.",
    );
  }
  assert(
    message &&
      message.author?.id === guild.client.user.id &&
      message.channelId === p.channelId,
    "A mensagem registrada não foi confirmada como uma publicação deste bot.",
  );
  return message;
}
export async function publishSession(i: any, s: any) {
  assert(!s.panelId, "Publique o painel pela área Cargos por reação.");
  const doc = parse(s.documentJson),
    payload = render(doc);
  assert(
    s.destinationChannelId,
    "Escolha o canal de destino antes de publicar.",
  );
  return exclusive("maker-publish:" + (s.publicationId || s.id), async () => {
    let p: any;
    if (s.publicationId) {
      p = await publication(i.guild.id, s.publicationId);
      assert(
        p.revision === s.publicationRevision,
        "Esta publicação mudou em outra edição. Reabra o envio para conferir a versão atual.",
      );
      assert(!p.panelId, "Use o gerenciamento próprio dos cargos por reação.");
      const message = await fetchMessage(i.guild, p);
      const claimed = await prisma.makerPublication.updateMany({
        where: { id: p.id, revision: p.revision },
        data: { status: "UPDATING", revision: { increment: 1 } },
      });
      assert(claimed.count === 1, "Outra atualização já está em andamento.");
      try {
        await message.edit({
          ...payload,
          content: null,
          embeds: [],
          attachments: [],
        });
        p = await prisma.makerPublication.update({
          where: { id: p.id },
          data: {
            name: s.name,
            snapshotJson: s.documentJson,
            payloadHash: hash(doc),
            status: "ACTIVE",
            legacy: false,
            lastError: null,
          },
        });
      } catch {
        await prisma.makerPublication.update({
          where: { id: p.id },
          data: {
            status: "UNCERTAIN",
            lastError:
              "Atualização não confirmada. Confira a mensagem original antes de repetir.",
          },
        });
        throw new MakerError(
          "Não foi possível confirmar a atualização. Consulte a mensagem original; nenhum novo envio foi criado.",
        );
      }
    } else {
      const ch = await channel(i.guild, s.destinationChannelId);
      p = await prisma.makerPublication.create({
        data: {
          id: uid(),
          guildId: i.guild.id,
          templateId: s.templateId,
          channelId: ch.id,
          name: s.name,
          snapshotJson: s.documentJson,
          createdById: i.user.id,
        },
      });
      // Bind before the API request: a consumed review cannot silently resend after uncertainty.
      await prisma.makerSession.update({
        where: { id: s.id },
        data: { publicationId: p.id, publicationRevision: p.revision },
      });
      let message: any;
      try {
        message = await ch.send(payload);
        p = await prisma.makerPublication.update({
          where: { id: p.id },
          data: {
            messageId: message.id,
            status: "ACTIVE",
            payloadHash: hash(doc),
          },
        });
      } catch {
        await prisma.makerPublication
          .update({
            where: { id: p.id },
            data: {
              messageId: message?.id || null,
              status: "UNCERTAIN",
              lastError:
                "Envio não confirmado. Confira o canal antes de enviar outra mensagem.",
            },
          })
          .catch(() => null);
        throw new MakerError(
          "Não foi possível confirmar o envio. Confira o canal e Mensagens enviadas antes de repetir.",
        );
      }
    }
    await prisma.makerSession.update({
      where: { id: s.id },
      data: {
        publicationId: p.id,
        publicationRevision: p.revision,
        templateId: null,
        templateRevision: null,
      },
    });
    return p;
  });
}
export async function verifyPublication(guild: any, id: string) {
  const p = await publication(guild.id, id);
  await fetchMessage(guild, p);
  if (!["LEGACY", "UNCERTAIN"].includes(p.status))
    await prisma.makerPublication.update({
      where: { id },
      data: { status: "ACTIVE", lastError: null },
    });
  return p;
}
