import * as D from "discord.js";
import { prisma as client } from "../database/prisma";
import { isBotAdmin } from "../utils/permissions";
import { deferPanel, refreshPanel } from "../utils/panelInteraction";
import { asComponentsV2 } from "../utils/componentMessages";
import { MakerError, assert, uid } from "./document";
export { D, MakerError, assert, uid };
export const prisma: any = client;
const queue = new Map<string, Promise<any>>();
export async function exclusive<T>(
  key: string,
  fn: () => Promise<T>,
): Promise<T> {
  const previous = queue.get(key) || Promise.resolve(),
    work = previous.catch(() => null).then(fn);
  queue.set(key, work);
  try {
    return await work;
  } finally {
    if (queue.get(key) === work) queue.delete(key);
  }
}
export const row = (...c: any[]) =>
  new D.ActionRowBuilder<any>().addComponents(c);
export const button = (
  id: string,
  label: string,
  style = D.ButtonStyle.Secondary,
  disabled = false,
) =>
  new D.ButtonBuilder()
    .setCustomId("maker:" + id)
    .setLabel(label)
    .setStyle(style)
    .setDisabled(disabled);
export const select = (
  id: string,
  placeholder: string,
  options: { value: string; label: string; description?: string }[],
) =>
  row(
    new D.StringSelectMenuBuilder()
      .setCustomId("maker-select:" + id)
      .setPlaceholder(placeholder)
      .addOptions(options),
  );
export function v2(p: any) {
  return {
    ...asComponentsV2(p),
    content: null,
    embeds: [],
    attachments: [],
    allowedMentions: { parse: [] },
  };
}
export async function show(i: any, p: any) {
  return refreshPanel(i, v2(p));
}
export { deferPanel };
export async function authorized(i: any) {
  assert(i.guild && i.message?.id, "Abra este painel no servidor com /adm.");
  const member = await i.guild.members.fetch(i.user.id);
  assert(
    await isBotAdmin(member),
    "Você não possui acesso para configurar este servidor.",
  );
}
export async function guard(i: any, fn: () => Promise<any>) {
  try {
    await authorized(i);
    return await fn();
  } catch (error: any) {
    if (!(error instanceof MakerError))
      console.error("[message-maker]", error?.code || error?.name || "falha");
    const p = {
      content:
        error instanceof MakerError
          ? error.message
          : "Não foi possível concluir. O rascunho permanece salvo; confira o painel antes de repetir.",
      flags: D.MessageFlags.Ephemeral,
    };
    if (i.deferred || i.replied) return i.followUp(p).catch(() => null);
    return i.reply(p).catch(() => null);
  }
}
export const clean = (value: string, n = 100) =>
  String(value || "")
    .replace(/[\r\n]/g, " ")
    .slice(0, n);
export function form(
  id: string,
  title: string,
  fields: {
    id: string;
    label: string;
    value?: string;
    max?: number;
    paragraph?: boolean;
    required?: boolean;
  }[],
) {
  return new D.ModalBuilder()
    .setCustomId("maker-form:" + id)
    .setTitle(title.slice(0, 45))
    .addComponents(
      ...fields.map((f) => {
        const input = new D.TextInputBuilder()
          .setCustomId(f.id)
          .setLabel(f.label)
          .setStyle(
            f.paragraph ? D.TextInputStyle.Paragraph : D.TextInputStyle.Short,
          )
          .setRequired(f.required !== false)
          .setMaxLength(f.max || 1000);
        if (f.value) input.setValue(f.value.slice(0, f.max || 1000));
        return row(input);
      }),
    );
}
export async function session(i: any, id: string, revision?: string | number) {
  const s = await prisma.makerSession.findUnique({ where: { id } });
  assert(
    s &&
      s.guildId === i.guild.id &&
      s.actorId === i.user.id &&
      s.sourceMessageId === i.message.id &&
      s.expiresAt > new Date(),
    "Esta edição expirou ou pertence a outro painel. Abra novamente em Mensagens salvas ou Mensagens enviadas.",
  );
  if (revision !== undefined)
    assert(
      s.revision === Number(revision),
      "O rascunho mudou depois que você abriu esta opção. Atualize o editor e tente novamente.",
    );
  return s;
}
export async function action(
  i: any,
  kind: string,
  targetId: string | null,
  data: any,
) {
  return prisma.makerAction.create({
    data: {
      id: uid(),
      guildId: i.guild.id,
      actorId: i.user.id,
      sourceMessageId: i.message.id,
      kind,
      targetId,
      payloadJson: JSON.stringify(data),
      expiresAt: new Date(Date.now() + 20 * 60000),
    },
  });
}
export async function getAction(i: any, id: string, consume = false) {
  const a = await prisma.makerAction.findUnique({ where: { id } });
  assert(
    a &&
      a.guildId === i.guild.id &&
      a.actorId === i.user.id &&
      a.sourceMessageId === i.message.id &&
      a.expiresAt > new Date(),
    "Esta confirmação expirou. Abra uma nova revisão.",
  );
  if (consume) {
    const r = await prisma.makerAction.updateMany({
      where: { id, usedAt: null, status: "READY" },
      data: { usedAt: new Date(), status: "RUNNING" },
    });
    assert(
      r.count === 1,
      "Esta confirmação já foi utilizada. Confira o resultado antes de repetir.",
    );
  }
  return a;
}
