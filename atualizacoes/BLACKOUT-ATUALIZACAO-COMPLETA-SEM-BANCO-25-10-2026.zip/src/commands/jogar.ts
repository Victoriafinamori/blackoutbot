import { SlashCommandBuilder, MessageFlags } from "discord.js";
import { Command } from "../structures/types";
import { guard, member } from "../games-chat/experience/common";
import { publicView, playView } from "../games-chat/experience/hub";
const command: Command = {
  data: new SlashCommandBuilder()
    .setName("jogar")
    .setDescription("Encontre os jogos e eventos da comunidade")
    .setDMPermission(false)
    .addStringOption((o) =>
      o
        .setName("jogo")
        .setDescription("Abrir um jogo diretamente")
        .addChoices(
          { name: "TERMO diário", value: "termo" },
          { name: "Bingo comunitário", value: "bingo" },
          { name: "Caixa Misteriosa", value: "mystery" },
          { name: "Quiz em equipes", value: "quiz" },
          { name: "Rankings do TERMO", value: "ranking" },
        ),
    ),
  async execute(i) {
    await guard(i, async () => {
      if (!i.guild) return;
      await member(i.guild, i.user.id);
      await i.deferReply({ flags: MessageFlags.Ephemeral });
      const choice = i.options.getString("jogo");
      await i.editReply(
        choice
          ? await playView(i.guild, i.user.id, choice)
          : await publicView(i.guild),
      );
    });
  },
};
export default command;
