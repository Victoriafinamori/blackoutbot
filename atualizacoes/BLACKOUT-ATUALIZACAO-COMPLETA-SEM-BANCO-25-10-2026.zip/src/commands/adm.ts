import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
} from "discord.js";
import { Command } from "../structures/types";
import { isBotAdmin } from "../utils/permissions";
import { buildAdmRootPanel } from "../utils/admPanel";
import { ensureAdmEmojis } from "../utils/admEmojis";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("adm")
    .setDescription("Abre o painel de moderação do bot")
    .setDMPermission(false) as SlashCommandBuilder,

  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.inGuild() || !interaction.guild) {
      await interaction.reply({
        content: "Esse comando só pode ser usado dentro de um servidor.",
        ephemeral: true,
      });
      return;
    }

    await interaction.deferReply({ ephemeral: true });
    const member = await interaction.guild.members.fetch(interaction.user.id);
    const authorized = await isBotAdmin(member);

    if (!authorized) {
      await interaction.editReply({
        content:
          "Você não tem permissão para acessar o painel administrativo.",
      });
      return;
    }

    await ensureAdmEmojis(interaction.guild);
    await interaction.editReply(await buildAdmRootPanel(interaction.guild, interaction.user));
  },
};

export default command;
