import { PermissionFlagsBits as P } from "discord.js";
import { Config, Rule, RULES } from "./config";
export async function missingForRule(guild: any, key: string, rule: Rule, c: Config) {
    const me = await guild.members.fetchMe(), problems: string[] = [], need = (bit: bigint, label: string) => {
        if (!me.permissions.has(bit))
            problems.push(label);
    };
    if (RULES[key].group === "team" || key === "moves")
        need(P.ViewAuditLog, "Ver Registro de Auditoria");
    if (rule.action === "KICK")
        need(P.KickMembers, "Expulsar Membros");
    if (rule.action === "TIMEOUT")
        need(P.ModerateMembers, "Moderar Membros");
    if (["DELETE", "TIMEOUT", "DELETE_WEBHOOK"].includes(rule.action) && RULES[key].group === "chat")
        need(P.ManageMessages, "Gerenciar Mensagens");
    if (rule.action === "DELETE_WEBHOOK")
        need(P.ManageWebhooks, "Gerenciar Webhooks");
    if (["REVOKE", "REVOKE_UNBAN", "RESTORE_REVOKE"].includes(rule.action) || rule.action === "RESTORE" && key === "roles")
        need(P.ManageRoles, "Gerenciar Cargos");
    if (rule.action === "REVOKE_UNBAN")
        need(P.BanMembers, "Banir Membros para reverter este ban");
    if (["RESTORE", "RESTORE_REVOKE"].includes(rule.action) && key === "punishments")
        need(P.ModerateMembers, "Moderar Membros para restaurar timeout");
    if (key === "honey" && !c.honeyChannel)
        problems.push("Escolher um canal-isca exclusivo");
    return problems;
}
export async function diagnose(guild: any, c: Config) {
    const lines: string[] = [];
    for (const [key, r] of Object.entries(c.rules))
        if (r.mode !== "OFF") {
            const missing = await missingForRule(guild, key, r, c);
            if (missing.length)
                lines.push(RULES[key].label + ": " + missing.join(", "));
        }
    for (const id of [...new Set([...c.trustedRoles, ...c.protectedRoles])])
        if (!await guild.roles.fetch(id).catch(() => null))
            lines.push("Cargo configurado não existe: " + id);
    if (c.honeyChannel) {
        const ch = await guild.channels.fetch(c.honeyChannel).catch(() => null);
        if (!ch)
            lines.push("Canal-isca não existe ou não está acessível.");
        if (c.ignoredChannels.includes(c.honeyChannel) || ch && c.ignoredChannels.includes(ch.parentId))
            lines.push("Canal-isca está nas exceções; a regra não será aplicada nele.");
    }
    return lines;
}
