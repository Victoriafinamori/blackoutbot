import * as D from "discord.js";
import { randomUUID } from "node:crypto";
import { db, assert, SecurityError, settings, save, normalize, editRule, RULES, ACTIONS, MODES, ids, exclusive } from "./config";
import { authorize, review, getReview, consume } from "./reviews";
import { missingForRule } from "./diagnostics";
import { prepare } from "./assets";
import { refreshPanel, deferPanel } from "../utils/panelInteraction";
import { operation, record, mirror } from "./incidents";
import * as V from "./views";
import * as L from "./locks";
export async function show(i: any, p: any) { return refreshPanel(i, p); }
export async function guard(i: any, fn: () => Promise<any>) {
    try {
        await authorize(i);
        return await fn();
    }
    catch (e: any) {
        if (!(e instanceof SecurityError))
            console.error("[blackout-security] interação:", e?.code || e?.name || "falha");
        const p = { content: e instanceof SecurityError ? e.message : "Não foi possível concluir. Confira o estado e o histórico antes de repetir.", flags: D.MessageFlags.Ephemeral };
        return (i.deferred || i.replied ? i.followUp(p) : i.reply(p)).catch(() => null);
    }
}
function form(id: string, title: string, fields: {
    id: string;
    label: string;
    value?: string;
    paragraph?: boolean;
    required?: boolean;
    max?: number;
}[]) {
    return new D.ModalBuilder().setCustomId("security-form:" + id).setTitle(title.slice(0, 45)).addComponents(...fields.map(f => V.row(new D.TextInputBuilder().setCustomId(f.id).setLabel(f.label.slice(0, 45)).setStyle(f.paragraph ? D.TextInputStyle.Paragraph : D.TextInputStyle.Short).setRequired(f.required !== false).setMaxLength(f.max || 100).setValue(f.value || ""))));
}
const integer = (v: string) => { assert(/^\d+$/.test(v.trim()), "Use um número inteiro, sem unidades ou casas decimais."); return Number(v); };
async function configReview(i: any, next: any, summary: string, returnTo: string, revision: number, changedRule?: string) {
    const r = await review(i, "CONFIG", { config: normalize(next), summary, returnTo, changedRule }, revision);
    return show(i, await V.reviewView(i.guild, r));
}
export async function open(i: any) { return guard(i, async () => { await deferPanel(i); await prepare(i.guild); return show(i, await V.home(i.guild)); }); }
async function confirmed(i: any, id: string) {
    return exclusive("security-config:" + i.guild.id, async () => {
        await authorize(i, true);
        const pending = await getReview(i, id), p = JSON.parse(pending.payloadJson), g = i.guild;
        if (pending.kind === "CONFIG") {
            const next = normalize(p.config);
            for (const [key, r] of Object.entries(next.rules))
                if ((!p.changedRule || p.changedRule === key) && r.mode === "ENFORCE") {
                    const missing = await missingForRule(g, key, r, next);
                    assert(!missing.length, "Antes de aplicar " + RULES[key].label + ": " + missing.join(", ") + ". Você pode usar observação enquanto corrige as pendências.");
                }
        }
        const r = await consume(i, id);
        if (r.kind === "CONFIG") {
            const before = await settings(g.id, true), next = normalize(p.config);
            await save(g.id, r.configRevision, next);
            if (before.config.rules.raid.mode !== next.rules.raid.mode || next.rules.raid.mode === "OFF")
                await db.securityState.upsert({ where: { guildId: g.id }, create: { guildId: g.id }, update: { raidUntil: null } });
            await operation(g, i.user.id, "Configuração de segurança atualizada após revisão.", { reviewId: r.id, summary: p.summary }).catch(() => console.error("[blackout-security] configuração salva; falha no registro do histórico."));
            return route(i, p.returnTo || "home", "Alteração salva. O estado abaixo já mostra a configuração vigente.");
        }
        if (r.kind === "DENY_ADD") {
            await db.securityDenyEntry.upsert({ where: { guildId_userId: { guildId: g.id, userId: p.userId } }, create: { id: randomUUID(), guildId: g.id, userId: p.userId, reason: p.reason, createdById: i.user.id }, update: { reason: p.reason, createdById: i.user.id } });
            await operation(g, i.user.id, "Cadastro adicionado à lista de entrada bloqueada.", { userId: p.userId, reason: p.reason });
            return show(i, await V.denyList(g));
        }
        if (r.kind === "ACK_CONFLICT") {
            const ids = p.lockIds;
            assert(Array.isArray(ids) && ids.length <= 25, "Revisão de conflitos inválida.");
            await db.securityChannelLock.updateMany({ where: { guildId: g.id, id: { in: ids }, status: "CONFLICT" }, data: { status: "RELEASED", lastError: "Equipe confirmou a revisão manual e preservou as permissões atuais." } });
            await operation(g, i.user.id, "Revisão manual de conflitos concluída; permissões atuais preservadas.", { reviewId: r.id, lockIds: ids });
            return show(i, await V.incidentHome(g, "Registros de conflito encerrados. Nenhuma permissão foi alterada; as regras atuais serão a referência de uma futura contenção."));
        }
        if (r.kind === "DENY_REMOVE") {
            await db.securityDenyEntry.deleteMany({ where: { id: p.entryId, guildId: g.id } });
            await operation(g, i.user.id, "Cadastro retirado da lista de entrada bloqueada.", { entryId: p.entryId });
            return show(i, await V.denyList(g));
        }
        if (r.kind === "END_RAID") {
            await db.securityState.upsert({ where: { guildId: g.id }, create: { guildId: g.id }, update: { raidUntil: null } });
            await operation(g, i.user.id, "Contenção de novas entradas encerrada pela equipe.");
            return show(i, await V.incidentHome(g, "Contenção encerrada. Silenciamentos anteriores mantêm os prazos que já tinham."));
        }
        if (r.kind === "LOCK" || r.kind === "RELEASE") {
            const incident = await record(g, { eventKey: "review:" + r.id, rule: "operation", mode: "ENFORCE", action: r.kind, actorId: i.user.id, summary: p.summary, revision: r.configRevision }, () => r.kind === "LOCK" ? L.lock(g, p.channelIds, i.user.id, p.minutes) : L.releaseMany(g, p.channelIds));
            return incident.id ? show(i, await V.incident(g, incident.id)) : show(i, await V.incidentHome(g));
        }
        if (r.kind === "MIRROR") {
            const incident = await db.securityIncident.findFirst({ where: { id: p.incidentId, guildId: g.id } });
            assert(incident && incident.deliveryStatus !== "SENDING", "O envio deste log já está em andamento.");
            await mirror(g, incident.id, true);
            return show(i, await V.incident(g, incident.id));
        }
        throw new SecurityError("Revisão desconhecida. Abra a central novamente.");
    });
}
async function route(i: any, value: string, notice = ""): Promise<any> {
    const [name, a, b] = value.split(":");
    const g = i.guild;
    if (name === "home")
        return show(i, await V.home(g, notice));
    if (name === "group")
        return show(i, await V.group(g, a));
    if (name === "rule")
        return show(i, await V.rule(g, a, notice));
    if (name === "settings")
        return show(i, await V.options(g));
    if (name === "list")
        return show(i, await V.listEditor(g, a));
    if (name === "history") {
        assert(!b || !!RULES[b], "Regra desconhecida.");
        return show(i, await V.history(g, Number(a) || 0, b));
    }
    if (name === "incident")
        return show(i, await V.incident(g, a));
    if (name === "incidents")
        return show(i, await V.incidentHome(g, notice));
    if (name === "deny")
        return show(i, await V.denyList(g, Number(a) || 0));
    if (name === "diagnose")
        return show(i, await V.diagnostic(g));
    if (name === "area")
        return show(i, await require("../utils/admPanel").buildAdmSectionPanel(g, "seguranca"));
    if (name === "logs")
        return require("../components/buttons/admLogsMenu").renderLogsMenu(i);
    if (name === "legacy")
        return require("../components/buttons/admModerationMenu").renderFiltersMenu(i);
    return false;
}
export async function execute(i: any) {
    return guard(i, async () => {
        const [prefix, name, a, b] = i.customId.split(":"), g = i.guild;
        const launchesModal = prefix === "security" && ["limits", "ids", "invites", "deny-add", "lock"].includes(name);
        if (!launchesModal)
            await deferPanel(i);
        if (prefix === "security") {
            if (name === "confirm")
                return confirmed(i, a);
            const routed = await route(i, [name, a, b].filter(v => v !== undefined).join(":"));
            if (routed !== false)
                return routed;
            if (launchesModal) {
                await authorize(i, true);
                const { config, revision } = await settings(g.id, true);
                if (name === "limits") {
                    const spec = RULES[a];
                    assert(spec && revision === Number(b), "A regra mudou. Abra novamente.");
                    return i.showModal(form("limits:" + a + ":" + revision, spec.label, spec.fields.map(f => ({ id: f.key, label: f.label + " (" + f.min + "–" + f.max + ")", value: String(config.rules[a][f.key]) }))));
                }
                if (name === "ids") {
                    assert(["trustedUsers", "protectedUsers"].includes(a) && revision === Number(b), "Esta lista mudou. Abra novamente.");
                    return i.showModal(form("ids:" + a + ":" + revision, V.LISTS[a].label, [{ id: "value", label: "Um ID por linha; vazio limpa a lista", paragraph: true, required: false, max: 1000, value: (config as any)[a].join("\n") }]));
                }
                if (name === "invites")
                    return i.showModal(form("invites:" + revision, "Convites autorizados", [{ id: "value", label: "Um código por linha; vazio limpa", paragraph: true, required: false, max: 2600, value: config.allowedInvites.join("\n") }]));
                if (name === "deny-add") {
                    assert(revision === Number(a), "A configuração mudou. Abra a lista novamente.");
                    return i.showModal(form("deny:" + revision, "Adicionar à lista bloqueada", [{ id: "user", label: "ID da pessoa ou bot", max: 25 }, { id: "reason", label: "Motivo do bloqueio de entrada", paragraph: true, max: 500 }]));
                }
                if (name === "lock")
                    return i.showModal(form("lock:" + revision, "Restrição temporária de chats", [{ id: "minutes", label: "Duração em minutos (1–60)", value: "10", max: 2 }]));
            }
            if (name === "release" || name === "end-raid") {
                await authorize(i, true);
                const locks = name === "release" ? await db.securityChannelLock.findMany({ where: { guildId: g.id, status: { in: ["ACTIVE", "PREPARING", "UNCERTAIN", "ERROR", "CONFLICT"] } }, take: 25 }) : [];
                assert(name !== "release" || locks.length, "Nenhum chat com bloqueio pendente.");
                if (name === "release" && locks.length && locks.every((l: any) => l.status === "CONFLICT")) {
                    const r = await review(i, "ACK_CONFLICT", { lockIds: locks.map((l: any) => l.id), summary: "Manter exatamente as permissões atuais e encerrar os registros de conflito destes chats: " + locks.map((l: any) => `<#${l.channelId}>`).join(", ") + ". Confirme somente depois de conferir manualmente o acesso. Nenhuma permissão será alterada. As regras atuais serão a referência de uma futura contenção.", returnTo: "incidents" });
                    return show(i, await V.reviewView(g, r));
                }
                const r = await review(i, name === "release" ? "RELEASE" : "END_RAID", { channelIds: locks.map((l: any) => l.channelId), summary: name === "release" ? "Restaurar as permissões temporárias de até 25 chats: " + locks.map((l: any) => `<#${l.channelId}>`).join(", ") + ". Alterações posteriores da equipe serão preservadas e conflitos aparecerão no resultado." : "Encerrar este ciclo de contenção de novas entradas. O Anti-Raid continua no modo configurado e poderá detectar outro pico; isso não retira silenciamentos já aplicados.", returnTo: "incidents" });
                return show(i, await V.reviewView(g, r));
            }
            if (name === "mirror") {
                await authorize(i, true);
                const p = await db.securityIncident.findFirst({ where: { id: a, guildId: g.id } });
                assert(p && p.deliveryStatus !== "SENDING", "Ocorrência indisponível ou log em envio.");
                const r = await review(i, "MIRROR", { incidentId: p.id, summary: "Reenviar somente o log deste incidente pelo destino atual da central. Se a entrega anterior ficou sem confirmação, o canal pode receber uma cópia. Nenhuma punição será repetida.", returnTo: "incident:" + p.id });
                return show(i, await V.reviewView(g, r));
            }
            if (name === "export") {
                const { config, revision } = await settings(g.id, true);
                return i.followUp({ flags: D.MessageFlags.Ephemeral, content: "Cópia das regras e exceções deste servidor. Não contém token, banco, histórico ou um backup completo do servidor.", files: [new D.AttachmentBuilder(Buffer.from(JSON.stringify({ version: 1, guildId: g.id, revision, exportedAt: new Date().toISOString(), config }, null, 2)), { name: "blackout-security-settings.json" })] });
            }
        }
        if (prefix === "security-select") {
            const v = i.values?.[0];
            if (name === "home")
                return route(i, ["incidents", "settings"].includes(v) ? v : "group:" + v);
            if (name === "rule")
                return route(i, "rule:" + v);
            if (name === "settings")
                return v === "invites" ? show(i, V.surface(g, "Convites autorizados", "Cadastre somente códigos de convite permitidos. O filtro Convites do Discord respeita esta lista; filtros antigos de links têm configurações independentes.", [V.row(V.button("invites", "Editar códigos"), V.button("settings", "Voltar às exceções"))], "settings")) : route(i, v === "diagnose" ? v : "list:" + v);
            if (name === "incident")
                return route(i, "incident:" + v);
            if (name === "mode" || name === "action") {
                await authorize(i, true);
                const { config, revision } = await settings(g.id, true);
                assert(revision === Number(b) && !!RULES[a], "A regra mudou. Abra novamente.");
                const next = editRule(config, a, { [name]: v }), nr = next.rules[a];
                const summary = "**" + RULES[a].label + "**\nModo atual: " + MODES[config.rules[a].mode] + "\nNovo modo: **" + MODES[nr.mode] + "**\nResposta: **" + ACTIONS[nr.action] + "**\n" + V.limits(a, nr) + (nr.mode === "ENFORCE" && nr.action !== "ALERT" ? "\n\nAo salvar, esta regra poderá executar a resposta automaticamente em novas ocorrências. Proprietário e o próprio bot são preservados." : "\n\nEsta configuração não aplica punição automática.");
                return configReview(i, next, summary, "rule:" + a, revision, a);
            }
            if (name === "list") {
                await authorize(i, true);
                assert(V.LISTS[a], "Lista desconhecida.");
                const { config, revision } = await settings(g.id, true);
                assert(revision === Number(b), "A lista mudou. Abra novamente.");
                const values = i.values || [];
                assert(values.length <= 25 && ids(values).length === values.length, "Seleção inválida.");
                if (V.LISTS[a].type === "roles")
                    for (const id of values) {
                        const role = await g.roles.fetch(id).catch(() => null);
                        assert(role && role.id !== g.id, "Escolha cargos existentes deste servidor, sem @everyone.");
                    }
                if (V.LISTS[a].type === "channels")
                    for (const id of values) {
                        const ch = await g.channels.fetch(id).catch(() => null);
                        assert(ch?.guildId === g.id && (["ignoredChannels", "protectedChannels"].includes(a) || [D.ChannelType.GuildText, D.ChannelType.GuildAnnouncement].includes(ch.type)), "Escolha canais compatíveis deste servidor.");
                    }
                const next = { ...config, [a]: a === "honeyChannel" ? values[0] || null : values };
                return configReview(i, next, "**" + V.LISTS[a].label + "**\nNova seleção: " + (values.join(", ") || "Nenhuma") + "\n\n" + V.LISTS[a].text, "list:" + a, revision);
            }
            if (name === "deny-remove") {
                const p = await db.securityDenyEntry.findFirst({ where: { id: v, guildId: g.id } });
                assert(p, "Cadastro indisponível.");
                const r = await review(i, "DENY_REMOVE", { entryId: p.id, summary: "Retirar <@" + p.userId + "> da lista de entrada bloqueada. Isso não altera cargos, castigos ou banimentos existentes.", returnTo: "deny:0" }, Number(a));
                return show(i, await V.reviewView(g, r));
            }
        }
        if (prefix === "security-form") {
            await authorize(i, true);
            const { config, revision } = await settings(g.id, true);
            if (name === "limits") {
                assert(RULES[a] && revision === Number(b), "A regra mudou. Abra novamente.");
                const patch = Object.fromEntries(RULES[a].fields.map(f => [f.key, integer(i.fields.getTextInputValue(f.key))])), next = editRule(config, a, patch);
                return configReview(i, next, "**" + RULES[a].label + " · novos limites**\n" + V.limits(a, next.rules[a]) + "\nModo: " + MODES[next.rules[a].mode] + "\nResposta: " + ACTIONS[next.rules[a].action], "rule:" + a, revision, a);
            }
            if (name === "ids") {
                assert(["trustedUsers", "protectedUsers"].includes(a) && revision === Number(b), "A lista mudou. Abra novamente.");
                const values = i.fields.getTextInputValue("value").split(/[\s,]+/).filter(Boolean);
                assert(values.length <= 25 && ids(values).length === values.length, "Use até 25 IDs válidos e diferentes, separados por linha.");
                return configReview(i, { ...config, [a]: values }, "**" + V.LISTS[a].label + "**\nNova lista: " + (values.join(", ") || "Nenhum") + "\n\n" + V.LISTS[a].text, "list:" + a, revision);
            }
            assert(revision === Number(a), "A configuração mudou. Abra novamente.");
            if (name === "invites") {
                const values = i.fields.getTextInputValue("value").split(/[\s,]+/).filter(Boolean);
                assert(values.length <= 25 && values.every((v: string) => /^[\w-]{2,100}$/.test(v)) && new Set(values).size === values.length, "Use até 25 códigos diferentes, sem URL, um por linha.");
                return configReview(i, { ...config, allowedInvites: values }, "Convites autorizados: " + (values.join(", ") || "Nenhum") + ". Filtros antigos de links permanecem independentes.", "settings", revision);
            }
            if (name === "deny") {
                const userId = i.fields.getTextInputValue("user").trim(), reason = i.fields.getTextInputValue("reason").trim();
                assert(/^\d{15,25}$/.test(userId) && reason.length >= 3 && reason.length <= 500, "Informe um ID válido e motivo de 3 a 500 caracteres.");
                assert(![g.ownerId, g.client.user?.id].includes(userId) && !config.trustedUsers.includes(userId), "Retire a exceção confiável antes de bloquear; proprietário e o próprio bot não entram nesta lista.");
                const r = await review(i, "DENY_ADD", { userId, reason, summary: "Cadastrar <@" + userId + "> na lista de entrada bloqueada.\nMotivo: " + reason + "\n\nA regra vigente está em **" + MODES[config.rules.deny.mode] + "**. Este cadastro não expulsa quem já está no servidor.", returnTo: "deny:0" }, revision);
                return show(i, await V.reviewView(g, r));
            }
            if (name === "lock") {
                const minutes = integer(i.fields.getTextInputValue("minutes"));
                assert(minutes >= 1 && minutes <= 60 && config.lockChannels.length, "Defina os chats para contenção e uma duração entre 1 e 60 minutos.");
                const r = await review(i, "LOCK", { channelIds: config.lockChannels, minutes, summary: "Restringir mensagens e criação de tópicos por **" + minutes + " minutos** nestes chats: " + config.lockChannels.map(id => `<#${id}>`).join(", ") + ".\n\nAs permissões de escrita atuais serão guardadas. Administradores mantêm o acesso nativo. O bot tenta restaurar ao vencer; se estiver desligado, retoma ao iniciar. Alterações posteriores da equipe exigem revisão e não serão sobrescritas.", returnTo: "incidents" }, revision);
                return show(i, await V.reviewView(g, r));
            }
        }
        throw new SecurityError("Opção indisponível. Abra a central com /adm.");
    });
}
