import { AuditLogEvent as A, PermissionsBitField } from "discord.js";
import { db, settings, exclusive, RULES } from "./config";
import { trusted, immutable, getMember, dangerous, revoke, merge, DANGEROUS } from "./actions";
import { ignoredChannel } from "./actions";
import { protectedTarget } from "./entry";
import { record, result, safeError, Result } from "./incidents";
const hasDanger = (value: any) => {
    try {
        const bits = new PermissionsBitField(BigInt(value));
        return DANGEROUS.some(p => bits.has(p));
    }
    catch {
        return false;
    }
};
const idOf = (entry: any) => entry.targetId || entry.target?.id;
function changes(entry: any, key: string) { return (entry.changes || []).find((c: any) => c.key === key); }
const OVERWRITES = [A.ChannelOverwriteCreate, A.ChannelOverwriteUpdate, A.ChannelOverwriteDelete];
async function currentEntry(guild: any, type: number, targetId: string, entryId: string) {
    const audit = await guild.fetchAuditLogs({ type, limit: 10 });
    const last = [...audit.entries.values()].find((e: any) => idOf(e) === targetId) as any;
    return last?.id === entryId;
}
async function currentOverwriteEntry(guild: any, channelId: string, overwriteId: string, entryId: string) {
    const logs = await guild.fetchAuditLogs({ limit: 25 });
    const last = [...logs.entries.values()].find((e: any) => OVERWRITES.includes(e.action) && idOf(e) === channelId && e.extra?.id === overwriteId) as any;
    return last?.id === entryId;
}
async function restore(guild: any, entry: any, context: any): Promise<Result> {
    const out = result(), targetId = idOf(entry);
    try {
        if (entry.action === A.MemberBanAdd) {
            if (!await currentEntry(guild, A.MemberBanAdd, targetId, entry.id)) {
                out.skipped.push("Outro banimento mais recente existe para o alvo; não foi revertido.");
                return out;
            }
            const ban = await guild.bans.fetch(targetId).catch((e: any) => {
                if (e?.code === 10026)
                    return null;
                throw e;
            });
            if (!ban)
                out.skipped.push("O alvo já não está banido.");
            else {
                await guild.members.unban(targetId, "BLACKOUT · revisão automática de Anti Ban, auditoria " + entry.id);
                out.done.push("O alvo deste incidente foi desbanido. Retorno ao servidor não é automático.");
            }
        }
        else if (OVERWRITES.includes(entry.action)) {
            const ch = await guild.channels.fetch(targetId, { force: true }), overwriteId = entry.extra?.id;
            if (!ch?.permissionOverwrites || !overwriteId) {
                out.skipped.push("Dados do canal/permissão indisponíveis para restauração.");
                return out;
            }
            const live = ch.permissionOverwrites.cache.get(overwriteId), allow = changes(entry, "allow"), deny = changes(entry, "deny");
            const matchesNew = (!allow || allow.new != null && String(live?.allow.bitfield ?? 0n) === String(allow.new)) && (!deny || deny.new != null && String(live?.deny.bitfield ?? 0n) === String(deny.new));
            if (!await currentOverwriteEntry(guild, targetId, overwriteId, entry.id)) {
                out.skipped.push("O canal teve outra alteração de permissões; revise manualmente.");
                return out;
            }
            if (entry.action === A.ChannelOverwriteCreate) {
                if (!live || !allow || !deny || !matchesNew) {
                    out.skipped.push("Permissão criada já mudou ou auditoria incompleta; nenhuma regra apagada.");
                    return out;
                }
                await ch.permissionOverwrites.delete(overwriteId, "BLACKOUT · reverter criação auditada " + entry.id);
                out.done.push("Nova exceção de acesso removida do canal protegido.");
            }
            else if (entry.action === A.ChannelOverwriteDelete) {
                if (live || allow?.old == null || deny?.old == null) {
                    out.skipped.push("A permissão já foi recriada ou auditoria incompleta; revise manualmente.");
                    return out;
                }
                const type = Number(entry.extra?.type) === 1 || entry.extra?.user ? 1 : 0;
                // Restore with one API write, retaining every unrelated overwrite.
                const values = [...ch.permissionOverwrites.cache.values()].map((v: any) => ({ id: v.id, type: v.type, allow: v.allow.bitfield, deny: v.deny.bitfield }));
                values.push({ id: overwriteId, type, allow: BigInt(allow.old), deny: BigInt(deny.old) });
                await ch.permissionOverwrites.set(values, "BLACKOUT · restaurar acesso auditado " + entry.id);
                out.done.push("Exceção de acesso anterior restaurada no canal protegido.");
            }
            else {
                if (!live || !matchesNew || allow && allow.old == null || deny && deny.old == null) {
                    out.skipped.push("Permissão já mudou ou auditoria incompleta; estado atual preservado.");
                    return out;
                }
                const values = [...ch.permissionOverwrites.cache.values()].map((v: any) => ({ id: v.id, type: v.type, allow: v.id === overwriteId && allow ? BigInt(allow.old) : v.allow.bitfield, deny: v.id === overwriteId && deny ? BigInt(deny.old) : v.deny.bitfield }));
                await ch.permissionOverwrites.set(values, "BLACKOUT · restaurar acesso auditado " + entry.id);
                out.done.push("Permissões anteriores restauradas no canal protegido.");
            }
        }
        else if (entry.action === A.RoleUpdate) {
            const change = changes(entry, "permissions"), role = await guild.roles.fetch(targetId);
            if (!role || !role.editable || role.managed || change?.old == null || change?.new == null || String(role.permissions.bitfield) !== String(change.new))
                out.skipped.push("Cargo mudou novamente ou não pode ser editado. Permissões preservadas para revisão manual.");
            else {
                await role.setPermissions(BigInt(change.old), "BLACKOUT · restaurar permissões confirmadas na auditoria " + entry.id);
                out.done.push("Permissões anteriores do cargo restauradas.");
            }
        }
        else if (entry.action === A.MemberRoleUpdate) {
            const member = await getMember(guild, targetId);
            if (!member) {
                out.skipped.push("Alvo saiu do servidor.");
                return out;
            }
            if (!member.manageable || immutable(guild, targetId)) {
                out.errors.push("Não é possível alterar os cargos do alvo pela hierarquia.");
                return out;
            }
            if (!await currentEntry(guild, A.MemberRoleUpdate, targetId, entry.id)) {
                out.skipped.push("O alvo recebeu outra alteração de cargos; revise manualmente.");
                return out;
            }
            for (const id of context.added || []) {
                const role = await guild.roles.fetch(id);
                if (!role || !member.roles.cache.has(id))
                    continue;
                if (role.managed || !role.editable)
                    out.errors.push("Cargo " + id + " não pode ser removido pelo bot.");
                else {
                    await member.roles.remove(id, "BLACKOUT · reverter concessão auditada " + entry.id);
                    out.done.push("Concessão não autorizada revertida: " + id);
                }
            }
            for (const id of context.removed || []) {
                const role = await guild.roles.fetch(id);
                if (!role || member.roles.cache.has(id))
                    continue;
                if (role.managed || !role.editable)
                    out.errors.push("Cargo " + id + " não pode ser restaurado pelo bot.");
                else {
                    await member.roles.add(id, "BLACKOUT · restaurar cargo protegido " + entry.id);
                    out.done.push("Cargo protegido restaurado: " + id);
                }
            }
        }
        else if (entry.action === A.MemberUpdate) {
            const change = changes(entry, "communication_disabled_until"), member = await getMember(guild, targetId), next = new Date(change?.new).getTime();
            if (!member || !member.moderatable || !Number.isFinite(next) || Math.abs((member.communicationDisabledUntilTimestamp || 0) - next) > 1000 || !await currentEntry(guild, A.MemberUpdate, targetId, entry.id))
                out.skipped.push("Castigo mudou novamente ou não pode ser revertido; confira o membro.");
            else {
                const old = change.old ? new Date(change.old).getTime() : 0;
                await member.timeout(old > Date.now() ? old - Date.now() : null, "BLACKOUT · restaurar castigo anterior, auditoria " + entry.id);
                out.done.push("Estado de timeout anterior restaurado.");
            }
        }
    }
    catch (e) {
        out.errors.push(safeError(e));
    }
    return out;
}
export async function audit(entry: any, guild: any) {
    if (!guild || !entry?.id || !entry.executorId || immutable(guild, entry.executorId))
        return;
    const at = Number(entry.createdTimestamp);
    if (!Number.isFinite(at) || Math.abs(Date.now() - at) > 120000)
        return; // Never act on replayed historical audit entries.
    return exclusive("security-audit:" + guild.id, async () => {
        const { config: c, revision } = await settings(guild.id, true), targetId = idOf(entry), actorId = entry.executorId;
        if (!Object.entries(c.rules).some(([k, r]) => (RULES[k].group === "team" || k === "moves") && r.mode !== "OFF"))
            return;
        if (c.trustedUsers.includes(actorId))
            return;
        const actor = await getMember(guild, actorId).catch(() => null);
        const newlyAdded = entry.action === A.MemberRoleUpdate && idOf(entry) === actorId ? (changes(entry, "$add")?.new || []).map((v: any) => v.id) : [];
        const priorActor = actor && newlyAdded.length ? { ...actor, roles: { cache: actor.roles.cache.filter((r: any) => !newlyAdded.includes(r.id)) } } : actor;
        if (priorActor && trusted(guild, priorActor, c))
            return;
        let rule = "", summary = "", violation = true, context: any = {};
        if (entry.action === A.MemberBanAdd) {
            rule = "bans";
            summary = "Banimento registrado pela auditoria do Discord.";
        }
        else if (entry.action === A.MemberKick) {
            rule = "kicks";
            summary = "Expulsão registrada pela auditoria do Discord.";
        }
        else if ([A.ChannelDelete, A.RoleDelete, A.WebhookCreate].includes(entry.action)) {
            rule = "destruction";
            summary = "Exclusão de canal/cargo ou criação de webhook registrada pela auditoria.";
        }
        else if ([A.MemberMove, A.MemberDisconnect].includes(entry.action)) {
            rule = "moves";
            summary = "Movimentações/desconexões atribuídas ao executor pela auditoria.";
        }
        else if (entry.action === A.GuildUpdate && changes(entry, "vanity_url_code")) {
            rule = "vanity";
            summary = "A URL personalizada do servidor foi alterada. Este monitor registra a ocorrência; não recupera a URL.";
        }
        else if (OVERWRITES.includes(entry.action)) {
            rule = "roles";
            const ch = await guild.channels.fetch(targetId).catch(() => null);
            violation = !!ch && ignoredChannel(ch, { ...c, ignoredChannels: c.protectedChannels });
            context.targetKind = "channel";
            context.overwriteId = entry.extra?.id;
            summary = "Permissões de acesso de canal protegido alteradas por executor não incluído nas exceções.";
        }
        else if (entry.action === A.RoleUpdate) {
            rule = "roles";
            const change = changes(entry, "permissions");
            violation = !!change && change.new != null && change.old != null && String(change.new) !== String(change.old) && ((c.protectedRoles.includes(targetId) || c.trustedRoles.includes(targetId)) || hasDanger(change.new) && !hasDanger(change.old));
            // Also detect newly added dangerous bits when a role already had another sensitive permission.
            if (change?.old != null && change?.new != null) {
                try {
                    const added = BigInt(change.new) & ~BigInt(change.old);
                    violation ||= DANGEROUS.some(p => (added & p) !== 0n);
                }
                catch {
                    violation = false;
                }
            }
            summary = "Permissões sensíveis de cargo alteradas por executor não incluído nas exceções.";
        }
        else if (entry.action === A.MemberRoleUpdate) {
            rule = "roles";
            const add = changes(entry, "$add")?.new || [], remove = changes(entry, "$remove")?.new || [];
            context.added = [];
            context.removed = [];
            for (const value of add.slice(0, 25)) {
                const role = await guild.roles.fetch(value.id).catch(() => null);
                if (role && (dangerous(role) || c.protectedRoles.includes(role.id) || c.trustedRoles.includes(role.id)))
                    context.added.push(role.id);
            }
            context.removed = remove.slice(0, 25).filter((v: any) => (c.protectedRoles.includes(v.id) || c.trustedRoles.includes(v.id))).map((v: any) => v.id);
            violation = context.added.length > 0 || context.removed.length > 0;
            summary = "Concessão sensível ou remoção de cargo protegido confirmada pela auditoria.";
        }
        else if (entry.action === A.MemberUpdate && changes(entry, "communication_disabled_until")) {
            rule = "punishments";
            const value = changes(entry, "communication_disabled_until").new;
            violation = value && new Date(value).getTime() > Date.now() && await protectedTarget(guild, targetId, c, at);
            summary = "Timeout aplicado a um membro protegido, com executor confirmado.";
        }
        if (!rule || c.rules[rule].mode === "OFF")
            return;
        const r = c.rules[rule];
        try {
            await db.securityAuditEntry.create({ data: { id: guild.id + ":audit:" + entry.id, guildId: guild.id, action: rule, actorId, targetId: targetId || null, units: rule === "moves" ? Math.max(1, Math.min(1000, Number(entry.extra?.count) || 1)) : 1, happenedAt: new Date(at) } });
        }
        catch (e: any) {
            if (e?.code === "P2002" || /UNIQUE constraint/i.test(e?.message || ""))
                return;
            throw e;
        }
        if (["bans", "kicks", "destruction", "moves"].includes(rule)) {
            const rows = await db.securityAuditEntry.findMany({ where: { guildId: guild.id, actorId, action: rule, happenedAt: { gte: new Date(at - r.windowSeconds * 1000), lte: new Date(at) } }, take: 1000 });
            const n = rows.reduce((sum: number, row: any) => sum + row.units, 0);
            const protectedMember = ["bans", "kicks"].includes(rule) && targetId && await protectedTarget(guild, targetId, c, at);
            violation = n >= r.limit || protectedMember;
            context.count = n;
            context.protectedTarget = !!protectedMember;
            summary += " " + n + " ocorrência(s) na janela; limite " + r.limit + (protectedMember ? ". Alvo protegido." : ".");
        }
        if (!violation)
            return;
        const mode = actor ? r.mode : "OBSERVE", action = actor ? r.action : "ALERT";
        if (!actor)
            summary += " Não foi possível verificar o acesso atual do executor; nenhuma contenção automática.";
        await record(guild, { eventKey: "audit:" + entry.id + ":" + rule, rule, mode, action, actorId, targetId: /^\d{15,25}$/.test(targetId || "") && ![A.RoleUpdate, A.ChannelDelete, A.RoleDelete, A.GuildUpdate, A.WebhookCreate, ...OVERWRITES].includes(entry.action) ? targetId : undefined, summary, revision, details: { auditId: entry.id, action: entry.action, targetId, targetKind: OVERWRITES.includes(entry.action) || entry.action === A.ChannelDelete ? "channel" : [A.RoleUpdate, A.RoleDelete].includes(entry.action) ? "role" : "member", changes: (entry.changes || []).filter((v: any) => ["permissions", "allow", "deny", "communication_disabled_until", "$add", "$remove", "vanity_url_code"].includes(v.key)).slice(0, 12), ...context } }, async () => {
            const out = result();
            if (["REVOKE", "REVOKE_UNBAN", "RESTORE_REVOKE"].includes(action))
                merge(out, await revoke(guild, actorId));
            if (["RESTORE", "RESTORE_REVOKE", "REVOKE_UNBAN"].includes(action))
                merge(out, await restore(guild, entry, context));
            return out;
        });
    });
}
