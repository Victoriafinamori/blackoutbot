import { randomUUID } from "node:crypto";
import { EmbedBuilder, PermissionsBitField } from "discord.js";
import { deliverLog } from "../logging/delivery";
import { db, RULES, ACTIONS, MODES, settings } from "./config";
export type Result = {
    done: string[];
    skipped: string[];
    errors: string[];
};
export const STATUS: Record<string, string> = { CLAIMED: "Em processamento", DONE: "Resposta aplicada", PARTIAL: "Resposta parcial", FAILED: "Falha na resposta", SKIPPED: "Sem ação possível", OBSERVED: "Registrado", CANCELLED: "Cancelado por mudança de regra", UNCERTAIN: "Resultado não confirmado" };
export const DELIVERY: Record<string, string> = { PENDING: "Aguardando envio", SENDING: "Envio em andamento", DELIVERED: "Enviado", PARTIAL: "Envio parcial", FAILED: "Falha no envio", SKIPPED: "Encaminhamento desativado", UNCERTAIN: "Entrega não confirmada" };
export const result = (): Result => ({ done: [], skipped: [], errors: [] });
export const clip = (v: any, n = 950) => String(v ?? "Não informado").replace(/\x00/g, "").slice(0, n);
export function safeError(e: any) { return e?.code === 50013 ? "Permissão ou hierarquia insuficiente." : e?.code === 10007 ? "Membro não está no servidor." : "A API não confirmou a ação. Confira o alvo e o diagnóstico antes de repetir."; }
export function targetLabel(details: any) { return !details.targetId ? "Não informado" : details.targetKind === "role" ? `<@&${details.targetId}> · cargo` : details.targetKind === "channel" ? `<#${details.targetId}> · canal` : `<@${details.targetId}>`; }
export function evidence(details: any) {
    const names: Record<string, string> = { permissions: "Permissões do cargo", allow: "Permissões permitidas", deny: "Permissões negadas", communication_disabled_until: "Timeout", "$add": "Cargos concedidos", "$remove": "Cargos retirados", vanity_url_code: "URL personalizada" };
    const labels: Record<string, string> = { Administrator: "Administrador", ManageGuild: "Gerenciar servidor", ManageRoles: "Gerenciar cargos", ManageChannels: "Gerenciar canais", BanMembers: "Banir", KickMembers: "Expulsar", ModerateMembers: "Moderar membros", ViewChannel: "Ver canal", SendMessages: "Enviar mensagens", MoveMembers: "Mover membros", ManageMessages: "Gerenciar mensagens", ManageWebhooks: "Gerenciar webhooks" };
    const value = (key: string, v: any) => {
        if (v == null)
            return "Não informado";
        if (["permissions", "allow", "deny"].includes(key)) {
            try {
                return new PermissionsBitField(BigInt(v)).toArray().map(k => labels[k] || k).join(", ") || "Nenhuma";
            }
            catch {
                return "Indisponível";
            }
        }
        if (Array.isArray(v))
            return v.map(x => x.id ? `<@&${x.id}>` : "Cargo indisponível").join(", ");
        return String(v);
    };
    return (details.changes || []).slice(0, 6).map((c: any) => "**" + (names[c.key] || c.key) + "**: " + value(c.key, c.old) + " → " + value(c.key, c.new)).join("\n");
}
export async function mirror(guild: any, id: string, retry = false) {
    const p = await db.securityIncident.findFirst({ where: { id, guildId: guild.id } });
    if (!p)
        return;
    const claim = await db.securityIncident.updateMany({ where: { id, deliveryStatus: retry ? p.deliveryStatus : "PENDING" }, data: { deliveryStatus: "SENDING", deliveryError: null } });
    if (!claim.count)
        return;
    try {
        const d = JSON.parse(p.detailsJson || "{}"), r = JSON.parse(p.resultJson || "{}"), detail = [...(r.done || []), ...(r.skipped || []), ...(r.errors || [])].join("\n");
        const e = new EmbedBuilder().setColor(p.status === "DONE" ? 0xd71935 : 0xf0b94b).setTitle("Segurança · " + (RULES[p.rule]?.label || "Operação da equipe"))
            .setDescription(clip(p.summary)).addFields({ name: "Estado", value: (STATUS[p.status] || p.status) + " · " + (MODES[p.mode as keyof typeof MODES] || p.mode), inline: true }, { name: "Resposta", value: ACTIONS[p.action] || clip(p.action), inline: true }, { name: "Executor", value: p.actorId ? `<@${p.actorId}> · ${p.actorId}` : "Não identificado; nenhuma culpa atribuída." }, ...(p.targetId ? [{ name: "Alvo", value: `<@${p.targetId}> · ${p.targetId}` }] : []), ...(p.channelId ? [{ name: "Canal", value: `<#${p.channelId}>` }] : []), ...(d.targetId && !p.targetId ? [{ name: "Alvo auditado", value: targetLabel(d) }] : []), ...(evidence(d) ? [{ name: "Alterações confirmadas", value: clip(evidence(d)) }] : []), { name: "Resultado", value: clip(detail || "Ocorrência registrada; sem alteração automática.") }).setFooter({ text: "Incidente " + p.id }).setTimestamp(p.createdAt);
        // Security decisions must not disappear because the offending account is a bot.
        const sent = await deliverLog(guild, "security.actions", e, { roleIds: [], channelIds: [] });
        await db.securityIncident.update({ where: { id }, data: { deliveryStatus: sent.sent ? (sent.errors.length ? "PARTIAL" : "DELIVERED") : sent.errors.length ? "FAILED" : "SKIPPED", deliveryError: sent.errors.length ? clip(sent.errors.join(" "), 400) : null } });
    }
    catch {
        await db.securityIncident.updateMany({ where: { id, deliveryStatus: "SENDING" }, data: { deliveryStatus: "UNCERTAIN", deliveryError: "Entrega não confirmada. Confira o canal antes de reenviar." } }).catch(() => null);
    }
}
export async function record(guild: any, input: {
    eventKey: string;
    rule: string;
    mode: string;
    action: string;
    summary: string;
    actorId?: string;
    targetId?: string;
    channelId?: string;
    details?: any;
    revision?: number;
}, execute?: () => Promise<Result>) {
    let row: any;
    try {
        row = await db.securityIncident.create({ data: { id: randomUUID(), guildId: guild.id, eventKey: guild.id + ":" + input.eventKey, rule: input.rule, mode: input.mode, action: input.action, summary: clip(input.summary, 1000), actorId: input.actorId || null, targetId: input.targetId || null, channelId: input.channelId || null, detailsJson: JSON.stringify(input.details || {}), status: "CLAIMED" } });
    }
    catch (e: any) {
        if (e?.code === "P2002" || /UNIQUE constraint/i.test(e?.message || ""))
            return { duplicate: true };
        throw e;
    }
    let out = result(), status = input.mode === "ENFORCE" && input.action !== "ALERT" ? "DONE" : "OBSERVED";
    try {
        const current = await settings(guild.id, true);
        if (input.revision !== undefined && current.revision !== input.revision) {
            status = "CANCELLED";
            out.skipped.push("As regras mudaram durante o processamento. Nenhuma ação automática foi executada.");
        }
        else if (status === "DONE" && execute) {
            out = await execute();
            status = out.errors.length ? out.done.length ? "PARTIAL" : "FAILED" : out.done.length ? "DONE" : "SKIPPED";
        }
        else
            out.skipped.push("Somente registro. Nenhuma ação automática aplicada.");
    }
    catch (e: any) {
        status = "UNCERTAIN";
        out.errors.push(safeError(e));
    }
    await db.securityIncident.update({ where: { id: row.id }, data: { status, resultJson: JSON.stringify(out) } });
    await mirror(guild, row.id);
    return { id: row.id, status, result: out };
}
export async function operation(guild: any, actorId: string, summary: string, details: any = {}) {
    return record(guild, { eventKey: "operation:" + randomUUID(), rule: "operation", mode: "OBSERVE", action: "ALERT", actorId, summary, details });
}
