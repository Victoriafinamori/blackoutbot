import * as D from "discord.js";
import { db, settings, RULES, GROUPS, MODES, ACTIONS, Config, assert } from "./config";
import { asset, emoji, Icon } from "./assets";
import { diagnose } from "./diagnostics";
import { clip, evidence, targetLabel, DELIVERY, STATUS } from "./incidents";
export const row = (...items: any[]) => new D.ActionRowBuilder<any>().addComponents(items);
export const button = (id: string, label: string, style = 2, disabled = false) => new D.ButtonBuilder().setCustomId("security:" + id).setLabel(label).setStyle(style).setDisabled(disabled);
export function select(guild: any, id: string, placeholder: string, items: any[], icon: Icon = "raid") { const png = emoji(guild, icon); return row(new D.StringSelectMenuBuilder().setCustomId("security-select:" + id).setPlaceholder(placeholder).addOptions(items.map(v => ({ ...v, ...(v.emoji ? {} : png ? { emoji: { id: png } } : {}) })))); }
export function surface(guild: any, title: string, text: string, components: any[], icon: Icon = "raid") {
    const image = emoji(guild, icon), url = image ? `https://cdn.discordapp.com/emojis/${image}.png?size=128&quality=lossless` : "attachment://security-context.png";
    return { flags: D.MessageFlags.IsComponentsV2, content: null, embeds: [], attachments: [], allowedMentions: { parse: [] },
        components: [new D.ContainerBuilder().setAccentColor(0xd71935).addSectionComponents(new D.SectionBuilder().addTextDisplayComponents(new D.TextDisplayBuilder().setContent("## " + clip(title, 100) + "\n" + text)).setThumbnailAccessory(new D.ThumbnailBuilder().setURL(url))), ...components],
        ...(image ? {} : { files: [new D.AttachmentBuilder(asset(icon), { name: "security-context.png" })] }) };
}
const iconFor = (group: string): Icon => ({ entry: "entry", chat: "chat", team: "team", voice: "voice" } as Record<string, Icon>)[group] || "raid";
const counts = (c: Config, group?: string) => { const r = Object.entries(c.rules).filter(([k]) => !group || RULES[k].group === group).map(([, r]) => r); return r.filter(r => r.mode === "ENFORCE").length + " aplicando · " + r.filter(r => r.mode === "OBSERVE").length + " em observação · " + r.filter(r => r.mode === "OFF").length + " desligadas"; };
export const limits = (key: string, rule: any) => RULES[key].fields.map(f => f.label + ": **" + rule[f.key] + "**").join("\n");
export async function home(guild: any, notice = "") {
    const { config } = await settings(guild.id), state = await db.securityState.findUnique({ where: { guildId: guild.id } });
    const active = config.rules.raid.mode === "ENFORCE" && config.rules.raid.action !== "ALERT" && state?.raidUntil && state.raidUntil.getTime() > Date.now();
    const options = Object.entries(GROUPS).map(([value, label]) => ({ value, label, description: counts(config, value), ...(emoji(guild, iconFor(value)) ? { emoji: { id: emoji(guild, iconFor(value)) } } : {}) }));
    options.push(...[{ value: "incidents", label: "Incidentes e contenção", description: "Histórico, resposta e restrição temporária de chats", emoji: { id: emoji(guild, "incidents") } }, { value: "settings", label: "Exceções e diagnóstico", description: "Pessoas, cargos, canais e funcionamento", emoji: { id: emoji(guild, "settings") } }].map(v => v.emoji.id ? v : { value: v.value, label: v.label, description: v.description } as any));
    return surface(guild, "Central de segurança", "Prepare as regras, observe os sinais e escolha quando aplicar cada proteção.\n\n" + counts(config) + (active ? "\nContenção de entrada até <t:" + Math.floor(state.raidUntil.getTime() / 1000) + ":t>." : "\nNenhuma contenção de entrada em andamento.") + (notice ? "\n\n" + notice : ""), [select(guild, "home", "O que você quer proteger?", options), row(button("diagnose", "Conferir funcionamento"), button("logs", "Logs de segurança")), row(button("area", "Voltar a Equipe e proteção"))]);
}
export async function group(guild: any, key: string) {
    assert(Object.prototype.hasOwnProperty.call(GROUPS, key), "Categoria desconhecida.");
    const { config } = await settings(guild.id);
    return surface(guild, (GROUPS as any)[key], counts(config, key) + "\nEscolha uma regra para conferir limites, resposta e modo de funcionamento.", [select(guild, "rule", "Escolha uma proteção", Object.entries(RULES).filter(([, s]) => s.group === key).map(([value, spec]) => ({ value, label: spec.label, description: MODES[config.rules[value].mode] + " · " + spec.description.slice(0, 55) })), iconFor(key)), ...(key === "chat" ? [row(button("legacy", "Palavras, links e filtros existentes"))] : []), row(button("home", "Voltar à segurança"))], iconFor(key));
}
export async function rule(guild: any, key: string, notice = "") {
    const spec = RULES[key];
    assert(spec, "Regra desconhecida.");
    const { config, revision } = await settings(guild.id), r = config.rules[key];
    const info = spec.group === "team" || key === "moves" ? "A auditoria confirma o executor depois da ação. Hierarquia pode impedir contenção ou reversão." : key === "voice" ? "O evento não identifica quem moveu o membro. Esta regra registra sem punir a pessoa movida." : key === "raid" ? "A contenção vale para novas entradas; membros anteriores não são expulsos em massa." : key === "honey" ? "Use um canal exclusivo, sinalizado para não receber mensagens normais." : "Pessoas/cargos confiáveis e canais ignorados respeitam as exceções configuradas.";
    return surface(guild, spec.label, spec.description + "\n\nModo: **" + MODES[r.mode] + "**\n" + (r.mode === "ENFORCE" ? "Resposta" : "Resposta ao ativar") + ": **" + ACTIONS[r.action] + "**" + (limits(key, r) ? "\n" + limits(key, r) : "") + "\n\n" + (notice || info), [
        select(guild, "mode:" + key + ":" + revision, "Escolha o modo", Object.entries(MODES).map(([value, label]) => ({ value, label, default: value === r.mode })), iconFor(spec.group)),
        select(guild, "action:" + key + ":" + revision, "Escolha a resposta", spec.actions.map(value => ({ value, label: ACTIONS[value], default: value === r.action })), iconFor(spec.group)),
        row(...(spec.fields.length ? [button("limits:" + key + ":" + revision, "Editar limites")] : []), ...(key === "deny" ? [button("deny:0", "Gerenciar lista bloqueada")] : []), button("history:0:" + key, "Ver ocorrências")),
        row(button("settings", "Exceções e canais"), button("group:" + spec.group, "Voltar à categoria")),
    ], key === "raid" ? "raid" : iconFor(spec.group));
}
export const LISTS: Record<string, {
    label: string;
    text: string;
    type: string;
}> = {
    trustedUsers: { label: "Pessoas e bots confiáveis", text: "Exceções às proteções automáticas. Inclua somente contas autorizadas; um ID de bot pode ser cadastrado antes de adicioná-lo ao servidor.", type: "users" },
    trustedRoles: { label: "Cargos confiáveis", text: "Membros destes cargos ficam fora das proteções automáticas. Todos que conseguem atribuir esses cargos podem conceder esta exceção.", type: "roles" },
    protectedUsers: { label: "Pessoas protegidas", text: "Ban, expulsão e timeout contra estas pessoas acionam as respectivas regras, sem esperar a cota do executor.", type: "users" },
    protectedRoles: { label: "Cargos protegidos", text: "Protege concessões/remoções e membros. Depois de um ban, cargos do alvo só são considerados quando há cache ou snapshot recente confiável.", type: "roles" },
    ignoredChannels: { label: "Canais ignorados", text: "Exceção para chat e movimentação observada em call. Categorias incluem os canais filhos; não desliga auditoria de ações da equipe.", type: "channels" },
    protectedChannels: { label: "Permissões de canais protegidos", text: "A regra Cargos e permissões também revisa alterações de acesso nestes canais e categorias. A reversão exige dados anteriores completos na auditoria e nenhuma alteração posterior.", type: "channels" },
    lockChannels: { label: "Chats para contenção", text: "Até 25 canais de texto. A restrição temporária exige revisão e prazo; permissões anteriores são guardadas para restauração.", type: "channels" },
    honeyChannel: { label: "Canal-isca exclusivo", text: "Escolha um canal que não deva receber mensagens normais e sinalize isso à comunidade. O bot não cria nem esconde o canal automaticamente.", type: "channels" },
};
export async function options(guild: any) {
    return surface(guild, "Exceções e diagnóstico", "Ajuste o alcance das regras. Alterações exigem Administrador do Discord ou o proprietário; cada mudança abre uma revisão antes de salvar.", [select(guild, "settings", "O que deseja configurar?", [...Object.entries(LISTS).map(([value, s]) => ({ value, label: s.label })), { value: "invites", label: "Convites autorizados" }, { value: "diagnose", label: "Conferir funcionamento" }], "settings"), row(button("export", "Exportar configurações"), button("home", "Voltar à segurança"))], "settings");
}
export async function listEditor(guild: any, key: string) {
    const spec = LISTS[key];
    assert(spec, "Lista desconhecida.");
    const { config, revision } = await settings(guild.id), selected = key === "honeyChannel" ? config.honeyChannel ? [config.honeyChannel] : [] : (config as any)[key];
    let menu: any;
    if (spec.type === "users")
        menu = new D.UserSelectMenuBuilder().setCustomId("security-select:list:" + key + ":" + revision).setPlaceholder("Escolha as pessoas ou bots").setMinValues(0).setMaxValues(25).setDefaultUsers(selected);
    else if (spec.type === "roles")
        menu = new D.RoleSelectMenuBuilder().setCustomId("security-select:list:" + key + ":" + revision).setPlaceholder("Escolha os cargos").setMinValues(0).setMaxValues(25).setDefaultRoles(selected);
    else
        menu = new D.ChannelSelectMenuBuilder().setCustomId("security-select:list:" + key + ":" + revision).setPlaceholder("Escolha os canais").setMinValues(0).setMaxValues(key === "honeyChannel" ? 1 : 25).setDefaultChannels(selected).addChannelTypes(...(["ignoredChannels", "protectedChannels"].includes(key) ? [D.ChannelType.GuildText, D.ChannelType.GuildAnnouncement, D.ChannelType.GuildCategory, D.ChannelType.GuildVoice, D.ChannelType.GuildStageVoice] : [D.ChannelType.GuildText, D.ChannelType.GuildAnnouncement]));
    const mentions = selected.map((id: string) => spec.type === "roles" ? `<@&${id}>` : spec.type === "channels" ? `<#${id}>` : `<@${id}>`).join(", ");
    return surface(guild, spec.label, spec.text + "\n\nSalvo: " + (mentions || "Nenhum") + "\nSeleção vazia limpa esta lista após confirmação.", [row(menu), row(...(spec.type === "users" ? [button("ids:" + key + ":" + revision, "Informar IDs")] : []), button("settings", "Voltar às exceções"))], "settings");
}
export async function reviewView(guild: any, item: any) {
    const p = JSON.parse(item.payloadJson), text = p.summary || "Confira a alteração e confirme para aplicar.";
    return surface(guild, "Conferir alteração", clip(text, 2800) + "\n\nSomente **Confirmar** aplica a mudança. Esta revisão pertence a você e expira em 20 minutos.", [row(button("confirm:" + item.id, "Confirmar", ["LOCK", "DENY_ADD"].includes(item.kind) ? 4 : 1), button(p.returnTo || "home", "Cancelar"))], "settings");
}
const labels = STATUS;
const LOCK_LABELS: Record<string, string> = { ACTIVE: "Restrição ativa", PREPARING: "Preparando restrição", UNCERTAIN: "Estado a conferir", ERROR: "Falha na restauração", CONFLICT: "Alteração da equipe a revisar" };
export async function history(guild: any, page = 0, key?: string) {
    const where = { guildId: guild.id, ...(key ? { rule: key } : {}) }, total = await db.securityIncident.count({ where });
    page = Math.max(0, Math.min(page, Math.max(0, Math.ceil(total / 8) - 1)));
    const rows = await db.securityIncident.findMany({ where, orderBy: { createdAt: "desc" }, skip: page * 8, take: 8 });
    const controls = rows.length ? [select(guild, "incident", "Escolha uma ocorrência", rows.map((r: any) => ({ value: r.id, label: clip((RULES[r.rule]?.label || "Operação da equipe") + " · " + (labels[r.status] || r.status), 100), description: clip(r.summary, 100) })), "incidents")] : [];
    return surface(guild, key ? "Ocorrências · " + RULES[key].label : "Histórico de segurança", (rows.length ? rows.map((r: any) => "**" + (RULES[r.rule]?.label || "Operação da equipe") + "** · " + (labels[r.status] || r.status) + "\n<t:" + Math.floor(r.createdAt.getTime() / 1000) + ":f> · " + clip(r.summary, 100)).join("\n\n") : "Nenhuma ocorrência registrada neste histórico.") + "\n\nPágina " + (page + 1), [...controls, row(button("history:" + (page - 1) + (key ? ":" + key : ""), "Anterior", 2, page === 0), button("history:" + (page + 1) + (key ? ":" + key : ""), "Próxima", 2, (page + 1) * 8 >= total)), row(button(key ? "rule:" + key : "incidents", "Voltar"))], "incidents");
}
export async function incident(guild: any, id: string) {
    const p = await db.securityIncident.findFirst({ where: { id, guildId: guild.id } });
    assert(p, "Ocorrência não pertence a este servidor.");
    const out = JSON.parse(p.resultJson), d = JSON.parse(p.detailsJson);
    return surface(guild, RULES[p.rule]?.label || "Operação da equipe", clip(p.summary) + "\n\nEstado: **" + (labels[p.status] || p.status) + "**\nModo: " + (MODES[p.mode as keyof typeof MODES] || p.mode) + "\nResposta: " + (ACTIONS[p.action] || p.action) + "\nExecutor: " + (p.actorId ? `<@${p.actorId}>` : "Não identificado") + (p.targetId ? "\nAlvo: <@" + p.targetId + ">" : "") + (d.auditId ? "\nAuditoria: `" + d.auditId + "`" : "") + (d.targetId && !p.targetId ? "\nAlvo auditado: " + targetLabel(d) : "") + (evidence(d) ? "\n\n" + clip(evidence(d), 900) : "") + "\n\n" + clip([...(out.done || []), ...(out.skipped || []), ...(out.errors || [])].join("\n") || "Ação ainda não confirmada; confira o alvo antes de repetir.", 1500) + "\n\nEncaminhamento do log: **" + (DELIVERY[p.deliveryStatus] || p.deliveryStatus) + "**" + (p.deliveryError ? "\n" + p.deliveryError : ""), [row(button("mirror:" + p.id, "Revisar reenvio do log"), button("history:0", "Voltar ao histórico"))], "incidents");
}
export async function incidentHome(guild: any, notice = "") {
    const { config } = await settings(guild.id), state = await db.securityState.findUnique({ where: { guildId: guild.id } }), until = config.rules.raid.mode === "ENFORCE" && config.rules.raid.action !== "ALERT" && state?.raidUntil && state.raidUntil.getTime() > Date.now();
    const locks = await db.securityChannelLock.findMany({ where: { guildId: guild.id, status: { in: ["ACTIVE", "PREPARING", "UNCERTAIN", "ERROR", "CONFLICT"] } }, take: 25 });
    return surface(guild, "Incidentes e contenção", (notice || "Consulte o histórico ou prepare uma restrição temporária dos chats escolhidos. Nenhum canal é alterado ao abrir esta tela.") + "\n\nEntrada: " + (until ? "em contenção até <t:" + Math.floor(state.raidUntil.getTime() / 1000) + ":t>" : "sem contenção ativa") + "\nChats com estado pendente: " + locks.length + (locks.length ? "\n" + locks.slice(0, 8).map((l: any) => `<#${l.channelId}> · ${LOCK_LABELS[l.status] || l.status}`).join("\n") : ""), [row(button("history:0", "Histórico de segurança"), button("lock", "Restringir chats temporariamente", 4)), row(button("release", locks.length && locks.every((l: any) => l.status === "CONFLICT") ? "Concluir revisão dos conflitos" : "Revisar liberação dos chats", 2, !locks.length), button("end-raid", "Encerrar contenção de entrada", 2, !until)), row(button("list:lockChannels", "Escolher chats"), button("home", "Voltar à segurança"))], "incidents");
}
export async function denyList(guild: any, page = 0) {
    const where = { guildId: guild.id }, total = await db.securityDenyEntry.count({ where });
    page = Math.max(0, Math.min(page, Math.max(0, Math.ceil(total / 10) - 1)));
    const rows = await db.securityDenyEntry.findMany({ where, orderBy: { createdAt: "desc" }, skip: page * 10, take: 10 }), { revision } = await settings(guild.id);
    return surface(guild, "Lista de entrada bloqueada", "A regra Lista de entrada bloqueada define se a nova entrada será apenas registrada ou expulsa. Adicionar à lista não expulsa quem já está no servidor.\n\n" + (rows.map((r: any) => `<@${r.userId}> · ${clip(r.reason, 80)}`).join("\n") || "Nenhum usuário cadastrado.") + "\nPágina " + (page + 1), [...(rows.length ? [select(guild, "deny-remove:" + revision, "Escolha um cadastro para retirar da lista", rows.map((r: any) => ({ value: r.id, label: r.userId, description: clip(r.reason, 100) })), "entry")] : []), row(button("deny-add:" + revision, "Adicionar ID"), button("deny:" + (page - 1), "Anterior", 2, page === 0), button("deny:" + (page + 1), "Próxima", 2, (page + 1) * 10 >= total)), row(button("rule:deny", "Voltar à regra de entrada"))], "entry");
}
export async function diagnostic(guild: any) {
    const { config } = await settings(guild.id, true), issues = await diagnose(guild, config), failed = await db.securityIncident.count({ where: { guildId: guild.id, status: { in: ["FAILED", "PARTIAL", "UNCERTAIN"] } } });
    return surface(guild, "Conferir funcionamento", (issues.length ? "Pendências encontradas:\n" + issues.slice(0, 12).map(s => "• " + s).join("\n") : "Nenhuma pendência detectada nas permissões gerais das regras configuradas.") + "\n\nOcorrências com resposta parcial ou não confirmada: **" + failed + "**.\n\nA hierarquia e as permissões de cada canal/alvo são revalidadas na ação. Verifique Server Members e Message Content no portal quando exigidos; auditoria exige Ver Registro de Auditoria. O diagnóstico não executa punições.", [row(button("diagnose", "Atualizar diagnóstico"), button("history:0", "Ver histórico")), row(button("logs", "Destinos dos logs"), button("home", "Voltar à segurança"))], "settings");
}
