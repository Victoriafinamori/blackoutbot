import { createHash } from "node:crypto";
import { settings } from "./config";
import { trusted, ignoredChannel, getMember, memberAction, merge } from "./actions";
import { record, result, safeError } from "./incidents";
const windows = new Map<string, number[]>(), observed = new Map<string, number>(), seen = new Map<string, number>();
export function resetWindows() { windows.clear(); observed.clear(); seen.clear(); }
export function hit(key: string, seconds: number, now = Date.now()) {
    let list = (windows.get(key) || []).filter(t => t > now - seconds * 1000);
    list.push(now);
    if (list.length > 101)
        list = list.slice(-101);
    if (windows.size >= 10000 && !windows.has(key))
        windows.delete(windows.keys().next().value!);
    windows.set(key, list);
    return list.length;
}
export function inviteCodes(text: string) { return [...text.matchAll(/(?:https?:\/\/)?(?:www\.)?(?:discord\.gg|discord(?:app)?\.com\/invite)\/([\w-]+)/gi)].map(v => v[1]); }
export async function check(message: any, edit = false): Promise<boolean> {
    const g = message.guild;
    if (!g || message.author?.id === g.client.user?.id)
        return false;
    if (message.partial) {
        try {
            message = await message.fetch();
        }
        catch {
            return false;
        }
    }
    const source = g.id + ":" + message.id + ":" + (edit ? message.editedTimestamp || "edit" : "create");
    if ((seen.get(source) || 0) > Date.now())
        return true;
    if (seen.size >= 10000)
        seen.delete(seen.keys().next().value!);
    seen.set(source, Date.now() + 300000);
    const { config: c, revision } = await settings(g.id);
    if (ignoredChannel(message.channel, c))
        return false;
    if (!message.webhookId && message.author?.bot)
        return false;
    const member = message.webhookId ? null : message.member || await getMember(g, message.author.id);
    if (!message.webhookId && (!member || trusted(g, member, c)))
        return false;
    const text = String(message.content || ""), actor = message.webhookId || message.author.id, prefix = g.id + ":" + message.channelId + ":" + actor;
    const counts = new Set(text.match(/<@!?\d+>|<@&\d+>/g) || []).size + (/@everyone\b/.test(text) ? 1 : 0) + (/@here\b/.test(text) ? 1 : 0);
    const candidates: [
        string,
        boolean,
        string
    ][] = [];
    const add = (key: string, detected: boolean, summary: string) => {
        if (c.rules[key].mode !== "OFF" && detected)
            candidates.push([key, detected, summary]);
    };
    if (message.webhookId) {
        if (!edit && c.rules.webhooks.mode !== "OFF")
            add("webhooks", hit(prefix + ":webhook", c.rules.webhooks.windowSeconds) >= c.rules.webhooks.limit, "Webhook publicou mensagens acima do limite configurado.");
    }
    else {
        add("honey", !!c.honeyChannel && message.channelId === c.honeyChannel, "Membro publicou no canal-isca exclusivo.");
        add("mentions", counts > c.rules.mentions.limit, "Mensagem com " + counts + " menções; máximo: " + c.rules.mentions.limit + ".");
        add("text", text.length > c.rules.text.limit || text.split("\n").length > c.rules.text.lines, "Mensagem excedeu os limites de texto/linhas configurados.");
        add("invites", inviteCodes(text).some(code => !c.allowedInvites.includes(code)), "Convite do Discord não autorizado, inclusive em formato sem https.");
        if (!edit && c.rules.flood.mode !== "OFF")
            add("flood", hit(prefix + ":flood", c.rules.flood.windowSeconds) >= c.rules.flood.limit, "Volume de mensagens acima do limite configurado.");
        if (!edit && c.rules.duplicates.mode !== "OFF" && text.trim())
            add("duplicates", hit(prefix + ":duplicate:" + createHash("sha256").update(text.toLowerCase().replace(/\s+/g, " ").trim()).digest("hex"), c.rules.duplicates.windowSeconds) >= c.rules.duplicates.limit, "Texto repetido acima do limite configurado.");
    }
    // An enforced violation is handled once. Observation never suppresses existing filters.
    candidates.sort((a, b) => Number(c.rules[b[0]].mode === "ENFORCE") - Number(c.rules[a[0]].mode === "ENFORCE"));
    for (const [rule, , summary] of candidates) {
        const r = c.rules[rule], observeKey = prefix + ":" + rule;
        if ((r.mode !== "ENFORCE" || r.action === "ALERT") && (observed.get(observeKey) || 0) > Date.now())
            continue;
        if (observed.size >= 10000)
            observed.delete(observed.keys().next().value!);
        observed.set(observeKey, Date.now() + 30000);
        await record(g, { eventKey: "message:" + rule + ":" + message.id + ":" + (edit ? message.editedTimestamp || "edit" : "create"), rule, mode: r.mode, action: r.action, targetId: member?.id, channelId: message.channelId, summary, revision, details: { messageId: message.id, webhookId: message.webhookId || null, characters: text.length, mentions: counts } }, async () => {
            const out = result();
            if (["DELETE", "TIMEOUT", "DELETE_WEBHOOK"].includes(r.action)) {
                try {
                    await message.delete();
                    out.done.push("Mensagem removida.");
                }
                catch (e: any) {
                    if (e?.code === 10008)
                        out.skipped.push("Mensagem já não existe.");
                    else
                        out.errors.push(safeError(e));
                }
            }
            if (r.action === "TIMEOUT" && member)
                merge(out, await memberAction(g, member.id, "TIMEOUT", r.durationMinutes));
            if (r.action === "DELETE_WEBHOOK") {
                try {
                    const hooks = await message.channel.fetchWebhooks(), hook = hooks.get(message.webhookId);
                    if (!hook || hook.channelId !== message.channelId)
                        out.skipped.push("Webhook indisponível; nenhum outro webhook foi alterado.");
                    else {
                        await hook.delete("BLACKOUT · flood de webhook configurado");
                        out.done.push("Webhook responsável excluído.");
                    }
                }
                catch (e) {
                    out.errors.push(safeError(e));
                }
            }
            return out;
        });
        if (r.mode === "ENFORCE" && r.action !== "ALERT")
            return true;
    }
    return false;
}
export async function voice(old: any, next: any) {
    if (old.channelId === next.channelId)
        return;
    const guild = next.guild || old.guild, m = next.member || old.member;
    if (!guild || !m || m.user.bot)
        return;
    const { config: c, revision } = await settings(guild.id), r = c.rules.voice;
    if (r.mode === "OFF" || trusted(guild, m, c) || ignoredChannel(next.channel || old.channel, c))
        return;
    if (hit(guild.id + ":voice:" + m.id, r.windowSeconds) < r.limit)
        return;
    const bucket = Math.floor(Date.now() / (r.windowSeconds * 1000));
    return record(guild, { eventKey: "voice:" + m.id + ":" + bucket, rule: "voice", mode: r.mode, action: "ALERT", targetId: m.id, channelId: next.channelId || old.channelId, revision, summary: "Movimentações repetidas em call. Executor não identificado pelo evento; nenhuma punição ao membro.", details: { before: old.channelId, after: next.channelId } });
}
