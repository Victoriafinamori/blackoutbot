import { db } from "./config";
import { due } from "./locks";
import { mirror } from "./incidents";
export async function safe(label: string, fn: () => Promise<any>) {
    try {
        return await fn();
    }
    catch (e: any) {
        console.error("[blackout-security] " + label + ":", e?.code || e?.name || "falha");
    }
}
const started = new WeakSet<object>();
export async function start(client: any) {
    if (started.has(client))
        return;
    started.add(client);
    for (const guild of client.guilds.cache.values())
        await safe("retomada", async () => {
            await db.securityIncident.updateMany({ where: { guildId: guild.id, status: "CLAIMED" }, data: { status: "UNCERTAIN", resultJson: JSON.stringify({ done: [], skipped: [], errors: ["Processo reiniciado antes da confirmação. Confira o alvo; nenhuma ação será repetida automaticamente."] }) } });
            await db.securityIncident.updateMany({ where: { guildId: guild.id, deliveryStatus: "SENDING" }, data: { deliveryStatus: "UNCERTAIN", deliveryError: "Processo reiniciado durante o envio do log. Confira o canal antes de reenviar." } });
        });
    let running = false, lastCleanup = 0;
    const tick = async () => {
        if (running)
            return;
        running = true;
        try {
            for (const guild of client.guilds.cache.values())
                await safe("rotina", async () => {
                    await due(guild);
                    const pending = await db.securityIncident.findMany({ where: { guildId: guild.id, deliveryStatus: "PENDING", status: { not: "CLAIMED" } }, orderBy: { createdAt: "asc" }, take: 20 });
                    for (const incident of pending)
                        await mirror(guild, incident.id);
                });
            if (Date.now() - lastCleanup > 900000) {
                for (const [model, column, age] of [["securityAuditEntry", "happenedAt", 172800000], ["securityMemberSnapshot", "capturedAt", 86400000], ["securityReview", "expiresAt", 86400000]] as const) {
                    const expired = await db[model].findMany({ where: { [column]: { lt: new Date(Date.now() - age) } }, select: { id: true }, take: 250 });
                    if (expired.length)
                        await db[model].deleteMany({ where: { id: { in: expired.map((x: any) => x.id) } } });
                }
                lastCleanup = Date.now();
            }
        }
        finally {
            running = false;
        }
    };
    await safe("início", tick);
    const timer = setInterval(() => void safe("rotina", tick), 30000);
    timer.unref?.();
}
