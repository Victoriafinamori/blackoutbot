import { db, settings, exclusive } from "./config";
import { getMember, trusted, memberAction } from "./actions";
import { record } from "./incidents";
export async function snapshot(member: any) {
    if (!member?.guild || !member.roles?.cache)
        return;
    const { config } = await settings(member.guild.id);
    if (!config.protectedRoles.length)
        return;
    await db.securityMemberSnapshot.upsert({ where: { guildId_userId: { guildId: member.guild.id, userId: member.id } }, create: { guildId: member.guild.id, userId: member.id, rolesJson: JSON.stringify([...member.roles.cache.keys()]), capturedAt: new Date() }, update: { rolesJson: JSON.stringify([...member.roles.cache.keys()]), capturedAt: new Date() } });
}
export async function protectedTarget(guild: any, userId: string, config: any, at = Date.now()) {
    if (config.protectedUsers.includes(userId) || userId === guild.ownerId)
        return true;
    const cached = guild.members.cache.get(userId);
    if (cached?.roles?.cache?.some((r: any) => config.protectedRoles.includes(r.id)))
        return true;
    const s = await db.securityMemberSnapshot.findUnique({ where: { guildId_userId: { guildId: guild.id, userId } } });
    // Only a recent removal/update snapshot can establish the target's former roles.
    return !!s && Math.abs(at - s.capturedAt.getTime()) <= 30000 && JSON.parse(s.rolesJson).some((id: string) => config.protectedRoles.includes(id));
}
export async function joined(member: any): Promise<boolean> {
    const guild = member.guild;
    if (!guild)
        return false;
    return exclusive("security-join:" + guild.id, async () => {
        const { config: c, revision } = await settings(guild.id, true);
        if (trusted(guild, member, c))
            return false;
        await snapshot(member);
        const stamp = member.joinedTimestamp || Date.now(), key = member.id + ":" + stamp;
        let raidDetected = false;
        const raid = c.rules.raid;
        if (raid.mode !== "OFF" && !member.user.bot) {
            try {
                await db.securityAuditEntry.create({ data: { id: guild.id + ":join:" + key, guildId: guild.id, action: "JOIN", targetId: member.id, happenedAt: new Date() } });
            }
            catch (e: any) {
                if (e?.code !== "P2002" && !/UNIQUE constraint/i.test(e?.message || ""))
                    throw e;
            }
            const count = await db.securityAuditEntry.count({ where: { guildId: guild.id, action: "JOIN", happenedAt: { gte: new Date(Date.now() - raid.windowSeconds * 1000) } } });
            let state = await db.securityState.findUnique({ where: { guildId: guild.id } });
            if (count >= raid.limit && raid.mode === "ENFORCE" && raid.action !== "ALERT" && (!state?.raidUntil || state.raidUntil.getTime() <= Date.now())) {
                state = await db.securityState.upsert({ where: { guildId: guild.id }, create: { guildId: guild.id, raidUntil: new Date(Date.now() + raid.activeMinutes * 60000) }, update: { raidUntil: new Date(Date.now() + raid.activeMinutes * 60000) } });
            }
            raidDetected = count >= raid.limit || !!state?.raidUntil && state.raidUntil.getTime() > Date.now();
        }
        const denied = c.rules.deny.mode !== "OFF" ? await db.securityDenyEntry.findUnique({ where: { guildId_userId: { guildId: guild.id, userId: member.id } } }) : null;
        const ageDays = Math.max(0, (Date.now() - member.user.createdTimestamp) / 86400000);
        const tests = [
            ["deny", !!denied, "Membro cadastrado na lista de entrada bloqueada."],
            ["bots", !!member.user.bot, "Entrada de bot não autorizado nas exceções."],
            ["age", !member.user.bot && ageDays < c.rules.age.minAgeDays, "Conta com " + Math.floor(ageDays) + " dias; mínimo configurado: " + c.rules.age.minAgeDays + "."],
            ["raid", raidDetected, "Pico de entradas detectado; esta é uma nova entrada durante a proteção."],
        ] as const;
        for (const [rule, detected, summary] of tests) {
            const r = c.rules[rule];
            if (!detected || r.mode === "OFF")
                continue;
            await record(guild, { eventKey: "join:" + rule + ":" + key, rule, mode: r.mode, action: r.action, targetId: member.id, summary, revision, details: { accountAgeDays: Math.floor(ageDays), joinedAt: stamp } }, () => memberAction(guild, member.id, r.action, r.durationMinutes));
            if (r.mode === "ENFORCE" && r.action !== "ALERT")
                return true;
        }
        return false;
    });
}
