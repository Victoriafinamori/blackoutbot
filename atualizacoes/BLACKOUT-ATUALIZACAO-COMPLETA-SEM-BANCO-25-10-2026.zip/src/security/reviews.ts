import { randomUUID } from "node:crypto";
import { PermissionFlagsBits as P } from "discord.js";
import { isBotAdmin } from "../utils/permissions";
import { db, assert, settings } from "./config";
export async function authorize(i: any, write = false) {
    assert(i.guild && i.message?.id && i.user?.id, "Abra a central de segurança no servidor com /adm.");
    const member = await i.guild.members.fetch({ user: i.user.id, force: true });
    assert(await isBotAdmin(member), "Você não possui acesso administrativo ao bot neste servidor.");
    if (write)
        assert(member.id === i.guild.ownerId || member.permissions.has(P.Administrator), "Alterar proteções e exceções exige Administrador do Discord ou ser proprietário do servidor.");
    return member;
}
export async function review(i: any, kind: string, payload: any, revision?: number) {
    await authorize(i, true);
    const current = await settings(i.guild.id, true);
    if (revision !== undefined)
        assert(revision === current.revision, "A configuração mudou. Abra a opção novamente.");
    return db.securityReview.create({ data: { id: randomUUID(), guildId: i.guild.id, actorId: i.user.id, messageId: i.message.id, kind, payloadJson: JSON.stringify(payload), configRevision: current.revision, expiresAt: new Date(Date.now() + 1200000) } });
}
export async function getReview(i: any, id: string) {
    await authorize(i, true);
    const r = await db.securityReview.findFirst({ where: { id, guildId: i.guild.id, actorId: i.user.id, messageId: i.message.id } });
    assert(r && r.status === "PENDING" && r.expiresAt.getTime() > Date.now(), "Esta revisão expirou, já foi usada ou pertence a outra pessoa/mensagem. Abra uma nova revisão.");
    assert(r.configRevision === (await settings(i.guild.id, true)).revision, "As regras mudaram depois desta revisão. Abra uma nova.");
    return r;
}
export async function consume(i: any, id: string) { const r = await getReview(i, id), claim = await db.securityReview.updateMany({ where: { id: r.id, status: "PENDING" }, data: { status: "CONSUMED" } }); assert(claim.count === 1, "Esta revisão já foi usada."); return r; }
