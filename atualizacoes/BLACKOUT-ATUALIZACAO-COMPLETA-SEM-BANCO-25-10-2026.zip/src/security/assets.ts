import path from "node:path";
export const ICONS = { voice: "blackout_sec_voice", raid: "blackout_sec_raid", entry: "blackout_sec_entry", team: "blackout_sec_team", chat: "blackout_sec_chat", incidents: "blackout_sec_incidents", settings: "blackout_sec_settings" };
export type Icon = keyof typeof ICONS;
export const asset = (key: Icon) => path.resolve(__dirname, "../../assets/blackout-ui/security", key + ".png");
export const emoji = (guild: any, key: Icon) => guild.client.application?.emojis?.cache?.find((v: any) => v.name === ICONS[key])?.id;
const pending = new WeakMap<object, Promise<void>>(), retry = new WeakMap<object, number>();
export async function prepare(guild: any) {
    const app = guild.client.application, m = app?.emojis;
    if (!m)
        return;
    if (Object.values(ICONS).every(n => m.cache.some((e: any) => e.name === n)))
        return;
    if (pending.has(app))
        return pending.get(app);
    if ((retry.get(app) || 0) > Date.now())
        return;
    const task = (async () => {
        try {
            await m.fetch();
            for (const [key, name] of Object.entries(ICONS))
                if (!m.cache.some((v: any) => v.name === name))
                    await m.create({ attachment: asset(key as Icon), name });
        }
        catch {
            retry.set(app, Date.now() + 300000);
            console.warn("[blackout-security] PNGs dos seletores indisponíveis; mantendo rótulos e imagem local. Nova tentativa em 5 minutos.");
        }
    })();
    pending.set(app, task);
    try {
        await task;
    }
    finally {
        pending.delete(app);
    }
}
