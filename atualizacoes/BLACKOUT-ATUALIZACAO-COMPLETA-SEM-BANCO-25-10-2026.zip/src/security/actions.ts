import { PermissionFlagsBits as P } from "discord.js";
import { Config, assert } from "./config";
import { result, Result, safeError } from "./incidents";
export const DANGEROUS = [P.Administrator, P.ManageGuild, P.ManageRoles, P.ManageChannels, P.BanMembers, P.KickMembers, P.ModerateMembers, P.ManageWebhooks, P.ManageMessages, P.MoveMembers, P.MuteMembers, P.DeafenMembers];
export const dangerous = (role: any) => DANGEROUS.some(bit => role.permissions?.has(bit));
export async function getMember(guild: any, id: string) {
    try {
        return await guild.members.fetch({ user: id, force: true });
    }
    catch (e: any) {
        if (e?.code === 10007)
            return null;
        throw e;
    }
}
export function immutable(guild: any, id: string) { return id === guild.ownerId || id === guild.client.user?.id; }
export function trusted(guild: any, member: any, c: Config) { return !!member && (immutable(guild, member.id) || c.trustedUsers.includes(member.id) || member.roles?.cache?.some((r: any) => c.trustedRoles.includes(r.id))); }
export function ignoredChannel(channel: any, c: Config) {
    let ch = channel;
    for (let n = 0; ch && n < 4; n++, ch = ch.parent || ch.guild?.channels?.cache?.get(ch.parentId))
        if (c.ignoredChannels.includes(ch.id))
            return true;
    return false;
}
export async function revoke(guild: any, actorId: string): Promise<Result> {
    const out = result();
    if (immutable(guild, actorId)) {
        out.skipped.push("Proprietário e próprio bot nunca são contidos automaticamente.");
        return out;
    }
    const m = await getMember(guild, actorId);
    if (!m) {
        out.skipped.push("Executor já saiu do servidor.");
        return out;
    }
    if (!m.manageable) {
        out.errors.push("Executor acima do bot na hierarquia; não foi possível contê-lo.");
        return out;
    }
    const candidates = [...m.roles.cache.values()].filter((r: any) => r.id !== guild.id && dangerous(r)) as any[];
    const roles = candidates.filter(r => !r.managed && r.editable);
    if (roles.length) {
        try {
            await m.roles.remove(roles.map(r => r.id), "BLACKOUT · proteção automática, executor confirmado pela auditoria");
            out.done.push("Cargos perigosos removidos do executor: " + roles.map(r => `<@&${r.id}>`).join(", "));
        }
        catch (e) {
            out.errors.push(safeError(e));
        }
    }
    const blocked = candidates.filter(r => r.managed || !r.editable);
    if (blocked.length)
        out.errors.push("Cargos gerenciados ou acima do bot não puderam ser retirados: " + blocked.map(r => `<@&${r.id}>`).join(", "));
    if (!candidates.length)
        out.skipped.push("Executor sem cargos perigosos removíveis.");
    return out;
}
export async function memberAction(guild: any, userId: string, action: string, minutes = 10): Promise<Result> {
    const out = result();
    if (immutable(guild, userId)) {
        out.skipped.push("Proprietário e próprio bot preservados.");
        return out;
    }
    const m = await getMember(guild, userId);
    if (!m) {
        out.skipped.push("Membro já saiu do servidor.");
        return out;
    }
    try {
        if (action === "KICK") {
            assert(m.kickable, "Membro fora da hierarquia de expulsão do bot.");
            await m.kick("BLACKOUT · regra de proteção de entrada");
            out.done.push("Membro expulso pela regra de entrada.");
        }
        else if (action === "TIMEOUT") {
            assert(!m.user.bot && m.moderatable, "O bot não pode silenciar este membro.");
            const until = Date.now() + minutes * 60000;
            if ((m.communicationDisabledUntilTimestamp || 0) >= until - 1000)
                out.skipped.push("Membro já possui um castigo igual ou mais longo; prazo preservado.");
            else {
                await m.timeout(minutes * 60000, "BLACKOUT · proteção automática configurada");
                out.done.push("Membro silenciado por " + minutes + " minutos.");
            }
        }
    }
    catch (e: any) {
        out.errors.push(e?.name === "SecurityError" ? e.message : safeError(e));
    }
    return out;
}
export function merge(a: Result, b: Result) { a.done.push(...b.done); a.skipped.push(...b.skipped); a.errors.push(...b.errors); return a; }
