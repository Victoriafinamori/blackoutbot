import { ChannelType, PermissionFlagsBits as P } from "discord.js";
import { randomUUID } from "node:crypto";
import { db, exclusive, assert } from "./config";
import { result, Result, safeError } from "./incidents";
const MASK = P.SendMessages | P.SendMessagesInThreads | P.CreatePublicThreads | P.CreatePrivateThreads;
const serial = (p: any) => ({ id: p.id, type: p.type, allow: String(p.allow?.bitfield ?? p.allow ?? 0), deny: String(p.deny?.bitfield ?? p.deny ?? 0) });
function bits(p: any) { return { allow: BigInt(p?.allow || 0), deny: BigInt(p?.deny || 0) }; }
const same = (a: any, b: any) => { const x = bits(a), y = bits(b); return (x.allow & MASK) === (y.allow & MASK) && (x.deny & MASK) === (y.deny & MASK); };
async function channel(guild: any, id: string) {
    const ch = await guild.channels.fetch(id, { force: true });
    assert(ch?.guildId === guild.id && [ChannelType.GuildText, ChannelType.GuildAnnouncement].includes(ch.type), "Escolha um canal de texto deste servidor.");
    const me = await guild.members.fetchMe();
    assert(ch.permissionsFor(me)?.has([P.ViewChannel, P.ManageChannels, P.ManageRoles]), "O bot precisa ver o canal e gerenciar canal/permissões.");
    return ch;
}
export async function lock(guild: any, channelIds: string[], actorId: string, minutes: number): Promise<Result> {
    assert(channelIds.length > 0 && channelIds.length <= 25 && Number.isInteger(minutes) && minutes >= 1 && minutes <= 60, "Escolha até 25 canais e prazo entre 1 e 60 minutos.");
    const out = result();
    for (const id of [...new Set(channelIds)])
        await exclusive("security-lock:" + guild.id + ":" + id, async () => {
            try {
                const old = await db.securityChannelLock.findUnique({ where: { guildId_channelId: { guildId: guild.id, channelId: id } } });
                if (old && !["RELEASED", "CANCELLED"].includes(old.status)) {
                    out.skipped.push("Canal " + id + " já possui bloqueio ou recuperação pendente; prazo original preservado.");
                    return;
                }
                const ch = await channel(guild, id), before = [...ch.permissionOverwrites.cache.values()].map(serial);
                if (!before.some(p => p.id === guild.id))
                    before.push({ id: guild.id, type: 0, allow: "0", deny: "0" });
                assert(before.length <= 100, "Canal sem espaço para a regra temporária de permissões.");
                const applied = before.map(p => { const b = bits(p); return p.id === guild.id || (b.allow & MASK) !== 0n ? { ...p, allow: String(b.allow & ~MASK), deny: String(b.deny | MASK) } : p; });
                const data = { beforeJson: JSON.stringify(before), appliedJson: JSON.stringify(applied), status: "PREPARING", createdById: actorId, expiresAt: new Date(Date.now() + minutes * 60000), lastError: null };
                const saved = await db.securityChannelLock.upsert({ where: { guildId_channelId: { guildId: guild.id, channelId: id } }, create: { id: randomUUID(), guildId: guild.id, channelId: id, ...data }, update: data });
                await ch.permissionOverwrites.set(applied.map(p => ({ ...p, allow: BigInt(p.allow), deny: BigInt(p.deny) })), "BLACKOUT · contenção temporária solicitada pela equipe");
                await db.securityChannelLock.update({ where: { id: saved.id }, data: { status: "ACTIVE" } });
                out.done.push("Chat " + id + " restringido por " + minutes + " minutos. Administradores mantêm o acesso nativo.");
            }
            catch (e: any) {
                await db.securityChannelLock.updateMany({ where: { guildId: guild.id, channelId: id, status: "PREPARING" }, data: { status: "UNCERTAIN", lastError: safeError(e) } }).catch(() => null);
                out.errors.push("Canal " + id + ": " + (e?.name === "SecurityError" ? e.message : safeError(e)));
            }
        });
    return out;
}
export async function release(guild: any, id: string): Promise<Result> {
    return exclusive("security-lock:" + guild.id + ":" + id, async () => {
        const out = result(), item = await db.securityChannelLock.findUnique({ where: { guildId_channelId: { guildId: guild.id, channelId: id } } });
        if (!item || item.status === "RELEASED") {
            out.skipped.push("Canal " + id + " não possui bloqueio pendente.");
            return out;
        }
        try {
            const ch = await channel(guild, id), before = JSON.parse(item.beforeJson), applied = JSON.parse(item.appliedJson), current = [...ch.permissionOverwrites.cache.values()].map(serial);
            const plan = [...current];
            let conflicts = 0;
            for (const previous of before) {
                const expected = applied.find((p: any) => p.id === previous.id), pos = plan.findIndex(p => p.id === previous.id), now = pos >= 0 ? plan[pos] : { ...previous, allow: "0", deny: "0" };
                if (same(previous, expected))
                    continue; // This overwrite was never changed by our lock.
                if (!same(now, expected)) {
                    if (!same(now, previous))
                        conflicts++;
                    continue;
                }
                const b = bits(now), restore = bits(previous), next = { ...now, allow: String((b.allow & ~MASK) | (restore.allow & MASK)), deny: String((b.deny & ~MASK) | (restore.deny & MASK)) };
                if (pos >= 0)
                    plan[pos] = next;
                else
                    plan.push(next);
            }
            if (conflicts) {
                out.skipped.push("Canal " + id + ": permissões alteradas por outra pessoa foram preservadas; " + conflicts + " conflito(s) exigem revisão.");
            }
            if (JSON.stringify(current) !== JSON.stringify(plan)) {
                await ch.permissionOverwrites.set(plan.map(p => ({ ...p, allow: BigInt(p.allow), deny: BigInt(p.deny) })), "BLACKOUT · restaurar somente permissões da contenção temporária");
                out.done.push("Permissões temporárias restauradas em " + id + ".");
            }
            else
                out.skipped.push("Canal " + id + " já está restaurado ou não possui alteração segura para aplicar.");
            await db.securityChannelLock.update({ where: { id: item.id }, data: { status: conflicts ? "CONFLICT" : "RELEASED", lastError: conflicts ? "Alteração externa preservada. Confira as regras do canal; o bot não sobrescreve a decisão posterior." : null } });
        }
        catch (e: any) {
            await db.securityChannelLock.update({ where: { id: item.id }, data: { status: "ERROR", lastError: safeError(e) } });
            out.errors.push("Canal " + id + ": " + safeError(e));
        }
        return out;
    });
}
export async function releaseMany(guild: any, ids?: string[]) {
    const out = result(), list = await db.securityChannelLock.findMany({ where: { guildId: guild.id, status: { in: ["ACTIVE", "PREPARING", "UNCERTAIN", "ERROR", "CONFLICT"] }, ...(ids ? { channelId: { in: ids } } : {}) }, take: 25 });
    for (const item of list) {
        const r = await release(guild, item.channelId);
        out.done.push(...r.done);
        out.skipped.push(...r.skipped);
        out.errors.push(...r.errors);
    }
    return out;
}
export async function due(guild: any) {
    const list = await db.securityChannelLock.findMany({ where: { guildId: guild.id, status: { in: ["ACTIVE", "PREPARING", "UNCERTAIN", "ERROR"] }, expiresAt: { lte: new Date() } }, take: 25 });
    for (const row of list)
        await release(guild, row.channelId);
}
