import "dotenv/config";
import { Client, Collection, Events, GatewayIntentBits, Partials } from "discord.js";
import { loadCommands } from "./handlers/loadCommands";
import { loadEvents } from "./handlers/loadEvents";
import { loadButtons } from "./handlers/loadButtons";
import { loadSelects } from "./handlers/loadSelects";
import { loadModals } from "./handlers/loadModals";
import { Command, ButtonComponent, SelectMenuComponent, ModalComponent } from "./structures/types";
import { prisma } from "./database/prisma";
import { runAutoProgression } from "./utils/reintegration";
import { checkAllGuildsRoleTransferSchedule } from "./utils/roleTransfer";

if (!process.env.DISCORD_TOKEN || !process.env.CLIENT_ID) {
  console.error("❌ DISCORD_TOKEN e CLIENT_ID precisam estar definidos no .env");
  process.exit(1);
}

function tokenOwnerId(token: string) {
  try { return Buffer.from(token.split(".")[0], "base64url").toString("utf8"); } catch { return null; }
}
const configuredClientId = process.env.CLIENT_ID;
const tokenClientId = tokenOwnerId(process.env.DISCORD_TOKEN);
if (tokenClientId && /^\d+$/.test(tokenClientId) && tokenClientId !== configuredClientId) {
  console.error("❌ CONFIGURAÇÃO INVÁLIDA: DISCORD_TOKEN e CLIENT_ID pertencem a bots diferentes.");
  console.error(`   ID identificado pelo token: ${tokenClientId}`);
  console.error(`   CLIENT_ID configurado:       ${configuredClientId}`);
  console.error("   Corrija as variáveis na Square Cloud antes de iniciar o bot.");
  process.exit(1);
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildModeration,
  ],
  partials: [Partials.Message, Partials.Channel, Partials.GuildMember, Partials.Reaction, Partials.User],
}) as Client & {
  commands: Collection<string, Command>;
  buttons: Collection<string, ButtonComponent>;
  selects: Collection<string, SelectMenuComponent>;
  modals: Collection<string, ModalComponent>;
};

client.commands = new Collection();
client.buttons = new Collection();
client.selects = new Collection();
client.modals = new Collection();

loadCommands(client);
loadButtons(client);
loadSelects(client);
loadModals(client);
loadEvents(client);

client.once(Events.ClientReady, readyClient => {
  if (readyClient.user.id !== configuredClientId) {
    console.error("❌ O bot conectado não corresponde ao CLIENT_ID configurado.");
    console.error(`   Bot conectado: ${readyClient.user.tag} (${readyClient.user.id})`);
    console.error(`   CLIENT_ID: ${configuredClientId}`);
    void shutdown();
  } else console.log(`✅ Identidade validada: ${readyClient.user.tag} (${readyClient.user.id})`);
});

client.login(process.env.DISCORD_TOKEN);

// Progressão automática de reintegração: verifica periodicamente se algum
// membro em etapa "automática" já cumpriu os dias mínimos e o avança.
const AUTO_PROGRESSION_INTERVAL_MS = 5 * 60 * 1000; // 5 minutos
client.once("ready", () => {
  setInterval(() => {
    runAutoProgression(client).catch((err) =>
      console.error("[auto-progression] Erro na verificação periódica:", err)
    );
  }, AUTO_PROGRESSION_INTERVAL_MS);
});

// Transferência automática de cargo (ex: "Perdido" -> "AUDAZ"): verifica
// periodicamente se algum servidor com modo AUTOMATIC configurado chegou
// no dia/horário agendado e, se sim, roda a transferência sozinho.
const ROLE_TRANSFER_CHECK_INTERVAL_MS = 5 * 60 * 1000; // 5 minutos
client.once("ready", () => {
  setInterval(() => {
    checkAllGuildsRoleTransferSchedule(client).catch((err) =>
      console.error("[role-transfer] Erro na verificação periódica:", err)
    );
  }, ROLE_TRANSFER_CHECK_INTERVAL_MS);
});

// Encerramento gracioso (fecha conexão com o banco corretamente)
async function shutdown() {
  console.log("\n🔻 Encerrando bot...");
  await prisma.$disconnect();
  client.destroy();
  process.exit(0);
}

process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
