import { prisma } from "./prisma";

/**
 * Retorna a configuração do servidor, criando uma configuração
 * padrão automaticamente caso ainda não exista.
 */
export async function getOrCreateGuildConfig(guildId: string) {
  const existing = await prisma.guildConfig.findUnique({ where: { guildId } });
  if (existing) return existing;
  try {
    return await prisma.guildConfig.upsert({
      where: { guildId },
      create: { guildId },
      update: {},
    });
  } catch (error: any) {
    if (error.code === "P2002")
      return prisma.guildConfig.findUniqueOrThrow({ where: { guildId } });
    throw error;
  }
}
