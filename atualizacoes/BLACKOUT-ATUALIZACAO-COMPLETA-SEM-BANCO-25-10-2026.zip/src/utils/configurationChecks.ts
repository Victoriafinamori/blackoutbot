import { ChannelType, Guild, PermissionFlagsBits } from "discord.js";

export async function writableChannel(guild: Guild, id: string, embed = true) {
  const channel = await guild.channels.fetch(id).catch(() => null);
  if (!channel || channel.guildId !== guild.id || !(channel.type === ChannelType.GuildText || channel.type === ChannelType.GuildAnnouncement)) {
    return { channel: null, issue: "Escolha um canal de texto deste servidor." };
  }
  const me = guild.members.me ?? await guild.members.fetchMe();
  const permissions = channel.permissionsFor(me);
  const required = [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, ...(embed ? [PermissionFlagsBits.EmbedLinks] : [])];
  if (!permissions?.has(required)) return { channel: null, issue: "O bot precisa ver o canal e ter permissão para enviar mensagens" + (embed ? " e embeds." : ".") };
  return { channel, issue: null };
}
export function autoRoleIssues(guild: Guild, ids: string[]) {
  return ids.flatMap(id => {
    const role = guild.roles.cache.get(id);
    if (!role) return ["Um cargo selecionado não existe mais."];
    if (role.id === guild.id || role.managed) return [`${role.name}: esse cargo não pode ser atribuído automaticamente.`];
    if (!role.editable) return [`${role.name}: verifique a hierarquia e a permissão Gerenciar Cargos do bot.`];
    return [];
  });
}
