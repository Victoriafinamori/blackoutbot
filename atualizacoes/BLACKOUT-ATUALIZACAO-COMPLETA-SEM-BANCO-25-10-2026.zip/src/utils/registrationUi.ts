import { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, Guild } from "discord.js";
import { prisma } from "../database/prisma";
import { regConfig, sessions } from "./registration";
import { ids } from "./tickets";

const hex = (v: string) => Number.parseInt(v.replace("#", ""), 16) || 0x000000;
export async function prettyRegistrationView(guild: Guild, owner: string) {
  const s = sessions.get(owner); if (!s) return null;
  const pages = await prisma.registrationPage.findMany({ where: { guildId: guild.id }, orderBy: { order: "asc" } });
  if (s.page >= pages.length) return prettyConfirmationView(guild, owner);
  const p = pages[s.page], c = await regConfig(guild.id), target = await guild.members.fetch(s.memberId);
  const roles = ids(p.roleIds).map(id => guild.roles.cache.get(id)).filter((r): r is NonNullable<typeof r> => !!r && r.editable).slice(0, 20);
  if (!roles.length) throw new Error(`A página “${p.name}” não possui cargos válidos e gerenciáveis.`);
  const selected = s.answers[p.id] || [];
  const embed = new EmbedBuilder().setColor(hex(c.internalColor)).setAuthor({ name: `Sistema de Registro — ${guild.name}`, iconURL: guild.iconURL() || undefined }).setTitle(c.internalTitle || "Selecione os cargos apropriados para o membro").setDescription([c.internalDescription,p.question,p.description].filter(Boolean).join("\n\n").slice(0,4096)).setThumbnail(c.internalThumbnail || target.displayAvatarURL()).addFields({ name: "Informações do Registro", value: `**Registrador(a):** <@${s.registrarId}>\n**Membro:** <@${s.memberId}>\n**Indicação:** ${s.indication || "Não informada"}` }).setFooter({ text: `Você pode selecionar até ${p.maxChoices} cargo(s) • Página ${s.page + 1}/${pages.length}${s.test ? " • MODO DE TESTE" : ""}` }).setTimestamp();
  if (c.internalImage) embed.setImage(c.internalImage); if (c.internalFooter) embed.setFooter({ text: `${c.internalFooter} • Página ${s.page + 1}/${pages.length}` });
  const roleRows: ActionRowBuilder<ButtonBuilder>[] = [];
  for (let x = 0; x < roles.length; x += 5) roleRows.push(new ActionRowBuilder<ButtonBuilder>().addComponents(...roles.slice(x, x + 5).map(r => new ButtonBuilder().setCustomId(`registration-choice:${owner}:${p.id}:${r.id}`).setLabel(r.name.slice(0, 80)).setStyle(selected.includes(r.id) ? ButtonStyle.Success : ButtonStyle.Secondary))));
  const nav = new ActionRowBuilder<ButtonBuilder>().addComponents(new ButtonBuilder().setCustomId(`registration-nav:prev:${owner}`).setLabel("Anterior").setStyle(ButtonStyle.Secondary).setDisabled(s.page === 0),new ButtonBuilder().setCustomId(`registration-nav:finish:${owner}`).setLabel("Concluir").setStyle(ButtonStyle.Success),new ButtonBuilder().setCustomId(`registration-nav:cancel:${owner}`).setLabel("Cancelar").setStyle(ButtonStyle.Danger),new ButtonBuilder().setCustomId(`registration-nav:next:${owner}`).setLabel("Próxima").setStyle(ButtonStyle.Primary));
  return { embeds: [embed], components: [...roleRows, nav] };
}
export async function prettyConfirmationView(guild: Guild, owner: string) {
  const s = sessions.get(owner)!; const pages = await prisma.registrationPage.findMany({ where: { guildId: guild.id }, orderBy: { order: "asc" } }); const c = await regConfig(guild.id);
  const answers = pages.map(p => `**${p.name}:** ${(s.answers[p.id] || []).map(id => `<@&${id}>`).join(", ") || "Não selecionado"}`).join("\n");
  const embed = new EmbedBuilder().setColor(hex(c.internalColor)).setTitle(s.test ? "MODO DE TESTE" : "Confirmar Registro").setDescription(s.test ? "Nenhuma alteração será realizada." : "Revise todas as informações antes de concluir.").addFields({ name: "Membro", value: `<@${s.memberId}>`, inline: true },{ name: "Registrador", value: `<@${s.registrarId}>`, inline: true },{ name: "Indicação", value: s.indication || "Não informada" },{ name: "Respostas", value: answers || "N/A" },{ name: "Não Registrado — cargos removidos", value: ids(c.unregisteredRoleIds).map(id => `<@&${id}>`).join(", ") || "Nenhum" },{ name: "Registrado — cargos adicionados", value: ids(c.registeredRoleIds).map(id => `<@&${id}>`).join(", ") || "Nenhum" });
  return { embeds: [embed], components: [new ActionRowBuilder<ButtonBuilder>().addComponents(new ButtonBuilder().setCustomId(`registration-nav:confirm:${owner}`).setLabel("Confirmar Registro").setStyle(ButtonStyle.Success),new ButtonBuilder().setCustomId(`registration-nav:prev:${owner}`).setLabel("Voltar").setStyle(ButtonStyle.Secondary),new ButtonBuilder().setCustomId(`registration-nav:cancel:${owner}`).setLabel("Cancelar").setStyle(ButtonStyle.Danger))] };
}
