import { ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import { refreshPanel } from './panelInteraction';
export async function adminMessagePreviewPayload(guild:any,key:string,focused=false){
  let preview:any,prefix:string,title:string,home='';
  if(key==='parcerias'){const m=require('./partnerships');preview=m.openingPanel(await m.partnershipConfig(guild.id),true);prefix='parceria-admin';title='Parcerias'}
  else if(key==='denuncias'){const m=require('./reports');preview=m.reportOpeningPanel(await m.reportConfig(guild.id),true);prefix='adm-denuncia';title='Central de denúncias'}
  else if(key==='feedback'){const m=require('./serverFeedback');preview=m.serverFeedbackPanelView(await m.getServerFeedbackConfig(guild.id));prefix='adm-feedback';title='Feedback da comunidade';home='adm-feedback:menu'}
  else if(key==='anonymous-photo'||key==='anonymous-message'){const m=require('../../app/submundo/service'),photo=key==='anonymous-photo';const c=await (photo?m.getAnonymousPhotoConfig:m.getAnonymousMessageConfig)(guild.id);preview=(photo?m.buildAnonymousMediaPanelView:m.buildAnonymousMessagePanelView)(c,await m.getGuildTimezone(guild.id));prefix='adm-'+key;title=photo?'Fotos e vídeos anônimos':'Mensagens anônimas';home=prefix+':home'}
  else throw Error('Prévia administrativa inválida.');
  const button=(id:string,label:string,style=ButtonStyle.Secondary)=>new ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style);
  const rows=(preview.components||[]).map((row:any)=>{const data=typeof row.toJSON==='function'?row.toJSON():structuredClone(row);for(const c of data.components)if(c.type===2&&c.custom_id)c.disabled=true;return ActionRowBuilder.from(data)});
  const simple=['feedback','anonymous-photo','anonymous-message'].includes(key);
  const controls=focused?[button(`admin-preview:edit-${key}`,'Voltar ao editor')]:[button(`${prefix}:${simple?'appearance':'edit-embed'}`,'Editar mensagem'),...(!simple?[button(`${prefix}:edit-button`,'Editar botão')]:[]),button(`admin-preview:${key}`,'Ver prévia'),button(`${prefix}:publish`,'Publicar / atualizar',ButtonStyle.Primary)];
  return {content:`**${title} · ${focused?'Prévia':'Mensagens e publicação'}**\n${focused?'Esta visualização não publica a mensagem.':'Salvar atualiza esta mesma embed. Use Publicar / atualizar para alterar o painel público.'}`,attachments:[],embeds:preview.embeds,components:[...rows,new ActionRowBuilder<ButtonBuilder>().addComponents(...controls),...(!focused?[new ActionRowBuilder<ButtonBuilder>().addComponents(button(home||(key==='parcerias'?'admin-task-home:parcerias':`${prefix}:menu`),'Voltar'))]:[])],allowedMentions:{parse:[]}};
}
export async function showAdminMessagePreview(i:any,key:string,focused=false){return refreshPanel(i,await adminMessagePreviewPayload(i.guild,key,focused))}
