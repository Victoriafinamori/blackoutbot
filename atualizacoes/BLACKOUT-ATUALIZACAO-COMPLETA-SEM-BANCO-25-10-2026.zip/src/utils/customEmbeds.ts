import { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } from "discord.js";
import { prisma } from "../database/prisma";

export function normalizeHex(value: string | null | undefined, fallback = "2B6CB0") {
  const clean = String(value || "").trim().replace(/^#/, "").toUpperCase();
  return /^[0-9A-F]{6}$/.test(clean) ? clean : fallback;
}

export async function fetchCustomEmbed(id: string, guildId: string) {
  return prisma.customEmbed.findFirst({
    where: { id, guildId },
    include: { buttons: { orderBy: { position: "asc" } } },
  });
}

type EmbedRecord = NonNullable<Awaited<ReturnType<typeof fetchCustomEmbed>>>;

function makeLinkButton(item: EmbedRecord["buttons"][number], guildId: string) {
  const target = item.type === "CHANNEL"
    ? (item.channelId ? `https://discord.com/channels/${guildId}/${item.channelId}` : null)
    : item.url;
  if (!target || !/^https?:\/\//i.test(target)) return null;
  const button = new ButtonBuilder()
    .setStyle(ButtonStyle.Link)
    .setLabel((item.label || "Abrir").slice(0, 80))
    .setURL(target);
  if (item.emoji) {
    try { button.setEmoji(item.emoji); } catch {}
  }
  return button;
}

export function buildCustomEmbedRows(record: EmbedRecord, guildId: string) {
  const rows: ActionRowBuilder<ButtonBuilder>[] = [];
  const buttons = (record.buttons || []).slice(0, 25)
    .map((item) => makeLinkButton(item, guildId))
    .filter((x): x is ButtonBuilder => Boolean(x));
  for (let i = 0; i < buttons.length; i += 5) {
    rows.push(new ActionRowBuilder<ButtonBuilder>().addComponents(...buttons.slice(i, i + 5)));
  }
  return rows;
}

export function buildCustomEmbedMessage(record: EmbedRecord, guildId: string) {
  const embed = new EmbedBuilder().setColor(`#${normalizeHex(record.color)}` as `#${string}`);
  if (record.title) embed.setTitle(record.title.slice(0, 256));
  if (record.description) embed.setDescription(record.description.slice(0, 4096));
  if (record.author) embed.setAuthor({ name: record.author.slice(0, 256) });
  if (record.footer) embed.setFooter({ text: record.footer.slice(0, 2048) });
  if (record.thumbnailUrl) embed.setThumbnail(record.thumbnailUrl);
  if (record.imageUrl) embed.setImage(record.imageUrl);
  if (record.showTimestamp) embed.setTimestamp();
  if (!record.title && !record.description && !record.imageUrl && !record.thumbnailUrl) embed.setDescription("*Configure o título e/ou a descrição desta embed.*");
  return { embeds: [embed], components: buildCustomEmbedRows(record, guildId) };
}
