import { EmbedBuilder, Guild } from "discord.js";
import { AdminArea, adminEmojiImage } from "./admEmojis";
export const BLACKOUT_RED = 0xd71935;
export const ADMIN_AREA_LABELS: Record<AdminArea, string> = {
  sistema: "Personalização do bot", seguranca: "Equipe e proteção", membros: "Entrada e evolução",
  atendimento: "Atendimento", servidor: "Comunidade e atividade", staff: "Jogos e eventos",
  entretenimento: "Social e entretenimento",
};
/** Only administrative views use this theme. Saved/public embeds keep their design. */
class AdminEmbed extends EmbedBuilder {
  override setTitle(title: string | null) {
    return super.setTitle(title?.replace(/^[\p{Extended_Pictographic}\uFE0F\u200D\s]+/u, "") ?? null);
  }
  override addFields(...fields: any[]): this {
    return super.addFields(...fields.flat().map(field => ({ ...field, name: field.name?.replace(/^[\p{Extended_Pictographic}\uFE0F\u200D\s]+/u, '') })));
  }
  override setFields(...fields: any[]): this {
    return super.setFields(...fields.flat().map(field => ({ ...field, name: field.name?.replace(/^[\p{Extended_Pictographic}\uFE0F\u200D\s]+/u, '') })));
  }
}
export function adminEmbed(guild: Guild, area: AdminArea): EmbedBuilder {
  const bot = guild.client.user;
  const embed = new AdminEmbed().setColor(BLACKOUT_RED)
    .setAuthor({ name: `BLACKOUT · ${ADMIN_AREA_LABELS[area]}`, ...(bot ? { iconURL: bot.displayAvatarURL() } : {}) })
    .setFooter({ text: "BLACKOUT · Administração" });
  const image = adminEmojiImage(guild, area);
  if (image) embed.setThumbnail(image);
  return embed;
}
