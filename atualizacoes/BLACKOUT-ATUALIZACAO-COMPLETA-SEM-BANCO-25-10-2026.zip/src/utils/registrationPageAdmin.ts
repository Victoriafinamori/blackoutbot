import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  Guild,
  RoleSelectMenuBuilder,
  StringSelectMenuBuilder,
} from "discord.js";
import { prisma } from "../database/prisma";
import { adminEmbed } from "./adminUi";

const button = (id: string, label: string, style = ButtonStyle.Secondary) =>
  new ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style);

export async function registrationPagesPayload(guild: Guild) {
  const pages = await prisma.registrationPage.findMany({
    where: { guildId: guild.id },
    orderBy: { order: "asc" },
  });

  const embed = (adminEmbed(guild, "membros"))
    .setTitle("Formulário do Registro")
    .setDescription(
      pages
        .map(
          (p) =>
            `**${p.order}. ${p.name}**\n${p.question}\n${
              p.roleIds
                .split(",")
                .filter(Boolean)
                .map((id) => `<@&${id}>`)
                .join(" • ") || "Sem cargos"
            }`
        )
        .join("\n\n") || "Nenhuma página configurada."
    );

  const components: any[] = [];
  if (pages.length) {
    const select = new StringSelectMenuBuilder()
      .setCustomId("registration-manage-page")
      .setPlaceholder("Selecione uma página para gerenciar")
      .addOptions(
        pages.map((p) => ({
          label: `${p.order}. ${p.name}`.slice(0, 100),
          description: `Pergunta, ordem, obrigatoriedade e cargos`.slice(0, 100),
          value: p.id,
        }))
      );
    components.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select));
  }

  components.push(
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      button("adm-reg:createpage", "Nova página", ButtonStyle.Primary).setDisabled(pages.length >= 5),
      button("adm-reg:menu", "Voltar")
    )
  );

  return { content: null, attachments: [], embeds: [embed], components, allowedMentions: { parse: [] as never[] } };
}

export async function registrationPageManagerPayload(guild: Guild, pageId: string) {
  const page = await prisma.registrationPage.findFirst({
    where: { id: pageId, guildId: guild.id },
  });
  if (!page) return registrationPagesPayload(guild);

  const roleIds = page.roleIds.split(",").filter(Boolean);
  const roleLines = roleIds.length
    ? roleIds.map((id) => `<@&${id}>`).join(" • ")
    : "Nenhum cargo configurado.";

  const embed = (adminEmbed(guild, "membros"))
    .setTitle(`Gerenciar Página ${page.order} — ${page.name}`)
    .setDescription(
      `**Pergunta**\n${page.question}\n\n` +
        `**Descrição**\n${page.description || "Sem descrição"}\n\n` +
        `**Resposta:** ${page.required ? "Obrigatória" : "Opcional"}\n\n` +
        `**Cargos desta página**\n${roleLines}\n\n` +
        `**Máximo de escolhas:** ${page.maxChoices}\n\n` +
        `Use os controles abaixo para adicionar/remover cargos ou excluir somente esta página.`
    );

  const addRoles = new RoleSelectMenuBuilder()
    .setCustomId(`registration-page-addroles:${page.id}`)
    .setPlaceholder("Adicionar cargo(s) nesta página")
    .setMinValues(1)
    .setMaxValues(20);

  const components: any[] = [
    new ActionRowBuilder<RoleSelectMenuBuilder>().addComponents(addRoles),
  ];

  if (roleIds.length) {
    const removeRoles = new StringSelectMenuBuilder()
      .setCustomId(`registration-page-removeroles:${page.id}`)
      .setPlaceholder("Remover cargo(s) desta página")
      .setMinValues(1)
      .setMaxValues(Math.min(20, roleIds.length))
      .addOptions(
        roleIds.slice(0, 20).map((id) => ({
          label: (guild.roles.cache.get(id)?.name || id).slice(0, 100),
          value: id,
          description: "Remover desta página",
        }))
      );
    components.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(removeRoles));
  }

  components.push(
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      button(`registration-ui:page-edit:${page.id}`, "Editar pergunta", ButtonStyle.Primary),
      button(`registration-ui:page-up:${page.id}`, "Mover para cima").setDisabled(page.order <= 1),
      button(`registration-ui:page-down:${page.id}`, "Mover para baixo").setDisabled(page.order >= await prisma.registrationPage.count({ where: { guildId: guild.id } })),
      button(`adm-reg:pagedelete:${page.id}`, "Excluir página", ButtonStyle.Danger),
      button("adm-reg:pages", "Voltar", ButtonStyle.Secondary)
    )
  );

  return { content: null, attachments: [], embeds: [embed], components, allowedMentions: { parse: [] as never[] } };
}

export async function deleteRegistrationPage(guildId: string, pageId: string) {
  const page = await prisma.registrationPage.findFirst({ where: { id: pageId, guildId } });
  if (!page) return false;

  await prisma.$transaction(async (tx) => {
    await tx.registrationPage.delete({ where: { id: page.id } });
    const following = await tx.registrationPage.findMany({
      where: { guildId, order: { gt: page.order } },
      orderBy: { order: "asc" },
    });
    for (const current of following) {
      await tx.registrationPage.update({
        where: { id: current.id },
        data: { order: current.order - 1 },
      });
    }
  });
  return true;
}
