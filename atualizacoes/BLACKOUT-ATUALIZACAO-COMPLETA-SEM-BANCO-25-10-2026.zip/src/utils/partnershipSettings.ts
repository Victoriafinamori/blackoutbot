import { ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelSelectMenuBuilder, ChannelType, RoleSelectMenuBuilder } from 'discord.js';
import { adminEmbed } from './adminUi';
export function partnershipRoleIds(raw:any){try{return JSON.parse(raw||'[]')}catch{return String(raw||'').split(',').filter(Boolean)}}
export async function partnershipSettingsPayload(guild:any,view:string){
  const c=await require('./partnerships').partnershipConfig(guild.id),e=adminEmbed(guild,'atendimento');const components:any[]=[];
  if(view==='channels'){
    e.setTitle('Canais e logs · Parcerias').setDescription('Escolha os destinos deste módulo. Uma seleção vazia remove o destino.');
    for(const [name,label,key,category]of [['panel','Canal do painel','panelChannelId',false],['category','Categoria do atendimento','categoryId',true],['logs','Canal de logs','logChannelId',false],['publish','Canal de divulgação','publishChannelId',false]] as const){
      e.addFields({name:label,value:c[key]?`<#${c[key]}>`:'Não configurado'});
      const s=new ChannelSelectMenuBuilder().setCustomId(`parceria-admin-select:${name}`).setPlaceholder(label).addChannelTypes(category?ChannelType.GuildCategory:ChannelType.GuildText).setMinValues(0).setMaxValues(1);if(c[key])s.setDefaultChannels(c[key]);components.push(new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(s));
    }
  }else{
    e.setTitle('Equipe e cargos · Parcerias').setDescription('Os responsáveis atendem as solicitações. O cargo de parceiro é atribuído ao concluir a parceria.');
    for(const [name,label,values]of [['staff','Responsáveis pelo atendimento',partnershipRoleIds(c.staffRoleIds)],['partner','Cargo de parceiro',c.partnerRoleId?[c.partnerRoleId]:[]]] as const){
      e.addFields({name:label,value:values.map((id:string)=>`<@&${id}>`).join(', ')||'Nenhum'});
      const s=new RoleSelectMenuBuilder().setCustomId(`parceria-admin-select:${name}`).setPlaceholder(label).setMinValues(0).setMaxValues(name==='staff'?10:1);if(values.length)s.setDefaultRoles(values);components.push(new ActionRowBuilder<RoleSelectMenuBuilder>().addComponents(s));
    }
  }
  components.push(new ActionRowBuilder<ButtonBuilder>().addComponents(new ButtonBuilder().setCustomId('admin-task-home:parcerias').setLabel('Voltar · Parcerias').setStyle(ButtonStyle.Secondary)));
  return {content:null,attachments:[],embeds:[e],components,allowedMentions:{parse:[]}};
}
