import { Guild } from "discord.js";
import path from "path";

/** Application emojis leave the server's existing emoji slots untouched. */
export const ADM_EMOJI_NAMES = {
  sistema: "blackout_v2_structure", seguranca: "blackout_v2_security",
  membros: "blackout_v2_members", atendimento: "blackout_v2_support",
  servidor: "blackout_v2_community", staff: "blackout_v2_games", entretenimento: "blackout_v2_social",
} as const;
export type AdminArea = keyof typeof ADM_EMOJI_NAMES;
const FILES: Record<AdminArea, string> = {
  sistema: "estrutura", seguranca: "seguranca", membros: "membros", atendimento: "atendimento",
  servidor: "comunidade", staff: "jogos", entretenimento: "social",
};
export const adminAsset = (...parts: string[]) => path.resolve(__dirname, "../../assets/blackout-ui", ...parts);
export const adminIconFile = (area: AdminArea) => adminAsset("icons", `${FILES[area]}.png`);
const legacy: Record<string, AdminArea> = { campeonatos: "staff", tickets: "atendimento", registro: "membros" };
function areaFor(value: string): AdminArea | undefined {
  return Object.prototype.hasOwnProperty.call(ADM_EMOJI_NAMES, value) ? value as AdminArea : legacy[value];
}
export function admEmoji(guild: Guild, value: string) {
  const area = areaFor(value);
  if (!area) return undefined;
  const emoji = guild.client.application?.emojis.cache.find(e => e.name === ADM_EMOJI_NAMES[area]);
  return emoji?.id;
}
export function adminEmojiImage(guild: Guild, area: AdminArea) {
  const emoji = admEmoji(guild, area);
  return emoji ? `https://cdn.discordapp.com/emojis/${emoji}.png?size=128&quality=lossless` : undefined;
}
// One application-wide queue avoids duplicate creations across guilds and /adm requests.
const pending = new WeakMap<object, Promise<void>>();
const retryAfter = new WeakMap<object, number>();
export async function ensureAdmEmojis(guild: Guild): Promise<void> {
  const application = guild.client.application;
  if (!application?.emojis) return;
  const manager = application.emojis;
  if (Object.values(ADM_EMOJI_NAMES).every(name => manager.cache.some(e => e.name === name))) return;
  const running = pending.get(application);
  if (running) return running;
  if (Date.now() < (retryAfter.get(application) ?? 0)) return;
  const task = (async () => {
    try {
      await manager.fetch();
      for (const area of Object.keys(ADM_EMOJI_NAMES) as AdminArea[]) {
        const name = ADM_EMOJI_NAMES[area];
        if (!manager.cache.some(e => e.name === name)) await manager.create({ attachment: adminIconFile(area), name });
      }
    } catch {
      console.warn("[blackout-ui] Não foi possível preparar os PNGs dos menus. Nova tentativa em 5 minutos.");
      retryAfter.set(application, Date.now() + 5 * 60 * 1000);
    }
  })();
  pending.set(application, task);
  try { await task; } finally { pending.delete(application); }
}
