import { createHash } from "crypto";
export function publicationHash(record: any) {
  const content = { guildId: record.guildId, destination: record.destinationChannelId ?? null,
    title: record.title ?? null, description: record.description ?? null, author: record.author ?? null,
    footer: record.footer ?? null, color: String(record.color || "2B6CB0").replace(/^#/,"").toUpperCase(),
    image: record.imageUrl ?? null, thumbnail: record.thumbnailUrl ?? null, timestamp: !!record.showTimestamp,
    buttons: (record.buttons ?? []).map((b: any) => ({ type:b.type,label:b.label,emoji:b.emoji??null,url:b.url??null,channelId:b.channelId??null })),
  };
  return createHash("sha256").update(JSON.stringify(content)).digest("hex");
}
export function publicationState(record: any) {
  if (!record.publishedMessageId) return "Rascunho salvo";
  if (!record.publishedPayloadHash) return "Publicação anterior · conteúdo a conferir";
  return record.publishedPayloadHash === publicationHash(record) ? "Publicado · sem alterações pendentes" : "Alterações salvas · ainda não publicadas";
}
export function hasMessageContent(record: any) {
  return !!(record.title?.trim() || record.description?.trim() || record.imageUrl || record.thumbnailUrl);
}
