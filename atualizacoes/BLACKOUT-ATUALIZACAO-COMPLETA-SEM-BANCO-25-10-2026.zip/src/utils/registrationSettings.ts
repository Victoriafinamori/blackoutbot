import { PermissionFlagsBits, ChannelType } from 'discord.js';
import { prisma } from '../database/prisma';
import { regConfig } from './registration';
import { ids } from './tickets';
export async function registrationRoleError(guild:any,values:string[],assignable:boolean){
  if(values.length>20)return 'Selecione até vinte cargos.';
  const me=guild.members.me??await guild.members.fetchMe();
  for(const id of values){const r=await guild.roles.fetch(id).catch(()=>null);
    if(!r||r.guild.id!==guild.id||id===guild.id)return 'Escolha cargos válidos deste servidor.';
    if(assignable&&(r.managed||!me.permissions.has(PermissionFlagsBits.ManageRoles)||r.position>=me.roles.highest.position))return `O bot não pode atribuir o cargo ${r.name}. Revise a posição e a permissão Gerenciar cargos.`;
  }return null;
}
export async function updateRegistrationSelection(i:any){
  const [kind,key]=i.customId.split(':');
  const roleKeys=['registeredRoleIds','unregisteredRoleIds','registrarRoleIds','leaderRoleIds'];
  const channelKeys=['logChannelId','panelChannelId','registrationCategoryId','welcomeChannelId'];
  if(kind==='registration-role'&&!roleKeys.includes(key)||kind==='registration-channel'&&!channelKeys.includes(key))return;
  const c=await regConfig(i.guild.id);
  if(kind==='registration-role'){
    const assigning=['registeredRoleIds','unregisteredRoleIds'].includes(key),error=await registrationRoleError(i.guild,i.values,assigning);
    if(error)return i.reply({content:error,ephemeral:true});
    if(assigning){const pages=await prisma.registrationPage.findMany({where:{guildId:i.guild.id}});const added=key==='registeredRoleIds'?i.values:ids(c.registeredRoleIds),removed=key==='unregisteredRoleIds'?i.values:ids(c.unregisteredRoleIds);
      if(removed.some((id:string)=>added.includes(id)||pages.some(p=>ids(p.roleIds).includes(id))))return i.reply({content:'Um cargo não pode ser adicionado pelo formulário e removido na conclusão. Revise as duas configurações.',ephemeral:true});
    }
  }else{
    if(i.values.length>1)return;
    if(i.values[0]){const ch=await i.guild.channels.fetch(i.values[0]).catch(()=>null),category=key==='registrationCategoryId';
      if(!ch||ch.guild.id!==i.guild.id||ch.type!==(category?ChannelType.GuildCategory:ChannelType.GuildText))return i.reply({content:'Escolha um canal válido deste servidor.',ephemeral:true});
      if(!category&&!ch.permissionsFor(i.guild.members.me)?.has([PermissionFlagsBits.ViewChannel,PermissionFlagsBits.SendMessages,PermissionFlagsBits.EmbedLinks]))return i.reply({content:'O bot precisa ver o canal, enviar mensagens e inserir links/embeds nesse destino.',ephemeral:true});
    }
  }
  const data:any={[key]:i.values.join(',')||null};if(key==='welcomeChannelId'&&!i.values.length)data.welcomeEnabled=false;
  await prisma.registrationConfig.update({where:{guildId:i.guild.id},data});
  const view=key==='welcomeChannelId'?'welcome':key==='logChannelId'?'logs':key==='panelChannelId'?'publication':['registeredRoleIds','unregisteredRoleIds'].includes(key)?'roles':'team';
  return require('./registrationAdmin').renderRegistrationAdmin(i,view);
}
