/** Refresh the originating ephemeral panel, including after a modal submission. */
export async function refreshPanel(interaction: any, payload: any) {
  if (interaction.deferred || interaction.replied) return interaction.editReply(payload);
  if (typeof interaction.isFromMessage === "function" && !interaction.isFromMessage()) {
    const { attachments, ...reply } = payload;
    return interaction.reply({ ...reply, ephemeral: true });
  }
  return interaction.update(payload);
}
export async function deferPanel(interaction: any) {
  if (interaction.deferred || interaction.replied) return;
  if (typeof interaction.isFromMessage === "function" && !interaction.isFromMessage()) {
    await interaction.deferReply({ ephemeral: true });
  } else await interaction.deferUpdate();
}
