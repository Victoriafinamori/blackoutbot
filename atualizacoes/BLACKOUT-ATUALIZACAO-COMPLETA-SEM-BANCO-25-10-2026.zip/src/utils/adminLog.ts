import { AdminLogAction, ACTION_LOG_CATEGORY, LOG_CATEGORY_LABELS, LogCategory } from "../structures/enums";
import { Guild, EmbedBuilder } from "discord.js";
import { prisma } from "../database/prisma";
import { baseEmbed } from "./embeds";
import { readLogSettings } from "../logging/config";
import { emitLog, resolveLocalLogChannel, LogContext } from "../logging/delivery";
interface LogParams {guild:Guild;actorId:string;action:AdminLogAction;targetId?:string;details?:string;context?:LogContext}
const groups:Record<LogCategory,string>={MODERATION:"moderation",SECURITY:"security",REINTEGRATION:"reintegration",SYSTEM:"system"};
export async function resolveLogChannel(guild:Guild,category:LogCategory){return resolveLocalLogChannel(guild,groups[category],await readLogSettings(guild.id)).catch(()=>null)}
export async function sendCategoryLog(guild:Guild,category:LogCategory,embed:EmbedBuilder){return emitLog(guild,`${groups[category]}.actions`,embed)}
export async function logAdminAction({guild,actorId,action,targetId,details,context}:LogParams){
 await prisma.adminLog.create({data:{guildId:guild.id,actorId,action,targetId,details}});
 const category=ACTION_LOG_CATEGORY[action]??LogCategory.SYSTEM;
 const key=action===AdminLogAction.MEMBER_JOINED?"member.join":action===AdminLogAction.MEMBER_LEFT?"member.leave":`${groups[category]}.actions`;
 const familyActions=new Set([AdminLogAction.FAMILY_CREATED,AdminLogAction.FAMILY_UPDATED,AdminLogAction.FAMILY_DELETED,AdminLogAction.FAMILY_LEADER_SET,AdminLogAction.FAMILY_CALL_LOCKED,AdminLogAction.FAMILY_CALL_UNLOCKED,AdminLogAction.FAMILY_CALL_LIMIT_SET,AdminLogAction.FAMILY_NOTICE_SENT]);
 const isFamilyAction=familyActions.has(action as any);
 const embed=(await baseEmbed(guild)).setTitle(isFamilyAction?"LOG DE FAMÍLIAS":LOG_CATEGORY_LABELS[category].label).addFields(
 {name:"Ação",value:action,inline:true},{name:key.startsWith("member.")?"Membro":"Responsável",value:`<@${actorId}>`,inline:true},
 ...(targetId?[{name:"Alvo",value:`<@${targetId}>`,inline:true}]:[]),...(details?[{name:"Detalhes",value:details.slice(0,1024)}]:[])).setTimestamp();
 const member=guild.members.cache?.get(actorId);
 let localOverrideId:string|undefined;
 if(isFamilyAction){const config=await prisma.familyConfig.findUnique({where:{guildId:guild.id}}).catch(()=>null);localOverrideId=config?.logChannelId??undefined}
 return emitLog(guild,key,embed,{userId:key.startsWith("member.")?actorId:undefined,bot:key.startsWith("member.")?member?.user.bot:undefined,roleIds:member?.roles.cache.map(r=>r.id),localOverrideId,...context});
}
