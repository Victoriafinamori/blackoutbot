import { Guild } from "discord.js";
import { prisma } from "../database/prisma";
import { getOrCreateGuildConfig } from "../database/guildConfig";
import { logAdminAction } from "./adminLog";
import { AdminLogAction, ModerationActionType } from "../structures/enums";
import { getWordWatchHistory } from "./wordWatch";

export class ModerationError extends Error {}

// Limite do timeout nativo do Discord (28 dias)
const MAX_TIMEOUT_MS = 28 * 24 * 60 * 60 * 1000;

async function notifyMember(guild: Guild, userId: string, message: string) {
  const config = await getOrCreateGuildConfig(guild.id);
  if (!(config.moderationNotifyDm ?? config.notifyDm)) return;
  const user = await guild.client.users.fetch(userId).catch(() => null);
  if (!user) return;
  await user.send(message).catch(() => null);
}

async function publicNotice(guild: Guild, message: string) {
  const config = await getOrCreateGuildConfig(guild.id);
  if (!config.notifyPublicWarns || !config.reportsChannelId) return;
  const channel = guild.channels.cache.get(config.reportsChannelId);
  if (channel && channel.isTextBased()) await channel.send(message).catch(() => null);
}

// -----------------------------
// Advertências (warns)
// -----------------------------
export function getActiveWarns(guildId: string, userId: string) {
  return prisma.warn.findMany({
    where: { guildId, userId, active: true },
    orderBy: { createdAt: "desc" },
  });
}

/**
 * Aplica uma advertência e, se o total de advertências ativas atingir os
 * limites configurados, escala automaticamente para mute ou ban.
 */
export async function warnMember(
  guild: Guild,
  actorId: string,
  userId: string,
  reason: string
) {
  const config = await getOrCreateGuildConfig(guild.id);

  const warn = await prisma.warn.create({
    data: { guildId: guild.id, userId, moderatorId: actorId, reason },
  });

  await logAdminAction({
    guild,
    actorId,
    action: AdminLogAction.WARN_ADDED,
    targetId: userId,
    details: reason,
  });

  await notifyMember(
    guild,
    userId,
    `⚠️ Você recebeu uma advertência em **${guild.name}**.\n**Motivo:** ${reason}`
  );
  await publicNotice(guild, `⚠️ <@${userId}> recebeu uma advertência. **Motivo:** ${reason}`);

  const activeWarns = await getActiveWarns(guild.id, userId);
  const count = activeWarns.length;
  const botId = guild.client.user?.id ?? actorId;

  if (config.maxWarnsBeforeBan > 0 && count >= config.maxWarnsBeforeBan) {
    await banMember(
      guild,
      botId,
      userId,
      `Automático: atingiu ${count} advertência(s) ativa(s).`,
      true
    ).catch(() => null);
  } else if (config.maxWarnsBeforeMute > 0 && count >= config.maxWarnsBeforeMute) {
    await muteMember(
      guild,
      botId,
      userId,
      `Automático: atingiu ${count} advertência(s) ativa(s).`,
      config.autoMuteDurationMinutes,
      true
    ).catch(() => null);
  }

  return { warn, count };
}

export async function removeWarn(guild: Guild, actorId: string, warnId: string) {
  const warn = await prisma.warn.update({ where: { id: warnId }, data: { active: false } });

  await logAdminAction({
    guild,
    actorId,
    action: AdminLogAction.WARN_REMOVED,
    targetId: warn.userId,
  });

  return warn;
}

export async function clearWarns(guild: Guild, actorId: string, userId: string, reason?: string) {
  await prisma.warn.updateMany({
    where: { guildId: guild.id, userId, active: true },
    data: { active: false },
  });

  await logAdminAction({
    guild,
    actorId,
    action: AdminLogAction.WARNS_CLEARED,
    targetId: userId,
    details: reason,
  });
}

// -----------------------------
// Mute (timeout nativo do Discord)
// -----------------------------
export async function muteMember(
  guild: Guild,
  actorId: string,
  userId: string,
  reason: string,
  durationMinutes: number,
  automatic = false
) {
  const member = await guild.members.fetch(userId).catch(() => null);
  if (!member) throw new ModerationError("Membro não encontrado no servidor.");
  if (!member.moderatable) {
    throw new ModerationError(
      "Não tenho permissão para silenciar este membro (cargo mais alto ou dono do servidor)."
    );
  }

  const ms = Math.min(Math.max(durationMinutes, 1) * 60 * 1000, MAX_TIMEOUT_MS);
  await member.timeout(ms, reason);

  const expiresAt = new Date(Date.now() + ms);

  await prisma.mute.create({
    data: { guildId: guild.id, userId, moderatorId: actorId, reason, expiresAt },
  });

  await logAdminAction({
    guild,
    actorId,
    action: AdminLogAction.MEMBER_MUTED,
    targetId: userId,
    details: `${reason}${automatic ? " (automático)" : ""} — ${durationMinutes} min`,
  });

  await notifyMember(
    guild,
    userId,
    `🔇 Você foi silenciado em **${guild.name}** por ${durationMinutes} minuto(s).\n**Motivo:** ${reason}`
  );

  return expiresAt;
}

export async function unmuteMember(guild: Guild, actorId: string, userId: string, reason?: string) {
  const member = await guild.members.fetch(userId).catch(() => null);
  if (member?.moderatable) await member.timeout(null).catch(() => null);

  await prisma.mute.updateMany({
    where: { guildId: guild.id, userId, active: true },
    data: { active: false },
  });

  await logAdminAction({
    guild,
    actorId,
    action: AdminLogAction.MEMBER_UNMUTED,
    targetId: userId,
    details: reason,
  });
}

// -----------------------------
// Kick / Ban / Unban
// -----------------------------
export async function kickMember(guild: Guild, actorId: string, userId: string, reason: string) {
  const member = await guild.members.fetch(userId).catch(() => null);
  if (!member) throw new ModerationError("Membro não encontrado no servidor.");
  if (!member.kickable) {
    throw new ModerationError("Não tenho permissão para expulsar este membro.");
  }

  await notifyMember(guild, userId, `👢 Você foi expulso de **${guild.name}**.\n**Motivo:** ${reason}`);
  await member.kick(reason);

  await prisma.moderationAction.create({
    data: {
      guildId: guild.id,
      userId,
      moderatorId: actorId,
      type: ModerationActionType.KICK,
      reason,
    },
  });

  await logAdminAction({
    guild,
    actorId,
    action: AdminLogAction.MEMBER_KICKED,
    targetId: userId,
    details: reason,
  });
}

export async function banMember(
  guild: Guild,
  actorId: string,
  userId: string,
  reason: string,
  automatic = false
) {
  const member = await guild.members.fetch(userId).catch(() => null);
  if (member && !member.bannable) {
    throw new ModerationError("Não tenho permissão para banir este membro.");
  }

  await notifyMember(guild, userId, `🔨 Você foi banido de **${guild.name}**.\n**Motivo:** ${reason}`);
  await guild.members.ban(userId, { reason });

  await prisma.moderationAction.create({
    data: {
      guildId: guild.id,
      userId,
      moderatorId: actorId,
      type: ModerationActionType.BAN,
      reason: `${reason}${automatic ? " (automático)" : ""}`,
    },
  });

  await logAdminAction({
    guild,
    actorId,
    action: AdminLogAction.MEMBER_BANNED,
    targetId: userId,
    details: reason,
  });
}

export async function unbanMember(
  guild: Guild,
  actorId: string,
  userId: string,
  reason?: string
) {
  try {
    await guild.members.unban(userId, reason);
  } catch {
    throw new ModerationError("Este usuário não está banido (ou já foi desbanido).");
  }

  await prisma.moderationAction.create({
    data: {
      guildId: guild.id,
      userId,
      moderatorId: actorId,
      type: ModerationActionType.UNBAN,
      reason,
    },
  });

  await logAdminAction({
    guild,
    actorId,
    action: AdminLogAction.MEMBER_UNBANNED,
    targetId: userId,
    details: reason,
  });
}

// -----------------------------
// Histórico consolidado
// -----------------------------
export async function getModerationHistory(guildId: string, userId: string) {
  const [warns, mutes, actions, wordWatchHits] = await Promise.all([
    prisma.warn.findMany({
      where: { guildId, userId },
      orderBy: { createdAt: "desc" },
      take: 10,
    }),
    prisma.mute.findMany({
      where: { guildId, userId },
      orderBy: { createdAt: "desc" },
      take: 5,
    }),
    prisma.moderationAction.findMany({
      where: { guildId, userId },
      orderBy: { createdAt: "desc" },
      take: 5,
    }),
    getWordWatchHistory(guildId, userId, 10),
  ]);

  return { warns, mutes, actions, wordWatchHits };
}
