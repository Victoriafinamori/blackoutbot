import { Guild, Client } from "discord.js";
import { prisma } from "../database/prisma";
import { logAdminAction } from "./adminLog";
import { getOrCreateGuildConfig } from "../database/guildConfig";
import { AdminLogAction, MemberStatus, StageChatMode } from "../structures/enums";

export class ReintegrationError extends Error {}

async function setMemberRole(guild: Guild, userId: string, roleId: string | null | undefined, add: boolean) {
  if (!roleId) return;
  const member = await guild.members.fetch(userId).catch(() => null);
  if (!member) return;
  if (add) await member.roles.add(roleId).catch(() => null);
  else await member.roles.remove(roleId).catch(() => null);
}

async function notifyMember(guild: Guild, userId: string, message: string) {
  const config = await getOrCreateGuildConfig(guild.id);
  if (!(config.reintegrationNotifyDm ?? config.notifyDm)) return;
  const user = await guild.client.users.fetch(userId).catch(() => null);
  if (!user) return;
  await user.send(message).catch(() => null);
}

// -----------------------------
// Etapas
// -----------------------------

export function getStages(guildId: string) {
  return prisma.stage.findMany({ where: { guildId }, orderBy: { order: "asc" } });
}

export function getStage(stageId: string) {
  return prisma.stage.findUnique({ where: { id: stageId } });
}

export async function createStage(
  guild: Guild,
  actorId: string,
  data: { name: string; minDays: number; restrictions?: string | null }
) {
  const stages = await getStages(guild.id);
  const nextOrder = stages.length ? Math.max(...stages.map((s: { order: number }) => s.order)) + 1 : 1;

  const stage = await prisma.stage.create({
    data: {
      guildId: guild.id,
      name: data.name,
      minDays: data.minDays,
      restrictions: data.restrictions ?? null,
      order: nextOrder,
    },
  });

  await logAdminAction({
    guild,
    actorId,
    action: AdminLogAction.STAGE_CREATED,
    details: `${stage.name} (ordem ${stage.order})`,
  });

  return stage;
}

export async function updateStage(
  guild: Guild,
  actorId: string,
  stageId: string,
  data: { name?: string; minDays?: number; restrictions?: string | null }
) {
  const stage = await prisma.stage.update({ where: { id: stageId }, data });

  await logAdminAction({
    guild,
    actorId,
    action: AdminLogAction.STAGE_UPDATED,
    details: stage.name,
  });

  return stage;
}

export async function setStageRole(guild: Guild, actorId: string, stageId: string, roleId: string | null) {
  const stage = await prisma.stage.update({ where: { id: stageId }, data: { roleId } });

  await logAdminAction({
    guild,
    actorId,
    action: AdminLogAction.STAGE_UPDATED,
    details: `${stage.name}: cargo ${roleId ? `<@&${roleId}>` : "removido"}`,
  });

  return stage;
}

export async function toggleStageAutoProgress(guild: Guild, actorId: string, stageId: string) {
  const current = await prisma.stage.findUniqueOrThrow({ where: { id: stageId } });
  const stage = await prisma.stage.update({
    where: { id: stageId },
    data: { autoProgress: !current.autoProgress },
  });

  await logAdminAction({
    guild,
    actorId,
    action: AdminLogAction.STAGE_UPDATED,
    details: `${stage.name}: progressão automática ${stage.autoProgress ? "ativada" : "desativada"}`,
  });

  return stage;
}

const CHAT_MODE_CYCLE: StageChatMode[] = [
  StageChatMode.UNRESTRICTED,
  StageChatMode.LOCKED,
  StageChatMode.LIMITED,
];

export function chatModeLabel(mode: string): string {
  switch (mode) {
    case StageChatMode.LOCKED:
      return "🔒 Bloqueado (apenas visualização)";
    case StageChatMode.LIMITED:
      return "✉️ Limitado (mensagens controladas)";
    default:
      return "🟢 Sem restrição";
  }
}

/**
 * Avança o modo de chat da etapa no ciclo: Sem restrição -> Bloqueado ->
 * Limitado -> Sem restrição.
 */
export async function cycleStageChatMode(guild: Guild, actorId: string, stageId: string) {
  const current = await prisma.stage.findUniqueOrThrow({ where: { id: stageId } });
  const index = CHAT_MODE_CYCLE.indexOf(current.chatMode as StageChatMode);
  const next = CHAT_MODE_CYCLE[(index + 1) % CHAT_MODE_CYCLE.length];

  const stage = await prisma.stage.update({ where: { id: stageId }, data: { chatMode: next } });

  await logAdminAction({
    guild,
    actorId,
    action: AdminLogAction.STAGE_CHAT_CONFIG_CHANGED,
    details: `${stage.name}: chat -> ${chatModeLabel(next)}`,
  });

  return stage;
}

/**
 * Define o limite diário de mensagens e/ou o cooldown (em segundos) usados
 * quando a etapa está em modo "Limitado". Passar null limpa o respectivo
 * limite (sem limite de quantidade / sem cooldown).
 */
export async function setStageChatLimits(
  guild: Guild,
  actorId: string,
  stageId: string,
  data: { chatMaxMessagesPerDay: number | null; chatCooldownSeconds: number | null }
) {
  const stage = await prisma.stage.update({
    where: { id: stageId },
    data: {
      chatMaxMessagesPerDay: data.chatMaxMessagesPerDay,
      chatCooldownSeconds: data.chatCooldownSeconds,
    },
  });

  await logAdminAction({
    guild,
    actorId,
    action: AdminLogAction.STAGE_CHAT_CONFIG_CHANGED,
    details:
      `${stage.name}: limite ${stage.chatMaxMessagesPerDay ?? "sem limite"} msg/dia, ` +
      `cooldown ${stage.chatCooldownSeconds ?? "sem"}s`,
  });

  return stage;
}

export async function deleteStage(guild: Guild, actorId: string, stageId: string) {
  const stage = await prisma.stage.delete({ where: { id: stageId } });

  // Renumera as etapas restantes para manter a ordem contígua (1..N)
  const remaining = await getStages(guild.id);
  await prisma.$transaction(
    remaining.map((s: { id: string }, index: number) =>
      prisma.stage.update({ where: { id: s.id }, data: { order: index + 1 } })
    )
  );

  await logAdminAction({
    guild,
    actorId,
    action: AdminLogAction.STAGE_DELETED,
    details: stage.name,
  });

  return stage;
}

export async function moveStage(guild: Guild, actorId: string, stageId: string, direction: "up" | "down") {
  const stages = await getStages(guild.id);
  const index = stages.findIndex((s: { id: string }) => s.id === stageId);
  if (index === -1) throw new ReintegrationError("Etapa não encontrada.");

  const targetIndex = direction === "up" ? index - 1 : index + 1;
  if (targetIndex < 0 || targetIndex >= stages.length) {
    throw new ReintegrationError("Não é possível mover a etapa nessa direção.");
  }

  const current = stages[index];
  const target = stages[targetIndex];

  await prisma.$transaction([
    prisma.stage.update({ where: { id: current.id }, data: { order: target.order } }),
    prisma.stage.update({ where: { id: target.id }, data: { order: current.order } }),
  ]);

  await logAdminAction({
    guild,
    actorId,
    action: AdminLogAction.STAGE_REORDERED,
    details: `${current.name} <-> ${target.name}`,
  });
}

// -----------------------------
// Membros
// -----------------------------

export function getActiveMember(guildId: string, userId: string) {
  return prisma.reintegrationMember.findFirst({
    where: { guildId, userId, status: MemberStatus.ACTIVE },
    include: { currentStage: true },
  });
}

export async function isBlacklisted(guildId: string, userId: string) {
  const entry = await prisma.blacklist.findUnique({ where: { guildId_userId: { guildId, userId } } });
  return !!entry;
}

export async function insertMember(guild: Guild, actorId: string, userId: string) {
  if (await isBlacklisted(guild.id, userId)) {
    throw new ReintegrationError("Este usuário está na blacklist e não pode ser inserido.");
  }
  if (await getActiveMember(guild.id, userId)) {
    throw new ReintegrationError("Este usuário já está em reintegração.");
  }

  const stages = await getStages(guild.id);
  if (!stages.length) {
    throw new ReintegrationError("Cadastre ao menos uma etapa antes de inserir membros.");
  }
  const firstStage = stages[0];

  const existingRecord = await prisma.reintegrationMember.findUnique({
    where: { guildId_userId: { guildId: guild.id, userId } },
  });

  const member = existingRecord
    ? await prisma.reintegrationMember.update({
        where: { id: existingRecord.id },
        data: {
          status: MemberStatus.ACTIVE,
          currentStageId: firstStage.id,
          stageEnteredAt: new Date(),
          notes: null,
        },
      })
    : await prisma.reintegrationMember.create({
        data: {
          guildId: guild.id,
          userId,
          status: MemberStatus.ACTIVE,
          currentStageId: firstStage.id,
        },
      });

  await setMemberRole(guild, userId, firstStage.roleId, true);
  await logAdminAction({
    guild,
    actorId,
    action: AdminLogAction.MEMBER_INSERTED,
    targetId: userId,
    details: `Etapa inicial: ${firstStage.name}`,
  });
  await notifyMember(guild, userId, `Você foi inserido no processo de reintegração de **${guild.name}**, na etapa **${firstStage.name}**.`);

  return member;
}

export async function removeMember(guild: Guild, actorId: string, userId: string, reason?: string) {
  const member = await getActiveMember(guild.id, userId);
  if (!member) throw new ReintegrationError("Este usuário não está em reintegração.");

  await setMemberRole(guild, userId, member.currentStage?.roleId, false);
  await prisma.reintegrationMember.update({
    where: { id: member.id },
    data: { status: MemberStatus.REMOVED, notes: reason ?? null },
  });

  await logAdminAction({
    guild,
    actorId,
    action: AdminLogAction.MEMBER_REMOVED,
    targetId: userId,
    details: reason,
  });
  await notifyMember(guild, userId, `Você foi removido do processo de reintegração de **${guild.name}**.`);
}

export async function blacklistMember(guild: Guild, actorId: string, userId: string, reason?: string) {
  const activeMember = await getActiveMember(guild.id, userId);
  if (activeMember) {
    await setMemberRole(guild, userId, activeMember.currentStage?.roleId, false);
    await prisma.reintegrationMember.update({
      where: { id: activeMember.id },
      data: { status: MemberStatus.REMOVED },
    });
  }

  await prisma.blacklist.upsert({
    where: { guildId_userId: { guildId: guild.id, userId } },
    update: { reason, addedBy: actorId },
    create: { guildId: guild.id, userId, reason, addedBy: actorId },
  });

  const blacklistRole = await prisma.systemRole.findUnique({
    where: { guildId_type: { guildId: guild.id, type: "BLACKLIST" } },
  });
  await setMemberRole(guild, userId, blacklistRole?.roleId, true);

  await logAdminAction({
    guild,
    actorId,
    action: AdminLogAction.MEMBER_BLACKLISTED,
    targetId: userId,
    details: reason,
  });
}

export async function unblacklistMember(guild: Guild, actorId: string, userId: string) {
  const entry = await prisma.blacklist.findUnique({ where: { guildId_userId: { guildId: guild.id, userId } } });
  if (!entry) throw new ReintegrationError("Este usuário não está na blacklist.");

  await prisma.blacklist.delete({ where: { id: entry.id } });

  const blacklistRole = await prisma.systemRole.findUnique({
    where: { guildId_type: { guildId: guild.id, type: "BLACKLIST" } },
  });
  await setMemberRole(guild, userId, blacklistRole?.roleId, false);

  await logAdminAction({
    guild,
    actorId,
    action: AdminLogAction.MEMBER_UNBLACKLISTED,
    targetId: userId,
  });
}

export async function progressMember(
  guild: Guild,
  actorId: string,
  userId: string,
  direction: "advance" | "regress"
) {
  const member = await getActiveMember(guild.id, userId);
  if (!member || !member.currentStage) {
    throw new ReintegrationError("Este usuário não está em reintegração.");
  }

  const stages = await getStages(guild.id);
  const index = stages.findIndex((s: { id: string }) => s.id === member.currentStageId);
  const targetIndex = direction === "advance" ? index + 1 : index - 1;

  if (direction === "regress" && targetIndex < 0) {
    throw new ReintegrationError("Este membro já está na primeira etapa.");
  }

  await setMemberRole(guild, userId, member.currentStage.roleId, false);

  if (direction === "advance" && targetIndex >= stages.length) {
    // Concluiu a última etapa
    await prisma.reintegrationMember.update({
      where: { id: member.id },
      data: { status: MemberStatus.COMPLETED, currentStageId: null },
    });
    await logAdminAction({
      guild,
      actorId,
      action: AdminLogAction.MEMBER_COMPLETED,
      targetId: userId,
    });
    await notifyMember(guild, userId, `🎉 Você concluiu o processo de reintegração em **${guild.name}**!`);
    return { completed: true };
  }

  const target = stages[targetIndex];
  await prisma.reintegrationMember.update({
    where: { id: member.id },
    data: { currentStageId: target.id, stageEnteredAt: new Date() },
  });
  await setMemberRole(guild, userId, target.roleId, true);

  await logAdminAction({
    guild,
    actorId,
    action: direction === "advance" ? AdminLogAction.MEMBER_PROGRESSED : AdminLogAction.MEMBER_REGRESSED,
    targetId: userId,
    details: `${member.currentStage.name} -> ${target.name}`,
  });
  await notifyMember(
    guild,
    userId,
    `Sua etapa de reintegração em **${guild.name}** foi atualizada para **${target.name}**.`
  );

  return { completed: false, stage: target };
}

export async function addEvaluation(
  guild: Guild,
  actorId: string,
  userId: string,
  approved: boolean,
  notes?: string
) {
  const member = await getActiveMember(guild.id, userId);
  if (!member || !member.currentStageId) {
    throw new ReintegrationError("Este usuário não está em reintegração.");
  }

  const evaluation = await prisma.evaluation.create({
    data: {
      guildId: guild.id,
      memberId: member.id,
      stageId: member.currentStageId,
      evaluatorId: actorId,
      approved,
      notes,
    },
  });

  await logAdminAction({
    guild,
    actorId,
    action: AdminLogAction.EVALUATION_ADDED,
    targetId: userId,
    details: `${approved ? "Aprovado" : "Reprovado"}${notes ? ` — ${notes}` : ""}`,
  });

  return evaluation;
}

// -----------------------------
// Progressão automática
// -----------------------------

/**
 * Verifica todos os membros ativos com progressão automática habilitada
 * na etapa atual e avança quem já cumpriu os dias mínimos. Deve ser
 * chamado periodicamente (ver index.ts).
 */
export async function runAutoProgression(client: Client) {
  const candidates = await prisma.reintegrationMember.findMany({
    where: { status: MemberStatus.ACTIVE },
    include: { currentStage: true },
  });

  for (const member of candidates) {
    const stage = member.currentStage;
    if (!stage || !stage.autoProgress) continue;

    const daysInStage = (Date.now() - new Date(member.stageEnteredAt).getTime()) / 86_400_000;
    if (daysInStage < stage.minDays) continue;

    const guild = client.guilds.cache.get(member.guildId);
    if (!guild) continue;

    await progressMember(guild, client.user?.id ?? "SYSTEM", member.userId, "advance").catch((err) =>
      console.error(`[auto-progression] Falha ao avançar ${member.userId}:`, err)
    );
  }
}
