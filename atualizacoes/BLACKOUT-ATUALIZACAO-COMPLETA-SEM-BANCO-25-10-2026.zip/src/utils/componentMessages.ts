import * as D from "discord.js";
/** Components V2 flags cannot be removed. Convert legacy navigation only on that message. */
export function asComponentsV2(payload: any) {
  if (!payload || typeof payload !== "object") return payload;
  if (Number(payload.flags) & D.MessageFlags.IsComponentsV2) return payload;
  const components: any[] = [];
  if (payload.content)
    components.push({ type: 10, content: String(payload.content) });
  for (const item of payload.embeds || []) {
    const e = item.toJSON ? item.toJSON() : item,
      blocks: any[] = [];
    const lines = [
      e.author?.name ? "-# " + e.author.name : null,
      e.title ? "## " + e.title : null,
      e.description,
    ]
      .filter(Boolean)
      .join("\n");
    if (e.thumbnail?.url && lines)
      blocks.push({
        type: 9,
        components: [{ type: 10, content: lines }],
        accessory: { type: 11, media: { url: e.thumbnail.url } },
      });
    else if (lines) blocks.push({ type: 10, content: lines });
    for (const f of e.fields || [])
      blocks.push({ type: 10, content: "**" + f.name + "**\n" + f.value });
    if (e.image?.url)
      blocks.push({ type: 12, items: [{ media: { url: e.image.url } }] });
    if (e.footer?.text)
      blocks.push({ type: 10, content: "-# " + e.footer.text });
    if (blocks.length)
      components.push({
        type: 17,
        accent_color: e.color ?? 0xd71935,
        components: blocks,
      });
  }
  components.push(
    ...(payload.components || []).map((c: any) => (c.toJSON ? c.toJSON() : c)),
  );
  return {
    ...payload,
    content: null,
    embeds: [],
    flags: (Number(payload.flags) || 0) | D.MessageFlags.IsComponentsV2,
    components,
    allowedMentions: payload.allowedMentions || { parse: [] },
  };
}
export function compatibleInteraction<T extends D.Interaction>(
  interaction: T,
): T {
  if (!(interaction as any).message?.flags?.has(D.MessageFlags.IsComponentsV2))
    return interaction;
  let source = true;
  return new Proxy(interaction, {
    get(target: any, prop) {
      if (["reply", "deferReply"].includes(String(prop)))
        return (...args: any[]) => {
          source = false;
          return target[prop](...args);
        };
      if (prop === "deferUpdate")
        return (...args: any[]) => {
          source = true;
          return target.deferUpdate(...args);
        };
      if (prop === "update")
        return (p: any) => {
          source = true;
          return target.update(asComponentsV2(p));
        };
      if (prop === "editReply")
        return (p: any) => target.editReply(source ? asComponentsV2(p) : p);
      const value = Reflect.get(target, prop, target);
      return typeof value === "function" ? value.bind(target) : value;
    },
  });
}
