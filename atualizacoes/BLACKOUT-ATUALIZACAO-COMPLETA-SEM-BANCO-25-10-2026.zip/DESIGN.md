---
name: BLACKOUT — Administração Discord
description: Administração de comunidades no universo preto, branco e vermelho do BLACKOUT.
colors:
  blackout-red: "#D71935"
---

# Design System: BLACKOUT

## Overview

**Creative North Star: "BLACKOUT no Discord"**

Esta documentação registra a extensão aprovada da identidade existente: preto, branco e vermelho, com ícones de esmalte branco e vermelho sobre grafite. O modo é Operate: o administrador organiza a comunidade por área, identifica o contexto e chega à ação com descrições curtas. A personalização pertence ao servidor do comprador e mostra o resultado real da edição na própria mensagem.

A interface é composta por embeds, selects e botões nativos do Discord. O aplicativo controla conteúdo, cor da embed e imagens; o Discord controla fontes, fundos, espaçamento, cantos, foco e cores dos controles. A aparência do HTML de revisão é uma simulação, não uma implementação de CSS no Discord.

**Key Characteristics:**
- Identidade BLACKOUT reconhecível por banner, vermelho e PNGs aprovados.
- Hierarquia de central, área e módulo, com retorno explícito.
- Texto em português, direto e orientado à configuração.
- Controles e comportamento visual nativos do Discord.
- Perfil local e prévia real, com salvamento separado da publicação.

Escopo: telas administrativas. As mensagens públicas e embeds salvas continuam configuráveis por `baseEmbed()` e pelos respectivos construtores; não recebem uma reformulação global.

## Colors

### Primary

- **Vermelho BLACKOUT** (`colors.blackout-red`): acento recorrente da embed administrativa definido por `BLACKOUT_RED` em `src/utils/adminUi.ts` e seu equivalente de produção.

### Neutral

Branco, grafite e preto compõem as imagens aprovadas; não constituem uma escala CSS controlada pelo bot. Textos e superfícies nativas seguem o tema do cliente Discord. Não fixar valores extraídos da simulação como tokens de produção.

**The State Meaning Rule.** Preserve cores de estado com significado operacional nos módulos; a identidade vermelha não elimina sinais de sucesso, alerta ou erro.

## Typography

O Discord escolhe família, tamanhos, pesos e entrelinhas. A aplicação estabelece a hierarquia semântica: autor BLACKOUT e contexto, título, descrição, campos e rodapé. Não há token próprio de fonte ou escala tipográfica.

Use títulos claros sem emojis decorativos iniciais: `AdminEmbed.setTitle()` remove esses prefixos. Os ícones de categoria têm uma função contextual, separados do título. Descrições explicam o destino e a tarefa; rótulos não devem depender apenas de cor ou ícone.

## Layout

A central apresenta orientação inicial, banner aprovado e um select com sete áreas numeradas. A sequência acompanha a construção e gestão da comunidade:

1. Personalização do bot
2. Equipe e proteção
3. Entrada e evolução
4. Atendimento
5. Comunidade e atividade
6. Jogos e eventos
7. Social e entretenimento

Cada área apresenta introdução, thumbnail contextual, resumo dos módulos, select e retorno à central. Há 28 destinos canônicos entre as sete áreas. Personalização do bot contém somente Perfil neste servidor, Padrão das mensagens e Mensagens Personalizadas / Embeds. Cargos automáticos ficam em Entrada e evolução; canais de logs em Logs e auditoria, dentro de Equipe e proteção. Avisos e preferências de comunicação ficam nos módulos responsáveis: moderação e reintegração mantêm suas próprias opções de DM. Módulos retornam à área pertinente: cargos automáticos, registro, oficialização e reintegração para Entrada e evolução; Free Fire, Bingo e Sorteios para Jogos e eventos.

Não há breakpoint, largura de painel ou escala de espaçamento controlada pelo bot. O Discord organiza embeds e componentes em desktop e celular. Mantenha textos concisos e respeite os limites do payload nativo.

## Elevation & Depth

A profundidade das superfícies pertence ao Discord. Não há sombra de interface configurada pelo bot. Os PNGs aprovados trazem volume de esmalte, bordas escuras e brilho local como parte da imagem; isso não autoriza sombras CSS ou novos efeitos na interface nativa.

## Shapes

Os sete ícones usam silhuetas compactas, bordas arredondadas e volume sobre fundo transparente. São PNGs RGBA de 128 × 128, abaixo de 256 KiB, em `assets/blackout-ui/icons/`. Preserve transparência, margem e leitura em tamanho de emoji. Cantos e contornos de embeds, selects e botões são definidos pelo Discord.

## Components

### Embed administrativa

`adminEmbed(guild, area)` aplica o acento, autor `BLACKOUT · área`, thumbnail quando o emoji da aplicação está disponível e rodapé `BLACKOUT · Administração`. A central e as áreas especializam o autor e rodapé conforme o contexto; consistência não significa texto idêntico em todas as telas.

A central usa `BLACKOUT · Administração`, título `Central do servidor`, banner e rodapé `Organize · Proteja · Conecte`. As áreas usam `BLACKOUT · Central do servidor`, título contextual e contagem de módulos no rodapé. A primeira área se apresenta como `Personalização do bot`.

### Perfil local e prévia na mesma mensagem

Perfil neste servidor mostra nome, avatar e banner locais. Alterações usam exclusivamente `guild.members.editMe` no servidor autorizado; a resposta atualiza imediatamente a embed e a reabertura busca o perfil local atualizado. Não há fallback para nome, avatar ou banner da conta global.

Padrão das mensagens mostra a embed real de `baseEmbed()`, incluindo cor, autor, rodapé e miniatura configurados por servidor. Mensagens Personalizadas / Embeds mostram o resultado de `buildCustomEmbedMessage()`, preservando o visual individual do modelo. A decoração administrativa não deve encobrir essas prévias: identificação e estado ficam no conteúdo da mesma mensagem, fora da embed pública.

`panelInteraction` atualiza a mensagem de origem após modals e seleções. Editar não cria uma cadeia de painéis ou uma embed separada com uma lista de campos preenchidos. Remover valores visuais também deve aparecer na prévia. Limpe conteúdo e anexos anteriores nas transições apropriadas.

**The Same Message Rule.** Mostre o resultado real da edição na mensagem de origem, preservando o conteúdo público da embed e o contexto dos controles.

### Editor e estado de publicação

O select do editor segue Conteúdo → Imagens e cor → Botões → Canal de destino. Renomear, duplicar e excluir ficam em Mais opções. A edição salva o modelo e atualiza a prévia; publicar ou atualizar a publicação exige ação explícita. O botão opcional `Ver prévia` continua disponível, sem ser necessário para enxergar as edições na própria embed. O botão Ver prévia abre a visualização focada da mensagem e dos links, com paginação e Voltar ao editor, sem publicar.

Mostre estados distintos para rascunho, alterações salvas ainda não publicadas e publicação sem pendências. O estado compara o conteúdo com `publishedPayloadHash`; nomes internos e relógio da prévia não devem criar pendências falsas. Publicações antigas sem hash indicam conteúdo a conferir. Ao mudar o destino, preserve a mensagem anterior e informe a publicação no novo canal. Uma falha de permissão não equivale a mensagem apagada nem autoriza duplicação silenciosa.

Listas de modelos e links da prévia são paginadas. A prévia admite até 25 botões, mostrando links em grupos de até dez para respeitar as cinco linhas de componentes do Discord; a publicação mantém todos os botões.

**The Explicit Publication Rule.** Salvar atualiza o modelo e a prévia; somente a ação explícita de publicação altera a mensagem pública.

### Equipe, proteção e moderação

Equipe e proteção tem quatro entradas: **Equipe e permissões**, **Proteção automática**, **Moderação de membros** e **Logs e auditoria**. Separe configuração preventiva de uma intervenção sobre um membro; não misture filtros com punições manuais na mesma entrada.

Equipe e permissões distingue Administradores do bot (acesso total), Permissões por função (três ações existentes) e Cargos usados pelo bot (oito associações existentes). As seleções salvam e reabrem o mesmo seletor com resumo atualizado. Diferencie cargos de acesso de cargos que o bot precisa atribuir; apenas estes últimos exigem capacidade de concessão. Mostre cargos excluídos e seleções inválidas com orientação contextual.

Proteção automática mantém seis filtros, listas, limites e monitoramento. A resposta é uma escolha explícita: **apagar**, **apagar e advertir** ou **apagar e silenciar**. Não use um botão que alterne respostas sem mostrar a escolha. Monitoramento é observacional, restrito à reintegração. As alterações atualizam a embed de origem.

Moderação de membros começa pela seleção do membro. A mesma embed mostra advertências, silenciamentos, histórico de ações e ocorrências de palavras, com ações e reversões pareadas. Hierarquia, permissão e capacidade nativa do Discord determinam estados indisponíveis; explique o impedimento e preserve o contexto do membro.

Formulários manuais preparam uma revisão, inclusive nos IDs legados; não executam punição nem reversão. A revisão mostra membro, ação, motivo, duração quando aplicável, avisos e limites de escalonamento. Confirmar executa; cancelar não altera o membro. O retorno permanece na mensagem de origem.

A confirmação expira em dez minutos, pertence ao autor, servidor e mensagem originais, e pode ser consumida uma única vez. Reinício invalida revisões abertas. Revalide acesso, hierarquia, capacidade do bot e política no momento de confirmar; mudanças relevantes de configuração ou contagem de advertências exigem nova revisão. Após falha de API ou registro, oriente consultar o histórico antes de repetir: Discord e SQLite não formam uma transação atômica.

**The Review Before Action Rule.** Formulários manuais abrem revisão na mesma mensagem; somente uma confirmação válida aplica a ação ou reversão sobre o membro.

### Central de logs

Logs e auditoria abre a central com quatro tarefas principais: **O que registrar**, **Onde enviar**, **O que ignorar** e **Testar envio**. Ações da equipe e Logs de Tickets e Registro são consultas ou atalhos secundários. Estes destinos internos não alteram as sete áreas nem os 28 destinos canônicos do painel. Use a embed administrativa de Equipe e proteção com o PNG de escudo aprovado; seleções e formulários atualizam a mesma mensagem. O resumo inicial é compacto: nomes de servidor/canal ativos, total de eventos e pendências reais de configuração ou autorização. Um destino externo opcional e inativo não é erro. A leitura confere rotas ativas, sem garantir entrega. IDs e detalhes de autorização ficam em formulários e Detalhes e ajuda.

O que registrar oferece 24 tipos em seis categorias visíveis: Membros, Calls, Mensagens, Moderação, Servidor e segurança e Sistemas do bot. O alias visual `bot` reúne os grupos persistidos `system` e `reintegration`; os sete grupos de armazenamento permanecem intactos. O seletor desse alias altera explicitamente as flags dos dois grupos, enquanto os IDs legados de cada grupo continuam independentes. Cada categoria usa seleção múltipla, com os valores salvos marcados; uma seleção vazia desliga seus eventos. Os seis tipos legados permanecem ligados inicialmente; novos eventos começam desligados. Não apresente um evento recém-adicionado como coleta já ativa.

Onde enviar reúne os modos **LOCAL**, **EXTERNAL** e **BOTH**, canal geral local, configuração/teste externos e destinos por categoria. Os IDs antigos de Organização dos canais abrem essa tela unificada. Ela permite um canal geral ou destinos específicos para cada um dos sete grupos persistidos, tanto no servidor local quanto no externo. Em Sistemas do bot, uma segunda escolha distingue operações do bot e Reintegração, preservando destinos próprios; salvar um canal externo retorna à tela que mostra o canal alterado. Um destino específico prevalece sobre o geral; limpar um override local usa o geral sem ressuscitar o destino legado da categoria. A configuração externa exige servidor e canal geral; canais por grupo são opcionais. Trocar o servidor externo limpa overrides anteriores. Não crie canais automaticamente nem altere as configurações independentes de Tickets e Registro.

A configuração requer administração autorizada do bot na origem; o autorizador externo precisa de Administrador ou Gerenciar Servidor no destino. O bot deve estar nos dois servidores e ter acesso de envio e embeds no canal. Cada envio externo revalida o mesmo autorizador nos dois servidores; revogação bloqueia o envio até nova configuração por administrador autorizado. Mostre destinos inválidos ou permissões ausentes com orientação. Falha externa não envia dados ao local no modo EXTERNAL; BOTH tenta cada destino independentemente.

**The Explicit Destination Rule.** Respeite o modo e a autorização vigente: um destino externo indisponível nunca autoriza fallback silencioso para o servidor local.

Em Testar envio, a ação principal testa a configuração atual; **Verificar permissões** é acesso secundário ao diagnóstico técnico. Teste externo envia um exemplo somente ao destino externo configurado, inclusive antes de ativar o modo externo, sem alterar eventos ou modo. O teste geral segue o modo atual e o destino de Sistemas do bot. Distinga esses testes de configuração salva e ativação. As embeds enviadas identificam origem, categoria e horário, com menções desativadas.

O que ignorar oferece explicação curta, ajuda contextual e exclusão de outros bots, até 25 canais/categorias e até 25 cargos. O próprio bot é sempre ignorado nos eventos de conteúdo e movimentação para evitar repetição. Categorias incluem ancestrais disponíveis em cache. Com filtros de cargo ativos, eventos sem cargos conhecidos são omitidos conservadoramente; esse aviso importante permanece visível na própria tela, sem depender de abrir a ajuda. Exclusão em massa filtra os autores antes de gerar um único resumo com amostra de até dez mensagens; não é transcript completo.

Verificar permissões reúne intents, auditoria, limites de fila e diagnóstico técnico; explicações extensas permanecem secundárias à tarefa. A ajuda explicita limites de conteúdo, cache, permissões e envio. Texto anterior de edição só existe quando disponível em cache; uma busca posterior não o recupera. Mensagens excluídas preservam somente dados disponíveis, e links de anexos podem deixar de funcionar. Eventos nativos sem executor conhecido não devem atribuir a ação ao autor da mensagem ou ao membro movido. Banimentos externos usam executor confirmado pela auditoria. Não há gravação de áudio nem arquivo de todas as mensagens.

O diagnóstico mostra falhas e descartes da fila em memória, limitada a 300 eventos totais e 100 por origem. Fila e contadores não são persistentes e se perdem no reinício; não prometa entrega durável nem repetição automática após falha incerta. **Ações da equipe** mantém a consulta aos últimos 15 eventos de `AdminLog`; esse histórico administrativo permanece no SQLite mesmo com encaminhamento desativado e não representa toda a auditoria nativa do Discord.

As categorias reutilizam os PNGs aprovados nos selects e thumbnails: Membros usa `membros`, Calls usa `atendimento`, Mensagens usa `entretenimento` (arquivo `social.png`), Moderação e Servidor e segurança usam `seguranca`, e Sistemas do bot usa `sistema` (arquivo `estrutura.png`). A central mantém o escudo. Sem emoji provisionado, preserve o rótulo textual; não crie novos ativos ou substitutos Unicode.

Logs de Tickets e Registro abre os controllers reais de produção para canais de Tickets, relatórios externos e configurações gerais de Registro. O adaptador preserva a mensagem já reconhecida, acrescentando retorno Central de logs dentro do limite nativo de cinco linhas de componentes. A central não reescreve configurações dos módulos; retornos internos seguintes continuam próprios do módulo. Preserve os controllers exclusivos de `app/`, sem substituí-los por versões incompletas de `src/`.

**The Task First Rule.** Mostre a tarefa e os destinos ativos primeiro; mantenha IDs, ajuda extensa e diagnóstico técnico em acessos secundários, preservando avisos que afetam a decisão atual.

### Seleção de área e módulo

Use selects nativos, rótulos explícitos e descrições informativas. A central numera as sete áreas na ordem de `ADM_SECTION_ORDER`; o select de módulo reutiliza o ícone da área. O placeholder de Entrada e evolução é `Escolha uma etapa da jornada`.

### Retorno

`adminBackRow()` usa botão nativo Secondary: `Central do servidor` na área e `Voltar · nome da área` nos módulos. Preserve destinos e a checagem de permissão de `admNavigation`; `campeonatos` é alias legado de `staff`, não uma oitava categoria. Não apresentar botões de retorno como ações destrutivas ou primárias.

### Banner e ícones aprovados

O banner é `assets/blackout-ui/header.png`. Os sete ícones aprovados são `estrutura.png`, `seguranca.png`, `membros.png`, `atendimento.png`, `comunidade.png`, `jogos.png` e `social.png`. O arquivo `estrutura.png` continua sendo o ícone de Personalização do bot, sem exigir renomear o ativo ou o identificador interno `sistema`. Estes arquivos são os originais visuais aprovados nesta entrega; não há licença externa ou autor adicional estabelecido aqui.

`admEmojis` prepara emojis da aplicação com nomes `blackout_v2_*`; não consome os slots de emoji do servidor nem apaga emojis antigos. Se a preparação falhar, o menu continua com texto, sem substituir os PNGs por emojis padrão. As telas centrais enviam as imagens locais como anexos; ao entrar nos módulos, os anexos anteriores são removidos. Preserve esse ciclo para evitar imagens soltas.

## Do's and Don'ts

### Do:

- **Do** reutilize `adminEmbed` na navegação administrativa, os builders reais nas prévias, `panelInteraction`, `ADM_SECTIONS`, `adminBackRow` e o mapeamento de ícones ao ampliar a interface.
- **Do** mantenha as sete áreas, os 28 destinos canônicos, a ordem e os retornos coerentes entre fonte `src/` e produção `app/`.
- **Do** mantenha membro, histórico, revisão e retorno na mesma mensagem; explique ações indisponíveis por permissão ou hierarquia.
- **Do** diferencie modo, destino, teste e ativação dos logs; mostre limites e indisponibilidade sem atribuir dados desconhecidos.
- **Do** preserve textos curtos, rótulos acessíveis e cores de estado com significado.
- **Do** use os PNGs aprovados, mantendo transparência e legibilidade em tamanho reduzido.
- **Do** valide payloads e limites com `node --test tests/admin-ui.test.cjs tests/personalization.test.cjs tests/security.test.cjs tests/log-center.test.cjs` ao alterar componentes.

### Don'ts:

- **Don't** aplique personalização ao perfil global da conta nem use alterações globais como fallback.
- **Don't** redirecione logs externos silenciosamente para o local ou prometa recuperação de conteúdo e entrega durável fora das capacidades reais.
- **Don't** execute punições ou reversões no envio do formulário, reutilize confirmações ou ignore mudanças de política após a revisão.
- **Don't** publique automaticamente ao salvar nem substitua a prévia real por um resumo de campos.

- **Don't** trate fontes, fundos, botões, seleção, espaçamento ou breakpoints da simulação como customizações reais do Discord.
- **Don't** aplique o tema administrativo globalmente às mensagens públicas personalizadas ou sobrescreva preferências salvas.
- **Don't** troque os ícones aprovados por emojis Unicode ou crie uma oitava área para um alias legado.
- **Don't** substitua `app/` por `dist/`; preserve módulos exclusivos da produção.

Referências de implementação: `src/utils/adminUi.ts`, `src/utils/admPanel.ts`, `src/utils/admEmojis.ts`, `src/utils/panelInteraction.ts`, `src/utils/embedPublication.ts`, os builders de personalização e seus equivalentes em `app/`. Contexto técnico e limites de validação: `docs/TECHNICAL.md`, seção 6 e seção Central de logs configurável e envio externo; implementação da central em `src/logging/` e equivalentes `app/`. A migração aditiva `20261021180000_personalization_module_notifications` acrescenta preferências nullable de DM por módulo e o hash de publicação; valores não configurados preservam o fallback anterior por servidor. Esta documentação não altera schema ou dados.

As quatro suítes de administração, personalização, segurança e central de logs passaram 75 testes offline. A revisão independente final inspecionou as dez capturas do refinamento, executou os 75 testes e retornou SHIP. As verificações de revogação de acesso na origem e filtragem por cargos na exclusão em massa permanecem preservadas. O TypeScript global mantém 38 erros preexistentes, sem erros adicionais. As alterações anteriores de Personalização e Equipe e proteção permanecem; a central acrescenta a tabela independente `ServerLogSettings` pela migração aditiva `20261021220000_server_log_center`. A migração anterior de personalização continua necessária. O refinamento de navegação não acrescenta schema, migration, dependências ou comandos; o pacote cumulativo mantém as duas migrations anteriores. O SQL novo foi verificado em cópia isolada do banco, preservando as 123 tabelas existentes, sem alterar o original; não houve execução do CLI Prisma nativo.

`BLACKOUT-central-logs-refinada.html`, em `/workspace/blackoutbot-review/`, apresenta 12 vistas de antes/depois baseadas nos builders reais. As dez capturas `logs-refino-{desktop,mobile}-{home,voice,destination,filters,modules}.png` documentam a navegação aprovada. `BLACKOUT-central-logs.html` e suas doze capturas `logs-{desktop,mobile}-{home,voiceAfter,destination,filters,edited,diagnostic}.png` são referências da etapa anterior; a navegação atual segue o refinamento de quatro tarefas. `BLACKOUT-equipe-protecao-implementada.html` e suas dez capturas `equipe-{desktop,mobile}-{inicio,protecao,membro,revisao,logs}.png` continuam como referência do refinamento anterior; os controles de logs atuais seguem a nova central. `BLACKOUT-personalizacao-ao-vivo.html` e suas oito capturas `refino-{desktop,mobile}-{personalizacao,perfil-depois,padrao-depois,mensagem-depois}.png` documentam a personalização. Todas são simulações com dados ilustrativos; os nomes não implicam conexão ao vivo. Não houve execução externa da API Discord, punições ou logs reais, edição real de perfil, cadastro real de emojis, consulta ao banco vivo ou deploy na Square Cloud.


## Refinamento das demais áreas — 21/10/2026

A navegação das sete áreas e os 28 destinos permanecem. Cargos e automações é o novo nome da entrada que reúne cargos de chegada e o acesso à transferência programada; Reintegração concentra etapas, canais e membros. Menus de módulos usam tarefas claras e retorno secundário para sua área; configurações destrutivas mantêm os handlers e as confirmações existentes. Nenhum botão desabilitado é promovido a opção ativa.

Registro organiza cinco tarefas: Formulário, Cargos após registro, Mensagens e publicação, Atendimento e equipe e Logs. Categoria privada pertence ao atendimento; canal público pertence à publicação. Gerenciar página reúne pergunta, descrição, obrigatoriedade, ordem e exclusão. Boas-vindas continuam explicitamente após registro. Testar é acesso secundário da entrada; comandos e estatísticas não repetem esse atalho. Pendências são derivadas da configuração básica; não representam garantia de permissões ou entrega externa.

Use a própria mensagem para mostrar as mudanças. Prévia pública conserva textos, imagens, rodapé e botão do modelo; contexto e controles ficam fora da embed pública. Editar aparência não dispara publicação imediata; escolha Publicar / atualizar para mudar a mensagem no canal. As ações públicas de exemplo ficam desabilitadas nos editores. Oficialização e Rádio apresentam resumos compactos; detalhes permanecem nas tarefas correspondentes. Seleção de ordem da rádio é explícita, com os valores salvos marcados.

Evidências: `BLACKOUT-refinamento-completo.html` apresenta 50 vistas extraídas dos builders reais, com nomes e dados ilustrativos. Os seletores superiores navegam na demonstração; os controles de Discord dentro da mensagem são referências visuais. Foram inspecionadas capturas em 1040 e 420 px, sem console errors ou overflow. As cinco suítes passam 107 testes offline. Nenhum envio ou alteração real foi realizado no Discord.


## Padrão atual — Mensagens V2 e reação (23/10/2026)

O estado vigente tem sete áreas e 29 destinos (as contagens anteriores são históricas). Central e subáreas mostram uma apresentação curta; categorias, descrições e PNGs ficam nos seletores. Não duplicar a navegação em uma lista numerada no corpo da embed.

O editor V2 exibe o documento público real, com rótulo curto de contexto e controles separados. Salvar o formulário atualiza a prévia na mesma mensagem. O seletor escolhe o bloco; adicionar/reorganizar/nome e cor ficam próximos da edição. Salvar modelo, Publicar e Ver prévia têm funções distintas. Documentos longos têm prévia paginada, sem truncar o envio. Botões públicos de link ficam desabilitados na prévia para não confundir exemplo e publicação.

Mensagens enviadas gerencia cada envio pelo próprio snapshot. Atualizar este envio mantém o modelo e outros canais. Mensagens legadas mostram aviso de conversão e limites do histórico. Falta de acesso, mensagem apagada e entrega incerta devem ter orientações diferentes.

Cargos por reação tem acesso próprio em Entrada e evolução → Cargos e automações. O editor oferece apenas o atalho opcional Usar em painel de cargos, que copia o conteúdo. O painel usa reações reais e legenda automática de emoji → cargo, exibida também na prévia. Configurar regras, editar aparência, publicar, pausar e sincronizar são ações distintas. Mostrar revisão e progresso antes de retiradas em etapas; pausa preserva cargos.

Reutilizar os PNGs aprovados (emojis da aplicação), acento vermelho e componentes nativos; não substituir por ícones Unicode de navegação. Emojis de reação escolhidos pelo administrador são conteúdo funcional do painel, separados dos PNGs da navegação. A simulação HTML mostra 25 telas geradas pelos builders com dados ilustrativos e menus visuais; não executa ações Discord. Revisão delimitada em desktop/celular concluída, sem expansão de escopo.


## Central de segurança — extensão de 24/10/2026

Extensão Operate da identidade BLACKOUT, sem reformulação global. Nome do destino protecao: Central de segurança. Categorias no seletor: Entrada e Anti-Raid; Chat e conteúdo; Anti Ban e ações da equipe; Proteção de calls; Incidentes e contenção; Exceções e diagnóstico. Contagem do modo das novas regras no resumo, sem listar todas as categorias acima. Estado da regra, resposta e limites aparecem no próprio painel e depois de confirmar uma edição.

Seis novos PNGs de esmalte branco/vermelho/grafite acompanham o escudo aprovado; calls reutiliza o headset aprovado. Sete arquivos em assets/blackout-ui/security/, RGBA128 com margem/transparência, nomes blackout_sec_*. Menus usam emojis da aplicação; thumbnail local mantém contexto se o provisionamento falhar. Não trocar por símbolos Unicode decorativos.

Desligado, Observar e registrar e Aplicar proteção são escolhas explícitas, sem botão de ciclo. Em modo desligado/observação, mostrar Resposta ao ativar. Alterações abrem revisão no mesmo painel; somente Confirmar aplica. BotAdmin sem Administrator pode consultar, sem obter poder de alterar as proteções. Diagnóstico não executa ações. Histórico distingue resposta aplicada/parcial/falha/não confirmada; modo, envio do log e estado da contenção têm rótulos em português. IDs de auditoria são informação secundária para apurar o incidente.

Proteção sem executor identificado nunca acusa/pune a vítima. Contenção apresenta canais/prazo e explica restauração; mudanças posteriores da equipe ficam preservadas para revisão. Salvar não envia avisos públicos de teste. Não apresentar etapas futuras como botões ativos. Evidência:32 telas dos builders reais conferidas em desktop/celular em uma rodada delimitada, com uma confirmação dos ajustes de copy e ícones. Prévia ilustrativa, sem Discord conectado.
