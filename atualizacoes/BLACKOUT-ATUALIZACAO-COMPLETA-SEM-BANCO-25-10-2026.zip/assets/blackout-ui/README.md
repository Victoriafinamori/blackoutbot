# Assets BLACKOUT

- `header.png`: banner gerado e aprovado pelo usuário, preservado no formato original.
- `icons/*.png`: sete ícones gerados e aprovados, RGBA, 128 × 128, abaixo de 256 KiB. As cópias de uso no Discord foram renderizadas em 128 px a partir das artes originais, com transparência. Metadados `Description` guardam o prompt; os pixels não foram alterados ao adicionar a proveniência.
- `prompts.json`: prompts exatos da geração dos sete ícones.

Os arquivos são carregados por caminhos relativos ao código, não ao diretório de execução. Os ícones são enviados como emojis da aplicação com nomes versionados `blackout_v2_*`. Não substitua por emojis Unicode nem renomeie somente um lado do mapeamento em `admEmojis`.

O Discord define o tamanho final do emoji nos selects. O preview pode ampliá-los para inspeção, mas a avaliação de legibilidade deve incluir 24 px.
