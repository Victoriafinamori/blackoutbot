# Central de segurança — 24/10/2026

- 19 novas regras em quatro categorias: entrada/Anti-Raid, chat, Anti Ban/ações da equipe e calls. Começam desligadas; modos de observação e aplicação com revisão explícita.
- Anti Ban e cotas usam executor confirmado na auditoria. Reversões de cargos, timeout e acesso a canais conferem estado atual; hierarquia e dados incompletos são respeitados. URL é monitorada, sem promessa de recuperação.
- Lista própria de entrada bloqueada, exceções por pessoas/cargos/canais, proteção de pessoas/cargos/canais e diagnóstico. Regra roda antes do auto-cargo e webhooks antes da exclusão de bots do fluxo antigo.
- Contenção temporária de chats com snapshot, prazo, restauração após reinício e conflitos preservados. Incidentes persistentes, logs integrados ao destino externo opcional e reenvio separado da resposta.
- Categorias somente nos seletores; prévias/estado na própria mensagem. Seis novos PNGs e headset aprovado, como emojis da aplicação. Filtros anteriores e outras funcionalidades preservados.
- Migration aditiva de oito tabelas, seis eventos, fonte e app/ sincronizados de modo direcionado. Sem dependências/slash commands novos.
- 319 testes offline aprovados (79 novos);32 telas desktop/celular; seis migrations em cópia isolada do banco, com123 tabelas anteriores preservadas. Um erro TypeScript preexistente; sem login ou deploy.

# Mensagens V2 e cargos por reação — 23/10/2026

- Embed Maker com blocos nativos V2, edição e prévia na própria mensagem, organização/duplicação/remoção, desfazer e botões de links/canais. Salvar continua separado de publicar.
- Mensagens enviadas com snapshot e gerenciamento por publicação; editar/excluir um envio preserva o modelo e os demais envios. Importação conservadora dos modelos/IDs antigos, com prévia de conversão explícita.
- Cargos por reação em Entrada e evolução → Cargos e automações, com atalho opcional para copiar conteúdo do editor. Reações reais, escolhas múltiplas, regra de retirada, pausa, diagnóstico e sincronização manual com revisão/etapas.
- Rastreamento das concessões preserva cargos preexistentes e outras concessões; validação de hierarquia/permissões/emojis. Recuperação de envio incerto evita duplicação silenciosa.
- Categorias/descritivos nos seletores, embeds de navegação curtas e PNGs aprovados. Retorno compatível entre Components V2 e painéis antigos.
- Migration aditiva de oito tabelas e novos eventos/intents/partials. Fonte e app/ sincronizados de forma direcionada, preservando módulos exclusivos da produção.
- 240 testes offline aprovados (55 novos); 25 telas em desktop/celular; cinco migrations testadas em cópia isolada do banco com dados anteriores preservados. Um erro TypeScript anterior em denunciaSelects.ts permanece. Sem deploy, login ou validação real no Discord.

# Refinamento da central de logs — 21/10/2026

- Quatro tarefas principais: O que registrar, Onde enviar, O que ignorar e Testar envio.
- Destino e canais na mesma tela; resumo mostra destinos ativos pelos nomes, quantidade de eventos e pendências reais.
- Reintegração agrupada visualmente em Sistemas do bot, mantendo flags/canais independentes e IDs legados funcionais.
- PNGs aprovados por categoria, ajuda contextual e diagnóstico técnico secundário.
- Atalhos para controllers reais de canais/relatórios de Tickets e configurações de Registro, com retorno à central e sem substituir preferências dos módulos.
- 75 testes offline aprovados; nenhum schema/migration novo; mesmos 38 erros TypeScript anteriores.

# Central de logs e destinos externos — 21/10/2026

- 24 tipos configuráveis, incluindo entrada/saída, apelidos/cargos, calls, edição/exclusão de mensagens, exclusão em massa e mudanças de canais/cargos/permissões.
- Envio local, somente externo ou em ambos, com canal geral e destinos opcionais por grupo; autorização na origem e destino revalidada ao enviar.
- Filtros por bots, canais/categorias e cargos; resumo único de exclusão em massa, com texto anterior desconhecido identificado como indisponível.
- Teste externo antes de ativar, diagnóstico de permissões/entregas e fila limitada sem bloquear operações do bot.
- Migration aditiva cria ServerLogSettings; configurações antigas, histórico administrativo e módulos Tickets/Registro preservados.
- 70 testes offline aprovados; SQL validado em cópia do banco, preservando as 123 tabelas existentes; mesmos 38 erros TypeScript preexistentes.

# Equipe e proteção — 21/10/2026

- Quatro entradas, com proteção automática separada da moderação de membros.
- Equipe distingue acesso total, permissões por função e associações de cargos; seletores permanecem após salvar e mostram problemas de configuração.
- Moderação começa pelo membro, exibe histórico e pareia ações e reversões. Formulários abrem revisão; confirmação com prazo, isolamento por servidor/autor/mensagem e consumo único chama os serviços existentes.
- Resposta dos filtros escolhida explicitamente. Logs começam pelo canal geral e mostram herança por categoria; histórico renomeado Ações da equipe.
- Sem nova migration nesta etapa. Pacote cumulativo mantém a migration aditiva da personalização.
- 47 testes com API/banco simulados; mesmas 38 falhas TypeScript preexistentes.

# Ajuste de mensagens — 21/10/2026

- Nome da opção: Mensagens Personalizadas / Embeds.
- Botão Ver prévia abre o conteúdo real com links paginados e retorno ao editor, sem publicar. A prévia automática durante a edição permanece.

## 2026-10-21 — Personalização local e edição na própria embed

- Personalização do bot agora reúne somente perfil neste servidor, padrão das mensagens e modelos personalizados. Logs ficam em Equipe e proteção; cargos automáticos, em Entrada e evolução; avisos ficam no módulo correspondente.
- Nome, avatar e banner usam exclusivamente o perfil do bot no servidor da interação. Edições globais da conta foram removidas do painel do cliente, sem fallback global.
- As alterações salvas aparecem imediatamente na mesma mensagem: perfil, padrão visual, conteúdo real, imagens, botões, canais e cargos.
- Editor com conteúdo real, publicação explícita e indicação de rascunho/pendências. Botões e lista de modelos paginados; erros de acesso à publicação não criam duplicatas silenciosas.
- Preferências de DM independentes para moderação e reintegração. Migração aditiva de três colunas nullable, preservando valores anteriores e usando notifyDm como fallback.
- 33 testes locais aprovados; migração SQLite verificada em cópia do banco enviado com os dados originais preservados. Nenhum novo erro TypeScript frente aos 38 da base. Sem deploy ou alterações na produção.

## 2026-10-21 — Interface BLACKOUT e navegação por jornada

- Aplicado o visual aprovado em preto, branco e vermelho às embeds administrativas, preservando as mensagens públicas e configurações salvas.
- Reorganizado `/adm` em sete áreas na ordem de configuração e gestão do servidor; mantidos todos os módulos anteriores e os recursos exclusivos de `app/`.
- Adicionados banner e sete PNGs exclusivos com transparência. Os selects usam emojis da aplicação, sem consumir os slots de emojis do servidor.
- Configurações agora abrem cinco destinos diretos. Registro, oficialização e reintegração ficam em Entrada e evolução; campeonatos e sorteios ficam em Jogos e eventos.
- Ajustados botões de retorno e anexos das embeds. Corrigido o contrato de payload que antes retornava `embed` singular aos handlers que esperavam `embeds`.
- Adicionados testes locais de interface, permissões, limites, preparação dos PNGs e navegação. Nenhuma mudança no schema, migrations, dependências ou credenciais.
- Checagem TypeScript comparada ao snapshot original: 38 erros preexistentes, nenhum novo. Execução ao vivo e deploy não realizados.


## 2026-09-30 — Restauração do Submundo no /adm + auditoria SUBIDA DE MEMBROS

- Restaurada a seção **ENTRETENIMENTO** no painel administrativo executado pela Square Cloud.
- Restauradas as rotas para **INSTA**, **Submundo**, **Rádio 24h** e **Gerenciador de Sorteios**; o Submundo já existia no código, mas estava inacessível pela navegação.
- Confirmada a presença do Submundo V2: mídia anônima com 🔥, DM anônima, Correio Anônimo com 🔥/🔞, horários, limpeza e destaque.
- Auditada a **SUBIDA DE MEMBROS**: contagem de mensagens, tempo em voz, reconciliação periódica, promoção, troca de cargos, DM/anúncio e histórico estão ligados aos eventos e handlers corretos.
- O banco real inspecionado já contém progresso de mensagens e voz, confirmando que o rastreamento está ativo.
- Nenhum schema/migration foi alterado e nenhum arquivo de banco foi incluído no pacote.

## 2026-09-30 — Central de Embeds V2

- `/adm → Configurações → Embeds` passou a abrir uma central própria em vez do modal antigo de quatro campos;
- adicionada criação e persistência de embeds salvas, com nome interno, texto, visual, canal de destino, prévia, clonagem, exclusão e publicação;
- quando uma embed já publicada é salva novamente no mesmo canal, o bot atualiza a mensagem original em vez de duplicá-la;
- adicionados botões de **link externo** e **canal do Discord**, com rótulo/emoji, edição, exclusão e reorganização individual;
- mantida a configuração antiga como **Padrão do Bot**, preservando o comportamento de `baseEmbed()`;
- criados models `CustomEmbed` e `CustomEmbedButton` e migration `20260930210000_add_custom_embed_v2`;
- produção (`app/`) e fonte TypeScript (`src/`) foram atualizadas em conjunto.


## 2026-09-30 — Registro por página + correção de TicketConfig

- Páginas de Registro agora podem ser selecionadas individualmente para gerenciamento.
- É possível adicionar cargos a uma página específica sem recriá-la.
- É possível remover cargos de uma página específica.
- É possível excluir qualquer página específica; as páginas posteriores são reordenadas automaticamente.
- Corrigido `P2003` ao abrir tickets: `ticketConfig()` agora garante a existência de `GuildConfig` antes do `upsert` de `TicketConfig`.
## 2026-09-30 — Central de Denúncias simplificada

### Atendimento

- reformulada `/adm → Atendimento → Central de Denúncias` para um fluxo simples no estilo ticket especializado;
- painel administrativo passou a exibir status, denúncias abertas, cargos responsáveis, canal do painel, categoria e logs;
- adicionados botões diretos para ativar/desativar, editar a embed, configurar canais/logs, configurar cargos e publicar/atualizar o painel;
- painel público utiliza o botão **Iniciar denúncia**;
- abertura solicita denunciado, motivo e relato e cria um canal privado `denuncia-XXXX`;
- limitado a uma denúncia aberta por usuário;
- cargos configurados podem assumir a denúncia e ficam identificados na embed interna;
- fechamento solicita motivo, gera transcript `.txt`, registra logs, envia DM ao denunciante e remove o canal após alguns segundos;
- publicação do painel agora atualiza a mensagem existente quando possível, evitando duplicação;
- removido o VOTEBAN da navegação administrativa para respeitar o estado atual do projeto. Artefatos históricos permanecem apenas para compatibilidade e não estão ativos.

### Banco

- nenhuma migration nova; reutilizados `ReportConfig`, `Report` e `ReportEvent`.

# Changelog técnico — FF BLACKOUT
## 2026-09-29 — Submundo: mídia, correio e DM anônima

### Fotos/Vídeos

- removido do fluxo público de envio qualquer texto informando que a identidade fica registrada para a administração;
- a confirmação agora mostra apenas a declaração de maioridade/autorização e que a identidade permanece em anonimato;
- a reação padrão das publicações mudou de ❤️ para 🔥;
- o Destaque passou a usar a reação 🔥 como critério;
- adicionado botão **Enviar DM anônima** em cada foto/vídeo publicado; a mensagem chega ao autor sem expor o remetente e possui cooldown de 30 segundos por usuário/envio;
- envios de vídeo passaram a usar **Components V2 + Media Gallery**, evitando o arquivo visualmente separado/“quebrado” abaixo da publicação.

### Mensagens anônimas

- painel público redesenhado como **📮 Correio Anônimo**, em estilo de correio/Tellonym;
- o texto de privacidade fica somente em **Antes de enviar** e não menciona logs administrativos;
- a publicação ganhou visual de carta e reações automáticas 🔥 e 🔞.

### Runtime e documentação

- `discord.js` passou a declarar versão mínima `^14.27.0` para garantir suporte aos componentes usados nas publicações de vídeo;
- no `ClientReady`, os painéis existentes do Submundo são atualizados uma vez para aplicar o novo texto/visual sem depender de uma troca de horário;
- nenhuma migration foi necessária;
- `docs/TECHNICAL.md`, `docs/CHANGELOG.md` e o guia contextual de `app/` foram atualizados.

## 2026-09-29 — Ajuste de texto do Submundo

- Simplificado o aviso público de Fotos/Vídeos Anônimos em **Antes de enviar**.
- O texto agora informa apenas que pessoas identificáveis devem ter 18 anos ou mais, que a publicação deve ser própria ou autorizada e que a identidade permanece em anonimato.
- Nenhuma regra interna de logs ou funcionamento do módulo foi alterada.


Este arquivo registra mudanças relevantes no projeto e na documentação. Entradas novas devem ser adicionadas no topo.

## 2026-09-28 — Rádio 24h V1

### Funcionalidade

- adicionado `/adm → Entretenimento → Rádio 24h`;
- criada configuração de call com suporte a canal de voz e Canal de Palco;
- criada playlist persistente de links do YouTube, com adição em lote, remoção por posição, paginação, reorganização e limpeza;
- adicionados modos **Sequencial** e **Aleatório**, repetição contínua e volume de 1 a 100;
- criado painel de controle com anterior, pausar/retomar, pular, reiniciar faixa e embaralhar fila;
- rádio tenta reconectar após queda da call e restaura configurações marcadas como ativas quando o bot reinicia;
- faixas indisponíveis são registradas e puladas para não interromper a estação inteira;
- a fila em execução é atualizada quando faixas são removidas/reorganizadas.

### Banco

- criados models `RadioConfig` e `RadioTrack`;
- criada migration `20260928230000_radio_24h`.

### Dependências e runtime

- adicionados `@discordjs/voice` e `youtubei.js`;
- runtime mínimo do projeto atualizado para Node.js >= 22.12 por requisito da camada de voz.

### Execução

- criado `app/radio/service.js`;
- criado painel `app/components/buttons/admRadioMenu.js`;
- criados select de call e modal de playlist/volume;
- `app/index.js` restaura rádios ativas no `ClientReady` e encerra conexões de voz no shutdown;
- implementação destinada ao código de produção executado pela Square Cloud (`app/`).

### Validação desta entrega

- sintaxe de todos os arquivos JavaScript de produção verificada com `node --check`;
- cadeia completa de migrations aplicada em um banco SQLite limpo;
- reprodução real em Discord/YouTube continua dependente de teste no ambiente conectado, pois o ambiente de montagem desta entrega não possui sessão Discord nem acesso npm/rede para um teste ponta a ponta.

## 2026-09-28 — Submundo V1

### Funcionalidade

- adicionado `/adm → Entretenimento → Submundo`;
- criado painel principal no padrão visual dos módulos administrativos existentes;
- Fotos Anônimas evoluíram para **Fotos/Vídeos Anônimos**, com suporte a imagem e vídeo;
- criado sistema de **Mensagens Anônimas** em modal, sem identificação pública;
- adicionados horários independentes de abertura/fechamento para mídia e mensagens;
- adicionada limpeza automática opcional após o fechamento, preservando logs e banco;
- criado **Destaque** de foto/vídeo pelo maior número de curtidas ❤️, com publicação automática ao fechamento e ação manual `Publicar Agora`; o canal de destaque recebe somente a mídia vencedora;
- logs ficam configurados dentro de Fotos/Vídeos e Mensagens, sem uma área geral de logs do Submundo;
- canais públicos e de destaque exigem NSFW e canais de log precisam ser privados;
- remoção administrativa por ID permanece disponível para mídia e foi adicionada para mensagens.

### Banco

- ampliados `AnonymousPhotoConfig` e `AnonymousPhotoSubmission`;
- criados `AnonymousMessageConfig` e `AnonymousMessageSubmission`;
- criada migration `20260928213000_submundo_system`.

### Execução

- criado `app/submundo/service.js`;
- `app/events/ready.js` executa o scheduler do Submundo a cada 60 segundos;
- atualização destinada ao código efetivamente executado pela Square Cloud (`app/`).

### Organização

- removida a pasta duplicada `ff/` do pacote de trabalho;
- removidos os documentos antigos específicos de games (`GAMES-DE-CHAT.md`, `AUDAZ-EM-GUERRA.md`, `README-v6.md` e o histórico de Bingo), mantendo a documentação canônica em `docs/`;
- `AGENTS.md`, `README.md` e `docs/TECHNICAL.md` atualizados para refletir o estado atual.

## 2026-09-28 — Fundação da documentação canônica

### Documentação

- `README.md` deixou de ser um changelog específico do Bingo e passou a ser a entrada geral do projeto.
- criado `AGENTS.md` com roteamento por módulo para reduzir leitura desnecessária por Codex/agentes;
- criados guias contextuais em `src/AGENTS.md`, `app/AGENTS.md` e `prisma/AGENTS.md` para reforçar regras específicas por camada;
- criado `docs/TECHNICAL.md` com o estado técnico atual;
- criado `docs/CHANGELOG.md` para manutenção contínua;
- o README anterior do Bingo foi inicialmente preservado como histórico; esse arquivo foi removido depois, na limpeza registrada na entrada acima;
- definida regra de atualização obrigatória da documentação após novas implementações.

### Descobertas documentadas

- Square Cloud executa `app/`, não `dist/`;
- há divergência entre `src/` e `app/`;
- foi identificado um `ff/` duplicado na raiz; ele foi removido depois. `src/ff/`, `app/ff/` e `dist/ff/` pertencem ao módulo real de Free Fire e não são essa duplicação;
- produção possui módulos que não estão totalmente representados em `src/`, como Guerra, Giveaways, Social/Instagram e partes avançadas de Família;
- o pacote contém `.env`, que deve ser tratado como segredo e nunca reproduzido na documentação.

### Código funcional

Nenhuma regra de negócio ou funcionalidade do bot foi alterada nesta entrada; a mudança é exclusivamente de documentação e orientação de manutenção.

## 2026-09-30 — Correção de persistência + Central de Denúncias

- identificado que o banco real possuía a migration `20260915170000_report_embed_appearance`, porém a Central de Denúncias passou a consultar novos campos `embed*` que não tinham migration própria, causando Prisma `P2022` em `ReportConfig.embedColor`;
- adicionada migration aditiva `20260930223000_report_config_embed_fields`, preservando os campos anteriores e copiando a aparência existente de `panel*` para `embed*`;
- mantida aplicação automática via `prisma migrate deploy` no START, antes do login do bot;
- registrada regra crítica de deploy: enquanto produção usar SQLite, nunca empacotar banco local/vazio/antigo no lugar do `prisma/dev.db` real obtido da Square Cloud;
- banco de produção fornecido em 30/09/2026 preservado nesta entrega de resgate para evitar perda das configurações atuais;
- nenhuma limpeza de dados de guild foi realizada; exclusão de servidor/dados exige identificação explícita do guild correto.

## 2026-09-30 — Sistema de Parcerias V1
- Adicionado `/adm → Atendimento → Parcerias`.
- Novo painel público configurável com botão `Solicitar parceria`.
- Solicitação abre canal privado numerado com nome do servidor, convite, membros, tema e proposta.
- Staff configurável pode assumir, aprovar, recusar ou encerrar a solicitação.
- Aprovação pode conceder cargo de parceiro e publicar a parceria em canal configurado.
- Logs com transcript `.txt` no encerramento.
- Requisitos básicos: mínimo de membros e cooldown após recusa.
- Migration aditiva `20260930233000_partnership_system` adicionada sem remover ou alterar dados existentes.
- `prisma/dev.db`, `prisma/dev.db.backup` e `prisma/dev.db.predeploy-20260930.bak` foram preservados sem alteração de conteúdo.

## 2026-09-30 — Hotfix de memória do Prisma na Square Cloud
- Corrigido o `START` da Square Cloud após `prisma generate` ser encerrado pelo sistema com `Killed`.
- O limite de heap do `prisma generate` foi elevado de 192 MB para 320 MB.
- O `prisma migrate deploy` passou a usar 256 MB; os processos continuam sequenciais, dentro do plano de 500 MB da aplicação.
- Nenhum banco SQLite ou backup foi recriado, resetado ou alterado por este hotfix.


## 2026-09-30 — Painéis modernos de Parcerias e Denúncias
- Parcerias e Central de Denúncias passaram a seguir o padrão visual moderno dos Tickets.
- A área **Painel** agora mostra prévia antes da publicação.
- Embed e botão principal são editados separadamente.
- Botão principal configurável por texto, emoji e cor: azul, cinza, verde ou vermelho.
- Painéis já publicados são atualizados quando a aparência for alterada.
- Adicionada migration aditiva `20260930214500_panel_buttons_reports_partnerships`; nenhum dado existente é removido.
- Regra de deploy reforçada: ZIPs de atualização não incluem `prisma/dev.db`, `dev.db.backup` ou arquivos `.bak`, evitando sobrescrever o banco vivo da Square Cloud.

## 2026-09-30 — Hotfix `/adm` Entretenimento
- Corrigido o menu raiz do `/adm` para garantir que `Entretenimento` seja exibido corretamente.
- Adicionado fallback `🎭` para a categoria `entretenimento` no sistema de emojis administrativos.
- O menu agora evita enviar emoji indefinido/inválido ao Discord.
- Nenhum banco de dados foi incluído ou alterado nesta entrega.

- 2026-10-02: Corrigido Páginas de Registro: removida rota legada "Remover última" sem handler; agora a área abre o seletor de página específica para gerenciar cargos/excluir diretamente.

## 2026-10-02 — Auto-Cargo

- Adicionado `/adm → Configurações → Auto-Cargo`.
- Seleção de até 10 cargos automáticos, com ativação/desativação independente.
- `guildMemberAdd` agora atribui os cargos configurados quando o membro entra.
- Implementação ignora cargos inexistentes, gerenciados ou acima do bot para não quebrar o evento.
- Migration aditiva `20261002203000_auto_role`; nenhum banco SQLite é empacotado na atualização.


## 2026-10-21 — Refinamento das demais áreas administrativas

- Navegação por tarefas, retornos de área consistentes, textos administrativos e PNGs aprovados nos módulos restantes.
- Transferência programada movida para Cargos e automações, preservando IDs e comportamento existente.
- Registro com cinco áreas, edição/ordenação de páginas, obrigatoriedade, categorias/responsáveis separados, logs próprios, prévias e publicação explícita.
- Seleções do Registro e de Parcerias validadas por servidor; ajustes aparecem no painel de origem.
- Tickets, Registro, Parcerias, Denúncias, Feedback e Submundo separam a edição de aparência da publicação imediata.
- Oficialização mais compacta; mensagens retornam à prévia. Rádio com escolha explícita da ordem das faixas. Sorteios e INSTA atualizam o painel após editar a aparência.
- 107 testes offline; 50 telas verificadas em duas larguras. Sem nova migration nesta etapa e sem deploy; preservados os módulos exclusivos de produção.

## 22/10/2026 — Social e entretenimento

- Novo destino Dinâmicas sociais, com perguntas, preferências, enquetes, desafios, propostas editáveis e programação por fuso do servidor.
- INSTA com prévia e confirmação, Minhas publicações e cartão V2 com MediaGallery para imagem/GIF/vídeo; preservação do anexo ao atualizar interações e destaques; original removido somente após sucesso.
- Pedidos da rádio persistentes, aprovação opcional, limites, fila separada da playlist, painel público e voto para pular por maioria dos ouvintes presentes.
- Hub de participação, perfis opcionais e descoberta por interesse/jogo; preferências de privacidade independentes por servidor.
- Submundo com opt-out, bloqueio opaco, denúncia de DMs e aprovação privada opcional de mídia/texto.
- Migration exclusivamente aditiva 20261022010000_social_experience, com recursos novos desativados por padrão.
- 140 testes offline; banco original preservado em validação de migrations sobre cópia isolada. Sem deploy ou conexão ao Discord.

# Jogos e eventos / referência Nix — 22/10/2026

- Novo /jogar e painel de participação com prévia, publicação explícita e atualização do estado na mesma mensagem.
- Bingo comunitário gratuito: inscrição, uma cartela privada no servidor, objetivos e ritmo configuráveis, pausa e conferência conjunta de vencedores. Cartelas/pedidos antigos preservados com acesso sem DM.
- TERMO: correção da meia-noite, palavra sorteada/persistida, dicionário ampliado, regras fixas por rodada, continuidade, ranking semanal e compartilhamento único sem spoiler. revealOnLoss respeitado.
- Caixa: resultados/entrega próprios, lista paginada, até 25 caixas sem exceder componentes e anúncios individuais opcionais.
- Quiz em equipes existente em /guerra aparece nos eventos e no hub; Game Musical exclusivo de app/ preservado.
- Quarta migration aditiva e reconciliação do schema antigo de Bingo; 185 testes offline, 24 telas em duas larguras, SQL das quatro migrations validado em cópia do banco com preservação das 123 tabelas originais. Typecheck mantém um erro anterior em denunciaSelects. Sem login ou deploy.
- Comparação em docs/reviews/NIX-COMPARACAO.md baseada na lista transcrita pelo usuário; site e painel Nix bloqueados pela rede. Lacunas fora de jogos registradas como futuras, sem alegação de paridade integral.
