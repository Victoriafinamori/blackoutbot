# Referência Nix e prioridades do BLACKOUT — 22/10/2026

Fonte: lista de sistemas de https://nixbot.vip/lista, transcrita pelo usuário nesta conversa. Tanto essa página quanto o painel https://nixbot.vip/bot/1454490224435396722 ficaram inacessíveis pela rede do ambiente (CONNECT/403). A análise usa a transcrição, sem acesso ao painel, teste do bot Nix ou inferência de nomes exatos de slash commands. As sugestões sobre a Nix abaixo avaliam a descrição do catálogo, não sua implementação.

| Área da referência | Situação do BLACKOUT antes desta etapa | Direção |
|---|---|---|
| Aparência | Perfil por servidor, cor, avatar/banner locais e embeds configuráveis | Preservar isolamento comercial. Comandos slash já existem; prefixo não é requisito para descobrir funções. |
| Segurança | Moderação, avisos, filtros, blacklist e logs; conta nova destacada em log | Cobertura parcial. Bloqueio por idade, resposta a entrada em massa e limites por moderador precisam de definição e implementação próprias. Não confundir alerta de conta nova com bloqueio anti-fake. |
| Servidor e automações | Cargos automáticos/transferência, boas-vindas de registro, relatórios e estatísticas | Auto-reações/respostas, temporárias, agenda de canais e rastreador de convites são lacunas separadas do trabalho em jogos. |
| Tickets | Atendimento, equipe, reivindicação, logs externos, avaliações, editor e prévias | Conservar funções e comparar requisitos de tópicos/horários antes de prometer paridade total. |
| Comunidade | Registro, reintegração/oficialização, famílias, feedback, sorteios, guerra | Priorizar descoberta e continuidade do que já existe. Migração/recrutamento por equipe é uma expansão futura. |
| Entretenimento | INSTA, Submundo, perfis voluntários, DM com controles, rádio e dinâmicas | Pets podem ser temas do INSTA. Evitar criar módulos duplicados para o mesmo ato de publicar. Match exigiria adesão voluntária e reciprocidade; não é prioridade dos jogos. |
| Economia/loja | Algumas recompensas externas só são registradas como pendentes; sem loja integrada completa | Não anunciar moeda, XP, Pix ou produto entregue sem provedor real. Pontuação de jogo deve ser apresentada como pontuação, com escopo claro. |
| Mov Call/Chat | Ranking, tempo, níveis/recompensas e configurações próprios | Comparar critérios e integração voluntária com eventos; não aumentar pontos por spam de mensagens ou cliques. |
| GIFs e edição | Sem suíte de conversão/edição nem gestão de postadores | Expansão opcional, com custo de CPU/memória a dimensionar para a Square Cloud. |
| FiveM | Free Fire possui campeonatos; FiveM é outra vertical | Farm, baú e vendas de facção não atendem automaticamente ao objetivo atual do bot de interação. |
| Ferramentas | Relatórios, limpeza administrativa, embeds e diversos comandos utilitários | Priorizar ferramentas de bot oficial. Recursos de conta pessoal, automação de missões da plataforma ou dados indisponíveis pela API não entram nesta etapa. |
| Primeira Dama / VIP / família VIP | Famílias, cargos e cargos temporários em recursos existentes | Delegação de cargos e expiração exigem permissões e auditoria próprias; sem alegação de cobertura completa. |

## O que melhorar no nosso uso diário

1. Entrada por painel e comando simples, sem obrigar o membro a decorar comandos de administração.
2. Regras, tempo restante, próxima ação e resultado na própria mensagem.
3. Continuidade de partidas e acesso aos dados pelo servidor, sem depender de DM aberta.
4. Controles da equipe separados dos controles do jogador.
5. Inscrições e ritmo claros no Bingo comunitário, com conferência que reconheça vencedores simultâneos.
6. TERMO com dicionário ampliado, regra respeitada ao perder, progresso e compartilhamento sem spoiler.
7. Caixa Misteriosa com resumo consolidado e anúncio individual opcional.
8. Dar acesso ao quiz em equipes já existente em Guerra, antes de criar outro motor de quiz igual.

## Melhorias que eu proporia ao catálogo da Nix

- Reorganizar a descoberta por intenção: configurar servidor, proteger, atender, participar e jogar. A descrição atual concentra muitos sistemas em uma lista extensa.
- Explicar a diferença entre Auto mensagem e Auto resposta: na transcrição ambos aparecem com a mesma descrição de agendamento.
- Mostrar o caminho do membro em cada sistema, estados de partida/participação e possibilidade de continuar depois; esses detalhes não aparecem na lista recebida.
- Distinguir claramente dados confirmados de heurísticas em anti-fake, verificações externas e “servidores suspeitos”. Não assumir dados que a API não entrega.
- Explicitar quem vê mensagens/identidades, como recusar DMs e quais ações dependem de adesão voluntária.
- Mostrar prévia real, resultado salvo e histórico de alterações no mesmo contexto de configuração.

## Implementado nesta entrega

| Necessidade | Resultado no BLACKOUT |
|---|---|
| Encontrar jogos | `/jogar [jogo]` e hub público editável, com estados dos eventos e publicação explícita. |
| Participar do Bingo | Inscrições gratuitas, uma cartela por pessoa, consulta privada no servidor sem depender de DM. |
| Conduzir o Bingo | Objetivos e ritmo manual/automático, regras fixas por partida, pausa e conferência de todos os vencedores aptos no mesmo número. |
| Dar continuidade ao TERMO | Tabuleiro salvo, dicionário ampliado, troca de dia corrigida, sequência e regras estáveis; ranking semanal e compartilhamento sem spoiler. |
| Reduzir ruído da Caixa | Anúncios individuais opcionais, resultados reunidos e consulta da própria entrega; paginação para respeitar componentes nativos. |
| Encontrar o quiz existente | Acesso ao Quiz em equipes de `/guerra` pelos eventos e pelo hub, sem duplicar motor. |
| Conferir alterações visuais | Mensagens e prévias atualizadas no painel aberto; salvar aparência separado de publicar. |

São melhorias próprias para a experiência do BLACKOUT, não uma alegação de que a Nix funciona dessa forma. As lacunas de segurança, automações, loja, VIP e edição de mídia continuam como possibilidades futuras e não foram anunciadas como implementadas. Não foram criados lembretes de inscrição, segunda etapa automática no Bingo nem nova fase de inscrições da Caixa. O HTML final mostra 24 telas de builders reais com dados ilustrativos; substitui a proposta conceitual inicial.

A referência serve para identificar necessidades e padrões úteis. Não há reprodução de marca, textos, artes ou código da Nix.


## Atualização posterior — Segurança, 24/10/2026

A comparação acima registra a situação anterior à etapa de segurança. O pacote BLACKOUT-seguranca-atualizada.zip agora acrescenta19 regras, incidentes persistentes, exceções e contenção temporária. Anti-Raid, entrada de bots/contas novas, Anti Ban, cotas, proteção de cargos/acesso a canais e filtros avançados têm implementação própria, descrita em SEGURANCA-BLACKOUT.md. Captcha, OCR, prisão de acesso, backup integral e aprovação em dupla permanecem fora desta etapa. Não equivale a completar todo o catálogo Nix nem comprova a versão instalada na Square Cloud.
