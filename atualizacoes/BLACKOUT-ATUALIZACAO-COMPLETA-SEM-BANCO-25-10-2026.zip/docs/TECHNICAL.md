# Documentação Técnica — FF BLACKOUT

**Estado documentado:** 24/10/2026  
**Função deste arquivo:** fonte canônica do estado técnico conhecido do projeto.  
**Atualização:** deve ser editado junto com mudanças estruturais do bot.

---

## 1. Visão geral

FF BLACKOUT é um bot Discord modular voltado a operação de comunidade. O projeto concentra moderação, administração, registro, tickets, movimentação de membros, games, campeonatos e recursos sociais em uma aplicação com persistência Prisma.

A interface administrativa principal parte do comando `/adm` e distribui os recursos em áreas. Interações de Discord são implementadas por comandos, botões, selects e modals carregados dinamicamente.

---

## 2. Stack e dependências principais

- **Runtime:** Node.js >= 22.12 (requisito da camada de voz da Rádio 24h)
- **Linguagem de desenvolvimento:** TypeScript 5.6
- **Discord:** discord.js ^14.27.0
- **Voz Discord:** `@discordjs/voice`
- **Resolução de mídia YouTube:** `youtubei.js`
- **ORM:** Prisma 5.20.x
- **Configuração:** dotenv
- **Hospedagem configurada:** Square Cloud
- **Banco:** definido via `DATABASE_URL`; o schema é Prisma

Scripts declarados em `package.json`:

- `npm run dev` → `src/index.ts` via `ts-node-dev`
- `npm run build` → `tsc`
- `npm start` → `dist/index.js`
- `npm run deploy` → registra slash commands a partir de `src/deploy-commands.ts`
- `npm run prisma:generate`
- `npm run prisma:migrate`
- `npm run prisma:studio`

**Observação importante:** esses scripts locais não representam integralmente o processo de produção, porque a Square Cloud está configurada para executar `app/`.

---

## 3. Arquitetura de diretórios

### `src/`

Fonte TypeScript disponível. Contém:

- `commands/` — slash commands;
- `components/buttons/` — handlers de botões;
- `components/selects/` — handlers de selects;
- `components/modals/` — handlers de modals;
- `events/` — eventos do Discord;
- `handlers/` — carregadores dinâmicos;
- `utils/` — serviços e regras transversais;
- `games/`, `games-chat/`, `bingo/`, `ff/`, `memberRise/` — módulos especializados ativos dentro de `src/`; `src/voteban/` permanece apenas como legado histórico/inativo (o `src/ff/` é o módulo real de Free Fire, não a antiga cópia duplicada da raiz);
- `database/` — Prisma Client;
- `structures/` — contratos TypeScript dos handlers.

### `dist/`

Saída definida por `tsconfig.json` (`outDir=dist`). É a saída natural de `npm run build` e o alvo de `npm start`, mas **não é o alvo atual da Square Cloud**.

### `app/`

Artefato JavaScript usado em produção pela configuração atual da Square Cloud. Além dos módulos equivalentes a `src/`, possui recursos adicionais que não estão totalmente representados na fonte TypeScript atual.

### `prisma/`

- `schema.prisma` — modelagem persistente;
- `migrations/` — histórico incremental de alterações do banco.

### `assets/`

Recursos visuais/estáticos, incluindo ícones administrativos e assets de jogos.

---

## 4. Bootstrap e ciclo de vida

### Desenvolvimento TypeScript

`src/index.ts`:

1. carrega `.env`;
2. exige `DISCORD_TOKEN` e `CLIENT_ID`;
3. valida se o token pertence ao `CLIENT_ID` configurado;
4. cria o `Client` do Discord;
5. registra collections de commands/buttons/selects/modals;
6. chama os loaders;
7. conecta com `client.login()`;
8. agenda verificações periódicas de reintegração e transferência de cargos;
9. encerra Prisma e Discord de forma graciosa em `SIGINT`/`SIGTERM`.

Intents configurados incluem guilds, membros, mensagens, voz, conteúdo de mensagem e moderação.

### Produção / Square Cloud

`squarecloud.app` define:

- `MAIN=app/index.js`
- `MEMORY=500`
- `AUTORESTART=true`

O START executa:

1. `prisma generate --schema=prisma/schema.prisma`;
2. `app/scripts/verify-prisma-client.js`;
3. `prisma migrate deploy --schema=prisma/schema.prisma`;
4. `app/deploy-commands.js`;
5. `app/index.js`.

**Implicação:** qualquer alteração destinada à produção deve chegar ao conteúdo efetivamente executado em `app/`.

---

## 5. Sistema de handlers e interações

Os loaders percorrem o diretório correspondente e adicionam módulos às collections do client:

- `loadCommands`
- `loadButtons`
- `loadSelects`
- `loadModals`
- `loadEvents`

`interactionCreate` encaminha:

- `ChatInputCommand` pelo nome do comando;
- botão pelo `customId`;
- select pelo `customId`;
- modal pelo `customId`.

Para componentes, o roteamento aceita:

1. correspondência exata;
2. correspondência por prefixo.

Isso permite IDs dinâmicos como `prefixo:<id>`, desde que o handler registre um prefixo coerente.

---

## 6. Painel administrativo

Comando principal: `/adm`.

| Ordem | Área | Conteúdo |
|---|---|---|
| 1 | Personalização do bot | Perfil neste servidor, padrão das mensagens e mensagens personalizadas |
| 2 | Equipe e proteção | Administradores, permissões, moderação, avisos e logs/auditoria |
| 3 | Entrada e evolução | Cargos automáticos, registro, oficialização e reintegração |
| 4 | Atendimento | Tickets, denúncias e parcerias |
| 5 | Comunidade e atividade | Famílias, chat/call, feedback, estatísticas e inatividade |
| 6 | Jogos e eventos | Eventos, jogos de chat, sorteios, Bingo e Free Fire |
| 7 | Social e entretenimento | INSTA, Submundo e Rádio 24h |

`ADM_SECTIONS` mantém a organização comum em `src/utils/admPanel.ts` e `app/utils/admPanel.js`. Os 23 módulos anteriores continuam acessíveis; há 28 destinos no select de áreas, incluindo as quatro entradas de configuração distribuídas entre Personalização e Entrada. `campeonatos` é um alias legado de `staff`. Os botões `adm-nav:` verificam o acesso administrativo antes de navegar. Rotas antigas de configuração encaminham para a área responsável.

### Identidade e PNGs

`adminUi` aplica a aparência das embeds administrativas: vermelho `#D71935`, autor BLACKOUT e contexto, rodapé e thumbnail do assunto. `assets/blackout-ui/` contém o banner e os sete PNGs RGBA de 128 × 128 abaixo de 256 KiB. `admEmojis` os prepara como emojis da aplicação `blackout_v2_*`, sem ocupar slots dos servidores ou apagar emojis existentes. A preparação tem proteção contra concorrência e espera cinco minutos após falha de API antes de tentar novamente. Não há substituição por emojis Unicode.

Perfil local, padrão de mensagens e editor exibem a **prévia real** em vez de impor a decoração administrativa sobre o conteúdo escolhido pelo cliente. A identificação do painel e o estado de salvamento/publicação ficam no conteúdo da mesma mensagem, sem modificar o conteúdo público da embed.

### Perfil por servidor e revenda

Nome, avatar e banner são editados com `guild.members.editMe`, sempre no servidor da interação autorizada. Não há chamada a `ClientUser.setAvatar/setBanner` nem fallback para alteração da conta global. A identidade da conta-base é preservada. O retorno da API é usado diretamente para atualizar a própria embed e uma abertura posterior busca o membro atualizado. Isso evita depender da chegada de um evento de cache para mostrar o resultado.

O acesso é o de administrador autorizado do bot no servidor. Licenciamento e cobrança não são implementados nesta entrega. Preferências e modelos continuam vinculados a `guildId`.

### Prévia na mesma mensagem

`panelInteraction` mantém a atualização do painel de origem, inclusive após modals. Modals de perfil, padrão visual, conteúdo e imagens atualizam título, cor, autor, rodapé, miniatura e imagem imediatamente após salvar. Seleções de canais e cargos atualizam o mesmo resumo e mantêm os seletores disponíveis. Anexos e conteúdo anteriores são limpos nas transições apropriadas.

Personalização tem apenas três destinos:

1. **Perfil neste servidor** — nome, avatar e banner locais.
2. **Padrão das mensagens** — cor, autor, rodapé e miniatura usados por `baseEmbed()`.
3. **Mensagens Personalizadas / Embeds** — criar, editar e publicar modelos próprios.

O padrão continua configurável por servidor; modelos próprios mantêm seu visual individual. Não há redefinição das configurações existentes.

### Mensagens salvas e publicação

O editor usa `buildCustomEmbedMessage()` para mostrar o conteúdo real. O select oferece Conteúdo → Imagens e cor → Botões → Canal de destino. Renomear, duplicar e excluir ficam em Mais opções. As edições continuam visíveis automaticamente. O botão **Ver prévia** abre uma visualização focada do conteúdo e dos links, com paginação e **Voltar ao editor**, sem salvar nem publicar.

Salvar não publica automaticamente. `publishedPayloadHash` guarda a impressão do conteúdo aplicado à publicação, sem incluir nome interno, data de edição ou relógio da prévia. O painel distingue rascunho, alterações ainda não publicadas e publicação sem pendências. Publicações antigas sem hash ficam como conteúdo a conferir. Um destino novo preserva a mensagem anterior e informa que haverá publicação no novo canal.

A prévia suporta até 25 botões, paginando a visualização de links em grupos de até dez e mantendo o limite de cinco linhas de componentes do Discord. A publicação contém todos os botões. Uma falha de permissão ao buscar a mensagem existente não é tratada como mensagem apagada e não cria uma duplicata silenciosa. A lista de modelos também é paginada.

### Destinos, entrada e avisos

- **Logs e auditoria:** configura o canal geral e os canais específicos, além da consulta à auditoria. Os canais são validados no servidor atual e precisam permitir envio de mensagens e embeds.
- **Cargos automáticos:** ficam em Entrada e evolução. A seleção valida existência, cargos gerenciados e possibilidade de atribuição; uma seleção inválida não substitui a configuração salva. Ativar exige cargos válidos e Gerenciar Cargos. Limpar a seleção desativa o sistema.
- **Avisos de moderação:** ficam em Moderação. O antigo `reportsChannelId` é identificado corretamente como destino de avisos públicos de moderação; denúncias privadas continuam em Atendimento. Não se ativa sem destino utilizável; remover o destino desativa os avisos.
- **DMs de reintegração:** ficam em Reintegração. As preferências de DM dos dois módulos são independentes.

### Migração aditiva

`20261021180000_personalization_module_notifications` adiciona:

- `GuildConfig.moderationNotifyDm Boolean?`;
- `GuildConfig.reintegrationNotifyDm Boolean?`;
- `CustomEmbed.publishedPayloadHash String?`.

Valores NULL das preferências usam `notifyDm` como fallback, preservando o comportamento anterior até a primeira configuração do módulo. Nenhum dado existente é removido. A migração foi testada em uma cópia isolada do banco enviado: valores de todas as colunas originais preservados. A cópia temporária foi removida. A Square Cloud já executa `prisma generate` e `prisma migrate deploy` no START; não aplicar SQL manualmente nem usar reset/db push.

### Validação e limites

`node --test tests/admin-ui.test.cjs tests/personalization.test.cjs`: 34 testes com fixtures, incluindo rotas, payloads, PNGs, SDK, perfis de dois servidores, atualização na mesma mensagem, remoção de valores visuais, permissões, canais, cargos, flags de DM e estados de publicação.

O `tsc --noEmit --incremental false` mantém os mesmos 38 erros preexistentes do snapshot original, sem novos diagnósticos. Não substituir `app/` por um build parcial de `dist/`. Os tipos Prisma locais foram gerados com a opção suportada `--no-engine`; o download dos binários nativos permanece bloqueado neste ambiente.

A demonstração HTML é uma simulação baseada nos builders de produção, com dados ilustrativos e estados antes/depois. Login no Discord, edição real dos perfis, cadastro real de emojis, migração via Prisma nativo e publicação na Square Cloud não foram executados aqui. O teste da migração foi feito com SQLite, não representa uma execução do CLI Prisma.

Social, Submundo, Sorteios e Rádio continuam implementados em `app/`; a navegação TypeScript possui uma ponte explícita para esses handlers sem reescrever os módulos exclusivos da produção.

---

## 7. Módulos técnicos conhecidos

| Módulo | Fonte TypeScript atual | Presente em `app/` | Persistência principal |
|---|---:|---:|---|
| Administração/permissões | Sim | Sim | `BotAdmin`, `PermissionRole`, `SystemRole`, `AdminLog` |
| Moderação/filtros | Sim | Sim | `Warn`, `Mute`, `ModerationAction`, `FilterRule`, `WordWatchLog` |
| Reintegração | Sim | Sim | `Stage`, `ReintegrationMember`, `Evaluation`, `StageMessageCount` |
| Tickets | Sim | Sim, com extras | `TicketConfig`, `Ticket`, `TicketRating`, `TicketReport` |
| Registro | Sim | Sim, com extras | `RegistrationConfig`, `RegistrationPage`, `RegistrationRecord`, `RegistrarStat`, `RegistrationReset` |
| MOV CHAT | Sim | Sim | `MovStat`, `MovChatDailyStat` |
| MOV CALL | Sim | Sim | `MovVoiceSession`, `MovCallReward`, `MovCallStreak`, `MovCallCompanion`, `MovCallDailyStat` |
| Limpeza/análise | Sim | Sim | `CleanupConfig`, `CleanupAnalysis`, `MemberPresenceStat` |
| Famílias | Parcial | Sim, com `family-app/` | `Family*` |
| Subida de membros | Sim | Sim | `MemberRiseStage`, `MemberRiseProgress`, `MemberRiseHistory` |
| Feedback | Sim | Sim | `ServerFeedbackConfig`, `ServerFeedback` |
| Games de Chat | Sim | Sim | `GamesChatConfig`, `Mystery*`, `Termo*` |
| Verdade ou Desafio | Sim | Sim | configuração vinculada ao módulo de jogos |
| Free Fire | Sim | Sim | `FFConfig`, `FFDuo`, `FFDuoLog` |
| Bingo | Sim | Sim | `BingoMatch`, `BingoDraw`, `BingoCard`, `BingoWinner`, `BingoConfig` |
| Social/Instagram | Não completo | Sim | `Social*` |
| Sorteios/Giveaways | Não | Sim | `Giveaway*` |
| Submundo (Fotos/Vídeos + Mensagens + Destaque) | Não | Sim | `AnonymousPhoto*`, `AnonymousMessage*` |
| Rádio 24h | Não | Sim | `RadioConfig`, `RadioTrack` |
| AUDAZ EM GUERRA | Não | Sim | `War*` |
| Jogo musical | Não completo | Sim | `MusicGame*` |
| Central de Denúncias | Sim | Sim | `ReportConfig`, `Report`, `ReportEvent` |
| Transferência de cargos | Sim | Sim | `RoleTransferConfig` |

---


### Central de Denúncias

A Central de Denúncias fica em `/adm → Atendimento → Central de Denúncias` e funciona como um atendimento privado especializado, sem a complexidade do antigo VOTEBAN.

Fluxo atual:

- painel público configurável com botão **Iniciar denúncia**;
- administrador define canal do painel, categoria dos atendimentos, canal de logs/transcripts e cargos responsáveis;
- abertura solicita denunciado, motivo e relato;
- cada usuário pode manter apenas uma denúncia aberta por vez;
- o bot cria `denuncia-XXXX` com acesso apenas ao denunciante e aos cargos responsáveis; o denunciado recebe `deny` explícito;
- staff pode **Assumir** ou **Fechar denúncia**;
- no fechamento é exigido um motivo, o atendimento é marcado como resolvido, o denunciante recebe DM e o canal é removido após alguns segundos;
- antes da remoção, o bot gera transcript `.txt` (até 500 mensagens) e envia ao canal de logs;
- abertura, assunção e encerramento também geram logs padronizados.

A implementação principal está em `src/utils/reports.ts` / `app/utils/reports.js`, com interface administrativa em `admDenunciasMenu`, abertura/ações em `denunciaButtons` e formulários em `denunciaModals`. Não foi necessária nova migration nesta versão; a solução reutiliza `ReportConfig`, `Report` e `ReportEvent`.

O antigo **VOTEBAN** foi retirado da navegação administrativa. Seus artefatos históricos/modelos podem permanecer no repositório/banco por compatibilidade de migrations, mas não fazem parte do fluxo ativo e não devem ser reintroduzidos sem pedido explícito.

---

## 8. Slash commands observados

### Em `src/commands/`

`/adm`, `/bingo`, `/caixa`, `/callinfo`, `/etapasreintegracao`, `/ff-inscricao`, `/grupo`, `/info`, `/limpa`, `/painelregistro`, `/r`, `/ranking`, `/rankingcall`, `/rankingtickets`, `/registrador`, `/registrar`, `/registros`, `/reintegrar`, `/relatorio`, `/tempocall`, `/termo`, `/topcall`, `/verdade`.

### Em `app/commands/` de produção

`/adm`, `/bingo`, `/caixa`, `/callinfo`, `/etapasreintegracao`, `/grupo`, `/guerra`, `/info`, `/limpa`, `/painelregistro`, `/r`, `/ranking`, `/rankingcall`, `/rankingtickets`, `/registrador`, `/registrar`, `/registros`, `/reintegrar`, `/relatorio`, `/sorteio`, `/tempocall`, `/termo`, `/topcall`, `/verdade`.

### Divergência relevante

- `/ff-inscricao` existe em `src/`, mas há instrução histórica `APAGAR_NO_SQUARE_CLOUD.txt` pedindo remoção de `app/commands/ff-inscricao.js` na hospedagem.
- `/guerra` e `/sorteio` existem no `app/`, mas não no `src/` atual.

Isso confirma que a árvore TypeScript e o artefato de produção não estão 100% sincronizados.

---


## Submundo — estado atual

O módulo de produção **Submundo** é acessado por `/adm → Social e entretenimento → Submundo` e segue o mesmo padrão visual dos outros painéis administrativos: uma embed resumida e botões de configuração.

### Fotos/Vídeos anônimos

- painel público configurável;
- canal de painel, canal de publicação e canal privado de logs;
- suporte a imagens e vídeos;
- autor oculto publicamente e preservado somente nos logs;
- confirmação de maioridade/autorização antes do envio de mídia, sem informar ao usuário sobre a existência dos logs;
- imagens continuam em embed tradicional e vídeos usam **Components V2 + Media Gallery** para manter o player visualmente integrado à publicação;
- cada publicação de mídia possui a opção **Enviar DM anônima** ao autor; o destinatário não recebe nome, avatar ou ID de quem escreveu, e a entrega fica auditável apenas nos logs internos;
- horário de abertura e fechamento (`HH:MM`), incluindo janelas que atravessam meia-noite;
- limpeza automática opcional ao fechamento da sessão;
- reação 🔥 usada como critério de destaque;
- remoção administrativa por ID público.

### Mensagens anônimas

- painel próprio com visual de **Correio Anônimo/Tellonym** e modal de texto;
- a orientação de privacidade aparece apenas no bloco **Antes de enviar**, sem mencionar logs administrativos;
- publicações usam uma embed de “carta” e recebem automaticamente as reações 🔥 e 🔞;
- canal de publicação e canal privado de logs independentes;
- horário de abertura/fechamento;
- limpeza automática opcional;
- remoção administrativa por ID;
- nenhuma identificação do autor na mensagem pública.

### Destaque

- usa apenas publicações de Fotos/Vídeos;
- critério atual: maior número de reações 🔥 da sessão;
- publica automaticamente no fechamento quando ativado;
- também oferece `Publicar Agora`;
- a publicação de destaque envia **somente o arquivo de mídia vencedor**, sem nome, avatar, ID ou texto identificando o autor.

### Scheduler

`app/events/ready.js` atualiza uma vez os painéis existentes quando o bot inicia e depois executa `runSubmundoScheduler()` a cada 60 segundos. O scheduler:

1. identifica se cada painel deveria estar aberto ou fechado conforme o horário e timezone do servidor;
2. atualiza o botão do painel quando há transição;
3. ao fechar Fotos/Vídeos, publica o destaque (se habilitado) e depois executa a limpeza (se habilitada);
4. ao fechar Mensagens, executa a limpeza quando configurada;
5. usa chaves de sessão para evitar repetição de destaque/limpeza.

### Persistência

- `AnonymousPhotoConfig` foi ampliado com horário, limpeza, estado do painel e configuração de destaque;
- `AnonymousPhotoSubmission` agora registra tipo/nome/URL da mídia, sessão e momento de destaque;
- novos models: `AnonymousMessageConfig` e `AnonymousMessageSubmission`;
- migration: `prisma/migrations/20260928213000_submundo_system/migration.sql`.

### Segurança operacional

- canais públicos do Submundo e de Destaque precisam ser canais de texto marcados como NSFW;
- canais de logs não podem ficar visíveis para `@everyone`;
- o reset de configuração preserva o histórico de submissões;
- limpeza automática apaga mensagens públicas, mas não os registros persistidos.
- as publicações de vídeo usam recursos de Components V2 disponíveis na versão de produção do `discord.js`; o projeto declara `discord.js ^14.27.0`.


## Rádio 24h — estado atual

O módulo de produção **Rádio 24h** é acessado por `/adm → Social e entretenimento → Rádio 24h` e segue o padrão administrativo do projeto: uma embed com o estado atual e botões de configuração.

### Configuração e playlist

- uma rádio persistente por servidor;
- seleção de canal de voz ou Canal de Palco;
- validação das permissões `Ver canal`, `Conectar` e `Falar`;
- playlist com até 500 links únicos do YouTube;
- adição de vários links de uma vez;
- paginação, remoção por posição, reorganização e limpeza completa;
- metadados de título/duração são carregados quando disponíveis;
- modos **Sequencial** e **Aleatório**; no aleatório, a fila é embaralhada em ciclos para reduzir repetição imediata;
- volume configurável de 1 a 100.

### Reprodução e controles

`app/radio/service.js` mantém o estado de execução em memória e a configuração no Prisma. O player oferece:

- anterior;
- pausar/retomar;
- pular;
- reiniciar a faixa atual;
- embaralhar a fila preparada.

A reprodução usa `@discordjs/voice`. Links do YouTube são resolvidos por uma camada isolada baseada em `youtubei.js`; o áudio WebM/Opus é encaminhado ao player do Discord quando o formato permite, evitando depender do restante do módulo administrativo para a resolução de mídia.

### Continuidade 24h

- ao terminar a playlist, uma nova sequência é montada automaticamente;
- uma faixa indisponível é registrada como falha e pulada, sem derrubar toda a rádio;
- após várias falhas consecutivas, o serviço aguarda antes de tentar novamente;
- desconexões de voz disparam tentativa de reconexão;
- rádios marcadas como ativas são restauradas no `ClientReady`;
- no encerramento gracioso do processo, conexões de voz são fechadas preservando o estado `enabled`, permitindo restauração no próximo boot;
- em Canal de Palco, o bot tenta assumir estado de orador quando possui permissão.

A retomada após reinício recupera a **faixa atual desde o início**; a posição exata em segundos não é persistida.

### Persistência

- `RadioConfig`: status, call, modo, volume, faixa atual, último início e último erro;
- `RadioTrack`: URL/ID do YouTube, metadados, posição, autor da adição e histórico de falha/reprodução;
- migration: `prisma/migrations/20260928230000_radio_24h/migration.sql`.

### Integração externa / atenção operacional

A disponibilidade de reprodução de links do YouTube depende da capacidade de resolver e obter o fluxo de mídia no momento da execução. Mudanças ou restrições do provedor podem exigir trocar apenas a camada de resolução em `app/radio/service.js`, sem redesenhar painel, banco ou fila.

---



## Central de Embeds V2 — estado atual

O caminho `/adm → Personalização do bot → Mensagens Personalizadas / Embeds` agora abre um construtor persistente de mensagens, separado da configuração visual global usada por `baseEmbed()`. A opção **Padrão do Bot** preserva a edição de `GuildConfig.embedColor`, `embedFooter`, `embedAuthor` e `embedThumbnail`.

### Editor

Cada registro `CustomEmbed` armazena nome interno, título, descrição, cor, autor, rodapé, imagem, thumbnail, timestamp, canal de destino e referência da publicação já enviada. O painel permite criar, listar, renomear, clonar, excluir, visualizar uma prévia e publicar/atualizar a mensagem original.

### Botões

`CustomEmbedButton` armazena até 25 botões ordenados por embed. Há dois tipos ativos:

- `LINK`: abre uma URL HTTP/HTTPS externa, útil para site e redes sociais;
- `CHANNEL`: gera automaticamente `https://discord.com/channels/<guild>/<channel>` para levar o usuário ao canal selecionado, sem exigir que a administração copie o link manualmente.

Os botões podem ser editados, removidos e movidos individualmente. A saída respeita o limite do Discord de cinco botões por linha e cinco linhas.

### Arquivos principais

- `src/components/buttons/admEmbedV2Menu.ts` / `app/components/buttons/admEmbedV2Menu.js`;
- `src/components/buttons/admEmbedV2ButtonItem.ts` / equivalente em `app/`;
- selects `admEmbedV2*`;
- modal `admEmbedV2Modal`;
- `src/utils/customEmbeds.ts` / `app/utils/customEmbeds.js`;
- migration `20260930210000_add_custom_embed_v2`.

## 9. Banco de dados e migrations

O schema possui modelos para módulos administrativos, sociais, jogos, campeonatos, métricas, tickets, registro e eventos.

O histórico de migrations vai desde a base inicial de julho de 2026 até alterações de setembro de 2026, incluindo, entre outras:

- sistemas de chat/call;
- famílias;
- tickets;
- registro;
- cleanup;
- Games de Chat;
- feedback;
- VOTEBAN;
- Social;
- Giveaways;
- AUDAZ EM GUERRA;
- Free Fire;
- Bingo;
- relatórios;
- Subida de Membros;
- conclusão do Instagram/Social;
- Submundo;
- Rádio 24h.

Produção executa `prisma migrate deploy` automaticamente no START.

### Política de banco

- nunca apagar banco para “resolver” migration;
- nunca usar `migrate reset` em produção;
- preferir migration aditiva/compatível;
- preservar dados existentes;
- alterações de model devem incluir revisão das consultas consumidoras.

---

## 10. Configuração e segredos

Variáveis identificadas no pacote:

- `DISCORD_TOKEN`
- `CLIENT_ID`
- `DATABASE_URL`
- `DEV_GUILD_ID`

O código também pode consultar `NODE_ENV`.

O pacote analisado contém um arquivo `.env`. Seus valores não fazem parte desta documentação e não devem ser copiados para README, prompts, commits ou respostas.

---

## 11. Documentos especializados já existentes

### Social

`README_FIX_CURTIDAS.txt` registra uma correção específica para preservar embed e attachment ao atualizar curtidas/comentários.

---

## 12. Riscos técnicos / pontos de atenção atuais

### 12.1 Divergência `src` x `app`

É o principal risco de manutenção. Um agente pode editar `src`, gerar `dist` e ainda assim não alterar o que a Square Cloud executa. Também pode reconstruir `app` a partir de um `src` incompleto e apagar funcionalidades de produção.

### 12.2 Documentação histórica espalhada

Existem READMEs e TXT de versões específicas. Eles são úteis para contexto do módulo, mas podem estar defasados em relação ao código atual.

### 12.3 `.env` dentro do pacote

O arquivo deve ser tratado como segredo. Em distribuições externas, o ideal é enviar `.env.example` sem valores e manter as credenciais apenas na hospedagem/ambiente local.


### 12.4 Integração de áudio externo

A Rádio 24h depende da resolução de mídia do YouTube. O módulo foi isolado para que mudanças nessa integração não contaminem o restante do sistema, mas reprodução real deve ser validada no ambiente de deploy sempre que houver mudança nas dependências ou no comportamento do provedor.

### 12.5 Validação de build

O ZIP não traz `node_modules`. Um `tsc --noEmit` executado sem instalar dependências não constitui validação confiável do código. Antes de certificar build, é necessário restaurar dependências com o lockfile e então executar as verificações.

---

## 13. Protocolo para novas funcionalidades

Em cada implementação nova:

1. identificar módulo e arquivos pelo `AGENTS.md`;
2. avaliar impacto em Prisma;
3. implementar no menor escopo possível;
4. atualizar o artefato realmente executado em `app/`;
5. testar o fluxo afetado;
6. atualizar esta documentação se o estado técnico mudou;
7. adicionar entrada em `docs/CHANGELOG.md`;
8. atualizar `AGENTS.md` se a nova funcionalidade criar uma nova rota de contexto.

A documentação faz parte da entrega, não é etapa opcional posterior.

### Administração de páginas de registro

A área **Páginas de Registro** permite selecionar qualquer página existente e gerenciá-la diretamente. O administrador pode adicionar ou remover cargos da página escolhida e excluir a própria página. Ao excluir uma página intermediária, a ordem das páginas seguintes é compactada automaticamente.

### Integridade de configuração de Tickets

`ticketConfig(guildId)` garante primeiro a existência do registro pai em `GuildConfig`, evitando violação da foreign key `TicketConfig.guildId -> GuildConfig.guildId` em servidores que ainda não possuam a configuração-base criada.

### Persistência do SQLite em atualizações da Square Cloud

O arquivo ativo é `prisma/dev.db` (`DATABASE_URL=file:./dev.db`). O deploy/commit da Square Cloud substitui os arquivos da aplicação pelo conteúdo enviado. Portanto, enquanto este projeto permanecer em SQLite dentro da pasta da aplicação, o ZIP de atualização não pode carregar um banco local, vazio ou desatualizado.

Procedimento atual de atualização:
1. `prisma/dev.db` da Square Cloud é o estado vivo e **não entra no ZIP de atualização**;
2. `dev.db.backup` e arquivos `.bak` também ficam fora do pacote;
3. preparar somente código + migrations, sem resetar o banco;
4. testar migrations novas em uma cópia do banco real quando ele for fornecido;
5. deixar `prisma migrate deploy` aplicar apenas as migrations pendentes durante o START;
6. nunca usar `prisma migrate reset` ou `db push --force-reset` em produção.

Solução estrutural recomendada: migrar produção para PostgreSQL persistente/externo para separar completamente código e dados e permitir deploys sem transportar o banco junto do ZIP.

## Parcerias
Módulo V1 disponível em `/adm → Atendimento → Parcerias`.

Arquivos principais:
- `src/utils/partnerships.ts` / `app/utils/partnerships.js`
- `src/components/buttons/admPartnershipsMenu.ts`
- `src/components/buttons/partnershipButtons.ts`
- `src/components/modals/partnershipModals.ts`
- `src/components/selects/partnershipAdminSelect.ts`

Persistência:
- `PartnershipConfig`: canais, cargos, aparência, requisitos, contador e status.
- `PartnershipRequest`: solicitações, responsável, status e decisão.

Fluxo: painel público → formulário → canal privado → assumir → aprovar/recusar/fechar → transcript/log → DM. Em aprovação, o cargo configurado pode ser concedido e uma divulgação pode ser enviada ao canal configurado.

Regra de deploy SQLite: o ZIP de código não inclui `prisma/dev.db`, backups ou `.bak`; a nova estrutura entra apenas via migration aditiva no `migrate deploy`.


### Painéis modernos — Parcerias e Denúncias

Os dois módulos usam agora o mesmo padrão visual do sistema moderno de Tickets. A área **Painel** mostra prévia e separa **Editar Embed** de **Editar Botão**. O botão principal aceita texto, emoji e cor (`PRIMARY/AZUL`, `SECONDARY/CINZA`, `SUCCESS/VERDE`, `DANGER/VERMELHO`). Se o painel já estiver publicado, alterações de embed ou botão tentam atualizar a mensagem existente automaticamente.

Persistência adicionada por migration `20260930214500_panel_buttons_reports_partnerships`, exclusivamente aditiva.

## Submundo e SUBIDA DE MEMBROS — verificação 2026-09-30

- O módulo **Submundo** continua implementado em `app/submundo/` e seus componentes, com fotos/vídeos anônimos, DM anônima, mensagens estilo Correio Anônimo, reações 🔥/🔞, horários, limpeza e destaque.
- O problema encontrado era de **roteamento administrativo**: a seção `ENTRETENIMENTO` havia sido removida de `app/utils/admPanel.js` e as rotas de Submundo/Rádio/INSTA/Sorteios haviam sido retiradas de `app/components/selects/admSectionSelect.js`. A seção e as rotas foram restauradas sem alterar banco ou migrations.
- **SUBIDA DE MEMBROS** foi auditado no código executado em produção: `messageCreate` chama `countMessage`, `voiceStateUpdate` chama `voiceChanged`, e `ready` executa `reconcileVoice` no boot e a cada 60 s. O painel, selects e modals usam handlers por prefixo e os intents necessários estão ativos.
- Verificação no banco real fornecido mostrou tabelas `MemberRiseStage`, `MemberRiseProgress` e `MemberRiseHistory` íntegras, com progresso real já registrado em mensagens e voz. Nenhuma alteração de banco foi necessária.
- Pacotes de atualização continuam **sem** `prisma/dev.db`, backups `.db` ou `.bak`.

## Auto-Cargo

- Entrada administrativa: `/adm → Entrada e evolução → Cargos automáticos`.
- Permite ativar/desativar o sistema e selecionar até 10 cargos.
- Ao receber `guildMemberAdd`, o bot lê `GuildConfig.autoRoleEnabled/autoRoleIds` e atribui somente cargos existentes, não gerenciados e abaixo do cargo do bot.
- Cargos removidos do servidor são ignorados sem interromper a entrada do membro.
- Persistência: campos aditivos em `GuildConfig`; migration `20261002203000_auto_role`.



## Equipe e proteção — refinamento aprovado (21/10/2026)

A área tem quatro destinos: Equipe e permissões (`administracao`), Proteção automática (`protecao`), Moderação de membros (`moderacao`) e Logs e auditoria (`logs`). Os IDs legados continuam roteados. Nenhum slash command ou modelo de banco novo foi necessário nesta etapa.

Equipe distingue Administradores do bot (acesso total), Permissões por função (três ações existentes) e Cargos usados pelo bot (oito associações existentes). Seleções salvam via `roleSync` e reabrem o mesmo seletor com o resumo atualizado. `teamRoles` informa cargos excluídos e bloqueia seleções de outro servidor, @everyone e associações que o bot não consegue atribuir. Cargos de acesso não exigem que o bot possa atribuí-los: são verificações de acesso, não concessões de cargo. Administradores do Discord continuam com acesso; administradores do bot passam nas permissões específicas conforme a implementação existente de `hasPermission`.

Proteção automática mantém os seis filtros, listas, limites e monitoramento existentes. A resposta é escolhida explicitamente em `adm-automod-select`: apagar, apagar e advertir ou apagar e silenciar. A seleção substitui o antigo botão que alternava respostas sem escolha direta. As alterações e os formulários atualizam a embed de origem. Monitoramento continua observacional, restrito à reintegração, com canais do servidor atual. Percentuais, contagens e durações recebem validação de inteiros e limites antes de salvar.

Moderação começa pela seleção de um membro. `moderationPanel` mostra advertências, silenciamentos, ações anteriores e ocorrências de palavras, com ações e reversões pareadas. Formulários inclusive os IDs legados de moderação apenas abrem uma revisão: membro, ação, motivo, duração quando aplicável, preferências de aviso e limites de escalonamento de advertências. Confirmar chama os serviços de moderação existentes; cancelar não aplica nada. Motivos das reversões são preservados nos registros de auditoria do bot.

A revisão usa token aleatório em memória, válido por dez minutos, restrito ao servidor, autor e mensagem de origem; é consumido antes de executar para bloquear repetição. Reinício invalida revisões abertas. A confirmação revalida acesso, hierarquia, capacidade do bot e as configurações relevantes; mudanças de política ou contagem de advertências exigem nova revisão. Erros recuperáveis retornam ao painel do membro com orientação. Falhas de API/registro podem ocorrer após uma ação Discord, por isso o painel orienta consultar o histórico antes de tentar novamente. Não há promessa de transação atômica entre Discord e SQLite.

Logs começam pelo destino geral; Personalizar por categoria contém os quatro destinos opcionais. Categorias sem destino próprio mostram o canal geral; destinos excluídos/inacessíveis ou sem permissão aparecem no resumo. Ações da equipe exibe até 15 eventos de `AdminLog`; não representa toda a auditoria nativa do Discord.

Validação focada: `node --test tests/admin-ui.test.cjs tests/personalization.test.cjs tests/security.test.cjs` (47 testes). Os testes usam banco/API simulados; não executam punições reais ou login. Demonstração HTML gerada por builders reais, com nove vistas e dez capturas desktop/celular. TypeScript mantém os 38 erros preexistentes, sem novos erros. `app/` recebe apenas alterações direcionadas; handlers exclusivos de produção em roleSelects são preservados.


## Central de logs configurável e envio externo (21/10/2026)

Entrada: `/adm → Equipe e proteção → Logs e auditoria`. A central apresenta quatro tarefas: O que registrar, Onde enviar, O que ignorar e Testar envio. Ações da equipe e Logs de Tickets e Registro ficam como consultas/atalhos secundários. Onde enviar reúne destino, canal geral e separação por categoria. As seleções e formulários atualizam a mesma mensagem.

`src/logging/config.ts` define 24 tipos de eventos em sete grupos: Membros, Calls, Mensagens, Moderação, Servidor e segurança, Sistemas do bot e a categoria anterior de Reintegração. Entrada/saída e os quatro grupos anteriores de ações permanecem habilitados por padrão. Novos eventos de alto volume começam desabilitados. Cada grupo tem um seletor múltiplo; vazio desabilita seus eventos. Uma leitura sem configuração não cria registros. O cache de configuração dura dois segundos e é invalidado ao salvar.

`ServerLogSettings`, indexado pela chave primária guildId, mantém modo de entrega, flags e destinos por grupo em JSON, destino externo, responsável autorizador e filtros. A migration `20261021220000_server_log_center` cria somente esta tabela. Não altera nem remove registros anteriores. A migration de personalização continua acompanhando a entrega cumulativa. Prisma Client gerado com `--no-engine`; não foi possível executar o CLI nativo de migrations no ambiente.

Modos: LOCAL (servidor de origem), EXTERNAL (somente externo) ou BOTH. Sem nova configuração o modo permanece LOCAL e os canais anteriores continuam funcionando. Destino específico tem prioridade sobre o canal geral. Um override local explicitamente nulo usa o geral e ignora o destino legado da categoria. A configuração externa exige IDs do servidor e canal geral; canais por grupo são opcionais. Trocar o servidor externo limpa seus overrides antigos. Tickets e Registro mantêm configuração, destinatários e lógica independentes.

Configuração exige `isBotAdmin` na origem. O autorizador externo precisa de Administrador ou Gerenciar Servidor no destino; o bot precisa estar nos dois servidores e poder ver o canal e enviar mensagens/embeds. A cada envio externo são buscados novamente o membro autorizador na origem e no destino: a perda de associação ou de acesso administrativo interrompe o envio externo. Um administrador autorizado deve reconfigurar/reativar o destino com sua própria autorização. Canais externos são conferidos dentro do servidor escolhido. Falha externa não redireciona dados ao canal local quando o modo é EXTERNAL; em BOTH, cada destino tem tentativa independente.

`delivery.ts` enfileira envios sem bloquear as operações do bot. Limites: 300 eventos pendentes no total, 100 por origem, contadores de descarte/falha visíveis no diagnóstico. Discord.js administra os rate limits HTTP. A fila e os diagnósticos ficam em memória, não são arquivo de auditoria durável e se perdem ao reiniciar. Não há reenvio automático que possa duplicar mensagens após uma falha incerta. As estruturas de cache e diagnóstico possuem limite de 500 origens. Cada embed identifica nome/ID da origem, categoria e horário e desabilita menções no envio. Não são criados canais automaticamente.

`adminLog.ts` continua persistindo a auditoria administrativa no SQLite mesmo se seu envio ao Discord estiver desativado. Somente o encaminhamento passa pela central. O canal específico de Famílias, antes exclusivo de app/, foi preservado como fallback local; ele não contorna o modo somente externo. Contexto de entrada/saída preserva cargos e identificação de bot mesmo após a remoção do cache. Os handlers operacionais de registro, cargos automáticos, presença, MOV CALL, famílias, Social e demais módulos permanecem existentes.

Handlers adicionais `events/log*.ts` observam apelidos/cargos, voz, mensagens, canais, cargos e configurações do servidor; são listeners separados dos handlers operacionais. Calls registram entrada, saída, troca e estados de microfone/áudio, independentemente de MOV CALL estar ativo. Mudanças de permissões usam nomes legíveis nas embeds. Os logs não registram áudio de voz e não arquivam todas as mensagens enviadas.

Mensagens editadas usam a versão anterior em cache. Buscar uma parcial só recupera a versão atual; o antes ausente é informado como indisponível. Exclusão individual preserva apenas texto/metadados/anexos disponíveis no evento. URLs de anexos não garantem disponibilidade depois da exclusão. Exclusão em massa gera um único resumo de até dez mensagens, com amostra truncada; não é transcript completo. Eventos nativos de edição/exclusão/voz/canais/cargos não informam o executor e não são atribuídos ao autor da mensagem ou ao membro movido. Banimentos fora do bot usam GuildAuditLogEntryCreate, com executor confirmado pela entrada de auditoria. Eventos desse tipo executados pelo próprio bot são omitidos para não duplicar suas sanções já registradas.

Filtros de canais incluem categorias e ancestrais em cache; cargos ignorados e outros bots são opcionais. O próprio bot é sempre excluído de logs de conteúdo/movimentação para evitar repetição. Se há filtros de cargo e faltam dados do cargo no evento de mensagem/call/membro, o evento é omitido de forma conservadora. Na exclusão em massa, a filtragem ocorre por mensagem e o resumo mantém somente autores permitidos com cargos conhecidos. Ignorar eventos não remove o histórico administrativo já salvo.

O bot já solicita Guilds, GuildMembers, GuildMessages, GuildVoiceStates, MessageContent e GuildModeration. Message Content e Server Members devem estar habilitados/aprovados no Developer Portal conforme a aplicação. Receber entradas de auditoria exige Ver Registro de Auditoria. Teste e diagnóstico mostra limites de conteúdo, permissões e resultados reais dos envios. Testar destino externo envia somente o exemplo ao destino externo configurado, mesmo no modo LOCAL, sem ativar eventos ou mudar o modo. O teste geral segue o modo atual e o destino de Sistemas do bot. Contadores reiniciam com o processo.

Validação: quatro suites com 75 testes offline, incluindo revogação de autorização nos dois servidores, isolamento, ausência de fallback indevido, filtros, fila limitada e eventos. Migration SQL testada numa cópia isolada do banco do SNAPSHOT: valores de todas as 123 tabelas existentes preservados e nova tabela vazia. O arquivo original não foi alterado e a cópia temporária foi removida. TypeScript mantém 38 erros anteriores sem novos. Demonstração gerada pelos builders reais tem dez telas e doze capturas desktop/celular. Nenhum login, log real, consulta a banco vivo ou deploy foi executado.


### Refinamento de navegação da central (21/10/2026)

O resumo inicial mostra apenas destinos ativos com nomes de servidor/canal, total de eventos e pendências reais de configuração ou autorização. Um destino externo opcional não configurado não aparece como erro. A leitura verifica somente as rotas de grupos ativos; não afirma entrega garantida. IDs permanecem nos formulários e em Detalhes e ajuda. Onde enviar unifica os controles de modo, canal geral local, configuração/teste externos e destinos por categoria; os IDs antigos de Organização dos canais continuam abrindo esta tela unificada.

A interface apresenta seis categorias. Sistemas do bot reúne os dois grupos persistidos `system` e `reintegration` por meio do alias visual `bot`. O seletor `events:bot` modifica as flags dos dois grupos de forma explícita; seletores legados de `system` e `reintegration` continuam independentes. Nos canais, Sistemas do bot abre uma segunda escolha entre operações do bot e Reintegração, preservando destinos próprios. Salvar uma categoria externa desse conjunto retorna à tela que mostra o canal alterado.

Categorias usam os PNGs aprovados já disponíveis como emojis da aplicação: Membros, Atendimento para Calls, Social para Mensagens, Segurança para moderação/segurança e Estrutura para Sistemas. O escudo permanece na central. Nenhum novo ícone Unicode substitui os PNGs; sem emoji provisionado, o rótulo textual permanece.

O que ignorar tem explicação curta e ajuda contextual; quando há filtro de cargos, a omissão de eventos sem dados de cargo é informada na própria tela. Testar envio contém a ação de teste e acesso secundário a Verificar permissões, que reúne intents, auditoria e limites da fila. A função de teste, a fila e todas as verificações de acesso permanecem iguais às da implementação anterior.

Logs de Tickets e Registro abre atalhos para os canais de Tickets, relatórios externos e configurações gerais de Registro. Esses atalhos chamam os controllers de produção de app/, sem copiar versões incompletas de src/. Um adaptador de interação redireciona update/editReply para a mensagem já reconhecida e acrescenta Central de logs em uma linha de botões compatível com os limites nativos. Nenhuma configuração de módulo é reescrita pela central. Os retornos internos seguintes continuam sendo os retornos próprios do módulo.

Validação desta etapa: 75 testes offline, incluindo agrupamento com compatibilidade de IDs antigos, nomes de destino, PNGs e atalhos para os controllers reais de produção. Comparação TypeScript mantém a base de 38 erros. Demonstração de antes/depois inclui 12 vistas e dez capturas desktop/celular. Não há mudança de schema, migration, dependências ou slash commands nesta etapa; o pacote cumulativo mantém as duas migrations anteriores.


## Refinamento administrativo das demais áreas (21/10/2026)

`src/utils/adminTasks.ts` e o equivalente em `app/` normalizam os painéis de entrada de 19 módulos. O catálogo permite somente tarefas explícitas, agrupa botões de navegação visíveis em select nativo e mantém os IDs originais, os controles de estado e um retorno à área. Os payloads continuam dentro das cinco linhas do Discord. O adaptador `adminTaskSelect` revalida o administrador e encaminha o ID permitido ao handler existente, vinculando métodos à interação original para conservar o reconhecimento da mensagem. Os handlers operacionais continuam responsáveis pelas próprias permissões, confirmações e efeitos.

`registrationAdmin` reúne a navegação do Registro em Formulário, Cargos após registro, Mensagens e publicação, Atendimento e equipe e Logs. `registrationSettings` valida campos permitidos, canal/cargo do servidor, capacidade de concessão e conflito entre cargos adicionados e removidos. Configurações são salvas por `guildId` e atualizam a mensagem de origem. As páginas são buscadas pelo par `id`/`guildId`; edição mantém descrição e obrigatoriedade, e reordenação faz uma troca transacional usando uma ordem temporária livre. A criação revalida o limite de cinco páginas dentro da transação. Testes e confirmação preservam respostas ao voltar, respeitam a sessão do servidor e revalidam perguntas obrigatórias.

O editor completo de Registro e o editor de Tickets continuam exclusivos de produção. Foram preservados upload, imagem pequena, banner, autor/rodapé e configurações do botão. Salvar nos editores não chama envio/edição pública; os controles explícitos de publicação continuam disponíveis. O Registro não substitui o rodapé público por uma lista administrativa de itens. `registrationPublicPreview` e o editor interno reusam os builders salvos, com ações públicas de exemplo desabilitadas. A publicação do Registro não interpreta falha de permissão ao buscar a mensagem como mensagem apagada: somente o código Discord 10008 autoriza recriação no destino explicitamente selecionado.

`adminMessagePreview` usa os builders de Parcerias, Denúncias, Feedback e Submundo; editar atualiza a mensagem de origem, com controles de exemplo desabilitados e publicação separada. Horários e demais ações operacionais do Submundo continuam atualizando seu painel quando necessário; isto não é um sistema de versões históricas de modelos. `partnershipSettings` apresenta canais e cargos com os valores atuais; seleções verificam o destino e mantêm a tela aberta. A aparência de sorteios reabre o builder da mesma mensagem, e a aparência de INSTA atualiza a configuração visível. Nenhuma configuração foi aplicada a outro servidor ou ao perfil global da conta.

Transferência de cargos deixa a entrada de Reintegração e passa a Cargos e automações, mantendo IDs e serviço. O retorno da transferência aponta para essa nova origem. Oficialização mostra um resumo compacto e configura seus dois cargos em tela própria; mensagens retornam à prévia após editar. Rádio usa `radio-mode-select` para uma escolha explícita, mantendo o serviço de reprodução existente. Os módulos de Famílias, Sorteios, Social, Submundo e Rádio exclusivos de `app/` foram preservados. Não houve cópia de `dist/` sobre `app/`.

`tests/admin-refinement.test.cjs` acrescenta 32 verificações: renderização dos módulos, limites de componentes, roteamento permitido, reconhecimento da interação original, escopo de servidor, reordenação, mudanças visíveis, prévias sem publicação, seletores preservados e modo de teste sem concessão real de cargos/registros. Com as quatro suítes anteriores, são 107 testes offline. O relatório visual tem 50 vistas reais com dados fictícios e foi conferido em 1040 e 420 px, sem erro de script ou transbordamento horizontal. A checagem global conserva os 38 erros preexistentes. Não houve autenticação externa, acesso ao SQLite vivo ou deploy nesta etapa. Sem nova dependência, schema ou migration; a entrega cumulativa mantém as duas migrations aditivas anteriores.

## Social e entretenimento — expansão de 22/10/2026

A Square Cloud continua executando `app/index.js`. A extensão `app/social-experience/` é exclusiva de produção, assim como os módulos Social/INSTA, Submundo e Rádio avançados que ela integra. Não substituir app/ por um build integral de src/. `admPanel` e `admSectionSelect` foram sincronizados em src/ e app/: a sétima área agora possui INSTA, Dinâmicas sociais, Submundo e Rádio 24h; total de 29 destinos. Nenhum slash command ou dependência foi adicionado.

### Publicação e mídia do INSTA

`app/social/media.js` constrói um Container com TextDisplay, MediaGallery e as ações existentes. O arquivo de imagem/GIF/vídeo é anexado **uma única vez à mensagem pública**, com referência attachment://. O player de vídeo usa a galeria nativa de Components V2: EmbedBuilder clássico não incorpora um player de vídeo enviado pelo bot. Curtidas/comentários preservam explicitamente os IDs dos anexos, limpam embeds/content legados ao migrar e não reenviam a mídia.

`social/service` valida formatos, legenda, cargos, limites, guildId e permissões existentes; serializa novos posts por servidor/autor. Os downloads aceitam apenas CDN HTTPS do Discord, sem redirects, com timeout e limite de 25 MiB. O Discord pode aceitar um tamanho menor conforme o servidor: falhas de envio preservam o original e mostram orientação. Múltiplos anexos são recusados sem descartar arquivos. A exclusão da mensagem original acontece somente depois de upload e persistência confirmados. Falha de persistência tenta remover a cópia pública incompleta. Falhas dos destaques não reclassificam uma publicação já concluída como falha.

Destaques e anúncio de destaque usam o mesmo cartão V2, incluindo estado vazio. As URLs CDN dos posts antigos são renovadas por leitura limitada às últimas 100 mensagens do canal de armazenamento da mesma guild e correspondência exata de attachmentId, com cache de dois minutos. Arquivos antigos apagados ou fora dessa janela não podem ser reconstruídos a partir de uma URL expirada: nesses casos é preciso reenviar a mídia. Posts históricos só de texto continuam renderizáveis.

No painel de participação, Publicar abre upload + legenda → prévia real em cartão V2 → Confirmar/Cancelar. Rascunho dura dez minutos e é consumido atomicamente, vinculado a servidor e autor. Confirmar revalida a configuração e usa o mesmo serviço dos envios diretos. O envio direto no canal configurado continua disponível. Minhas publicações lista somente posts ativos do próprio membro, com paginação e links para as opções existentes de cada publicação.

### Dinâmicas sociais

`activities.js`: Pergunta do dia, Você prefere?, Enquete e Desafio temático; propostas prontas e até 100 propostas próprias por servidor. Tipos ativos, canal, HH:MM e intervalo de 1–7 dias são administráveis; campos salvos aparecem na mensagem de origem. As propostas podem ser editadas ou pausadas, afetando publicações futuras.

A rotina usa timezone de GuildConfig, executa a cada minuto e publica uma vez por data local, respeitando o intervalo. Ao reiniciar depois do horário, recupera apenas a proposta do dia atual. A chave única guildId/scheduleKey e o estado PROCESSING impedem reenvio automático de um envio incerto; o administrador pode conferir o aviso e publicar manualmente. Publicar agora exige confirmação e também consome uma chave única. Dinâmicas anteriores permanecem consultáveis, com uma resposta/voto editável por pessoa. Contagens são consultadas de forma agregada, sem carregar todas as respostas; votos individuais não são divulgados. Respostas abertas são públicas e paginadas.

### Rádio e pedidos

`social-experience/radio.js` mantém pedidos em SQLite, separados de RadioTrack. Configuração: ativar/desativar, exigir aprovação ou fila direta, limite de 1–10 pedidos ativos por pessoa e intervalo de 30–3600 segundos. Links passam pelo parser YouTube existente; resolução de áudio continua no serviço da rádio. A equipe revisa cada pedido e o membro pode acompanhar seus próprios pedidos e falhas.

Pedidos aprovados são reivindicados atomicamente e tocam antes da próxima faixa da playlist, sem entrar permanentemente nela. Terminados, deixam a fila. Falhas registram o erro e a playlist segue; pedidos interrompidos por reinício são marcados como falhos, evitando repetição automática incerta. Reiniciar uma faixa conserva seu estado de pedido ativo; parar a rádio cancela o pedido interrompido.

O painel público mostra faixa atual e próximos pedidos. Publicar/atualizar é explícito. O scheduler edita o mesmo painel somente quando seu conteúdo muda. Votar para pular exige presença na call configurada, áudio ativado, token da faixa atual, voto único e maioria absoluta dos ouvintes humanos elegíveis. Há trava por servidor e nova checagem do token antes de pular. A playlist, modo, volume e controles antigos permanecem.

### Perfis, participação e privacidade

`profiles.js` oferece bio (300 caracteres), interesses e jogos (150 cada), edição, publicação voluntária, ocultação, exclusão confirmada e descoberta por interesse/jogo. Perfis começam ocultos e o recurso começa desativado. Não importa informações do Registro nem muda identidade global do bot. A busca é paginada e seu filtro fica em sessão de dez minutos, restrita à guild.

`views.js` publica um hub com INSTA, Dinâmicas, Rádio, Minhas publicações, Perfil e Privacidade. Preferências de DM do INSTA e do Submundo são independentes, persistentes e por servidor. O serviço de entrega do INSTA passou a respeitar SocialUserPreference também no backend.

### Submundo

`anonymous.js` aplica opt-out, bloqueio por referência opaca e denúncia em DMs anônimas, incluindo botões antigos de envio. A identidade real nunca entra nos IDs nem no conteúdo enviado ao destinatário; fica disponível nos registros privados. Entregas expiram em sete dias, com intervalo persistente de 30s por remetente. Denúncias confirmadas são preservadas para revisão e enviadas somente ao canal privado da guild de origem. A preferência padrão preserva o comportamento antigo de aceitar DMs; o membro pode recusá-las.

Aprovação prévia de mídia e texto é opcional e começa desligada. Ao ativar, exige canal privado +18; até três envios pendentes por pessoa, validade de 48h. Mídia é copiada para a mensagem privada de revisão, permitindo renovação da URL antes da aprovação. Revisão exige acesso ao canal e ManageMessages ou BotAdmin; aprovação/recusa é consumida uma única vez e guarda reviewerId. Aprovar revalida membro, horário, destino +18 e logs privados. Publicações seguem nos modelos originais do Submundo, compatíveis com limpeza, sessões e destaque. O autor recebe a decisão por DM quando disponível. Os formulários explicam o anonimato público e o acesso da equipe aos registros.

### Persistência e validação

Migration aditiva `20261022010000_social_experience`: cria 11 tabelas novas (configuração, propostas, atividades, respostas, perfis, pedidos, votos, submissões, preferências/bloqueios/entregas anônimas), sem alterar tabelas anteriores. Configurações novas começam desligadas; a aplicação do pacote não dispara novos painéis ou dinâmicas. O ZIP cumulativo também preserva as duas migrations das etapas anteriores. `.env`, SQLite, backups e dependências não fazem parte dele.

Validação: 140 testes offline (33 novos) incluindo SQLite real em memória, IDs consumíveis, isolamento, layouts, falhas, galerias de imagem/GIF/vídeo, curtidas/comentários e preservação de anexos. SQL das três migrations aplicado a uma cópia isolada do banco do SNAPSHOT: todas as colunas e valores das 123 tabelas anteriores preservados; integridade ok e unicidade exercitada. A cópia foi removida. Prisma Client gerado com --no-engine; migrate deploy nativo não foi executado no ambiente. TypeScript conserva os 38 erros preexistentes. Prévia independente com 66 telas de builders reais, conferida em 1040/420 px. Testes executados com Node 24; a fixture node:sqlite exige Node >=22.13, sem impacto na execução do bot.

Sem login no Discord, envio real, alteração no banco vivo ou deploy. O player de vídeo precisa de verificação final num servidor de teste após aplicar o ZIP: enviar PNG/GIF/MP4, abrir no desktop/celular, curtir/comentar e confirmar que o anexo permanece no cartão. Formatos/codecs não suportados pelo cliente Discord não ganham suporte por esta mudança.

## Jogos e eventos — experiência de participação (22/10/2026)

### Descoberta e publicação

`commands/jogar` fornece resposta ephemeral com opção de jogo. `games-chat/experience/{common,hub}` mantém validação de membro/equipe, canais da mesma guild, travas por chave, layout nativo e hub persistente. Configuração em `GamesHubConfig`: canal/mensagem, aparência, publishedHash/publishedStyle e anúncio individual da Caixa. Rascunho e aparência publicada são distintos; editar retorna a prévia na mensagem de origem e publicar é explícito. Refresh a cada minuto edita somente a publicação existente quando seu payload muda, usando o estilo publicado. Nenhum novo painel é enviado pelo scheduler.

Botões play:, games-admin:, games-select: e games-form: têm handlers dedicados. `/guerra` já é quiz em equipes: integração reaproveita app/war e suas permissões. A visualização de membro no hub retira o botão administrativo de início. admEventsMenu em app foi alterado diretamente para preservar Game Musical; ready em src/app recebeu somente os hooks necessários. O tipo Command aceita SlashCommandOptionsOnlyBuilder.

### Bingo

`bingo/community` persiste configuração, estado e conferências em BingoExperienceConfig/State/Claim, mantendo BingoMatch/Card/Draw/Winner como registros principais. O novo modo é gratuito e opcional; uma cartela por humano. Fases LOBBY/RUNNING/PAUSED/REVIEW/ENDED, limites e objetivos congelados por partida. Objetivos: ANY_LINE (linha/coluna/diagonal), FULL_CARD e FOUR_CORNERS. Permissões administrativas: BotAdmin ou ManageEvents; controles públicos não executam operações da equipe.

Inscrição, criação, sorteio e conferência usam travas, transações e reivindicações condicionais. Números usam crypto.randomInt e não se repetem. Cartelas são validadas quanto a formato, unicidade, faixa de coluna e centro livre. Conferência válida trava a partida e registra todas as cartelas aptas no mesmo drawVersion, com unicidade matchId/cardId. A equipe revisa e encerra; não há segunda etapa automática. Histórico e vencedores são consultáveis, com paginação quando necessário.

`communityViews` usa embeds e componentes nativos. Cartela privada textual 5x5 marca sorteados e mostra melhor combinação/última consulta, com Atualizar; a resposta ephemeral não recebe push a cada número. `cardAccess` cobre cartelas do fluxo antigo e pendentes sem depender de DM. Modo comunitário não vincula cartelas/pedidos pendentes. Serviços clássicos preservam a vinculação anterior e agora rejeitam a entrega de cartelas estranhas a uma partida comunitária. Botões clássicos de operação verificam a mensagem da partida; pausa/retomada/encerramento mantêm novo estado coerente.

Ready chama community.tick imediatamente e a cada 2s. Prazos são persistidos; retorno após queda sorteia no máximo um número vencido por rodada de processamento, sem catch-up em rajada. GAME_BUSY só adia o tick; falhas operacionais pausam com aviso da equipe. Não há agendamento de inscrição, lembretes por DM ou prêmio financeiro novo neste modo.

### TERMO

`termo/lexicon` fornece 532 respostas e 664 formas normalizadas totais de cinco letras; seeder acrescenta faltantes sem reativar palavras desativadas. Palavra diária usa sorteio criptográfico persistido e repetição por histórico da guild, respeitando a fonte configurada. nextMidnight foi corrigido para buscar a próxima troca de data local; o deadline atual é corrigido quando inconsistente. Rodadas guardam maxAttemptsSnapshot/wordLengthSnapshot; modals guardam roundId e rejeitam tentativas de um dia antigo. Submit serializa por partida e atualiza palpite/estatística em transação com validação de estado.

Tabuleiro privado é salvo, com tentativas e sequência ajustada para dias perdidos. revealOnLoss é respeitado; inválidos não gastam tentativa. TermoGame guarda pointsEarned para ranking semanal e sharedMessageId para publicação voluntária de grade sem letras/resposta. Reivindicação de compartilhamento é única e libera retry quando o envio falha; não altera pontos ou vitória. O editor de aparência não cria rodada nem envia mensagem, e usa a aparência salva na prévia. Palavras próprias de 4–12 letras podem ser preparadas antes de mudar o tamanho; regras não aceitam tamanho sem resposta elegível.

### Caixa e compatibilidade

mysteryView limita a 20 caixas por página e reserva a quinta linha para Meu resultado, Resultados, Como jogar e Mais caixas. Mantém até 25 caixas no evento, uma abertura por membro e o serviço de entrega anterior. mystery-panel: consulta resultado/entrega próprios ou resultados paginados; integrações externas continuam PENDING_EXTERNAL. Anúncios individuais são opcionais em GamesHubConfig e começam ativos para preservar comportamento anterior. Falha de anúncio celebrativo não reverte uma abertura/entrega válida.

getOrCreateGuildConfig preserva findUnique para registros existentes e usa upsert com recuperação de corrida P2002 na primeira criação. Não há mudança de pacotes, squarecloud.app ou dependências. Produção app/ foi sincronizada por arquivo; módulos exclusivos não foram sobrescritos.

### Banco e verificação

Migration `20261022140000_games_experience`: quatro tabelas novas, duas colunas nullable em TermoRound e pointsEarned/sharedMessageId em TermoGame. Backfill de pontos usa a regra das vitórias anteriores, só na nova coluna. BingoOrder e campos antigos de BingoConfig foram reconciliados com migrations/banco existentes; não há SQL para recriá-los. Quatro migrations aditivas no ZIP cumulativo. Sem reset, db push, inclusão de SQLite ou alteração de .env.

185 testes offline aprovados (45 novos), incluindo SQLite real em memória com schema e migration, concorrência, escopo, regras, estados, recuperação e limites dos payloads. SQL aplicado às quatro etapas numa cópia isolada do banco fornecido: todas as colunas e valores das 123 tabelas anteriores preservados, integrity_check ok; cópia removida. Prisma Client gerado com --no-engine; CLI migrate deploy nativo não executado aqui. Typecheck passou de 38 erros anteriores para um erro preexistente em src/components/selects/denunciaSelects.ts:61, fora deste módulo. Prévia com 24 telas de builders reais, dados ilustrativos, imagens embutidas; conferida em 1040/420 px sem overflow ou erros de script. Revisão visual de inscrição, cartela, equipe, TERMO, Caixa e hub concluída sem nova rodada de polimento. Sem login no Discord ou deploy; timers, entregas e interação real dependem de validação final no servidor de teste.


## Mensagens V2, publicações independentes e cargos por reação — 23/10/2026

### Rotas e código executado

- `/adm → Personalização do bot → Mensagens Personalizadas / Embeds`: Criar mensagem, Modelos salvos e Mensagens enviadas.
- `/adm → Entrada e evolução → Cargos e automações → Cargos por reação`: gerenciamento próprio de painéis. Cargos ao entrar e Transferência programada continuam acessíveis na mesma central.
- O atalho Usar em painel de cargos copia o documento atual para um painel independente; não transforma nem vincula o modelo ou seus envios.
- Fonte em `src/message-maker/{document,common,service,views,editorInteractions,roles,roleInteractions,interactions,navigation}.ts`; equivalentes direcionados em `app/message-maker/`. Produção permanece em `app/index.js`.
- Prefixos exclusivos `maker:`, `maker-select:` e `maker-form:` nos três handlers messageMaker. O dispatcher intercepta IDs antigos `embedv2*` para abrir o novo fluxo, sem executar publicações pelo editor clássico.
- A navegação preserva sete áreas e 29 destinos. Central e áreas têm apresentação curta: as categorias e descrições ficam nos seletores, com os PNGs aprovados.

### Documento, editor e publicações

O documento serializado tem versão 2, cor e blocos de título, texto, seção com miniatura, galeria de imagens, separador e linha de botões de link/canal. Não há escolha de editor clássico. URLs aceitam somente HTTP(S), sem credenciais. A interface edita até 25 blocos; cada linha de links aceita cinco botões. O renderizador público valida os limites nativos de 40 componentes e 4.000 caracteres de texto. Prévia e confirmação usam o mesmo renderizador, com páginas que reservam espaço aos controles; a publicação contém o documento completo e exige que caiba em uma mensagem.

A sessão pertence ao servidor, administrador e mensagem de origem e dura 24 horas. Formulários atualizam essa mesma mensagem com o conteúdo real. Revisões otimistas rejeitam controles e formulários antigos; Desfazer guarda a alteração anterior. A sessão permite retomar um rascunho compatível a partir do mesmo painel, mesmo após reinício. Salvar modelo/painel não envia nem atualiza o canal público. Publicar abre escolha de canal e revisão explícita; edição de um envio existente mantém o canal e altera somente aquele messageId.

Cada publicação armazena seu próprio snapshot, nome, canal, messageId, hash, revisão, autor, datas e estado. Editar este envio parte do snapshot e não altera o modelo nem outras publicações. Duplicar/publicar uma cópia cria outro envio. Exclusão lógica do modelo preserva publicações; exclusão de uma publicação exige confirmação e não apaga os outros envios. Menções automáticas ficam desativadas.

Modelos CustomEmbed são importados de maneira idempotente por guildId, sem modificar as linhas antigas. Importa-se somente a última mensagem cujo ID/canal já estava registrado. O snapshot de um envio legado é uma prévia convertida do modelo, não uma leitura garantida do conteúdo histórico. A interface exige conferência do original. Textos, imagens, author/footer e links são convertidos para blocos; os dados originais permanecem preservados.

A escrita registra o envio antes da chamada externa e mantém estados intermediários. Timeout ou resposta incerta não criam outra mensagem silenciosamente. Registrar mensagem existente aceita somente mensagem do próprio bot, mesmo canal/servidor e conteúdo compatível com o snapshot ou painel em preparação. Mensagem apagada, falta de acesso e entrega não confirmada têm estados distintos. Discord e SQLite não compartilham transação; conferir o canal continua necessário após uma falha incerta.

`utils/componentMessages` adapta o retorno dos painéis clássicos quando a mensagem de origem já usa Components V2, cujo flag não pode ser removido. O Proxy distingue atualizar a origem de uma resposta privada independente; não transforma indiscriminadamente replies de erro em V2. Não remover esse adaptador ao alterar a navegação.

### Cargos por reação

Um painel aceita até 20 associações ativas: um emoji Unicode ou personalizado disponível para o bot e um cargo por associação. Escolhas múltiplas são permitidas; exclusividade entre cargos não integra esta versão. A legenda e a regra de retirada são geradas no cartão e aparecem também no editor. Não há botões para conceder cargos: os eventos de reação reais fazem isso.

O serviço valida hierarquia, cargo editável/não gerenciado/não everyone e bloqueia permissões sensíveis enumeradas em `roles.ts`. Revalida no processamento; publicação exige Gerenciar Cargos, Ver Canal, Enviar Mensagens, Ler Histórico e Adicionar Reações, além do acesso aos emojis. Emojis externos podem exigir Usar Emojis Externos. O novo intent GuildMessageReactions e partials Reaction/User acompanham o código. Server Members já é solicitado e precisa estar habilitado/aprovado no portal quando exigido.

Publicar primeiro mostra o estado em preparação, adiciona as reações e só depois ativa o painel. Falha mantém a mensagem registrada e o painel suspenso para corrigir e atualizar a mesma mensagem. Pausar não retira cargos; reações durante a pausa/offline exigem revisão manual posterior. Trocar um canal depois de publicado exige uma cópia do painel.

Bindings publicados são imutáveis: desative a associação antiga e adicione a nova. A revisão mostra concessões rastreadas e permite preservar cargos ou revisar retiradas em etapas de 25. A desativação confirmada interrompe a concessão dessa associação; editar conteúdo ou regra não publica automaticamente. A regra de retirada configurada entra em vigor na próxima publicação.

Grant registra concessões por associação/membro; Ownership acompanha o papel do bot no cargo por servidor/membro/cargo. Cargo preexistente e concessões ativas de outros painéis são preservados ao retirar uma reação. Eventos repetidos são idempotentes e operações do mesmo membro/cargo são serializadas no processo. Estado ambíguo após interrupção preserva o cargo conservadoramente; a origem de uma concessão externa feita depois do bot não é distinguível pela API Discord.

Conferir funcionamento verifica mensagem, permissões e reações. Sincronizar primeiro lê as reações atuais e mostra o impacto sem alterar cargos; a confirmação relê e processa até 25 operações por etapa. A revisão aceita até 2.000 participações e expira em 20 minutos. Falhas de busca de membro são diferentes de membro ausente; retirada pendente pode ser repetida. Não há varredura automática de todos os painéis na inicialização nem garantia de recuperar todos os eventos offline. Reações de associações retiradas podem continuar visíveis, mas deixam de conceder cargos; não se apagam reações dos membros em massa.

Oito eventos novos cobrem adicionar/remover reação, apagar mensagem individual/em lote, limpar reações, remover um emoji da mensagem, saída do membro e exclusão de cargo. Exclusão ou limpeza suspende o painel afetado. Saída encerra concessões rastreadas daquele membro, sem tentar alterar uma conta fora do servidor. Execute uma instância por banco SQLite; filas locais não constituem coordenação de múltiplos processos.

### Persistência e entrega

Migration aditiva `20261023180000_message_maker_reaction_roles` cria oito tabelas independentes: MakerTemplate, MakerPublication, MakerSession, MakerAction, ReactionRolePanel, ReactionRoleBinding, ReactionRoleGrant e ReactionRoleOwnership. Não altera tabelas anteriores. Existem índices únicos para importação, messageId, concessão por associação/membro e propriedade por servidor/membro/cargo. MakerAction guarda revisões de confirmação com autor/mensagem/servidor, prazo e consumo único; sincronizações registram cursor/progresso. Não criar dependências em banco de teste, não empacotar SQLite e não substituir o banco vivo.

A quinta migration acompanha as quatro anteriores no pacote cumulativo. `app/scripts/verify-prisma-client.js` também verifica os oito delegates. package.json, package-lock.json e squarecloud.app permanecem preservados. Não houve mudança de slash commands nesta etapa.

Validação atual: 240 testes offline em oito suítes (55 novos do Maker/reação), com SQLite isolado e API Discord simulada; 25 telas geradas pelos builders reais em 1040 e 420 px, sem overflow horizontal, erros de script ou requisições externas. SQL das cinco migrations aplicado numa cópia do banco enviado: valores e colunas das 123 tabelas anteriores preservados e integrity_check OK. Prisma validate/generate passaram; migrate deploy nativo não foi executado neste ambiente. O typecheck global conserva um erro anterior em denunciaSelects.ts:61, sem erros novos. A execução real, os limites da API e a renderização nativa precisam de conferência após aplicar a atualização; nenhum login, envio real ou deploy foi realizado aqui.


## Central de segurança — 24/10/2026

### Escopo e navegação

O destino `protecao` agora abre `security/interactions.open`, mantendo as sete áreas e os 29 destinos. Nome visível: Central de segurança. Seis opções no seletor: Entrada e Anti-Raid, Chat e conteúdo, Anti Ban e ações da equipe, Proteção de calls, Incidentes e contenção e Exceções e diagnóstico. Não duplicar categorias no corpo. Os filtros anteriores continuam em admModerationMenu e são acessíveis pelo chat; suas preferências não foram migradas nem desligadas. Há retorno à nova central. Observar vale para a nova regra, sem anular ações de filtros legados.

Fonte em `src/security/{config,actions,entry,messages,audit,locks,incidents,assets,diagnostics,reviews,views,interactions,runtime}.ts`, com equivalentes direcionados em app/security/. Prefixos security:, security-select: e security-form: e três handlers próprios. `admSectionSelect`, `admPanel`, `guildMemberAdd` e `messageCreate` foram alterados em ambas as árvores sem substituir as versões de produção pelos arquivos incompletos de src/. GuildModeration já era solicitado; não há novo slash command ou dependência.

Seis PNGs novos de esmalte branco/vermelho/grafite foram gerados; o headset aprovado foi reaproveitado para calls. Assets em assets/blackout-ui/security/, sete PNGs RGBA128 abaixo de256KiB, nomes blackout_sec_*. Provisionamento sob demanda na abertura, idempotente e sem apagar emojis. Falha preserva rótulos e imagem local de contexto; tenta novamente após5min. Os emojis pertencem à aplicação, não ao servidor.

### Políticas e processamento

São19 regras: raid/bots/age/deny; mentions/text/invites/flood/duplicates/webhooks/honey; bans/kicks/roles/punishments/destruction/vanity; voice/moves. Todas novas começam OFF. Cada regra tem modo OFF/OBSERVE/ENFORCE, ação permitida e limites validados por catálogo. Usar apenas o serviço de configuração para normalizar, salvar por revisão otimista e limpar cache de1,5s. Não transformar um campo JSON arbitrário em uma ação suportada.

Entrada é aguardada antes do auto-cargo. Raid registra entradas no SQLite e conserva raidUntil, aplicando contenção somente às novas chegadas depois do gatilho. Não varre/expulsa os anteriores. Lista bloqueada é independente da reintegração. Texto avaliado antes da exclusão de autores bot permite proteger webhooks; bots comuns continuam fora dos filtros novos. Conteúdo editado não incrementa flood/repetição. As janelas de chat/voz são limitadas em memória e reiniciam com o processo; mensagens repetidas de gateway são deduplicadas. Um conteúdo com mais de uma violação recebe somente uma resposta nova. Menções de logs ficam desativadas.

Auditoria usa GuildAuditLogEntryCreate com executor confirmado e ignora o próprio bot, proprietário, eventos antigos e exceções explícitas. Cotas por executor/janela persistem em SecurityAuditEntry; movimentações usam units agregado quando informado pelo Discord. O evento de voz sem executor apenas registra, nunca pune a vítima. Executor não consultável vira observação. As respostas podem retirar cargos perigosos editáveis e, se explicitamente configurado, restaurar um ban/timeout/cargo/permissão confirmado. Não existe reversão universal ou recuperação de membros/canais apagados.

Concessão de cargo confiável é sensível quando a regra de cargos está ativa; uma autoatribuição não usa a confiança que ela mesma acabou de conceder para escapar. Hierarquia e cargos gerenciados continuam prevalecendo. ProtectedUsers é explícito; ProtectedRoles após saída depende de cache/snapshot recente de até30s. Atualização/saída de membro mantém snapshot somente quando a proteção por cargos está configurada. Não inferir dados históricos ausentes.

Canal/categoria em protectedChannels entra na proteção de permissões. ChannelOverwriteCreate/Update/Delete só são revertidos com identificação, valores anteriores/atuais completos e correlação recente. A consulta de auditoria para reversão é limitada; ausência de prova ou mudança posterior preserva o estado atual para revisão. A API não fornece transação/ETag para garantir isolamento de edições simultâneas. URL personalizada é um monitor, sem tentativa/promessa de recuperação.

### Contenção, confirmações e falhas

BotAdmin pode consultar; alterar políticas, exceções, lista bloqueada ou contenção exige proprietário/Administrador do Discord, revalidado no momento da confirmação. SecurityReview dura20min, vincula guildId/actorId/messageId/configRevision e é consumido por compare-and-swap. Alterar modo/resposta/limites abre revisão na mensagem original; Confirmar salva e mostra o estado vigente. Revisão de ENFORCE confere permissões gerais do bot; execução também valida o alvo. Mudança de regras invalida confirmações pendentes.

Restrição de chats é manual, explícita, por1–60min e até25canais por revisão. Antes da API, SecurityChannelLock guarda os overwrites originais e aplicados. Limita SendMessages, SendMessagesInThreads e criação de tópicos, sem retirar ViewChannel; admins mantêm acesso nativo. Restauração altera somente bits que ainda correspondem à intervenção; novas decisões observadas da equipe não são sobrescritas. CONFLICT fica para revisão manual. Quando restam somente conflitos, a confirmação de conclusão mantém as permissões atuais e encerra os registros, permitindo futura contenção com nova referência. Não libera canais silenciosamente. Expiração é conferida a cada30s e na retomada. Repetir bloqueio não substitui snapshot nem estende prazo silenciosamente.

SecurityIncident reivindica eventKey único antes de ações externas, grava resultado DONE/PARTIAL/FAILED/SKIPPED/CANCELLED/UNCERTAIN e persiste mesmo sem canal de logs. Reinício marca CLAIMED como UNCERTAIN e não repete castigos. Mirror usa security.actions da central existente, preservando destino local/externo/ambos e autorização contínua. Não filtra a decisão porque o infrator é bot; filtros de conteúdo/evento nativos continuam próprios. CLAIMED não é enviado antes de finalizar. PENDING sem tentativa pode ser retomado; SENDING de processo anterior vira UNCERTAIN, sem repetição automática. Reenviar um log exige revisão e nunca reexecuta a resposta. Não prometer exatamente uma vez entre API e banco.

Security runtime tem seis eventos: audit, memberRemove, memberUpdate, messageUpdate, voice e ready. Não substitui o ready de produção. Rotina limpa contagens brutas após2dias, snapshots antigos e revisões expiradas em lotes250; não apaga incidentes. Uma instância por SQLite e filas locais por guild/objeto. Falhas não são compensadas por punição mais forte.

### Persistência, validação e expansão

A sexta migration,20261024180000_security_center, cria oito tabelas independentes: SecuritySettings, SecurityState, SecurityIncident, SecurityAuditEntry, SecurityDenyEntry, SecurityReview, SecurityChannelLock e SecurityMemberSnapshot. Não altera tabelas anteriores. Unique para eventKey, cadastro guild/user, lock guild/channel e snapshot guild/user; índices das cotas e histórico. O verificador de Prisma Client inclui os oito delegates. package.json, lockfile e squarecloud.app permanecem iguais.

319 testes offline em nove suítes, incluindo79 novos de segurança;32 telas nativas extraídas dos builders em1040/420px. A migração SQL cumulativa foi aplicada numa cópia isolada do banco fornecido: todos os valores/colunas das123 tabelas anteriores preservados e integrity_check OK. Prisma validate/generate passaram; migrate deploy nativo e uso real no Discord não foram executados. Typecheck mantém somente denunciaSelects.ts:61, anterior à etapa. Testes e prévia não são teste de carga nem prova de funcionamento em produção. Nenhum login, envio real, banco vivo ou deploy foi realizado.

Guia operacional: SEGURANCA-BLACKOUT.md. Captcha, prisão de acesso, OCR, backup integral/restauração e aprovação de ban por segunda pessoa continuam fora desta etapa; não criar botões fingindo que existem. A referência Nix foi usada como catálogo, sem cópia de marca/arte/código e sem prometer dados indisponíveis da API.
