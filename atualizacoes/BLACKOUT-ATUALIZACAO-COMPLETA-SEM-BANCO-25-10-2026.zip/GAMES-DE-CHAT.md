# Jogos e eventos

O membro encontra jogos por `/jogar` ou pelo painel público configurado pela equipe. A resposta de `/jogar` é privada; a opção `jogo` abre TERMO, Bingo, Caixa Misteriosa, Quiz em equipes ou rankings do TERMO diretamente. Os comandos anteriores continuam disponíveis.

## Configuração e atualização

A Square Cloud executa **app/index.js**, conforme squarecloud.app. O START existente gera o Prisma Client, aplica `prisma migrate deploy`, registra comandos por app/deploy-commands.js e inicia o bot. Preserve .env, prisma/dev.db e as migrations anteriores. O pacote cumulativo inclui a nova migration `20261022140000_games_experience` e as três anteriores. Faça backup do banco vivo antes de aplicar a atualização; o ZIP contém somente código e documentação alterados. Não substitua app/ inteiro por dist/.

Abra `/adm → Jogos e eventos → Games de Chat → Painel de participação e resultados`. Escolha canal, edite a mensagem e veja a prévia na própria mensagem. Salvar não publica: use Publicar / atualizar. Após publicado, o mesmo painel acompanha mudanças de estado, mantendo a aparência publicada até a próxima publicação explícita. O código não recria automaticamente um painel excluído.

O registro de `/jogar` ocorre no START. Se não aparecer, confira o log do registro; DEV_GUILD_ID opcional restringe o registro rápido ao servidor configurado. Não troque credenciais como parte desta atualização.

## Bingo comunitário

Caminho: `/adm → Jogos e eventos → Bingo → Bingo comunitário e dinâmica` ou pelo painel de participação. Escolha canal, objetivo, mínimo/máximo de participantes e sorteio manual ou automático. Confira Mensagem e prévia e confirme Abrir inscrições. Cada membro humano recebe uma cartela gratuita; a equipe inicia quando o mínimo é alcançado.

Objetivos disponíveis: uma linha, coluna ou diagonal; cartela cheia; quatro cantos. As regras da partida ficam fixas, e mudanças posteriores valem para a próxima. A cartela é consultada no servidor em resposta privada, com números marcados, progresso e Atualizar. Não exige DM aberta. Os controles de sortear, pausar, retomar e encerrar ficam no painel da equipe.

Conferir bingo valida as cartelas contra os números registrados e reconhece todos os vencedores aptos no mesmo sorteio. A partida pausa para conferência; a equipe consulta vencedores e encerra. Não há avanço automático para uma segunda etapa da mesma partida. O timer automático retoma com um número quando vence o prazo, sem disparar números acumulados após queda.

O fluxo anterior de cartelas, pedidos e partidas permanece em Bingo geral. Cartelas antigas ou pendentes continuam consultáveis pelo servidor e por reenvio em DM quando disponível. Uma partida comunitária não consome cartelas pendentes do fluxo anterior; finalize a partida aberta antes de iniciar outra.

## TERMO diário

Em Games de Chat → TERMO Diário, defina canal, regras e palavras; ative e publique o painel. A aparência tem Mensagem e prévia; editar não cria rodada ou publica mensagem. O desafio troca à meia-noite no fuso configurado do servidor. Tamanho e tentativas ficam fixos durante a rodada atual.

O dicionário padrão passa a 664 formas normalizadas aceitas, das quais 532 podem ser respostas; palavras próprias e palavras desativadas são preservadas. Acentos são normalizados e letras repetidas são avaliadas em duas passagens. Palpites inválidos não consomem tentativa. O tabuleiro privado fica salvo para continuar depois, mostrando progresso e sequência de vitórias. A opção de revelar a palavra ao perder é respeitada.

Rankings diário, semanal e geral ficam na mesma tela. Compartilhar no TERMO envia uma vez a grade de cores e o resultado, sem letras nem palavra. É uma escolha do membro, independente da pontuação. O ranking semanal usa os pontos das vitórias registradas, sem zerar o histórico geral.

## Caixa Misteriosa

O painel principal reúne disponibilidade, prazo, aberturas e resultados. Há até 25 caixas; as caixas adicionais aparecem em Mais caixas para respeitar o limite de componentes do Discord. Meu resultado mostra o registro e o estado da entrega; Resultados oferece lista paginada. Cada pessoa continua abrindo uma caixa por evento.

Em Painel de participação e resultados, a equipe pode desativar anúncios por abertura e concentrar o evento em uma mensagem. O padrão preserva os anúncios anteriores. Cargos permanentes/temporários seguem os serviços existentes; COIN, XP, ITEM e CUSTOM permanecem pendentes de integração externa. A interface não simula entrega de prêmio.

## Quiz em equipes e demais eventos

Eventos de interação agora também abre o quiz já existente em `/guerra`. O painel de jogos dá acesso aos participantes, preservando o motor, as equipes e os controles administrativos existentes. Verdade ou Desafio, Game Musical, sorteios e Free Fire continuam em seus destinos. Esta etapa não cria um segundo motor de quiz nem uma loja/economia completa.

## Validação

185 testes offline, com Discord simulado e SQLite em memória; 24 telas reais de builders conferidas em desktop/celular. As quatro migrations foram exercitadas em cópia isolada do banco fornecido, preservando todos os valores/colunas das 123 tabelas anteriores. O CLI nativo migrate deploy não foi executado aqui. A checagem global TypeScript tem um erro anterior de denunciaSelects; a camada de produção foi atualizada de forma direcionada.

Não houve login, publicação real nem deploy. Após aplicar o pacote, valide em um servidor de teste: inscrição simultânea e DM fechada no Bingo, pausa/reinício do sorteio, vitória conjunta, tentativa repetida no TERMO, troca de dia e compartilhamento único, abertura simultânea e prêmios pendentes na Caixa. Publique painéis somente nos canais desejados.
